/*
***************************************************************************
*  Mediatek Inc.
* 4F, No. 2 Technology 5th Rd.
* Science-based Industrial Park
* Hsin-chu, Taiwan, R.O.C.
*
* (c) Copyright 2002-2011, Mediatek, Inc.
*
* All rights reserved. Mediatek's source code is an unpublished work and the
* use of a copyright notice does not imply otherwise. This source code
* contains confidential trade secret material of Ralink Tech. Any attemp
* or participation in deciphering, decoding, reverse engineering or in any
* way altering the source code is stricitly prohibited, unless the prior
* written consent of Mediatek, Inc. is obtained.
***************************************************************************

                Module Name:
                Channel Monitor

                Abstract:
                Per client monitoring

                Revision History:
                Who         When          What
                --------    ----------    -----------------------------------------
                Neelansh.M   2018/05/02     First implementation of the client monitor Module
*/
#include "includes.h"
#include "common.h"
#include "steer_fsm.h"
#include "list.h"
#include "client_db.h"
#include "mapd_i.h"
#ifdef SUPPORT_MULTI_AP
#include "data_def.h"
#endif
#include "chan_mon.h"
#include "wapp_if.h"
#ifdef SUPPORT_MULTI_AP
#include "topologySrv.h"
#endif
#include "client_mon.h"
#include "ap_roam_algo.h"
#include "ap_est.h"
#include "steer_action.h"
#ifdef SUPPORT_MULTI_AP
#include "tlv_parsor.h"
#include "mapd_user_iface.h"
#include "1905_map_interface.h"
#include "apSelection.h"
#endif
#include <assert.h>
#ifdef CENT_STR
#include "ap_cent_str.h"
#endif
#ifdef DATA_ELEMENT_SUPPORT
#include "de2json.h"
#endif

extern u8 ZERO_MAC_ADDR[ETH_ALEN];

void client_mon_handle_activity_change(struct mapd_global *global, uint32_t client_id, uint8_t act_stat)
{

	struct client *cli = &global->dev.client_db[client_id];
	cli->activity_state = act_stat;
}


/**
 * @brief : Handling a received probe request, update the clientDB according to the
 * probe and initiate pre assoc steering if required. Called from wlanif
 *
 * @param global : global device pointer
 * @param mac_addr : mac address of the client for which probe is received 
 * @param channel : channel on which the probe request is received
 * @param rssi : RSSI at which the probe is received 
 * @param preq_len : length of the probe request
 * @param preq : pointer to the probe request frame 
 * @param now : current time at which the event is received, used for timestamping
 */
void client_mon_handle_client_preq(struct mapd_global *global, uint8_t *mac_addr,
		uint8_t channel, uint8_t rssi, uint8_t preq_len, uint8_t *preq, struct os_reltime now
#ifdef MAP_6E_SUPPORT
		, uint8_t band
#endif
) {
	uint8_t idx = 0;
	struct mapd_radio_info *radio_info;
	struct client *cli;
	u8 already_seen = 0;
	uint32_t client_id;
	unsigned char *bssid;
	struct mapd_radio_info *preq_ra_info = NULL;
	uint8_t band_idx = 0;
#ifdef MAP_6E_SUPPORT
	uint8_t radio_band = 0;
	u8 is_triband = 0, is_6g = 0;
#ifdef SUPPORT_MULTI_AP
	struct _1905_map_device *own_1905_dev = NULL;
#endif
#endif

	/* Do not add locally administered mac addresses:
	 * Stations use Random mac addresses while scanning */
#if 0
	if (is_local_adm_ether_addr(mac_addr))
		return ;
#endif
		/* Update known bands and known channels */
#ifdef MAP_6E_SUPPORT
#ifdef SUPPORT_MULTI_AP
	own_1905_dev = topo_srv_get_1905_device(&global->dev, NULL);
	is_triband = check_is_triband(own_1905_dev);
	is_6g = check_is_6E(own_1905_dev);
#else
	is_triband = bs_check_is_triband(global);
	is_6g = bs_check_is_6E(global);
#endif

	if (band == WPS_BAND_24G) {
		band_idx = BAND_2G_IDX;
		radio_band = BAND_2G;
	} else if (band == WPS_BAND_5GL || band == WPS_BAND_5GH || band == WPS_BAND_5G) {
		band_idx = BAND_5G_IDX;
		if (isChan5GH(channel) && is_triband && !is_6g)
			radio_band = BAND_5GH;
		else
			radio_band = BAND_5GL;
	} else {
		band_idx = BAND_6G_IDX;
		radio_band = BAND_6G;
	}
#endif

#ifndef MAP_6E_SUPPORT
	if (mapd_get_radio_from_channel(global, channel) == NULL)
#else
	if (mapd_get_radio_from_channel_and_band(global, channel, radio_band) == NULL)
#endif
	{
		err(DEBUG_CAT_CLIENT_MON, "ERROR ********************** Invalid channel=%d*********************", channel);
		return;
	}

	/* Add to client DB: client_db_track_add */
	client_id = client_db_track_add(global, mac_addr, &already_seen);
	if (client_id == (uint32_t)-1) {
		err(DEBUG_CAT_CLIENT_MON, "No more room to accommodate" MACSTR
				", that is discovered", MAC2STR(mac_addr));
		return;
	}
	if (already_seen != 1) {
		 debug(DEBUG_CAT_CLIENT_MON, "New Client discovered"
					MACSTR, MAC2STR(mac_addr));
	}

	cli = &global->dev.client_db[client_id];

	/* Update known bands and known channels */
#ifndef MAP_6E_SUPPORT
	if(channel < 14) {
		cli->known_bands |= BAND_2G_SUPPORTED;
		band_idx = BAND_2G_IDX;
	} else {
		cli->known_bands |= BAND_5G_SUPPORTED;
		band_idx = BAND_5G_IDX;
	}
#else
	if (band == WPS_BAND_24G) {
		cli->known_bands |= BAND_2G_SUPPORTED;
	} else if (band == WPS_BAND_5GL || band == WPS_BAND_5GH || band == WPS_BAND_5G) {
		cli->known_bands |= BAND_5G_SUPPORTED;
	} else {
		cli->known_bands |= BAND_6G_SUPPORTED;
	}
#endif

	/* Update PHY CAPs */
	if (preq_len > 24 && preq_len <= PREQ_IE_LEN) {
		client_db_update_cli_ht_vht_cap(global, client_id, preq + 24, preq_len - 24, band_idx);
	}
	else {
		err(DEBUG_CAT_CLIENT_MON, "************* Invalid Preq length ***********");
		//assert(0);
		return;
	}

	/* Sure to support the channel on which preq is rx */
#ifndef MAP_6E_SUPPORT
	client_db_set_known_channels(global, client_id, channel);
#else
	client_db_set_known_channels(global, client_id, channel, radio_band);
#endif
	bssid = client_db_get_bssid(global, client_id);
	/* Not connected and Remote Steering not in Progress */
	if (is_zero_ether_addr(bssid) 
#ifdef SUPPORT_MULTI_AP
		&& cli->coord_data.cli_coordination_state == COORD_STATE_IDLE
#endif
	) {
#ifndef MAP_6E_SUPPORT
		preq_ra_info = mapd_get_radio_from_channel(global, channel);
#else
		preq_ra_info = mapd_get_radio_from_channel_and_band(global, channel, radio_band);
#endif
		if(preq_ra_info == NULL) {
			err(DEBUG_CAT_RADIO, "not got channel from radio");
			return;
		}
		/* Update RSSI on the channel on which preq is recvd */
		client_db_set_ul_rssi(global, cli->client_id, rssi, preq_ra_info->radio_idx, 1);	

		/* Use past learning */
		for (idx = 0; idx < MAX_NUM_OF_RADIO; ++idx) 
		{
			radio_info = &global->dev.dev_radio_info[idx];
			if (radio_info->radio_idx == (uint8_t)-1)
				continue;
			if (radio_info->radio_idx == preq_ra_info->radio_idx)
				continue;
#ifdef MAP_6E_SUPPORT
#ifdef SUPPORT_MULTI_AP
			uint8_t band_of_radio = get_band_6E(own_1905_dev, radio_info->channel, radio_info->op_class);
#else
			uint8_t band_of_radio = bs_get_band_6E(global, radio_info->channel, radio_info->op_class);
#endif

			if (!is_chan_supported(cli->known_channels, radio_info->channel,
				get_client_max_bw(radio_info->channel, cli, band_of_radio), band_of_radio))
#else
			if (!is_chan_supported(cli->known_channels, radio_info->channel,
				get_client_max_bw(radio_info->channel, cli)))
#endif
				continue;
			/* Estimate if the client is known to operate on this radio idx and
			 * if the RSSI is too old or unknown */
			if (os_reltime_expired(&now, &cli->rssi_ts[idx],
							global->dev.cli_steer_params.RSSIAgeLim_preAssoc)) {
				debug(DEBUG_CAT_CLIENT_MON, "Unassoc client =%d is known to operate"
								"on %d channel and RSSI is too old -- Estimate its RSSI",
								cli->client_id, radio_info->channel);
				ap_est_update_non_serving_rssi(global,
									cli,  preq_ra_info->radio_idx, idx);
				debug(DEBUG_CAT_CLIENT_MON, "Estimated RSSI =%d", cli->ul_rssi[idx]);
			}
		}
		/* Trigger pre-asoc str on preq recv(rssi-update) */
#ifdef CENT_STR
		if(!global->dev.cent_str_en)
#endif
		ap_roam_algo_chk_preassoc_str(global, cli);
	}
}
static coarse_phy_mode phy_mode_mapper(enum phy_mode phy_mode)
{
	switch(phy_mode) {
		case MODE_CCK:
		case MODE_OFDM:
			return LEGACY_MODE;
		case MODE_HTMIX:
		case MODE_HTGREENFIELD:
			return HT_MODE;
		case MODE_VHT:
			return VHT_MODE;
		case MODE_HE:
			return HE_MODE;
#ifdef MAP_EHT_SUPPORT
		case MODE_EHT:
			return EHT_MODE;
#endif
		default:
			return HT_MODE;
	}
}

/**
 * @brief : Called when new assoc is received (from wlanif) or when link metrics are
 * received for a client not in the DB. Add the client to clientDB, remove from
 * unassoc lists, add to assoc list, remove blacklists, reset statistics and update
 * info from the assoc IEs
 *
 * @param global : global device pointer
 * @param mac_addr : mac address of the client for which assoc received
 * @param bssid : BSSID on which connected
 * @param assoc_req : pointer to the assoc request
 * @param assoc_req_len : length of the assoc request
 *
 * @return 
 */
uint32_t client_mon_handle_local_join(struct mapd_global *global, u8 *mac_addr, u8 *bssid,
				u8 valid, u8 bBtm, u8 bRrm, u8 bMbo,
				int nss, enum phy_mode phy_mode, enum max_bw bw, struct map_he_nss *nss_he
#ifdef MAP_R6
				, enum PARAM_CLEAR is_clear
#endif /* MAP_R6 */
				)
{
	 uint32_t client_id;
	 u8 *old_bssid;
	 u8 already_seen = 0;
	 uint8_t channel = 0;
#ifdef MAP_6E_SUPPORT
	 uint8_t band, band_idx;
	struct os_reltime now = {0, 0};

	os_get_reltime(&now);
#endif
	 struct client *cli = NULL;
	 struct bss_info_db *bss_info = NULL;
	 struct _1905_map_device *own_dev = NULL;
	 /* Add to client DB: client_db_track_add */
	 info(DEBUG_CAT_CLIENT_MON, "Assoc for a client that has not been seen yet"
			MACSTR, MAC2STR(mac_addr));
	 client_id = client_db_track_add(global, mac_addr, &already_seen);
	if (client_id == (uint32_t)-1) {
		err(DEBUG_CAT_CLIENT_MON, "No more room to accommodate"
				MACSTR ", that is leaving a BSS on my device", MAC2STR(mac_addr));
		return -1;
	}
	 if (already_seen != 1) {
		err(DEBUG_CAT_CLIENT_MON, "Assoc for a client that has not been seen yet"
			MACSTR, MAC2STR(mac_addr));
	 }
	 cli = client_db_get_client_from_client_id(global, client_id);
	if (cli == NULL) {
		err(DEBUG_CAT_CLIENT_MON, "cli is NULL for client_id(%u) mac "MACSTR, client_id, MAC2STR(mac_addr));
		return -1;
	}
	 cli->in_db = IN_DB;
	 if (already_seen != 1)
		 cli->dirty = 1;

	 /* Remove all BLs due to STEER_ALGO*/
	 client_mon_bl_sta_for_all_bss(global, cli, 0, NULL, FALSE);

	 old_bssid = client_db_get_bssid(global, client_id);

	own_dev = topo_srv_get_1905_device(&global->dev, NULL);
	bss_info = topo_srv_get_bss_by_bssid(&global->dev, own_dev, old_bssid);

	 if (!is_zero_ether_addr(old_bssid) && bss_info) {
		notice(DEBUG_CAT_CLIENT_MON, "Got local join for client " MACSTR
				", that has not left me/remote BSS ", MAC2STR(mac_addr));
		client_db_remove_from_assoc_list(global, client_id);
		if (os_memcmp(old_bssid, bssid, ETH_ALEN)) {
			info(DEBUG_CAT_CLIENT_MON, "New bssid " MACSTR
				" .Issue local disconnect on old bssid " MACSTR,
				MAC2STR(bssid), MAC2STR(old_bssid));
			wlanif_deauth_sta(global, cli->mac_addr, old_bssid);
			if (cli->cli_steer_state == CLI_STATE_IDLE)
				cli->cli_steer_state = CLI_STATE_INVALID;
		}
	 }
#ifdef MAP_R6
	if (cli->mld_sta_profile) {
		err(DEBUG_CAT_MISC, "this is indication setup link processed before");
		if (is_clear == PARAM_CLEAR_FROM_LOCAL_JOIN)
			is_clear = PARAM_CLEAR_NO;
		err(DEBUG_CAT_MISC, "no need to clear assoc parameter");
	}
#endif /* MAP_R6 */
	 /* Clear PostAssoc Params */
	client_db_clear_post_assoc_params(global, client_id
#ifdef MAP_R6
			, is_clear
#endif /* MAP_R6 */
	);
	 /* Add to local assoc List */
	 mapd_add_client_to_bss_assoc_list(global, client_id, bssid);
	 client_db_set_bssid(global, client_id, bssid);
	 /* Client is connected to me -- It is no longer remote */
	 cli->is_remote = 0;
	 /* Update current Channel */
	 channel = mapd_get_channel_from_bssid(global, bssid);
#ifdef MAP_6E_SUPPORT
	 band = mapd_get_band_from_bssid(global, bssid);
	 client_db_set_curr_band(global, client_id, band);
	 cli->known_bands |= band;
	err(DEBUG_CAT_BSS, "channel %d band %d cli->known_bands %d", channel, band, cli->known_bands);
#endif
	 client_db_set_curr_channel(global, client_id, channel);

	 /* Update known_channels */
	 client_db_set_known_channels(global, client_id, channel
#ifdef MAP_6E_SUPPORT
			, band
#endif
	);
	 /* Update current radio_idx */
	 client_db_set_radio_idx(global, client_id,
					 mapd_get_radio_idx_from_bssid(global, bssid));

	 /* Update Caps */
	 if (valid) {
		 client_db_set_capab(global, client_id, bBtm, bRrm, bMbo);
#ifndef MAP_6E_SUPPORT
		 client_db_set_phy_capab(global, client_id, 2,
			(channel > 14 ? BAND_5G_IDX : BAND_2G_IDX),
			bw, nss, phy_mode_mapper(phy_mode));
#else
		if (IS_BAND_6G(band))
			band_idx = BAND_6G_IDX;
		else if (IS_BAND_5G(band))
			band_idx = BAND_5G_IDX;
		else
			band_idx = BAND_2G_IDX;

		err(DEBUG_CAT_CLIENT_MON, "(CLIENT_ASSOCIATED) bw %d nss %d phy_mode %d band_idx %d",
					bw, nss, phy_mode_mapper(phy_mode), band_idx);
		client_db_set_phy_capab(global, client_id, 2,
			band_idx, bw, nss, phy_mode_mapper(phy_mode));
#ifdef MAP_6E_SUPPORT
		cli->chan_id_trigger_ts = now;
#endif

#endif
		if (phy_mode_mapper(phy_mode) == HE_MODE) {
			debug(DEBUG_CAT_CLIENT_MON, "NSS_HE80: %d NSS_HE160: %d NSS_HE8080: %d\n",
				nss_he->nss_80, nss_he->nss_160, nss_he->nss_8080);
			client_db_set_he_phy_capab(global, client_id, nss_he);
		}
		 steer_action_sta_join(global, cli, 0);
	 }

	/* Trigger FSM */
	 info(DEBUG_CAT_CLIENT_MON, "Trigger FSM (CLIENT_ASSOCIATED)");
	 steer_fsm_trigger(global, client_id, CLIENT_ASSOCIATED, NULL);
	 return client_id;
}

/**
 * @brief : In the event that a client leaves one of the BSS on our system, remove
 * the client from assoc lists(if required), and trigger the state machine for the
 * client
 *
 * @param global : global device pointer
 * @param mac_addr : mac adress of the client leaving
 */
void client_mon_handle_local_leave(struct mapd_global *global, u8 *mac_addr,
				u8 *leaving_bssid)
{
	uint32_t client_id = 0;
	u8 already_seen = 0;
	u8 *curr_bssid = NULL;
	struct client *cli = NULL;
#ifdef SUPPORT_MULTI_AP
	struct bss_info_db *bss_info = NULL;
#endif

	/* Add to client DB: client_db_track_add */
	/* XXX : Why is the following required here? */
	client_id = client_db_track_add(global, mac_addr, &already_seen);
	if (client_id == (uint32_t)-1) {
		err(DEBUG_CAT_CLIENT_MON, "No more room to accommodate" MACSTR
			", that is leaving a BSS on my device", MAC2STR(mac_addr));
		return;
	}
	/*curr_bssid = client_db_get_bssid(global, client_id);*/
	cli = client_db_get_client_from_client_id(global, client_id);
	if (cli == NULL) {
		err(DEBUG_CAT_CLIENT_MON, "cli is NULL for client_id(%u) mac "MACSTR, client_id, MAC2STR(mac_addr));
		return;
	}
	cli->in_db = IN_DB;
	curr_bssid = client_db_get_bssid(global, client_id);
	info(DEBUG_CAT_CLIENT_MON, "client " MACSTR ") leave bssid (" MACSTR ")",
		MAC2STR(mac_addr), MAC2STR(leaving_bssid));
	/* Stale Local Leave */
	if (!curr_bssid || os_memcmp(curr_bssid, leaving_bssid, ETH_ALEN)) {
		notice(DEBUG_CAT_CLIENT_MON, "Stale Local leave");
		return;
	}
#ifdef SUPPORT_MULTI_AP
	bss_info = topo_srv_get_bss_by_bssid(&global->dev, NULL, leaving_bssid);
	if (bss_info) {
		info(DEBUG_CAT_CLIENT_MON, "inform local wifi sta leave: ssid: %s\n", bss_info->ssid);
		mapd_user_wireless_client_leave(global, mac_addr,
			leaving_bssid, (char *)bss_info->ssid);
	}
#endif
	if (already_seen != 1) {
		err(DEBUG_CAT_CLIENT_MON, "Dissaoc for a client that has not been seen yet"
					 MACSTR, MAC2STR(mac_addr));
		err(DEBUG_CAT_CLIENT_MON, "Trigger FSM (CLIENT_DISSOCIATED)");
		steer_fsm_trigger(global, client_id, CLIENT_DISSOCIATED, NULL);
		cli->dirty = 1;
		return;
	}
	/* Remove from assoc list */
	client_db_remove_from_assoc_list(global, client_id);
	/* Trigger FSM */
	info(DEBUG_CAT_CLIENT_MON, "Trigger FSM (CLIENT_DISSOCIATED)");
	steer_fsm_trigger(global, client_id, CLIENT_DISSOCIATED, NULL);
	/* Clear PostAssoc Tmp params */
	client_db_clear_post_assoc_params(global, client_id
#ifdef MAP_R6
			, PARAM_CLEAR_YES
#endif /* MAP_R6 */
	);
}
#ifdef SUPPORT_MULTI_AP
/**
 * @brief : Handle
 *
 * @param global
 * @param mac_addr
 * @param bssid
 * @param assoc_req
 * @param assoc_req_len
 */
void client_mon_handle_remote_join(struct mapd_global *global, u8 *mac_addr,
		  u8 *bssid, u8 * al_mac)
{
	uint32_t client_id;
	u8 already_seen = 0;
	u8 *old_bssid = NULL;
	struct client *cli = NULL;
#if defined(ROAM_CALIB)
	char str[150] = {0};
	int res;
#endif

	 /* Add to client DB: client_db_track_add */
	 client_id = client_db_track_add(global, mac_addr, &already_seen);
	 if (client_id == (uint32_t)-1) {
		  err(DEBUG_CAT_CLIENT_MON, "No more room to accommodate" MACSTR
					 ", that has joined a BSS on another device", MAC2STR(mac_addr));
		  return;
	 }
	 cli = client_db_get_client_from_client_id(global, client_id);
	if (cli == NULL) {
		err(DEBUG_CAT_CLIENT_MON, "cli is NULL for client_id(%u) mac "MACSTR, client_id, MAC2STR(mac_addr));
		return;
	}
	 cli->in_db = IN_DB;
	if (already_seen != 1) {
		notice(DEBUG_CAT_CLIENT_MON, "Remote JOIN client notific for a client that has not been seen yet " MACSTR,
					MAC2STR(mac_addr));
		cli->dirty = 1;
	}
	 /* Remove all BLs due to STEER_ALGO*/
	 client_mon_bl_sta_for_all_bss(global, cli, 0, NULL, FALSE);

	 old_bssid = client_db_get_bssid(global, client_id);
	 if (!is_zero_ether_addr(old_bssid)) {
		notice(DEBUG_CAT_CLIENT_MON, "Got remote client JOIN notific for client " MACSTR
				", that has not left a local/remote bss ", MAC2STR(mac_addr));
		  client_db_remove_from_assoc_list(global, client_id);
	 }
	 /* Clear PostAssoc Tmp params */
	client_db_clear_post_assoc_params(global, client_id
#ifdef MAP_R6
			, PARAM_CLEAR_NO
#endif /* MAP_R6 */
	);
	 /* Update BSSID */
	 cli->is_remote = 1;
	 client_db_set_bssid(global, client_id, bssid);
#ifdef MAP_R6
	client_db_set_bssid_mld(global, client_id, bssid);
#endif

#if 0
	 //TODO 
	 //channel = get_From_topo_server(bssid);
	 /* Update from Assoc IEs */
	 if(assoc_req_len > 28)
		 client_db_update_from_ies(global, client_id, assoc_req + 28,
				 assoc_req_len -28, channel);
#endif
#if defined(ROAM_CALIB)
	if (global->dev.RoamCalibEnable) {
		res = os_snprintf(str, sizeof(str), "Client Remote Join to BSSID %02x:%02x:%02x:%02x:%02x:%02x",
				PRINT_MAC(bssid));
		if (os_snprintf_error(sizeof(str), res)) {
			err(DEBUG_CAT_MISC, "Too long GET command.\n");
			return;
		}
		if (cli)
			RoamingCaldata(&global->dev, (u8 *)cli->mac_addr, (u8 *)cli->bssid, str);
	}
#endif

#ifndef CENT_STR
	steer_action_sta_join(global, cli, 1);
	/* Trigger FSM */
	 info(DEBUG_CAT_CLIENT_MON, "Trigger FSM (REMOTE_TOPOLOGY_NOTIFICATION)");
	 steer_fsm_trigger(global, client_id, REMOTE_TOPOLOGY_NOTIFICATION, NULL);
#else
	if (!global->dev.cent_str_en || global->dev.device_role == DEVICE_ROLE_AGENT) {
		steer_action_sta_join(global, cli, 1);
		/* Trigger FSM */
		 info(DEBUG_CAT_CLIENT_MON, "Trigger FSM (REMOTE_TOPOLOGY_NOTIFICATION)");
		 steer_fsm_trigger(global, client_id, REMOTE_TOPOLOGY_NOTIFICATION, NULL);
	}
#endif
}

/**
 * @brief
 *
 * @param global
 * @param mac_addr
 */
void client_mon_handle_remote_leave(struct mapd_global *global, struct client_assoc *assoc_notif)
{
	 uint32_t client_id;
	 u8 *old_bssid;
	 u8 already_seen = 0;
	 struct client *cli = NULL;
#ifdef MAP_R6
	u8 *old_bssid_mld = NULL;
	int i;
	struct client *aff_cli = NULL;
	uint32_t aff_client_id;
	int index;
#endif /* MAP_R6 */

	 /* Add to client DB: client_db_track_add */
	 client_id = client_db_track_add(global, assoc_notif->sta_addr, &already_seen);
	 if (client_id == (uint32_t)-1) {
		  err(DEBUG_CAT_CLIENT_MON, "No more room to accommodate" MACSTR
					 ", that has left a remote BSS", MAC2STR(assoc_notif->sta_addr));
		  return;
	 }

	 cli = client_db_get_client_from_client_id(global, client_id);
	 if (cli == NULL) {
		err(DEBUG_CAT_CLIENT_MON, "cli is NULL for client_id(%u) mac "MACSTR, client_id, MAC2STR(assoc_notif->sta_addr));
		return;
	}
	cli->in_db = IN_DB;

	 if (already_seen != 1) {
		err(DEBUG_CAT_CLIENT_MON, "Remote client LEAVE notific for a client that has not been seen yet " MACSTR,
				MAC2STR(assoc_notif->sta_addr));
		cli->dirty = 1;
		return;
	 }
	 /* Remove from local assoc list(just in-case we missed both local leave and remote join) */

	 if(cli->is_remote == 0) {
		err(DEBUG_CAT_CLIENT_MON, "Delayed remote topology notification... STA is already connected to us.ignore");
		return;
	 }
	 old_bssid = client_db_get_bssid(global, client_id);
#ifdef MAP_R6
	old_bssid_mld = client_db_get_bssid_mld(global, client_id);
#endif
#ifdef CENT_STR
	if (global->dev.cent_str_en && (os_memcmp(old_bssid, assoc_notif->bssid, ETH_ALEN) == 0
#ifdef MAP_R6
		|| os_memcmp(old_bssid_mld, assoc_notif->bssid, ETH_ALEN) == 0
#endif
	)) {
#endif
		if (!is_zero_ether_addr(old_bssid)
#ifdef MAP_R6
			|| !is_zero_ether_addr(old_bssid_mld)
#endif /* MAP_R6 */
		) {
			notice(DEBUG_CAT_CLIENT_MON, CENT_STEER_PREX"Got remote client LEAVE notific for client" MACSTR
					 ", that has not left a local/remote bss ", MAC2STR(assoc_notif->sta_addr));
#ifdef DATA_ELEMENT_SUPPORT
			if (global->dev.device_role == DEVICE_ROLE_CONTROLLER)
				create_sta_disassociation_json_file(&global->dev, cli->mac_addr, cli->is_remote);
#endif
			client_db_remove_from_assoc_list(global, client_id);
		}

		/* DO NOT Remove all BLs: Remote Steering would get affected */
		/* tRIgger FSM */
		info(DEBUG_CAT_CLIENT_MON, CENT_STEER_PREX"Trigger FSM (REMOTE_TOPOLOGY_NOTIFICATION)");
		/*steer_fsm_trigger(global, client_id, REMOTE_TOPOLOGY_NOTIFICATION, NULL);*/
#ifdef CENT_STR
		if ((global->dev.cent_str_en && global->dev.device_role == DEVICE_ROLE_CONTROLLER)) {
			remove_entry_fail_candidate_list(cli, &global->dev);
			steer_fsm_trigger(global, client_id, CLIENT_DISSOCIATED, NULL);
		}
#endif
#ifdef MAP_R6
		if (cli->mlo_enable) {
			notice(DEBUG_CAT_MISC, "mlo enabled client found");
			index = 0;
			for (i = 0; i < MAX_MLD_CLI; i++) {
				aff_client_id = client_db_get_cid_from_mld_mac(global, cli->mld_addr, index);
				if (aff_client_id == (uint32_t)-1) {
					err(DEBUG_CAT_CLIENT_DB, "client id not found by mld mac");
					break;
				}
				index = aff_client_id + 1;
				notice(DEBUG_CAT_CLIENT_DB, "aff_client_id = %u", aff_client_id);
				if (aff_client_id == cli->client_id) {
					notice(DEBUG_CAT_CLIENT_DB, "This is same client will clear db after affiliated client");
					continue;
				}
				aff_cli = client_db_get_client_from_client_id(global, aff_client_id);
				if (aff_cli == NULL) {
					err(DEBUG_CAT_CLIENT_DB, "cli is NULL for client_id(%u) mac ", aff_client_id);
					continue;
				}
				aff_cli->in_db = IN_DB;
				aff_cli->dirty = 1;
				notice(DEBUG_CAT_CLIENT_DB, "Going to clear client db data for affilitaed link");
				client_db_clear_post_assoc_params(global, aff_client_id, PARAM_CLEAR_YES);
				aff_cli->is_remote = 0;
			}
		}
#endif /* MAP_R6 */

		/* Clear PostAssoc Tmp params */
		client_db_clear_post_assoc_params(global, client_id
#ifdef MAP_R6
			, PARAM_CLEAR_YES
#endif /* MAP_R6 */
		);
		cli->is_remote = 0;
#ifdef CENT_STR
	}
#endif
}

#ifdef MAP_R6
struct bss_info_db *find_bss_from_dev_by_bssid(struct _1905_map_device *dev, unsigned char *bssid)
{
	struct mld_bss_config_db *mld_bss;
	struct mlo_config_db *mlo_cfg;
	struct affiliated_ap_db *aff_ap;
	struct bss_info_db *bss = NULL;
	int count;

	mld_bss = &dev->mld_bss;

	dl_list_for_each(mlo_cfg, &mld_bss->mlo_cfg_list, struct mlo_config_db, list) {
		info(DEBUG_CAT_CLIENT_MON, "mlo_cfg = "MACSTR, MAC2STR(mlo_cfg->mld_mac));
		count = 0;
		if (os_memcmp(mlo_cfg->mld_mac, bssid, ETH_ALEN) == 0) {
			/* indicate ap mld found now need to find bss entry by affiliated bssid */
			dl_list_for_each(aff_ap, &mlo_cfg->aff_ap_list, struct affiliated_ap_db, list) {
				bss = topo_srv_get_bss(dev, (char *)aff_ap->affiliated_ap_bssid);
				if (bss) {
					count++;
					notice(DEBUG_CAT_BSS, "found bss = " MACSTR, MAC2STR(bss->bssid));
				}
			}
			if (mlo_cfg->num_affiliated_ap == count) {
				notice(DEBUG_CAT_BSS, "this is same bss with mld mac with count = %d", count);
				return bss;
			}
		}
	}
	return(bss);
}

unsigned char find_mld_enable_from_assoc_sta_bssid_map(struct _1905_map_device *dev, unsigned char *sta_mac)
{
	struct topo_connected_ap_sta_map *sta;

	dl_list_for_each(sta, &dev->ap_sta_map_head, struct topo_connected_ap_sta_map, entry) {
		if (!memcmp(sta->sta_mac, sta_mac, ETH_ALEN)) {
			notice(DEBUG_CAT_MISC, "sta->sta_mac " MACSTR, MAC2STR(sta->sta_mac));
			notice(DEBUG_CAT_BSS, "sta->bssid_mac " MACSTR, MAC2STR(sta->bssid_mac));
			return sta->is_mld_sta;
		}
	}
	return(0);
}


#endif /* MAP_R6 */

void client_mon_handle_topo_notification(struct mapd_global *global,struct topo_notification *evt)
{
	u8 i;

	for (i = 0; i < evt->assoc_cnt; i++) {
		/* Ignore BACKHAUL STAs */
		/* All all STA/Backhaul STA as well*/
		/* Remove Backhaul STA using topology response */
#if 0
		if (is_local_adm_ether_addr(evt->assoc[i].sta_addr))
			return ;
#endif
#ifdef MAP_R2
		struct _1905_map_device *_1905_dev = topo_srv_get_1905_device(&global->dev, evt->al_mac);
#endif
		if(evt->assoc[i].is_joined) {
#ifdef CENT_STR
			if (!global->dev.cent_str_en || global->dev.device_role == DEVICE_ROLE_AGENT)
#endif
			client_mon_handle_remote_join(global,evt->assoc[i].sta_addr, evt->assoc[i].bssid, evt->al_mac);
#ifdef CENT_STR
			else{
#ifdef MAP_R2
				if ((global->dev.map_version == DEV_TYPE_R2 
#ifdef MAP_R3
					||	global->dev.map_version == DEV_TYPE_R3
#endif
					) && _1905_dev && (_1905_dev->map_version == DEV_TYPE_R2
#ifdef MAP_R3
					||	_1905_dev->map_version == DEV_TYPE_R3
#endif
					)) {
					struct bss_info_db *bss = topo_srv_get_bss(_1905_dev, (char *)evt->assoc[i].bssid);
#ifdef MAP_R6
					if (!bss) {
						err(DEBUG_CAT_BSS, "bss not found for bssid = " MACSTR " try to check via mld mac",
							MAC2STR(evt->assoc[i].bssid));
						bss = find_bss_from_dev_by_bssid(_1905_dev, evt->assoc[i].bssid);
					}
#endif /* MAP_R6 */
					if (bss) {
					client_mon_handle_remote_join(global, evt->assoc[i].sta_addr,
									evt->assoc[i].bssid, _1905_dev->_1905_info.al_mac_addr);
					uint32_t client_id = client_db_get_cid_from_mac(global, evt->assoc[i].sta_addr);
#ifdef MAP_R6
					if (client_id == (uint32_t)-1)
						client_id = client_db_get_cid_from_mld_mac(global, evt->assoc[i].sta_addr, 0);
#endif

					if (!bss->radio) {
						err(DEBUG_CAT_BSS, "bss radio is null");
						return;
					}


#ifdef MAP_6E_SUPPORT
#ifdef MAP_R6
					if (!find_mld_enable_from_assoc_sta_bssid_map(_1905_dev, evt->assoc[i].sta_addr) &&
							client_id != (uint32_t)-1) {
						client_db_set_curr_channel(global, client_id, bss->radio->channel[0]);
						client_db_set_curr_band(global, client_id, bss->radio->band);
					}
#else
					if (client_id != (uint32_t)-1) {
					client_db_set_curr_channel(global, client_id, bss->radio->channel[0]);
					client_db_set_curr_band(global, client_id, bss->radio->band);
					}
#endif /* MAP_R6 */
#else
					if (client_id != (uint32_t)-1)
						client_db_set_curr_channel(global, client_id, bss->radio->channel[0]);
#endif
					}
				} else
#endif
				map_1905_Send_Client_Capability_Query_Message(global->_1905_ctrl, (char *) evt->al_mac,
						evt->assoc[i].bssid, evt->assoc[i].sta_addr);
				
			}
#endif
		} else {
			client_mon_handle_remote_leave(global, &evt->assoc[i]);
		}
	}
}
#endif

void client_mon_handle_link_metrics(struct mapd_global *global, u8 *sta_mac,
				uint32_t dl_phy_rate, int8_t ul_rssi, u8 *bssid)
{
	uint8_t radio_idx = 0;
	struct client *cli = NULL;
	uint32_t client_id = client_db_get_cid_from_mac(global, sta_mac);

	if (client_id == (uint32_t)-1) {
		client_id = client_mon_handle_local_join(global, sta_mac,
						bssid, 0, 0, 0, 0, 0, 0, 0, NULL
#ifdef MAP_R6
			, PARAM_CLEAR_NO
#endif /* MAP_R6 */
				);
		if (client_id == (uint32_t)-1) {
			err(DEBUG_CAT_CLIENT_MON, "new assoc seen-->But no more room");
			return;
		}
		debug(DEBUG_CAT_CLIENT_MON, "new assoc seen-->assigned_id=%d",
						client_id);
	}

	cli = client_db_get_client_from_client_id(global, client_id);

	if (cli && os_memcmp(cli->bssid, bssid, ETH_ALEN)) {
		debug(DEBUG_CAT_CLIENT_MON, "Err: Different bssid(present in 2 wapp wdev tables)"
						MACSTR, MAC2STR(cli->mac_addr));
		return;
	}
	if (cli && cli->cli_steer_state > CLI_STATE_IDLE) {
		debug(DEBUG_CAT_CLIENT_MON, "Steering in progress for " MACSTR,
						MAC2STR(cli->mac_addr));
		return;
	}

	radio_idx = mapd_get_radio_idx_from_bssid(global, bssid);
	if(radio_idx > MAX_NUM_OF_RADIO) {
		err(DEBUG_CAT_CLIENT_MON, "radio_idx (%d) invalid", radio_idx);
		return;
	}
	client_db_set_dl_phy_rate(global, client_id, dl_phy_rate);
	client_db_set_ul_rssi(global, client_id, ul_rssi, radio_idx, FALSE);
}
#ifdef MTK_MLO_MAP_SUPPORT
void client_mon_mlo_fill_activity_state(
	struct mapd_global *global,
	struct client *cli,
	uint32_t thresh)
{
	uint32_t idx = 0;
	struct client *mld_cli;
	uint32_t tp_rate = 0;
	u8 ml_cnt = 0;

	for (idx = 0; idx < MAX_MLD_CLI; ++idx) {
		if (!cli->mld_clients[idx])
			continue;
		if (os_memcmp(cli->mld_clients[idx]->mld_addr, cli->mld_addr, ETH_ALEN))
			continue;
		mld_cli = cli->mld_clients[idx];
		tp_rate = tp_rate + mld_cli->bytes_check;
		ml_cnt++;
	}
	if (!ml_cnt) {
		err(DEBUG_CAT_MISC, "ml_cnt is 0 return");
		return;
	}
	/*find avg tp_rate*/
	tp_rate = tp_rate / ml_cnt;
	info(DEBUG_CAT_CLIENT_MON, "ml_cnt %d, tp_rate %d, thresh %d", ml_cnt, tp_rate, thresh);
	if (tp_rate > thresh)
		cli->curr_activity_state = 1;
	else
		cli->curr_activity_state = 0;

	info(DEBUG_CAT_CLIENT_MON, "cli active state %d", cli->curr_activity_state);
}
#endif
void client_mon_handle_tp_metrics(struct mapd_global *global, u8 *sta_mac,
				uint32_t tx_tp, uint32_t rx_tp, u8 *bssid)
{
	uint32_t client_id = client_db_get_cid_from_mac(global, sta_mac);
	struct client *cli = NULL;

	if (client_id == (uint32_t)-1) {
		client_id = client_mon_handle_local_join(global, sta_mac,
						bssid, 0, 0, 0, 0, 0, 0, 0, NULL
#ifdef MAP_R6
			, PARAM_CLEAR_NO
#endif /* MAP_R6 */
						);
		if (client_id == (uint32_t)-1) {
			err(DEBUG_CAT_CLIENT_MON, "new assoc seen-->But no more room");
			return;
		}
		debug(DEBUG_CAT_CLIENT_MON, "new assoc seen-->assigned_id=%d",
						client_id);
	}

	cli = client_db_get_client_from_client_id(global, client_id);
	if (cli == NULL) {
		err(DEBUG_CAT_CLIENT_MON, "cli is NULL for client_id(%u) mac "MACSTR, client_id, MAC2STR(sta_mac));
		return;
	}
	if (os_memcmp(cli->bssid, bssid, ETH_ALEN)) {
		debug(DEBUG_CAT_CLIENT_MON, "Err: Different bssid(present in 2 wapp wdev tables)"
						MACSTR, MAC2STR(cli->mac_addr));
		return;
	}
	if (cli->cli_steer_state > CLI_STATE_IDLE) {
		debug(DEBUG_CAT_CLIENT_MON, "Steering in progress for " MACSTR,
						MAC2STR(cli->mac_addr));
		return;
	}

	cli->dl_rate = (u16)((u32)tx_tp >> 17); //Convert to Mbps
	cli->ul_rate = (u16)((u32)rx_tp >> 17);
/* Update the Activity Status */
#ifndef MTK_MLO_MAP_SUPPORT
	if (tx_tp + rx_tp > global->dev.cli_steer_params.ActivityThreshold)
		cli->curr_activity_state = 1;
	else
		cli->curr_activity_state = 0;
#else
	debug(DEBUG_CAT_CLIENT_MON, "Cli for mlo_enable %d" MACSTR,
						cli->mlo_enable, MAC2STR(cli->mac_addr));
	if (cli->mlo_enable) {
		cli->bytes_check = tx_tp + rx_tp;
		client_mon_mlo_fill_activity_state(global, cli, global->dev.cli_steer_params.ActivityThreshold);
	} else {
		if (tx_tp + rx_tp > global->dev.cli_steer_params.ActivityThreshold)
			cli->curr_activity_state = 1;
		else
			cli->curr_activity_state = 0;
	}
#endif
}

void client_mon_get_assoc_stats(struct mapd_global *global)
{
	uint8_t i = 0;
	struct mapd_radio_info *ra_info = NULL;
	struct mapd_bss *bss = NULL;
	struct client *cli = NULL;
	uint32_t rssi_refresh_num_clients = 0;
	struct os_reltime now = {0, 0};
#ifdef MAP_R6
	struct _1905_map_device *own_1905_dev = NULL;

	own_1905_dev = topo_srv_get_1905_device(&global->dev, NULL);
	if (SLIST_EMPTY(&own_1905_dev->assoc_clients) && SLIST_EMPTY(&own_1905_dev->wlan_clients))
		return;
#endif /* MAP_R6 */

	os_get_reltime(&now);

	for(i = 0; i < MAX_NUM_OF_RADIO; i++) {
		ra_info = &global->dev.dev_radio_info[i];
		if (ra_info->radio_idx == (uint8_t)-1)
			continue;

		/* Get Assoc STA Stats */
		wlanif_get_all_assoc_sta_link_metrics(global, ra_info->identifier); 
#ifdef MAP_R2
		wlanif_get_all_assoc_sta_ext_link_metrics(global, ra_info->identifier);
#endif
		/* Get STA TP matrics */
		wlanif_get_all_assoc_sta_tp_metrics(global, ra_info->identifier);
		/* Get Traffic stats for all STAs */
		wlanif_get_assoc_sta_traffic_stats(global, ra_info->identifier);
#ifdef MAP_R6
		wlanif_get_assoc_sta_mld_traffic_stats(global, ra_info->identifier);
#endif
		dl_list_for_each(bss, &ra_info->bss_list, struct mapd_bss, bss_entry) {
			dl_list_for_each(cli, &bss->assoc_sta_list, struct client, assoc_sta_entry) {
				cli->curr_air_time = ap_est_get_airtime(global, cli->ul_rate,
								cli->dl_rate, cli->dl_phy_rate);
				/* Monitor RSSI freshness */
				if (global->dev.cli_steer_params.ForcedRssiUpdate) {
						if ((os_reltime_expired(&now, &cli->rssi_ts[cli->radio_idx],
												global->dev.cli_steer_params.RSSIAgeLim)) &&
							(os_reltime_expired(&now, &cli->null_frame_trigger_ts, 30)) &&
							(rssi_refresh_num_clients * global->dev.cli_steer_params.RSSIMeasureSamples < 50)) { //only 50 in 1 burst
								/* Trigger NULL frame */
								wlanif_trigger_null_frames(global, cli->mac_addr, cli->bssid,
												global->dev.cli_steer_params.RSSIMeasureSamples);
								os_get_reltime(&cli->null_frame_trigger_ts);
								rssi_refresh_num_clients++;
						}
				}
			}
		}
	}
}

void client_mon_chk_post_assoc_str(struct mapd_global *global)
{
	struct steer_cands *cand = NULL;
#ifdef SUPPORT_MULTI_AP
	struct steer_cands *t_cand = NULL;
#endif
	struct own_1905_device *ctx = &global->dev;
	struct client *arr_cand_list[MAX_STA_SEEN];
	int cand_cnt = 0, i;

#ifdef SUPPORT_MULTI_AP
	if(global->dev.SetSteer==STEER_DISABLE){
		err(DEBUG_CAT_CLIENT_MON, "Steering is disabled");
		return;
	}
#endif

	/* Check if post-assoc steering is disabled */
	if (global->dev.cli_steer_params.disable_post_assoc_strng)
		return;

	/* Steering already in progress */
	cand = NULL;
#ifdef SUPPORT_MULTI_AP
	SLIST_FOREACH_SAFE(cand, &ctx->steer_cands_head, next_cand, t_cand) {
	if (cand->steer_cand->cli_steer_method == MANDATE)
		return;
	}
#endif
	ap_roam_algo_select_steer_candidate(global, arr_cand_list, &cand_cnt);
	for (i = 0 ; i < cand_cnt ; i++) {
		cand = NULL;
		notice(DEBUG_CAT_CLIENT_MON, "[Steer] Trigger Steering for client =%d "MACSTR,
					arr_cand_list[i]->client_id, MAC2STR(arr_cand_list[i]->mac_addr));
		/* Once steering is complete, Below 2 shall be reset
		 * Also, send steer complete when only_one_in_win is set*/
#ifdef MAP_R6
		if (arr_cand_list[i]->mlo_enable && !arr_cand_list[i]->mlo_setup_link) {
			err(DEBUG_CAT_CLIENT_DB, "it is not setup link continue for this client id = %u", arr_cand_list[i]->client_id);
			continue;
		}
#endif /* MAP_R6 */
		cand = os_zalloc(sizeof(*cand));
		if (!cand)
			return;
		cand->steer_cand = arr_cand_list[i];
		os_memcpy(cand->steer_cand_home_bssid, arr_cand_list[i]->bssid, ETH_ALEN);
		SLIST_INSERT_HEAD(&ctx->steer_cands_head, cand, next_cand);
		steer_fsm_trigger(global, arr_cand_list[i]->client_id,
					mapd_get_trigger_from_steer_method(global,
							arr_cand_list[i]->cli_steer_method), NULL);
	}
}

/**
 * @brief: Install/Uninstall BL for this client on all BSSs except, excluding_bssids 
 * @param global
 * @param cli
 * @param num_bssid
 * @param excluding_bssid_arr[][ETH_ALEN]
 * @param blacklist
 */
void client_mon_bl_sta_for_all_bss(struct mapd_global *global, struct client *cli,
		u8 num_bssid, u8 excluding_bssid_arr[][ETH_ALEN], Boolean blacklist)

{
	uint8_t idx = 0, j = 0;
	struct mapd_bss *bss = NULL;
	uint8_t num_bss = 0;
	struct mapd_bss *bss_arr[MAX_NUM_BSS];
	struct mapd_radio_info *radio_info = NULL;


	for (idx = 0; idx < MAX_NUM_OF_RADIO; ++idx)
	{
		radio_info = &global->dev.dev_radio_info[idx];
		if (radio_info->radio_idx == (uint8_t)-1)
			continue;
		dl_list_for_each(bss, &radio_info->bss_list, struct mapd_bss, bss_entry)
		{
			for (j = 0; j < num_bssid; j++) {
				u8 *bssid = (u8 *)excluding_bssid_arr[j];
				if (!os_memcmp(bss->bssid, bssid, ETH_ALEN))
					break;
			}
			if (j < num_bssid){
				info(DEBUG_CAT_CLIENT_MON, "Excl BSSID" MACSTR, MAC2STR(bss->bssid));
			} else {
				bss_arr[num_bss++] = bss;
			}
		}
	}
	client_mon_bl_sta_for_bss(global, cli, num_bss, bss_arr, blacklist);
}

Boolean is_cli_bl_map_assoc_control(struct mapd_global *global, struct client *cli)
{
	int i = 0;
	for (i = 0; i < MAX_NUM_OF_RADIO; i++) {
		struct mapd_radio_info *ra_info = NULL;
		ra_info = &global->dev.dev_radio_info[i];
		if (ra_info->radio_idx == (uint8_t)-1)
			continue;
		struct mapd_bss *bss = NULL;
		dl_list_for_each(bss, &ra_info->bss_list, struct mapd_bss, bss_entry) {
				struct bl_client *bl_sta = NULL;
				dl_list_for_each(bl_sta, &bss->bl_sta_list, struct bl_client,
								list_entry) {
						if (bl_sta->cli != cli)
							continue;
						if (bl_sta->bl_reason & BL_MAP_ASSOC_CONTROL)
							return TRUE;
				}
		}
	}
	return FALSE;
}

void client_mon_force_unblock_cli_on_all_bss(struct mapd_global *global, struct client *cli)
{
	int i = 0;
	u8 block = 0;

	for (i = 0; i < MAX_NUM_OF_RADIO; i++) {
		struct mapd_radio_info *ra_info = NULL;
		struct mapd_bss *bss = NULL;

		ra_info = &global->dev.dev_radio_info[i];
		if (ra_info->radio_idx == (uint8_t)-1)
			continue;

		dl_list_for_each(bss, &ra_info->bss_list, struct mapd_bss, bss_entry) {
			struct bl_client *bl_sta_curr = NULL, *bl_sta_next = NULL;
			dl_list_for_each_safe(bl_sta_curr, bl_sta_next, &bss->bl_sta_list,
							struct bl_client, list_entry) {
				struct map_dev *map_dev_curr = NULL, *map_dev_next = NULL;
				if (bl_sta_curr->cli != cli)
					continue;
				dl_list_for_each_safe(map_dev_curr, map_dev_next, &bl_sta_curr->map_dev_list,
								struct map_dev, map_dev_entry) {
					dl_list_del(&map_dev_curr->map_dev_entry);
					os_free(map_dev_curr);
				}
				if (wlanif_bl_sta_for_bss(global, bl_sta_curr->cli->mac_addr,
										bss->bssid, block) == 0) {
					debug(DEBUG_CAT_CLIENT_MON, " %d(" MACSTR
								") UNBLACKLISTED ON BSSID=" MACSTR,
								bl_sta_curr->cli->client_id,
								MAC2STR(bl_sta_curr->cli->mac_addr),
								MAC2STR(bss->bssid));
				} else {
					err(DEBUG_CAT_CLIENT_MON, "%d(" MACSTR ") UN-BLACKLISTING ON BSSID="
								MACSTR " FAILED", cli->client_id,
								MAC2STR(cli->mac_addr),
								MAC2STR(bss->bssid));
				}
				dl_list_del(&bl_sta_curr->list_entry);
				os_free(bl_sta_curr);
			}
		}
	}
}


void client_mon_block_check(struct mapd_global *global)
{
	int i = 0;

	for (i = 0; i < MAX_NUM_OF_RADIO; i++) {
		struct mapd_radio_info *ra_info = NULL;
		struct mapd_bss *bss = NULL;
		ra_info = &global->dev.dev_radio_info[i];
		if (ra_info->radio_idx == (uint8_t)-1)
			continue;
		dl_list_for_each(bss, &ra_info->bss_list, struct mapd_bss, bss_entry) {
				struct bl_client *bl_sta = NULL, *bl_sta_next = NULL;
				dl_list_for_each_safe(bl_sta, bl_sta_next, &bss->bl_sta_list, struct bl_client,
								list_entry) {
						struct map_dev *tmp = NULL, *next = NULL;
						if (!(bl_sta->bl_reason & BL_MAP_ASSOC_CONTROL))
							continue;
						dl_list_for_each_safe(tmp, next, &bl_sta->map_dev_list,
										struct map_dev, map_dev_entry) {
								if (tmp->duration <= 0) //Blocked till unblocked
									continue;
								tmp->duration--;
								if (tmp->duration == 0) {
									info(DEBUG_CAT_CLIENT_MON, "BL done by al_mac " MACSTR
													" timed out for " MACSTR
													" on " MACSTR, MAC2STR(tmp->al_mac),
													MAC2STR(bl_sta->cli->mac_addr),
													MAC2STR(bss->bssid));
									client_mon_unblock_cli_on_bss(global, bss,
													bl_sta->cli,
													BL_MAP_ASSOC_CONTROL,
													tmp->al_mac
#ifdef MTK_MLO_MAP_SUPPORT
													, bl_sta->cli->mlo_enable
#endif /* MTK_MLO_MAP_SUPPORT */
													);
								}
								if (dl_list_empty(&bss->bl_sta_list)) {
									info(DEBUG_CAT_CLIENT_MON, "list is empty break");
									break;
								}
						}
					if (dl_list_empty(&bss->bl_sta_list)) {
						info(DEBUG_CAT_CLIENT_MON, "list is empty break");
						break;
					}
				}
		}
	}
}
/**
 * @brief : This function is used to deduce the channels supported by a connected
 * STA. Should only be called for clients that support Active Beacon Requests.
 *
 * @param global : global device pointer
 * @param cli : struct client
 */
#if !defined(MAP_6E_SUPPORT) || !defined(SUPPORT_MULTI_AP)
static int client_mon_chan_id(struct mapd_global *global, struct client *cli)
{
	u8 chan_id_bssid[] = {0xff, 0xff, 0xff, 0xff, 0xff, 0xff};
	struct mapd_radio_info *ra_info = NULL;
	uint8_t i = 0;
#ifdef MAP_6E_SUPPORT
	uint8_t band;
#endif

	for (i = 0; i < MAX_NUM_OF_RADIO; i++) {
		ra_info = &global->dev.dev_radio_info[i];
		if (ra_info->radio_idx == (uint8_t)-1) {
			err(DEBUG_CAT_CLIENT_MON, "Trigger Channel ID on Channel NULL for ");
			continue;
		}

#ifdef MAP_6E_SUPPORT
		band = bs_get_band_6E(global, ra_info->channel, ra_info->op_class);

		if (is_chan_supported(cli->known_channels, ra_info->channel,
			get_client_max_bw(ra_info->channel, cli, band), band))
#else
		if (is_chan_supported(cli->known_channels, ra_info->channel,
			get_client_max_bw(ra_info->channel, cli)))
#endif
			continue;
		/* Already tried; Treat this channel as unsupported */
		if (cli->chan_id_tries[i] >= 5)
			continue;

		/* Trigger an Unaccounted(response would be ignored) active meas req
		 * This will hopefuly trigger probe req from the STA */
		err(DEBUG_CAT_CLIENT_MON, "Trigger Channel ID on Channel %d for " MACSTR, ra_info->channel,
					MAC2STR(cli->mac_addr));
		wlanif_beacon_metrics_query(global, cli->mac_addr, cli->bssid,
						0, NULL,
						ra_info->channel,
#ifdef MAP_6E_SUPPORT
						chan_mon_get_op_class_frm_channel(ra_info->channel, BW_20, band),
#else
						chan_mon_get_op_class_frm_channel(ra_info->channel, BW_20),
#endif
						chan_id_bssid,
						0, 0, NULL, 0, NULL);
		cli->chan_id_tries[i]++;
		return 1;
	}
	return 0;
}
#else
static int client_mon_chan_id_cent(struct mapd_global *global, struct client *cli)
{
	u8 chan_id_bssid[] = {0xff, 0xff, 0xff, 0xff, 0xff, 0xff};
	struct radio_info_db *ra_info = NULL;
	uint8_t i = 0, measurement_band = BAND_UNKNOWN, is_1905_6G = 0;
	struct _1905_map_device *map_1905_dev = NULL;
	struct bss_info_db *bss = NULL, *bss_tmp, *measurement_bss = NULL;

	map_1905_dev = topo_srv_get_1905_by_bssid(&global->dev, cli->bssid);
	if (!map_1905_dev)
		return 0;

	is_1905_6G = check_is_6E(map_1905_dev);

	for (i = 0; i < IEEE_NUM_BANDS; i++) {
		if (cli->chan_id_tries[i] < CLI_11K_BAND_MEAS_RETRY) {
			if (i == 2 && is_1905_6G == TRUE)
				measurement_band = BAND_6G;
			else
				measurement_band = i + 1;
			cli->chan_id_tries[i]++;
			break;
		}
	}

	if (measurement_band == BAND_UNKNOWN)
		return 1;

	SLIST_FOREACH_SAFE(bss, &map_1905_dev->first_bss, next_bss, bss_tmp) {

		if (bss && !bss->radio) {
			err(DEBUG_CAT_RADIO, "bss radio is null");
			continue;
		}

		if (bss->radio->band == measurement_band) {
			measurement_bss = bss;
			break;
		}
	}

	ra_info = topo_srv_get_radio_by_band_type(map_1905_dev, measurement_band);

	if (!ra_info || !measurement_bss)
		return 0;

	if (cli->current_band == ra_info->band) {
		err(DEBUG_CAT_CLIENT_MON, "No need to seend 11k, as client's known band");
		return 1;
	}

	err(DEBUG_CAT_CLIENT_MON, "Trigger Channel ID on Channel %d for " MACSTR, ra_info->channel[0],
					MAC2STR(cli->mac_addr));
	cli->meas_data.cli_measurement_state = MEAS_STATE_11K_TEST;
	if (map_1905_dev->device_role == DEVICE_ROLE_CONTROLLER
			|| map_1905_dev->device_role == DEVICE_ROLE_CONTRAGENT)
		wlanif_beacon_metrics_query(global, cli->mac_addr, cli->bssid, measurement_bss->ssid_len, measurement_bss->ssid,
						ra_info->channel[0],
						chan_mon_get_op_class_frm_channel(ra_info->channel[0], BW_20, ra_info->band),
						chan_id_bssid,
						0, 0, NULL, 0, NULL);
	else
		topo_srv_trigger_beacon_metrics_query(global, map_1905_dev, cli->mac_addr, cli->bssid,
					measurement_bss->ssid_len, measurement_bss->ssid,
					ra_info->channel[0],
					chan_mon_get_op_class_frm_channel(ra_info->channel[0], BW_20, ra_info->band),
					chan_id_bssid,
					0, 0, NULL, 0, NULL);
	return 1;
}
#endif

void client_channel_change_handle(struct mapd_global *global, uint8_t radio_idx)
{
	struct client *cli = NULL;
	int i;

	if (radio_idx >= MAX_NUM_OF_RADIO)
		return;

	for (i = 0; i < MAX_STA_SEEN; i++) {
		cli = &global->dev.client_db[i];
		if (cli->client_id == (uint32_t)-1)
			continue;

		/* reset beacon query retry for connected STA */
		if (!is_zero_ether_addr(cli->bssid)) {
			cli->chan_id_tries[radio_idx] = 0;
			info(DEBUG_CAT_CLIENT_MON, "chan_id_tries reset for STA=" MACSTR, MAC2STR(cli->mac_addr));
		}
	}
}

/**
 * @brief : Periodic maintenance of the clientDB, called from the periodic thread
 *
 * @param global : Global device pointer
 */
void client_mon_cli_db_maintenance(struct mapd_global *global)
{
	struct client *cli = NULL;
	int i;
	struct os_reltime now = {0, 0};

	os_get_reltime(&now);

	for(i = 0; i < MAX_STA_SEEN; i++) {
		cli = &global->dev.client_db[i];
		if (cli->client_id == (uint32_t)-1) {
			continue;
		}

		/* Use Active Meas Request to identify channels supported by the STA */
#ifndef MAP_6E_SUPPORT
		if (
#ifdef SUPPORT_MULTI_AP
			global->params.Certification == 0 &&
#endif
#ifdef CENT_STR
			!global->dev.cent_str_en &&
#endif
			(!is_zero_ether_addr(cli->bssid)) &&
			(cli->cli_steer_state == CLI_STATE_IDLE) &&
			(cli->capab & CLI_CAP_11K) &&
			(os_reltime_expired(&now, &cli->chan_id_trigger_ts, 10)) &&
			(client_mon_chan_id(global, cli)))
			 cli->chan_id_trigger_ts = now;

#else
		if (
#ifdef SUPPORT_MULTI_AP
			global->params.Certification == 0 &&
#endif
#ifdef CENT_STR
			global->dev.cent_str_en &&
#endif
			(!is_zero_ether_addr(cli->bssid)) &&
			(cli->cli_steer_state == CLI_STATE_IDLE) &&
			(cli->capab & CLI_CAP_11K) &&
			(os_reltime_expired(&now, &cli->chan_id_trigger_ts, 10)) &&
#ifdef SUPPORT_MULTI_AP
			(global->dev.device_role == DEVICE_ROLE_CONTROLLER) &&
#endif
			(cli->current_chan != 0) &&
			(cli->dual_band == BAND_SUPPORT_AMBIGUOUS) &&
#ifdef SUPPORT_MULTI_AP
			(client_mon_chan_id_cent(global, cli))
#else
			(client_mon_chan_id(global, cli))
#endif
		)
			cli->chan_id_trigger_ts = now;
#endif

#ifdef SUPPORT_MULTI_AP
		// check rfs_req_timestamp;
		if (cli->coord_data.cli_coordination_state == COORD_STATE_RFS_RECEIVED
			&& os_reltime_expired(&now, &cli->coord_data.rfs_req_timestamp, TSQ_REQ_TIMEOUT_VAL)) {
			err(DEBUG_CAT_CLIENT_MON, "rfs req received but no tsq req. Clear blacklist");
			client_mon_bl_sta_for_all_bss(global, cli, 0, NULL, FALSE);
			cli->coord_data.cli_coordination_state = COORD_STATE_IDLE;
			cli->coord_data.rfs_req_timestamp.sec = 0;
			cli->coord_data.rfs_req_timestamp.usec = 0;
		}
		if (cli->coord_data.cli_coordination_state == COORD_STATE_ASSOC_CONTROL_RECEIVED
			&& os_reltime_expired(&now, &cli->coord_data.assoc_cntrl_req_timestamp, ASSOC_BLOCK_DURATION)) {
			notice(DEBUG_CAT_CLIENT_MON, "sta mac: " MACSTR", reset COORD_STATE_IDLE ", MAC2STR(cli->mac_addr));
			cli->coord_data.cli_coordination_state = COORD_STATE_IDLE;
			cli->coord_data.assoc_cntrl_req_timestamp.sec = 0;
			cli->coord_data.assoc_cntrl_req_timestamp.usec = 0;
		}
#endif
		/* Activity State */
		if (cli->curr_activity_state == 1) {
			cli->activity_state = 1; //mark active
			cli->consec_idle_count = 0;
		} else {
			cli->consec_idle_count++;
			info(DEBUG_CAT_CLIENT_MON, "cli->consec_idle_count %d", cli->consec_idle_count);
			if(cli->consec_idle_count >= global->dev.cli_steer_params.idle_count_th) {
				cli->activity_state = 0; //mark idle
				cli->consec_idle_count = 0;
			}
		}

	}
	/* User config Block Check */
	client_mon_block_check(global);
}

#ifdef MAP_R2
void client_mon_handle_auth_rej(struct mapd_global *global, wapp_sta_cnnct_rej_info *rej_cnnct_info)
{
	struct client *cli = client_db_get_client_from_sta_mac(global, rej_cnnct_info->sta_mac);

#ifdef DATA_ELEMENT_SUPPORT
	if (global->dev.device_role == DEVICE_ROLE_CONTROLLER) {
		err(DEBUG_CAT_CLIENT_MON, "send_failed_assoc_frame(%d) status(%d) reason(%d)",
			rej_cnnct_info->send_failed_assoc_frame,
			rej_cnnct_info->assoc_status_code,
			rej_cnnct_info->assoc_reason_code);
		create_sta_fail_connect_json_file(&global->dev,
			rej_cnnct_info->sta_mac, rej_cnnct_info->assoc_reason_code,
			rej_cnnct_info->assoc_status_code);
	}
#endif

	if (cli == NULL)
		err(DEBUG_CAT_CLIENT_MON, "Auth Rej for client " MACSTR
		" not in DB", MAC2STR(rej_cnnct_info->sta_mac));
	if (cli && rej_cnnct_info->cnnct_fail.connect_stage <= WAPP_ASSOC) {
	//Increment reject count stored in the DB
		cli->auth_deny_count ++;
		info(DEBUG_CAT_CLIENT_MON, "Auth Rejected count=%d for client=%d " MACSTR,
					cli->auth_deny_count, cli->client_id, MAC2STR(rej_cnnct_info->sta_mac));
		// If the reject count exceeds the max reject count for this client, remove BL
		if (cli->auth_deny_count >= cli->auth_deny_max) {
				if (cli->cli_steer_state >= CLI_STATE_IDLE) {
						info(DEBUG_CAT_CLIENT_MON, "Trigger FSM (AUTH_DENY_MAX_REACHED)");
						steer_fsm_trigger(global, cli->client_id, AUTH_DENY_MAX_REACHED, NULL);
				} else {
						 /* Remove all BLs due to STEER_ALGO*/
						 client_mon_bl_sta_for_all_bss(global, cli, 0, NULL, FALSE);
				}

		}
	}
#ifdef MAP_R2
	debug(DEBUG_CAT_CLIENT_MON, "###assoc_status_code = %d ####\n",
		rej_cnnct_info->assoc_status_code);
	debug(DEBUG_CAT_CLIENT_MON,
	MACSTR, MAC2STR(rej_cnnct_info->sta_mac));
	if (rej_cnnct_info->send_failed_assoc_frame == 1) {
		struct own_1905_device *dev = &global->dev;
#ifdef MAP_R3
/*To Do: MAP version check for MAP R3 missing*/
		if (dev->map_version == DEV_TYPE_R3
#ifdef EM_PLUS_SUPPORT
		|| dev->map_version >= DEV_TYPE_R2
#endif
		) {
#if  defined(MTK_MLO_MAP_SUPPORT) && defined(MAP_R6)
			if (cli && cli->mlo_enable)
				Send_Failed_assoc_message(global->_1905_ctrl, dev, cli->mld_addr,
								rej_cnnct_info->assoc_status_code,
								rej_cnnct_info->assoc_reason_code,
								rej_cnnct_info->bssid);
			else
				Send_Failed_assoc_message(global->_1905_ctrl, dev, rej_cnnct_info->sta_mac,
								rej_cnnct_info->assoc_status_code,
								rej_cnnct_info->assoc_reason_code,
								rej_cnnct_info->bssid);
#else
			Send_Failed_assoc_message(global->_1905_ctrl, dev, rej_cnnct_info->sta_mac,
								rej_cnnct_info->assoc_status_code,
								rej_cnnct_info->assoc_reason_code,
								rej_cnnct_info->bssid);
#endif /*MTK_MLO_SUPPORT and MAP_R6*/
		} else
#endif
#if defined(MTK_MLO_MAP_SUPPORT) && defined(MAP_R6)
			if (cli && cli->mlo_enable)
				Send_Failed_assoc_message(global->_1905_ctrl, dev, cli->mld_addr,
								rej_cnnct_info->assoc_status_code,
								rej_cnnct_info->assoc_reason_code,
								NULL);
			else
				Send_Failed_assoc_message(global->_1905_ctrl, dev, rej_cnnct_info->sta_mac,
								rej_cnnct_info->assoc_status_code,
								rej_cnnct_info->assoc_reason_code,
								NULL);
#else
			Send_Failed_assoc_message(global->_1905_ctrl, dev, rej_cnnct_info->sta_mac,
								rej_cnnct_info->assoc_status_code,
								rej_cnnct_info->assoc_reason_code,
								NULL);
#endif
	}
#endif //MAPR2
}

#else
/**
 * @brief : Handle auth reject event received via the wlanif 
 *
 * @param global : global device pointer
 * @param mac_addr: mac address of the client for which auth rejection is done
 */
//XXX: TODO: Handle auth rejects for multi-ap ?
void client_mon_handle_auth_rej(struct mapd_global *global, u8 *mac_addr)
{
	struct client *cli = client_db_get_client_from_sta_mac(global, mac_addr);

	if (cli == NULL) {
		err(DEBUG_CAT_CLIENT_MON, "Auth Rej for client " MACSTR
						" not in DB", MAC2STR(mac_addr));
		return;
	}
	//Increment reject count stored in the DB
	cli->auth_deny_count ++;
	info(DEBUG_CAT_CLIENT_MON, "Auth Rejected count=%d for client=%d " MACSTR,
				cli->auth_deny_count, cli->client_id, MAC2STR(mac_addr));
	// If the reject count exceeds the max reject count for this client, remove BL
	if (cli->auth_deny_count >= cli->auth_deny_max) {
			if (cli->cli_steer_state >= CLI_STATE_IDLE) {
					info(DEBUG_CAT_CLIENT_MON, "Trigger FSM (AUTH_DENY_MAX_REACHED)");
					steer_fsm_trigger(global, cli->client_id, AUTH_DENY_MAX_REACHED, NULL);
			} else {
					 /* Remove all BLs due to STEER_ALGO*/
					 client_mon_bl_sta_for_all_bss(global, cli, 0, NULL, FALSE);
			}

	}
}
#endif
void client_mon_unblock_cli_on_bss(struct mapd_global *global,
		struct mapd_bss *bss, struct client *cli, u32 reason, u8 *al_mac
#ifdef MTK_MLO_MAP_SUPPORT
		, Boolean Mlo_En
#endif /* MTK_MLO_MAP_SUPPORT */
)
{
	struct bl_client *bl_sta = NULL;
	u8 block = 0;
#ifdef MTK_MLO_MAP_SUPPORT
	u8 ZERO_MAC_ADDR[ETH_ALEN] = {0, 0, 0, 0, 0, 0};
	uint8_t bl_mac_addr[ETH_ALEN] = {0, 0, 0, 0, 0, 0};
#endif /* MTK_MLO_MAP_SUPPORT */

	dl_list_for_each(bl_sta, &bss->bl_sta_list, struct bl_client,
			list_entry) {
		if (bl_sta->cli == cli) {
#ifdef SUPPORT_MULTI_AP
				if (reason == BL_MAP_ASSOC_CONTROL) {
						struct map_dev *tmp = NULL, *next = NULL;
						if (!al_mac)
							return;
						/* The reasaon is MAP_ASSOC_CONTROL */
						dl_list_for_each_safe(tmp, next, &bl_sta->map_dev_list,
										struct map_dev, map_dev_entry) {
								if (!(os_memcmp(al_mac, tmp->al_mac, ETH_ALEN))) {
										dl_list_del(&tmp->map_dev_entry);
										os_free(tmp);
										break;
								}
						}
						if (!dl_list_empty(&bl_sta->map_dev_list))
								return;
				}
#endif
				if (bl_sta->bl_reason  == reason) {
#ifdef MTK_MLO_MAP_SUPPORT
					/* If MLO is enabled/supported then check for mlo mac address
					 * and replace the existing sta mac address with the same
					 */
					os_memcpy(bl_mac_addr, cli->mac_addr, ETH_ALEN);
					if ((Mlo_En == TRUE) &&
						(os_memcmp(ZERO_MAC_ADDR, cli->mld_addr, ETH_ALEN))) {
						os_memcpy(bl_mac_addr, cli->mld_addr, ETH_ALEN);
						block = MLO_ASSOC_UNBLOCK;
					}
#endif /* MTK_MLO_MAP_SUPPORT */

						/* I am the only reason */
#ifdef MTK_MLO_MAP_SUPPORT
					if (wlanif_bl_sta_for_bss(global, bl_mac_addr, bss->bssid, block) == 0)
#else
					if (wlanif_bl_sta_for_bss(global, cli->mac_addr, bss->bssid, block) == 0)
#endif
					{
						debug(DEBUG_CAT_CLIENT_MON, " %d(" MACSTR
									") UNBLACKLISTED ON BSSID=" MACSTR,
									cli->client_id, MAC2STR(cli->mac_addr),
									MAC2STR(bss->bssid));
						dl_list_del(&bl_sta->list_entry);
						os_free(bl_sta);
					} else {
						err(DEBUG_CAT_CLIENT_MON, "%d(" MACSTR ") UN-BLACKLISTING ON BSSID="
									MACSTR " FAILED", cli->client_id,
									MAC2STR(cli->mac_addr),
									MAC2STR(bss->bssid));
						/* Failed ; try again after 10 seconds */
#ifdef SUPPORT_MULTI_AP
						if (bl_sta->bl_reason == BL_MAP_ASSOC_CONTROL) {
								struct map_dev *map_device = NULL;
								map_device = (struct map_dev *)os_malloc(sizeof(struct map_dev));
								if (map_device) {
								os_memset(map_device, 0, sizeof(struct map_dev));
								map_device->duration = 10;
								os_memcpy(map_device->al_mac, al_mac, ETH_ALEN);
								dl_list_add(&bl_sta->map_dev_list, &map_device->map_dev_entry);
								}
						}
#endif
					}
			} else if(bl_sta->bl_reason) {
				/* Multiple reasons  */
				bl_sta->bl_reason &= ~reason;
			}
			return;
		}
	}
	/* Not in list */
	return ;
}

void client_mon_block_cli_on_bss(struct mapd_global *global,
		struct mapd_bss *bss, struct client *cli, u32 reason, u32 duration, u8 *al_mac
#ifdef MTK_MLO_MAP_SUPPORT
		, Boolean Mlo_En
#endif /* MTK_MLO_MAP_SUPPORT */
)
{
	struct bl_client *bl_sta = NULL;
	u8 block = 1;
#ifdef MTK_MLO_MAP_SUPPORT
	u8 ZERO_MAC_ADDR[ETH_ALEN] = {0, 0, 0, 0, 0, 0};
	uint8_t bl_mac_addr[ETH_ALEN] = {0, 0, 0, 0, 0, 0};
#endif /* MTK_MLO_MAP_SUPPORT */

	dl_list_for_each(bl_sta, &bss->bl_sta_list, struct bl_client,
			list_entry) {
		/* Already Blacklisted */
		if (bl_sta->cli == cli) {
			bl_sta->bl_reason  |= reason;
#ifdef SUPPORT_MULTI_AP
			if (reason == BL_MAP_ASSOC_CONTROL) {
					struct map_dev *map_device = NULL;
					dl_list_for_each(map_device, &bl_sta->map_dev_list, struct map_dev,
									map_dev_entry) {
							if (!os_memcmp(map_device->al_mac, al_mac, ETH_ALEN)) {
									map_device->duration = duration;
									return;
							}
					}
					map_device = (struct map_dev *)os_malloc(sizeof(struct map_dev));
					if (!map_device) {
						err(DEBUG_CAT_CLIENT_MON, "OOM: Could not allocate memory");
					}
					if(map_device) {
					os_memset(map_device, 0, sizeof(struct map_dev));
					map_device->duration = duration;
					os_memcpy(map_device->al_mac, al_mac, ETH_ALEN);
					dl_list_add(&bl_sta->map_dev_list, &map_device->map_dev_entry);
					}
			}
#endif
			return;
		}
	}

#ifdef MTK_MLO_MAP_SUPPORT
	/* If MLO is enabled/supported then check for mlo mac address
	 * and replace the existing sta mac address with the same
	 */
	os_memcpy(bl_mac_addr, cli->mac_addr, ETH_ALEN);
	if ((Mlo_En == TRUE) &&
		(os_memcmp(ZERO_MAC_ADDR, cli->mld_addr, ETH_ALEN))) {
		os_memcpy(bl_mac_addr, cli->mld_addr, ETH_ALEN);
		block = MLO_ASSOC_BLOCK;
	}
#endif /* MTK_MLO_MAP_SUPPORT */

	/* Not in List */
#ifdef MTK_MLO_MAP_SUPPORT
	if (wlanif_bl_sta_for_bss(global, bl_mac_addr, bss->bssid, block) == 0)
#else
	if (wlanif_bl_sta_for_bss(global, cli->mac_addr, bss->bssid, block) == 0)
#endif
	{
		err(DEBUG_CAT_CLIENT_MON, "%d(" MACSTR
					") BLACKLISTED ON BSSID=" MACSTR,
					cli->client_id, MAC2STR(cli->mac_addr),
					MAC2STR(bss->bssid));
		bl_sta = (struct bl_client *)malloc(sizeof(struct bl_client));
		if(bl_sta == NULL) {
			err(DEBUG_CAT_CLIENT_MON, "memory alloc fail");
			return;
		}
		os_memset(bl_sta, 0, sizeof(struct bl_client));
		bl_sta->cli = cli;
		bl_sta->bl_reason |= reason;
		dl_list_add(&bss->bl_sta_list, &bl_sta->list_entry);
		dl_list_init(&bl_sta->map_dev_list);
#ifdef SUPPORT_MULTI_AP
		if (reason == BL_MAP_ASSOC_CONTROL) {
				struct map_dev *map_device = NULL;
				map_device = (struct map_dev *)malloc(sizeof(struct map_dev));
				if (!map_device) {
					err(DEBUG_CAT_CLIENT_MON, "OOM: Could not allocate memory");
					return;
				}
				os_memset(map_device, 0, sizeof(struct map_dev));
				map_device->duration = duration;
				os_memcpy(map_device->al_mac, al_mac, ETH_ALEN);
				dl_list_add(&bl_sta->map_dev_list, &map_device->map_dev_entry);
		}
#endif
	} else {
		err(DEBUG_CAT_CLIENT_MON, "%d(" MACSTR ") BLACKLISTING ON BSSID="
					MACSTR " FAILED", cli->client_id,
					MAC2STR(cli->mac_addr),
					MAC2STR(bss->bssid));
	}
}


/* OK */
/**
 * @brief : Function to blacklist/unblacklist a stations on a given list of BSS.
 * Internally calls the wlanif function to BL/UnBL the station on a single BSS by
 * iterating through the list.
 *
 * @param global: The global device pointer
 * @param cli: client to be blacklisted/unblacklisted
 * @param num_bss: number of BSS on which to be blacklisted/unblacklisted
 * @param bss_arr : Pointer to the BSS array
 * @param blacklist: 1 for Blacklisting, 0 for unblacklisting
 */
void client_mon_bl_sta_for_bss(struct mapd_global *global, struct client *cli,
		u8 num_bss, struct mapd_bss **bss_arr,
		Boolean blacklist)
{
	uint8_t i = 0;
	struct mapd_bss *bss = NULL;

	debug(DEBUG_CAT_CLIENT_MON, "ENTERED");
	//Iterate through the BSS list
	for (i = 0; i < num_bss; i++) {
		bss = (struct mapd_bss *)bss_arr[i];
#ifdef SUPPORT_MULTI_AP
		if (blacklist) {
			client_mon_block_cli_on_bss(global, bss, cli, BL_STEER_ALGO, 0, global->dev.al_mac
#ifdef MTK_MLO_MAP_SUPPORT
					, cli->mlo_enable
#endif /* MTK_MLO_MAP_SUPPORT */
					);
		} else {
			client_mon_unblock_cli_on_bss(global, bss, cli, BL_STEER_ALGO, global->dev.al_mac
#ifdef MTK_MLO_MAP_SUPPORT
					, cli->mlo_enable
#endif /* MTK_MLO_MAP_SUPPORT */
					);
		}
#else
		/* In BS there is no use of al_mac */
		if (blacklist) {
			client_mon_block_cli_on_bss(global, bss, cli, BL_STEER_ALGO, 0, NULL
#ifdef MTK_MLO_MAP_SUPPORT
					, cli->mlo_enable
#endif /* MTK_MLO_MAP_SUPPORT */
					);
		} else {
			client_mon_unblock_cli_on_bss(global, bss, cli, BL_STEER_ALGO, NULL
#ifdef MTK_MLO_MAP_SUPPORT
					, cli->mlo_enable
#endif /* MTK_MLO_MAP_SUPPORT */
					);
		}
#endif
	}
}

void client_mon_handle_traffic_stats(struct mapd_global *global, u8 *mac_addr,
				u32 tx_bytes, u32 rx_bytes, u32 tx_pkts, u32 rx_pkts, u32 tx_errs,
				u32 rx_errs)
{
	struct client *cli = NULL;
	uint32_t tx_success = 0;
	uint32_t rx_success = 0;
	uint32_t client_id;
	unsigned char *bssid;

	cli = client_db_get_client_from_sta_mac(global, mac_addr);
	if (cli == NULL) {
		debug(DEBUG_CAT_CLIENT_MON, MACSTR " is not in DB",
						MAC2STR(mac_addr));
		return;
	}
	if (cli->cli_steer_state > CLI_STATE_IDLE) {
		debug(DEBUG_CAT_CLIENT_MON, "Steering in progress for " MACSTR,
						MAC2STR(cli->mac_addr));
		return;
	}

	client_id = cli->client_id;
	if (client_id == (uint32_t)-1) {
		err(DEBUG_CAT_CLIENT_MON, "client_id is not valid!");
		return;
	}

	bssid = client_db_get_bssid(global, client_id);
	if (is_zero_ether_addr(bssid)) {
		err(DEBUG_CAT_CLIENT_MON, "Zero bssid!");
		return;
	}

	if (cli->radio_idx == (uint8_t)-1) {
		err(DEBUG_CAT_CLIENT_MON, "invalid radio_idx!");
		return;
	}

	debug(DEBUG_CAT_CLIENT_MON, MACSTR ": %d %d %d %d %d %d",
					MAC2STR(cli->mac_addr), tx_bytes, rx_bytes, tx_pkts, rx_pkts,
					tx_errs, rx_errs);

	/* Update Tx and Rx Packet Count, and update RSSI ts */
	tx_success = tx_pkts - tx_errs;
	rx_success = rx_pkts - rx_errs;
	/* Update RSSI TS */
	if (((tx_success - cli->tx_success_pkt_cnt > 0) ||
		 (rx_success - cli->rx_success_pkt_cnt > 0)) &&
		(cli->ul_rssi[cli->radio_idx] != 0))
		os_get_reltime(&cli->rssi_ts[cli->radio_idx]);
	/* Update Counter */
	cli->tx_success_pkt_cnt = tx_success;
	cli->rx_success_pkt_cnt = rx_success;
}
#ifdef SUPPORT_MULTI_AP
void client_mon_handle_assoc_control(struct mapd_global *global, struct cli_assoc_control *assoc_cntrl, u8 len, u8 *al_mac)
{
	u32 client_id;
	int i = 0;
	struct client *cli = NULL;
	struct mapd_bss *bss = NULL;
	u8 already_seen = 0;
#ifdef MAP_R6
	u8 mld_enabled = 0;
#endif /* MAP_R6 */

	assoc_cntrl->valid_period = be_to_host16(assoc_cntrl->valid_period);
	notice(DEBUG_CAT_CLIENT_MON, "valid period: %d bssid:"MACSTR" al_mac:"MACSTR, assoc_cntrl->valid_period, MAC2STR(assoc_cntrl->bssid), MAC2STR(al_mac));
	bss = mapd_get_bss_from_mac(global, assoc_cntrl->bssid);

	if (!bss) {
		err(DEBUG_CAT_BSS, "BSS mac not found in db\n");
		return;
	}

	for (i = 0; i < assoc_cntrl->sta_list_count; i++) {
		client_id = client_db_track_add(global, &assoc_cntrl->sta_mac[ETH_ALEN * i],
						&already_seen);
			if (client_id == (uint32_t)-1) {
				notice(DEBUG_CAT_CLIENT_MON, "No more room to accommodate " MACSTR,
								MAC2STR(&assoc_cntrl->sta_mac[ETH_ALEN * i]));
				return;
			}
			cli = &global->dev.client_db[client_id];
			cli->in_db = IN_DB;
#ifdef MAP_R6
		if (os_memcmp(ZERO_MAC_ADDR, cli->mld_addr, ETH_ALEN)) {
			mld_enabled = 1;
		}
#endif /* MAP_R6 */
			if (already_seen != 1) {
				debug(DEBUG_CAT_CLIENT_MON, "New Client discovered"
								MACSTR, MAC2STR(&assoc_cntrl->sta_mac[ETH_ALEN * i]));
				cli->dirty = 1;
			}
#ifdef MAP_R5
			if (assoc_cntrl->assoc_control == BLOCK || assoc_cntrl->assoc_control == INDEFINITE_BLOCK) {
#else
			if (assoc_cntrl->assoc_control == BLOCK) {
#endif
				client_mon_block_cli_on_bss(global, bss, cli,
								BL_MAP_ASSOC_CONTROL, assoc_cntrl->valid_period,
								al_mac
#ifdef MTK_MLO_MAP_SUPPORT
#ifdef MAP_R6
						, mld_enabled?1:0
#else
								, 0
#endif /* MAP_R6 */
#endif /* MTK_MLO_MAP_SUPPORT */
								);
#ifdef MAP_R5
			} else if (assoc_cntrl->assoc_control == PERSISTENT_BLOCK) {
				client_mon_block_cli_on_bss(global, bss, cli,
								BL_MAP_ASSOC_CONTROL, 0,
								al_mac
#ifdef MTK_MLO_MAP_SUPPORT
#ifdef MAP_R6
						, mld_enabled?1:0
#else
								, 0
#endif /* MAP_R6 */
#endif /* MTK_MLO_MAP_SUPPORT */
								);
#endif
			} else {
				client_mon_unblock_cli_on_bss(global, bss, cli,
								BL_MAP_ASSOC_CONTROL, al_mac
#ifdef MTK_MLO_MAP_SUPPORT
#ifdef MAP_R6
						, mld_enabled?1:0
#else
								, 0
#endif /* MAP_R6 */
#endif /* MTK_MLO_MAP_SUPPORT */
								);
			}
	}
}

#ifdef MTK_MLO_MAP_SUPPORT
void mlo_client_mon_handle_assoc_control(struct mapd_global *global,
		struct cli_assoc_mlo_ctrl *assoc_cntrl, u8 len, u8 *al_mac)
{
	u32 client_id;
	int i = 0;
	struct client *cli = NULL;
	struct mapd_bss *bss = NULL;
	u8 already_seen = 0;
	u8 cli_mac[ETH_ALEN] = {0};

	assoc_cntrl->valid_period = be_to_host16(assoc_cntrl->valid_period);
	notice(DEBUG_CAT_BSS, "valid period: %d bssid:"MACSTR" al_mac:"MACSTR,
			assoc_cntrl->valid_period, MAC2STR(assoc_cntrl->bssid), MAC2STR(al_mac));
	bss = mapd_get_bss_from_mac(global, assoc_cntrl->bssid);

	if (!bss)
		return;

	for (i = 0; i < assoc_cntrl->mlo_sta_list_count; i++) {
		os_memcpy(cli_mac, &assoc_cntrl->mlo_sta_mac[(ETH_ALEN * i) + 6], ETH_ALEN);
		client_id = client_db_track_add(global, cli_mac, &already_seen);
		if (client_id == (uint32_t)-1) {
			err(DEBUG_CAT_CLIENT_MON, "No more room to accommodate " MACSTR,
					MAC2STR(&assoc_cntrl->mlo_sta_mac[(ETH_ALEN * i) + 6]));
			return;
		}
		cli = &global->dev.client_db[client_id];
		cli->in_db = IN_DB;
		/* Insert te mlo MAC address in the client structure for ACL use */
		notice(DEBUG_CAT_CLIENT_MON, "before client id = %u and mld_addr = "MACSTR, cli->client_id, MAC2STR(cli->mld_addr));
		os_memcpy(cli->mld_addr, &assoc_cntrl->mlo_sta_mac[(ETH_ALEN * i) + 6], ETH_ALEN);
		notice(DEBUG_CAT_CLIENT_MON, "after client id = %u and mld_addr = "MACSTR, cli->client_id, MAC2STR(cli->mld_addr));
		if (already_seen != 1) {
			debug(DEBUG_CAT_CLIENT_MON, "New Client discovered"
					MACSTR, MAC2STR(&assoc_cntrl->mlo_sta_mac[(ETH_ALEN * i) + 6]));
			cli->dirty = 1;
		}

#ifdef MAP_R5
		if (assoc_cntrl->assoc_control == MLO_ASSOC_BLOCK || assoc_cntrl->assoc_control == MLO_INDEFINITE_BLOCK)
#else
			if (assoc_cntrl->assoc_control == MLO_ASSOC_BLOCK)
#endif
			{
				client_mon_block_cli_on_bss(global, bss, cli,
						BL_MAP_ASSOC_CONTROL, assoc_cntrl->valid_period,
						al_mac, 1);
#ifdef MAP_R5
			} else if (assoc_cntrl->assoc_control == MLO_PERSISTENT_BLOCK) {
				client_mon_block_cli_on_bss(global, bss, cli,
						BL_MAP_ASSOC_CONTROL, 0,
						al_mac, 1);
#endif
			} else {
				client_mon_unblock_cli_on_bss(global, bss, cli,
						BL_MAP_ASSOC_CONTROL, al_mac, 1);
			}
	}
}
#endif /* MTK_MLO_MAP_SUPPORT */

#endif
