/*
 * ***************************************************************************
 * *  Mediatek Inc.
 * * 4F, No. 2 Technology 5th Rd.
 * * Science-based Industrial Park
 * * Hsin-chu, Taiwan, R.O.C.
 * *
 * * (c) Copyright 2002-2011, Mediatek, Inc.
 * *
 * * All rights reserved. Mediatek's source code is an unpublished work and the
 * * use of a copyright notice does not imply otherwise. This source code
 * * contains confidential trade secret material of Ralink Tech. Any attemp
 * * or participation in deciphering, decoding, reverse engineering or in any
 * * way altering the source code is stricitly prohibited, unless the prior
 * * written consent of Mediatek, Inc. is obtained.
 * ***************************************************************************
 *
 *  Module Name:
 *  Steer Exec
 *
 *  Abstract:
 *  Steering Orchestration module
 *
 *  Revision History:
 *  Who         When          What
 *  --------    ----------    -----------------------------------------
 *  Neelansh.M   2018/05/02     First implementation of the steer exec Module
 * */
#include "includes.h"
#include "common.h"
#include "steer_fsm.h"
#include "list.h"
#include "client_db.h"
#include "mapd_i.h"
#include "db.h"
#ifdef SUPPORT_MULTI_AP
#include "data_def.h"
#endif
#include "chan_mon.h"
#ifdef SUPPORT_MULTI_AP
#include "topologySrv.h"
#endif
#include "client_mon.h"
//#include <sys/queue.h>
#include "eloop.h"
#include "steer_action.h"
#include "ap_est.h"
#include "eloop.h"
#include "wapp_if.h"
#include <assert.h>
#include <sys/un.h>
#ifdef SUPPORT_MULTI_AP
#include "1905_map_interface.h"
#include "ch_planning.h"
#endif
#include "ap_roam_algo.h"
#ifdef CENT_STR
#include "ap_cent_str.h"
#endif

struct steer_cands *get_client_from_steer_cand_list(struct own_1905_device *ctx, struct client *cli)
{
	struct steer_cands *cand = NULL;
	if (SLIST_EMPTY(&(ctx->steer_cands_head)))
		return NULL;
	cand = SLIST_FIRST(&(ctx->steer_cands_head));
	while(cand != NULL) {
		if (cli->client_id == cand->steer_cand->client_id)
			return cand;
		cand = SLIST_NEXT(cand, next_cand);
	}
	return NULL;
}

#ifdef CENT_STR
#ifdef MTK_MLO_MAP_SUPPORT
/* To check if there is an already existing client in the cand list which has same mld address as cli*/
struct client *is_mld_cli_present(struct own_1905_device *ctx, struct client *cli)
{
	struct steer_cands *cand = NULL;

	if (SLIST_EMPTY(&(ctx->steer_cands_head)))
		return NULL;
	cand = SLIST_FIRST(&(ctx->steer_cands_head));
	while (cand != NULL) {
		if (cand->steer_cand->mlo_enable &&
			(os_memcmp(cand->steer_cand->mld_addr, cli->mld_addr, ETH_ALEN) == 0)) {
			err(DEBUG_CAT_STEERING, "[Steer] found mld_cli in cand list with MAC" MACSTR,
					MAC2STR(cand->steer_cand->mac_addr));
			return cand->steer_cand;
		}
		cand = SLIST_NEXT(cand, next_cand);
	}
	return NULL;
}
#endif
struct cent_steer_cands *get_client_from_cent_steer_cand_list(struct own_1905_device *ctx, struct client *cli)
{
	struct cent_steer_cands *cand = NULL;
	if (STAILQ_EMPTY(&(ctx->cent_steer_cands_head)))
		return NULL;
	cand = STAILQ_FIRST(&(ctx->cent_steer_cands_head));
	while(cand != NULL) {
		if (cli->client_id == cand->steer_cand->client_id)
			return cand;
		cand = STAILQ_NEXT(cand, next_cand);
	}
#ifdef MTK_MLO_MAP_SUPPORT
	/* To check if there is an already existing client in the cand list which has same mld address as cli*/
	struct client *mld_cand = is_mld_cli_present(ctx, cli);

	if (cli->mlo_enable && mld_cand) {
		err(DEBUG_CAT_STEERING, "[Steer] cli mld is enable" MACSTR, MAC2STR(cli->mac_addr));
		cand = STAILQ_FIRST(&(ctx->cent_steer_cands_head));
		while (cand != NULL) {
			if (mld_cand->client_id == cand->steer_cand->client_id)
				return cand;
			cand = STAILQ_NEXT(cand, next_cand);
		}
	}
#endif
	return NULL;
}

#endif


/* We will check if the prohibit timoeut is registered wherever we need to
 * take care of the prohibit timoeut existence. Thus nothing needs to be done in the
 * timoeut handler because the timeout has already expired
 */
void steer_action_handle_prohibit_timeout(void *eloop_ctx, void *timeout_ctx)
{
	struct client *cli = (struct client *)timeout_ctx;

	info(DEBUG_CAT_STEERING, "Prohibit Timer expired for %d " MACSTR,
					cli->client_id, MAC2STR(cli->mac_addr));
}

void steer_action_handle_bounce_prohibit_timeout(void *eloop_ctx, void *timeout_ctx)
{
	struct client *cli = (struct client *)timeout_ctx;

	info(DEBUG_CAT_STEERING, "Prohibit Timer expired for %d " MACSTR,
					cli->client_id, MAC2STR(cli->mac_addr));
}

void steer_action_handle_global_prohibit_timeout(void *eloop_ctx, void *timeout_ctx)
{
	info(DEBUG_CAT_STEERING, "****** Glboal Prohibit Timer expired *******");
}

void client_disconn_trigger(struct mapd_global *global) {
	struct client *cli = NULL;
	uint32_t i = 0;

	/*During reset all clients will be disconnected so trigger leave*/
	for(i = 0; i < MAX_STA_SEEN; i++) {
		cli = &global->dev.client_db[i];
		if (cli->client_id == (uint32_t)-1)
			continue;

		if(cli->cli_steer_state == CLI_STATE_INVALID)
			continue;
		if(!is_zero_ether_addr(cli->bssid)){
			notice(DEBUG_CAT_CLIENT_MON, "State:%d ,Trigger client leave "MACSTR,cli->cli_steer_state,MAC2STR(cli->mac_addr));
			client_mon_handle_local_leave(global,cli->mac_addr,cli->bssid);
		}
	}

	return;
}

