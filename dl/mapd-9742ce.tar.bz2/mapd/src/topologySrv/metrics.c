/*
 * ***************************************************************************
 * *  Mediatek Inc.
 * * 4F, No. 2 Technology 5th Rd.
 * * Science-based Industrial Park
 * * Hsin-chu, Taiwan, R.O.C.
 * *
 * * (c) Copyright 2002-2018, Mediatek, Inc.
 * *
 * * All rights reserved. Mediatek's source code is an unpublished work and the
 * * use of a copyright notice does not imply otherwise. This source code
 * * contains confidential trade secret material of Ralink Tech. Any attemp
 * * or participation in deciphering, decoding, reverse engineering or in any
 * * way altering the source code is stricitly prohibited, unless the prior
 * * written consent of Mediatek, Inc. is obtained.
 * ***************************************************************************
 *
 *  Module Name:
 *  metrics query/response
 *
 *  Abstract:
 *  metrics query/response
 *
 *  Revision History:
 *  Who         When          What
 *  --------    ----------    -----------------------------------------
 *  Kapil.Gupta 2018/05/02    First implementation of the metrics query/response
 * */
#include "includes.h"
#ifdef __linux__
#include <fcntl.h>
#endif				/* __linux__ */

#include "common.h"
#include <sys/un.h>

#include "interface.h"
#include "data_def.h"
#include "client_db.h"
#include "mapd_i.h"
#include "topologySrv.h"
#include "eloop.h"
#include "wapp_if.h"
#include "tlv_parsor.h"
#include "1905_if.h"
#include "1905_map_interface.h"
#include "ap_est.h"
#include "wapp_if.h"
#include "client_mon.h"
#include "ap_cent_str.h"
#include "apSelection.h"

void infra_metrics_srv_send_link_metrics_query(void *eloop_ctx, void *timeout_ctx);
void infra_metrics_srv_send_cb_infra_metrics(void *eloop_ctx, void *timeout_ctx);

int byte_count_trans(int byte_cnt)
{
	if (byte_cnt == 0) {
		err(DEBUG_CAT_METRIC, "byte_cnt = 0 is invalid\n");
		return -1;
	}

	return byte_cnt == 1 ? 1 : power(1024, 1);
}

int parse_associated_sta_link_metrics_rsp_msg(struct own_1905_device *ctx, struct _1905_map_device *dev, unsigned char *buf, int len)
{
        int length = 0;
        unsigned char *temp_buf;
	unsigned short check_len = 0;
	unsigned short tlv_len = 0;

        temp_buf = buf;
		info(DEBUG_CAT_METRIC, " ");
        while (1) {
		check_len = get_tlv_len(temp_buf);
		tlv_len = check_len + 3;

			if (len < tlv_len) {
				err(DEBUG_CAT_METRIC, "Error TLV len, type = %d, len %d less than tlv_len %d\n",
					*temp_buf, len, tlv_len);
				return -1;
			}

			if (*temp_buf == ASSOC_STA_LINK_METRICS_TYPE) {
					length = parse_assoc_sta_link_metrics_tlv(ctx, dev, temp_buf);
					if (length < 0) {
						err(DEBUG_CAT_METRIC, "error associated sta link metrics query tlv");
						return -1;
					}
					temp_buf += length;
			} else if (*temp_buf == END_OF_TLV_TYPE) {
					break;
			} else {
					length = get_cmdu_tlv_length(temp_buf);
					temp_buf += length;
			}
		len -= tlv_len;
        }

        return 0;
}

/**
* @brief Fn to send link metrics query to every 1905 device as part of infra metrics service
*
* @param eloop_ctx eloop ctx
* @param timeout_ctx timeout ctx
*/
void infra_metrics_srv_send_link_metrics_query(void *eloop_ctx, void *timeout_ctx)
{
	struct mapd_global *global = (struct mapd_global *)eloop_ctx;
	struct own_1905_device *own_dev = &global->dev;
	struct _1905_map_device *dev, *tdev = NULL;
	unsigned char metrics = BOTH_TX_AND_RX_METRICS;
	char neighbor_almac[ETH_ALEN] = { 0 };
	unsigned char neighbor = 0x00;

	debug(DEBUG_CAT_METRIC, "trace");
	SLIST_FOREACH_SAFE(dev, &own_dev->_1905_dev_head, next_1905_device, tdev) {
		if (dev == topo_srv_get_1905_device(own_dev, NULL))
			continue;
		map_1905_Send_Link_Metric_Query_Message(global->_1905_ctrl, (char *)dev->_1905_info.al_mac_addr, neighbor, neighbor_almac,
							metrics);
	}

	/* start timer to shoot every 30 sec for each 1905 to collect link metrics */
	eloop_register_timeout(30, 0, infra_metrics_srv_send_link_metrics_query, global, own_dev);
}
/**
* @brief fill combined infra metrics to be set for 1905
*
* @param ctx own 1905 ctx
* @param ap_met_cnt ap metrics count
* @param ap_metrics_ptr ap metrics pointet
* @param link_cnt link count
* @param tx_ap_ptr tx ap metrics pointer
* @param tx_sta_ptr tx sta metics pointer
* @param rx_ap_ptr rx ap metrics pointer
* @param rx_sta_ptr rx sta metics pointer
*
* @return 0 if success 
*/
unsigned short combined_infrastructure_metrics_message(struct own_1905_device *ctx, int *ap_met_cnt,
						       struct ap_metrics_info_lib *ap_metrics_ptr, int *link_cnt,
						       struct tx_link_metrics *tx_ap_ptr,
						       struct tx_link_metrics *tx_sta_ptr,
						       struct rx_link_metrics *rx_ap_ptr,
						       struct rx_link_metrics *rx_sta_ptr)
{
	int is_ap = 0;
	unsigned char *ap_metrics_buf, *tx_ap_buf, *rx_ap_buf, *tx_sta_buf, *rx_sta_buf;

	struct bss_info_db *bss = NULL, *tbss = NULL;
	struct _1905_map_device *tmp_dev, *t_tmp_dev = NULL;
	struct map_neighbor_info *neighbor, *t_neighbor = NULL;
	int bh_link_cnt = 0, ap_metrics_cnt = 0, count, ap_cnt = 0, sta_cnt = 0;
	struct ap_metrics_info_lib *valid_ap_metric = NULL;
#ifdef MTK_MLO_MAP_SUPPORT
	unsigned char *tx_sta_mlo_buf, *rx_sta_mlo_buf;
	struct tx_link_metrics tx_sta_mlo;
	struct rx_link_metrics rx_sta_mlo;
	struct backhaul_link_info *link, *tlink = NULL;
	u8 non_setup_link_id = 0;
	int lmetric_len = 0;

	tx_sta_mlo_buf = (unsigned char *)&tx_sta_mlo;
	rx_sta_mlo_buf = (unsigned char *)&rx_sta_mlo;
#endif

	debug(DEBUG_CAT_METRIC, "enter");
	ap_metrics_buf = (unsigned char *)ap_metrics_ptr;
	tx_ap_buf = (unsigned char *)tx_ap_ptr;
	tx_sta_buf = (unsigned char *)tx_sta_ptr;
	rx_ap_buf = (unsigned char *)rx_ap_ptr;
	rx_sta_buf = (unsigned char *)rx_sta_ptr;

	SLIST_FOREACH_SAFE(tmp_dev, &ctx->_1905_dev_head, next_1905_device, t_tmp_dev) {
		if (!tmp_dev->in_network) {
			debug(DEBUG_CAT_METRIC, "al_mac  = " MACSTR " not in network", MAC2STR(tmp_dev->_1905_info.al_mac_addr));
			continue;
		}
		SLIST_FOREACH_SAFE(bss, &tmp_dev->first_bss, next_bss, tbss) {
			/* TODO make a proper check */
			if (bss->esp_cnt != 4) {
				debug(DEBUG_CAT_METRIC, "ESP count not 4 bssid("MACSTR") ch_uti=%d, assoc_sta_cnt=%d, valid_esp_cnt=%d",
					MAC2STR(bss->bssid),bss->ch_util,
					bss->assoc_sta_cnt, bss->esp_cnt);
			}
			append_ap_metrics_info(ap_metrics_buf, bss);
			valid_ap_metric = (struct ap_metrics_info_lib *)ap_metrics_buf;
			if (valid_ap_metric->valid_esp_count > 0) {
				ap_metrics_cnt++;
				if(ap_metrics_cnt >= MAX_SET_BSS_INFO_NUM) {
					err(DEBUG_CAT_METRIC, "ap_metrics_cnt %d comes up to the max setting", ap_metrics_cnt);
					break;
				}
				ap_metrics_buf += sizeof(struct ap_metrics_info_lib);
			}
		}

		if (SLIST_EMPTY(&tmp_dev->neighbors_entry)) {
			debug(DEBUG_CAT_METRIC, "continue list is empty");
			continue;
		}

		neighbor = SLIST_FIRST(&tmp_dev->neighbors_entry);

		SLIST_FOREACH_SAFE(neighbor, &tmp_dev->neighbors_entry, next_neighbor, t_neighbor) {
			count =
				append_link_metric_info(tx_ap_buf, rx_ap_buf, tx_sta_buf, rx_sta_buf, tmp_dev, neighbor,
							&is_ap
#ifdef MTK_MLO_MAP_SUPPORT
	, 1, 0, 0, NULL, NULL, 1, 0
#endif
#ifdef EM_PLUS_EXT_SUPPORT
	, NULL
#endif

);
#ifdef MTK_MLO_MAP_SUPPORT
		if (tmp_dev->device_role == DEVICE_ROLE_CONTROLLER  ||
			(tmp_dev->device_role == DEVICE_ROLE_AGENT && !tmp_dev->mld_enabled) || (is_ap)) {
			err(DEBUG_CAT_METRIC, "tmp_dev->device_role :%d, tmp_dev->mld_enabled:%d, is_ap=%d", tmp_dev->device_role,
							tmp_dev->mld_enabled, is_ap);
			goto out;
		}

		link = SLIST_FIRST(&neighbor->bh_head);

	SLIST_FOREACH_SAFE(link, &neighbor->bh_head, next_bh, tlink) {
		if (!link->is_nonsetup_valid) {
			err(DEBUG_CAT_METRIC, "continue as non-setup link is invalid for this neigh BH ");
			continue;
		}

		for (non_setup_link_id = 0; non_setup_link_id < link->mlo_link_no; non_setup_link_id++) {
			count = append_link_metric_info(tx_ap_buf, rx_ap_buf, tx_sta_mlo_buf, rx_sta_mlo_buf, tmp_dev, neighbor, &is_ap
#ifdef MTK_MLO_MAP_SUPPORT
				, 0, non_setup_link_id,  link->mlo_link_no,
				link->mlo_tx[non_setup_link_id].connected_iface_addr, NULL, 1, 0
#endif
#ifdef EM_PLUS_EXT_SUPPORT
				, NULL
#endif
				);

			if (!is_ap) {
				if (lmetric_len >= MAX_NUM_RX_TX_METRICS)
					goto out;

				os_memcpy(&((rx_sta_ptr + lmetric_len)->metrics[non_setup_link_id + 1]), &rx_sta_mlo.metrics[0],
										sizeof(struct rx_link_metrics_sub));
				os_memcpy(&((tx_sta_ptr + lmetric_len)->metrics[non_setup_link_id + 1]), &tx_sta_mlo.metrics[0],
					sizeof(struct tx_link_metrics_sub));
			}
		}
	}
out:
		debug(DEBUG_CAT_METRIC, "goto out");
#endif
		debug(DEBUG_CAT_METRIC, "count %d", count);
		if (count > 0) {
			bh_link_cnt++;
				if (is_ap) {
					ap_cnt++;
					if(ap_cnt >= MAX_NUM_RX_TX_METRICS) {
						tx_ap_buf = NULL;
						rx_ap_buf = NULL;
						if(sta_cnt >= MAX_NUM_RX_TX_METRICS) {
							err(DEBUG_CAT_METRIC,
							 "ap_cnt %d and sta_cnt %d come up to the max setting", ap_cnt, sta_cnt);
							break;
						}
					} else {
						tx_ap_buf +=sizeof(struct tx_link_metrics);
						rx_ap_buf +=sizeof(struct rx_link_metrics);
						debug(DEBUG_CAT_METRIC, "increment tx rx for AP");
					}
				} else {
					sta_cnt++;
					if(sta_cnt >= MAX_NUM_RX_TX_METRICS) {
						tx_sta_buf = NULL;
						rx_sta_buf = NULL;
						if(ap_cnt >= MAX_NUM_RX_TX_METRICS){
							err(DEBUG_CAT_METRIC,
							 "sta_cnt %d and ap_cnt %d come up to the max setting", sta_cnt, ap_cnt);
							break;
						}
					} else {
						tx_sta_buf +=sizeof(struct tx_link_metrics);
						rx_sta_buf +=sizeof(struct rx_link_metrics);
						debug(DEBUG_CAT_METRIC, "increment tx rx for STA");
#ifdef MTK_MLO_MAP_SUPPORT
						lmetric_len += 1;
#endif
					}
				}
			}
		}
	}
	/* if odd, then we missed something */
	err(DEBUG_CAT_METRIC, "ap_metrics_cnt %d bh_link_cnt =%d", ap_metrics_cnt, bh_link_cnt);
	bh_link_cnt = bh_link_cnt / 2;

	*ap_met_cnt = ap_metrics_cnt;
	*link_cnt = bh_link_cnt;

	return 0;
}

/**
* @brief Fn to set combined infra metrics info in 1905 daemon
*
* @param eloop_ctx
* @param timeout_ctx
*/
void infra_metrics_srv_send_cb_infra_metrics(void *eloop_ctx, void *timeout_ctx)
{
	struct mapd_global *global = (struct mapd_global *)eloop_ctx;
	struct own_1905_device *own_dev = &global->dev;
	struct _1905_map_device *dev, *tdev = NULL;
	struct ap_metrics_info_lib *ap_metrics;
	struct tx_link_metrics *tx_sta_buf, *tx_ap_buf;
	struct rx_link_metrics *rx_sta_buf, *rx_ap_buf;
	int bh_link_cnt, ap_metrics_cnt;

	//TODO should we use realloc here??
	ap_metrics = os_zalloc(MAX_SET_BSS_INFO_NUM * (sizeof(struct ap_metrics_info_lib)));
	tx_sta_buf = os_zalloc(MAX_NUM_RX_TX_METRICS * (sizeof(struct tx_link_metrics)));
	tx_ap_buf = os_zalloc(MAX_NUM_RX_TX_METRICS * (sizeof(struct tx_link_metrics)));
	rx_sta_buf = os_zalloc(MAX_NUM_RX_TX_METRICS * (sizeof(struct rx_link_metrics)));
	rx_ap_buf = os_zalloc(MAX_NUM_RX_TX_METRICS * (sizeof(struct rx_link_metrics)));


	if(!ap_metrics || !tx_sta_buf || !tx_ap_buf || !rx_sta_buf || !rx_ap_buf){
		err(DEBUG_CAT_METRIC, "MAlloc Failed !!!!!!!!!!!!!!!!");
		if(ap_metrics)
			os_free(ap_metrics);
		if(tx_sta_buf)
			os_free(tx_sta_buf);
		if(tx_ap_buf)
			os_free(tx_ap_buf);
		if(rx_sta_buf)
			os_free(rx_sta_buf);
		if(rx_ap_buf)
			os_free(rx_ap_buf);

		eloop_register_timeout(60, 0, infra_metrics_srv_send_cb_infra_metrics, global, own_dev);
		return;
	}
#if 1
	topo_srv_cont_update_ap_metrics(own_dev);
	topo_srv_cont_update_link_metrics(own_dev);
#undef MAX_SIZE
	combined_infrastructure_metrics_message(own_dev, &ap_metrics_cnt, ap_metrics, &bh_link_cnt,
						tx_ap_buf, tx_sta_buf, rx_ap_buf, rx_sta_buf);
	if (bh_link_cnt > 0) {
		SLIST_FOREACH_SAFE(dev, &own_dev->_1905_dev_head, next_1905_device, tdev) {
			if (dev == topo_srv_get_1905_device(own_dev, NULL)) {
				debug(DEBUG_CAT_METRIC, "continue for own_dev = " MACSTR "", MAC2STR(dev->_1905_info.al_mac_addr));
				continue;
			}
			map_1905_Send_Combined_Infrastructure_Metrics_Message(global->_1905_ctrl, (char *)dev->_1905_info.al_mac_addr,
									      ap_metrics_cnt, ap_metrics, bh_link_cnt,
									      tx_ap_buf, tx_sta_buf, rx_ap_buf, rx_sta_buf);
		}
	}
#endif
	free(ap_metrics);
	free(tx_sta_buf);
	free(tx_ap_buf);
	free(rx_sta_buf);
	free(rx_ap_buf);
	/* start timer to send combined infra every 60 sec?? */
	eloop_register_timeout(60, 0, infra_metrics_srv_send_cb_infra_metrics, global, own_dev);
}

/**
* @brief Fn to start combined infra metrics
*
* @param ctx own 1905 device ctx
*
* @return 0 
*/
int topo_srv_start_combined_infra_metrics_srv(struct own_1905_device *ctx)
{

	struct mapd_global *global = ctx->back_ptr;

	if(global->params.Certification) {
		return 0;
	}

	if (ctx->device_role != DEVICE_ROLE_CONTROLLER)	/* controller */
		return 0;

	/* Standalone MAPD without 1905 */
	if (is_1905_present() == FALSE)
		return 0;

	info(DEBUG_CAT_METRIC, "started combined infra metric service");
	/* start timer to shoot every 30 sec for each 1905 to collect link metrics */
	eloop_register_timeout(30, 0, infra_metrics_srv_send_link_metrics_query, ctx->back_ptr, ctx);
	/* start timer to send combined infra every 60 sec?? */
	eloop_register_timeout(60, 0, infra_metrics_srv_send_cb_infra_metrics, ctx->back_ptr, ctx);

	return 0;
}

/**
* @brief Fn to append link metrics info
*
* @param ap_tx_link ap tx link info
* @param ap_rx_link ap rx link info
* @param sta_tx_link sta tx link info
* @param sta_rx_link sta rx link info
* @param dev 1905 map device pointer
* @param neighbor map neighbor pointer
* @param is_ap whether its an ap or sta
*
* @return 0 if success else -1
*/
int append_link_metric_info(unsigned char *ap_tx_link, unsigned char *ap_rx_link, unsigned char *sta_tx_link,
			    unsigned char *sta_rx_link, struct _1905_map_device *dev,
			    struct map_neighbor_info *neighbor, int *is_ap
#ifdef MTK_MLO_MAP_SUPPORT
	, int is_setup_link, int nonsetuplink_id, int mlo_link_pair, unsigned char mac_addr[ETH_ALEN]
	, unsigned char agent_bssid_mac[ETH_ALEN],
	int is_call_from_combined, int num_of_ap_link
#endif
#ifdef EM_PLUS_EXT_SUPPORT
	, struct _1905_map_device *agent_dev
#endif

	)
{
	int i = 0, link_count = 0;
	struct backhaul_link_info *link, *tlink = NULL;
	struct tx_link_metrics_sub *tx_link_sub;
	struct tx_link_metrics tx_link;
	struct rx_link_metrics_sub *rx_link_sub;
	struct rx_link_metrics rx_link;
	struct iface_info *iface = NULL;
#ifdef MTK_MLO_MAP_SUPPORT
	int cont_link_pair = 0, cont_setup_valid = 0;
	int iface_add_cont = 0;
	u8 ZERO_MAC_ADDR_MLO[ETH_ALEN] = {0, 0, 0, 0, 0, 0};
#endif

	if (dev == NULL) {
		err(DEBUG_CAT_METRIC, "dev is NULL return ");
		return -1;
	}
#ifdef MTK_MLO_MAP_SUPPORT
	if (nonsetuplink_id < 0) {
		err(DEBUG_CAT_METRIC, "Negative non setup link id invalid");
		nonsetuplink_id = 0;
	}

	if (is_setup_link) {
#endif
		/*fill into local abstration layer mac addr */
		os_memcpy(tx_link.almac, dev->_1905_info.al_mac_addr, ETH_ALEN);
		os_memcpy(rx_link.almac, dev->_1905_info.al_mac_addr, ETH_ALEN);

		/*fill into neighbor abstration layer mac addr */
#ifdef EM_PLUS_EXT_SUPPORT
		if (agent_dev) {
			os_memcpy(tx_link.neighbor_almac, agent_dev->_1905_info.al_mac_addr, ETH_ALEN);
			os_memcpy(rx_link.neighbor_almac, agent_dev->_1905_info.al_mac_addr, ETH_ALEN);
		} else {
#endif
			os_memcpy(tx_link.neighbor_almac, neighbor->n_almac, ETH_ALEN);
			os_memcpy(rx_link.neighbor_almac, neighbor->n_almac, ETH_ALEN);
#ifdef EM_PLUS_EXT_SUPPORT
		}
#endif
#ifdef MTK_MLO_MAP_SUPPORT
	}
#endif
	SLIST_FOREACH_SAFE(link, &neighbor->bh_head, next_bh, tlink) {
#ifdef MTK_MLO_MAP_SUPPORT
		cont_link_pair = link->mlo_link_no;
		cont_setup_valid = link->is_nonsetup_valid;

		if (is_setup_link)
#endif
			iface = topo_srv_get_interface(NULL, dev, link->connected_iface_addr);
#ifdef MTK_MLO_MAP_SUPPORT
		else {
			if (*is_ap == 0)
				iface = topo_srv_get_interface(NULL, dev, mac_addr);
			else if (*is_ap == 1)
				iface = topo_srv_get_interface(NULL, dev, link->mlo_tx[nonsetuplink_id].connected_iface_addr);

			if (!iface && (cont_link_pair > 0 && cont_link_pair < MAX_MLD_CLI) && (cont_setup_valid == 1)) {
				debug(DEBUG_CAT_METRIC, "still iface is NULL get BH IFACE for controlller");
				iface = topo_srv_get_interface(NULL, dev, link->connected_iface_addr);
				iface_add_cont = 1;
			}
		}
#endif

		if (!iface) {
			err(DEBUG_CAT_METRIC, "failed to get interface");
			return -1;
		}
		if ((iface->ap_role == 0x4) || (iface->ap_role == 0x00)) {
			debug(DEBUG_CAT_METRIC, "link count for ap or apcli role link_count = %d ", link_count);
			link_count++;
		} else {
			err(DEBUG_CAT_METRIC, "continue ap_role not found");
			continue;
		}
#ifdef MTK_MLO_MAP_SUPPORT
		if (is_setup_link) {
#endif
			debug(DEBUG_CAT_METRIC, "is_setup_link is TRUE i %d", i);
			/* TODO memory allocation here */
			tx_link_sub = &tx_link.metrics[i];
			/*fill into local interface mac addr */
			memcpy(tx_link_sub->mac_address, link->connected_iface_addr, ETH_ALEN);
			/*fill into neighbor interface mac addr */
			memcpy(tx_link_sub->mac_address_neighbor, link->neighbor_iface_addr, ETH_ALEN);
			/*fill into interface media type */
			tx_link_sub->intftype = iface->media_type;
			/*fill into bridge flag */
			tx_link_sub->ieee80211_bridgeflg = link->tx.is_80211_bridge;
			/*fill into tx packets error */
			tx_link_sub->packetErrors = link->tx.pkt_err;
			/*fill into total transmitted packets */
			tx_link_sub->transmittedPackets = link->tx.tx_packet;
			/*fill into max throughput capability */
			tx_link_sub->macThroughputCapacity = link->tx.mac_throughput;
			/*fill into link availability field */
			tx_link_sub->linkAvailability = link->tx.link_availability;
			/* fill into phy rate */
			tx_link_sub->phyRate = link->tx.phy_rate;

			info(DEBUG_CAT_METRIC, TOPO_PREX"connected_iface_addr("MACSTR") neighbor_iface_addr("MACSTR")",
			MAC2STR(link->connected_iface_addr), MAC2STR(link->neighbor_iface_addr));
			debug(DEBUG_CAT_METRIC, "Tx link=%d mac("MACSTR") n_mac("MACSTR
			") intftype=%d, ieee80211_bridgeflg=%d, packetErrors=%d",
			 link_count, MAC2STR(tx_link_sub->mac_address),
			  MAC2STR(tx_link_sub->mac_address_neighbor), tx_link_sub->intftype,
			   tx_link_sub->ieee80211_bridgeflg, tx_link_sub->packetErrors);

			debug(DEBUG_CAT_METRIC, "transmittedPackets=%d, macThroughputCapacity=%d, linkAvailability=%d, phyRate=%d",
				tx_link_sub->transmittedPackets, tx_link_sub->macThroughputCapacity,
				tx_link_sub->linkAvailability, tx_link_sub->phyRate);

			/* Rx link */
			rx_link_sub = &rx_link.metrics[i];
			/*fill into local interface mac addr */
			memcpy(rx_link_sub->mac_address, link->connected_iface_addr, ETH_ALEN);
			/*fill into neighbor interface mac addr */
			memcpy(rx_link_sub->mac_address_neighbor, link->neighbor_iface_addr, ETH_ALEN);
			/*fill into interface media type */
			rx_link_sub->intftype = iface->media_type;
			/*fill into rx packets error */
			rx_link_sub->packetErrors = link->rx.pkt_err;
			/*fill into total received packets */
			rx_link_sub->packetsReceived = link->rx.pkt_received;
			/* fill rssi */
			rx_link_sub->rssi = link->rx.rssi;
			debug(DEBUG_CAT_METRIC, "Rx link=%d, mac("MACSTR") n_mac("MACSTR") intftype=%d, packetErrors=%d",
				link_count, MAC2STR(rx_link_sub->mac_address), MAC2STR(rx_link_sub->mac_address_neighbor),
				rx_link_sub->intftype, rx_link_sub->packetErrors);
			debug(DEBUG_CAT_METRIC, "packetsReceived=%d, rssi=%d",
				rx_link_sub->packetsReceived, rx_link_sub->rssi);
#ifdef MTK_MLO_MAP_SUPPORT
		} else {
			debug(DEBUG_CAT_METRIC, "is NON setup link:%d i %d", nonsetuplink_id, i);
			tx_link_sub = &tx_link.metrics[i];
			/*fill into local interface mac addr */
			if (*is_ap == 0) {
				if (mac_addr)
					memcpy(tx_link_sub->mac_address, mac_addr, ETH_ALEN);
				/*fill into neighbor interface mac addr */
				if (iface_add_cont != 1 && agent_bssid_mac)
					os_memcpy(tx_link_sub->mac_address_neighbor, agent_bssid_mac, ETH_ALEN);
				else
					os_memcpy(tx_link_sub->mac_address_neighbor, ZERO_MAC_ADDR_MLO, ETH_ALEN);

			} else if (*is_ap == 1) {
				memcpy(tx_link_sub->mac_address,  link->mlo_tx[nonsetuplink_id].connected_iface_addr, ETH_ALEN);
				/*fill into neighbor interface mac addr */
				if (mac_addr)
					memcpy(tx_link_sub->mac_address_neighbor, mac_addr, ETH_ALEN);
			}
			/*fill into interface media type */
			tx_link_sub->intftype = iface->media_type;
			/*fill into bridge flag */
			tx_link_sub->ieee80211_bridgeflg = link->mlo_tx[nonsetuplink_id].is_80211_bridge;
			/*fill into tx packets error */
			tx_link_sub->packetErrors = link->mlo_tx[nonsetuplink_id].pkt_err;
			/*fill into total transmitted packets */
			tx_link_sub->transmittedPackets = link->mlo_tx[nonsetuplink_id].tx_packet;
			/*fill into max throughput capability */
			tx_link_sub->macThroughputCapacity = link->mlo_tx[nonsetuplink_id].mac_throughput;
			/*fill into link availability field */
			tx_link_sub->linkAvailability = link->mlo_tx[nonsetuplink_id].link_availability;
			if (tx_link_sub->linkAvailability > 100)
				tx_link_sub->linkAvailability = 100;
			/* fill into phy rate */
			tx_link_sub->phyRate = link->mlo_tx[nonsetuplink_id].phy_rate;
			debug(DEBUG_CAT_METRIC, " mac("MACSTR") n_mac("MACSTR")",
				MAC2STR(tx_link_sub->mac_address), MAC2STR(tx_link_sub->mac_address_neighbor));
			debug(DEBUG_CAT_METRIC,
			 "tx_link_sub->intftype:%d,  tx_link_sub->transmittedPackets:%d, tx_link_sub->linkAvailability %d",
			  tx_link_sub->intftype, tx_link_sub->transmittedPackets,
			  tx_link_sub->linkAvailability);
			/* Rx link */
			rx_link_sub = &rx_link.metrics[i];
			/*fill into local interface mac addr */
			if (*is_ap == 0) {
				if (mac_addr)
					memcpy(rx_link_sub->mac_address, mac_addr, ETH_ALEN);
				/*fill into neighbor interface mac addr */
			if (iface_add_cont != 1 && agent_bssid_mac)
				memcpy(rx_link_sub->mac_address_neighbor, agent_bssid_mac, ETH_ALEN);
			else
				memcpy(rx_link_sub->mac_address_neighbor, link->mlo_rx[nonsetuplink_id].connected_iface_addr, ETH_ALEN);

			} else if (*is_ap == 1) {
				memcpy(rx_link_sub->mac_address, link->mlo_rx[nonsetuplink_id].connected_iface_addr, ETH_ALEN);
				/*fill into neighbor interface mac addr */
				if (mac_addr)
					memcpy(rx_link_sub->mac_address_neighbor, mac_addr, ETH_ALEN);
			}
			/*fill into interface media type */
			rx_link_sub->intftype = iface->media_type;
			/*fill into rx packets error */
			rx_link_sub->packetErrors = link->mlo_rx[nonsetuplink_id].pkt_err;
			/*fill into total received packets */
			rx_link_sub->packetsReceived = link->mlo_rx[nonsetuplink_id].pkt_received;
			/* fill rssi */
			rx_link_sub->rssi = link->mlo_rx[nonsetuplink_id].rssi;

		debug(DEBUG_CAT_METRIC,
		 " MLO Rx link=%d, mac("MACSTR") n_mac("MACSTR") intftype=%d, packetErrors=%d, packetsReceived=%d, rssi=%d",
		  link_count, MAC2STR(rx_link_sub->mac_address), MAC2STR(rx_link_sub->mac_address_neighbor), rx_link_sub->intftype,
		   rx_link_sub->packetErrors, rx_link_sub->packetsReceived, rx_link_sub->rssi);

		}
#endif
		/* next backhaul between same neighbors */
		i++;
	}
	//TODO correct this based on new structure
#ifdef MTK_MLO_MAP_SUPPORT
	debug(DEBUG_CAT_METRIC, "mlo_link_pair %d link_count %d", mlo_link_pair, link_count);
	if (mlo_link_pair > 1) {
		tx_link.link_pair_cnt = mlo_link_pair;
		rx_link.link_pair_cnt = mlo_link_pair;
	} else {
#endif
		tx_link.link_pair_cnt = link_count;
		rx_link.link_pair_cnt = link_count;
#ifdef MTK_MLO_MAP_SUPPORT
		// Added for at controller side for fetching bh link number data
		if ((cont_setup_valid == 1) && (is_setup_link == 1) && (cont_link_pair != 0) && (cont_link_pair < MLO_LINK_MAX)) {
			tx_link.link_pair_cnt = cont_link_pair + 1; /* Non setup link plus setup link */
			rx_link.link_pair_cnt = cont_link_pair + 1;
		}
#endif
#ifdef MTK_MLO_MAP_SUPPORT
	}
#endif
	if (iface) {
		if ((iface->ap_role == 0x4)) {
			debug(DEBUG_CAT_METRIC, " copy sta info");
			if(sta_tx_link)
				os_memcpy(sta_tx_link, &tx_link, sizeof(tx_link));
			if(sta_rx_link)
				os_memcpy(sta_rx_link, &rx_link, sizeof(rx_link));

			*is_ap = 0;
		} else if (iface->ap_role == 0x00) {
			debug(DEBUG_CAT_METRIC, " copy ap info");
#ifdef MTK_MLO_MAP_SUPPORT
			if (is_call_from_combined == 0 && is_setup_link && num_of_ap_link > 0 && num_of_ap_link < MLO_LINK_MAX) {
				tx_link.link_pair_cnt = num_of_ap_link;
				rx_link.link_pair_cnt = num_of_ap_link;
				debug(DEBUG_CAT_METRIC, "AP TYPE APPEND LINK METRICS AP LINK NUM COPY:%d", num_of_ap_link);
			}
#endif
			if (ap_tx_link
#ifdef MTK_MLO_MAP_SUPPORT
			&& (is_setup_link) &&  (tx_link.link_pair_cnt <= 1)
			&& num_of_ap_link == 0
#endif
			) {
				os_memcpy(ap_tx_link, &tx_link, sizeof(tx_link));
			}
#ifdef MTK_MLO_MAP_SUPPORT
			else {
				if (is_call_from_combined) {

					debug(DEBUG_CAT_METRIC, "update link pair count");
					tx_link.link_pair_cnt = 1;
					if (ap_tx_link)
						os_memcpy(ap_tx_link, &tx_link, sizeof(tx_link));
					else
						err(DEBUG_CAT_METRIC, "ap_tx_link is null");
				} else {
					if (sta_tx_link)
						os_memcpy(sta_tx_link, &tx_link, sizeof(tx_link));
					else
						err(DEBUG_CAT_METRIC, "sta_tx_link is null");
				}
			}
#endif
			if (ap_rx_link
#ifdef MTK_MLO_MAP_SUPPORT
			&& (is_setup_link) && (rx_link.link_pair_cnt <= 1)
			&& num_of_ap_link == 0
#endif
			) {
				os_memcpy(ap_rx_link, &rx_link, sizeof(rx_link));
			}
#ifdef MTK_MLO_MAP_SUPPORT
			else {
				if (is_call_from_combined) {
					debug(DEBUG_CAT_METRIC, "update link pair count rx_link");
					rx_link.link_pair_cnt = 1;
					if (ap_rx_link)
						os_memcpy(ap_rx_link, &rx_link, sizeof(rx_link));
					else
						err(DEBUG_CAT_METRIC, "ap_rx_link is null");
				} else {
					if (sta_rx_link)
						os_memcpy(sta_rx_link, &rx_link, sizeof(rx_link));
					else
						err(DEBUG_CAT_METRIC, "sta_rx_link is null");
				}
			}
#endif
			*is_ap = 1;
		}
	}

	return i;
}

u8 is_op_class_2g(u8 op_class) {
	switch(op_class) {
		case 81:
		case 82:
		case 83:
		case 84:
		case 103:
		case 113:
		case 114:
			return TRUE;
		default:
			return FALSE;
	}
}
#ifdef CENT_STR
u8 is_op_class_5g(u8 op_class) {
	switch(op_class) {
		case 94:
		case 95:
		case 96:
		case 104:
		case 105:
		case 106:
		case 107:
		case 108:
		case 109:
		case 110:
		case 111:
		case 115:
		case 116:
		case 117:
		case 118:
		case 119:
		case 120:
		case 121:
		case 122:
		case 123:
		case 124:
		case 125:
		case 126:
		case 127:
		case 128:
		case 129:
		case 130:
			return TRUE;
		default:
			return FALSE;
	}
}
#endif

void topo_srv_update_wireless_mode(struct _1905_map_device *dev)
{
	struct radio_info_db *radio = NULL, *tradio = NULL;
	struct basic_cap_db *cap, *tcap = NULL;
	struct ap_radio_basic_capability *bcap;

	SLIST_FOREACH_SAFE(radio, &dev->first_radio, next_radio, tradio){
		radio->wireless_mode =0;
		bcap = &radio->radio_capability.basic_caps;
		SLIST_FOREACH_SAFE(cap, &bcap->bcap_head,basic_cap_entry, tcap) {
			if(is_op_class_2g(cap->op_class)) {
				radio->wireless_mode |= (WMODE_B | WMODE_G);
				if(radio->radio_capability.ht_cap.valid == 1)
					radio->wireless_mode |= WMODE_GN;
				if(radio->radio_capability.he_cap.valid == 1)
					radio->wireless_mode |= WMODE_AX_24G;
#ifdef MAP_R3_WF6
				if (radio->radio_capability.wf6_cap.valid == 1)
					radio->wireless_mode |= WMODE_AX_24G;
#endif
#ifdef MAP_EHT_SUPPORT
				if (radio->radio_capability.eht_cap.valid == 1)
					radio->wireless_mode |= WMODE_BE_24G;
#endif
			} else if (is_op_class_5g(cap->op_class)) {
				radio->wireless_mode |= (WMODE_A);
				if(radio->radio_capability.ht_cap.valid == 1)
					radio->wireless_mode |= WMODE_AN;
				if(radio->radio_capability.vht_cap.valid == 1)
					radio->wireless_mode |= (WMODE_AC | WMODE_AN);
				if(radio->radio_capability.he_cap.valid == 1)
					radio->wireless_mode |= WMODE_AX_5G;
#ifdef MAP_R3_WF6
				if (radio->radio_capability.wf6_cap.valid == 1)
					radio->wireless_mode |= WMODE_AX_5G;
#endif
#ifdef MAP_EHT_SUPPORT
				if (radio->radio_capability.eht_cap.valid == 1)
					radio->wireless_mode |= WMODE_BE_5G;
#endif
			}
#ifdef MAP_6E_SUPPORT
			else if (IS_OP_CLASS_6G(cap->op_class)) {
				radio->wireless_mode |= WMODE_AX_6G;
#ifdef MAP_EHT_SUPPORT
				if (radio->radio_capability.eht_cap.valid == 1)
					radio->wireless_mode |= WMODE_BE_6G;
#endif
			}
#endif
			else {
				err(DEBUG_CAT_METRIC, "op_class=%d is error\n", cap->op_class);
				return;
			}
		}
	}
}
#ifdef MAP_NON6E_CONTROLLER
void delete_1905_6g_radio(struct own_1905_device *ctx, struct _1905_map_device *dev)
{

	struct radio_info_db *radio = NULL, *tradio = NULL, *tmp_radio = NULL;
	struct bss_info_db *bss = NULL;
	u8 identifier[ETH_ALEN];
	struct esp_db *esp = NULL, *esp_tmp = NULL;
	struct cent_str_cu_mon_ch_info *ch_info = NULL, *tmp_ch_info = NULL;
	struct iface_info *iface = NULL, *tiface = NULL;

	if (dev->device_role == DEVICE_ROLE_AGENT) {
		SLIST_FOREACH_SAFE(radio, &dev->first_radio, next_radio, tradio) {
			if (radio && (radio->operating_class > 130 || radio->band > 3)) {
				os_memcpy(identifier, radio->identifier, ETH_ALEN);
				SLIST_FOREACH_SAFE(iface, &(dev->_1905_info.first_iface), next_iface, tiface) {
				tmp_radio = (struct radio_info_db *)iface->radio;
				if (tmp_radio) {
					if (os_memcmp(tmp_radio->identifier, identifier, ETH_ALEN) == 0) {
						err(DEBUG_CAT_METRIC, "clean up iface radio of 6G interface=%p valid=%d",
						 iface->radio, iface->valid);
						iface->radio = NULL;
						iface->valid = 0;
					}
				}
				}
				do {
					bss = topo_srv_get_next_bss(dev, bss);

					if (!bss) {
						err(DEBUG_CAT_METRIC, "no BSS found");
						break;
					}

					if (bss->radio == NULL)
						continue;

				if (os_memcmp(bss->radio->identifier, identifier, ETH_ALEN) == 0) {
					if (!SLIST_EMPTY(&(bss->esp_head))) {
					esp = SLIST_FIRST(&(bss->esp_head));
					while (esp) {
						esp_tmp = SLIST_NEXT(esp, esp_entry);
						SLIST_REMOVE(&(bss->esp_head), esp, esp_db, esp_entry);
						os_free(esp);
						esp = esp_tmp;
					}
					}
					bss->radio = NULL;
				}

				} while (bss);

				if (SLIST_EMPTY(&(ctx->cent_str_cu_mon_ch_list)))
					goto end;

				SLIST_FOREACH_SAFE(ch_info,
						&(ctx->cent_str_cu_mon_ch_list), next_mon_ch, tmp_ch_info) {

					if (ch_info->radio == NULL)
						continue;

					if (os_memcmp(ch_info->radio->identifier, identifier, ETH_ALEN) == 0)
						ch_info->radio = NULL;
				}

end:
				SLIST_REMOVE(&dev->first_radio,
						radio,
						radio_info_db,
						next_radio);
				os_free(radio);
				radio = NULL;
				dev->tear_down_6g = 1;
				break;
			}
		}
	}
}
#endif
/**
* @brief Fn to parse ap caps report
*
* @param ctx own 1905 device ctx
* @param buf msg buffer
*
* @return 0 if success else -1
*/
int topo_srv_prase_ap_cap_report(struct own_1905_device *ctx, unsigned char *buf, int left_tlv_len)
{
	int length = 0, len, tlv_len = 0;
	unsigned char *temp_buf;
	struct _1905_map_device *dev;
	struct ap_radio_basic_cap *bcap = NULL;
	struct ap_capability ap_cap;
	struct ap_ht_capability ht_cap;
	struct ap_vht_capability vht_cap;
	struct ap_he_capability he_cap;

#ifdef MAP_R2
	struct channel_scan_capab ch_scan_cap;
#endif

#ifdef MAP_R6
	struct dl_list wifi7_mlo_cap_list;
	struct wifi7_mlo_cap_db *mlo_cap = NULL, *mlo_cap_tmp = NULL;
	struct radio_info_db *radio = NULL;

	dl_list_init(&wifi7_mlo_cap_list);
#endif

	temp_buf = buf;
	dev = topo_srv_get_1905_device(ctx, temp_buf);

	if (!dev) {
		err(DEBUG_CAT_METRIC, "failed to get 1905 device");
		return -1;
	}
	temp_buf += ETH_ALEN;
	while (1) {
		len = get_tlv_len(temp_buf);
		tlv_len = len + 3;
		if (left_tlv_len < tlv_len) {
			err(DEBUG_CAT_METRIC, "Error TLV len, type = %d, left_tlv_length %d less than tlv_len %d",
					*temp_buf, left_tlv_len, tlv_len);
		}
		if (*temp_buf == AP_CAPABILITY_TYPE) {
			os_memset(&ap_cap, 0, sizeof(ap_cap));
			length = parse_ap_cap_tlv(temp_buf, dev, &ap_cap);
			if (length < 0) {
				err(DEBUG_CAT_METRIC, "error parse ap cap tlv");
				return -1;
			}
			topo_srv_update_1905_ap_cap(dev, &ap_cap);
			temp_buf += length;
		} else if (*temp_buf == AP_RADIO_BASIC_CAPABILITY_TYPE) {
			length = parse_basic_radio_cap_tlv(temp_buf, dev, &bcap);
			if (length < 0) {
				err(DEBUG_CAT_METRIC, "error basic ap cap tlv");
				if (bcap)
					os_free(bcap);
				return -1;
			}
			if (bcap) {
				topo_srv_update_radio_basic_cap(ctx, dev, bcap);
				os_free(bcap);
			}
			temp_buf += length;
		} else if (*temp_buf == AP_HT_CAPABILITY_TYPE) {
			length = parse_ap_ht_cap_tlv(temp_buf, &ht_cap);
			if (length < 0) {
				err(DEBUG_CAT_METRIC, "error ap ht cap tlv");
				return -1;
			}
			topo_srv_update_ap_ht_cap(ctx, dev, &ht_cap);
			temp_buf += length;
		} else if (*temp_buf == AP_VHT_CAPABILITY_TYPE) {
			length = parse_ap_vht_cap_tlv(temp_buf, &vht_cap);
			if (length < 0) {
				err(DEBUG_CAT_METRIC, "error ap vht cap tlv");
				return -1;
			}
			topo_srv_update_ap_vht_cap(ctx, dev, &vht_cap);
			temp_buf += length;
		} else if (*temp_buf == AP_HE_CAPABILITY_TYPE) {
			length = parse_ap_he_cap_tlv(temp_buf, &he_cap);
			if (length < 0) {
				err(DEBUG_CAT_METRIC, "error ap he cap tlv");
				return -1;
			}
			topo_srv_update_ap_he_cap(ctx, dev, &he_cap);
			temp_buf += length;
		}
#ifdef MAP_R2
		else if (*temp_buf == CHANNEL_SCAN_CAPABILITY_TYPE) {
			length = parse_ap_scan_cap_tlv(temp_buf, dev, &ch_scan_cap);
			if (length < 0) {
				err(DEBUG_CAT_METRIC, "error channel scan capability TLV");
				return -1;
			}
			topo_srv_update_dev_ch_scan_cap(ctx, dev, &ch_scan_cap);
			temp_buf += length;
		}
		/* One CAC Capabilities TLV */
		else if (*temp_buf == CAC_CAPABILITIES_TYPE) {
			length = parse_ap_cac_cap_tlv(temp_buf, dev, left_tlv_len);
			if (length < 0) {
				err(DEBUG_CAT_METRIC, "error channel scan capability TLV");
				return -1;
			}
			temp_buf += length;
		} else if (*temp_buf == METRIC_COLLECTION_INTERVAL_TYPE) {
			length = parse_metric_collection_intv_tlv(temp_buf, dev);
			if (length < 0) {
				err(DEBUG_CAT_METRIC, "error channel scan capability TLV");
				return -1;
			}
			temp_buf += length;
		} else if (*temp_buf == R2_AP_CAPABILITY_TYPE) {
			length = parse_r2_cap_tlv(temp_buf, dev);
			//dev->map_version = DEV_TYPE_R2;
			temp_buf += length;
		}
#endif
#ifdef MAP_R3
				/* One Device 1905 Layer Security Capability TLV */
		else if (*temp_buf == _1905_LAYER_SECURITY_CAPABILITY_TYPE) {

			length = parse_1905_layer_secure_cap_tlv(dev, temp_buf);
			if(length < 0) {
				err(DEBUG_CAT_METRIC, "error 1905layer security cap tlv");
				return -1;
			}
			temp_buf += length;
		}
		else if (*temp_buf == AP_WF6_CAPABILITIES_TLV) {
			debug(DEBUG_CAT_METRIC, "This is expected WIFI6 HE 2 capaility");
			length = parse_ap_wf6_capability_tlv(dev, temp_buf);
			temp_buf += length;
		}
#endif // MAP_R3
#ifdef MAP_R3_DE
		else if (*temp_buf == R3_DE_INVENTORY_TLV_TYPE) {
			length = parse_r3_de_inven_tlv(temp_buf, dev);
			temp_buf += length;
		}
#endif //MAP_R3_DE
#ifdef MAP_EHT_SUPPORT
		else if (*temp_buf == VENDOR_SPECIFIC_TLV_TYPE
#ifdef MAP_R6
			&& dev->R6_dev == 0
#endif
			) {
			length = parse_ap_vendor_specific_tlv(dev, temp_buf);
			temp_buf += length;
		}
#ifdef MAP_R6
		else if (*temp_buf == EHT_OPERATION_TLV_TYPE && dev->R6_dev == 1) {
			length = parse_eht_operations_tlv(dev, temp_buf);
			temp_buf += length;
		}
#endif
#endif
#ifdef MAP_R6
		else if (*temp_buf == WIFI7_AGENT_CAPABILITY_TLV_TYPE) {
			length = parse_wifi7_mlo_capability_tlv(dev, &wifi7_mlo_cap_list, temp_buf);
			temp_buf += length;
		}
#endif
		else if (*temp_buf == END_OF_TLV_TYPE) {
			break;
		} else {
			length = get_cmdu_tlv_length(temp_buf);
			temp_buf += length;
		}
		left_tlv_len -= tlv_len;
	}
	/*check integrity */
	topo_srv_update_wireless_mode(dev);

#ifdef MAP_R6
	if (dev->R6_dev == 0) {
		err(DEBUG_CAT_METRIC, "not R6 dev");
		dl_list_for_each_safe(mlo_cap, mlo_cap_tmp, &wifi7_mlo_cap_list,
			struct wifi7_mlo_cap_db, list) {
			dl_list_del(&mlo_cap->list);
			os_free(mlo_cap);
		}
		return 0;
	}

	if (dl_list_empty(&wifi7_mlo_cap_list)) {
		err(DEBUG_CAT_METRIC, "WIFI7 mlo cap list empty");
		return 0;
	}
	radio = topo_srv_get_next_radio(dev, radio);
	while (radio) {
		os_memset(&radio->wf7_mlo_cap, 0, sizeof(struct wifi7_mlo_cap_db));
		radio = topo_srv_get_next_radio(dev, radio);
	}

	dl_list_for_each_safe(mlo_cap, mlo_cap_tmp, &wifi7_mlo_cap_list,
			struct wifi7_mlo_cap_db, list) {
		radio = NULL;
		radio = find_radio_db_ruid(dev, mlo_cap->identifier);

		if (!radio)
			continue;

		radio->ap_mlo_enable = 0;
		radio->wf7_mlo_cap.ap_str_support = mlo_cap->ap_str_support;
		radio->wf7_mlo_cap.ap_nstr_support = mlo_cap->ap_nstr_support;
		radio->wf7_mlo_cap.ap_emlsr_support = mlo_cap->ap_emlsr_support;
		radio->wf7_mlo_cap.ap_emlmr_support = mlo_cap->ap_emlmr_support;
		info(DEBUG_CAT_METRIC, TOPO_PREX"mlo_cfg->ap_str_support %d", mlo_cap->ap_str_support);
		if (mlo_cap->ap_str_support || mlo_cap->ap_nstr_support ||
				mlo_cap->ap_emlsr_support || mlo_cap->ap_emlmr_support) {
			radio->ap_mlo_enable = 1;
			radio->radio_capability.mlo_cap.MloCapPerRole[0].mlo_enable = 1;
			info(DEBUG_CAT_METRIC, TOPO_PREX"ap mlo cap valid for ruid "MACSTR,
					MAC2STR(mlo_cap->identifier));
		}
		if (mlo_cap->sta_str_support || mlo_cap->sta_nstr_support ||
				mlo_cap->ap_emlsr_support || mlo_cap->sta_emlmr_support) {
			radio->radio_capability.mlo_cap.MloCapPerRole[1].mlo_enable = 1;
			info(DEBUG_CAT_METRIC, TOPO_PREX"sta mlo cap valid for ruid "MACSTR,
					MAC2STR(mlo_cap->identifier));
		}
		os_memcpy(&radio->wf7_mlo_cap, mlo_cap, sizeof(struct wifi7_mlo_cap_db));
		dl_list_del(&mlo_cap->list);
		os_free(mlo_cap);
	}
	if (!dl_list_empty(&wifi7_mlo_cap_list)) {
		dl_list_for_each_safe(mlo_cap, mlo_cap_tmp, &wifi7_mlo_cap_list,
					struct wifi7_mlo_cap_db, list) {
			dl_list_del(&mlo_cap->list);
			os_free(mlo_cap);
		}
	}
#endif

	debug(DEBUG_CAT_METRIC, "exit");

	return 0;

}

#ifdef MAP_R6
/**
 * @brief Fn to parse early ap caps report
 *
 * @param ctx own 1905 device ctx
 * @param buf msg buffer
 *
 * @return 0 if success else -1
 */
int topo_srv_prase_early_ap_cap_report(struct own_1905_device *ctx, unsigned char *buf, int left_tlv_len)
{
	unsigned char *temp_buf;
	struct _1905_map_device *dev;
	unsigned char al_mac_addr[ETH_ALEN];

	err(DEBUG_CAT_METRIC, "entry");

	temp_buf = (unsigned char *)buf;
	memcpy(al_mac_addr, temp_buf, ETH_ALEN);

	dev = topo_srv_get_1905_device(ctx, temp_buf);
	if (!dev)
		dev = topo_srv_create_1905_device(ctx, al_mac_addr);

	dev->R6_dev = 1;
	err(DEBUG_CAT_METRIC, "exit");

	return 0;
}

int topo_srv_prase_controller_found_event(struct own_1905_device *ctx,
			unsigned char *buf,
			int len)
{
	struct _1905_map_device *dev = NULL;
	unsigned char al_mac_addr[ETH_ALEN];
	unsigned char *temp_buf;
	int r6_dev = 0;

	err(DEBUG_CAT_METRIC, "entry");
	temp_buf = (unsigned char *)buf;
	memcpy(al_mac_addr, temp_buf, ETH_ALEN);
	temp_buf += ETH_ALEN;
	len -= ETH_ALEN;

	r6_dev = *temp_buf;
	info(DEBUG_CAT_METRIC, "r6_dev = %d", r6_dev);
	dev = topo_srv_get_1905_device(ctx, al_mac_addr);
	if (!dev)
		dev = topo_srv_create_1905_device(ctx, al_mac_addr);
	dev->R6_dev = r6_dev;


	err(DEBUG_CAT_METRIC, "Exit");
	return 0;
}


/**
 * @brief Fn to parse autoconfig ap caps report
 *
 * @param ctx own 1905 device ctx
 * @param buf msg buffer
 *
 * @return 0 if success else -1
 */
int topo_srv_prase_autoconfig_ap_cap_report(struct own_1905_device *ctx,
			unsigned char *buf,
			int len)
{
	unsigned char al_mac_addr[ETH_ALEN];
	int length = 0;
	unsigned char *temp_buf;
	unsigned char integrity = 0;
	struct _1905_map_device *dev = NULL;
	unsigned short check_len = 0;
	unsigned short tlv_len = 0;
	int r6_dev = 0;

	err(DEBUG_CAT_METRIC, "entry\n");

	temp_buf = (unsigned char *)buf;
	memcpy(al_mac_addr, temp_buf, ETH_ALEN);
	temp_buf += ETH_ALEN;
	len -= ETH_ALEN;

	while (1) {
		check_len = get_tlv_len(temp_buf);
		tlv_len = check_len + 3;

		if (len < tlv_len) {
			err(DEBUG_CAT_METRIC, "Error TLV len, type = %d, len %d less than tlv_len %d\n",
					*temp_buf, len, tlv_len);
			return -1;
		}

		if (*temp_buf == CONTROLLER_CAPABILITY_TYPE) {
			integrity |= 0x1;
			err(DEBUG_CAT_METRIC, "CONTROLLER_CAPABILITY_TYPE");
			length = parse_controller_cap_tlv(ctx, NULL, temp_buf, &r6_dev);
			if (length < 0) {
				err(DEBUG_CAT_METRIC, "error parse controller cap tlv");
				return -1;
			}
			temp_buf += length;
			err(DEBUG_CAT_METRIC, "r6_dev = %d", r6_dev);
			dev = topo_srv_get_1905_device(ctx, al_mac_addr);
			if (!dev)
				dev = topo_srv_create_1905_device(ctx, al_mac_addr);
			dev->R6_dev = r6_dev;
		} else if (*temp_buf == END_OF_TLV_TYPE) {
			goto out;
		} else {
			length = get_cmdu_tlv_length(temp_buf);
			temp_buf += length;
		}
		len -= tlv_len;
	}
out:
	/*check integrity */
	if (integrity != 0x1) {
		err(DEBUG_CAT_METRIC, "no controller capability tlv");
		return -1;
	}

	err(DEBUG_CAT_METRIC, "exit");

	return 0;
}
#endif /* MAP_R6 */
/**
* @brief Fn to parse combined infra msg
*
* @param ctx own 1905 device ctx
* @param buf msg buffer
*
* @return 0 if success else -1
*/
int topo_srv_parse_combined_infra_msg(struct own_1905_device *ctx, unsigned char *buf, int len)
{
	int length = 0;
	unsigned char *temp_buf;
	unsigned char integrity = 0;
	struct _1905_map_device *dev = NULL;
	unsigned short check_len = 0;
	unsigned short tlv_len = 0;

	temp_buf = buf;
	while (1) {
		check_len = get_tlv_len(temp_buf);
		tlv_len = check_len + 3;

		if (len < tlv_len) {
			err(DEBUG_CAT_METRIC, "Error TLV len, type = %d, len %d less than tlv_len %d\n",
					*temp_buf, len, tlv_len);
			return -1;
		}

		if (*temp_buf == AP_METRICS_TYPE) {
			integrity |= 0x1;
			//err(DEBUG_CAT_METRIC, "parse combined infra metric");
			//err_hexdump(DEBUG_CAT_METRIC, "parse combined infra metric", temp_buf, 44);
			length = parse_ap_metrics_tlv(ctx, NULL, temp_buf);
			if (length < 0) {
				err(DEBUG_CAT_METRIC, "error parse ap metrics tlv");
				return -1;
			}
			temp_buf += length;
		} else if (*temp_buf == TRANSMITTER_LINK_METRIC_TYPE) {
			integrity |= 0x1;
			dev = topo_srv_get_1905_device(ctx, temp_buf + 3);
			if (!dev) {
				err(DEBUG_CAT_METRIC, "failed to get tx metric dev");
				err_hexdump(DEBUG_CAT_METRIC, "topo_srv_parse_combined_infra_msg", temp_buf, 44);
				return -1;
			}
			length = parse_tx_link_metrics_tlv(temp_buf, dev);
			if (length < 0) {
				err(DEBUG_CAT_METRIC, "error tx link metrics tlv");
				return -1;
			}
			temp_buf += length;
		} else if (*temp_buf == RECEIVER_LINK_METRIC_TYPE) {
			integrity |= 0x1;
			dev = topo_srv_get_1905_device(ctx, temp_buf + 3);
			if (!dev) {
				err(DEBUG_CAT_METRIC, "failed to get rx metric dev");
				err_hexdump(DEBUG_CAT_METRIC, "topo_srv_parse_combined_infra_msg", temp_buf, 38);
				return -1;
			}
			length = parse_rx_link_metrics_tlv(temp_buf, dev);
			if (length < 0) {
				err(DEBUG_CAT_METRIC, "error rx link metrics tlv");
				return -1;
			}
			temp_buf += length;
		} else if (*temp_buf == END_OF_TLV_TYPE) {
			break;
		} else {
			length = get_cmdu_tlv_length(temp_buf);
			temp_buf += length;
		}
		len -= tlv_len;
	}
	/*check integrity */
	if (integrity != 0x1) {
		err(DEBUG_CAT_METRIC, "no backhaul steering response tlv");
		return -1;
	}
	debug(DEBUG_CAT_METRIC, "exit");

	return 0;
}

/**
* @brief Fn to delete current metrics policy
*
* @param mpolicy policy to be delelted
*
* @return -1 if error else 0
*/
int delete_exist_metrics_policy(struct metrics_policy *mpolicy)
{
	struct metric_policy_db *policy = NULL, *policy_tmp = NULL;

	debug(DEBUG_CAT_METRIC, "delete_steering_policy");

	policy = SLIST_FIRST(&mpolicy->policy_head);
	while (policy != NULL) {
		debug(DEBUG_CAT_METRIC, "metric_policy_db identifier("MACSTR")",
			     MAC2STR(policy->identifier));
		debug(DEBUG_CAT_METRIC, "rssi_thres=%d, hysteresis_margin=%d, ch_util_thres=%d"
			     "rssi_thres=%d, hysteresis_margin=%d",
			     policy->rssi_thres, policy->hysteresis_margin, policy->ch_util_thres,
			     policy->sta_stats_inclusion, policy->sta_metrics_inclusion);
		policy_tmp = SLIST_NEXT(policy, policy_entry);
		free(policy);
		policy = policy_tmp;
	}
	SLIST_INIT(&mpolicy->policy_head);
	mpolicy->report_interval = 0;
	mpolicy->radio_num = 0;

	return 0;
}

/**
* @brief 
*
* @param ctx
* @param msg_buf
* @param len
*
* @return 
*/
int topo_srv_handle_assoc_link_metrics_rsp(struct own_1905_device *ctx, unsigned char *buf, int len)
{
	struct _1905_map_device *dev = topo_srv_get_1905_device(ctx, buf);
	
	if(!dev){
		err(DEBUG_CAT_METRIC, "dev is NULL");
		return -1;
	}
	info(DEBUG_CAT_METRIC, "got ASSOC_LINK_METRICS_RESPONSE from ("MACSTR")", MAC2STR(buf));
	/*parse assoc link metrics response message*/
	if (parse_associated_sta_link_metrics_rsp_msg(ctx, dev, buf + ETH_ALEN, len) < 0)
		debug(DEBUG_CAT_METRIC, "error! parse assoc sta link metrics response message");

	return 0;
}

/**
* @brief Fn to handle assoc link metrics resp
*
* @param ctx own 1905 device ctx
* @param msg_buf msg buffer
* @param len msg len
*
* @return 0
*/
int topo_srv_handle_unassoc_link_metrics_rsp(struct own_1905_device *ctx, unsigned char *msg_buf, int len)
{
	ap_est_handle_unassoc_sta_link_metric_rsp(ctx->back_ptr, (struct unassoc_link_1905_metric_tlv_rsp *) msg_buf, len);
	return 0;
}


#ifdef CENT_STR
int parse_beacon_metrics_rsp_tlv(struct own_1905_device * ctx, struct _1905_map_device *dev, unsigned char *buf)
{
	unsigned char *temp_buf;
	unsigned short length = 0,rpt_len = 0;
	unsigned char *bcn_rpt, bcn_rpt_num;
	unsigned char isSuccess = 1, islastreport= 0;
	unsigned char sta_mac[ETH_ALEN] = {0};
	PEID_STRUCT eid_ptr = NULL;
	prrm_beacon_rep_info pBcnRep = NULL;
	int bcnrpt_cnt = 0;
	struct client *cli = NULL;
#ifdef MAP_6E_SUPPORT
	uint8_t band = 0;
#endif
	temp_buf = buf;

	if((*temp_buf) == BEACON_METRICS_RESPONSE_TYPE) {
		temp_buf++;
	} else {
		err(DEBUG_CAT_METRIC, CENT_STEER_PREX"should not go here");
		return -1;
	}
	//calculate tlv length
	length = *(unsigned short *)temp_buf;
	length = (length << 8) & 0xFF00;
	length = length |(*(temp_buf+1));

	//shift to tlv value field
	temp_buf += 2;

	//Copy sta mac address
	os_memcpy(sta_mac, temp_buf, ETH_ALEN);	
	temp_buf += ETH_ALEN;		

	//skip resvd field
	temp_buf += 1;
	
	bcn_rpt_num = *temp_buf;
	temp_buf++;

	if(length > 0)
	rpt_len = length - 8;
	else
		rpt_len = 0;


	bcn_rpt = (unsigned char *)temp_buf;	

	cli = client_db_get_client_from_sta_mac((struct mapd_global *)ctx->back_ptr, sta_mac);
	if(cli && rpt_len) {
		if (cli->beacon_report_ie) {
			os_free(cli->beacon_report_ie);
			cli->beacon_report_ie = NULL;
			cli->beacon_report_ie_len = 0;
			cli->num_beacon_report = 0;
		}
		cli->beacon_report_ie = os_zalloc(rpt_len);
		if (cli->beacon_report_ie) {
			os_memcpy(cli->beacon_report_ie, bcn_rpt, rpt_len);
			cli->beacon_report_ie_len = rpt_len;
			cli->num_beacon_report = bcn_rpt_num;
		} else {
			err(DEBUG_CAT_METRIC, "alloc beacon_report_ie for cli("MACSTR") fail. ie_len(%d)",
				MAC2STR(sta_mac), rpt_len);
		}
	}

	if(rpt_len > 0) {
		eid_ptr = (PEID_STRUCT)bcn_rpt;
		while (((u8 *)eid_ptr + eid_ptr->Len + 1) < ((u8 *)bcn_rpt + rpt_len)){
			switch (eid_ptr->Eid) {
				case IE_MEASUREMENT_REPORT:
					/*Skip measurement report token and type*/
					if(eid_ptr->Len - 3 > 0){
						pBcnRep = (prrm_beacon_rep_info)((u8*)eid_ptr->Octet + 3);
						debug(DEBUG_CAT_METRIC, CENT_STEER_PREX"Chan No:%d, rcpi:%d, bssid:"MACSTR"\n",
						 pBcnRep->ch_number, pBcnRep->rcpi, MAC2STR(pBcnRep->bssid));
						bcnrpt_cnt++;

						if(bcnrpt_cnt == bcn_rpt_num)
							islastreport = 1;
#ifdef MAP_6E_SUPPORT
						band = get_band_6E(dev, pBcnRep->ch_number, pBcnRep->regulatory_Class);
#endif

						ap_est_handle_11k_report(ctx->back_ptr, sta_mac, isSuccess,
							pBcnRep->bssid, pBcnRep->ch_number,
							pBcnRep->rcpi, islastreport
#ifdef MAP_6E_SUPPORT
							, band
#endif
						);
					} else {
						isSuccess = 0;
						ap_est_handle_11k_report(ctx->back_ptr, sta_mac, isSuccess,
									NULL, 0, 0, 0
#ifdef MAP_6E_SUPPORT
									, 0
#endif
						);
					}
					break;
				default:
					break;

			}
			eid_ptr = (PEID_STRUCT)((u8 *)eid_ptr + 2 + eid_ptr->Len);
		}
	
	}


	return (length+3);
}

int parse_beacon_metrics_rsp_msg(struct own_1905_device *ctx, struct _1905_map_device *dev, unsigned char *buf, int len)
{
	int length = 0;
	unsigned char *temp_buf;
	unsigned short check_len = 0;
	unsigned short tlv_len = 0;


        temp_buf = buf;
        while (1) {
		check_len = get_tlv_len(temp_buf);
		tlv_len = check_len + 3;

			if (len < tlv_len) {
				err(DEBUG_CAT_METRIC, "Error TLV len, type = %d, len %d less than tlv_len %d\n",
					*temp_buf, len, tlv_len);
				return -1;
			}

			if (*temp_buf == BEACON_METRICS_RESPONSE_TYPE) {
				length = parse_beacon_metrics_rsp_tlv(ctx, dev, temp_buf);
				if (length < 0) {
					err(DEBUG_CAT_METRIC, CENT_STEER_PREX"error associated sta link metrics query tlv");
					return -1;
				}
				temp_buf += length;
			} else if (*temp_buf == END_OF_TLV_TYPE) {
					break;
			} else {
					length = get_cmdu_tlv_length(temp_buf);
					temp_buf += length;
			}
		len -= tlv_len;
        }

        return 0;
}


#endif


/**
* @brief Fn to handle beacon metrics resp event
*
* @param ctx own 1905 device ctx
* @param msg_buf msg buffer
* @param len msg length
*
* @return 0
*/
int topo_srv_handle_beacon_metrics_rsp_event(struct own_1905_device *ctx, unsigned char *msg_buf, int len)
{
	struct _1905_map_device *dev = topo_srv_get_1905_device(ctx, msg_buf);
	
	info(DEBUG_CAT_METRIC, "got BEACON METRICS RESPONSE from ("MACSTR")", MAC2STR(msg_buf));
	/*parse beacon metrics response message*/
	if (parse_beacon_metrics_rsp_msg(ctx, dev, msg_buf + ETH_ALEN, len) < 0)
		debug(DEBUG_CAT_METRIC, "error! parse beacon metrics response message");

	return 0;
}

/**
* @brief Fn to delete existing unlink metrics info
*
* @param unlink_metrics unlink metrics to be deleted
*
* @return -1 if error else 0
*/
int delete_exist_unlink_metrics_rsp(struct unlink_metrics_info *unlink_metrics)
{
	struct unlink_metrics_db *metrics = NULL, *metrics_tmp = NULL;

	debug(DEBUG_CAT_METRIC, "delete_exist_unlink_metrics_info");

	unlink_metrics->oper_class = 0;
	unlink_metrics->sta_num = 0;
	metrics = SLIST_FIRST(&unlink_metrics->unlink_metrics_head);
	while (metrics != NULL) {
		metrics_tmp = SLIST_NEXT(metrics, unlink_metrics_entry);
		debug(DEBUG_CAT_METRIC, "sta mac="MACSTR, MAC2STR(metrics->mac));
		debug(DEBUG_CAT_METRIC, "ch=%d, time_delta=%d, uplink_rssi=%d",
			     metrics->ch, metrics->time_delta, metrics->uplink_rssi);
		free(metrics);
		metrics = metrics_tmp;
	}
	SLIST_INIT(&unlink_metrics->unlink_metrics_head);

	return 0;
}

/**
* @brief Fn to update unlink metrics resp
*
* @param unlink_metrics_ctx unlink mterics context
* @param unlink_metrics unlink metrics response
*
* @return -1 if error else 0
*/
int update_unlink_metrics_rsp(struct unlink_metrics_info *unlink_metrics_ctx, struct unlink_metrics_rsp *unlink_metrics)
{
	struct unlink_metrics_db *metrics = NULL;
	struct unlink_rsp_sta *info = NULL;
	int i = 0;

	debug(DEBUG_CAT_METRIC, "enter");

	delete_exist_unlink_metrics_rsp(unlink_metrics_ctx);

	unlink_metrics_ctx->oper_class = unlink_metrics->oper_class;
	unlink_metrics_ctx->sta_num = unlink_metrics->sta_num;
	debug(DEBUG_CAT_METRIC, "oper_class=%d, sta_num=%d",
		     unlink_metrics_ctx->oper_class, unlink_metrics_ctx->sta_num);

	SLIST_INIT(&unlink_metrics_ctx->unlink_metrics_head);

	for (i = 0; i < unlink_metrics->sta_num; i++) {
		metrics = (struct unlink_metrics_db *)
		    os_zalloc(sizeof(struct unlink_metrics_db));
		if (!metrics) {
			debug(DEBUG_CAT_METRIC, "alloc struct unlink_metrics_db fail");
			return -1;
		}
		info = &unlink_metrics->info[i];
		memcpy(metrics->mac, info->mac, ETH_ALEN);
		metrics->ch = info->ch;
		metrics->time_delta = info->time_delta;
		metrics->uplink_rssi = info->uplink_rssi;
		info->uplink_rssi = rssi_to_rcpi(info->uplink_rssi);
		SLIST_INSERT_HEAD(&unlink_metrics_ctx->unlink_metrics_head, metrics, unlink_metrics_entry);
		debug(DEBUG_CAT_METRIC, "sta mac="MACSTR, MAC2STR(metrics->mac));
		debug(DEBUG_CAT_METRIC, "ch=%d, time_delta=%d, uplink_rssi=%d",
			     metrics->ch, metrics->time_delta, metrics->uplink_rssi);
	}
	return 0;

}
/**
* @brief Fn to update one station link metrics
*
* @param ctx own 1905 device ctx
* @param metrics link_metrics for sta
*
* @return -1 if error else 0
*/
int update_one_sta_link_metrics_info(struct own_1905_device *ctx, struct link_metrics *metrics)
{
#ifdef MAP_R6
	struct metrics_db *metrics_sta = &ctx->metric_entry.assoc_sta_link_metrics[ctx->affiliated_sta_index];
#else
	struct metrics_db *metrics_sta = &ctx->metric_entry.assoc_sta_link_metrics;
#endif

	debug(DEBUG_CAT_METRIC, "enter");

	//memset(metrics_sta, 0, sizeof(struct metrics_db));
	memcpy(metrics_sta->mac, metrics->mac, ETH_ALEN);
	memcpy(metrics_sta->bssid, metrics->bssid, ETH_ALEN);
	metrics_sta->time_delta = metrics->time_delta;
	metrics_sta->erate_downlink = metrics->erate_downlink;
	metrics_sta->erate_uplink = metrics->erate_uplink;
	metrics_sta->rssi_uplink = metrics->rssi_uplink;

	debug(DEBUG_CAT_METRIC, "insert struct link_metrics_db");
	debug(DEBUG_CAT_METRIC, "sta mac("MACSTR")", MAC2STR(metrics_sta->mac));
	debug(DEBUG_CAT_METRIC, "bssid("MACSTR")", MAC2STR(metrics_sta->bssid));
	debug(DEBUG_CAT_METRIC, "time_delta=%d, erate_downlink=%d erate_uplink=%d rssi_uplink=%d",
	     metrics_sta->time_delta, metrics_sta->erate_downlink, metrics_sta->erate_uplink, metrics_sta->rssi_uplink);

	return 0;

}
#ifdef MAP_R2
int update_one_sta_link_ext_metrics_info(struct own_1905_device *ctx, struct ext_link_metrics *metrics)
{
#ifdef MAP_R6
	struct metrics_db *metrics_sta = &ctx->metric_entry.assoc_sta_link_metrics[ctx->affiliated_sta_index];
#else
	struct metrics_db *metrics_sta = &ctx->metric_entry.assoc_sta_link_metrics;
#endif
	debug(DEBUG_CAT_METRIC, "enter");

	//memset(metrics_sta, 0, sizeof(struct metrics_db));
	memcpy(metrics_sta->mac, metrics->mac, ETH_ALEN);
	memcpy(metrics_sta->bssid, metrics->bssid, ETH_ALEN);

	metrics_sta->sta_ext_info.last_data_dl_rate = metrics->last_data_dl_rate;
	metrics_sta->sta_ext_info.last_data_ul_rate = metrics->last_data_ul_rate;
	metrics_sta->sta_ext_info.utilization_rx = metrics->utilization_rx;
	metrics_sta->sta_ext_info.utilization_tx = metrics->utilization_tx;

	debug(DEBUG_CAT_METRIC, "insert struct link_metrics_db");
	debug(DEBUG_CAT_METRIC, "sta mac("MACSTR")", MAC2STR(metrics_sta->mac));
	debug(DEBUG_CAT_METRIC, "bssid("MACSTR")", MAC2STR(metrics_sta->bssid));
	debug(DEBUG_CAT_METRIC, "dl rate: %d, ul rate: %d", metrics_sta->sta_ext_info.last_data_dl_rate,
	 metrics_sta->sta_ext_info.last_data_ul_rate);
	debug(DEBUG_CAT_METRIC, "rx rate: %d, tx rate: %d", metrics_sta->sta_ext_info.utilization_rx,
	 metrics_sta->sta_ext_info.utilization_tx);

	return 0;

}

#endif

/**
* @brief Fn to add new link metrics info
*
* @param ctx own 1905 device ctx
* @param metrics_info sta_link_metrics to be added
*
* @return 0 if success else -1
*/
int topo_srv_create_new_sta(struct own_1905_device *ctx, struct link_metrics *cinfo)
{
	struct _1905_map_device *device = topo_srv_get_1905_device(ctx, NULL);
	struct connected_clients *client = NULL, *tmp_conn_cli = NULL, *t_tmp_conn_cli = NULL;
	struct associated_clients *assoc_client = NULL;
	struct bss_info_db *bss = NULL;
	uint32_t client_id, is_exit = 0;

	// TODO move connected clients to bss basis
	client = (struct connected_clients *)os_zalloc(sizeof(struct connected_clients));
	assoc_client = (struct associated_clients *)os_zalloc(sizeof(struct associated_clients));
	if (!client || !assoc_client) {
		err(DEBUG_CAT_METRIC, "mem assoc failed");
		if (client)
			os_free(client);
		if (assoc_client)
			os_free(assoc_client);
		return -1;
	}
	os_memcpy(client->client_addr, cinfo->mac, ETH_ALEN);
	os_memcpy(client->_1905_iface_addr, cinfo->bssid, ETH_ALEN);
	os_memcpy(assoc_client->client_addr, cinfo->mac, ETH_ALEN);
	client->is_APCLI = cinfo->is_APCLI;
	assoc_client->is_APCLI = cinfo->is_APCLI;
	bss = topo_srv_get_bss_by_bssid(ctx, device, cinfo->bssid);
	assoc_client->bss = bss;

	if(assoc_client->bss != NULL) {
		os_memcpy(assoc_client->bss->bssid, cinfo->bssid, ETH_ALEN);
		os_memcpy(client->bss_addr, cinfo->bssid, ETH_ALEN);
	} else {
		err(DEBUG_CAT_METRIC, "There is no BSS");
		os_free(client);
		os_free(assoc_client);
		return -1;
	}

	assoc_client->last_assoc_time = 0;

	if (!ctx->dual_bh_en)
		remove_duplicate_cli_single_bh(device, ctx, cinfo->mac);
	SLIST_FOREACH_SAFE(tmp_conn_cli, &(device->wlan_clients), next_client, t_tmp_conn_cli) {
		if (!is_zero_ether_addr(client->client_addr) &&
			0 == os_memcmp(client->client_addr, tmp_conn_cli->client_addr, ETH_ALEN)) {
			tmp_conn_cli->link_info = client->link_info;
			os_memmove(tmp_conn_cli->bss_addr, client->bss_addr, ETH_ALEN);
			tmp_conn_cli->entry_valid = client->entry_valid;
			tmp_conn_cli->is_bh_link = client->is_bh_link;
			tmp_conn_cli->is_APCLI = client->is_APCLI;
			is_exit = 1;
			debug(DEBUG_CAT_METRIC, "duplicate sta(%02x:%02x:%02x:%02x:%02x:%02x) in bss(%02x:%02x:%02x:%02x:%02x:%02x)",
			PRINT_MAC(client->client_addr), PRINT_MAC(client->bss_addr));
			break;
		}
	}
	if (!is_exit)
		SLIST_INSERT_HEAD(&(device->wlan_clients), client, next_client);
	else
		os_free(client);
	SLIST_INSERT_HEAD(&(device->assoc_clients), assoc_client, next_client);
	duplicate_sta_check_for_1905_device(ctx, device);

	if (!cinfo->is_APCLI) {
		client_id = client_mon_handle_local_join(ctx->back_ptr, cinfo->mac,
						cinfo->bssid, 0, 0, 0, 0, 0, 0, 0, NULL
#ifdef MAP_R6
			, PARAM_CLEAR_NO
#endif /* MAP_R6 */
						);
		if (client_id == (uint32_t)-1) {
			debug(DEBUG_CAT_METRIC, "new assoc seen-->But no more room");
			return -1;
		}
	}
	return 0;
}

int insert_new_link_metrics_info(struct _1905_context *_1905_ctrl,struct own_1905_device *ctx, struct sta_link_metrics *metrics_info)
{
#ifdef CENT_STR
	struct _1905_map_device *own_dev = topo_srv_get_1905_device(ctx,NULL);
	int found_sta = 0;
	struct link_metrics *info_to_send = NULL;
#endif
	u8 zero_mac[ETH_ALEN] = {0};

	if (is_1905_present()) {
		struct link_metrics *info = NULL;
		struct associated_clients *metrics_ctx = NULL;
		int i = 0;

		debug(DEBUG_CAT_METRIC, "enter");
#ifdef CENT_STR
		info_to_send = os_zalloc(sizeof(struct link_metrics) * metrics_info->sta_cnt);
		if (info_to_send == NULL)
			return -1;
#endif
		for (i = 0; i < metrics_info->sta_cnt; i++) {
		info = &metrics_info->info[i];
		metrics_ctx = topo_srv_get_associate_client(ctx, NULL, info->mac);
		if (!metrics_ctx) {
			if (os_memcmp(info->mac, zero_mac, ETH) != 0)
				topo_srv_create_new_sta(ctx, info);
			continue;
		}
		metrics_ctx->time_delta = info->time_delta;
		metrics_ctx->erate_downlink = info->erate_downlink;
		metrics_ctx->erate_uplink = info->erate_uplink;
		metrics_ctx->rssi_uplink = info->rssi_uplink;
		info->rssi_uplink = rssi_to_rcpi((signed char)info->rssi_uplink);

		info(DEBUG_CAT_METRIC, "insert struct metrics_db");
		info(DEBUG_CAT_METRIC, "---------->time_delta=%d, erate_downlink=%d erate_uplink=%d rssi_uplink=%d<-----------------",
		     metrics_ctx->time_delta, metrics_ctx->erate_downlink,
			     metrics_ctx->erate_uplink, metrics_ctx->rssi_uplink);

		if ((signed char)metrics_ctx->rssi_uplink == -127) {
			info(DEBUG_CAT_METRIC, "the rssi value of the sta ("MACSTR") is invalid, query it again\n",
				PRINT_MAC(metrics_ctx->client_addr));
			wlanif_issue_wapp_command((struct mapd_global *)ctx->back_ptr, WAPP_USER_GET_ONE_ASSOC_STA_LINK_METRICS,
				WAPP_ONE_ASSOC_STA_LINK_METRICS, NULL, metrics_ctx->client_addr, NULL,
				0, 1, 1, 0);
		}

#ifdef CENT_STR
		if (ctx->cent_str_en && own_dev->device_role == DEVICE_ROLE_CONTROLLER && !metrics_ctx->is_bh_link
#ifdef MTK_MLO_MAP_SUPPORT
			&& !metrics_ctx->is_apcli_link
#endif
			){
			if (link_metrics_mon_rcpi_at_controller(metrics_ctx, ctx)
#ifdef MTK_MLO_MAP_SUPPORT
			|| (ctx->cli_steer_params.force_cli_nol_steer == 1)
#endif
			) {
				/*Get the client db entry for this sta.*/
				struct client *cli = client_db_get_client_from_sta_mac(ctx->back_ptr, metrics_ctx->client_addr);

				info(DEBUG_CAT_METRIC, "insert struct metrics_db is_bh_link %d", metrics_ctx->is_bh_link);
				if (cli && !metrics_ctx->is_bh_link
#ifdef MTK_MLO_MAP_SUPPORT
					&& !metrics_ctx->is_apcli_link
#endif
				) {
					cli->dl_phy_rate = metrics_ctx->erate_downlink;
					cent_str_select_on_demand_str_method(ctx, cli);
#ifdef MTK_MLO_MAP_SUPPORT
					ctx->cli_steer_params.force_cli_nol_steer = 0;
#endif
				}
			}
		} else {
#endif
			if(send_link_metrics_selective(metrics_ctx,ctx)) {
#ifdef CENT_STR
				if (ctx->cent_str_en) {
					os_memcpy(&info_to_send[found_sta], info, sizeof(struct link_metrics));
					found_sta++;
				} else {
#endif
#ifdef MAP_R2
					map_1905_Set_Assoc_Sta_Link_Metric_Rsp_Info(_1905_ctrl, 1,
							info, 0, NULL, NULL, 0, 0);
#else
					map_1905_Set_Assoc_Sta_Link_Metric_Rsp_Info(_1905_ctrl, 1, info, NULL, 0, 0);
#endif
#ifdef CENT_STR
			}
#endif
		}
		}
		}
#ifdef CENT_STR
		if (found_sta && ctx->cent_str_en) {
			debug(DEBUG_CAT_METRIC, CENT_STEER_PREX"Sending STA link metrics rsp");
#ifdef MAP_R2
			map_1905_Set_Assoc_Sta_Link_Metric_Rsp_Info(_1905_ctrl, found_sta,
			info_to_send, 0, NULL, NULL, 0, 0);
#else
			map_1905_Set_Assoc_Sta_Link_Metric_Rsp_Info(_1905_ctrl, found_sta, info_to_send, NULL, 0, 0);
#endif
		}
		os_free(info_to_send);
#endif
	}
	return 0;
}

#ifdef MAP_R2
int insert_new_ext_link_metrics_info(struct own_1905_device *ctx, struct ext_sta_link_metrics *metrics_info)
{
	if (is_1905_present()) {
		//struct link_metrics_db *link_metrics_ctx = NULL;
		struct associated_clients *metrics_ctx = NULL;
		struct ext_link_metrics *info = NULL;
		int i = 0;

		debug(DEBUG_CAT_METRIC, "enter");

		for (i = 0; i < metrics_info->sta_cnt; i++) {
			info = &metrics_info->info[i];
			metrics_ctx = topo_srv_get_associate_client(ctx, NULL, info->mac);
			if (!metrics_ctx) {
				err(DEBUG_CAT_METRIC, "No associated client found");
				return -1;
			}
			metrics_ctx->sta_ext_info.last_data_dl_rate = info->last_data_dl_rate;
			metrics_ctx->sta_ext_info.last_data_ul_rate = info->last_data_ul_rate;
			metrics_ctx->sta_ext_info.utilization_rx = info->utilization_rx;
			metrics_ctx->sta_ext_info.utilization_tx = info->utilization_tx;
			debug(DEBUG_CAT_METRIC, "insert struct link_metrics_db");
			debug(DEBUG_CAT_METRIC, "dl rate: %d, ul rate: %d", metrics_ctx->sta_ext_info.last_data_dl_rate,
			 metrics_ctx->sta_ext_info.last_data_ul_rate);
			debug(DEBUG_CAT_METRIC, "rx rate: %d, tx rate: %d", metrics_ctx->sta_ext_info.utilization_rx,
			 metrics_ctx->sta_ext_info.utilization_tx);

		}
	}
	return 0;
}
#endif


/**
* @brief Fn to delete a ap metrics info
*
* @param ctx own 1905 device ctx
* @param bssid bssid if ap
*
* @return -1 if error else 0
*/
int delete_exist_ap_metrics_info(struct own_1905_device *ctx, unsigned char *bssid)
{
	struct esp_db *esp = NULL, *esp_tmp = NULL;
	struct bss_info_db *bss = topo_srv_get_bss_by_bssid(ctx, NULL, bssid);

	debug(DEBUG_CAT_METRIC, "delete_exist_ap_metrics_info");
	if (!bss) {
		err(DEBUG_CAT_METRIC, "bss not found");
		return -1;
	}
	debug(DEBUG_CAT_METRIC, "esp_cnt=%d", bss->esp_cnt);
	if (!SLIST_EMPTY(&(bss->esp_head))) {
		esp = SLIST_FIRST(&(bss->esp_head));
		while (esp) {
			debug(DEBUG_CAT_METRIC, "delete_exist struct esp_db");
			debug(DEBUG_CAT_METRIC, "ac=%d, format=%d ba_win_size=%d", esp->ac, esp->format, esp->ba_win_size);
			debug(DEBUG_CAT_METRIC, "e_air_time_fraction=%d, ppdu_dur_target=%d",
				esp->e_air_time_fraction, esp->ppdu_dur_target);

			esp_tmp = SLIST_NEXT(esp, esp_entry);
			SLIST_REMOVE(&(bss->esp_head), esp, esp_db, esp_entry);
			os_free(esp);
			esp = esp_tmp;
		}
	}
	debug(DEBUG_CAT_METRIC, "delete_exist struct mrsp_db");
	debug(DEBUG_CAT_METRIC, "bssid("MACSTR")", MAC2STR(bss->bssid));
	debug(DEBUG_CAT_METRIC, "ch_uti=%d, assoc_sta_cnt=%d", bss->ch_util, bss->assoc_sta_cnt);

	return 0;
}

/**
* @brief Fn to delete a traffic stats info
*
* @param ctx own 1905 device ctx
* @param identifier radio identifier
*
* @return 0 if success else -1
*/
int delete_exist_traffic_stats_info(struct own_1905_device *ctx, unsigned char *identifier)
{
	struct traffic_stats_db *traffic_stats = NULL, *t_traffic_stats = NULL;
	struct stats_db *stats = NULL, *stats_tmp = NULL;

	debug(DEBUG_CAT_METRIC, "delete_exist_traffic_stats_info");

	SLIST_FOREACH_SAFE(traffic_stats, &ctx->metric_entry.traffic_stats_head, traffic_stats_entry, t_traffic_stats) {
		if (!memcmp(traffic_stats->identifier, identifier, ETH_ALEN)) {
			debug(DEBUG_CAT_METRIC, "sta_cnt=%d", traffic_stats->sta_cnt);

			stats = SLIST_FIRST(&traffic_stats->stats_head);
			while (stats) {
				debug(DEBUG_CAT_METRIC, "delete_exist struct stats_db");
				debug(DEBUG_CAT_METRIC, "sta mac("MACSTR")", MAC2STR(stats->mac));
				debug(DEBUG_CAT_METRIC, "bytes_sent=%d, bytes_received=%d"
					     "packets_sent=%d, packets_received=%d"
					     "tx_packets_errors=%d, rx_packets_errors=%d"
					     "retransmission_count=%d",
					     stats->bytes_sent,
					     stats->bytes_received,
					     stats->packets_sent,
					     stats->packets_received,
					     stats->tx_packets_errors,
					     stats->rx_packets_errors, stats->retransmission_count);

				stats_tmp = SLIST_NEXT(stats, stats_entry);
				SLIST_REMOVE(&traffic_stats->stats_head, stats, stats_db, stats_entry);
				free(stats);
				stats = stats_tmp;
			}

			debug(DEBUG_CAT_METRIC, "delete_exist struct traffic_stats_db");
			debug(DEBUG_CAT_METRIC,
			 "identifier("MACSTR")", MAC2STR(traffic_stats->identifier));
			SLIST_REMOVE(&ctx->metric_entry.traffic_stats_head,
				     traffic_stats, traffic_stats_db, traffic_stats_entry);
			free(traffic_stats);
			break;
		}
	}

	return 0;
}
#ifdef MAP_R6
/**
* @brief Fn to delete a traffic mld stats info
*
* @param ctx own 1905 device ctx
* @param identifier radio identifier
*
* @return 0 if success else -1
*/
int delete_exist_traffic_mld_stats_info(struct own_1905_device *ctx, unsigned char *identifier)
{
	struct mld_traffic_stats_db *traffic_stats = NULL, *t_traffic_stats = NULL;
	struct mld_stats_db *stats = NULL, *stats_tmp = NULL;

	debug(DEBUG_CAT_METRIC, "delete_exist_traffic_stats_info");

	SLIST_FOREACH_SAFE(traffic_stats, &ctx->metric_entry.mld_traffic_stats_head, mld_traffic_stats_entry, t_traffic_stats) {
		if (!memcmp(traffic_stats->identifier, identifier, ETH_ALEN)) {
			debug(DEBUG_CAT_METRIC, "sta_cnt=%d", traffic_stats->sta_cnt);

			stats = SLIST_FIRST(&traffic_stats->mld_stats_head);
			while (stats) {
				debug(DEBUG_CAT_METRIC, "delete_exist struct stats_db");
				debug(DEBUG_CAT_METRIC, "sta mac("MACSTR")", MAC2STR(stats->mac));
				stats_tmp = SLIST_NEXT(stats, stats_entry);
				SLIST_REMOVE(&traffic_stats->mld_stats_head, stats, mld_stats_db, stats_entry);
				free(stats);
				stats = stats_tmp;
			}

			debug(DEBUG_CAT_METRIC, "delete_exist struct traffic_stats_db");
			debug(DEBUG_CAT_METRIC,
			 "identifier("MACSTR")", MAC2STR(traffic_stats->identifier));
			SLIST_REMOVE(&ctx->metric_entry.mld_traffic_stats_head,
				     traffic_stats, mld_traffic_stats_db, mld_traffic_stats_entry);
			free(traffic_stats);
			break;
		}
	}

	return 0;
}
#endif
/**
* @brief Fn to add new traffic stats
*
* @param ctx own 1905 device ctx
* @param traffic_stats sta_traffic_stats to be added
*
* @return 0 if success else -1
*/
int insert_new_traffic_stats_info(struct own_1905_device *ctx, struct sta_traffic_stats *traffic_stats)
{
	struct traffic_stats_db *tstats = NULL;
	struct stats_db *stats = NULL;
	struct stat_info *info = NULL;
	int i = 0;
	struct _1905_map_device *own_dev = NULL;

	debug(DEBUG_CAT_METRIC, "enter");
	tstats = (struct traffic_stats_db *)os_zalloc(sizeof(struct traffic_stats_db));
	if (!tstats) {
		err(DEBUG_CAT_METRIC, "alloc struct traffic_stats_db fail");
		return -1;
	}
	memset(tstats, 0, sizeof(struct traffic_stats_db));
	memcpy(tstats->identifier, traffic_stats->identifier, ETH_ALEN);
	tstats->sta_cnt = traffic_stats->sta_cnt;
	SLIST_INIT(&tstats->stats_head);
	SLIST_INSERT_HEAD(&(ctx->metric_entry.traffic_stats_head), tstats, traffic_stats_entry);

	debug(DEBUG_CAT_METRIC, "insert struct traffic_stats_db");
	debug(DEBUG_CAT_METRIC, "identifier("MACSTR")", MAC2STR(tstats->identifier));
	debug(DEBUG_CAT_METRIC, "sta_cnt=%d", tstats->sta_cnt);

	for (i = 0; i < traffic_stats->sta_cnt; i++) {
		info = &traffic_stats->stats[i];
		stats = (struct stats_db *)os_zalloc(sizeof(struct stats_db));
		if (!stats) {
			err(DEBUG_CAT_METRIC, "alloc struct stats_db fail");
			return -1;
		}
		os_memcpy(stats->mac, info->mac, ETH_ALEN);
		stats->bytes_sent = info->bytes_sent;
		stats->bytes_received = info->bytes_received;
		stats->packets_sent = info->packets_sent;
		stats->packets_received = info->packets_received;
		stats->tx_packets_errors = info->tx_packets_errors;
		stats->rx_packets_errors = info->rx_packets_errors;
		stats->retransmission_count = info->retransmission_count;
		os_memcpy(stats->sta_mld_mac, info->sta_mld_mac, ETH_ALEN);
		SLIST_INSERT_HEAD(&tstats->stats_head, stats, stats_entry);

		debug(DEBUG_CAT_METRIC, "insert struct stats_db");
		debug(DEBUG_CAT_METRIC, "sta mac("MACSTR")", MAC2STR(stats->mac));
		debug(DEBUG_CAT_METRIC, "sta sta_mld_mac("MACSTR")", MAC2STR(stats->sta_mld_mac));
		debug(DEBUG_CAT_METRIC, "bytes_sent=%d, bytes_received=%d packets_sent=%d"
			     "packets_received=%d, tx_packets_errors=%d rx_packets_errors=%d"
			     "retransmission_count=%d",
			     stats->bytes_sent, stats->bytes_received,
			     stats->packets_sent, stats->packets_received,
			     stats->tx_packets_errors, stats->rx_packets_errors, stats->retransmission_count);
		own_dev = topo_srv_get_1905_device(ctx, NULL);
		if (own_dev && own_dev->in_network)
			insert_new_traffic_stats_tlv(ctx, info, own_dev);
	}

	return 0;

}
/**
* @brief Fn to add new mld traffic stats
*
* @param ctx own 1905 device ctx
* @param traffic_stats sta_mld_traffic_stats to be added
*
* @return 0 if success else -1
*/
#ifdef MAP_R6
int insert_new_mld_traffic_stats_info(struct own_1905_device *ctx, struct sta_mld_traffic_stats *traffic_stats)
{
	struct mld_traffic_stats_db *tstats = NULL;
	struct mld_stats_db *stats = NULL;
	struct stat_mld_info *info = NULL;
	int i = 0;
	struct _1905_map_device *own_dev = NULL;

	debug(DEBUG_CAT_METRIC, "enter");
	tstats = (struct mld_traffic_stats_db *)os_zalloc(sizeof(struct mld_traffic_stats_db));
	if (!tstats) {
		err(DEBUG_CAT_METRIC, "alloc struct mld traffic_stats_db fail");
		return -1;
	}
	memcpy(tstats->identifier, traffic_stats->identifier, ETH_ALEN);
	tstats->sta_cnt = traffic_stats->sta_cnt;
	SLIST_INIT(&tstats->mld_stats_head);
	SLIST_INSERT_HEAD(&(ctx->metric_entry.mld_traffic_stats_head), tstats, mld_traffic_stats_entry);

	debug(DEBUG_CAT_METRIC, "insert struct traffic_stats_db");
	debug(DEBUG_CAT_METRIC, "identifier("MACSTR")", MAC2STR(tstats->identifier));
	debug(DEBUG_CAT_METRIC, "sta_cnt=%d", tstats->sta_cnt);

	for (i = 0; i < traffic_stats->sta_cnt; i++) {
		info = &traffic_stats->stats[i];
		stats = (struct mld_stats_db *)os_zalloc(sizeof(struct mld_stats_db));
		if (!stats) {
			err(DEBUG_CAT_METRIC, "alloc struct stats_db fail");
			return -1;
		}
		memcpy(stats->mac, info->mac, ETH_ALEN);
		stats->bytes_sent = info->bytes_sent;
		stats->bytes_received = info->bytes_received;
		stats->packets_sent = info->packets_sent;
		stats->packets_received = info->packets_received;
		stats->tx_packets_errors = info->tx_packets_errors;
		SLIST_INSERT_HEAD(&tstats->mld_stats_head, stats, stats_entry);

		debug(DEBUG_CAT_METRIC, "insert struct stats_db");
		debug(DEBUG_CAT_METRIC, "sta mac("MACSTR")", MAC2STR(stats->mac));
		debug(DEBUG_CAT_METRIC, "bytes_sent=%d, bytes_received=%d packets_sent=%d packets_received=%d, tx_packets_errors=%d",
			stats->bytes_sent, stats->bytes_received,
			stats->packets_sent, stats->packets_received,
			stats->tx_packets_errors);
		own_dev = topo_srv_get_1905_device(ctx, NULL);
		if (own_dev && own_dev->in_network)
			insert_new_mld_traffic_stats_tlv(ctx, info, own_dev);
	}

	return 0;
}
#endif

#ifdef MAP_R3_WF6
/**
 * @brief Fn to delete a traffic stats info
 *
 * @param ctx own 1905 device ctx
 * @param identifier radio identifier
 *
 * @return 0 if success else -1
 */
int delete_exist_assoc_wifi6_sta_status(struct own_1905_device *ctx, unsigned char *identifier)
{
	struct assoc_wf6_sta_status_db *assoc_wf6_sta_status = NULL, *t_assoc_wf6_status = NULL;
	struct assoc_wf6_sta_db *assoc_wf6_sta = NULL, *assoc_wf6_sta_tmp = NULL;

	debug(DEBUG_CAT_METRIC, "delete_exist_assoc_wifi6_sta_status");

	SLIST_FOREACH_SAFE(assoc_wf6_sta_status, &ctx->metric_entry.assoc_wf6_sta_status_db_head, assoc_wf6_sta_status_entry, t_assoc_wf6_status) {
		if (!memcmp(assoc_wf6_sta_status->identifier, identifier, ETH_ALEN)) {
			debug(DEBUG_CAT_METRIC, "sta_cnt=%d", assoc_wf6_sta_status->sta_cnt);

			assoc_wf6_sta = SLIST_FIRST(&assoc_wf6_sta_status->assoc_wf6_sta_db_head);
			while (assoc_wf6_sta) {
				debug(DEBUG_CAT_METRIC, "delete_exist struct assoc_wf6_sta_db");
				debug(DEBUG_CAT_METRIC, "sta mac(%02x:%02x:%02x:%02x:%02x:%02x)", PRINT_MAC(assoc_wf6_sta->mac));
				assoc_wf6_sta_tmp = SLIST_NEXT(assoc_wf6_sta, assoc_wf6_sta_entry);
				SLIST_REMOVE(&assoc_wf6_sta_status->assoc_wf6_sta_db_head, assoc_wf6_sta, assoc_wf6_sta_db, assoc_wf6_sta_entry);
				free(assoc_wf6_sta);
				assoc_wf6_sta = assoc_wf6_sta_tmp;
			}

			debug(DEBUG_CAT_METRIC, "delete_exist struct assoc_wf6_sta_status_db");
			debug(DEBUG_CAT_METRIC, "identifier(%02x:%02x:%02x:%02x:%02x:%02x)", PRINT_MAC(assoc_wf6_sta_status->identifier));
			SLIST_REMOVE(&ctx->metric_entry.assoc_wf6_sta_status_db_head,
					assoc_wf6_sta_status, assoc_wf6_sta_status_db, assoc_wf6_sta_status_entry);
			free(assoc_wf6_sta_status);
			break;
		}
	}

	return 0;
}

/**
 * @brief Fn to add new traffic stats
 *
 * @param ctx own 1905 device ctx
 * @param traffic_stats sta_traffic_stats to be added
 *
 * @return 0 if success else -1
 */
int insert_new_assoc_wifi6_sta_status(struct own_1905_device *ctx, struct assoc_wifi6_sta_status *wf6_sta_status)
{
	/* TODO: ADD code for Associated WiFi6 Status report tlv*/
	/* DB NODE creation is done. */
	/* Need to fill the values from WAPP and driver. */
	struct assoc_wf6_sta_status_db *assoc_wf6_sta_status = NULL;
	struct assoc_wf6_sta_db *assoc_wf6_sta = NULL;
	struct assoc_wifi6_sta_status_tlv *info = NULL;
	int i = 0, j = 0;

	debug(DEBUG_CAT_METRIC, "enter into function\n");

	assoc_wf6_sta_status = (struct assoc_wf6_sta_status_db *)os_zalloc(sizeof(struct assoc_wf6_sta_status_db));
	if (!assoc_wf6_sta_status) {
		err(DEBUG_CAT_METRIC, "alloc struct assoc_wf6_sta_status_db fail");
		return -1;
	}

	memset(assoc_wf6_sta_status, 0, sizeof(struct assoc_wf6_sta_status_db));
	memcpy(assoc_wf6_sta_status->identifier, wf6_sta_status->identifier, ETH_ALEN);

	assoc_wf6_sta_status->sta_cnt = wf6_sta_status->sta_cnt;
	SLIST_INIT(&assoc_wf6_sta_status->assoc_wf6_sta_db_head);
	SLIST_INSERT_HEAD(&(ctx->metric_entry.assoc_wf6_sta_status_db_head), assoc_wf6_sta_status, assoc_wf6_sta_status_entry);

	debug(DEBUG_CAT_METRIC, "insert struct assoc_wf6_sta_status_db");
	debug(DEBUG_CAT_METRIC, "identifier(%02x:%02x:%02x:%02x:%02x:%02x)", PRINT_MAC(assoc_wf6_sta_status->identifier));
	debug(DEBUG_CAT_METRIC, "sta_cnt=%d", assoc_wf6_sta_status->sta_cnt);

        for (i = 0; i < wf6_sta_status->sta_cnt; i++) {
			info = &wf6_sta_status->status[i];
			assoc_wf6_sta = (struct assoc_wf6_sta_db *)os_zalloc(sizeof(struct assoc_wf6_sta_db));

			if (!assoc_wf6_sta) {
				err(DEBUG_CAT_METRIC, "alloc struct assoc_wf6_sta_db fail");
				return -1;
			}
			memcpy(assoc_wf6_sta->mac, info->mac, ETH_ALEN);
		assoc_wf6_sta->tid_cnt = info->tid_cnt;

		for (j = 0; j < MAX_TID; j++) {
			assoc_wf6_sta->status_tlv[j].tid = info->status_tlv[j].tid;
			assoc_wf6_sta->status_tlv[j].tid_q_size = info->status_tlv[j].tid_q_size;
		}

		SLIST_INSERT_HEAD(&assoc_wf6_sta_status->assoc_wf6_sta_db_head, assoc_wf6_sta, assoc_wf6_sta_entry);

		debug(DEBUG_CAT_METRIC, "insert struct assoc_wf6_sta_db");
		debug(DEBUG_CAT_METRIC, "sta mac(%02x:%02x:%02x:%02x:%02x:%02x)", PRINT_MAC(assoc_wf6_sta->mac));
	}

	return 0;

}
#endif

/**
* @brief Fn to parse link metrics response
*
* @param dev _1905_map_device pointer
* @param buf msg buffer
*
* @return -1 if error else 0
*/
int parse_link_metrics_response_message(struct _1905_map_device *dev, unsigned char *buf, int len)
{
	int length = 0;
	unsigned char *temp_buf;
	unsigned short check_len = 0;
	unsigned short tlv_len = 0;

	temp_buf = buf;
	while (1) {
		check_len = get_tlv_len(temp_buf);
		tlv_len = check_len + 3;

		if (len < tlv_len) {
			err(DEBUG_CAT_METRIC, "Error TLV len, type = %d, len %d less than tlv_len %d\n",
					*temp_buf, len, tlv_len);
			return -1;
		}

		if (*temp_buf == TRANSMITTER_LINK_METRIC_TYPE) {
			length = parse_tx_link_metrics_tlv(temp_buf, dev);
			if (length < 0) {
				err(DEBUG_CAT_METRIC, "error tx link metrics tlv");
				return -1;
			}
			temp_buf += length;
		} else if (*temp_buf == RECEIVER_LINK_METRIC_TYPE) {
			length = parse_rx_link_metrics_tlv(temp_buf, dev);
			if (length < 0) {
				err(DEBUG_CAT_METRIC, "error rx link metrics tlv");
				return -1;
			}
			temp_buf += length;
		} else if (*temp_buf == END_OF_TLV_TYPE) {
			break;
		} else {
			length = get_cmdu_tlv_length(temp_buf);
			temp_buf += length;
		}
		len -= tlv_len;
	}

	return 0;
}

/* handle link metric report msgs */
int topo_srv_update_link_metric_report(struct _1905_map_device *_1905_device, char *msg)
{
	return 0;
}

/* handle ap metric msgs */
int topo_srv_update_ap_metric(struct _1905_map_device *_1905_device, char *msg)
{
	return 0;
}

int validate_unassociated_sta_link_metrics_query_message(unsigned char *buf)
{
	unsigned char *temp_buf;
	unsigned short length = 0;
	unsigned short left_tlv_len = 0;
	unsigned char num_ch = 0;
	unsigned char num_sta = 0;
	int i = 0;

	temp_buf = buf;

	if ((*temp_buf) == UNASSOC_STA_LINK_METRICS_QUERY_TYPE)
		temp_buf++;
	else {
		err(DEBUG_CAT_METRIC, "should not go here");
		return -1;
	}

	/*calculate tlv length*/
	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length | (*(temp_buf + 1));

	left_tlv_len = length;

	/*shift to tlv value field*/
	temp_buf += 2;

	if (left_tlv_len < 2) {
		err(DEBUG_CAT_METRIC, "error in length");
		return -1;
	}

	temp_buf++;

	num_ch = *temp_buf++;

	left_tlv_len -= 2;

	for (i = 0; i < num_ch; i++) {
		if (left_tlv_len < 2) {
			err(DEBUG_CAT_METRIC, "error in length");
			return -1;
		}

		temp_buf++;
		num_sta = *temp_buf++;

		left_tlv_len -= 2;

		if (left_tlv_len < (num_sta * ETH_ALEN)) {
			err(DEBUG_CAT_METRIC, "error in length");
			return -1;
		}
		left_tlv_len -= (num_sta * ETH_ALEN);
	}
	return 0;
}

/**
* @brief Fn to parse unass sta link query msg
*
* @param ctx own 1905 device ctx
* @param buf msg buffer
*
* @return -1 if error else 0
*/
int parse_unassociated_sta_link_metrics_query_message(struct own_1905_device
						      *ctx, unsigned char *buf, struct unlink_metrics_query *unlink_query,
							unsigned short len)
{
	int length = 0;
	unsigned char *temp_buf;
	unsigned char integrity = 0;
	unsigned short check_tlv = 0;
	unsigned short tlv_len = 0;


	temp_buf = buf;

	while (1) {
		check_tlv = get_tlv_len(temp_buf);
		tlv_len = check_tlv + 3;

		if (len < tlv_len) {
			err(DEBUG_CAT_METRIC, "Error TLV len, type = %d, len %d less than tlv_len %d\n",
					*temp_buf, len, tlv_len);
			return -1;
		}

		if (*temp_buf == UNASSOC_STA_LINK_METRICS_QUERY_TYPE) {
			integrity |= 0x1;
			length = validate_unassociated_sta_link_metrics_query_message(temp_buf);

			if (length < 0) {
				err(DEBUG_CAT_METRIC, "error validated sta link metrics query tlv");
				return -1;
			}

			length =
			    parse_unassociated_sta_link_metrics_query_tlv(temp_buf, unlink_query);
			if (length < 0) {
				err(DEBUG_CAT_METRIC, "error unassociated sta link metrics query tlv");
				return -1;
			}
			temp_buf += length;
		} else if (*temp_buf == END_OF_TLV_TYPE) {
			break;
		} else {
			length = get_cmdu_tlv_length(temp_buf);
			temp_buf += length;
		}
		len -= tlv_len;
	}
	/*check integrity */
	if (integrity != 0x1) {
		err(DEBUG_CAT_METRIC, "no unassicated sta link metrics query tlv");
		return -1;
	}
	debug(DEBUG_CAT_METRIC, "exit");

	return 0;
}

/**
* @brief Fn to handle usassoc link metrics query msg from 1905
*
* @param ctx own 1905 device
* @param buf msg buffer
*
* @return -1 if error else 0
*/
int topo_srv_handle_unassoc_sta_link_metrics_query(struct own_1905_device *ctx, unsigned char *buf, unsigned short len)
{
	int len_data = 0;
	struct mapd_global *global = (struct mapd_global *)ctx->back_ptr;
	u8 *unlink_query[150];
	struct unlink_metrics_query *p_unlink_query = (struct unlink_metrics_query *)unlink_query;
	debug(DEBUG_CAT_METRIC, "got UNASSOC_STA_LINK_METRICS_QUERY");
	debug_hexdump(DEBUG_CAT_METRIC, "UNASSOC_STA_LINK_METRICS_QUERY", (buf - ETH_ALEN), len_data);

	/*parse AP_LINK_METRICS_QUERY msg */
	/*TODO hanlde unlink Query Properly in case of multiple STA Query
		Handle 7621 Stack corruption issue due to the unlink_query present in ctx*/
	if (parse_unassociated_sta_link_metrics_query_message(ctx, buf, p_unlink_query, len) < 0) {
		err(DEBUG_CAT_METRIC, "error! no need to response this unassociated sta link metrics query message");
		goto error_exit;
	} else {
		/* Add check to avoid air monitor for connected STA */
		Boolean drop_req = FALSE;
		int i = 0;
		unsigned char *mac = NULL;
		struct _1905_map_device *dev = topo_srv_get_1905_device(ctx, NULL);
		struct associated_clients *client = NULL, *tmp_client = NULL;
		struct bh_link_entry *bh_entry = NULL, *tmp_bh_entry = NULL;

		mac = p_unlink_query->sta_list;
		for (i = 0; i < p_unlink_query->sta_num; i++) {
			mac += ETH_ALEN*i;
			SLIST_FOREACH_SAFE(client, &dev->assoc_clients, next_client, tmp_client) {
				if (os_memcmp(client->client_addr, mac, ETH_ALEN) == 0) {
					err(DEBUG_CAT_METRIC, "Unassoc metric query for connected STA, drop request");
					err(DEBUG_CAT_METRIC, "STA["MACSTR"] is coneected to BSS:"MACSTR, MAC2STR(mac),
					 MAC2STR(client->bss->bssid));
					drop_req = TRUE;
					break;
				}
			}

			/* also check apcli entry not match */
			SLIST_FOREACH_SAFE(bh_entry, &(ctx->bh_link_head), next_bh_link, tmp_bh_entry) {
				if ((os_memcmp(mac, bh_entry->mac_addr, ETH_ALEN) == 0) ||
					((bh_entry->bh_assoc_state == WAPP_APCLI_ASSOCIATED) &&
					(os_memcmp(mac, bh_entry->bssid, ETH_ALEN) == 0))) {
					drop_req = TRUE;
					break;
				}
			}
		}

		/* dump unassoc link query */
		info(DEBUG_CAT_METRIC, "operating class:%d", p_unlink_query->oper_class);
		info(DEBUG_CAT_METRIC, "channel List[%d]:", p_unlink_query->ch_num);
		for (i = 0; i < p_unlink_query->ch_num; i++)
			info(DEBUG_CAT_METRIC, "CH[%d]:%d", i, p_unlink_query->ch_list[i]);
		info(DEBUG_CAT_METRIC, "STA List[%d]", p_unlink_query->sta_num);
		mac = p_unlink_query->sta_list;
		for (i = 0; i < p_unlink_query->sta_num; i++) {
			mac += ETH_ALEN*i;
			info(DEBUG_CAT_METRIC, "STA[%d]:"MACSTR, i, MAC2STR(mac));
		}
		if (drop_req) {
			err(DEBUG_CAT_METRIC, "unassoc_sta_link_metrics_query dropped");
			goto error_exit;
		}
	}

	/*query ap metrics response info from wapp */
	len_data = sizeof(struct unlink_metrics_query) + ((p_unlink_query->sta_num) * ETH_ALEN);
	if(global->params.Certification){
	if (0 >
	    map_get_info_from_wapp(ctx,
				   WAPP_USER_GET_UNASSOC_STA_LINK_METRICS,
				   WAPP_UNASSOC_STA_LINK_METRICS, NULL, NULL,
				   (void *)p_unlink_query, len_data)) {
		err(DEBUG_CAT_METRIC, "error! wapp_get_unassoc_sta_link_metrics");
		goto error_exit;
		}
	} else {
		if (0 >
		    map_get_info_from_wapp(ctx,
						WAPP_USER_SET_AIR_MONITOR_REQUEST,
						0, NULL, NULL,
						(void *)unlink_query, len_data)) {
			err(DEBUG_CAT_METRIC, "error! wapp_get_unassoc_sta_link_metrics");
			goto error_exit;
		}
	}
	//os_free(ctx->metric_entry.unlink_query);

	//ctx->metric_entry.unlink_query = NULL;
	return 0;

error_exit:
	map_1905_Set_Unassoc_Sta_Link_Metric_Rsp_Info(global->_1905_ctrl, NULL);
	return -1;
}

/**
* @brief Fn to parse beacon metrics query msg
*
* @param ctx own 1905 device ctx
* @param buf msg buffer
*
* @return -1 if error else 0
*/
int parse_beacon_metrics_query_message(struct own_1905_device *ctx, unsigned char *buf)
{
	int length = 0;
	unsigned char *temp_buf;
	unsigned char integrity = 0;

	temp_buf = buf;

	while (1) {
		if (*temp_buf == BEACON_METRICS_QUERY_TYPE) {
			integrity |= 0x1;
			length = parse_beacon_metrics_query_tlv(temp_buf, &ctx->metric_entry.bcn_query);
			if (length < 0) {
				err(DEBUG_CAT_METRIC, "error beacon metrics query tlv");
				return -1;
			}
			temp_buf += length;
		} else if (*temp_buf == END_OF_TLV_TYPE) {
			break;
		} else {
			length = get_cmdu_tlv_length(temp_buf);
			temp_buf += length;
		}
	}
	/*check integrity */
	if (integrity != 0x1) {
		err(DEBUG_CAT_METRIC, "no beacon metrics query tlv");
		return -1;
	}
	debug(DEBUG_CAT_METRIC, "exit");

	return 0;
}

struct client *get_client_from_sta_mac(struct own_1905_device *ctx, unsigned char *sta_mac)
{
	uint32_t idx = 0;

	for (idx = 0; idx < MAX_STA_SEEN; idx++) {
		if (!os_memcmp(ctx->client_db[idx].mac_addr, sta_mac, ETH_ALEN))
			return &ctx->client_db[idx];
	}

	return NULL;
}

#ifdef EM_PLUS_SUPPORT
void handle_beacon_query_mutil_info(struct mapd_global *global, unsigned char *cli_mac)
{
	struct client *cli = NULL;
	int datalen = 0, status;
	unsigned char assoc_bssid[ETH_ALEN] = {0};
	struct beacon_metrics_query *config_bcn_query = NULL;
	struct ap_chn_rpt *rpt = NULL;
	struct own_1905_device *ctx = NULL;

	if (!global || global->params.Certification || !cli_mac) {
		err(DEBUG_CAT_METRIC, "invalid input parameters");
		return;
	}

	ctx = &global->dev;
	if (!ctx) {
		err(DEBUG_CAT_METRIC, "invalid ctx");
		return;
	}

	cli = get_client_from_sta_mac(ctx, cli_mac);
	if (!cli) {
		err(DEBUG_CAT_METRIC, STEER_PREX" cli:" MACSTR " not in DB", MAC2STR(cli_mac));
		return;
	}

	if (!cli->bcn_query) {
		err(DEBUG_CAT_METRIC, STEER_PREX" cli:" MACSTR " bcn query is null", MAC2STR(cli_mac));
		return;
	}

	if (cli->bcn_query->ap_ch_rpt_num == 1) {
		err(DEBUG_CAT_METRIC, STEER_PREX" cli:" MACSTR " bcn query num is 1", MAC2STR(cli_mac));
		return;
	}

	if (cli->bcn_query_idx == cli->bcn_query->ap_ch_rpt_num) {
		err(DEBUG_CAT_METRIC, STEER_PREX" cli:" MACSTR " bcn query is done(total num:%d)", MAC2STR(cli_mac), cli->bcn_query_idx);
		free(cli->bcn_query);
		cli->bcn_query = NULL;
		cli->bcn_query_idx = 0;
		return;
	}

	datalen = sizeof(struct beacon_metrics_query) + sizeof(struct ap_chn_rpt);
	config_bcn_query = os_malloc(datalen);
	if (!config_bcn_query) {
		err(DEBUG_CAT_METRIC, "alloc memory(%d) fail", datalen);
		os_free(cli->bcn_query);
		cli->bcn_query = NULL;
		cli->bcn_query_idx = 0;
		return;
	}

	os_memcpy(config_bcn_query, cli->bcn_query, sizeof(struct beacon_metrics_query));
	if ((cli->bcn_query->ch == 255) && cli->bcn_query->ap_ch_rpt_num) {
		rpt = &cli->bcn_query->rpt[cli->bcn_query_idx];
		os_memcpy(&config_bcn_query->rpt[0], rpt, sizeof(struct ap_chn_rpt));
		config_bcn_query->ap_ch_rpt_num = 1;
		err(DEBUG_CAT_METRIC, STEER_PREX"11 cli:" MACSTR " bcn query ap report config[idx:%d] ch[0]:%d, opclass:%d",
			MAC2STR(cli_mac), cli->bcn_query_idx, rpt->ch_list[0], rpt->oper_class);
	}

	cli->bcn_query_idx++;

	status = topo_srv_get_bssid_of_sta(ctx, config_bcn_query, assoc_bssid);
	if (status == 0)
		map_get_info_from_wapp(ctx, WAPP_USER_SET_BEACON_METRICS_QRY,
				   0, assoc_bssid, NULL, (void *)config_bcn_query, datalen);
	else
		map_get_info_from_wapp(ctx, WAPP_USER_SET_BEACON_METRICS_QRY,
				   0, NULL, NULL, (void *)config_bcn_query, datalen);

	if (cli->bcn_query_idx == cli->bcn_query->ap_ch_rpt_num) {
		err(DEBUG_CAT_METRIC, STEER_PREX" cli:" MACSTR " bcn query is done (total num:%d)", MAC2STR(cli_mac), cli->bcn_query_idx);
		free(cli->bcn_query);
		cli->bcn_query = NULL;
		cli->bcn_query_idx = 0;
	}

	free(config_bcn_query);
}

void beacon_query_mutil_timeout(void *eloop_ctx, void *timeout_ctx)
{
	struct mapd_global *global = (struct mapd_global *)eloop_ctx;
	struct client *cli = NULL;

	if (!timeout_ctx || !eloop_ctx || global->params.Certification)
		return;

	err(DEBUG_CAT_METRIC, "timeout!\n");
	cli = client_db_get_client_from_sta_mac(global, (unsigned char *)timeout_ctx);
	if (global && cli) {
		info(DEBUG_CAT_METRIC, "handle_beacon_query_mutil_info!\n");
		handle_beacon_query_mutil_info(global, timeout_ctx);
		if (cli->bcn_query)
			eloop_register_timeout(1, 0, beacon_query_mutil_timeout, global, cli->mac_addr);
	}

}

void beacon_query_mutil_info(struct own_1905_device *ctx, struct beacon_metrics_query *bcn_query)
{
	struct client *cli = NULL;
	int datalen = 0, status;
	unsigned char assoc_bssid[ETH_ALEN] = {0};
	struct beacon_metrics_query *total_bcn_query = NULL, *config_bcn_query = NULL;
	uint32_t client_id = 0;
	u8 already_seen = 0;

	if (!ctx || !bcn_query) {
		err(DEBUG_CAT_METRIC, "invalid input parameters");
		return;
	}

	if ((bcn_query->ch != 255) || !bcn_query->ap_ch_rpt_num) {
		err(DEBUG_CAT_METRIC, "no ap ch report tlv(ch:%d, ap_ch_rpt_num:%d), return directly",
		 bcn_query->ch, bcn_query->ap_ch_rpt_num);
		return;
	}

	cli = get_client_from_sta_mac(ctx, bcn_query->sta_mac);
	if (!cli) {
		info(DEBUG_CAT_METRIC, STEER_PREX"cli:" MACSTR " not in DB, add to cli DB\n",
			MAC2STR(bcn_query->sta_mac));

		client_id = client_db_track_add(ctx->back_ptr, bcn_query->sta_mac, &already_seen);
		if (client_id == (uint32_t)-1) {
			err(DEBUG_CAT_METRIC, "No more room to accommodate" MACSTR "\n", MAC2STR(bcn_query->sta_mac));
			return;
		}
		cli = get_client_from_sta_mac(ctx, bcn_query->sta_mac);
		if (!cli) {
			err(DEBUG_CAT_METRIC, STEER_PREX" cli:" MACSTR " not in DB\n", MAC2STR(bcn_query->sta_mac));
			return;
		}
	}

	if (cli->bcn_query) {
		err(DEBUG_CAT_METRIC, STEER_PREX" cli:" MACSTR " bcn query is ongoing\n", MAC2STR(bcn_query->sta_mac));
		return;
	}

	/*query ap metrics response info from wapp */
	datalen = sizeof(struct beacon_metrics_query) +
	    ctx->metric_entry.bcn_query->ap_ch_rpt_num * sizeof(struct ap_chn_rpt);
	total_bcn_query = os_malloc(datalen);
	if (!total_bcn_query) {
		err(DEBUG_CAT_METRIC, "alloc memory(%d) fail", datalen);
		return;
	}

	os_memcpy(total_bcn_query, bcn_query, datalen);
	cli->bcn_query = total_bcn_query;
	cli->bcn_query_idx = 1;

	datalen = sizeof(struct beacon_metrics_query) + sizeof(struct ap_chn_rpt);
	config_bcn_query = os_malloc(datalen);
	if (!config_bcn_query) {
		err(DEBUG_CAT_METRIC, "alloc memory(%d) fail", datalen);
		os_free(cli->bcn_query);
		cli->bcn_query = NULL;
		cli->bcn_query_idx = 0;
		return;
	}

	os_memcpy(config_bcn_query, bcn_query, sizeof(struct beacon_metrics_query));
	if ((bcn_query->ch == 255) && bcn_query->ap_ch_rpt_num) {
		os_memcpy(&config_bcn_query->rpt[0], &bcn_query->rpt[0], sizeof(struct ap_chn_rpt));
		config_bcn_query->ap_ch_rpt_num = 1;
		err(DEBUG_CAT_METRIC, STEER_PREX" cli:" MACSTR " bcn query ap report config, ch[0]:%d, opclass:%d",
			MAC2STR(bcn_query->sta_mac), config_bcn_query->rpt[0].ch_list[0], config_bcn_query->rpt[0].oper_class);
	}

	status = topo_srv_get_bssid_of_sta(ctx, ctx->metric_entry.bcn_query, assoc_bssid);

	if (status == 0)
		map_get_info_from_wapp(ctx, WAPP_USER_SET_BEACON_METRICS_QRY,
				   0, assoc_bssid, NULL, (void *)config_bcn_query, datalen);
	else
		map_get_info_from_wapp(ctx, WAPP_USER_SET_BEACON_METRICS_QRY,
				   0, NULL, NULL, (void *)config_bcn_query, datalen);
	free(config_bcn_query);
	eloop_register_timeout(1, 0, beacon_query_mutil_timeout, ctx->back_ptr, cli->mac_addr);
}
#endif

/**
* @brief Fn to handle beacon metrics query from 1905 and send it to wapp for query
*
* @param ctx own 1905 device ctx
* @param temp_buf msg buffer
*
* @return -1 if error else 0
*/
int topo_srv_handle_beacon_metrics_query(struct own_1905_device *ctx, unsigned char *temp_buf)
{
	int datalen = 0, status;
	unsigned char assoc_bssid[ETH_ALEN] = {0};
#ifdef MTK_MLO_MAP_SUPPORT
	struct client *temp_cli, *temp_main_cli;
#endif
#ifdef EM_PLUS_SUPPORT
	struct mapd_global *global = NULL;
#endif

	debug(DEBUG_CAT_METRIC, "got BEACON_METRICS_QUERY");

	if (!ctx || !ctx->back_ptr || !temp_buf) {
		err(DEBUG_CAT_METRIC, "error! input param is null");
		return -1;
	}

	/*parse AP_LINK_METRICS_QUERY msg */
	if (0 > parse_beacon_metrics_query_message(ctx, temp_buf)) {
		err(DEBUG_CAT_METRIC, "error! no need to response this beacon metrics query message");
		return -1;
	}
#ifdef EM_PLUS_SUPPORT
	global = ctx->back_ptr;

	if (!global->params.Certification && (ctx->metric_entry.bcn_query->ch == 255) && (ctx->metric_entry.bcn_query->ap_ch_rpt_num > 1))
		beacon_query_mutil_info(ctx, ctx->metric_entry.bcn_query);
	else
#endif
	{
		status = topo_srv_get_bssid_of_sta(ctx, ctx->metric_entry.bcn_query, assoc_bssid);
#ifdef MTK_MLO_MAP_SUPPORT
		temp_cli = client_db_get_client_from_sta_mac((struct mapd_global *)ctx->back_ptr,
			ctx->metric_entry.bcn_query->sta_mac);
		if (temp_cli) {
			if (temp_cli->mlo_enable && !temp_cli->mlo_setup_link) {
				err(DEBUG_CAT_METRIC, "cli found at the agent side");
				temp_main_cli = find_main_setup_link(temp_cli);
				if (temp_main_cli) {
					err(DEBUG_CAT_METRIC, " override cli by main setup link");
					os_memcpy(ctx->metric_entry.bcn_query->sta_mac, temp_main_cli->mac_addr, ETH_ALEN);
					os_memcpy(ctx->metric_entry.bcn_query->bssid, temp_main_cli->bssid, ETH_ALEN);
					status = topo_srv_get_bssid_of_sta(ctx, ctx->metric_entry.bcn_query, assoc_bssid);
				}
			}
		}
		err(DEBUG_CAT_METRIC, "At Agent 11k req at sta mac "MACSTR" bssid "MACSTR" channel %d , ssid %s",
			MAC2STR(ctx->metric_entry.bcn_query->sta_mac),
			MAC2STR(ctx->metric_entry.bcn_query->bssid),
			ctx->metric_entry.bcn_query->ch,
			ctx->metric_entry.bcn_query->ssid);
#endif

		/*query ap metrics response info from wapp */
		datalen = sizeof(struct beacon_metrics_query) +
		    ctx->metric_entry.bcn_query->ap_ch_rpt_num * sizeof(struct ap_chn_rpt);

		if (status == 0)
			map_get_info_from_wapp(ctx, WAPP_USER_SET_BEACON_METRICS_QRY,
					   0, assoc_bssid, NULL, (void *)ctx->metric_entry.bcn_query, datalen);
		else
			map_get_info_from_wapp(ctx, WAPP_USER_SET_BEACON_METRICS_QRY,
					   0, NULL, NULL, (void *)ctx->metric_entry.bcn_query, datalen);
	}

	free(ctx->metric_entry.bcn_query);
	ctx->metric_entry.bcn_query = NULL;

	return 0;
}

/**
* @brief Fn to parse ap metrics query msg
*
* @param ctx own 1905 device ctx
* @param buf msg buffer
*
* @return -1 if error else 0
*/
int parse_ap_metrics_query_message(struct own_1905_device *ctx, unsigned char *buf, int left_tlv_len)
{
	int length = 0, len, tlv_len;
	unsigned char *temp_buf;
	unsigned int integrity = 0;
#ifdef MAP_R2
	unsigned short *band_idx = &ctx->metric_entry.total_radio_band;
	*band_idx = 0;
#endif
	temp_buf = buf;

	while (1) {
		len = get_tlv_len(temp_buf);
		tlv_len = len + 3;
		if (left_tlv_len < tlv_len) {
			err(DEBUG_CAT_METRIC, "[%d] Error TLV len, type = %d, left_tlv_length %d less than tlv_len %d\n",
			      __LINE__, *temp_buf, left_tlv_len, tlv_len);
			return -1;
		}
		if (*temp_buf == AP_METRICS_QUERY_TYPE) {
			integrity |= (1 << AP_METRICS_QUERY_TYPE_CHECK);
			if (validate_tlv_length_specific_pattern(len, AP_METRICS_QUERY_TYPE_CONST_LEN,
				AP_METRICS_QUERY_TYPE_REPEAT_LEN) == FALSE) {
				err(DEBUG_CAT_METRIC, "error in ap metrics query type");
				return -1;
			}
			length = parse_ap_metrics_query_tlv(temp_buf, ctx);
			if (length < 0) {
				err(DEBUG_CAT_METRIC, "error ap metrics query tlv");
				return -1;
			}
			temp_buf += length;
		} 
#ifdef MAP_R2
		else if (*temp_buf == AP_RADIO_IDENTIFIER_TYPE) {
			integrity |= (1 << AP_RADIO_IDENTIFIER_TYPE_CHECK);
			if (check_fixed_length_tlv(AP_RADIO_IDENTIFIER_TYPE_LEN, temp_buf, left_tlv_len) == FALSE) {
				err(DEBUG_CAT_METRIC, "error radio identifier type tlv");
				return -1;
			}
			length = parse_ap_radio_identifier_tlv(temp_buf, ctx, *band_idx);
			if (length < 0) {
				err(DEBUG_CAT_METRIC, "error radio identifier type tlv");
				return -1;
			}
			*band_idx+=1;

			//code to remove
			//return 0;
			temp_buf += length;
		} 
#endif
		else if (*temp_buf == END_OF_TLV_TYPE) {
			break;
		} else {
			length = get_cmdu_tlv_length(temp_buf);
			temp_buf += length;
		}
		left_tlv_len -= tlv_len;
	}
	/*check integrity */
	if ((integrity & (1 << AP_METRICS_QUERY_TYPE_CHECK)) == 0) {
		err(DEBUG_CAT_METRIC, "incomplete ap metrics query message 0x%x 0x%x",
			     integrity, ((1 << AP_METRICS_QUERY_TYPE_CHECK) | (1 << AP_RADIO_IDENTIFIER_TYPE_CHECK)));
		return -1;
	}
	debug(DEBUG_CAT_METRIC, "exit");

	return 0;
}

/**
* @brief Fn to parse link metrics query msg
*
* @param ctx own 1905 device ctx
* @param buf msg buffer
* @param target neighbor target
* @param type tx/rx/both
*
* @return -1 if error else 0
*/
static int parse_link_metric_query_message(struct own_1905_device *ctx,
					   unsigned char *buf, unsigned char *target, unsigned char *type)
{
	int length = 0;
	unsigned char *temp_buf;

	temp_buf = buf;

	length = parse_link_metric_query_type_tlv(temp_buf, target, type);

	if (length < 0) {
		err(DEBUG_CAT_METRIC, "error link metric query tlv ");
		return -1;
	}
	temp_buf += length;

	return 0;
}

#ifdef MAP_R6
u8 check_mld_sta_client(struct _1905_map_device *dev, unsigned char *sta_mac)
{
	struct mlo_sta_config_db *mld_sta_cfg = NULL, *tmld_sta_cfg = NULL;
	struct mlo_sta_db *mld_sta = NULL, *tmld_sta = NULL;
	u8 client_found = 0;

	SLIST_FOREACH_SAFE(mld_sta_cfg, &dev->first_mld_sta_cnf_rpt, list, tmld_sta_cfg) {
		debug(DEBUG_CAT_METRIC, "mld_sta_cfg->num_affiliates_sta = %d", mld_sta_cfg->num_affiliates_sta);

		SLIST_FOREACH_SAFE(mld_sta, &(mld_sta_cfg->mlo_sta_list), list, tmld_sta) {
			debug(DEBUG_CAT_METRIC, "mld_sta->bssid " MACSTR"", MAC2STR(mld_sta->bssid));
			debug(DEBUG_CAT_METRIC, "mld_sta->affiliated_sta_mac " MACSTR "", MAC2STR(mld_sta->affiliated_sta_mac));
			if ((mld_sta_cfg->num_affiliates_sta > 1)
				&& !os_memcmp(mld_sta->affiliated_sta_mac, sta_mac, ETH_ALEN)) {
				client_found = 1;
				debug(DEBUG_CAT_METRIC, "MLD CLIENT FOUND");
				return client_found;
			}
		}
	}

	return client_found;
}
#endif
/**
* @brief Fn to update link metrics info to 1905
*
* @param ctx own 1905 device ctx
* @param target neighbor target
* @param type rx/tx/both
*
* @return -1 if error else 0
*/
int send_link_metrics_response_message(struct own_1905_device *ctx, unsigned char *target, int type)
{
	int count, is_ap = 0, total_len = 0, len = 0;
	struct tx_link_metrics *tx_sta, *tx_ap;
	struct rx_link_metrics *rx_sta, *rx_ap;
	unsigned char *tx_ap_buf, *rx_ap_buf, *tx_sta_buf, *rx_sta_buf;
	unsigned char zero_bssid[ETH_ALEN] = { 0 };

	struct _1905_map_device *tmp_dev = topo_srv_get_1905_device(ctx, NULL);
	struct map_neighbor_info *neighbor, *t_neighbor = NULL;
	struct link_stat_query lsq;
	struct iface_info *ifc_info = SLIST_FIRST(&(tmp_dev->_1905_info.first_iface));
	int tx_metrics_cnt = 0, rx_metrics_cnt = 0;
	struct mapd_global *mapd_ctx = (struct mapd_global *)ctx->back_ptr;
#ifdef MTK_MLO_MAP_SUPPORT
	unsigned char *tx_sta_mlo_buf, *rx_sta_mlo_buf;
	struct tx_link_metrics tx_sta_mlo;
	struct rx_link_metrics rx_sta_mlo;
	int num_of_links = 0;
	int linkid_ap = 0;
	unsigned char num_of_ap_link = 0;
#ifdef MAP_R6
	struct _1905_map_device *dev_aff_ap = NULL;
#endif
#endif
#ifdef EM_PLUS_EXT_SUPPORT
	struct backhaul_link_info *controller_bh = NULL;
	struct _1905_map_device *agent_dev = NULL;
	struct iface_info *iface, *tiface = NULL;
	unsigned char add_GW_agent_info = FALSE;
#endif

	if (mapd_ctx == NULL) {
		err(DEBUG_CAT_METRIC, "mapd global pointer is NULL");
		return -1;
	}
#ifdef MTK_MLO_MAP_SUPPORT
#define MAX_SIZE_MLO (1024 * MLO_LINK_MAX)
#endif
#define MAX_SIZE 1024
	tx_sta = os_zalloc(MAX_SIZE);
#ifdef MTK_MLO_MAP_SUPPORT
	tx_ap = os_zalloc(MAX_SIZE_MLO);
#else
	tx_ap = os_zalloc(MAX_SIZE);
#endif
	rx_sta = os_zalloc(MAX_SIZE);
#ifdef MTK_MLO_MAP_SUPPORT
	rx_ap = os_zalloc(MAX_SIZE_MLO);
#else
	rx_ap = os_zalloc(MAX_SIZE);
#endif

	len = (sizeof(struct tx_link_metrics) > sizeof(struct rx_link_metrics))?sizeof(struct tx_link_metrics):sizeof(struct rx_link_metrics);

	debug(DEBUG_CAT_METRIC, "enter");

	if((tx_sta == NULL) || (tx_ap == NULL) || (rx_sta == NULL) || (rx_ap == NULL)){
		if(tx_sta){
			os_free(tx_sta);
		}
		if(tx_ap){
			os_free(tx_ap);
		}
		if(rx_sta){
			os_free(rx_sta);
		}
		if(rx_ap){
			os_free(rx_ap);
		}
		return -1;
	}

	//TODO should we allocate memory here?
	tx_ap_buf = (unsigned char *)tx_ap;
	rx_ap_buf = (unsigned char *)rx_ap;
	tx_sta_buf = (unsigned char *)tx_sta;
	rx_sta_buf = (unsigned char *)rx_sta;
#ifdef MTK_MLO_MAP_SUPPORT
	tx_sta_mlo_buf = (unsigned char *)&tx_sta_mlo;
	rx_sta_mlo_buf = (unsigned char *)&rx_sta_mlo;
#endif

	if (SLIST_EMPTY(&tmp_dev->neighbors_entry)) {
		if (mapd_ctx->params.Certification)
			goto fail;
		os_free(tx_sta);
		os_free(tx_ap);
		os_free(rx_sta);
		os_free(rx_ap);
		return -1;
	}
	lsq.media_type = ifc_info->media_type;
#ifdef EM_PLUS_EXT_SUPPORT
	SLIST_FOREACH_SAFE(neighbor, &tmp_dev->neighbors_entry, next_neighbor, t_neighbor) {
		if (neighbor && (neighbor->neighbor->device_role == DEVICE_ROLE_CONTROLLER)) {
			controller_bh = SLIST_FIRST(&neighbor->bh_head);
			info(DEBUG_CAT_METRIC, TOPO_PREX"controller found("MACSTR") n-inf ("MACSTR") c-inf ("MACSTR")",
				MAC2STR(neighbor->n_almac), MAC2STR(controller_bh->neighbor_iface_addr),
				MAC2STR(controller_bh->connected_iface_addr));
			break;
		}
	}

	if (controller_bh) {
		agent_dev = topo_srv_get_1905_device(ctx, NULL);
		while (agent_dev) {
			if ((agent_dev != tmp_dev) && (agent_dev->device_role == DEVICE_ROLE_AGENT)) {
				SLIST_FOREACH_SAFE(iface, &(agent_dev->_1905_info.first_iface), next_iface, tiface) {
					if (!os_memcmp(controller_bh->neighbor_iface_addr, iface->iface_addr, ETH_ALEN)) {
						info(DEBUG_CAT_METRIC, TOPO_PREX"Device("MACSTR") role[%d] matched inf",
							MAC2STR(agent_dev->_1905_info.al_mac_addr), agent_dev->device_role);
						add_GW_agent_info = TRUE;
						break;
					}
				}
			}
			if (add_GW_agent_info == TRUE)
				break;
			agent_dev = topo_srv_get_next_1905_device(ctx, agent_dev);
		}
	}
#endif

	if (!memcmp(zero_bssid, target, ETH_ALEN)) {
		SLIST_FOREACH_SAFE(neighbor, &tmp_dev->neighbors_entry, next_neighbor, t_neighbor) {
			if (!neighbor) {
				err(DEBUG_CAT_METRIC, "neighbor not found for link metrics");
				if (mapd_ctx->params.Certification)
					goto fail;
				os_free(tx_sta);
				os_free(tx_ap);
				os_free(rx_sta);
				os_free(rx_ap);
				return -1;
			}
			ctx->metric_entry.bh = SLIST_FIRST(&neighbor->bh_head);
			info(DEBUG_CAT_METRIC, TOPO_PREX"almac("MACSTR")connected_iface_addr("MACSTR") neighbor_iface_addr("MACSTR")",
				MAC2STR(neighbor->n_almac), MAC2STR(ctx->metric_entry.bh->connected_iface_addr),
				MAC2STR(ctx->metric_entry.bh->neighbor_iface_addr));

			if (ctx->is_lo != 1 && ((memcmp(zero_bssid, ctx->metric_entry.bh->connected_iface_addr, ETH_ALEN) == 0) ||
				memcmp(zero_bssid, ctx->metric_entry.bh->neighbor_iface_addr, ETH_ALEN) == 0)) {
				err(DEBUG_CAT_METRIC, "bh entry is not valid yet");
				continue;
			}

			ifc_info = topo_srv_get_iface(tmp_dev, ctx->metric_entry.bh->connected_iface_addr);
			if(!ifc_info) {
				err(DEBUG_CAT_METRIC, "interface not found");
				continue;
			}
			lsq.media_type = ifc_info->media_type;
			os_memcpy(lsq.local_if, ctx->metric_entry.bh->connected_iface_addr, ETH_ALEN);
			os_memcpy(lsq.neighbor_if, ctx->metric_entry.bh->neighbor_iface_addr, ETH_ALEN);
			wlanif_issue_wapp_command((struct mapd_global *)ctx->back_ptr, WAPP_USER_GET_TX_LINK_STATISTICS,
					WAPP_TX_LINK_STATISTICS, target, NULL, &lsq, sizeof(struct link_stat_query), 0, 1, 0);
			wlanif_issue_wapp_command((struct mapd_global *)ctx->back_ptr, WAPP_USER_GET_RX_LINK_STATISTICS,
					WAPP_RX_LINK_STATISTICS, target, NULL, &lsq, sizeof(struct link_stat_query), 0, 1, 0);
#ifndef MTK_MLO_MAP_SUPPORT
			ctx->metric_entry.bh = NULL;
#endif
#ifdef MTK_MLO_MAP_SUPPORT
			/* For Non MLD and single mld device */
			if (lsq.media_type == 0) {
				debug(DEBUG_CAT_METRIC, "ETH media_type:%d\n", lsq.media_type);
				num_of_links = 0;
				num_of_ap_link = 0;
			} else if (tmp_dev->mld_enabled != 1) {
				debug(DEBUG_CAT_METRIC, "tmp_dev->mld_enabled = %d", tmp_dev->mld_enabled);
				num_of_links = 1;
				num_of_ap_link = 0;
			} else if (tmp_dev->mld_enabled == 1) {
				num_of_links = ctx->setup_link_num;
#ifdef MAP_R6
				dev_aff_ap = topo_srv_get_1905_by_iface_addr(ctx, ctx->metric_entry.bh->neighbor_iface_addr);
				if (dev_aff_ap == NULL) {
					err(DEBUG_CAT_METRIC, "1905 AFF Device not found\n");
					num_of_ap_link = 0;
				} else if (dev_aff_ap->mld_bsta.num_affiliated_sta >= 1
						&& dev_aff_ap->mld_bsta.num_affiliated_sta <= MAX_MLD_CLI) {
					debug(DEBUG_CAT_METRIC, "MLO CASE: num_of_ap_link:%d\n", dev_aff_ap->mld_bsta.num_affiliated_sta);
					num_of_ap_link = dev_aff_ap->mld_bsta.num_affiliated_sta - 1;
				} else {
					debug(DEBUG_CAT_METRIC, "num_of_ap_link:0, dev_aff_ap->mld_bsta.num_affiliated_sta:%d, %d\n",
							dev_aff_ap->mld_bsta.num_affiliated_sta, dev_aff_ap->mld_bss.num_ap_mld);
					num_of_ap_link = 0;
				}
#endif
				debug(DEBUG_CAT_METRIC, "MLD ENAABLED FOR LINK METRICS tmp_dev->mld_enabled = %d, %d, %d",
					tmp_dev->mld_enabled, num_of_links, num_of_ap_link);
			}

#endif
			count =
				append_link_metric_info(tx_ap_buf, rx_ap_buf, tx_sta_buf, rx_sta_buf, tmp_dev, neighbor, &is_ap
#ifdef MTK_MLO_MAP_SUPPORT
				, 1, 0, num_of_links, NULL, NULL, 0, num_of_ap_link
#endif
#ifdef EM_PLUS_EXT_SUPPORT
				, NULL
#endif

);
			if ((is_ap
#ifdef MTK_MLO_MAP_SUPPORT
				&& num_of_ap_link == 0
#endif
				) || lsq.media_type == 0) {
				debug(DEBUG_CAT_METRIC, "AP LINK 1 MEDIA TYPE ZERO");
				(tx_ap+tx_metrics_cnt)->link_pair_cnt = 1;
				(rx_ap+rx_metrics_cnt)->link_pair_cnt = 1;
			}

			if (count > 0) {
				if (!is_ap
#ifdef MTK_MLO_MAP_SUPPORT
				|| (num_of_links > 1)
				|| (num_of_ap_link > 0 && is_ap && lsq.media_type != 0)
#endif
			) {
				memcpy(tx_ap_buf, tx_sta_buf, sizeof(struct tx_link_metrics));
				memcpy(rx_ap_buf, rx_sta_buf, sizeof(struct rx_link_metrics));
			}
				tx_metrics_cnt++;
				rx_metrics_cnt++;
				total_len = tx_metrics_cnt * len;

#ifndef MTK_MLO_MAP_SUPPORT
				if ((total_len >= MAX_SIZE) || ((total_len < MAX_SIZE) && ((MAX_SIZE - total_len) < len)))
#else
				if ((total_len >= MAX_SIZE_MLO) || ((total_len < MAX_SIZE_MLO) && ((MAX_SIZE_MLO - total_len) < len)))
#endif
				{
					err(DEBUG_CAT_METRIC, "tx metric data size %d comes up to max setting", total_len);
					break;
				}
#ifdef MTK_MLO_MAP_SUPPORT
#ifndef EM_PLUS_EXT_SUPPORT
				if (num_of_links <= 1 && is_ap && num_of_ap_link == 0) {
#endif
#endif
					ctx->metric_entry.bh = NULL;
					debug(DEBUG_CAT_METRIC, "DEBUG metric entry NULL, is_ap:%d", is_ap);
					tx_ap_buf += sizeof(struct tx_link_metrics);
					tx_sta_buf += sizeof(struct tx_link_metrics);
					rx_ap_buf += sizeof(struct rx_link_metrics);
					rx_sta_buf += sizeof(struct rx_link_metrics);
#ifdef MTK_MLO_MAP_SUPPORT
#ifndef EM_PLUS_EXT_SUPPORT
				}
#endif
#endif
			}
#ifdef EM_PLUS_EXT_SUPPORT
			if ((neighbor->neighbor->device_role == DEVICE_ROLE_CONTROLLER) && add_GW_agent_info) {
				count = append_link_metric_info(tx_ap_buf, rx_ap_buf, tx_sta_buf, rx_sta_buf, tmp_dev, neighbor, &is_ap
#ifdef MTK_MLO_MAP_SUPPORT
				, 1, 0, num_of_links, NULL, NULL, 0, num_of_ap_link
#endif
	, agent_dev);
				if (count > 0) {
					if (!is_ap
#ifdef MTK_MLO_MAP_SUPPORT
						|| (num_of_links > 1)
						|| (num_of_ap_link > 0 && is_ap && lsq.media_type != 0)
#endif
						) {
						memcpy(tx_ap_buf, tx_sta_buf, sizeof(struct tx_link_metrics));
						memcpy(rx_ap_buf, rx_sta_buf, sizeof(struct rx_link_metrics));
					}
					tx_metrics_cnt++;
					rx_metrics_cnt++;
					total_len = tx_metrics_cnt * len;
#ifndef MTK_MLO_MAP_SUPPORT
					if ((total_len >= MAX_SIZE) || ((total_len < MAX_SIZE) && ((MAX_SIZE - total_len) < len)))
#else
					if ((total_len >= MAX_SIZE_MLO) ||
						((total_len < MAX_SIZE_MLO) && ((MAX_SIZE_MLO - total_len) < len)))
#endif
					{
						err(DEBUG_CAT_METRIC, "tx metric data size %d comes up to max setting", total_len);
						break;
					}
#ifdef MTK_MLO_MAP_SUPPORT
					if (num_of_links <= 1 && is_ap && num_of_ap_link == 0) {
#endif
						tx_ap_buf += sizeof(struct tx_link_metrics);
						tx_sta_buf += sizeof(struct tx_link_metrics);
						rx_ap_buf += sizeof(struct rx_link_metrics);
						rx_sta_buf += sizeof(struct rx_link_metrics);
#ifdef MTK_MLO_MAP_SUPPORT
					}
#endif
				}
			}
#endif
#ifdef MTK_MLO_MAP_SUPPORT
			if ((num_of_links > 1) && (num_of_links <= MLO_LINK_MAX)
				&& (!is_ap)) {
				int i, k = 0, linkid = 0, lmetric_tx_len, lmetric_rx_len;

				for (i = 0; i < num_of_links; i++) {
					if (!ctx->linkinfo[i].is_non_setup_link
						|| !ctx->linkinfo[i].mlo_enable)
						continue;

				ifc_info = topo_srv_get_iface(tmp_dev, ctx->linkinfo[i].mac_addr);

				if (!ifc_info) {
					err(DEBUG_CAT_METRIC, "interface not found MLO1");
					continue;
				}

				lsq.media_type = ifc_info->media_type;
				os_memcpy(lsq.local_if, ctx->linkinfo[i].mac_addr, ETH_ALEN);
				os_memcpy(lsq.neighbor_if, ctx->linkinfo[i].connected_bssid, ETH_ALEN);
				wlanif_issue_wapp_command((struct mapd_global *)ctx->back_ptr, WAPP_USER_GET_TX_LINK_STATISTICS,
				WAPP_TX_LINK_STATISTICS,  ctx->linkinfo[i].connected_bssid,
						NULL, &lsq, sizeof(struct link_stat_query), 0, 1, 0);
				wlanif_issue_wapp_command((struct mapd_global *)ctx->back_ptr, WAPP_USER_GET_RX_LINK_STATISTICS,
				WAPP_RX_LINK_STATISTICS,  ctx->linkinfo[i].connected_bssid, NULL, &lsq,
					sizeof(struct link_stat_query), 0, 1, 0);
				count =
					 append_link_metric_info(tx_ap_buf, rx_ap_buf, tx_sta_buf, rx_sta_buf, tmp_dev, neighbor, &is_ap
#ifdef MTK_MLO_MAP_SUPPORT
					, 0, linkid, num_of_links, ctx->linkinfo[i].mac_addr, ctx->linkinfo[i].connected_bssid, 0, 0
#endif
#ifdef EM_PLUS_EXT_SUPPORT
					, NULL
#endif
						);
				linkid += 1;

				if (count > 0) {
					if (i < MLO_LINK_MAX) {
						memcpy(tx_sta_mlo_buf, tx_sta_buf, sizeof(struct tx_link_metrics));
						memcpy(rx_sta_mlo_buf, rx_sta_buf, sizeof(struct rx_link_metrics));
						lmetric_tx_len = tx_metrics_cnt - 1;
						lmetric_rx_len = rx_metrics_cnt - 1;
						memcpy(&((rx_ap + lmetric_rx_len)->metrics[k + 1]), &rx_sta_mlo.metrics[0],
							sizeof(struct rx_link_metrics_sub));
						memcpy(&((tx_ap + lmetric_tx_len)->metrics[k + 1]), &tx_sta_mlo.metrics[0],
							sizeof(struct tx_link_metrics_sub));
						k += 1;
					}

					total_len = tx_metrics_cnt * len;
					if ((total_len >= MAX_SIZE_MLO) || ((total_len < MAX_SIZE_MLO) && ((MAX_SIZE - total_len) < len))) {
						err(DEBUG_CAT_METRIC, "tx metric data size %d comes up to max setting", total_len);
						break;
					}
				}
				}

				ctx->metric_entry.bh = NULL;
				tx_ap_buf += sizeof(struct tx_link_metrics);
				rx_ap_buf += sizeof(struct rx_link_metrics);
				os_memset(tx_sta_buf, '\0', sizeof(struct tx_link_metrics));
				os_memset(rx_sta_buf, '\0', sizeof(struct rx_link_metrics));
			} else if ((num_of_links > 1 || num_of_ap_link > 0) && linkid_ap < MLO_LINK_MAX && (is_ap)) {
				int k = 0, lmetric_tx_len, lmetric_rx_len, i = 0;
				struct _1905_map_device *dev_1905;
				int client_found = 0;
				struct iface_info *ifc_info2 = NULL;
				struct associated_clients *assoc_client = NULL, *tclient = NULL;
				struct iface_info *iface = NULL, *tiface = NULL;
				if (ctx->metric_entry.bh == NULL) {
					err(DEBUG_CAT_METRIC, "BH NULL, Proxy ETH condition");
					continue;
				}


				dev_1905 = topo_srv_get_1905_by_iface_addr(ctx, ctx->metric_entry.bh->neighbor_iface_addr);

				if (dev_1905 == NULL) {
					err(DEBUG_CAT_METRIC, "1905 Device not found\n");
					continue;
				}


			SLIST_FOREACH_SAFE(iface, &(dev_1905->_1905_info.first_iface), next_iface, tiface) {
				if (os_memcmp(ctx->metric_entry.bh->neighbor_iface_addr,
						iface->iface_addr, ETH_ALEN) == 0)
					break;
			}

			SLIST_FOREACH_SAFE(assoc_client, &tmp_dev->assoc_clients, next_client, tclient) {
				/* For AP Setup link continue */
				if (os_memcmp(assoc_client->client_addr, ctx->metric_entry.bh->neighbor_iface_addr, ETH_ALEN)  == 0) {
					err(DEBUG_CAT_METRIC, "AP Setup link or not APCLI continue");
					continue;
				}

				if (num_of_ap_link > 0 && num_of_links == 0 && linkid_ap >= num_of_ap_link) {
					err(DEBUG_CAT_METRIC, "AP LINK for MLO overflow check for race condition\n");
					continue;
				}


				for (i = 0; i < iface->itf_num_mlo; i++) {
					if (os_memcmp(assoc_client->client_addr,
							iface->nonsetup_link_mac[i], ETH_ALEN) == 0) {
						client_found = 1;
						break;
					}
				}

				if (!client_found && num_of_ap_link > 0 && assoc_client->is_APCLI == 1 && num_of_links == 0) {
#ifdef MAP_R6
					client_found = check_mld_sta_client(dev_1905, assoc_client->client_addr);
					err(DEBUG_CAT_METRIC, "MLD CLient not found for AP condition");
#endif
				}

				if (!client_found) {
					info(DEBUG_CAT_METRIC, "client not found for "MACSTR"", MAC2STR(assoc_client->client_addr));
					continue;
				}

				ifc_info2 = topo_srv_get_iface(tmp_dev, assoc_client->bss->bssid);

				if (!ifc_info2) {
					err(DEBUG_CAT_METRIC, "interface not found MLO2");
					continue;
				}

				lsq.media_type = ifc_info2->media_type;
				os_memcpy(lsq.local_if, assoc_client->bss->bssid, ETH_ALEN);
				os_memcpy(lsq.neighbor_if, assoc_client->client_addr, ETH_ALEN);
				wlanif_issue_wapp_command((struct mapd_global *)ctx->back_ptr, WAPP_USER_GET_TX_LINK_STATISTICS,
				WAPP_TX_LINK_STATISTICS,  assoc_client->bss->bssid,
						NULL, &lsq, sizeof(struct link_stat_query), 0, 1, 0);
				wlanif_issue_wapp_command((struct mapd_global *)ctx->back_ptr, WAPP_USER_GET_RX_LINK_STATISTICS,
				WAPP_RX_LINK_STATISTICS,  assoc_client->bss->bssid, NULL, &lsq,
					sizeof(struct link_stat_query), 0, 1, 0);
				lmetric_tx_len = tx_metrics_cnt - 1;
				lmetric_rx_len = rx_metrics_cnt - 1;
				(rx_ap + lmetric_rx_len)->link_pair_cnt = linkid_ap + 2;
				(tx_ap + lmetric_tx_len)->link_pair_cnt = linkid_ap + 2;
				count =
					 append_link_metric_info(tx_ap_buf, rx_ap_buf, tx_sta_buf, rx_sta_buf, tmp_dev, neighbor, &is_ap
#ifdef MTK_MLO_MAP_SUPPORT
						, 0, linkid_ap, linkid_ap + 2, assoc_client->client_addr, NULL, 0, 0
#endif
#ifdef EM_PLUS_EXT_SUPPORT
						, NULL
#endif
						);
				linkid_ap += 1;
				if (count > 0) {
					if (linkid_ap < MLO_LINK_MAX) {
						memcpy(tx_sta_mlo_buf, tx_sta_buf, sizeof(struct tx_link_metrics));
						memcpy(rx_sta_mlo_buf, rx_sta_buf, sizeof(struct rx_link_metrics));
						memcpy(&((rx_ap + lmetric_rx_len)->metrics[k + 1]), &rx_sta_mlo.metrics[0],
							sizeof(struct rx_link_metrics_sub));
						memcpy(&((tx_ap + lmetric_tx_len)->metrics[k + 1]), &tx_sta_mlo.metrics[0],
							sizeof(struct tx_link_metrics_sub));
						k += 1;
					}

					total_len = tx_metrics_cnt * len;
					if ((total_len >= MAX_SIZE_MLO) || ((total_len < MAX_SIZE_MLO) && ((MAX_SIZE - total_len) < len))) {
						err(DEBUG_CAT_METRIC, "tx metric data size %d comes up to max setting", total_len);
						break;
					}
				}
			}
				ctx->metric_entry.bh = NULL;
				tx_ap_buf += sizeof(struct tx_link_metrics);
				rx_ap_buf += sizeof(struct rx_link_metrics);
				os_memset(tx_sta_buf, '\0', sizeof(struct tx_link_metrics));
				os_memset(rx_sta_buf, '\0', sizeof(struct rx_link_metrics));
			}
#endif
	}
	} else {
		t_neighbor = NULL;
		SLIST_FOREACH_SAFE(neighbor, &tmp_dev->neighbors_entry, next_neighbor, t_neighbor) {
			if (memcmp(neighbor->n_almac, target, ETH_ALEN)){
#ifdef EM_PLUS_EXT_SUPPORT
				if (!(add_GW_agent_info &&
					(neighbor->neighbor->device_role == DEVICE_ROLE_CONTROLLER) &&
					!memcmp(agent_dev->_1905_info.al_mac_addr, target, ETH_ALEN)))
					continue;
#else
				continue;
#endif
			}
			ctx->metric_entry.bh = SLIST_FIRST(&neighbor->bh_head);

			if (ctx->is_lo != 1 && ((memcmp(zero_bssid, ctx->metric_entry.bh->connected_iface_addr, ETH_ALEN) == 0) ||
				(memcmp(zero_bssid, ctx->metric_entry.bh->neighbor_iface_addr, ETH_ALEN) == 0))) {
				continue;
			}

			ifc_info = topo_srv_get_iface(tmp_dev, ctx->metric_entry.bh->connected_iface_addr);
			if(!ifc_info) {
				err(DEBUG_CAT_METRIC, "interface not found");
				continue;
			}
			lsq.media_type = ifc_info->media_type;
			os_memcpy(lsq.local_if, ctx->metric_entry.bh->connected_iface_addr, ETH_ALEN);
			os_memcpy(lsq.neighbor_if, ctx->metric_entry.bh->neighbor_iface_addr, ETH_ALEN);
			wlanif_issue_wapp_command((struct mapd_global *)ctx->back_ptr, WAPP_USER_GET_TX_LINK_STATISTICS,
					WAPP_TX_LINK_STATISTICS, target, NULL, &lsq, sizeof(struct link_stat_query), 0, 1, 0);
			wlanif_issue_wapp_command((struct mapd_global *)ctx->back_ptr, WAPP_USER_GET_RX_LINK_STATISTICS,
					WAPP_RX_LINK_STATISTICS, target, NULL, &lsq, sizeof(struct link_stat_query), 0, 1, 0);
			ctx->metric_entry.bh = NULL;
#ifdef EM_PLUS_EXT_SUPPORT
			if ((add_GW_agent_info &&
				(neighbor->neighbor->device_role == DEVICE_ROLE_CONTROLLER) &&
				!memcmp(agent_dev->_1905_info.al_mac_addr, target, ETH_ALEN))) {
				count =
					append_link_metric_info(tx_ap_buf, rx_ap_buf, tx_sta_buf, rx_sta_buf, tmp_dev, neighbor, &is_ap
#ifdef MTK_MLO_MAP_SUPPORT
					, 1, 0, 0, NULL, NULL, 0, 0
#endif
					, agent_dev);
			} else
#endif
			{
				count =
					append_link_metric_info(tx_ap_buf, rx_ap_buf, tx_sta_buf, rx_sta_buf, tmp_dev, neighbor, &is_ap
#ifdef MTK_MLO_MAP_SUPPORT
						, 1, 0, 0, NULL, NULL, 0, 0
#endif
#ifdef EM_PLUS_EXT_SUPPORT
						, NULL
#endif
					);
			}
			if (count > 0) {
				tx_metrics_cnt++;
				rx_metrics_cnt++;

				if (!is_ap) {
					memcpy(tx_ap_buf, tx_sta_buf, sizeof(struct tx_link_metrics));
					memcpy(rx_ap_buf, rx_sta_buf, sizeof(struct rx_link_metrics));
				}

				total_len = tx_metrics_cnt * len;
				if((total_len >= MAX_SIZE) || ((total_len < MAX_SIZE) && ((MAX_SIZE- total_len) < len))) {
					err(DEBUG_CAT_METRIC, "metric data size %d comes up to max setting", total_len);
					break;
				}

				tx_ap_buf += sizeof(struct tx_link_metrics);
				tx_sta_buf += sizeof(struct tx_link_metrics);
				rx_ap_buf += sizeof(struct rx_link_metrics);
				rx_sta_buf += sizeof(struct rx_link_metrics);
			}
			break;
		}
		if (!neighbor) {
			err(DEBUG_CAT_METRIC, "failed to get the specified neighbor");
			if (mapd_ctx->params.Certification)
				goto fail;
			os_free(tx_sta);
			os_free(tx_ap);
			os_free(rx_sta);
			os_free(rx_ap);
			return -1;
		}
	}
	if (type == TX_METRICS_ONLY)
		rx_metrics_cnt = 0;
	else if (type == RX_METRICS_ONLY)
		tx_metrics_cnt = 0;


	map_1905_Set_Link_Metrics_Rsp_Info(mapd_ctx->_1905_ctrl,
			tx_metrics_cnt, tx_ap,
			rx_metrics_cnt, rx_ap, ctx->mid);

	os_free(tx_sta);
	os_free(tx_ap);
	os_free(rx_sta);
	os_free(rx_ap);
	return 0;

fail:
	rx_metrics_cnt = 0;
	tx_metrics_cnt = 0;

	map_1905_Set_Link_Metrics_Rsp_Info(mapd_ctx->_1905_ctrl,
			tx_metrics_cnt, tx_ap,
			rx_metrics_cnt, rx_ap, ctx->mid);
	os_free(tx_sta);
	os_free(tx_ap);
	os_free(rx_sta);
	os_free(rx_ap);

	return 0;
}

/**
* @brief Fn to handle link metrics query
*
* @param ctx own 1905 device ctx
* @param buf msg buffer
*
* @return -1 if error else 0
*/
int topo_srv_handle_link_metrics_query(struct own_1905_device *ctx, unsigned char *buf)
{
	unsigned char target[ETH_ALEN], type;

	if (0 > parse_link_metric_query_message(ctx, buf, target, &type)) {
		err(DEBUG_CAT_METRIC, "receive error link metric query message");
		return -1;
	}
	send_link_metrics_response_message(ctx, target, type);

	return 0;
}

/**
* @brief Fn to prase assoc sta metrics query and send it to wapp
*
* @param ctx own 1905 device ctx
* @param buf msg buffer
* @param len msg len
*
* @return 0 if success else error
*/
int topo_srv_handle_assoc_sta_metrics_query(struct own_1905_device *ctx, unsigned char *buf, int len)
{
	struct mapd_global *global = (struct mapd_global *)ctx->back_ptr;
	struct link_metrics sta_metrics;
#ifdef MAP_R6
	ctx->affiliated_sta_index = 0;
	uint32_t client_id;
	struct client *cli = NULL;
	struct associated_clients *tmp_client = NULL, *client = NULL;
#endif
	debug(DEBUG_CAT_METRIC, "got ASSOC_STA_LINK_METRICS_QUERY");
	hex_dump("ASSOC_STA_LINK_METRICS_QUERY", (buf - ETH_HLEN), len);

	/*parse AP_LINK_METRICS_QUERY msg */
	if (parse_associated_sta_link_metrics_query_message(ctx, buf, len) < 0) {
		err(DEBUG_CAT_METRIC, "error! no need to response this associated sta link metrics query message");
		return -1;
	}

	/*query ap metrics response info from wapp */
	if (topo_srv_get_associate_client(ctx, NULL, ctx->metric_entry.assoc_sta) == NULL) {
		err(DEBUG_CAT_METRIC, "STA is not present"MACSTR, MAC2STR(ctx->metric_entry.assoc_sta));
		os_memcpy(sta_metrics.mac, ctx->metric_entry.assoc_sta, ETH_ALEN);
#ifdef MAP_R2
		map_1905_Set_Assoc_Sta_Link_Metric_Rsp_Info(global->_1905_ctrl, 1, &sta_metrics,
					0, NULL, ctx->metric_entry.assoc_sta, 2, ctx->mid);
#else
		map_1905_Set_Assoc_Sta_Link_Metric_Rsp_Info(global->_1905_ctrl, 0, NULL, ctx->metric_entry.assoc_sta, 2, ctx->mid);
#endif
		return -1;
	}
#ifdef MAP_R6
		struct _1905_map_device *map_dev = topo_srv_get_1905_device(&global->dev, NULL);

		SLIST_FOREACH_SAFE(client, &(map_dev->assoc_clients), next_client, tmp_client) {
			info(DEBUG_CAT_METRIC, "looking for cli\n");
			client_id = client_db_get_cid_from_mld_mac(global, ctx->metric_entry.assoc_sta, 0);
			cli = client_db_get_client_from_client_id(global, client_id);
		}
		if (cli)
			info(DEBUG_CAT_METRIC, "cli was found\n");
#endif
		wlanif_issue_wapp_command((struct mapd_global *)ctx->back_ptr, WAPP_USER_GET_ONE_ASSOC_STA_LINK_METRICS,
		WAPP_ONE_ASSOC_STA_LINK_METRICS, NULL, ctx->metric_entry.assoc_sta, NULL,
			0, 1, 1, 0);

#ifdef MAP_R6
		ctx->affiliated_sta_index++;
		if (cli) {
			for (int i = 1 ; i < cli->mld_sta_config->num_affiliates_sta; i++) {
				wlanif_issue_wapp_command((struct mapd_global *)ctx->back_ptr,
						WAPP_USER_GET_ONE_ASSOC_STA_LINK_METRICS, WAPP_ONE_ASSOC_STA_LINK_METRICS,
						NULL, cli->mld_sta_config->mlo_sta_info[i].affiliated_sta_mac, NULL,
						0, 1, 1, 0);
				ctx->affiliated_sta_index++;
			}
		}
		ctx->affiliated_sta_index = 0;
#endif
#ifdef MAP_R2
		wlanif_issue_wapp_command((struct mapd_global *)ctx->back_ptr, WAPP_USER_GET_ONE_ASSOC_STA_EXTENDED_LINK_METRICS,
		WAPP_ONE_ASSOC_STA_EXTENDED_LINK_METRICS, NULL, ctx->metric_entry.assoc_sta, NULL,
			0, 1, 1, 0);
#ifdef MAP_R6
		ctx->affiliated_sta_index++;

		if (cli) {
			for (int m = 1; m < cli->mld_sta_config->num_affiliates_sta; m++) {
				wlanif_issue_wapp_command((struct mapd_global *)ctx->back_ptr,
					WAPP_USER_GET_ONE_ASSOC_STA_EXTENDED_LINK_METRICS,
					WAPP_ONE_ASSOC_STA_EXTENDED_LINK_METRICS, NULL,
					cli->mld_sta_config->mlo_sta_info[m].affiliated_sta_mac, NULL,
					0, 1, 1, 0);
				ctx->affiliated_sta_index++;
			}
		}
#endif
#endif
	return 0;
}

/**
* @brief Fn to parse metrics query and send it to wapp
*
* @param ctx own 1905 device
* @param buf msg buffer
* @param len msg len
*
* @return -1 if error else 0
*/
int topo_srv_handle_metrics_query(struct own_1905_device *ctx, unsigned char *buf, int len, unsigned char periodic)
{
	int ret = 0;

	ret = parse_ap_metrics_query_message(ctx, buf, len);

	if (ret < 0) {
		err(DEBUG_CAT_METRIC, "this shouldn't happen");
		return -1;
	}
	/*query ap metrics response info from wapp */
	topo_srv_get_assoc_sta_traffic_stats(ctx);
	topo_srv_get_all_assoc_sta_link_metrics(ctx);
#ifdef MAP_R2
	if(!periodic)
		topo_srv_get_radio_metrics_info(ctx);
	else
		topo_srv_get_all_radio_metrics_info(ctx);
#endif
	topo_srv_get_ap_metrics_info(ctx);
#ifdef MAP_R3_WF6
	debug(DEBUG_CAT_METRIC, "calling topo_srv_get_assoc_wifi6_sta_status\n");
	topo_srv_get_assoc_wifi6_sta_status(ctx);
#endif
#ifdef EM_PLUS_SUPPORT
	topo_srv_get_radio_cpu_temperature(ctx);
#endif
	return 0;
}

int topo_srv_cont_update_ap_metrics(struct own_1905_device *ctx)
{
       /*query ap metrics response info from wapp */
       topo_srv_get_own_metrics_info(ctx);

       /* TODO later */
#if 0
       topo_srv_get_assoc_sta_traffic_stats(ctx);
       topo_srv_get_all_assoc_sta_link_metrics(ctx);
#endif
       return 0;
}

int topo_srv_cont_update_link_metrics(struct own_1905_device *ctx)
{
       /*query ap metrics response info from wapp */
       topo_srv_get_own_link_metrics_info(ctx);

       /* TODO later */
#if 0
       topo_srv_get_assoc_sta_traffic_stats(ctx);
       topo_srv_get_all_assoc_sta_link_metrics(ctx);
#endif
       return 0;
}

/**
* @brief Fn to append metrics info
*
* @param pkt buffer where metrics needs to be appended
* @param mrsp bss info db
*
* @return -1 if error else 0
*/
unsigned short append_ap_metrics_info(unsigned char *pkt, struct bss_info_db *mrsp)
{
	struct esp_db *esp = NULL, *t_esp = NULL;
	struct ap_metrics_info_lib *ap_metrics;
	struct esp_info *esp_lib;

	ap_metrics = (struct ap_metrics_info_lib *)pkt;

	memcpy(ap_metrics->bssid, mrsp->bssid, ETH_ALEN);

	ap_metrics->ch_util = mrsp->ch_util;
	ap_metrics->assoc_sta_cnt = mrsp->assoc_sta_cnt;
	ap_metrics->valid_esp_count = 0;
	esp_lib = ap_metrics->esp;
	debug(DEBUG_CAT_METRIC, "insert into function");
	debug(DEBUG_CAT_METRIC, "bssid("MACSTR") ch_uti=%d, assoc_sta_cnt=%d, valid_esp_cnt=%d",
			MAC2STR(ap_metrics->bssid),ap_metrics->ch_util, ap_metrics->assoc_sta_cnt, mrsp->esp_cnt);

	SLIST_FOREACH_SAFE(esp, &(mrsp->esp_head), esp_entry, t_esp) {
		ap_metrics->valid_esp_count++;
		esp_lib->ac = esp->ac;
		esp_lib->format = esp->format;
		esp_lib->ba_win_size = esp->ba_win_size;
		esp_lib->e_air_time_fraction = esp->e_air_time_fraction;
		esp_lib->ppdu_dur_target = esp->ppdu_dur_target;
		debug(DEBUG_CAT_METRIC, "inser into function");
		debug(DEBUG_CAT_METRIC, "ac=%d, format=%d ba_win_size=%d", esp_lib->ac, esp_lib->format, esp_lib->ba_win_size);
		debug(DEBUG_CAT_METRIC, "e_air_time_fraction=%d, ppdu_dur_target=%d esp =%p",
			esp_lib->e_air_time_fraction, esp_lib->ppdu_dur_target, esp_lib);
		esp_lib = &ap_metrics->esp[ap_metrics->valid_esp_count];
	}

	return 0;
}

/**
* @brief Fn to append ap metrics tlv
*
* @param pkt msg buffer
* @param mrsp bss info
*
* @return -1 if error else 0
*/
unsigned short append_ap_metrics_tlv(unsigned char *pkt, struct bss_info_db *mrsp)
{
	struct esp_db *esp = NULL, *t_esp = NULL;
	struct ap_metrics_info_lib *ap_metrics;
	struct esp_info *esp_lib;
	unsigned short len = 0;

	ap_metrics = (struct ap_metrics_info_lib *)pkt;

	memcpy(ap_metrics->bssid, mrsp->bssid, ETH_ALEN);
	len += ETH_ALEN;

	ap_metrics->ch_util = mrsp->ch_util;
	len += sizeof(char);
	ap_metrics->assoc_sta_cnt = mrsp->assoc_sta_cnt;
	len += sizeof(short);
	ap_metrics->valid_esp_count = 0;
	len += sizeof(char);
	esp_lib = ap_metrics->esp;
	SLIST_FOREACH_SAFE(esp, &(mrsp->esp_head), esp_entry, t_esp) {
		ap_metrics->valid_esp_count++;
		esp_lib->ac = esp->ac;
		esp_lib->format = esp->format;
		esp_lib->ba_win_size = esp->ba_win_size;
		esp_lib->e_air_time_fraction = esp->e_air_time_fraction;
		esp_lib->ppdu_dur_target = esp->ppdu_dur_target;
		debug(DEBUG_CAT_METRIC, " esplib =%p ac=%d, format=%d, ba_win=%d, airtime=%d, target=%d valid_esp_count=%d",
		 esp_lib, esp_lib->ac, esp_lib->format, esp_lib->ba_win_size, esp_lib->e_air_time_fraction,
		  esp_lib->ppdu_dur_target, ap_metrics->valid_esp_count);
		esp_lib = &ap_metrics->esp[ap_metrics->valid_esp_count];
	}
	len += ap_metrics->valid_esp_count * sizeof(struct esp_info);

	debug(DEBUG_CAT_METRIC, "len =%d", len);
	return len;
}

#ifdef MAP_R2
unsigned short append_radio_metrics_tlv(unsigned char *pkt, struct mapd_radio_info *radio_info)
{
	struct radio_metrics_lib *radio_metrics;
	unsigned short len = 0;

	radio_metrics = (struct radio_metrics_lib *)pkt;

	os_memcpy(radio_metrics->identifier, radio_info->radio_metrics.ra_id, ETH_ALEN);

	len += ETH_ALEN;

	radio_metrics->noise = radio_info->radio_metrics.cu_noise;
	len += sizeof(char);
	radio_metrics->transmit = radio_info->radio_metrics.cu_tx;
	len += sizeof(short);
	radio_metrics->receive_self = radio_info->radio_metrics.cu_rx;
	len += sizeof(char);
	radio_metrics->receive_other= radio_info->radio_metrics.cu_other;
	len += sizeof(short);
	debug(DEBUG_CAT_METRIC, "len =%d", len);

	return len;
}
unsigned short append_ch_util_tlv(unsigned char *pkt, struct mapd_radio_info *radio_info)
{
	struct ch_util_lib *ch_util;
	unsigned short len = 0;

	ch_util = (struct ch_util_lib *)pkt;

	ch_util->ch_num = radio_info->channel;
	ch_util->edcca = radio_info->radio_metrics.edcca;
	len = sizeof(struct ch_util_lib);
	debug(DEBUG_CAT_METRIC, "len =%d", len);
	return len;
}
#endif

/**
* @brief Fn to append sta traffic stats
*
* @param pkt msg buffer where sta traffic stats to be appended
* @param stats stats_db
*
* @return 0 if success else -1
*/
unsigned short append_sta_traffic_stats_tlv(struct own_1905_device *ctx, unsigned char *pkt, struct stats_db *stats, int byte_cnt)
{
	struct stat_info *stats_lib;
	struct traffic_stats_db *traffic_stats = NULL, *t_traffic_stats = NULL;
	struct stats_db *l_stats = NULL, *l_tstats = NULL;
	stats_lib = (struct stat_info *)pkt;

	if (!is_zero_ether_addr(stats->sta_mld_mac)) {
		os_memcpy(stats_lib->mac, stats->sta_mld_mac, ETH_ALEN);
		os_memcpy(stats_lib->sta_mld_mac, stats->sta_mld_mac, ETH_ALEN);
	} else
		os_memcpy(stats_lib->mac, stats->mac, ETH_ALEN);

	stats_lib->bytes_sent = stats->bytes_sent/byte_count_trans(byte_cnt);
	stats_lib->bytes_received = stats->bytes_received/byte_count_trans(byte_cnt);
	stats_lib->packets_sent = stats->packets_sent;
	stats_lib->packets_received = stats->packets_received;
	stats_lib->tx_packets_errors = stats->tx_packets_errors;
	stats_lib->rx_packets_errors = stats->rx_packets_errors;
	stats_lib->retransmission_count = stats->retransmission_count;

	if (!is_zero_ether_addr(stats->sta_mld_mac)) {
		SLIST_FOREACH_SAFE(traffic_stats, &ctx->metric_entry.traffic_stats_head, traffic_stats_entry, t_traffic_stats) {
			SLIST_FOREACH_SAFE(l_stats, &traffic_stats->stats_head, stats_entry, l_tstats) {
				debug(DEBUG_CAT_METRIC, "l_stats->sta_mld_mac " MACSTR, MAC2STR(l_stats->sta_mld_mac));
				debug(DEBUG_CAT_METRIC, "stats->sta_mld_mac " MACSTR, MAC2STR(stats->sta_mld_mac));
				debug(DEBUG_CAT_METRIC, "l_stats->mac " MACSTR, MAC2STR(l_stats->mac));
				debug(DEBUG_CAT_METRIC, "stats->mac " MACSTR, MAC2STR(stats->mac));
				if (!os_memcmp(l_stats->sta_mld_mac, stats->sta_mld_mac, ETH_ALEN) &&
					os_memcmp(l_stats->mac, stats->mac, ETH_ALEN)) {

					stats_lib->bytes_sent += l_stats->bytes_sent/byte_count_trans(byte_cnt);
					stats_lib->bytes_received += l_stats->bytes_received/byte_count_trans(byte_cnt);
					stats_lib->packets_sent += l_stats->packets_sent;
					stats_lib->packets_received += l_stats->packets_received;
					stats_lib->tx_packets_errors += l_stats->tx_packets_errors;
					stats_lib->rx_packets_errors += l_stats->rx_packets_errors;
					stats_lib->retransmission_count += l_stats->retransmission_count;
				}
			}
		}

	}
	return 0;
}
#ifdef MAP_R6
/**
* @brief Fn to append sta mld traffic stats
*
* @param pkt msg buffer where sta mld traffic stats to be appended
* @param stats mld_stats_db
*
* @return 0 if success else -1
*/
unsigned short append_sta_mld_traffic_stats_tlv(unsigned char *pkt, struct stats_db *stats, int byte_cnt)
{
	struct stat_info *stats_lib;

	stats_lib = (struct stat_info *)pkt;

	memcpy(stats_lib->mac, stats->mac, ETH_ALEN);
#ifdef MAP_R6
	stats_lib->bytes_sent += stats->bytes_sent/byte_count_trans(byte_cnt);
	stats_lib->bytes_received += stats->bytes_received/byte_count_trans(byte_cnt);
	stats_lib->packets_sent += stats->packets_sent;
	stats_lib->packets_received += stats->packets_received;
	stats_lib->tx_packets_errors += stats->tx_packets_errors;
#else
	stats_lib->bytes_sent = stats->bytes_sent/byte_count_trans(byte_cnt);
	stats_lib->bytes_received = stats->bytes_received/byte_count_trans(byte_cnt);
	stats_lib->packets_sent = stats->packets_sent;
	stats_lib->packets_received = stats->packets_received;
	stats_lib->tx_packets_errors = stats->tx_packets_errors;
#endif
	return 0;
}
#endif

#ifdef EM_PLUS_SUPPORT
unsigned short append_radio_temperature_tlv(unsigned char *pkt, struct mapd_radio_info *radio_info)
{
	struct radio_temperature *radio_temp = NULL;

	radio_temp = (struct radio_temperature *)pkt;
	if (radio_temp == NULL) {
		debug(DEBUG_CAT_METRIC, "radio_temp is null");
		return -1;
	}
	os_memcpy(radio_temp->identifier, radio_info->identifier, ETH_ALEN);
	radio_temp->temperature = radio_info->temperature;
	return 0;
}
#endif

#ifdef MAP_R3_WF6
/**
* @brief Fn to append sta traffic stats
*
* @param pkt msg buffer where sta traffic stats to be appended
* @param stats stats_db
*
* @return 0 if success else -1
*/
unsigned short append_assoc_wf6_sta_status_tlv(unsigned char *pkt, struct assoc_wf6_sta_db *assoc_wf6_sta)
{
	struct assoc_wifi6_sta_status_tlv *wf6_sta;
	int i = 0;

	wf6_sta = (struct assoc_wifi6_sta_status_tlv *)pkt;

	memcpy(wf6_sta->mac, assoc_wf6_sta->mac, ETH_ALEN);
	wf6_sta->tid_cnt = MAX_TID;

	for(i = 0; i < MAX_TID; i++) {
		wf6_sta->status_tlv[i].tid = assoc_wf6_sta->status_tlv[i].tid;
		wf6_sta->status_tlv[i].tid_q_size = assoc_wf6_sta->status_tlv[i].tid_q_size;
	}

	return 0;
}
#endif

/**
* @brief Fn to append sta link metrics
*
* @param pkt buffer where data needs to be appended
* @param metrics sta link metrics db
*
* @return -1 if error else 0
*/
unsigned short append_sta_link_metrics_tlv(unsigned char *pkt, struct associated_clients *metrics)
{
	struct link_metrics *link_met;

	link_met = (struct link_metrics *)pkt;

	memcpy(link_met->mac, metrics->client_addr, ETH_ALEN);
	memcpy(link_met->bssid, metrics->bss->bssid, ETH_ALEN);

	link_met->time_delta = metrics->time_delta;
	link_met->erate_downlink = metrics->erate_downlink;
	link_met->erate_uplink = metrics->erate_uplink;
	link_met->time_delta = metrics->time_delta;
	link_met->rssi_uplink = rssi_to_rcpi((signed char)metrics->rssi_uplink);

	return 0;
}
unsigned short append_one_sta_link_metrics_tlv(unsigned char *pkt, struct metrics_db*metrics)
{
	struct link_metrics *link_met;

	link_met = (struct link_metrics *)pkt;

	memcpy(link_met->mac, metrics->mac, 6);
	memcpy(link_met->bssid, metrics->bssid, 6);

	link_met->time_delta = metrics->time_delta;
	link_met->erate_downlink = metrics->erate_downlink;
	link_met->erate_uplink = metrics->erate_uplink;
	link_met->time_delta = metrics->time_delta;
	link_met->rssi_uplink = rssi_to_rcpi((signed char)metrics->rssi_uplink);

	return 0;
}

#ifdef MAP_R6
unsigned short append_one_sta_link_metrics_mld_tlv(unsigned char *pkt, struct metrics_db *metrics)
{
	struct link_metrics *link_met;

	link_met = (struct link_metrics *)pkt;

	memcpy(link_met->mac, metrics->mac, ETH_ALEN);
	memcpy(link_met->bssid, metrics->bssid, ETH_ALEN);

	link_met->time_delta = metrics->time_delta;
	link_met->erate_downlink = metrics->erate_downlink;
	link_met->erate_uplink = metrics->erate_uplink;
	link_met->time_delta = metrics->time_delta;
	link_met->rssi_uplink = rssi_to_rcpi((signed char)metrics->rssi_uplink);

	return 0;
}

unsigned short append_one_sta_link_ext_metrics_mld_tlv(unsigned char *pkt, struct metrics_db *metrics)
{
	struct sta_extended_metrics_lib *link_met = NULL;

	link_met = (struct sta_extended_metrics_lib *)pkt;

	memcpy(link_met->sta_mac, metrics->mac, 6);
	memcpy(link_met->metric_info[0].bssid, metrics->bssid, 6);

	link_met->extended_metric_cnt = 1;
	link_met->metric_info[0].last_data_dl_rate = metrics->sta_ext_info.last_data_dl_rate;
	link_met->metric_info[0].last_data_ul_rate = metrics->sta_ext_info.last_data_ul_rate;
	link_met->metric_info[0].utilization_rx = metrics->sta_ext_info.utilization_rx;
	link_met->metric_info[0].utilization_tx = metrics->sta_ext_info.utilization_tx;

	return 0;
}

unsigned short append_mlo_ap_ext_metrics_tlv(unsigned char *pkt, struct bss_info_db *metrics)
{
	struct mlo_ap_extended_metrics_lib *link_met = NULL;

	link_met = (struct mlo_ap_extended_metrics_lib *)pkt;

	os_memcpy(link_met->bssid, metrics->bssid, ETH_ALEN);
	link_met->mlo_pkts_tx = metrics->mlo_pkts_tx;
	link_met->mlo_pkts_rx = metrics->mlo_pkts_rx;
	link_met->mlo_tx_pkts_error_count = metrics->mlo_tx_pkts_error_count;
	link_met->mlo_bc_rx = metrics->mlo_bc_rx;
	link_met->mlo_bc_tx = metrics->mlo_bc_tx;
	link_met->mlo_mc_rx = metrics->mlo_mc_rx;
	link_met->mlo_mc_tx = metrics->mlo_mc_tx;
	link_met->mlo_uc_rx = metrics->mlo_uc_rx;
	link_met->mlo_uc_tx = metrics->mlo_uc_tx;
	debug(DEBUG_CAT_METRIC,
	 "tx_pkts: %d, rx_pkts: %d, tx_error_cnt: %d, bc_rx: %d, bc_tx: %d, mc_rx: %d, mc_tx: %d, uc_rx: %d, uc_tx: %d\n",
	  link_met->mlo_tx_pkts_error_count,
		link_met->mlo_pkts_tx,
		link_met->mlo_pkts_rx,
		link_met->mlo_bc_rx,
		link_met->mlo_bc_tx,
		link_met->mlo_mc_rx,
		link_met->mlo_mc_tx,
		link_met->mlo_uc_rx,
		link_met->mlo_uc_tx);

	return 0;
}
#endif

#ifdef MAP_R2
unsigned short append_ap_ext_metrics_tlv(unsigned char *pkt, struct bss_info_db *metrics)
{
	struct ap_extended_metrics_lib *link_met = NULL;

	link_met = (struct ap_extended_metrics_lib *)pkt;

	os_memcpy(link_met->bssid, metrics->bssid, ETH_ALEN);
	link_met->bc_rx = metrics->bc_rx;
	link_met->bc_tx = metrics->bc_tx;
	link_met->mc_rx = metrics->mc_rx;
	link_met->mc_tx = metrics->mc_tx;
	link_met->uc_rx = metrics->uc_rx;
	link_met->uc_tx = metrics->uc_tx;
	debug(DEBUG_CAT_METRIC, "bc_rx: %d, bc_tx: %d, mc_rx: %d, mc_tx: %d, uc_rx: %d, uc_tx: %d",
		link_met->bc_rx,
		link_met->bc_tx,
		link_met->mc_rx,
		link_met->mc_tx,
		link_met->uc_rx,
		link_met->uc_tx);

	return 0;
}
unsigned short append_sta_link_ext_metrics_tlv(unsigned char *pkt, struct associated_clients *metrics)
{
	struct sta_extended_metrics_lib *link_met = NULL;

	link_met = (struct sta_extended_metrics_lib *)pkt;

	memcpy(link_met->sta_mac, metrics->client_addr, ETH_ALEN);
	memcpy(link_met->metric_info[0].bssid, metrics->bss->bssid, ETH_ALEN);

	link_met->extended_metric_cnt = 1;
	link_met->metric_info[0].last_data_dl_rate = metrics->sta_ext_info.last_data_dl_rate;
	link_met->metric_info[0].last_data_ul_rate = metrics->sta_ext_info.last_data_ul_rate;
	link_met->metric_info[0].utilization_rx = metrics->sta_ext_info.utilization_rx;
	link_met->metric_info[0].utilization_tx = metrics->sta_ext_info.utilization_tx;

	return 0;
}
unsigned short append_one_sta_link_ext_metrics_tlv(unsigned char *pkt, struct metrics_db *metrics)
{
	struct sta_extended_metrics_lib *link_met = NULL;

	link_met = (struct sta_extended_metrics_lib *)pkt;

	memcpy(link_met->sta_mac, metrics->mac, ETH_ALEN);
	memcpy(link_met->metric_info[0].bssid, metrics->bssid, ETH_ALEN);

	link_met->extended_metric_cnt = 1;
	link_met->metric_info[0].last_data_dl_rate = metrics->sta_ext_info.last_data_dl_rate;
	link_met->metric_info[0].last_data_ul_rate = metrics->sta_ext_info.last_data_ul_rate;
	link_met->metric_info[0].utilization_rx = metrics->sta_ext_info.utilization_rx;
	link_met->metric_info[0].utilization_tx = metrics->sta_ext_info.utilization_tx;

	return 0;
}

/**
* @brief Fn to fill ap metrics rsp message
*
* @param ctx own 1905 device ctx
* @param info ap_metrics_info_lib to be filled
* @param ap_metrics_info_cnt ap metrics count
* @param sta_stats sta stats to be filled
* @param sta_stats_cnt sta stats count
* @param sta_metrics sta metrics to be filled
* @param sta_metrics_cnt sta metrics count
*
* @return -1 if error else 0
*/
unsigned short topo_srv_sta_metrics_rsp_message(struct mapd_global *global, struct own_1905_device *ctx,
				struct link_metrics **sta_metrics, unsigned char *sta_metrics_cnt
#ifdef MAP_R2
				, struct sta_extended_metrics_lib **ext_sta_metric, unsigned char *ext_sta_met_cnt
#endif
			)
{
#ifdef MAP_R6
		uint32_t client_id;
		struct client *cli = NULL;
		struct associated_clients *tmp_client = NULL, *client = NULL;
		struct _1905_map_device *map_dev = topo_srv_get_1905_device(&global->dev, NULL);

		SLIST_FOREACH_SAFE(client, &(map_dev->assoc_clients), next_client, tmp_client) {
			info(DEBUG_CAT_METRIC, "looking for cli\n");
			client_id = client_db_get_cid_from_mld_mac(global, ctx->metric_entry.assoc_sta, 0);
			cli = client_db_get_client_from_client_id(global, client_id);
		}
		if (cli)
			info(DEBUG_CAT_METRIC, "cli was found\n");
		if (cli && cli->mlo_enable) {
			*sta_metrics_cnt = ctx->affiliated_sta_index;
			*sta_metrics = os_zalloc(sizeof(struct link_metrics) * (*sta_metrics_cnt));
			/*need to send affiliated_num times */
			for (int m = 0; m < *sta_metrics_cnt; m++)
				append_one_sta_link_metrics_mld_tlv((unsigned char *)*sta_metrics,
					&ctx->metric_entry.assoc_sta_link_metrics[m]);
			debug(DEBUG_CAT_METRIC, "sta metics info cnt=%d", *sta_metrics_cnt);
#ifdef MAP_R2
		if (ctx->map_version == DEV_TYPE_R2
#ifdef MAP_R3
		||	ctx->map_version == DEV_TYPE_R3
#endif
		) {
			*ext_sta_met_cnt = ctx->affiliated_sta_index;
			*ext_sta_metric = os_zalloc((sizeof(struct sta_extended_metrics_lib) +
					sizeof(struct extended_metrics_info)) * (*ext_sta_met_cnt));
			for (int n = 0; n < *ext_sta_met_cnt; n++)
				append_one_sta_link_ext_metrics_mld_tlv((unsigned char *)*ext_sta_metric,
					&ctx->metric_entry.assoc_sta_link_metrics[n]);
			err(DEBUG_CAT_METRIC, "ext sta metics info cnt=%d", *ext_sta_met_cnt);
		}
		return 0;
	}
#endif
#endif
	*sta_metrics_cnt = 1;
	*sta_metrics = os_zalloc(sizeof(struct link_metrics) * (*sta_metrics_cnt));

#ifdef MAP_R6
	append_one_sta_link_metrics_tlv((unsigned char *)*sta_metrics, &ctx->metric_entry.assoc_sta_link_metrics[0]);
#else
	append_one_sta_link_metrics_tlv((unsigned char *)*sta_metrics, &ctx->metric_entry.assoc_sta_link_metrics);
#endif
	debug(DEBUG_CAT_METRIC, "sta metics info cnt=%d", *sta_metrics_cnt);

#ifdef MAP_R2
	if (ctx->map_version == DEV_TYPE_R2 
#ifdef MAP_R3	
	||	ctx->map_version == DEV_TYPE_R3
#endif	
		) 
	{
		*ext_sta_met_cnt = 1;
		*ext_sta_metric = os_zalloc((sizeof(struct sta_extended_metrics_lib) + sizeof(struct extended_metrics_info))* (*ext_sta_met_cnt));

#ifdef MAP_R6
		append_one_sta_link_ext_metrics_tlv((unsigned char *)*ext_sta_metric, &ctx->metric_entry.assoc_sta_link_metrics[0]);
#else
		append_one_sta_link_ext_metrics_tlv((unsigned char *)*ext_sta_metric, &ctx->metric_entry.assoc_sta_link_metrics);
#endif
		debug(DEBUG_CAT_METRIC, "ext sta metics info cnt=%d", *ext_sta_met_cnt);
	}
#endif
	return 0;

}
#endif

#ifdef EM_PLUS_SUPPORT
unsigned short topo_srv_radio_temperature_message(struct own_1905_device *ctx,
						struct radio_temperature **radio_temp, u8 *radio_cnt)
{
	struct radio_info_db *radio_db = NULL, *tradio_db = NULL;
	struct _1905_map_device *device = topo_srv_get_1905_device(ctx, NULL);
	struct mapd_global *global = ctx->back_ptr;
	struct mapd_radio_info *radio_info = NULL;
	unsigned char *tlv_temp_buf = NULL;
	unsigned char tmp_buf[MAP_MAX_RADIO * sizeof(struct radio_temperature)] = {0};

	tlv_temp_buf = tmp_buf;
	SLIST_FOREACH_SAFE(radio_db, &device->first_radio, next_radio, tradio_db) {
		radio_info = get_radio_info_by_radio_id(global, radio_db->identifier);
		if (!radio_info)
			continue;
		append_radio_temperature_tlv(tlv_temp_buf, radio_info);
		tlv_temp_buf += sizeof(struct radio_metrics_lib);
		*radio_cnt = *radio_cnt + 1;
		debug(DEBUG_CAT_METRIC, "radio metrics info cnt=%d", *radio_cnt);
	}

	if (*radio_cnt) {
		debug(DEBUG_CAT_METRIC, "radio_cnt memcpy");
		*radio_temp = os_zalloc(sizeof(struct radio_temperature) * (*radio_cnt));
		if (*radio_temp)
			os_memcpy(*radio_temp, tmp_buf, sizeof(struct radio_temperature) * (*radio_cnt));
	}
	return 0;
}
#endif


/**
* @brief Fn to fill ap metrics rsp message
*
* @param ctx own 1905 device ctx
* @param info ap_metrics_info_lib to be filled
* @param ap_metrics_info_cnt ap metrics count
* @param sta_stats sta stats to be filled
* @param sta_stats_cnt sta stats count
* @param sta_metrics sta metrics to be filled
* @param sta_metrics_cnt sta metrics count
* @param mlo_ext_ap_metrics count to be filled
* @return -1 if error else 0
*/
unsigned short topo_srv_ap_metrics_rsp_message(struct own_1905_device *ctx,
					       struct ap_metrics_info_lib **info, int *ap_metrics_info_cnt,
					       struct stat_info **sta_stats, int *sta_stats_cnt,
					       struct link_metrics **sta_metrics, int *sta_metrics_cnt
#ifdef MAP_R2					       
					       , struct ap_extended_metrics_lib **ext_ap_metric, int *ext_ap_met_cnt,
					       struct sta_extended_metrics_lib **ext_sta_metric, int *ext_sta_met_cnt,
							struct radio_metrics_lib **info_radio, int *radio_metrics_info_cnt,
							struct ch_util_lib **ch_util, int *ch_util_cnt, unsigned char periodic
#endif
#ifdef MAP_R3_WF6
						, struct assoc_wifi6_sta_status_tlv_lib **wf6_sta, int *wf6_sta_cnt
#endif
#ifdef MAP_R6
						, struct mlo_ap_extended_metrics_lib **mlo_ext_ap_metric, int *mlo_ext_ap_met_cnt
						, struct stat_info **mld_sta_stats, int *mld_sta_stats_cnt
#endif
							)
{
	struct bss_info_db *mrsp = NULL;
	struct traffic_stats_db *traffic_stats = NULL, *t_traffic_stats = NULL;
	struct stats_db *stats = NULL, *tstats = NULL;
#ifdef MAP_R6
	u8 ZERO_MAC[ETH_ALEN] = {0};
#endif
#ifdef MAP_R2
	//struct metrics_db *metrics = NULL;
#endif
	unsigned char *tlv_temp_buf = NULL;
	/* maximum sta connect limit is 256 , taking maximum size of structure as sta stats to avoid
	 * overflow of data in temporary buffer when the maximum sta connect.
	 */
	unsigned char tmp_buf[MAX_STA_CONNECT_LIMIT * sizeof(struct stat_info)] = {0};
	struct _1905_map_device *device = topo_srv_get_1905_device(ctx, NULL);
	struct bss_db *bss = NULL, *tbss = NULL;
	struct associated_clients *client = NULL, *tclient = NULL;
	struct metric_policy_db *policy = NULL, *tpolicy = NULL;
#ifdef MAP_R2
	struct mapd_radio_info *radio_info = NULL;
	struct mapd_global *global = ctx->back_ptr;
	int i;
	struct tlv_head vs;
	struct radio_info_db *radio_db = NULL, *tradio_db = NULL;
	struct _1905_map_device *cont = topo_srv_get_controller_device(ctx);
#endif
	int byte_cnt = 0;

	unsigned char zero_mac[6] = {0};
	int sta_i = 0;
	unsigned char *check_almac_stat = NULL;
	int mld_dev_break = 0;

#ifdef MAP_R2
	if (!cont) {
		err(DEBUG_CAT_METRIC, "can't found controller.\n");
		return -1;
	}
	if ((cont->map_version == DEV_TYPE_R2 && device->map_version == DEV_TYPE_R2)
#ifdef MAP_R3
		|| ((cont->map_version == DEV_TYPE_R3 || cont->map_version == DEV_TYPE_R2)
		  && device->map_version == DEV_TYPE_R3)
#endif
	)		
		byte_cnt = ctx->r2_ap_capab->byte_counter_units;
#endif

#ifdef MAP_R3_WF6
	struct assoc_wf6_sta_status_db *assoc_wf6_sta_status = NULL, *t_assoc_wf6_status = NULL;
	struct assoc_wf6_sta_db *assoc_wf6_sta = NULL, *t_assoc_wf6_sta = NULL;
#endif

	os_memset(tmp_buf, 0, sizeof(tmp_buf));
	tlv_temp_buf = tmp_buf;
	SLIST_FOREACH_SAFE(bss, &(ctx->metric_entry.metrics_query_head), bss_entry, tbss) {
		mrsp = topo_srv_get_bss_by_bssid(ctx, topo_srv_get_1905_device(ctx, NULL), bss->bssid);
		if (!mrsp) {
			err(DEBUG_CAT_METRIC, "failed to find AP with bssid "MACSTR"",
					MAC2STR(bss->bssid));
			continue;
		}
		append_ap_metrics_tlv(tlv_temp_buf, mrsp);
		tlv_temp_buf += sizeof(struct ap_metrics_info_lib);
		*ap_metrics_info_cnt = *ap_metrics_info_cnt + 1;
	}
	if (*ap_metrics_info_cnt) {
		*info = os_zalloc(sizeof(struct ap_metrics_info_lib) * (*ap_metrics_info_cnt));
		if (*info)
			os_memcpy(*info, tmp_buf, sizeof(struct ap_metrics_info_lib) * *ap_metrics_info_cnt);
	}

	os_memset(tmp_buf, 0, sizeof(tmp_buf));
	tlv_temp_buf = tmp_buf;
	
	SLIST_FOREACH_SAFE(traffic_stats, &ctx->metric_entry.traffic_stats_head, traffic_stats_entry, t_traffic_stats) {
		SLIST_FOREACH_SAFE(policy, &ctx->map_policy.mpolicy.policy_head, policy_entry, tpolicy) {
			if (os_memcmp(policy->identifier,traffic_stats->identifier,ETH_ALEN) == 0 &&
				policy->sta_stats_inclusion) {
				SLIST_FOREACH_SAFE(stats, &traffic_stats->stats_head, stats_entry, tstats) {
					if (*sta_stats_cnt >= MAX_STA_CONNECT_LIMIT)
						break;

					if (!os_memcmp(stats->mac, zero_mac, ETH_ALEN))
						continue;

					check_almac_stat = tmp_buf;
					mld_dev_break = 0;
					for (sta_i = 0; sta_i < *sta_stats_cnt; sta_i++) {
						debug(DEBUG_CAT_METRIC, "check_almac_stat: "MACSTR,
						MAC2STR(((struct stat_info *)check_almac_stat)->sta_mld_mac));
					if ((!is_zero_ether_addr(stats->sta_mld_mac) &&
					!is_zero_ether_addr(((struct stat_info *)check_almac_stat)->sta_mld_mac)) &&
					!os_memcmp(stats->sta_mld_mac,
					((struct stat_info *)check_almac_stat)->sta_mld_mac, ETH_ALEN)) {
						debug(DEBUG_CAT_METRIC, "stats->sta_mld_mac" MACSTR, MAC2STR(stats->sta_mld_mac));
						mld_dev_break = 1;
						break;
					}
					check_almac_stat += sizeof(struct stat_info);
					}

					if (mld_dev_break == 1)
						continue;

					append_sta_traffic_stats_tlv(ctx, tlv_temp_buf, stats, byte_cnt);
					tlv_temp_buf += sizeof(struct stat_info);
					*sta_stats_cnt = *sta_stats_cnt + 1;
					debug(DEBUG_CAT_METRIC, "sta stats info cnt=%d", *sta_stats_cnt);
				}
			}
		}
	}
	if (*sta_stats_cnt) {
		*sta_stats = os_zalloc(sizeof(struct stat_info) * (*sta_stats_cnt));
		if (*sta_stats)
			os_memcpy(*sta_stats, tmp_buf, (sizeof(struct stat_info) * (*sta_stats_cnt)));
	}

#ifdef MAP_R3_WF6
	os_memset(tmp_buf, 0, sizeof(tmp_buf));
	tlv_temp_buf = tmp_buf;
	SLIST_FOREACH_SAFE(assoc_wf6_sta_status, &ctx->metric_entry.assoc_wf6_sta_status_db_head, assoc_wf6_sta_status_entry, t_assoc_wf6_status) {
		SLIST_FOREACH_SAFE(assoc_wf6_sta, &assoc_wf6_sta_status->assoc_wf6_sta_db_head, assoc_wf6_sta_entry, t_assoc_wf6_sta) {
			if (*wf6_sta_cnt >= MAX_STA_CONNECT_LIMIT)
				break;

#ifdef EM_PLUS_SUPPORT
			if (!os_memcmp(assoc_wf6_sta->mac, zero_mac, ETH_ALEN))
				continue;
#endif /* EM_PLUS_SUPPORT */

			append_assoc_wf6_sta_status_tlv(tlv_temp_buf, assoc_wf6_sta);
			tlv_temp_buf += sizeof(struct assoc_wifi6_sta_status_tlv);
			*wf6_sta_cnt = *wf6_sta_cnt + 1;
			debug(DEBUG_CAT_METRIC, "sta stats info cnt=%d", *wf6_sta_cnt);
		}
	}
	if (*wf6_sta_cnt) {
		*wf6_sta = os_zalloc(sizeof(struct assoc_wifi6_sta_status_tlv) * (*wf6_sta_cnt));
		if (*wf6_sta)
			memcpy(*wf6_sta, tmp_buf, (sizeof(struct assoc_wifi6_sta_status_tlv) * (*wf6_sta_cnt)));
	}
#endif

#ifdef MAP_R6
	os_memset(tmp_buf, 0, sizeof(tmp_buf));
		tlv_temp_buf = tmp_buf;
		tbss = NULL;
		SLIST_FOREACH_SAFE(bss, &(ctx->metric_entry.metrics_query_head), bss_entry, tbss) {
		mrsp = topo_srv_get_bss_by_bssid(ctx, topo_srv_get_1905_device(ctx, NULL), bss->bssid);
		if (!mrsp) {
			err(DEBUG_CAT_METRIC, "failed to find AP with bssid "MACSTR"",
					MAC2STR(bss->bssid));
			continue;
		}
		/*send mlo_ap_ext_metrics_tlv only for mld bss */
		if (os_memcmp(mrsp->mlo_info.mld_addr, ZERO_MAC, ETH_ALEN)) {
			append_mlo_ap_ext_metrics_tlv(tlv_temp_buf, mrsp);
			tlv_temp_buf += sizeof(struct mlo_ap_extended_metrics_lib);
			*mlo_ext_ap_met_cnt = *mlo_ext_ap_met_cnt + 1;
			debug(DEBUG_CAT_METRIC, "mlo ap ext metics info cnt=%d", *mlo_ext_ap_met_cnt);
		}
	}
		if (*mlo_ext_ap_met_cnt) {
			*mlo_ext_ap_metric = os_zalloc(sizeof(struct mlo_ap_extended_metrics_lib) * (*mlo_ext_ap_met_cnt));
			if (*mlo_ext_ap_metric) {
				os_memcpy(*mlo_ext_ap_metric, tmp_buf,
					(sizeof(struct mlo_ap_extended_metrics_lib) * (*mlo_ext_ap_met_cnt)));
			}
		}

	os_memset(tmp_buf, 0, sizeof(tmp_buf));
	tlv_temp_buf = tmp_buf;

	/* Append Affiliated STA Traffic STATS TLV  for MLO*/
	SLIST_FOREACH_SAFE(traffic_stats, &ctx->metric_entry.traffic_stats_head, traffic_stats_entry, t_traffic_stats) {
		SLIST_FOREACH_SAFE(policy, &ctx->map_policy.mpolicy.policy_head, policy_entry, tpolicy) {
			if (os_memcmp(policy->identifier, traffic_stats->identifier, ETH_ALEN) == 0 &&
				policy->sta_stats_inclusion) {
				SLIST_FOREACH_SAFE(stats, &traffic_stats->stats_head, stats_entry, tstats) {
					if (*mld_sta_stats_cnt >= MAX_STA_CONNECT_LIMIT)
						break;
					if (is_zero_ether_addr(stats->sta_mld_mac)) {
						debug(DEBUG_CAT_METRIC, "STA MLD MAC ZERO");
						continue;
					}
					append_sta_mld_traffic_stats_tlv(tlv_temp_buf, stats, byte_cnt);
					tlv_temp_buf += sizeof(struct stat_info);
					*mld_sta_stats_cnt = *mld_sta_stats_cnt + 1;
					debug(DEBUG_CAT_METRIC, "mld sta stats info cnt=%d", *mld_sta_stats_cnt);
				}
			}
		}
	}

	if (*mld_sta_stats_cnt) {
		*mld_sta_stats = os_zalloc(sizeof(struct stat_info) * (*mld_sta_stats_cnt));
		if (*mld_sta_stats)
			os_memcpy(*mld_sta_stats, tmp_buf, (sizeof(struct stat_info) * (*mld_sta_stats_cnt)));
	}
#endif
	os_memset(tmp_buf, 0, sizeof(tmp_buf));
	tlv_temp_buf = tmp_buf;
	SLIST_FOREACH_SAFE(client, &device->assoc_clients, next_client, tclient) {
		tpolicy = NULL;
		SLIST_FOREACH_SAFE(policy, &ctx->map_policy.mpolicy.policy_head, policy_entry, tpolicy) {
			if (!client->bss->radio)
				err(DEBUG_CAT_METRIC, "bss radio is null");
			if (client->bss->radio && os_memcmp(policy->identifier, client->bss->radio->identifier, ETH_ALEN) == 0 &&
				policy->sta_metrics_inclusion) {
				if (*sta_metrics_cnt >= MAX_STA_CONNECT_LIMIT)
					break;

#ifdef EM_PLUS_SUPPORT
				if (!os_memcmp(client->client_addr, zero_mac, ETH_ALEN))
					continue;
#endif /* EM_PLUS_SUPPORT */

				append_sta_link_metrics_tlv(tlv_temp_buf, client);
				tlv_temp_buf += sizeof(struct link_metrics);
				*sta_metrics_cnt = *sta_metrics_cnt + 1;
				debug(DEBUG_CAT_METRIC, "sta metics info cnt=%d", *sta_metrics_cnt);
			}
		}
	}
	if (*sta_metrics_cnt) {
		*sta_metrics = os_zalloc(sizeof(struct link_metrics) * (*sta_metrics_cnt));
		if (*sta_metrics)
			os_memcpy(*sta_metrics, tmp_buf, (sizeof(struct link_metrics) * (*sta_metrics_cnt)));
	}
#ifdef MAP_R2
	os_memset(tmp_buf, 0, sizeof(tmp_buf));
	tlv_temp_buf = tmp_buf;
	tbss = NULL;
	SLIST_FOREACH_SAFE(bss, &(ctx->metric_entry.metrics_query_head), bss_entry, tbss) {
		mrsp = topo_srv_get_bss_by_bssid(ctx, topo_srv_get_1905_device(ctx, NULL), bss->bssid);
		if (!mrsp) {
			err(DEBUG_CAT_METRIC, "failed to find AP with bssid "MACSTR"",
					MAC2STR(bss->bssid));
			continue;
		}
		append_ap_ext_metrics_tlv(tlv_temp_buf, mrsp);
		tlv_temp_buf += sizeof(struct ap_extended_metrics_lib);
		*ext_ap_met_cnt = *ext_ap_met_cnt + 1;
		debug(DEBUG_CAT_METRIC, "ap ext metics info cnt=%d", *ext_ap_met_cnt);
	}
	if (*ext_ap_met_cnt) {
		*ext_ap_metric = os_zalloc(sizeof(struct ap_extended_metrics_lib) * (*ext_ap_met_cnt));
		if (*ext_ap_metric)
			os_memcpy(*ext_ap_metric, tmp_buf, (sizeof(struct ap_extended_metrics_lib) * (*ext_ap_met_cnt)));
	}

	os_memset(tmp_buf, 0, sizeof(tmp_buf));
	tlv_temp_buf = tmp_buf;
	if(periodic) {
		/*need to send:
		include one Radio Metrics TLV for each radio which it is operating*/
		SLIST_FOREACH_SAFE(radio_db,&device->first_radio,next_radio, tradio_db) {
			radio_info = get_radio_info_by_radio_id(global,radio_db->identifier);
			if(!radio_info)
				continue;
			debug(DEBUG_CAT_METRIC, "@@@MAP@@@ channel = %d", radio_info->channel);
			append_radio_metrics_tlv(tlv_temp_buf, radio_info);
			tlv_temp_buf += sizeof(struct radio_metrics_lib);
			*radio_metrics_info_cnt = *radio_metrics_info_cnt + 1;
			debug(DEBUG_CAT_METRIC, "radio metrics info cnt=%d", *radio_metrics_info_cnt);
		}
	} else {
		for(i = 0; i < ctx->metric_entry.total_radio_band; i++) {
			radio_info = get_radio_info_by_radio_id(global, ctx->metric_entry.radio_id[i].identifier);
			if(!radio_info)
				continue;
			debug(DEBUG_CAT_METRIC, "@@@MAP@@@ radio_idx = %d", radio_info->radio_idx);
			append_radio_metrics_tlv(tlv_temp_buf, radio_info);
			tlv_temp_buf += sizeof(struct radio_metrics_lib);
			*radio_metrics_info_cnt = *radio_metrics_info_cnt + 1;
			debug(DEBUG_CAT_METRIC, "radio metrics info cnt=%d", *radio_metrics_info_cnt);
		}
	}
	if (*radio_metrics_info_cnt) {
		debug(DEBUG_CAT_METRIC, "radio_metrics_info_cnt memcpy");
		*info_radio = os_zalloc(sizeof(struct radio_metrics_lib) * (*radio_metrics_info_cnt));
		if (*info_radio)
			os_memcpy(*info_radio, tmp_buf, sizeof(struct radio_metrics_lib) * *radio_metrics_info_cnt);
	}
	os_memset(tmp_buf, 0, sizeof(tmp_buf));
	tlv_temp_buf = tmp_buf;
	tclient = NULL;
	SLIST_FOREACH_SAFE(client, &device->assoc_clients, next_client, tclient) {
		tpolicy = NULL;
		SLIST_FOREACH_SAFE(policy, &ctx->map_policy.mpolicy.policy_head, policy_entry, tpolicy) {
			if (!client->bss) {
				err(DEBUG_CAT_METRIC, "bss is null");
				continue;
			}
			if (!client->bss->radio)
				err(DEBUG_CAT_METRIC, "bss radio is null");
			if (client->bss && client->bss->radio && os_memcmp(policy->identifier, client->bss->radio->identifier,
			 ETH_ALEN) == 0 && policy->sta_metrics_inclusion) {
				if (*ext_sta_met_cnt >= MAX_STA_CONNECT_LIMIT)
					break;

#ifdef EM_PLUS_SUPPORT
				if (!os_memcmp(client->client_addr, zero_mac, ETH_ALEN))
					continue;
#endif /* EM_PLUS_SUPPORT */

				append_sta_link_ext_metrics_tlv(tlv_temp_buf, client);
				tlv_temp_buf += (sizeof(struct sta_extended_metrics_lib) + sizeof(struct extended_metrics_info));
				*ext_sta_met_cnt = *ext_sta_met_cnt + 1;
				debug(DEBUG_CAT_METRIC, "ext sta metics info cnt=%d", *ext_sta_met_cnt);
			}
		}
	}
	if (*ext_sta_met_cnt) {
		*ext_sta_metric = os_zalloc((sizeof(struct sta_extended_metrics_lib) + sizeof(struct extended_metrics_info)) * (*ext_sta_met_cnt));
		if (*ext_sta_metric)
			os_memcpy(*ext_sta_metric, tmp_buf,
				((sizeof(struct sta_extended_metrics_lib) + sizeof(struct extended_metrics_info)) * (*ext_sta_met_cnt)));
	}
#if 1 
	os_memset(tmp_buf, 0, sizeof(tmp_buf));
	tlv_temp_buf = tmp_buf;
	if(periodic) {
		tradio_db = NULL;
		SLIST_FOREACH_SAFE(radio_db,&device->first_radio,next_radio, tradio_db) {
			radio_info = get_radio_info_by_radio_id(global,radio_db->identifier);
			if(!radio_info)
				continue;
			debug(DEBUG_CAT_METRIC, "@@@MAP@@@ radio_idx = %d", radio_info->radio_idx);
			append_ch_util_tlv(tlv_temp_buf, radio_info);
			tlv_temp_buf += sizeof(struct ch_util_lib);
			*ch_util_cnt = *ch_util_cnt + 1;
			debug(DEBUG_CAT_METRIC, "ch util cnt=%d", *ch_util_cnt);
		}
	} else {
		for(i = 0; i < ctx->metric_entry.total_radio_band; i++) {
			radio_info = get_radio_info_by_radio_id(global, ctx->metric_entry.radio_id[i].identifier);
			if(!radio_info)
				continue;
			debug(DEBUG_CAT_METRIC, "@@@MAP@@@ radio_idx = %d", radio_info->radio_idx);
			append_ch_util_tlv(tlv_temp_buf, radio_info);
			err_hexdump(DEBUG_CAT_METRIC, "ch util lib", tlv_temp_buf, sizeof(struct ch_util_lib));
			tlv_temp_buf += sizeof(struct ch_util_lib);
			*ch_util_cnt = *ch_util_cnt + 1;
			debug(DEBUG_CAT_METRIC, "ch util cnt=%d", *ch_util_cnt);
		}
	}
	if (*ch_util_cnt) {
		*ch_util = os_zalloc(sizeof(struct ch_util_lib) * (*ch_util_cnt) + sizeof(struct tlv_head));
		if (*ch_util == NULL) {
			*ch_util_cnt = 0;
			return -1;
		}
		vs.tlv_type = VENDOR_SPECIFIC_TLV_TYPE;
		vs.func_type = FUNC_VENDOR_CHANNEL_UTIL_RSP;
		os_memcpy(vs.oui, MTK_OUI, OUI_LEN);
		vs.tlv_len = OUI_LEN + sizeof(struct ch_util_lib) * (*ch_util_cnt) + 1;//1 is for function type len
		vs.tlv_len = host_to_be16(vs.tlv_len);
		char *temp_ch_util = (char *)*ch_util;
		os_memcpy(temp_ch_util, &vs, sizeof(struct tlv_head)) ;
		os_memcpy(temp_ch_util + sizeof(struct tlv_head), tmp_buf, sizeof(struct ch_util_lib) * *ch_util_cnt);
	}
	#endif
#endif
	return 0;

}
