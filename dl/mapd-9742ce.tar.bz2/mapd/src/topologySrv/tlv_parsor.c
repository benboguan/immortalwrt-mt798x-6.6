/*
 * ***************************************************************************
 * *  Mediatek Inc.
 * * 4F, No. 2 Technology 5th Rd.
 * * Science-based Industrial Park
 * * Hsin-chu, Taiwan, R.O.C.
 * *
 * * (c) Copyright 2002-2018, Mediatek, Inc.
 * *
 * * All rights reserved. Mediatek's source code is an unpublished work and the
 * * use of a copyright notice does not imply otherwise. This source code
 * * contains confidential trade secret material of Ralink Tech. Any attemp
 * * or participation in deciphering, decoding, reverse engineering or in any
 * * way altering the source code is stricitly prohibited, unless the prior
 * * written consent of Mediatek, Inc. is obtained.
 * ***************************************************************************
 *
 *  Module Name:
 *  1905 tlv parsor
 *
 *  Abstract:
 *  1905 tlv parsor
 *
 *  Revision History:
 *  Who         When          What
 *  --------    ----------    -----------------------------------------
 *  Kapil.Gupta 2018/05/02    First implementation of the 1905 tlv parsor
 * */

#include "includes.h"
#ifdef __linux__
#include <fcntl.h>
#endif				/* __linux__ */

#include "common.h"
#include <sys/un.h>

#include "interface.h"
#include "data_def.h"
#include "client_db.h"
#include "mapd_i.h"
#include "topologySrv.h"
#include "eloop.h"
#include "tlv_parsor.h"
#include "ap_est.h"
#include "ch_planning.h"
#include "network_optimization.h"
#include "mapd_user_iface.h"
#include "utils/list.h"
#include "ctrl_iface.h"
#include "chan_mon.h"
#include "ap_cent_str.h"
#include "mapfilter_if.h"
#ifdef MAP_R6
#include "mapd_afc.h"
#endif
#ifdef BR_IP_TLV_SUPPORT
#include <net/if.h>
#endif /* BR_IP_TLV_SUPPORT */
#ifdef CENT_STR
#include "1905_map_interface.h"
#endif
#include "wapp_if.h"
#ifdef DATA_ELEMENT_SUPPORT
#include "de2json.h"
#endif
#ifndef INT_MAX
#define INT_MAX 2147483647
#endif
extern u8 ZERO_MAC_ADDR[ETH_ALEN];
#ifndef MIN
#define MIN(a, b) (((a) < (b)) ? (a) : (b))
#endif

#ifdef MAP_R6
#define DOT11BE_MCS_NSS_MASK 0xf
#define DOT11BE_MCS_NSS_SHIFT 4
#endif

void mapd_user_eth_client_leave(
	struct mapd_global *global,
	unsigned char *sta_mac, unsigned char *bssid)
{
	struct mapd_user_iface_eth_client_event *client_notif = NULL;
	struct mapd_user_event *user_event = NULL;
	struct ctrl_iface_global_priv *priv = global->ctrl_iface;

	user_event = (struct mapd_user_event *)os_zalloc(sizeof(struct mapd_user_event) +
		sizeof(struct mapd_user_iface_eth_client_event));
	if (!user_event) {
		err(DEBUG_CAT_TLVPRS, "mem alloc failed\n");
		return;
	}
	os_memset(user_event, 0, sizeof(struct mapd_user_event) +
		sizeof(struct mapd_user_iface_eth_client_event));

	user_event->event_id = ETHERNET_CLIENT_LEAVE_NOTIF;
	client_notif = (struct mapd_user_iface_eth_client_event *)user_event->event_body;

	os_memcpy(client_notif->sta_mac, sta_mac, ETH_ALEN);
	os_memcpy(client_notif->almac, bssid, ETH_ALEN);
	if (!dl_list_empty(&priv->ctrl_dst)) {
		mapd_ctrl_iface_send(global,
							priv->sock,
							&priv->ctrl_dst,
							(const char *)user_event, sizeof(struct mapd_user_event) +
							sizeof(struct mapd_user_iface_eth_client_event),
							priv);
	}
	os_free(user_event);
}
void mapd_user_eth_client_join(
	struct mapd_global *global,
	unsigned char *sta_mac, unsigned char *bssid)
{
	struct mapd_user_iface_eth_client_event *client_notif = NULL;
	struct mapd_user_event *user_event = NULL;
	struct ctrl_iface_global_priv *priv = global->ctrl_iface;

	user_event = (struct mapd_user_event *)os_zalloc(sizeof(struct mapd_user_event) +
		sizeof(struct mapd_user_iface_eth_client_event));
	if (!user_event) {
		err(DEBUG_CAT_TLVPRS, "mem alloc failed\n");
		return;
	}
	os_memset(user_event, 0, sizeof(struct mapd_user_event) +
		sizeof(struct mapd_user_iface_eth_client_event));

	user_event->event_id = ETHERNET_CLIENT_JOIN_NOTIF;
	client_notif = (struct mapd_user_iface_eth_client_event *)user_event->event_body;

	os_memcpy(client_notif->sta_mac, sta_mac, ETH_ALEN);
	os_memcpy(client_notif->almac, bssid, ETH_ALEN);
	if (!dl_list_empty(&priv->ctrl_dst)) {
		mapd_ctrl_iface_send(global,
							priv->sock,
							&priv->ctrl_dst,
							(const char *)user_event, sizeof(struct mapd_user_event) +
							sizeof(struct mapd_user_iface_eth_client_event),
							priv);
	}
	os_free(user_event);
}

void mapd_user_wireless_client_join(
	struct mapd_global *global,
	unsigned char *sta_mac, unsigned char *bssid, char *ssid)
{
	struct mapd_user_iface_wireless_client_event *client_notif = NULL;
	struct mapd_user_event *user_event = NULL;
	struct ctrl_iface_global_priv *priv = global->ctrl_iface;

	user_event = (struct mapd_user_event *)os_zalloc(sizeof(struct mapd_user_event) +
		sizeof(struct mapd_user_iface_wireless_client_event));
	if (!user_event) {
		err(DEBUG_CAT_TLVPRS, "mem alloc failed\n");
		return;
	}
	os_memset(user_event, 0, sizeof(struct mapd_user_event) +
		sizeof(struct mapd_user_iface_wireless_client_event));

	user_event->event_id = WIRELESS_CLIENT_JOIN_NOTIF;
	client_notif = (struct mapd_user_iface_wireless_client_event *)user_event->event_body;

	os_memcpy(client_notif->sta_mac, sta_mac, ETH_ALEN);
	os_memcpy(client_notif->bssid, bssid, ETH_ALEN);
	if (strlen(ssid) <= MAX_SSID_LEN +1)
		os_memcpy(client_notif->ssid, ssid, strlen(ssid));
	if (!dl_list_empty(&priv->ctrl_dst)) {
		mapd_ctrl_iface_send(global,
							priv->sock,
							&priv->ctrl_dst,
							(const char *)user_event, sizeof(struct mapd_user_event) +
							sizeof(struct mapd_user_iface_wireless_client_event),
							priv);
	}
	os_free(user_event);
}


void mapd_user_wireless_client_leave(
	struct mapd_global *global,
	unsigned char *sta_mac, unsigned char *bssid, char *ssid)
{
	struct mapd_user_iface_wireless_client_event *client_notif = NULL;
	struct mapd_user_event *user_event = NULL;
	struct ctrl_iface_global_priv *priv = global->ctrl_iface;

	user_event = (struct mapd_user_event *)os_zalloc(sizeof(struct mapd_user_event) +
		sizeof(struct mapd_user_iface_wireless_client_event));
	if (!user_event) {
		err(DEBUG_CAT_TLVPRS, "mem alloc failed\n");
		return;
	}
	os_memset(user_event, 0, sizeof(struct mapd_user_event) +
		sizeof(struct mapd_user_iface_wireless_client_event));

	user_event->event_id = WIRELESS_CLIENT_LEAVE_NOTIF;
	client_notif = (struct mapd_user_iface_wireless_client_event *)user_event->event_body;

	os_memcpy(client_notif->sta_mac, sta_mac, ETH_ALEN);
	os_memcpy(client_notif->bssid, bssid, ETH_ALEN);
	if (strlen(ssid) <= MAX_SSID_LEN +1)
		os_memcpy(client_notif->ssid, ssid, strlen(ssid));
	if (!dl_list_empty(&priv->ctrl_dst)) {
		mapd_ctrl_iface_send(global,
							priv->sock,
							&priv->ctrl_dst,
							(const char *)user_event, sizeof(struct mapd_user_event) +
							sizeof(struct mapd_user_iface_wireless_client_event),
							priv);
	}
	os_free(user_event);
}
void mapd_user_conn_fail_notify(
	struct mapd_global *global,
	unsigned char *buf, int buf_len)
{
	struct mapd_user_conn_fail_event *conn_fail_info = NULL;
	struct mapd_user_event *user_event = NULL;
	struct ctrl_iface_global_priv *priv = global->ctrl_iface;

	user_event = (struct mapd_user_event *)os_zalloc(sizeof(struct mapd_user_event) +
		sizeof(struct mapd_user_conn_fail_event));
	if (!user_event) {
		err(DEBUG_CAT_TLVPRS, "mem alloc failed\n");
		return;
	}
	os_memset(user_event, 0, sizeof(struct mapd_user_event) +
		sizeof(struct mapd_user_conn_fail_event));

	user_event->event_id = SEC_CONNECTION_FAILURE;
	conn_fail_info = (struct mapd_user_conn_fail_event *)user_event->event_body;

	os_memcpy(conn_fail_info->reason, buf, MIN(buf_len, sizeof(conn_fail_info->reason)));
	if (!dl_list_empty(&priv->ctrl_dst)) {
		mapd_ctrl_iface_send(global,
							priv->sock,
							&priv->ctrl_dst,
							(const char *)user_event, sizeof(struct mapd_user_event) +
							sizeof(struct mapd_user_conn_fail_event),
							priv);
	}
	os_free(user_event);
}
void mapd_user_fail_notify(
	struct mapd_global *global,
	unsigned char *buf, int buf_len)
{
	struct mapd_user_fail_event *fail_info = NULL;
	struct mapd_user_event *user_event = NULL;
	struct ctrl_iface_global_priv *priv = global->ctrl_iface;

	user_event = (struct mapd_user_event *)os_zalloc(sizeof(struct mapd_user_event) +
		sizeof(struct mapd_user_fail_event));
	if (!user_event) {
		err(DEBUG_CAT_TLVPRS, "mem alloc failed\n");
		return;
	}
	os_memset(user_event, 0, sizeof(struct mapd_user_event) +
		sizeof(struct mapd_user_fail_event));

	user_event->event_id = USER_FAIL_EVENTS;
	fail_info = (struct mapd_user_fail_event *)user_event->event_body;
	os_memcpy((char *)fail_info, buf, buf_len);
	err(DEBUG_CAT_TLVPRS, "when sending: %s\n", fail_info->reason);
	if (!dl_list_empty(&priv->ctrl_dst)) {
		mapd_ctrl_iface_send(global,
							priv->sock,
							&priv->ctrl_dst,
							(const char *)user_event, sizeof(struct mapd_user_event) +
							sizeof(struct mapd_user_fail_event),
							priv);
	}
	os_free(user_event);
}


/**
* @brief Fn to get tlv lenght
*
* @param buf msg buff
*
* @return tlv lenght
*/
int get_cmdu_tlv_length(unsigned char *buf)
{
	unsigned char *temp_buf = buf;
	int length = 0;

	temp_buf += 1;		//shift to length field

	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length | (*(temp_buf + 1));

	return (length + 3);
}

/**
* @brief Parse backhaul sterring tlv
*
* @param buf msg buff
* @param ctx own 1905 device ctx
*
* @return tlv lenght parsed if success else -1
*/
int parse_backhaul_steering_request_tlv(unsigned char *buf,
		struct own_1905_device *ctx)
{
	unsigned char *temp_buf = NULL;
	unsigned char *check_buf = NULL;
	unsigned short length = 0;

	temp_buf = buf;
	check_buf = buf;

	if ((*temp_buf) == BACKHAUL_STEERING_REQUEST_TYPE) {
		temp_buf++;
	} else {
		err(DEBUG_CAT_TLVPRS, "should not go here\n");
		return -1;
	}

	//calculate tlv length
	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length | (*(temp_buf + 1));

	if (!check_fixed_length_tlv(BACKHAUL_STEERING_REQUEST_TYPE_LEN, check_buf, length)) {
		err(DEBUG_CAT_TLVPRS, "error BACKHAUL_STEERING_REQUEST_TYPE length is %d incorrect\n", length);
		return -1;
	}

	//shift to tlv value field
	temp_buf += 2;

	memcpy(ctx->bsteer_req.backhaul_mac, temp_buf, ETH_ALEN);
	temp_buf += ETH_ALEN;
	memcpy(ctx->bsteer_req.target_bssid, temp_buf, ETH_ALEN);
	temp_buf += ETH_ALEN;
	ctx->bsteer_req.oper_class = *temp_buf++;
	ctx->bsteer_req.channel = *temp_buf++;

	debug(DEBUG_CAT_TLVPRS, "backhaul_mac("MACSTR") target_bssid("MACSTR
	") operating class=%d, channel=%d\n",
			MAC2STR(ctx->bsteer_req.backhaul_mac),
			MAC2STR(ctx->bsteer_req.target_bssid),
			ctx->bsteer_req.oper_class, ctx->bsteer_req.channel);
	return (length + 3);
}

/**
* @brief Fn to update global steering params
*
* @param ctx own 1905 device ctx
* @param policy steering policy
*
* @return 0 if success else -1
*/
extern int8_t NOISE_OFFSET_BY_CH_WIDTH[];
int topo_srv_update_global_steer_params(struct own_1905_device *ctx, struct radio_policy_db *policy)
{
	struct radio_info_db *radio;
	struct steer_params *cli_steer = &ctx->cli_steer_params;

	radio = topo_srv_get_radio(topo_srv_get_1905_device(ctx, NULL), policy->identifier);
	if (!radio) {
		err(DEBUG_CAT_TLVPRS, "failed to found radio\n");
		return -1;
	}
	if (get_band_from_channel(radio->channel[0]) == BAND_5GH) {
		cli_steer->CUOverloadTh_5G_H = policy->ch_util_thres;
	} else if (get_band_from_channel(radio->channel[0]) == BAND_5GL) {
		cli_steer->CUOverloadTh_5G_L = policy->ch_util_thres;
	} else if (get_band_from_channel(radio->channel[0]) == BAND_2G) {
		cli_steer->CUOverloadTh_2G = policy->ch_util_thres;
	}
	cli_steer->LowRSSIAPSteerEdge_RE = policy->rssi_thres - NOISE_OFFSET_BY_CH_WIDTH[0];
	policy->rssi_thres = cli_steer->LowRSSIAPSteerEdge_RE;
	if (policy->steer_policy == AGENT_STEER_DISALLOWED)
		cli_steer->disable_post_assoc_strng = 1;
	else
		cli_steer->disable_post_assoc_strng = 0;

	return 0;
}

/**
* @brief Fn to get radio sterring policy
*
* @param ctx own 1905 device ctx
* @param identifier radio identifier
* @param radio_policy steering policy to be filled
*
* @return 0 if sccess else -1
*/
int topo_srv_get_radio_steer_policy(struct own_1905_device *ctx, unsigned char *identifier, int8_t *radio_policy)
{
	struct radio_policy_db *policy, *tpolicy = NULL;

	SLIST_FOREACH_SAFE(policy, &ctx->map_policy.spolicy.radio_policy_head, radio_policy_entry, tpolicy) {
		if (os_memcmp(policy->identifier, identifier, ETH_ALEN) == 0) {
			*radio_policy = policy->steer_policy;
			return 0;
		}
	}

	return -1;
}
/**
* @brief Fn to get rssi threshould by steer policy
*
* @param ctx own 1905 device ctx
* @param identifier radio identifier
* @param rssi rssi threshould to be filled
*
* @return 0 if success else -1
*/
int topo_srv_get_rssi_th_by_policy(struct own_1905_device *ctx, struct mapd_radio_info *radio_info , int8_t *rssi)
{
	struct radio_policy_db *policy, *tpolicy = NULL;

	SLIST_FOREACH_SAFE(policy, &ctx->map_policy.spolicy.radio_policy_head, radio_policy_entry, tpolicy) {
		if (memcmp(policy->identifier, radio_info->identifier, ETH_ALEN) == 0) {
			*rssi = policy->rssi_thres + ap_est_get_noise_offset(ctx->back_ptr,radio_info->radio_idx);
			return 0;
		}
	}

	return -1;
}

/**
* @brief Fn to parse steer policy tlv
*
* @param buf msg buf
* @param ctx own 1905 device ctx
*
* @return -1 if error else tlv lenght
*/
int parse_steering_policy_tlv(unsigned char *buf, struct own_1905_device *ctx)
{
	unsigned char *temp_buf;
	unsigned short length = 0;
	int i =0;
	struct sta_db *sta = NULL;
	struct radio_policy_db *radio_policy = NULL;
	struct steer_policy *spolicy = &ctx->map_policy.spolicy;

	temp_buf = buf;

	if((*temp_buf) == STEERING_POLICY_TYPE) {
		temp_buf++;
	}
	else {
		err(DEBUG_CAT_TLVPRS, "should not go here\n");
		return -1;
	}

	//calculate tlv length
	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length |(*(temp_buf+1));

	//shift to tlv value field
	temp_buf += 2;

	spolicy->local_disallow_count = *temp_buf++;
	for (i = 0; i < spolicy->local_disallow_count; i++) {
		sta = (struct sta_db *)os_malloc(sizeof(struct sta_db));
		if (!sta) {
			err(DEBUG_CAT_TLVPRS, "alloc struct sta_db for local_disallow_head fail\n");
			return -1;
		}
		memcpy(sta->mac, temp_buf, ETH_ALEN);
		temp_buf += ETH_ALEN;
		SLIST_INSERT_HEAD(&spolicy->local_disallow_head, sta, sta_entry);
	}
	spolicy->btm_disallow_count = *temp_buf++;
	for (i = 0; i < spolicy->btm_disallow_count; i++) {
		sta = (struct sta_db *)os_malloc(sizeof(struct sta_db));
		if (!sta) {
			err(DEBUG_CAT_TLVPRS, "alloc struct sta_db for btm_disallow_head fail\n");
			return -1;
		}
		memcpy(sta->mac, temp_buf, ETH_ALEN);
		temp_buf += ETH_ALEN;
		SLIST_INSERT_HEAD(&spolicy->btm_disallow_head, sta, sta_entry);
	}

	spolicy->radios = *temp_buf++;
	for (i = 0; i < spolicy->radios; i++) {
		radio_policy = (struct radio_policy_db *)os_malloc(sizeof(struct radio_policy_db));
		if (!radio_policy) {
			err(DEBUG_CAT_TLVPRS, "alloc struct radio_policy_db fail\n");
			return -1;
		}
		memcpy(radio_policy->identifier, temp_buf, ETH_ALEN);
		temp_buf += ETH_ALEN;
		radio_policy->steer_policy = *temp_buf++;
		radio_policy->ch_util_thres = *temp_buf++;
		radio_policy->rssi_thres = *temp_buf++;
		radio_policy->rssi_thres = rcpi_to_rssi(radio_policy->rssi_thres);
		SLIST_INSERT_HEAD(&spolicy->radio_policy_head, radio_policy, radio_policy_entry);
		topo_srv_update_global_steer_params(ctx, radio_policy);
	}
	return (length+3);
}
int parse_bh_assoc_ctrl_policy_tlv(unsigned char *buf,
		struct own_1905_device *ctx)
{
	unsigned char *temp_buf;
	unsigned short length = 0;
	struct bh_bss_assoc_ctrl_setting bh_setting = {0};

	temp_buf = buf;
	if ((*temp_buf) == BACKHAUL_BSS_CONFIG_TYPE)
		temp_buf++;
	else {
		err(DEBUG_CAT_TLVPRS, "should not go here\n");
		return -1;
	}
	/*calculate tlv length*/
	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length | (*(temp_buf+1));
	/*shift to tlv value field*/
	temp_buf += 2;
	os_memcpy(bh_setting.BSSID, temp_buf, ETH_ALEN);
	temp_buf += ETH_ALEN;
	if (*temp_buf & 0x80)
		bh_setting.P1_disallow = 1;
	if (*temp_buf & 0x40)
		bh_setting.P2_disallow = 1;
	notice(DEBUG_CAT_TLVPRS, "send BH setting to wapp for BSSID "MACSTR", P1 disallow %d , P2 disallow %d\n",
		MAC2STR(bh_setting.BSSID),
		bh_setting.P1_disallow,
		bh_setting.P2_disallow);
	wlanif_issue_wapp_command((struct mapd_global *)ctx->back_ptr,
						WAPP_USER_SEND_BH_BSS_CONFIG, 0, NULL, NULL,
						(void *)&bh_setting, sizeof(struct bh_bss_assoc_ctrl_setting), 0, 0, 0);
	return (length+3);
}

/**
* @brief Fn to parse metric policy tlv
*
* @param buf msg buf
* @param ctx own 1905 device ctx
*
* @return -1 if error else tlv lenght
*/
int parse_metric_reporting_policy_tlv(unsigned char *buf,
		struct own_1905_device *ctx)
{
	unsigned char *temp_buf;
	unsigned short length = 0, i =0;
	struct metric_policy_db *metric_policy = NULL;
	struct metrics_policy *mpolicy = &ctx->map_policy.mpolicy;

	temp_buf = buf;

	if((*temp_buf) == METRIC_REPORTING_POLICY_TYPE) {
		temp_buf++;
	}
	else {
		err(DEBUG_CAT_TLVPRS, "should not go here\n");
		return -1;
	}

	//calculate tlv length
	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length |(*(temp_buf+1));

	//shift to tlv value field
	temp_buf += 2;

	mpolicy->report_interval = *temp_buf++;
	mpolicy->radio_num = *temp_buf++;
	for (i = 0; i < mpolicy->radio_num; i++) {
		metric_policy = (struct metric_policy_db *)os_malloc(sizeof(struct metric_policy_db));
		if (!metric_policy) {
			err(DEBUG_CAT_TLVPRS, "alloc struct metric_policy_db fail\n");
			return -1;
		}
		memcpy(metric_policy->identifier, temp_buf, ETH_ALEN);
		temp_buf += ETH_ALEN;
		metric_policy->rssi_thres = *temp_buf++;
		metric_policy->hysteresis_margin = *temp_buf++;
		metric_policy->ch_util_thres = *temp_buf++;
		metric_policy->sta_stats_inclusion = (*temp_buf & 0x80) >> 7;
		metric_policy->sta_metrics_inclusion = (*temp_buf & 0x40) >> 6;
#ifdef MAP_R3_WF6
		metric_policy->assoc_wf6_inclusion = (*temp_buf & 0x20) >> 5;
#endif
		temp_buf += 1;
		SLIST_INSERT_HEAD(&mpolicy->policy_head, metric_policy, policy_entry);
	}
	return (length+3);
}

int parse_client_steering_btm_report_tlv(struct own_1905_device * ctx, struct _1905_map_device *dev, unsigned char *buf)
{
	unsigned char *temp_buf = NULL;
	unsigned short length = 0;
	unsigned char client_mac[ETH_ALEN] = {0};
	struct client* cli = NULL;
	unsigned char btm_status = 0;

	temp_buf = buf;


	//calculate tlv length
	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length |(*(temp_buf+1));

	//shift to tlv value field
	temp_buf += 2;

	if (!(length == CLIENT_STEERING_BTM_REPORT_MIN ||
		length == CLIENT_STEERING_BTM_REPORT_MAX)) {
		err(DEBUG_CAT_TLVPRS, "error CLIENT_STEERING_BTM_REPORT length is %d incorrect\n", length);
		return -1;
	}

	//skip bssid field
	temp_buf += ETH_ALEN;

	//sta mac address
	os_memcpy(client_mac, temp_buf, ETH_ALEN);

	cli = client_db_get_client_from_sta_mac(ctx->back_ptr, client_mac);
	temp_buf += ETH_ALEN;

	btm_status = *temp_buf;
#ifdef CENT_STR
	if(ctx->cent_str_en && cli ) {
		if(btm_status > 0 ) {
			debug(DEBUG_CAT_TLVPRS, CENT_STEER_PREX" btm fail report status:%d\n", btm_status);
			steer_fsm_trigger(ctx->back_ptr, cli->client_id, BTM_FAILURE, NULL);
		}
		else {
			debug(DEBUG_CAT_TLVPRS, CENT_STEER_PREX"btm success report status:%d\n", btm_status);
			steer_fsm_trigger(ctx->back_ptr, cli->client_id, BTM_SUCCESS, NULL);
		}
	}
#endif
	return (length+3);
}

int parse_client_steering_btm_report_message(struct own_1905_device *ctx, struct _1905_map_device *dev,
						unsigned char *buf, unsigned short len)
{
	int length =0;
	unsigned char *temp_buf;
	temp_buf = buf;
	unsigned short check_len = 0;
	unsigned short tlv_len = 0;

	while(1)
	{
		check_len = get_tlv_len(temp_buf);
		tlv_len = check_len + 3;

		if (len < tlv_len) {
			err(DEBUG_CAT_TLVPRS, "Error TLV len, type = %d, len %d less than tlv_len %d\n",
				*temp_buf, len, tlv_len);
			return -1;
		}
		if(*temp_buf == STEERING_BTM_REPORT_TYPE)
		{
			length = parse_client_steering_btm_report_tlv(ctx, dev, temp_buf + 1);

			if(length < 0)
			{
				err(DEBUG_CAT_TLVPRS, "error client steering btm report tlv\n");
				return -1;
			}
			temp_buf += length;
		} else if(*temp_buf == END_OF_TLV_TYPE) {
			break;
		} else {
			length = get_cmdu_tlv_length(temp_buf);
			temp_buf += length;
		}
		len -= tlv_len;
	}

	return 0;
}

/**
* @brief Fn to parse ap metrics policy tlv
*
* @param buf msg buf
* @param ctx own 1905 device ctx
*
* @return -1 if error else tlv lenght
*/
int parse_ap_metrics_query_tlv(unsigned char *buf, struct own_1905_device *ctx)
{
	unsigned char *temp_buf = NULL;
	unsigned short length = 0;
	int i = 0;
	struct bss_db *bss = NULL, *tmp_bss = NULL;
	int bss_cnt = 0;

	temp_buf = buf;

	if ((*temp_buf) == AP_METRICS_QUERY_TYPE) {
		temp_buf++;
	} else {
		err(DEBUG_CAT_TLVPRS, "should not go here\n");
		return -1;
	}

	//calculate tlv length
	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length | (*(temp_buf + 1));

	//shift to tlv value field
	temp_buf += 2;

	/*bssid num */
	temp_buf += 1;

	bss_cnt = (length - 1) / ETH_ALEN;
	debug(DEBUG_CAT_TLVPRS, "bss count is %d\n", bss_cnt);
	bss = SLIST_FIRST(&ctx->metric_entry.metrics_query_head);
	while (bss) {
		tmp_bss = SLIST_NEXT(bss, bss_entry);
		free(bss);
		bss = tmp_bss;
	}
	SLIST_INIT(&ctx->metric_entry.metrics_query_head);
	for (i = 0; i < bss_cnt; i++) {
		bss = (struct bss_db *)os_malloc(sizeof(struct bss_db));
		if (!bss) {
			err(DEBUG_CAT_TLVPRS, "alloc struct bss_db fail\n");
			return -1;
		}
		memcpy(bss->bssid, temp_buf, ETH_ALEN);
		temp_buf += ETH_ALEN;
		debug(DEBUG_CAT_TLVPRS, "bssid("MACSTR")\n",
			MAC2STR(bss->bssid));
		SLIST_INSERT_HEAD(&(ctx->metric_entry.metrics_query_head),
				bss, bss_entry);
	}
	return (length + 3);
}
#ifdef MAP_R2
int parse_ap_radio_identifier_tlv(unsigned char *buf, struct own_1905_device *ctx, unsigned short band_idx)
{
	unsigned char *temp_buf = NULL;
	unsigned short length = 0;
	//int i = 0;
	//struct bss_db *bss = NULL/*, *tmp_bss = NULL*/;
	//int bss_cnt = 0;
	temp_buf = buf;

	if ((*temp_buf) == AP_RADIO_IDENTIFIER_TYPE) {
		temp_buf++;
	} else {
		err(DEBUG_CAT_TLVPRS, "should not go here\n");
		return -1;
	}

	//calculate tlv length
	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length | (*(temp_buf + 1));

	debug_hexdump(DEBUG_CAT_TLVPRS, "FUNCTION INSERT\n", buf, length+3);
	//shift to tlv value field
	temp_buf += 2;
	os_memcpy(ctx->metric_entry.radio_id[band_idx].identifier, temp_buf, ETH_ALEN);
	notice(DEBUG_CAT_TLVPRS, MACSTR"\n", MAC2STR(ctx->metric_entry.radio_id[band_idx].identifier));
	temp_buf += ETH_ALEN;
	return (length + 3);
}
int dump_ch_scan_info(struct radio_info_db *radio, char** reply_buf, size_t buf_len)
{
	struct scan_result_tlv *scan_result, *t_scan_result = NULL;
	unsigned char exist = 0;
	char *pos, *end;
	int ret = 0;
	s32 temp_ch_score;
	pos = *reply_buf;
	end = pos + buf_len;

	ret = os_snprintf(pos, end - pos, "{\n");
	if (ret < 0 || ret >= end - pos)
		return -1;
	pos += ret;

	ret = os_snprintf(pos, end - pos, "\"identifier\":\"%02x:%02x:%02x:%02x:%02x:%02x\",\n", PRINT_MAC(radio->identifier));
	if (ret < 0 || ret >= end - pos)
		return -1;
	pos += ret;
	//err(DEBUG_CAT_TLVPRS, "Radio ID "MACSTR"", MAC2STR(radio->identifier));
	ret = os_snprintf(pos, end - pos, "\"Channel scan result\":[\n");
	if (ret < 0 || ret >= end - pos)
		return -1;
	pos += ret;
	SLIST_FOREACH_SAFE(scan_result, &radio->first_scan_result, next_scan_result, t_scan_result)
	{
		ret = os_snprintf(pos, end - pos, "{\n");
		if (ret < 0 || ret >= end - pos)
			return -1;
		pos += ret;
		ret = os_snprintf(pos, end - pos, "\"Channel Number\":\"%u\",\n", scan_result->channel);
		if (ret < 0 || ret >= end - pos)
			return -1;
		pos += ret;
		ret = os_snprintf(pos, end - pos, "\"Channel Util\":\"%u\",\n", scan_result->utilization);
		if (ret < 0 || ret >= end - pos)
			return -1;
		pos += ret;
		ret = os_snprintf(pos, end - pos, "\"Channel Neighbour\":\"%u\",\n", scan_result->neighbor_num);
		if (ret < 0 || ret >= end - pos)
			return -1;
		pos += ret;
#if 0
		ret = os_snprintf(pos, end - pos, "\"Channel EDCCA\":\"%u\",\n", scan_result->cu_distribution.edcca_airtime);
		if (ret < 0 || ret >= end - pos)
			return -1;
		pos += ret;
#endif
		if(scan_result->ch_score <= -65535){
			/*keeping a high negative value for filtered out channel , so that graph formation for demo is ok*/
			temp_ch_score = -100;
		} else {
			temp_ch_score = scan_result->ch_score;
		}
		ret = os_snprintf(pos, end - pos, "\"Channel Condition\":\"%d\"", temp_ch_score);
		if (ret < 0 || ret >= end - pos)
			return -1;
		pos += ret;
#ifdef MAP_6E_SUPPORT
		ret = os_snprintf(pos, end - pos, ",\n\"Channel Band\":\"%d\"", radio->band);
		if (ret < 0 || ret >= end - pos)
			return -1;
		pos += ret;
#endif
		//always("Channel Number=%u\n", scan_result->channel);
		//always("Channel Util=%u\n", scan_result->utilization);
		//always("Channel Noise=%u\n", scan_result->noise);
		//always("Channel Condition=%u\n", scan_result->score);
		/*always("OperatingClass=%u\n", scan_result->oper_class);
		always("ScanStatus=%u\n", scan_result->scan_status);
		always("ChannelScanType=%u\n", scan_result->scan_type);
		always("Timestamp=%s\n", scan_result->timestamp);
		always("AggScanDuration=%u\n", scan_result->agg_scan_duration);
		always("cu_dis ch_num=%u\n", scan_result->cu_distribution.ch_num);
		always("cu_dis edcca airtime =%u\n", scan_result->cu_distribution.edcca_airtime);
		SLIST_FOREACH(nb_info,
			&scan_result->first_neighbor_info, next_neighbor_info)
		{
			always("NeighborBSSID=(%02x:%02x:%02x:%02x:%02x:%02x)\n", PRINT_MAC(nb_info->bssid));
			always("NeighborSSID=%s\n", nb_info->ssid);
			always("NeighborRCPI=%u\n", nb_info->RCPI);
			always("NeighborBW=%s\n", nb_info->ch_bw);
			if (nb_info->cu_stacnt_present & 0x80)
				always("NeighborCU: %u\n", nb_info->cu);
			if (nb_info->cu_stacnt_present & 0x40)
				always("NeighborSTACount: %u\n", nb_info->sta_cnt);
		}*/
		ret = os_snprintf(pos, end - pos, "},\n");
		if (ret < 0 || ret >= end - pos)
			return -1;
		pos += ret;
		exist = 1;
	}
	if (exist == 1) {
		pos -= 2;
	}
	ret = os_snprintf(pos, end - pos, "]");
	if (ret < 0 || ret >= end - pos)
		return -1;
	pos += ret;
	ret = os_snprintf(pos, end - pos, "\n},\n");
	if (ret < 0 || ret >= end - pos)
		return -1;
	pos += ret;
	*reply_buf = pos;
	return 0;
}

int dump_score_info(struct score_info *cumulative_score, char* reply_buf, size_t buf_len, struct own_1905_device *ctx)
{
	char *pos, *end;
	int ret = 0;

	pos = reply_buf;
	end = pos + buf_len;

	ret = os_snprintf(pos, end - pos, "{\n");
	if (ret < 0 || ret >= end - pos)
		return -1;
	pos += ret;

	ret = os_snprintf(pos, end - pos, "\"Channel Number\":\"%d\",\n", cumulative_score->channel);
	if (ret < 0 || ret >= end - pos)
		return -1;
	pos += ret;
	ret = os_snprintf(pos, end - pos, "\"Channel Score\":\"%d\",\n", cumulative_score->avg_score);
	if (ret < 0 || ret >= end - pos)
		return -1;
	pos += ret;
#ifdef MAP_6E_SUPPORT
	ret = os_snprintf(pos, end - pos, "\"Channel Rank\":\"%d\",\n", cumulative_score->ch_rank);
#else
	ret = os_snprintf(pos, end - pos, "\"Channel Rank\":\"%d\"", cumulative_score->ch_rank);
#endif
	if (ret < 0 || ret >= end - pos)
		return -1;
	pos += ret;
#ifdef MAP_6E_SUPPORT
	ret = os_snprintf(pos, end - pos, "\"Channel band\":\"%d\"", cumulative_score->ch_band);
	if (ret < 0 || ret >= end - pos)
		return -1;
	pos += ret;
#endif
	ret = os_snprintf(pos, end - pos, "\n},\n");
	if (ret < 0 || ret >= end - pos)
		return -1;
	pos += ret;

	return pos - reply_buf;
}

int dump_dev_scan_info( struct _1905_map_device *dev, char* reply_buf, size_t buf_len, struct own_1905_device *ctx)
{
	struct radio_info_db *radio, *tradio = NULL;
	struct _1905_device *_1905_info = &dev->_1905_info;
	unsigned char exist = 0;
	char *pos, *end;
	int ret = 0;
	int cnt = 0;

	pos = reply_buf;
	end = pos + buf_len;

	ret = os_snprintf(pos, end - pos, "{\n");
	if (ret < 0 || ret >= end - pos)
		return -1;
	pos += ret;

	ret = os_snprintf(pos, end - pos, "\"AL MAC\":\"%02x:%02x:%02x:%02x:%02x:%02x\",\n", PRINT_MAC(_1905_info->al_mac_addr));
	if (ret < 0 || ret >= end - pos)
		return -1;
	pos += ret;
	//err(DEBUG_CAT_TLVPRS, "DEVALMAC "MACSTR"",MAC2STR(dev->_1905_info.al_mac_addr));
	cnt = 0;
	SLIST_FOREACH_SAFE(radio, &dev->first_radio, next_radio, tradio) {
		cnt++;
	}
	ret = os_snprintf(pos, end - pos, "\"Number of radios\":\"%d\",\n", cnt);
	if (ret < 0 || ret >= end - pos)
		return -1;
	pos += ret;
	ret = os_snprintf(pos, end - pos, "\"Radio Info\":[\n");
	if (ret < 0 || ret >= end - pos)
		return -1;
	pos += ret;
	tradio = NULL;
	SLIST_FOREACH_SAFE(radio, &dev->first_radio, next_radio, tradio) {
		//err(DEBUG_CAT_TLVPRS, "Radio ID "MACSTR"",MAC2STR(radio->identifier));
		dump_ch_scan_info(radio, &pos, end - pos);
		exist = 1;
	}
	if (exist == 1) {
		pos -= 2;
	//	exist = 0;
	}
	ret = os_snprintf(pos, end - pos, "],\n");
	if (ret < 0 || ret >= end - pos)
		return -1;
	pos += ret;
	exist = 1;
	if (exist == 1) {
		pos -= 2;
	}
	ret = os_snprintf(pos, end - pos, "\n},\n");
	if (ret < 0 || ret >= end - pos)
		return -1;
	pos += ret;

	return pos - reply_buf;
}
#ifdef MAP_R2
int dump_ch_plan_score_info(struct own_1905_device *own_dev, char *buf, char* reply_buf, size_t buf_Len)
{
	char *pos, *end;
	int ret = 0;
	int exist = 0;
	int len = 0, total_len = 0;
	pos = reply_buf;
	end = pos + buf_Len;
	ret = os_snprintf(pos, end - pos, "{\n\"Channel Planning Score Information\":[ \n");
	if (ret < 0 || ret >= end - pos)
		return -1;
	pos += ret;

	debug(DEBUG_CAT_TLVPRS, "*********ScoreTable****************\n");
	struct score_info *cumulative_score = NULL, *t_cumm_score = NULL;
	SLIST_FOREACH_SAFE(cumulative_score,
		&own_dev->ch_planning_R2.first_ch_score,next_ch_score, t_cumm_score) {
		debug(DEBUG_CAT_TLVPRS, "CH %d , avg score %d, rank %d\n",
		 cumulative_score->channel, cumulative_score->avg_score, cumulative_score->ch_rank);
		len = dump_score_info(cumulative_score,pos, end - pos, own_dev);
		pos += len;
		exist = 1;
		if (len < 0) {
			break;
		} else {
			if (total_len + len > buf_Len - 3) {
				break;
			}
			else
				total_len += len;
		}
	}
#if 0
	while (dev) {
		if (dev->in_network == 0) {
			dev = topo_srv_get_next_1905_device(own_dev, dev);
			continue;
		}
		//err(DEBUG_CAT_TLVPRS, "DEVALMAC "MACSTR"",MAC2STR(dev->_1905_info.al_mac_addr));
		len = dump_dev_scan_info(dev, pos, end - pos, own_dev);
		//dump_dev_scan_info(dev);
		dev = topo_srv_get_next_1905_device(own_dev, dev);
		pos += len;
		exist = 1;
		if (len < 0) {
			break;
		} else {
			if (total_len + len > buf_Len - 3) {
				break;
			}
			else
				total_len += len;
		}
	}
#endif
	if (exist == 1)
		pos -= 2; // for truncating extra comma character in topology dump

	ret = os_snprintf(pos, end - pos, "]\n}\n");
	if (ret < 0 || ret >= end - pos)
		return -1;
	pos += ret;

	if (ret < 0 || ret >= end - pos)
		return -1;
	pos += ret;

	total_len  = pos - reply_buf;

	return total_len;
}
#endif
int dump_all_dev_scan_info(struct own_1905_device *own_dev, char *buf, char* reply_buf, size_t buf_Len)
{
	struct _1905_map_device *dev;
	dev = topo_srv_get_1905_device(own_dev, NULL);
	char *pos, *end;
	int ret = 0;
	int exist = 0;
	int len = 0, total_len = 0, i = 0;
	pos = reply_buf;
	end = pos + buf_Len;
	ret = os_snprintf(pos, end - pos, "{\n\"Channel Scan Information\":[ \n");
	if (ret < 0 || ret >= end - pos)
		return -1;
	pos += ret;
	while (dev) {
		if (dev->in_network == 0) {
			dev = topo_srv_get_next_1905_device(own_dev, dev);
			continue;
		}
		//err(DEBUG_CAT_TLVPRS, "DEVALMAC "MACSTR"",MAC2STR(dev->_1905_info.al_mac_addr));
		len = dump_dev_scan_info(dev, pos, end - pos, own_dev);
		//dump_dev_scan_info(dev);
		dev = topo_srv_get_next_1905_device(own_dev, dev);
		pos += len;
		exist = 1;
		if (len < 0) {
			break;
		} else {
			if (total_len + len > buf_Len - 3) {
				break;
			}
			else
				total_len += len;
		}
	}
	if (exist == 1)
		pos -= 2; // for truncating extra comma character in topology dump

	ret = os_snprintf(pos, end - pos, "]\n}\n");
	if (ret < 0 || ret >= end - pos)
		return -1;
	pos += ret;

	if (dev == NULL)
		ret = 0;//removing end character
	else
		ret = os_snprintf(pos, end - pos, "%03d", i);
	if (ret < 0 || ret >= end - pos)
		return -1;
	pos += ret;

	total_len  = pos - reply_buf;

	return total_len;
}

int insert_new_ch_scan_report_info(
		struct mapd_global * global,
		struct _1905_map_device *dev,
		unsigned char *buf,
		unsigned short len)
{
	unsigned char *pos = buf;
	struct radio_info_db *radio = NULL, *tradio = NULL;
	struct own_1905_device *ctx = &global->dev;
	u8 i = 0, j = 0;

	SLIST_FOREACH_SAFE(radio, &dev->first_radio, next_radio, tradio) {
		if (ctx->user_triggered_scan == FALSE &&
				(radio->dev_ch_plan_info.dev_ch_plan_state != CHPLAN_STATE_SCAN_ONGOING &&
				global->dev.ch_planning_R2.ch_plan_state != CHPLAN_STATE_SCAN_ONGOING)) {
			continue;
		}
		if (os_memcmp(radio->identifier, pos, ETH_ALEN) == 0) {
			struct scan_result_tlv *res = NULL, *tres = NULL;
			u8 *pos_backup = pos;
			pos_backup += ETH_ALEN+1;
			struct scan_result_tlv *new_scan_result = NULL;
			SLIST_FOREACH_SAFE(res, &(radio->first_scan_result), next_scan_result, tres) {
				if (*pos_backup == res->channel){
					err(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"duplicate channel scan result on ch(%d) skip!!!\n",
					 res->channel);
					return 0;
				}
			}
			if(!new_scan_result){
				new_scan_result = os_zalloc(sizeof(struct scan_result_tlv));
			}
			if (!new_scan_result) {
				err(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"alloc memory fail for new_scan_result\n");
				return -1;
			}
			os_memcpy(new_scan_result->radio_id, pos, ETH_ALEN);
			pos += ETH_ALEN;
			new_scan_result->oper_class = *pos++;
			new_scan_result->channel = *pos++;
			new_scan_result->scan_status = *pos++;
			if (new_scan_result->scan_status != SCAN_SUCCESS) {
				err(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"scan fail on ch(%d), status: %u\n",
					new_scan_result->channel, new_scan_result->scan_status);
				if (new_scan_result->scan_status == OP_CLASS_CHAN_NOT_SUPP) {
					os_free(new_scan_result);
					goto SCAN_FAIL;
				} else {
					os_free(new_scan_result);
					ch_planning_scan_restart_due_to_failure(global);
					return -1;
				}
			}
			debug(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"scan_res%d opclass(%d) ch(%d) scan_status(%d)\n",
				j, new_scan_result->oper_class,
				new_scan_result->channel,
				new_scan_result->scan_status);
			j++;
			new_scan_result->timestamp_len = *pos++;
			if (new_scan_result->timestamp_len > TS_MAX) {
				err(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"Error in os_memcpy\n");
				os_free(new_scan_result);
				ch_planning_scan_restart_due_to_failure(global);
				return -1;
			}
			os_memcpy(new_scan_result->timestamp, pos, new_scan_result->timestamp_len);
			pos += new_scan_result->timestamp_len;
			new_scan_result->utilization = *pos++;
			new_scan_result->noise = *pos++;
			if (new_scan_result->noise > 220)
				new_scan_result->noise = 0;
			new_scan_result->neighbor_num = (((*pos) << 8) | (*(pos + 1)));
			if (new_scan_result->neighbor_num > MAX_LEN_OF_BSS_TABLE) {
				err(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"maximum scan result neighbor_num(%u) exceeded than 256\n",
				 new_scan_result->neighbor_num);
				os_free(new_scan_result);
				ch_planning_scan_restart_due_to_failure(global);
				return -1;
			}
			debug(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"timestamp_len(%d) utilization(%d) noise(%d) neighbor_num(%d)\n",
				new_scan_result->timestamp_len, new_scan_result->utilization,
				new_scan_result->noise,
				new_scan_result->neighbor_num);
			SLIST_INSERT_HEAD(&(radio->first_scan_result), new_scan_result, next_scan_result);
			SLIST_INIT(&(new_scan_result->first_neighbor_info));

			if(new_scan_result->neighbor_num)
			{
				pos += 2;
				for (i = 0; i < new_scan_result->neighbor_num; i++) {
					struct nb_info *nb_info = os_zalloc(sizeof(struct nb_info));
					u8 tmp_len = 0;
					if(!nb_info) {
						err(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"alloc memory fail for nb_info\n");
						os_free(new_scan_result);
						return -1;
					}
					SLIST_INSERT_HEAD(&(new_scan_result->first_neighbor_info), nb_info, next_neighbor_info);
					os_memcpy(nb_info->bssid, pos, ETH_ALEN);
					pos += ETH_ALEN;
					tmp_len = *pos++;
					if(tmp_len < MAX_LEN_OF_SSID)
						nb_info->ssid_len = tmp_len;
					else
						nb_info->ssid_len = MAX_LEN_OF_SSID;
					os_memcpy(nb_info->ssid, pos, nb_info->ssid_len);
					pos += tmp_len;
					nb_info->RCPI = *pos++;
					tmp_len = 0;
					tmp_len = *pos++;
					if(tmp_len < MAX_CH_BW_LEN)
						nb_info->ch_bw_len = tmp_len;
					else
						nb_info->ch_bw_len = MAX_CH_BW_LEN;
					os_memcpy(nb_info->ch_bw, pos, nb_info->ch_bw_len);
					pos += tmp_len;
					nb_info->cu_stacnt_present = *pos++;
					if (nb_info->cu_stacnt_present & 0x80)
						nb_info->cu = *pos++;
					if (nb_info->cu_stacnt_present & 0x40) {
						nb_info->sta_cnt = *pos;
						pos += 2;
					}
					debug(DEBUG_CAT_TLVPRS,
					 CH_PLANING_PREX"nb%d bssid("MACSTR") ssid_len(%d) ssid(%s) RCPI(%d)"
						"ch_bw_len(%d) ch_bw(%s) cu_stacnt_present(%d) cu(%d) sta_cnt(%d)\n",
						i, MAC2STR(nb_info->bssid), nb_info->ssid_len, nb_info->ssid,
						nb_info->RCPI, nb_info->ch_bw_len, nb_info->ch_bw, nb_info->cu_stacnt_present,
						nb_info->cu, nb_info->sta_cnt);
				}
			}
SCAN_FAIL:
			//dump_ch_scan_info(radio);
			topo_srv_update_ch_plan_scan_done(&global->dev,dev,radio);
			break;
		}
	}
	return 0;

}
int insert_new_ch_net_opt_report_info(struct _1905_map_device *dev, unsigned char *buf,
                struct net_opt_scan_report_event **scan_resp , unsigned int *resp_len)
{
	unsigned char a = 0;
	unsigned char *pos = buf;
	u16 neighbor_num = 0;
	struct net_opt_scan_report_event *temp = NULL;
	struct net_opt_scan_result_event *result = NULL;
	u8 *buf_result = NULL;

	*resp_len = *resp_len + sizeof(struct net_opt_scan_result_event);
	temp = os_realloc(*scan_resp,*resp_len);
	if (!temp)
		return -1;
	buf_result = (u8 *)temp->scan_result;
	for (a = 0; a < temp->scan_result_num; a++)
	{
	  result = (struct net_opt_scan_result_event *)buf_result;
	  buf_result = buf_result + sizeof(struct net_opt_scan_result_event) +
			(result->neighbor_num * sizeof(struct neighbor_info));
	}
	result = (struct net_opt_scan_result_event *)buf_result;
	os_memcpy(result->radio_id, pos, ETH_ALEN);
	pos += ETH_ALEN;
	result->oper_class = *pos;
	pos++;
	result->channel = *pos;
	pos++;
	result->scan_status = *pos;
	pos++;
	if (result->scan_status == 0) {
		result->timestamp_len = *pos;
		pos++;
		if (sizeof(result->timestamp) < MAX_TS_LEN)
			os_memcpy(result->timestamp, pos, result->timestamp_len);
		else
			os_memcpy(result->timestamp, pos, MAX_TS_LEN);
		pos += result->timestamp_len;
		result->utilization = *pos++;
		result->noise = *pos++;
		result->neighbor_num = (((*pos) << 8) | (*(pos + 1)));
		if (result->neighbor_num > MAX_LEN_OF_BSS_TABLE) {
			err(DEBUG_CAT_TLVPRS, NETOPT_PREX"maximum scan result neighbor_num(%u) exceeded than 256\n", result->neighbor_num);
			os_free(temp);
			*scan_resp = NULL;
			return -1;
		}
		pos += 2;
		if (result->neighbor_num) {
			*resp_len = *resp_len + (result->neighbor_num)*sizeof(struct neighbor_info);
			temp = os_realloc(temp, *resp_len);
			if(!temp)
				return -1;
			buf_result = (u8*)temp->scan_result;
			for (a = 0; a < temp->scan_result_num; a++) {
				result = (struct net_opt_scan_result_event *)buf_result;
				if (result->neighbor_num > MAX_LEN_OF_BSS_TABLE) {
					err(DEBUG_CAT_TLVPRS, NETOPT_PREX"maximum scan result neighbor_num(%u) exceeded than 256\n",
					 result->neighbor_num);
					os_free(temp);
					*scan_resp = NULL;
					return -1;
				}
				buf_result = buf_result + sizeof(struct net_opt_scan_result_event) +
					(result->neighbor_num * sizeof(struct neighbor_info));
			}
			result = (struct net_opt_scan_result_event *)buf_result;
		}
		if (result->neighbor_num > MAX_LEN_OF_BSS_TABLE) {
			err(DEBUG_CAT_TLVPRS, NETOPT_PREX"maximum scan result neighbor_num(%u) exceeded than 256\n", result->neighbor_num);
			os_free(temp);
			*scan_resp = NULL;
			return -1;
		}
		for (neighbor_num = 0; neighbor_num < result->neighbor_num; neighbor_num++) {
			os_memcpy(result->nb_info[neighbor_num].bssid, pos, ETH_ALEN);
			pos += ETH_ALEN;
			result->nb_info[neighbor_num].ssid_len = *pos++;
			os_memset(result->nb_info[neighbor_num].ssid, 0, MAX_LEN_OF_SSID);
			if (result->nb_info[neighbor_num].ssid_len > MAX_LEN_OF_SSID) {
				err(DEBUG_CAT_TLVPRS, NETOPT_PREX"Error in os_memcpy\n");
				os_free(temp);
				*scan_resp = NULL;
				return -1;
			}
			os_memcpy(result->nb_info[neighbor_num].ssid, pos,
				result->nb_info[neighbor_num].ssid_len);
			pos += result->nb_info[neighbor_num].ssid_len;
			result->nb_info[neighbor_num].RCPI = *pos++;
			result->nb_info[neighbor_num].ch_bw_len = *pos++;
			os_memcpy(result->nb_info[neighbor_num].ch_bw, pos,
				result->nb_info[neighbor_num].ch_bw_len);
			pos += result->nb_info[neighbor_num].ch_bw_len;
			result->nb_info[neighbor_num].cu_stacnt_present = *pos++;
			if (result->nb_info[neighbor_num].cu_stacnt_present & 0x80) {
				result->nb_info[neighbor_num].cu = *pos++;
				result->nb_info[neighbor_num].sta_cnt = (((*pos) << 8) | (*(pos + 1)));
				pos += 2;
			}
		}
		temp->scan_result_num++;
		*scan_resp = temp;
		return 0;
	} else  {
		notice(DEBUG_CAT_TLVPRS, NETOPT_PREX"scan_status: %u\n", result->scan_status);
		os_free(temp);
		*scan_resp = NULL;
		return -1;
	}
}

int parse_ch_scan_timestamp_tlv(struct mapd_global *global, struct _1905_map_device *dev, unsigned char *buf)
{
	unsigned char *temp_buf;
	unsigned short length = 0;

	temp_buf = buf;

	if((*temp_buf) == TIMESTAMP_TYPE) {
		temp_buf++;
	} else {
		err(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"should not go here\n");
		return -1;
	}

	//calculate tlv length
	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length |(*(temp_buf+1));
	return (length+3);

}

Boolean validate_ch_scan_tlv(unsigned char *buf)
{
	int len, timestamp_len, neighbor_num, ssid_len, ch_bw_len,
	bss_load_element, scan_status;
	unsigned char *temp_buff = buf;

	len = get_tlv_len(temp_buff);

	temp_buff += 3;

	/* RUID(6 byte) + OP class(1 byte) + channel (1 byte) + scan status (1 byte) + timestamp length (1 byte)*/
	if (len < 9) {
		err(DEBUG_CAT_TLVPRS, "error in length\n");
		return FALSE;
	}
	temp_buff += 8;
	scan_status = *temp_buff++;
	if (scan_status != 0x00)
		return TRUE;

	len -= 10;
	timestamp_len = *temp_buff++;
	if (len < timestamp_len) {
		err(DEBUG_CAT_TLVPRS, "error in length\n");
		return FALSE;
	}
	len -= timestamp_len;
	temp_buff += timestamp_len;
	/* Utilization(1 byte) + Noise(1 byte) + num_neighbor(2 byte)*/
	if (len < 4) {
		err(DEBUG_CAT_TLVPRS, "error in length\n");
		return FALSE;
	}

	temp_buff += 2;
	len -= 4;
	neighbor_num = (((*temp_buff) << 8) | (*(temp_buff + 1)));
	temp_buff += 2;
	if (neighbor_num > MAX_LEN_OF_BSS_TABLE) {
		err(DEBUG_CAT_TLVPRS, TOPO_PREX"maximum scan result neighbor_num(%u) exceeded than 256\n", neighbor_num);
		return FALSE;
	}
	for (int i = 0; i < neighbor_num; i++) {
		/* BSSID(6 byte) + SSID length (1 byte)*/
		if (len < 7) {
			err(DEBUG_CAT_TLVPRS, "error in length\n");
			return FALSE;
		}

		temp_buff += 6;
		len -= 7;
		ssid_len = *temp_buff++;
		if (check_subfield_length(MAX_SSID_LEN, ssid_len) == FALSE) {
			err(DEBUG_CAT_TLVPRS, "error in ssid length %d\n", ssid_len);
			return FALSE;
		}

		len -= ssid_len;
		temp_buff += ssid_len;
		/* signal strength(1 byte) + channel bw len(1 byte)*/
		if (len < 2) {
			err(DEBUG_CAT_TLVPRS, "error in length\n");
			return FALSE;
		}

		len -= 2;
		temp_buff++;
		ch_bw_len = *temp_buff++;
		if (len < ch_bw_len) {
			err(DEBUG_CAT_TLVPRS, "error in length");
			return FALSE;
		}

		len -= ch_bw_len;
		temp_buff += ch_bw_len;
		/* bss color(1 byte) + channel util(1 octet) + station count(2 byte)*/
		if (len < 1) {
			err(DEBUG_CAT_TLVPRS, "error in length\n");
			return FALSE;
		}
		bss_load_element = *temp_buff++;
		len -= 1;
		if (bss_load_element & 0x80) {
			temp_buff += 3;
			len -= 3;
		}
	}
	/* scan duration(4 byte) + scan Type (1 byte)*/
	if (len < 5) {
		err(DEBUG_CAT_TLVPRS, "error in length\n");
		return FALSE;
	}

	return TRUE;
}

int parse_ch_scan_result_tlv(struct mapd_global *global, struct _1905_map_device *dev, unsigned char
		*buf, struct net_opt_scan_report_event **scan_resp, unsigned int *resp_len)
{
	unsigned char *temp_buf;
	unsigned short length = 0;

	temp_buf = buf;

	if ((*temp_buf) != CHANNEL_SCAN_RESULT_TYPE) {
		err(DEBUG_CAT_TLVPRS, TOPO_PREX"should not go here for dev("MACSTR")\n",
			MAC2STR(dev->_1905_info.al_mac_addr));
		return -1;
	}

	//calculate tlv length
	length = get_tlv_len(temp_buf);
	if (validate_ch_scan_tlv(temp_buf) == FALSE) {
		err(DEBUG_CAT_TLVPRS, TOPO_PREX"error in parsing in channel scan result tlv\n");
		return -1;
	}
	//shift to tlv value field
	temp_buf += 3;
	if(dev->network_opt_per1905.network_opt_device_state == NETOPT_STATE_DATA_COLLECTION_ONGOING) {
		if (0 > insert_new_ch_net_opt_report_info(dev, temp_buf, scan_resp, resp_len)) {
			debug(DEBUG_CAT_TLVPRS, "insert_new_ch_net_opt_report_info");
			return -1;
		}
	}
	else {
		/*insert new channel preference info*/
		if (0 > insert_new_ch_scan_report_info(global, dev, temp_buf, length)) {
			err(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"insert_new_ch_scan_report_info fail for dev("MACSTR")\n",
				MAC2STR(dev->_1905_info.al_mac_addr));
			return -1;
		}
	}
	return (length+3);
}
int parse_ch_scan_cu_tlv(
	struct mapd_global * global,
	struct _1905_map_device *dev,
	unsigned char *buf)
{
	unsigned char *temp_buf = buf;
	int length = 0, temp_len = 0, sanity_len = 0;
	unsigned char func_type = 0;
	struct ch_util_lib ch_util;
	struct radio_info_db *radio = NULL, *tradio = NULL;
	struct scan_result_tlv *result = NULL, *tresult = NULL;
	struct own_1905_device *ctx = &global->dev;

	//calculate tlv length
	length = get_cmdu_tlv_length(temp_buf);

	if (length < 4) {
		err(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"TLV Length is not sufficient!\n");
		return -1;
	}

	//shift to tlv value field
	temp_buf += 3;
	temp_len += 3;
	if (os_memcmp(temp_buf, MTK_OUI, OUI_LEN)) {
		err(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"OUI not mtk_oui; do not handle!\n");
		return length;
	}
	sanity_len = length - 4;
	if (!(sanity_len > 0 && sanity_len < INT_MAX)) {
		err(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"TLV length is out of Integer Range!\n");
		return -1;
	}
	temp_buf += OUI_LEN;
	func_type = *temp_buf++;
	debug(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"func_type %d, "MACSTR"\n", func_type, MAC2STR(dev->_1905_info.al_mac_addr));
	SLIST_FOREACH_SAFE(radio, &dev->first_radio, next_radio, tradio) {
		if(ctx->user_triggered_scan == FALSE &&
			(radio->dev_ch_plan_info.dev_ch_plan_state != CHPLAN_STATE_SCAN_ONGOING &&
			global->dev.ch_planning_R2.ch_plan_state != CHPLAN_STATE_SCAN_ONGOING)) {
				continue;
		}
		if (func_type == FUNC_VENDOR_CHANNEL_UTIL_RSP) {
			while (temp_len < sanity_len) {/*-4 is done to ignore OUI Len and FUNC_TYPE LEN)*/
				ch_util.ch_num = *temp_buf;
				temp_buf++;
				temp_len++;
				ch_util.edcca = (u32) *temp_buf;
				temp_buf += 4;
				temp_len += 4;
				debug(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"channel num %d, edcca %d\n", ch_util.ch_num, ch_util.edcca);
				radio = topo_srv_get_radio_by_band(dev,ch_util.ch_num);
				if(!radio)
					return length;
				SLIST_FOREACH_SAFE(result,&radio->first_scan_result,next_scan_result, tresult) {
					if(ch_util.ch_num == result->channel) {
						result->cu_distribution.edcca_airtime = ch_util.edcca;
						result->cu_distribution.ch_num = ch_util.ch_num;
						break;
					}
				}
			}
		}
	}
	return length;
}

int parse_channel_scan_report_message(struct mapd_global *global,
	unsigned char *buf, int left_tlv_len, struct _1905_map_device *dev)
{
	int length = 0, tlv_len, len;
	unsigned char *temp_buf;
	unsigned char integrity = 0;
	struct net_opt_scan_report_event *scan_resp = NULL;
	unsigned int resp_len = 0;
	unsigned char scan_resp_parse = 0;

	temp_buf = buf;

	if(dev->network_opt_per1905.network_opt_device_state == NETOPT_STATE_DATA_COLLECTION_ONGOING)
	{
		resp_len = sizeof(struct net_opt_scan_report_event);
		scan_resp = (struct net_opt_scan_report_event*)os_zalloc(resp_len);
		if(scan_resp ==NULL) {
			err(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"alloc scan_resp fail for dev("MACSTR")\n",
				MAC2STR(dev->_1905_info.al_mac_addr));
			return -1;
		}
	}
	while(1) {
		len = get_tlv_len(temp_buf);
		tlv_len = len + 3;
		if (left_tlv_len < tlv_len) {
			notice(DEBUG_CAT_TLVPRS, "Error TLV len, type = %d, left_tlv_length %d less than tlv_len %d\n",
					*temp_buf, left_tlv_len, tlv_len);
			if (scan_resp) {
				free(scan_resp);
				scan_resp = NULL;
			}
			return -1;
		}
		if (*temp_buf == TIMESTAMP_TYPE) {
			integrity |= 0x1;
			length = parse_ch_scan_timestamp_tlv(global, dev, temp_buf);
			if(length < 0) {
				err(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"error timestamp tlv for dev("MACSTR")\n",
					MAC2STR(dev->_1905_info.al_mac_addr));
				goto PARSE_FAIL;
			}
			temp_buf += length;
		} else if (*temp_buf == CHANNEL_SCAN_RESULT_TYPE) {
			integrity |= 0x2;
			length = parse_ch_scan_result_tlv(global, dev, temp_buf, &scan_resp, &resp_len);
			if(length < 0) {
				err(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"error channel scan result tlv for dev("MACSTR")\n",
					MAC2STR(dev->_1905_info.al_mac_addr));
				scan_resp_parse = 1;
				goto PARSE_FAIL;
			}
			temp_buf += length;
		} else if (*temp_buf == VENDOR_SPECIFIC_TLV_TYPE) {
			integrity |= 0x2;
			length = parse_ch_scan_cu_tlv(global, dev, temp_buf);
			if(length < 0) {
				err(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"error channel scan result CU tlv for dev("MACSTR")\n",
					MAC2STR(dev->_1905_info.al_mac_addr));
				goto PARSE_FAIL;
			}
			temp_buf += length;
		} else if (*temp_buf == END_OF_TLV_TYPE) {
			break;
		} else {
			length = get_cmdu_tlv_length(temp_buf);
			temp_buf += length;
		}
		left_tlv_len -= tlv_len;
	}
	//dump_dev_scan_info(dev);
PARSE_FAIL:
	if(dev->network_opt_per1905.network_opt_device_state == NETOPT_STATE_DATA_COLLECTION_ONGOING) {
		if(scan_resp) {
			dev->net_opt_scan_report = scan_resp;
			dev->network_opt_per1905.network_opt_device_state = NETOPT_STATE_DATA_COLLECTION_COMPLETE;
			notice(DEBUG_CAT_TLVPRS, NETOPT_PREX"Scan report received from almac " MACSTR " data connection complete\n",
			 MAC2STR(dev->_1905_info.al_mac_addr));
		}
		if (scan_resp_parse == 1) {
			dev->network_opt_per1905.network_opt_device_state = NETOPT_STATE_DATA_COLLECTION_COMPLETE;
			notice(DEBUG_CAT_TLVPRS, NETOPT_PREX"Scan report received from almac" MACSTR
			 "with radio Busy. data connection complete\n",
				MAC2STR(dev->_1905_info.al_mac_addr));
		}
	}
	/*check integrity*/
	if(integrity != 0x3) {
		err(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"incomplete channel scan report 0x%x 0x3 for dev("MACSTR")\n",
			integrity, MAC2STR(dev->_1905_info.al_mac_addr));
		return -1;
	}
	if (length < 0) {
		return -1;
	}

	return 0;
}
int insert_new_radio_metrics(
		struct mapd_global * global,
		struct _1905_map_device *dev,
		unsigned char *buf, unsigned short len)
{
	unsigned char *pos = buf;
	struct radio_info_db *radio = NULL, *tradio = NULL;
	SLIST_FOREACH_SAFE(radio, &dev->first_radio, next_radio, tradio) {
		if (os_memcmp(radio->identifier, pos, ETH_ALEN) == 0) {
			os_memcpy(radio->radio_metrics.ra_id, pos, ETH_ALEN);
			pos += ETH_ALEN;
			radio->radio_metrics.cu_noise = *pos++;
			radio->radio_metrics.cu_tx = *pos++;
			radio->radio_metrics.cu_rx = *pos++;
			radio->radio_metrics.cu_other = *pos++;
			break;
		}
	}
#ifdef MAP_R2
	if(radio)
		info(DEBUG_CAT_TLVPRS, "other dev ch %d, cu_tx %d, cu_rx %d\n", radio->channel[0],
	 radio->radio_metrics.cu_tx, radio->radio_metrics.cu_rx);
	topo_srv_update_ch_planning_info(&global->dev,dev,NULL,radio,0);
#endif
	return 0;
}


int insert_new_ap_extended_metrics(
		struct mapd_global * global, struct _1905_map_device *dev, unsigned char *buf, unsigned short len)
{
	unsigned char *pos = buf;
	struct bss_info_db *bss = NULL, *tbss = NULL;

	SLIST_FOREACH_SAFE(bss, &dev->first_bss, next_bss, tbss) {
		if (os_memcmp(bss->bssid, pos, ETH_ALEN) == 0) {
			pos += ETH_ALEN;
			bss->uc_tx = ((*pos) << 24) | ((*(pos + 1)) << 16) |
						((*(pos + 2)) << 8) | (*(pos + 3));
			pos += 4;
			bss->uc_rx = ((*pos) << 24) | ((*(pos + 1)) << 16) |
						((*(pos + 2)) << 8) | (*(pos + 3));
			pos += 4;
			bss->mc_tx = ((*pos) << 24) | ((*(pos + 1)) << 16) |
						((*(pos + 2)) << 8) | (*(pos + 3));
			pos += 4;
			bss->mc_rx = ((*pos) << 24) | ((*(pos + 1)) << 16) |
						((*(pos + 2)) << 8) | (*(pos + 3));
			pos += 4;
			bss->bc_tx = ((*pos) << 24) | ((*(pos + 1)) << 16) |
						((*(pos + 2)) << 8) | (*(pos + 3));
			pos += 4;
			bss->bc_rx = ((*pos) << 24) | ((*(pos + 1)) << 16) |
						((*(pos + 2)) << 8) | (*(pos + 3));
			pos += 4;
			break;
		}
	}
	return 0;

}

#ifdef MAP_R6
int insert_new_mlo_ap_extended_metrics(
		struct mapd_global *global, struct _1905_map_device *dev, unsigned char *buf, unsigned short len)
{
	unsigned char *pos = buf;
	struct bss_info_db *bss = NULL, *tbss = NULL;

	SLIST_FOREACH_SAFE(bss, &dev->first_bss, next_bss, tbss) {
		if (os_memcmp(bss->bssid, pos, ETH_ALEN) == 0) {
			pos += ETH_ALEN;
			bss->mlo_pkts_tx = ((*pos) << 24) | ((*(pos + 1)) << 16) |
						((*(pos + 2)) << 8) | (*(pos + 3));
			pos += 4;
			bss->mlo_pkts_rx = ((*pos) << 24) | ((*(pos + 1)) << 16) |
						((*(pos + 2)) << 8) | (*(pos + 3));
			pos += 4;
			bss->mlo_tx_pkts_error_count = ((*pos) << 24) | ((*(pos + 1)) << 16) |
						((*(pos + 2)) << 8) | (*(pos + 3));
			pos += 4;
			bss->mlo_uc_tx = ((*pos) << 24) | ((*(pos + 1)) << 16) |
						((*(pos + 2)) << 8) | (*(pos + 3));
			pos += 4;
			bss->mlo_uc_rx = ((*pos) << 24) | ((*(pos + 1)) << 16) |
						((*(pos + 2)) << 8) | (*(pos + 3));
			pos += 4;
			bss->mlo_mc_tx = ((*pos) << 24) | ((*(pos + 1)) << 16) |
						((*(pos + 2)) << 8) | (*(pos + 3));
			pos += 4;
			bss->mlo_mc_rx = ((*pos) << 24) | ((*(pos + 1)) << 16) |
						((*(pos + 2)) << 8) | (*(pos + 3));
			pos += 4;
			bss->mlo_bc_tx = ((*pos) << 24) | ((*(pos + 1)) << 16) |
						((*(pos + 2)) << 8) | (*(pos + 3));
			pos += 4;
			bss->mlo_bc_rx = ((*pos) << 24) | ((*(pos + 1)) << 16) |
						((*(pos + 2)) << 8) | (*(pos + 3));
			pos += 4;
			break;
		}
	}
	return 0;

}

int parse_assoc_mlo_ap_extended_metrics_tlv(struct own_1905_device *ctx, struct _1905_map_device *dev, unsigned char *buf)
{
	unsigned char *temp_buf = NULL;
	unsigned char *check_buf = NULL;
	unsigned short length = 0;

	temp_buf = buf;
	check_buf = buf;

	if ((*temp_buf) == MLO_AP_EXTENDED_METRIC_TYPE) {
		temp_buf++;
	} else {
		err(DEBUG_CAT_TLVPRS, "should not go here\n");
		return -1;
	}
	/*calculate tlv length*/
	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length | (*(temp_buf+1));

	/*minimum len should be at least 42 bytes*/

	if (!check_metrics_fixed_length_tlv(MLO_AP_EXTENDED_METRIC_TYPE_LEN, check_buf, length)) {
		err(DEBUG_CAT_TLVPRS, "error MLO_AP_EXTENDED_METRIC_TYPE length is %d incorrect\n", length);
		return -1;
	}
	/*shift to tlv value field*/
	temp_buf += 2;

	if (insert_new_mlo_ap_extended_metrics((struct mapd_global *)ctx->back_ptr, dev, temp_buf, length) <  0) {
		debug(DEBUG_CAT_TLVPRS, "insert_new_mlo_ap_metrics_info fail\n");
		return -1;
	}
	return (length+3);
}
#endif

int parse_assoc_ap_extended_metrics_tlv(struct own_1905_device * ctx, struct _1905_map_device *dev, unsigned char *buf)
{
	unsigned char *temp_buf = NULL;
	unsigned char *check_buf = NULL;
	unsigned short length = 0;

	temp_buf = buf;
	check_buf = buf;

	if((*temp_buf) == AP_EXTENDED_METRIC_TYPE) {
		temp_buf++;
	} else {
		err(DEBUG_CAT_TLVPRS, "should not go here\n");
		return -1;
	}
	//calculate tlv length
	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length |(*(temp_buf+1));

	if (!check_fixed_length_tlv(AP_EXTENDED_METRIC_TYPE_LEN, check_buf, length)) {
		err(DEBUG_CAT_TLVPRS, "error AP_EXTENDED_METRIC_TYPE length is %d incorrect\n", length);
		return -1;
	}
	//shift to tlv value field
	temp_buf += 2;

	if (0 > insert_new_ap_extended_metrics((struct mapd_global *)ctx->back_ptr, dev, temp_buf, length)) {
		debug(DEBUG_CAT_TLVPRS, "insert_new_ap_metrics_info fail\n");
		return -1;
	}

	return (length+3);
}
int parse_radio_metrics_tlv(struct own_1905_device * ctx, struct _1905_map_device *dev, unsigned char *buf)
{
	unsigned char *temp_buf = NULL;
	unsigned char *check_buf = NULL;
	unsigned short length = 0;

	temp_buf = buf;
	check_buf = buf;

	if((*temp_buf) == RADIO_METRIC_TYPE) {
		temp_buf++;
	} else {
		err(DEBUG_CAT_TLVPRS, "should not go here\n");
		return -1;
	}
	//calculate tlv length
	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length |(*(temp_buf+1));

	if (!check_fixed_length_tlv(RADIO_METRIC_TYPE_LEN, check_buf, length)) {
		err(DEBUG_CAT_TLVPRS, "error RADIO_METRIC_TYPE length is %d incorrect\n", length);
		return -1;
	}
	//shift to tlv value field
	temp_buf += 2;

	if (insert_new_radio_metrics((struct mapd_global *)ctx->back_ptr, dev, temp_buf, length) < 0) {
		debug(DEBUG_CAT_TLVPRS, "insert_new_ap_metrics_info fail\n");
		return -1;
	}

	return (length+3);
}
int insert_new_sta_ext_metrics(
		struct mapd_global * global, struct _1905_map_device *dev, unsigned char *buf, unsigned short len)
{
	unsigned char *pos = buf;
	struct associated_clients *sta = NULL, *tsta = NULL;

	SLIST_FOREACH_SAFE(sta, &dev->assoc_clients, next_client, tsta) {
		if (os_memcmp(sta->client_addr, pos, ETH_ALEN) == 0) {
			pos += ETH_ALEN;
			pos += sizeof(unsigned char) + ETH_ALEN;
			sta->sta_ext_info.last_data_ul_rate = ((*pos) << 24) | ((*(pos + 1)) << 16) |
													((*(pos + 2)) << 8) | (*(pos + 3));
			pos += 4;
			sta->sta_ext_info.last_data_dl_rate = ((*pos) << 24) | ((*(pos + 1)) << 16) |
													((*(pos + 2)) << 8) | (*(pos + 3));
			pos += 4;
			sta->sta_ext_info.utilization_rx = ((*pos) << 24) | ((*(pos + 1)) << 16) |
												((*(pos + 2)) << 8) | (*(pos + 3));
			pos += 4;
			sta->sta_ext_info.utilization_tx = ((*pos) << 24) | ((*(pos + 1)) << 16) |
												((*(pos + 2)) << 8) | (*(pos + 3));
			pos += 4;
			break;
		}
	}
	return 0;

}

int parse_assoc_sta_ext_metrics_tlv(struct own_1905_device * ctx, struct _1905_map_device *dev, unsigned char *buf)
{
	unsigned char *temp_buf;
	unsigned short length = 0;

	temp_buf = buf;

	if((*temp_buf) == ASSOCIATED_STA_EXTENDED_LINK_METRIC_TYPE) {
		temp_buf++;
	} else {
		err(DEBUG_CAT_TLVPRS, "should not go here\n");
		return -1;
	}
	//calculate tlv length
	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length |(*(temp_buf+1));

	if (validate_tlv_length_specific_pattern(length,
		ASSOCIATED_STA_EXTENDED_LINK_METRIC_TYPE_CONST_LEN,
		ASSOCIATED_STA_EXTENDED_LINK_METRIC_TYPE_REPEATED_LEN) == FALSE) {
		err(DEBUG_CAT_TLVPRS, "error ASSOCIATED_STA_EXTENDED_LINK_METRIC_TYPE length is %d incorrect\n", length);
	}

	//shift to tlv value field
	temp_buf += 2;

	if (0 > insert_new_sta_ext_metrics((struct mapd_global *)ctx->back_ptr, dev, temp_buf, length)) {
		debug(DEBUG_CAT_TLVPRS, "insert_new_ap_metrics_info fail\n");
		return -1;
	}

	return (length+3);
}

int parse_assoc_status_notification_type_tlv(struct own_1905_device *ctx, struct _1905_map_device *dev, unsigned char *buf)
{
    unsigned char *temp_buf;
    unsigned short length = 0;
	int i, bss_num = 0;
	struct bss_info_db *bss = NULL, *tbss = NULL;

    temp_buf = buf;

    if((*temp_buf) == ASSOCIATION_STATUS_NOTIFICATION_TYPE) {
        temp_buf++;
    }
    else {
        return -1;
    }

    //calculate tlv length
    length = (*temp_buf);
    length = (length << 8) & 0xFF00;
	length = length |(*(temp_buf+1));

    temp_buf += 2;

	bss_num = *temp_buf;
	temp_buf++;

	for (i = 0; i < bss_num; i++) {
		SLIST_FOREACH_SAFE(bss, &dev->first_bss, next_bss, tbss) {
			if (os_memcmp(bss->bssid, temp_buf, ETH_ALEN) == 0) {
				temp_buf += ETH_ALEN;
				if (*temp_buf == 0)
					bss->status = 1;
				else
					bss->status = 0;
				temp_buf++;
			}
		}
	}

    return (length+3);
}

int parse_assoc_status_notification_message(struct own_1905_device *ctx, struct _1905_map_device *dev, unsigned char *buf, int left_tlv_len)
{
	int length = 0, len, tlv_len;
	unsigned char *temp_buf;
	unsigned int integrity = 0;
	temp_buf = buf;

	while(1)
	{
		len = get_tlv_len(temp_buf);
		tlv_len = len + 3;
		if (left_tlv_len < tlv_len) {
			err(DEBUG_CAT_TLVPRS, "Error TLV len, type = %d, left_tlv_length %d less than tlv_len %d\n",
					*temp_buf, left_tlv_len, tlv_len);
			return -1;
		}
		if (*temp_buf == ASSOCIATION_STATUS_NOTIFICATION_TYPE) {
			if (validate_tlv_length_specific_pattern(len, ASSOCIATION_STATUS_NOTIFICATION_TYPE_CONST_LEN,
				ASSOCIATION_STATUS_NOTIFICATION_TYPE_REPEAT_LEN) == FALSE) {
				err(DEBUG_CAT_TLVPRS, "error assoc status notification type tlv\n");
				return -1;
			}
			length = parse_assoc_status_notification_type_tlv(ctx, dev, temp_buf);

			if(length < 0)
			{
				err(DEBUG_CAT_TLVPRS, "error assoc status notification type tlv\n");
				return -1;
			}
			integrity |= (1 << 0);
			temp_buf += length;
		} else if(*temp_buf == END_OF_TLV_TYPE) {
			break;
		} else {
			length = get_cmdu_tlv_length(temp_buf);
			temp_buf += length;
		}
	}
		/*check integrity*/
	if(integrity != 1) {
		err(DEBUG_CAT_TLVPRS, "error when check tunneled message tlvs\n");
		return -1;
	}
	return 0;
}
int parse_client_disassciation_stats_message(struct own_1905_device *ctx, struct _1905_map_device *dev,
			unsigned char *buf, int left_tlv_len)
{
	int length = 0, tlv_len, len;
	unsigned char *temp_buf;
	unsigned int integrity = 0;
	temp_buf = buf;
	struct client *cli = NULL;
	unsigned char *pos = NULL;
	unsigned char sta_mac[ETH_ALEN] = {0};
#ifdef MAP_R6
	unsigned char mld_mac[ETH_ALEN] = {0};
	u8 ZERO_MAC_ADDR[ETH_ALEN] = {0, 0, 0, 0, 0, 0};
	unsigned int affiliated_sta = 0;
	int i;
#endif
	unsigned short reason_code = 0;

	while(1)
	{
		len = get_tlv_len(temp_buf);
		tlv_len = len + 3;
		if (left_tlv_len < tlv_len) {
			err(DEBUG_CAT_TLVPRS, "Error TLV len, type = %d, left_tlv_length %d less than tlv_len %d\n",
					*temp_buf, left_tlv_len, tlv_len);
			return -1;
		}
		/* One STA MAC Address TLV */
		if (*temp_buf == STA_MAC_ADDRESS_TYPE) {
			if (!check_fixed_length_tlv(STA_MAC_ADDRESS_TYPE_LEN, temp_buf, left_tlv_len)) {
				err(DEBUG_CAT_TLVPRS, "error STA_MAC_ADDRESS_TYPE length is %d incorrect\n", length);
				return -1;
			}
			integrity |= (1 << 0);
			length = get_cmdu_tlv_length(temp_buf);
			pos = temp_buf + 3;
			/*if sta is mld , then have to copy sta mld in sta mac*/
			os_memcpy(sta_mac, pos, ETH_ALEN);
			temp_buf += length;
		}
		/* One Disassociation Reason Code TLV */
		else if (*temp_buf == DISASSOCIATION_REASON_CODE_TYPE) {
			if (check_fixed_length_tlv(DISASSOCIATION_REASON_CODE_TYPE_LEN, temp_buf,
			left_tlv_len) == FALSE) {
				err(DEBUG_CAT_TLVPRS, "Error in parsing disassoc reason code tlv\n");
				return -1;
			}
			integrity |= (1 << 1);
			length = get_cmdu_tlv_length(temp_buf);
			pos = temp_buf + 3;
			reason_code = *pos << 8 | *(pos + 1);
			temp_buf += length;
		}
		/* One Associated STA Traffic Stats TLV */
		else if (*temp_buf == ASSOC_STA_TRAFFIC_STATS_TYPE) {
			if (!check_fixed_length_tlv(ASSOC_STA_TRAFFIC_STATS_TYPE_LEN, temp_buf
				, left_tlv_len)) {
				err(DEBUG_CAT_TLVPRS, "error ASSOC_STA_TRAFFIC_STATS_TYPE length is %d incorrect\n", length);
				return -1;
			}
			integrity |= (1 << 2);
			length = get_cmdu_tlv_length(temp_buf);
			temp_buf += length;
		}
#ifdef MAP_R6
		else if (*temp_buf == AFFILIATED_STA_TRAFFIC_STATS_TYPE) {
			if (!check_fixed_length_tlv(AFFILIATED_STA_TRAFFIC_STATS_TYPE, temp_buf
				, left_tlv_len)) {
				err(DEBUG_CAT_TLVPRS, "error AFFILIATED_STA_TRAFFIC_STATS_TYPE length is %d incorrect\n", length);
				return -1;
			}
			integrity |= (1 << 2);
			length = get_cmdu_tlv_length(temp_buf);
			/*extract mld address here*/
			pos = temp_buf + 3;
			affiliated_sta = *pos << 8 | *(pos + 1);
			pos = temp_buf + 2;
			os_memcpy(mld_mac, pos, ETH_ALEN);
			temp_buf += length;
		}
#endif
		else if (*temp_buf == END_OF_TLV_TYPE) {
			break;
		} else {
			length = get_cmdu_tlv_length(temp_buf);
			temp_buf += length;
		}
		left_tlv_len -= tlv_len;
	}
		/*check integrity*/
	if(integrity != 0x7) {
		err(DEBUG_CAT_TLVPRS, "error when check client disassciation stats tlvs\n");
		return -1;
	}

#ifdef MAP_R6
if (mld_mac[5] != 0) {
	/*implies sta_mld_mac*/
	dl_list_for_each(cli, &ctx->sta_seen_list, struct client, sta_seen_entry)
	{
		if (!os_memcmp(&cli->mld_addr[0], mld_mac, ETH_ALEN)) {
			cli->disassoc_reason = reason_code;
			break;
		}
	}

	for (i = 0; i < MAX_MLD_CLI ; i++) {
		if (cli->mld_clients[i]) {
			if (os_memcmp(cli->mld_clients[i]->mld_addr, ZERO_MAC_ADDR, ETH_ALEN)) {
				if (!os_memcmp(&cli->mld_clients[i]->mld_addr, mld_mac, ETH_ALEN))
					cli->mld_clients[i]->disassoc_reason = reason_code;
				}
			}
		}
} else {
		dl_list_for_each(cli, &ctx->sta_seen_list, struct client, sta_seen_entry) {
			if (!os_memcmp(&cli->mac_addr[0], sta_mac, ETH_ALEN)) {
				cli->disassoc_reason = reason_code;
				break;
		}
	}
}
#else
	dl_list_for_each(cli, &ctx->sta_seen_list, struct client, sta_seen_entry)
	{
		if (!os_memcmp(&cli->mac_addr[0], sta_mac, ETH_ALEN)) {
			cli->disassoc_reason = reason_code;
			break;
		}
	}
#endif
	return 0;
}
int parse_bh_sta_report(struct own_1905_device *ctx, struct _1905_map_device *dev, unsigned char *buf, int left_tlv_len)
{
	int length = 0, len, tlv_len;
	unsigned char *temp_buf;
	unsigned int integrity = 0;
	temp_buf = buf;

	while(1)
	{
		len = get_tlv_len(temp_buf);
		tlv_len = len + 3;
		if (left_tlv_len < tlv_len) {
			err(DEBUG_CAT_TLVPRS, "Error TLV len, type = %d, left_tlv_length %d less than tlv_len %d\n",
					*temp_buf, left_tlv_len, tlv_len);
			return -1;
		}
		if (*temp_buf == BACKHAUL_STA_RADIA_CAPABILITY_TYPE) {
			integrity |= (1 << 0);
			length = get_cmdu_tlv_length(temp_buf);
			if (length > left_tlv_len) {
				err(DEBUG_CAT_TLVPRS, "error when check backhaul sta cap report tlvs\n");
				return -1;
			}
			temp_buf += length;
		} else if(*temp_buf == END_OF_TLV_TYPE) {
			break;
		} else {
			length = get_cmdu_tlv_length(temp_buf);
			temp_buf += length;
		}
	}

	if (integrity == 0x0) {
		err(DEBUG_CAT_TLVPRS, "error when check backhaul sta cap report tlvs\n");
		return -1;
	}
	return 0;
}
int parse_cu_tlv(
	struct own_1905_device * ctx,
	struct _1905_map_device *dev,
	unsigned char *buf)
{
	unsigned char *temp_buf = buf;
	u8 temp_len = 0;
	unsigned short length = 0;
	unsigned char func_type = 0;
	struct ch_util_lib ch_util;
	struct radio_info_db *radio = NULL;

	//calculate tlv length
	length = get_cmdu_tlv_length(temp_buf);

	//shift to tlv value field
	temp_buf += 3;
	temp_len += 3;

	if (os_memcmp(temp_buf, MTK_OUI, OUI_LEN)) {
		err(DEBUG_CAT_TLVPRS, "OUI not mtk_oui; do not handle!\n");
		return length;
	}
	temp_buf += OUI_LEN;
	func_type = *temp_buf++;//FUNC_LEN is 1


	if (func_type == FUNC_VENDOR_CHANNEL_UTIL_RSP) {
		while(temp_len < (length - (OUI_LEN+1))) {
			ch_util.ch_num = *temp_buf++;
			temp_len++;
			ch_util.edcca = (u32)*temp_buf;
			temp_buf +=4;
			temp_len += 4;
			radio = topo_srv_get_radio_by_channel(dev,ch_util.ch_num);
			if(!radio)
				return length;
			debug(DEBUG_CAT_TLVPRS, "ch_util_channel is %d\n", ch_util.ch_num);
			radio->cu_distribution.edcca_airtime = ch_util.edcca;
			radio->cu_distribution.ch_num = ch_util.ch_num;
			debug(DEBUG_CAT_TLVPRS, " other dev\n");
			topo_srv_update_ch_planning_info(ctx,dev,NULL,radio,1);
		}

	}
	return length;
}

int parse_tunneled_message_type_tlv(struct own_1905_device *ctx, unsigned char *buf, int left_tlv_len, u8 *tunnel_type)
{
	unsigned char *temp_buf;
	unsigned short length = 0;

	temp_buf = buf;

	if ((*temp_buf) != TUNNELED_MESSAGE_TYPE)
		return -1;

	if (check_fixed_length_tlv(TUNNELED_MESSAGE_TYPE_LEN, temp_buf, left_tlv_len) == FALSE) {
		err(DEBUG_CAT_TLVPRS, "error in length\n");
		return -1;
	}

	//calculate tlv length
	length = get_tlv_len(temp_buf);

	temp_buf += 3;

	*tunnel_type = *temp_buf++;

	return (length+3);
}

int parse_source_info_tlv(struct own_1905_device *ctx, unsigned char *buf, int left_tlv_len, uint32_t *client_id, u8 *mac)
{
	unsigned char *temp_buf = NULL;
	unsigned short length = 0;
	struct mapd_global *global = ctx->back_ptr;
	u8 already_seen = 0;

	temp_buf = buf;

	if ((*temp_buf) != SOURCE_INFO_TYPE)
		return -1;

	if (check_fixed_length_tlv(SOURCE_INFO_TYPE_LEN, temp_buf, left_tlv_len) == FALSE) {
		err(DEBUG_CAT_TLVPRS, "error in length\n");
		return -1;
	}
	//calculate tlv length
	length = get_tlv_len(temp_buf);

	temp_buf += 3;

	os_memcpy(mac, temp_buf, ETH_ALEN);
	temp_buf += ETH_ALEN;
	if (global->params.Certification)
		*client_id = client_db_track_add(global, mac, &already_seen);

	return (length+3);
}

int parse_tunneled_type_tlv(struct own_1905_device *ctx, unsigned char *buf, struct client *cli, u8 tunnel_type, struct _1905_map_device *dev)
{
	unsigned char *temp_buf;
	unsigned short length = 0;
	temp_buf = buf;
	struct associated_clients *sta = NULL;

	if((*temp_buf) == TUNNELED_TYPE) {
		temp_buf++;
	}
	else {
		return -1;
	}

	//calculate tlv length
	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length |(*(temp_buf+1));

	temp_buf += 2;
#if 0
	if (tunnel_type < MAX_TUNNEL_TYPE) {
		if (cli->tunnel_info[tunnel_type].tunneled_payload != NULL &&
			cli->tunnel_info[tunnel_type].tunnel_payload_len != length)
			cli->tunnel_info[tunnel_type].tunneled_payload =
			os_realloc(cli->tunnel_info[tunnel_type].tunneled_payload, length);
		else
			cli->tunnel_info[tunnel_type].tunneled_payload = os_malloc(length);
		os_memcpy(cli->tunnel_info[tunnel_type].tunneled_payload, temp_buf, length);
	}
#endif
#ifdef CENT_STR
	if (ctx->cent_str_en && (tunnel_type == ASSOC_REQ_NORMAL || tunnel_type == ASSOC_REQ_REASSOC)) {
		cli->is_remote = 1;
		parse_assoc_req((struct mapd_global *)ctx->back_ptr, cli->mac_addr,
			cli->bssid, temp_buf, length, cli->current_chan,
#ifdef MAP_6E_SUPPORT
			cli->current_band,
#endif
			tunnel_type
#ifdef MAP_R6
		, dev->_1905_info.al_mac_addr
		, 0
#endif /* MAP_R6 */
	);
		sta = topo_srv_get_associate_client(ctx, dev, cli->mac_addr);
		if (sta) {
			os_get_time(&(sta->stat_db.last_traffic_stats_time));
			sta->stat_db.last_bytes_recieved = 0;
			sta->stat_db.last_bytes_sent = 0;
#ifdef MAP_R6
			os_get_time(&(sta->stat_db.last_traffic_stats_time_mlo));
			sta->stat_db.last_bytes_recieved_mlo = 0;
			sta->stat_db.last_bytes_sent_mlo = 0;
#endif
		}
#ifdef DATA_ELEMENT_SUPPORT
		create_sta_association_json_file(ctx, cli->mac_addr);
#endif
	}
#endif
	return (length+3);
}


int parse_tunneled_message(struct own_1905_device *ctx, unsigned char *buf, int left_tlv_len, struct _1905_map_device *dev)
{
	int length = 0, len, tlv_len;
	unsigned char *temp_buf = NULL;
	unsigned int integrity = 0;
	temp_buf = buf;
	struct client *cli = NULL;
	u8 tunnel_type = 255;
	uint32_t cli_id = 0;
	u8 mac[ETH_ALEN] = {0};
	u8 already_seen = 0;
	struct mapd_global *global = (struct mapd_global *)ctx->back_ptr;
#ifdef MAP_R6
	int index = 0;
	int i;
	uint32_t aff_client_id;
	struct client *aff_cli;
#endif /* MAP_R6 */

	while(1)
	{
		len = get_tlv_len(temp_buf);
		tlv_len = len + 3;
		if (left_tlv_len < tlv_len) {
			err(DEBUG_CAT_TLVPRS, "Error TLV len, type = %d, left_tlv_length %d less than tlv_len %d\n",
					*temp_buf, left_tlv_len, tlv_len);
			return -1;
		}
		if (*temp_buf == SOURCE_INFO_TYPE)
		{
			length = parse_source_info_tlv(ctx, temp_buf, left_tlv_len, &cli_id, mac);
			if(length < 0)
			{
				err(DEBUG_CAT_TLVPRS, "error source info tlv\n");
				return -1;
			}
			integrity |= (1 << 0);
			temp_buf += length;
		} else if (*temp_buf == TUNNELED_MESSAGE_TYPE) {

			length = parse_tunneled_message_type_tlv(ctx, temp_buf, left_tlv_len, &tunnel_type);
			if(length < 0)
			{
				err(DEBUG_CAT_TLVPRS, "error tunneled message type tlv\n");
				return -1;
			}
			integrity |= (1 << 0);
			temp_buf += length;
		}  else if (*temp_buf == TUNNELED_TYPE) {
			if (global->params.Certification) {
				cli = client_db_get_client_from_client_id((struct mapd_global *)ctx->back_ptr, cli_id);
			} else if (ctx->cent_str_en && (tunnel_type == ASSOC_REQ_NORMAL || tunnel_type == ASSOC_REQ_REASSOC)) {

				cli_id = client_db_track_add(global, mac, &already_seen);
				if (cli_id == (uint32_t)-1) {
					err(DEBUG_CAT_TLVPRS, "Client id not found\n");
					return -1;
				}
				cli = client_db_get_client_from_client_id((struct mapd_global *)ctx->back_ptr, cli_id);
				if (!cli) {
					err(DEBUG_CAT_TLVPRS, "Client id %d can not find client db\n", cli_id);
					return -1;
				}
#ifdef MAP_R6
				info(DEBUG_CAT_TLVPRS, "cli mac = "MACSTR " cli->mlo_enable = %d", MAC2STR(cli->mac_addr), cli->mlo_enable);
				info(DEBUG_CAT_TLVPRS, "cli mld mac = " MACSTR, MAC2STR(cli->mld_addr));
				for (i = 0; cli->mlo_enable && i < MAX_MLD_CLI; i++) {
					aff_client_id = client_db_get_cid_from_mld_mac(global, mac, index);
					index = aff_client_id + 1;
					err(DEBUG_CAT_TLVPRS, "aff_client_id = %u", aff_client_id);
					if (aff_client_id == (uint32_t)-1) {
						err(DEBUG_CAT_TLVPRS, "client id not found by mld mac");
						break;
					}
					if (cli->client_id == aff_client_id) {
						err(DEBUG_CAT_TLVPRS, "This is same client id will handle after afflieated cli = %u",
						 aff_client_id);
						continue;
					}
					aff_cli = client_db_get_client_from_client_id(global, aff_client_id);
					if (!aff_cli) {
						err(DEBUG_CAT_TLVPRS, "aff_cli not found by aff_client_id %d", aff_client_id);
						break;
					}
					remove_steer_candidate_list(global, aff_cli);
					cancel_steer_timer(global, aff_cli);
					already_seen = 2;
					err(DEBUG_CAT_TLVPRS, "going to clear client id = %u client mac = " MACSTR,
						aff_cli->client_id, MAC2STR(aff_cli->mac_addr));
					client_db_track_add(global, aff_cli->mac_addr, &already_seen);
				}
				if (cli->mlo_enable) {
					remove_steer_candidate_list(global, cli);
					cancel_steer_timer(global, cli);
					already_seen = 2;
					notice(DEBUG_CAT_TLVPRS, "going to clear main client id = %u client mac = " MACSTR"\n",
						cli->client_id, MAC2STR(cli->mac_addr));
					client_db_track_add(global, cli->mac_addr, &already_seen);
				}
#endif /* MAP_R6 */
				already_seen = 0;
				cli_id = client_db_track_add(global, mac, &already_seen);
				if (cli_id == (uint32_t)-1) {
					err(DEBUG_CAT_TLVPRS, "Client id not found\n");
					return -1;
				}
				cli = client_db_get_client_from_client_id((struct mapd_global *)ctx->back_ptr, cli_id);
			}
			if (cli && tunnel_type < MAX_TUNNEL_TYPE)
				length = parse_tunneled_type_tlv(ctx, temp_buf, cli, tunnel_type, dev);
			else
				length = get_cmdu_tlv_length(temp_buf);
			if(length < 0)
			{
				err(DEBUG_CAT_TLVPRS, "error tunneled type tlv\n");
				return -1;
			}
			integrity |= (1 << 0);
			temp_buf += length;
		} else if(*temp_buf == END_OF_TLV_TYPE) {
			break;
		} else {
			length = get_cmdu_tlv_length(temp_buf);
			temp_buf += length;
		}
		left_tlv_len -= tlv_len;
	}
		/*check integrity*/
	if(integrity != 1) {
		err(DEBUG_CAT_TLVPRS, "error when check tunneled message tlvs\n");
		return -1;
	}
	return 0;
}
int parse_1905_ack_message(struct own_1905_device *ctx, struct _1905_map_device *dev, unsigned char *buf, int tlv_length)
{
	int length = 0;
	unsigned char *temp_buf;
	unsigned short len = 0;
	unsigned int tlv_len = 0;

	temp_buf = buf;

	while (1) {
		len = get_tlv_len(temp_buf);
		tlv_len = len + 3;
		if (tlv_length < tlv_len) {
			err(DEBUG_CAT_TLVPRS, "[%d] Error TLV len, type = %d, left_tlv_length %d less than tlv_len %d\n",
			      __LINE__, *temp_buf, tlv_length, tlv_len);
			return -1;
		}
		if (*temp_buf == ERROR_CODE_TYPE) {
			if (check_fixed_length_tlv(ERROR_CODE_TLV_LEN, temp_buf, tlv_length) == FALSE) {
				err(DEBUG_CAT_TLVPRS, "error in error code tlv\n");
				return -1;
			}
			length = get_cmdu_tlv_length(temp_buf);
			temp_buf += length;
		}
		else if (*temp_buf == END_OF_TLV_TYPE) {
			break;
		} else {
			/*ignore extra tlv*/
			length = get_cmdu_tlv_length(temp_buf);
			temp_buf += length;
		}
		tlv_length -= tlv_len;
	}

	return 0;
}


#endif

#ifdef MTK_MLO_MAP_SUPPORT
void netopt_fill_ch_util_per_radio(struct _1905_map_device *_1905_device, struct own_1905_device *ctx)
{
	struct bss_info_db *bss = NULL, *bss_tmp = NULL;
	struct radio_info_db *radio = NULL;
	u8 ch_util_filled = 0;

	radio = topo_srv_get_radio(_1905_device, NULL);
	while (radio) {
		SLIST_FOREACH_SAFE(bss, &(_1905_device->first_bss), next_bss, bss_tmp) {
#ifdef MAP_R6
			if (!bss->radio) {
				err(DEBUG_CAT_TLVPRS, "bss radio is null for bssid\n" MACSTR, MAC2STR(bss->bssid));
				continue;
			}
#endif /* MAP_R6 */

			if (bss->radio == radio && ch_util_filled == 0) {
				info(DEBUG_CAT_TLVPRS, NETOPT_PREX" Filling up the channel util old value\n");

				ch_util_filled = 1;
				radio->netopt_ch_util[radio->netopt_ch_util_cnt] = bss->ch_util;
				radio->netopt_ch_util_cnt++;

				if (!(radio->netopt_ch_util_cnt % ctx->network_optimization.netopt_ch_util_sec)) {
					info(DEBUG_CAT_TLVPRS, NETOPT_PREX" cu util rollover.\n");
					radio->netopt_ch_util_cnt_completed = 1;
				}

				/*rollover from ch util sample size start with Zero index.*/
				radio->netopt_ch_util_cnt = radio->netopt_ch_util_cnt
							    % ctx->network_optimization.netopt_ch_util_sec;
			}
		}
		ch_util_filled = 0;
		radio = topo_srv_get_next_radio(_1905_device, radio);
	}
}
#endif

int parse_ap_metrics_response_message(struct own_1905_device *ctx, struct _1905_map_device *dev,
        unsigned char *buf, int len)
{
	int length =0;
	unsigned char *temp_buf;
	int parse_len = 0;
	temp_buf = buf;
	while(1) {
		if(parse_len > len) {
			err(DEBUG_CAT_TLVPRS, " parse_len (%d) is bigger than total len (%d), drop this topo event\n", parse_len, len);
			return -1;
		}
		if (*temp_buf == AP_METRICS_TYPE) {
			length = get_cmdu_tlv_length(temp_buf);
			if(length > (len - parse_len)) {
				err(DEBUG_CAT_TLVPRS, "error len in ap metrics tlv\n");
				return -1;
			}
			length = parse_ap_metrics_tlv(ctx, dev, temp_buf);
			if(length < 0) {
				err(DEBUG_CAT_TLVPRS, "error ap metrics tlv\n");
				return -1;
			}
			temp_buf += length;
			parse_len = parse_len + length;
		} else if (*temp_buf == ASSOC_STA_TRAFFIC_STATS_TYPE) {
			length = get_cmdu_tlv_length(temp_buf);
			if(length > (len - parse_len)) {
				err(DEBUG_CAT_TLVPRS, "error len in assoc sta traffic stats tlv\n");
				return -1;
			}
			length = parse_assoc_sta_traffic_stats_tlv(ctx, dev, temp_buf);
			if(length < 0) {
				err(DEBUG_CAT_TLVPRS, "error assoc sta traffic stats tlv\n");
				return -1;
			}
			temp_buf += length;
			parse_len = parse_len + length;
		} else if (*temp_buf == ASSOC_STA_LINK_METRICS_TYPE) {
			length = get_cmdu_tlv_length(temp_buf);
			if(length > (len - parse_len)) {
				err(DEBUG_CAT_TLVPRS, "error len in assoc sta link metrics tlv\n");
				return -1;
			}
			length = parse_assoc_sta_link_metrics_tlv(ctx, dev, temp_buf);
			if(length < 0) {
				err(DEBUG_CAT_TLVPRS, "error assoc sta link metrics tlv\n");
				return -1;
			}
			temp_buf += length;
			parse_len = parse_len + length;
		}
#ifdef MAP_R2
		/* Zero or more Radio Metrics TLVs */
		else if (*temp_buf == RADIO_METRIC_TYPE) {
			length = get_cmdu_tlv_length(temp_buf);
			if(length > (len - parse_len)) {
				err(DEBUG_CAT_TLVPRS, "error len in radio metrics tlv\n");
				return -1;
			}
			length = parse_radio_metrics_tlv(ctx, dev, temp_buf);
			if(length < 0) {
				err(DEBUG_CAT_TLVPRS, "error radio metrics tlv\n");
				return -1;
			}
			temp_buf += length;
			parse_len = parse_len + length;
		}
		else if (*temp_buf == TLV_802_11_VENDOR_SPECIFIC) {
			length = get_cmdu_tlv_length(temp_buf);
			if(length > (len - parse_len)) {
				err(DEBUG_CAT_TLVPRS, "error len in cu tlv\n");
				return -1;
			}
			length = parse_cu_tlv(ctx, dev, temp_buf);
			if(length < 0) {
				err(DEBUG_CAT_TLVPRS, "error cu tlv\n");
				return -1;
			}
			temp_buf += length;
			parse_len = parse_len + length;
		}
		/* One or more AP Extended Metrics TLVs */
		else if (*temp_buf == AP_EXTENDED_METRIC_TYPE) {
			length = get_cmdu_tlv_length(temp_buf);
			if(length > (len - parse_len)) {
				err(DEBUG_CAT_TLVPRS, "error len in assoc ap extended metric tlv\n");
				return -1;
			}
			length = parse_assoc_ap_extended_metrics_tlv(ctx, dev, temp_buf);
			if(length < 0) {
				err(DEBUG_CAT_TLVPRS, "error assoc ap extended metric tlv\n");
				return -1;
			}
			temp_buf += length;
			parse_len = parse_len + length;
		}
#ifdef MAP_R6
		/* One or more MLO AP Extended Metrics TLVs */
		else if (*temp_buf == MLO_AP_EXTENDED_METRIC_TYPE) {
			length = get_cmdu_tlv_length(temp_buf);
			if (length > (len - parse_len)) {
				err(DEBUG_CAT_TLVPRS, "error len in assoc MLO ap extended metric tlv\n");
				return -1;
			}
			length = parse_assoc_mlo_ap_extended_metrics_tlv(ctx, dev, temp_buf);
			if (length < 0) {
				err(DEBUG_CAT_TLVPRS, "error assoc ap extended metric tlv\n");
				return -1;
			}
			temp_buf += length;
			parse_len = parse_len + length;
		}
#endif
		/* Zero or more Associated STA Extended Link Metrics TLVs */
		else if (*temp_buf == ASSOCIATED_STA_EXTENDED_LINK_METRIC_TYPE) {
			length = get_cmdu_tlv_length(temp_buf);
			if(length > (len - parse_len)) {
				err(DEBUG_CAT_TLVPRS, "error len in assoc sta extended link metric tlv\n");
				return -1;
			}
			length = parse_assoc_sta_ext_metrics_tlv(ctx, dev, temp_buf);
			if(length < 0) {
				err(DEBUG_CAT_TLVPRS, "error assoc sta extended link metric tlv\n");
				return -1;
			}
			temp_buf += length;
			parse_len = parse_len + length;
		}
#endif
#ifdef MAP_R3_WF6
		else if (*temp_buf == 0xB0) {
			notice(DEBUG_CAT_TLVPRS, "mapd Controller recvd assoc wf6 STA status tlv\n");
			length = parse_assoc_sta_wifi6_status_report_tlv(temp_buf, dev);
			if(length < 0) {
				err(DEBUG_CAT_TLVPRS, "error assoc sta extended link metric tlv\n");
				return -1;
			}
			temp_buf += length;
			parse_len += length;
		}
#endif
#ifdef MAP_R6
		else if (*temp_buf == AFFILIATED_STA_TRAFFIC_STATS_TYPE) {
			length = get_cmdu_tlv_length(temp_buf);
			if (length > (len - parse_len)) {
				err(DEBUG_CAT_TLVPRS, "error len in aff sta traffic stats tlv R6\n");
				return -1;
			}

			length = parse_aff_sta_traffic_stats_tlv(ctx, dev, temp_buf);
			if (length < 0) {
				err(DEBUG_CAT_TLVPRS, "error aff sta traffic stats tlv R6\n");
				return -1;
			}
			temp_buf += length;
			parse_len = parse_len + length;
		}
#endif
		else if (*temp_buf == END_OF_TLV_TYPE) {
			break;
		} else {
			length = get_cmdu_tlv_length(temp_buf);
			if(length < 0||  length > (len - parse_len)) {
				err(DEBUG_CAT_TLVPRS, "error len\n");
				return -1;
			}
			temp_buf += length;
			parse_len = parse_len + length;
		}
	}
	return 0;
}

/**
* @brief Fn to parse link metric query tlv
*
* @param buf msg buffer
* @param target target for the link metric
* @param type rx/tx/rx-tx
*
* @return -1 if error else tlv lenght
*/
int parse_link_metric_query_type_tlv(unsigned char *buf,
		unsigned char *target, unsigned char *type)
{
	unsigned char *temp_buf;
	int length = 0;

	temp_buf = buf;

	if ((*temp_buf) == LINK_METRICS_QUERY_TLV_TYPE)
		temp_buf++;
	else {
		return -1;
	}

	/*calculate tlv length */
	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length | (*(temp_buf + 1));
	/*shift to tlv value field */
	temp_buf += 2;

	/*set target mac = 0 if query all neighbors */
	if (*temp_buf == QUERY_ALL_NEIGHBOR) {
		memset(target, 0, ETH_ALEN);
		temp_buf += 1;

		/*add for IOT issue with BRCM */
		if (length == 8)
			temp_buf += ETH_ALEN;

	} else if (*temp_buf == QUERY_SPECIFIC_NEIGHBOR) {
		temp_buf += 1;
		memcpy(target, temp_buf, ETH_ALEN);
		temp_buf += ETH_ALEN;
	} else {
		debug(DEBUG_CAT_TLVPRS, "reserve valus %d\n", *temp_buf);
		return -1;
	}

	if (*temp_buf == TX_METRICS_ONLY)
		*type = TX_METRICS_ONLY;
	else if (*temp_buf == RX_METRICS_ONLY)
		*type = RX_METRICS_ONLY;
	else if (*temp_buf == BOTH_TX_AND_RX_METRICS)
		*type = BOTH_TX_AND_RX_METRICS;

	return (length + 3);
}

#ifdef MAP_VENDOR_SUPPORT
int check_if_40M_bw_cont_supported(struct own_1905_device *ctx, int op_class)
{
	int bw = 0;
	int ret = 1;

	if (ctx->device_role != DEVICE_ROLE_CONTROLLER)
		return ret;
	bw = chan_mon_get_bw_from_op_class(op_class);
	if (bw == BW_40 && ctx->is_40M_bw_disable == 1)
		ret = 0;
	else
		ret = 1;

	return ret;
}
#endif /* MAP_VENDOR_SUPPORT */

#ifdef MAP_VENDOR_SUPPORT_RADAR
int check_if_nop_cont_support(struct own_1905_device *ctx, int preference, int reason)
{
	int ret = 1;

	if (ctx->device_role != DEVICE_ROLE_CONTROLLER)
		return ret;

	if (ctx->NOP_Sync == 0)
		return ret;

	if (preference == 0x00 && reason ==  NOP_RADAR_REASON_CODE)
		ret = 0;

	return ret;
}
#endif /* MAP_VENDOR_SUPPORT_RADAR */


/**
* @brief Fn to insert channel preference
*
* @param dev 1905 map device pointer
* @param buf msg buffer
* @param len msg len
*
* @return 0 if success else error
*/

int insert_new_ch_prefer_info(
	struct own_1905_device *ctx,
	struct _1905_map_device * dev,
	unsigned char *buf,
	unsigned short len)
{
	struct radio_ch_prefer *chcap = NULL;
	struct prefer_info_db *prefer = NULL;
	struct prefer_info_db *high_prefer = NULL;
	struct prefer_info_db *opclass_chlist = NULL;
	struct ap_radio_basic_capability *bcap = NULL;
	struct basic_cap_db *cap, *tcap = NULL;
	unsigned char channel = 0, channel_found = FALSE;
	unsigned char ch_add[MAX_CH_NUM] = {0}, ch_count = 0;
	unsigned char *pos = buf;
	unsigned short check_len = 0, prefer_len = 0;
	unsigned char i = 0, j = 0, k = 0, op_class = 0, ch_num = 0, preference, reason = 0;
	struct prefer_info_db *prefer_info = NULL, *t_prefer_info = NULL;
	int index = -1;
	u8 nop_expiry_ch_plan_trigger = 0;
	struct monitor_ch_info ch_info = {0};
#ifdef MAP_VENDOR_SUPPORT_RADAR
	unsigned char ch_pref_vend_cnt = 0;
	unsigned char nop_sync_at_cont = 0;
	int ret2 = 0, vendor_tlv_len = 0;
	struct ch_pref_tlv *ch_pref_vend = NULL;

	ch_pref_vend = (struct ch_pref_tlv *)os_zalloc(sizeof(struct ch_pref_tlv) * MAX_CH_NUM);
	if (ch_pref_vend == NULL) {
		err(DEBUG_CAT_TLVPRS, "mem not allocated failure\n");
		return -1;
	}
#endif /* MAP_VENDOR_SUPPORT_RADAR */

	debug(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"ENTRY IN FUNCTION\n");
	if (len < 7) {
		err(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"length error less than 7\n");
#ifdef MAP_VENDOR_SUPPORT_RADAR
	os_free(ch_pref_vend);
#endif /* MAP_VENDOR_SUPPORT_RADAR */
		return -1;
	}

	struct radio_info_db *radio = topo_srv_get_radio(dev, buf);
	if (!radio) {
		err(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"can't find radio by identifier("MACSTR")\n", MAC2STR(buf));
#ifdef MAP_VENDOR_SUPPORT_RADAR
		os_free(ch_pref_vend);
#endif /* MAP_VENDOR_SUPPORT_RADAR */
		return -1;
	}
	chcap = &radio->chan_preferance;
	pos += ETH_ALEN;
	check_len += ETH_ALEN;
	chcap->op_class_num = *pos;
	pos += 1;
	check_len += 1;
	chcap->is_valid = 1;
	opclass_chlist =
			(struct prefer_info_db *)
			os_malloc(sizeof(struct prefer_info_db));
	if (!opclass_chlist) {
		err(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"alloc struct prefer_info_db fail\n");
#ifdef MAP_VENDOR_SUPPORT_RADAR
		os_free(ch_pref_vend);
#endif /* MAP_VENDOR_SUPPORT_RADAR */
		return -1;
	}

	for (i = 0; i < chcap->op_class_num; i++) {
		op_class = *pos;
		pos += 1;
		check_len += 1;
		ch_num = *pos;
		pos += 1;
		check_len += 1;
		prefer =
			(struct prefer_info_db *)
			os_malloc(sizeof(struct prefer_info_db));
		if (!prefer) {
			err(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"alloc struct prefer_info_db fail\n");
#ifdef MAP_VENDOR_SUPPORT_RADAR
			os_free(ch_pref_vend);
#endif /* MAP_VENDOR_SUPPORT_RADAR */
			return -1;
		}
		memset(prefer, 0, prefer_len);
		memset(opclass_chlist, 0, (sizeof(struct prefer_info_db)));
		if (check_support_current_op_class(op_class) == FALSE) {
			prefer->op_class = 0;
			prefer->ch_num = ch_num;
			preference = *(pos + ch_num) >> 4;
			reason = *(pos + ch_num) & 0x0f;
		} else {
			prefer->op_class = op_class;
			prefer->ch_num = ch_num;
			get_op_class_channel_list(op_class, opclass_chlist);
			preference = *(pos + ch_num) >> 4;
			reason = *(pos + ch_num) & 0x0f;
		}
#ifdef MAP_VENDOR_SUPPORT
		if (!check_if_40M_bw_cont_supported(ctx, op_class) && reason != 7) {
			preference = 1;
			reason = 12;
			debug(DEBUG_CAT_TLVPRS, "Pref one for 40M opclass at agent1:%d\n", op_class);
		}
#endif /* MAP_VENDOR_SUPPORT */
#ifdef MAP_VENDOR_SUPPORT_RADAR
		if (IS_BAND_5G(radio->band)
			&& !check_if_nop_cont_support(ctx, preference, reason)
			&& ch_pref_vend[ch_pref_vend_cnt].op_class_cnt < MAX_OP_CLASS_NUM) {
			ch_pref_vend[ch_pref_vend_cnt].opclass[ch_pref_vend[ch_pref_vend_cnt].op_class_cnt].op_class = op_class;
			os_memcpy(ch_pref_vend[ch_pref_vend_cnt].identifier, radio->identifier, ETH_ALEN);
			ch_pref_vend[ch_pref_vend_cnt].op_class_cnt++;
		}
#endif /* MAP_VENDOR_SUPPORT_RADAR*/

		if (prefer->op_class == 0) {
			pos += ch_num;
			check_len += ch_num;
			pos += 1;
			check_len += 1;
			prefer->ch_num = 0;
			prefer->perference = 0;
			prefer->reason = 0;
		} else if ((opclass_chlist->ch_num > prefer->ch_num) && (preference == 0) && !(reason == 0x07 || reason == 0x0c)) {
			memcpy(prefer->ch_list, pos, ch_num);

			for (j = 0; j < opclass_chlist->ch_num; j++) {
				for (k = 0; k < prefer->ch_num; k++) {
					if (opclass_chlist->ch_list[j] == prefer->ch_list[k])
						break;
				}
				if (k == prefer->ch_num) {
					high_prefer =
							(struct prefer_info_db *)
							os_malloc(sizeof(struct prefer_info_db));
					if (!high_prefer) {
						err(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"alloc struct prefer_info_db fail\n");
						os_free(opclass_chlist);
						os_free(prefer);
#ifdef MAP_VENDOR_SUPPORT_RADAR
						os_free(ch_pref_vend);
#endif /* MAP_VENDOR_SUPPORT_RADAR */

						return -1;
					}
					high_prefer->op_class = op_class;
					high_prefer->ch_num = 1;
					high_prefer->ch_list[0] = opclass_chlist->ch_list[j];
					high_prefer->perference = 0xf;
					high_prefer->reason = *(pos + ch_num) & 0x0f;
#ifdef MAP_VENDOR_SUPPORT
			if (!check_if_40M_bw_cont_supported(ctx, op_class) && high_prefer->reason != 0x07) {
				high_prefer->perference = 1;
				high_prefer->reason = 12;
				debug(DEBUG_CAT_TLVPRS, "Pref one for 40M opclass at agent2:%d\n", op_class);
			}
#endif /* MAP_VENDOR_SUPPORT */


					break;
				}
			}
			memcpy(prefer->ch_list, pos, ch_num);
			debug(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"opclass %d, chnum %d, ch[0] %d\n",
				prefer->op_class,
				prefer->ch_num,
				prefer->ch_list[0]);
			pos += ch_num;
			check_len += ch_num;
			/*bit 4~7 */
			prefer->perference = *pos >> 4;
			/*bit 0~3 */
			prefer->reason = *pos & 0x0f;
			pos += 1;
			check_len += 1;
#ifdef MAP_VENDOR_SUPPORT
			if (!check_if_40M_bw_cont_supported(ctx, op_class) &&  prefer->reason != 0x07) {
				high_prefer->perference = 1;
				high_prefer->reason = 12;
				debug(DEBUG_CAT_TLVPRS, "Pref one for 40M opclass at agent3:%d\n", op_class);
			}
#endif /* MAP_VENDOR_SUPPORT */

		} else if (prefer->ch_num) {
			memcpy(prefer->ch_list, pos, ch_num);
			debug(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"opclass %d, chnum %d, ch[0] %d\n",
				prefer->op_class,
				prefer->ch_num,
				prefer->ch_list[0]);
			pos += ch_num;
			check_len += ch_num;
			/*bit 4~7 */
			prefer->perference = *pos >> 4;
			/*bit 0~3 */
			prefer->reason = *pos & 0x0f;
			pos += 1;
			check_len += 1;
#ifdef MAP_VENDOR_SUPPORT
			if (!check_if_40M_bw_cont_supported(ctx, prefer->op_class) &&  prefer->reason != 0x07) {
				prefer->perference = 1;
				prefer->reason = 12;
				debug(DEBUG_CAT_TLVPRS, "Pref one for 40M opclass at agent4:%d\n", prefer->op_class);
			}
#endif /* MAP_VENDOR_SUPPORT */
#ifdef MAP_VENDOR_SUPPORT_RADAR
		if (IS_BAND_5G(radio->band)
			&& (!check_if_nop_cont_support(ctx, prefer->perference,  prefer->reason))
			&& (ch_pref_vend[ch_pref_vend_cnt].op_class_cnt < MAX_OP_CLASS_NUM)) {
			ch_pref_vend[ch_pref_vend_cnt].opclass[ch_pref_vend[ch_pref_vend_cnt].op_class_cnt - 1].ch_num = prefer->ch_num;
		for (k = 0; k < prefer->ch_num; k++) {
			ch_pref_vend[ch_pref_vend_cnt].opclass[ch_pref_vend[ch_pref_vend_cnt].op_class_cnt - 1].chan_list[k].channel =
			prefer->ch_list[k];
			ch_pref_vend[ch_pref_vend_cnt].opclass[ch_pref_vend[ch_pref_vend_cnt].op_class_cnt - 1].chan_list[k].preference =
			0;
			ch_pref_vend[ch_pref_vend_cnt].opclass[ch_pref_vend[ch_pref_vend_cnt].op_class_cnt - 1].chan_list[k].reason_code =
			NOP_RADAR_REASON_CODE;
			nop_sync_at_cont = 1;
			info(DEBUG_CAT_TLVPRS, "NOP SYNC AT CONTROLLER for opclass:%u, ch:%u\n",
				ch_pref_vend[ch_pref_vend_cnt].opclass[ch_pref_vend[ch_pref_vend_cnt].op_class_cnt - 1].op_class
				, prefer->ch_list[k]);
		}
		}
#endif /* MAP_VENDOR_SUPPORT_RADAR*/

		}else {
			/*if no ch_list under preference channel, make all channel to highest prefernce channel as MAP SEPC*/
			debug(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"ch num is 0 for this opclass %d\n", prefer->op_class);
			get_op_class_channel_list(op_class,prefer);
#ifndef MAP_6E_SUPPORT
			/*bit 4~7 */
			prefer->perference = *pos >> 4;
			/*bit 0~3 */
			prefer->reason = *pos & 0x0f;
#else
			/*bit 4~7 */
			prefer->perference = 0xf;
			/*bit 0~3 */
			prefer->reason = 0;
#endif
			pos += 1;
			check_len += 1;
#ifdef MAP_VENDOR_SUPPORT
			if (!check_if_40M_bw_cont_supported(ctx, prefer->op_class)) {
				prefer->perference = 1;
				prefer->reason = 12;
				debug(DEBUG_CAT_TLVPRS, "Pref one for 40M opclass at agent4:%d\n", prefer->op_class);
			}
#endif /* MAP_VENDOR_SUPPORT */

		}
		if ((ctx->device_role == DEVICE_ROLE_CONTROLLER))
		{
			int i;
			for (i = 0; i < prefer->ch_num; i++)
			{
#ifdef MAP_VENDOR_SUPPORT
				ch_planning_add_ch_to_preferred_list(ctx,
					dev,
					prefer->ch_list[i],
					radio,
					prefer->ch_list[i] > 14,
					prefer->perference,
					prefer->reason,
					prefer->op_class);
#else
				ch_planning_add_ch_to_preferred_list(ctx,
					prefer->ch_list[i],
					radio,
					prefer->ch_list[i] > 14,
					prefer->perference,
					prefer->reason,
					prefer->op_class);
#endif /* MAP_VENDOR_SUPPORT */
			}

		}
		if (high_prefer) {
			SLIST_INSERT_HEAD(&(chcap->prefer_info_head), high_prefer,
				prefer_info_entry);
			high_prefer = NULL;
		}
		SLIST_INSERT_HEAD(&(chcap->prefer_info_head), prefer,
				prefer_info_entry);
		debug(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"insert struct prefer_info_db\n");
		debug(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"opclass=%d, ch_num=%d perference=%d, reason=%d\n",
				prefer->op_class, prefer->ch_num,
				prefer->perference, prefer->reason);
		debug(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"ch_list:\n");
		for (j = 0; j < prefer->ch_num; j++) {
			debug(DEBUG_CAT_TLVPRS, "%d\n", prefer->ch_list[j]);
		}
	}

	bcap = &radio->radio_capability.basic_caps;
	SLIST_FOREACH_SAFE(cap, &bcap->bcap_head, basic_cap_entry, tcap) {
		ch_count = 0;
		if (cap->op_class == 0 || check_support_current_op_class(cap->op_class) == FALSE) {
			debug(DEBUG_CAT_TLVPRS, "Do not process not valid opclass:%d\n", cap->op_class);
			continue;
		}

		get_op_class_channel_list(cap->op_class, opclass_chlist);
		for (i = 0; i < opclass_chlist->ch_num; i++) {
			channel = opclass_chlist->ch_list[i];
			channel_found = FALSE;
			SLIST_FOREACH_SAFE(prefer_info, &(radio->chan_preferance.prefer_info_head),
				prefer_info_entry, t_prefer_info) {
				if (prefer_info->op_class == cap->op_class) {
					for (j = 0; j < prefer_info->ch_num; j++) {
						if (prefer_info->ch_list[j] == channel) {
							channel_found = TRUE;
							break;
						}
					}
				}
				if (channel_found == TRUE)
					break;
			}
			if (channel_found == FALSE) {
				ch_add[ch_count] = channel;
				ch_count++;
			}
		}
		if (ch_count) {
			prefer =
				(struct prefer_info_db *)
				os_malloc(sizeof(struct prefer_info_db));
			if (!prefer) {
				err(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"alloc struct prefer_info_db fail\n");
				os_free(opclass_chlist);
#ifdef MAP_VENDOR_SUPPORT_RADAR
				os_free(ch_pref_vend);
#endif /* MAP_VENDOR_SUPPORT_RADAR */
				return -1;
			}
			if (chcap->op_class_num < (MAX_OP_CLASS_NUM - 1))
				chcap->op_class_num += 1;
			prefer->op_class = cap->op_class;
			prefer->ch_num = ch_count;
			memcpy(prefer->ch_list, ch_add, ch_count);
			prefer->perference = 0xf;
			prefer->reason = 0;
#ifdef MAP_VENDOR_SUPPORT
			if (!check_if_40M_bw_cont_supported(ctx, prefer->op_class)) {
				prefer->perference = 1;
				prefer->reason = 12;
				debug(DEBUG_CAT_TLVPRS, "Pref zero for 40M opclass at agent6:%d\n", prefer->op_class);
			}
#endif /* MAP_VENDOR_SUPPORT */
			if (ctx->device_role == DEVICE_ROLE_CONTROLLER) {
				for (i = 0; i < prefer->ch_num; i++) {
#ifdef MAP_VENDOR_SUPPORT
					ch_planning_add_ch_to_preferred_list(ctx,
					dev,
					prefer->ch_list[i],
					radio,
					channel > 14,
					prefer->perference,
					prefer->reason,
					prefer->op_class);
#else
					ch_planning_add_ch_to_preferred_list(ctx,
					prefer->ch_list[i],
					radio,
					prefer->ch_list[i] > 14,
					prefer->perference,
					prefer->reason,
					prefer->op_class);
#endif /* MAP_VENDOR_SUPPORT */
				}
			}

			SLIST_INSERT_HEAD(&(chcap->prefer_info_head), prefer,
					prefer_info_entry);
		}
	}

	os_free(opclass_chlist);
	if (len != check_len) {
		err(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"length mismatch len(%d) != check_len(%d)\n",
				len, check_len);
		delete_agent_ch_prefer_info(ctx, dev);
#ifdef MAP_VENDOR_SUPPORT_RADAR
		os_free(ch_pref_vend);
#endif /* MAP_VENDOR_SUPPORT_RADAR */
		return -1;
	}

	/* Clear radar channel when NOP indication received */
	if (ctx->device_role == DEVICE_ROLE_CONTROLLER &&
			IS_BAND_5G(radio->band) && !SLIST_EMPTY(&(chcap->prefer_info_head))) {
		SLIST_FOREACH_SAFE(prefer_info, &(radio->chan_preferance.prefer_info_head),
				prefer_info_entry, t_prefer_info) {
			for (i = 0; i < prefer_info->ch_num; i++) {
				if (prefer_info->perference != 0
						&& (prefer_info->op_class == 118 ||
							prefer_info->op_class == 115 ||
							prefer_info->op_class == 125 ||
							prefer_info->op_class == 121)) {
					index = ch_planning_get_if_dfs_ch_index(prefer_info->ch_list[i]);
					if (index >= 0 &&  dev->prev_radar_ch[index] == 1) {
						dev->prev_radar_ch[index] = 0;
						nop_expiry_ch_plan_trigger = 1;
						break;
					}
				}
			}
		}

#ifdef MAP_VENDOR_SUPPORT_RADAR
		/* Sync NOP in driver when radar at agent*/
		if (nop_sync_at_cont == 1) {
			nop_sync_at_cont = 0;
			vendor_tlv_len = sizeof(struct ch_pref_tlv);
			ret2 = wlanif_issue_wapp_command(ctx->back_ptr, WAPP_USER_SET_VENDOR_CH_PREF, 0,
				NULL, NULL, ch_pref_vend, vendor_tlv_len, 0, 0, 0);
			if (ret2 == -1)
				err(DEBUG_CAT_TLVPRS, " WAPP_USER_SET_VENDOR_CH_PREF fail 1905_2 func for agent\n");
		}

#endif /* MAP_VENDOR_SUPPORT_RADAR */
		if (nop_expiry_ch_plan_trigger == 1) {
			err(DEBUG_CAT_TLVPRS, "channel planning trigger at agent for nop expiry\n");
			nop_expiry_ch_plan_trigger = 0;
			eloop_register_timeout(10, 0, retrigger_ch_planning_post_all_ch_nop_expiry,
					ctx->back_ptr, radio);
			if (ctx->ch_planning_R2.ch_plan_enable_bw &&
				!SLIST_EMPTY(&ctx->ch_planning_R2.first_ch_score)) {
				info(DEBUG_CAT_TLVPRS, "update grp score rank for ch %u, band %d due to nop_expiry\n",
						radio->channel[0], radio->band);
					ch_info.channel_num = radio->channel[0];
					ch_info.band = radio->band;
					ch_planning_group_ch_by_bw(ctx, &ch_info);
			}
		}

	}

#ifdef MAP_VENDOR_SUPPORT_RADAR
	os_free(ch_pref_vend);
#endif /* MAP_VENDOR_SUPPORT_RADAR */
	return 0;
}

int validate_channel_preference_tlv(unsigned char *buf, int left_tlv_len)
{
	unsigned char *temp_buf = buf;
	unsigned char num_op_class, num_channel;

	if (left_tlv_len < ETH_ALEN+1) {
		err(DEBUG_CAT_TLVPRS, "error in length parsing\n");
		return FALSE;
	}
	temp_buf += ETH_ALEN;
	num_op_class = *temp_buf++;
	left_tlv_len -= ETH_ALEN+1;

	if (check_subfield_length(MAX_OP_CLASS_NUM, num_op_class) == FALSE) {
		err(DEBUG_CAT_TLVPRS, "error in op class-\n");
		return FALSE;
	}
	for (int i = 0; i < num_op_class; i++) {
		if (left_tlv_len < 2) {
			err(DEBUG_CAT_TLVPRS, "error in length parsing\n");
			return FALSE;
		}
		temp_buf++;
		num_channel = *temp_buf++;
		left_tlv_len -= 2;
		if (left_tlv_len < num_channel+1) {
			err(DEBUG_CAT_TLVPRS, "error in length parsing\n");
			return FALSE;
		}
		temp_buf += num_channel+1;
		left_tlv_len -= num_channel+1;
	}
	return TRUE;
}
/**
* @brief Fn to parse channel preferce tlv
*
* @param buf msg buffer
* @param dev 1905 map device pointer
*
* @return -1 if error else tlv length
*/
int parse_channel_preference_tlv(
	struct own_1905_device *ctx,
	unsigned char *buf,
	struct _1905_map_device *dev,
	int left_tlv_len)
{
	unsigned char *temp_buf;
	unsigned short length = 0;
	struct radio_info_db *radio = NULL;

	temp_buf = buf;

	if ((*temp_buf) != CH_PREFERENCE_TYPE) {
		err(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"should not go here\n");
		return -1;
	}

	//calculate tlv length
	length = get_tlv_len(temp_buf);

	/*shift to tlv value field*/
	temp_buf += 3;
	left_tlv_len -= 3;

	if (length > left_tlv_len || validate_channel_preference_tlv(temp_buf,
					length) == FALSE) {
		err(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"error in length\n");
		return -1;
	}

	/*insert new channel preference info */
	if (0 > insert_new_ch_prefer_info(ctx, dev, temp_buf, length)) {
		debug(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"insert_new_ch_prefer_info fail\n");
		return -1;
	}

	radio = topo_srv_get_radio(dev, temp_buf);
	if (radio == NULL || radio->operating_class == 0 ||
		radio->channel[0] == 0) {
		err(DEBUG_CAT_TLVPRS, "do not recv operating ch report for dev"MACSTR "do not set  ch_preference_available to true\n",
			MAC2STR(dev->_1905_info.al_mac_addr));
	} else {
		dev->ch_preference_available = TRUE;
		debug(DEBUG_CAT_TLVPRS, "ch_preference_available true for "MACSTR"\n", MAC2STR(dev->_1905_info.al_mac_addr));
	}

#ifdef MAP_R6
#ifndef EM_PLUS_SUPPORT
	debug(DEBUG_CAT_TLVPRS, "update ch pref..\n");
	if (dev->afcEnabled) {
		clear_afc_skip_list(dev);
		update_afc_ch_for_dev(ctx, dev);
	}
#endif
#endif
	return (length + 3);
}

/**
* @brief Fn to update parse channel preferce
*		when channel preference TLV is not
*		present
*
* @param buf msg buffer
* @param dev 1905 map device pointer
*
* @return -1 if error else tlv length
*/
int update_channel_preference(
	struct own_1905_device *ctx,
	struct _1905_map_device *dev)
{
	struct radio_info_db *radio = NULL, *tradio = NULL;
	struct ap_radio_basic_capability *bcap_db = NULL;
	struct basic_cap_db *cap = NULL;
	struct prefer_info_db *prefer = NULL;
	struct radio_ch_prefer *chcap = NULL;
	unsigned char op_class;
	int op_class_num = 0, i = 0, j = 0;

	SLIST_FOREACH_SAFE(radio, &(dev->first_radio), next_radio, tradio) {
		debug(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"radio identifier("MACSTR")\n", MAC2STR(radio->identifier));
		bcap_db = &radio->radio_capability.basic_caps;
		op_class_num = bcap_db->op_class_num;

		chcap = &radio->chan_preferance;
		chcap->op_class_num = op_class_num;
		chcap->is_valid = 1;

		cap = SLIST_FIRST(&(bcap_db->bcap_head));
		while (cap) {
			prefer =
				(struct prefer_info_db *)
				os_malloc(sizeof(struct prefer_info_db));
			if (!prefer) {
				err(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"alloc struct prefer_info_db fail\n");
				return -1;
			}
			memset(prefer, 0, (sizeof(struct prefer_info_db)));

			op_class = cap->op_class;
			debug(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"op_class = %d\n", op_class);
			prefer->perference = 0xf;
			prefer->reason = 0;
			prefer->op_class = op_class;
			get_op_class_channel_list(op_class, prefer);

			for (i = 0; i < prefer->ch_num; i++) {
#ifdef MAP_VENDOR_SUPPORT
				ch_planning_add_ch_to_preferred_list(ctx,
					dev,
					prefer->ch_list[i],
					radio,
					prefer->ch_list[i] > 14,
					prefer->perference,
					prefer->reason,
					prefer->op_class);
#else
				ch_planning_add_ch_to_preferred_list(ctx,
					prefer->ch_list[i],
					radio,
					prefer->ch_list[i] > 14,
					prefer->perference,
					prefer->reason,
					prefer->op_class);
#endif /* MAP_VENDOR_SUPPORT */
			}


			SLIST_INSERT_HEAD(&(chcap->prefer_info_head), prefer,
					prefer_info_entry);
			debug(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"opclass=%d, ch_num=%d perference=%d, reason=%d\n",
				prefer->op_class, prefer->ch_num,
				prefer->perference, prefer->reason);
			debug(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"ch_list:\n");
			for (j = 0; j < prefer->ch_num; j++)
				debug(DEBUG_CAT_TLVPRS, "%d\n", prefer->ch_list[j]);

			cap = SLIST_NEXT(cap, basic_cap_entry);
		}
	}
	dev->ch_preference_available = TRUE;
	return 0;
}

/**
* @brief Fn to parse assoc sta link metrics
*
* @param buf msg buffer
* @param ctx own 1905 device ctx
*
* @return -1 if error else tlv lenght
*/
int parse_associated_sta_link_metrics_query_tlv(unsigned char *buf,
		struct own_1905_device *ctx)
{
	unsigned char *temp_buf = NULL;
	unsigned char *check_buf = NULL;
	unsigned short length = 0;

	temp_buf = buf;
	check_buf = buf;

	if((*temp_buf) == STA_MAC_ADDRESS_TYPE) {
		temp_buf++;
	}
	else {
		err(DEBUG_CAT_TLVPRS, "should not go here\n");
		return -1;
	}
	//calculate tlv length
	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length |(*(temp_buf+1));

	if (!check_fixed_length_tlv(STA_MAC_ADDRESS_TYPE_LEN, check_buf, length)) {
		err(DEBUG_CAT_TLVPRS, "error STA_MAC_ADDRESS_TYPE length is %d incorrect\n", length);
		return -1;
	}
	//shift to tlv value field
	temp_buf += 2;

	memcpy(ctx->metric_entry.assoc_sta, temp_buf, ETH_ALEN);
	temp_buf += ETH_ALEN;
	return (length+3);
}

/**
* @brief Fn to parse assoc link metrics tlv
*
* @param ctx own 1905 device pointer
* @param buf msg buffer
*
* @return -1 if error else tlv lenght
*/
int parse_associated_sta_link_metrics_query_message(struct own_1905_device *ctx,
		unsigned char *buf, unsigned short len)
{
	int length = 0;
	unsigned char *temp_buf;
	unsigned char integrity = 0;
	unsigned short check_len = 0;
	unsigned short tlv_len = 0;

	temp_buf = buf;

	while (1) {
		check_len = get_tlv_len(temp_buf);
		tlv_len = check_len + 3;

		if (len < tlv_len) {
			err(DEBUG_CAT_TLVPRS, "Error TLV len, type = %d, len %d less than tlv_len %d\n",
				*temp_buf, len, tlv_len);
			return -1;
		}

		if (*temp_buf == STA_MAC_ADDRESS_TYPE) {
			integrity |= 0x1;
			length =
				parse_associated_sta_link_metrics_query_tlv
				(temp_buf, ctx);
			if (length < 0) {
				err(DEBUG_CAT_TLVPRS, "error associated sta link metrics query tlv\n");
				return -1;
			}
			temp_buf += length;
		} else if (*temp_buf == END_OF_TLV_TYPE) {
			break;
		} else {
			length = get_cmdu_tlv_length(temp_buf);
			temp_buf += length;
		}
		len -= tlv_len;
	}
	/*check integrity */
	if (integrity != 0x1) {
		err(DEBUG_CAT_TLVPRS, "no sta mac address tlv\n");
		return -1;
	}

	return 0;
}

/**
* @brief Fn to insert new channel restriction info
*
* @param dev 1905 map device
* @param buf msg buffer
* @param len msg lenght
*
* @return 0 if success else error
*/
int insert_new_radio_oper_restrict(struct _1905_map_device * dev, unsigned char *buf, unsigned short len)
{
	struct oper_restrict *restriction = NULL;
	struct restrict_db *restrict_var = NULL;
	unsigned char *pos = buf;
	unsigned short check_len = 0, prefer_len = 0;
	unsigned char i = 0, j = 0, op_class = 0, ch_num = 0;

	if (len < 7) {
		err(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"length error less than 7\n");
		return -1;
	}

	struct radio_info_db *radio = topo_srv_get_radio(dev, pos);
	if (!radio) {
		err(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"can't find radio by identifier("MACSTR")\n", MAC2STR(pos));
		return -1;
	}
	restriction = &radio->chan_restrict;
	pos += ETH_ALEN;
	check_len += ETH_ALEN;
	restriction->op_class_num = *pos++;
	check_len += 1;
	restriction->is_valid = 1;

	if (restriction->op_class_num > MAX_OP_CLASS_NUM) {
		err(DEBUG_CAT_TLVPRS, "op class is more than max %d\n", restriction->op_class_num);
		return -1;
	}

	for(i = 0; i < restriction->op_class_num; i++) {
		if (check_len + 2 > len) {
			err(DEBUG_CAT_TLVPRS, "error in length\n");
			return -1;
		}
		op_class = *pos++;
		check_len += 1;
		ch_num = *pos++;
		check_len += 1;
		restrict_var = (struct restrict_db *)os_malloc(sizeof(struct restrict_db));
		if (!restrict_var) {
			err(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"alloc struct restrict_db fail\n");
			return -1;
		}
		memset(restrict_var, 0 , prefer_len);
		restrict_var->op_class = op_class;
		restrict_var->ch_num = ch_num;
		if (len < (check_len + (2 * ch_num))) {
			err(DEBUG_CAT_TLVPRS, "error in length");
			free(restrict_var);
			return -1;
		}
		for (j = 0; j < restrict_var->ch_num; j++) {
			restrict_var->ch_list[j] = *pos++;
			restrict_var->min_fre_sep[j] = *pos++;
			check_len += 2;
		}
		SLIST_INSERT_HEAD(&restriction->restrict_head, restrict_var, restrict_entry);
		debug(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"insert struct restrict_db\n");
		debug(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"opclass=%d, ch_num=%d\n", restrict_var->op_class, restrict_var->ch_num);
		debug(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"ch_list:\n");
		for (j = 0; j < restrict_var->ch_num; j++) {
			debug(DEBUG_CAT_TLVPRS, "%d ", restrict_var->ch_list[j]);
		}
		debug(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"min_fre_sep_list:\n");
		for (j = 0; j < restrict_var->ch_num; j++) {
			debug(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"%d ", restrict_var->min_fre_sep[j]);
		}
	}

	if (len != check_len) {
		err(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"length mismatch len(%d) != check_len(%d)\n",
				len, check_len);
		delete_agent_ch_prefer_info(NULL, dev);
		return -1;
	}

	return 0;
}

/**
* @brief Fn to parse radio operating restriction tlv
*
* @param buf msg buffer
* @param dev 1905 map device pointer
*
* @return -1 if error else tlv lenght
*/
int parse_radio_operation_restriction_tlv(unsigned char *buf, struct _1905_map_device *dev)
{
	unsigned char *temp_buf;
	unsigned short length = 0;

	temp_buf = buf;

	if ((*temp_buf) == RADIO_OPERATION_RESTRICTION_TYPE) {
		temp_buf++;
	} else {
		err(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"should not go here\n");
		return -1;
	}

	//calculate tlv length
	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length | (*(temp_buf + 1));

	//shift to tlv value field
	temp_buf += 2;

	/*insert new channel preference info */
	if (0 >insert_new_radio_oper_restrict(dev, temp_buf,
				length)) {
		err(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"insert_new_radio_oper_restrict fail\n");
		return -1;
	}

	return (length + 3);
}

/**
* @brief Fn to add new ap metrics info
*
* @param ctx own 1905 device ctx
* @param dev 1905 map device pointer
* @param buf msg buffer
* @param len msg leng
*
* @return 0 if success else -1
*/
int insert_new_ap_metrics_info(
		struct own_1905_device * ctx, struct _1905_map_device *dev, unsigned char *buf, unsigned short len)
{
	unsigned char *pos = buf;
	unsigned short check_len = 0;
	struct esp_db *esp = NULL;
	struct bss_info_db *mrsp = topo_srv_get_bss_by_bssid(ctx, dev, buf);
	if (!mrsp) {
		err(DEBUG_CAT_TLVPRS, "should have never happened\n");
		return -1;
	}
	delete_exist_ap_metrics_info(ctx, buf);

	pos += ETH_ALEN;
	check_len += ETH_ALEN;
	mrsp->ch_util = *pos++;
	check_len += 1;
	mrsp->assoc_sta_cnt = (((*pos)<<8)|(*(pos+1)));
	pos += 2;
	check_len += 2;
	/*skip esp indicator*/
	pos += 1;
	check_len += 1;
	mrsp->esp_cnt = 0;
	SLIST_INIT(&mrsp->esp_head);

	debug(DEBUG_CAT_TLVPRS, "insert struct mrsp_db\n");
	debug(DEBUG_CAT_TLVPRS, "bssid("MACSTR") ch_util=%d assoc_sta_cnt=%d\n",
			MAC2STR(mrsp->bssid), mrsp->ch_util, mrsp->assoc_sta_cnt);
	while(check_len < len) {
		esp = (struct esp_db *)os_zalloc(sizeof(struct esp_db));
		if (!esp) {
			err(DEBUG_CAT_TLVPRS, "alloc struct esp_db fail\n");
			return -1;
		}
		memset(esp, 0 , sizeof(struct esp_db));
		esp->ac = (*(pos + 2)) & 0x03;
		esp->format = ((*(pos + 2)) & 0x18) >> 3;
		esp->ba_win_size = ((*(pos + 2)) & 0xe0) >> 5;
		esp->e_air_time_fraction = *(pos + 1);
		esp->ppdu_dur_target = *pos;
		SLIST_INSERT_HEAD(&mrsp->esp_head, esp, esp_entry);
		pos += 3;
		check_len += 3;
		mrsp->esp_cnt++;
		debug(DEBUG_CAT_TLVPRS, "insert struct esp_db\n");
		debug(DEBUG_CAT_TLVPRS, "ac=%d, format=%d ba_win_size=%d, e_air_time_fraction=%d,\n",
				esp->ac, esp->format, esp->ba_win_size, esp->e_air_time_fraction);
		debug(DEBUG_CAT_TLVPRS, "ppdu_dur_target=%d esp_cnt=%d\n", esp->ppdu_dur_target, mrsp->esp_cnt);
	}
	topo_srv_update_channel_info(ctx, mrsp);
#ifdef MAP_R2
	debug(DEBUG_CAT_TLVPRS, "other_dev");
	topo_srv_update_ch_planning_info(ctx,dev,mrsp,NULL,0);
#endif
#ifdef CENT_STR
	if(ctx->cent_str_en && ctx->device_role == DEVICE_ROLE_CONTROLLER)
		cent_str_cu_monitor(ctx,mrsp);
#endif
	return 0;

}

int insert_new_sta_metrics_info(
		struct own_1905_device * ctx, struct _1905_map_device *dev, unsigned char *buf, unsigned short len)
{
	unsigned char mac[ETH_ALEN] = {0};
	unsigned char bssid[ETH_ALEN] = {0};
	unsigned char *p = NULL;
	struct associated_clients *client = NULL, *tclient = NULL;
#ifdef CENT_STR
	struct client *cli = NULL;
#endif
	p = buf;
	os_memcpy(mac, p, ETH_ALEN);
	p += ETH_ALEN;
	p++; //for bss cnt
	os_memcpy(bssid, p, ETH_ALEN);
	p += ETH_ALEN;
	SLIST_FOREACH_SAFE(client, &dev->assoc_clients, next_client, tclient) {
		debug(DEBUG_CAT_TLVPRS, "metric bss mac: "MACSTR"\n", MAC2STR(bssid));
		debug(DEBUG_CAT_TLVPRS, "metric cli mac: "MACSTR"\n", MAC2STR(mac));
		debug(DEBUG_CAT_TLVPRS, "cli mac: "MACSTR"\n", MAC2STR(client->client_addr));
		debug(DEBUG_CAT_TLVPRS, "bssid mac: "MACSTR"\n", MAC2STR(client->bss->bssid));
		if(!memcmp(client->client_addr, mac, ETH_ALEN) && !memcmp(client->bss->bssid, bssid, ETH_ALEN)) {
			client->time_delta = (((*p)<<24)|((*(p+1))<<16)|((*(p+2))<<8)|(*(p+3)));
			p+=4;
			client->erate_downlink = (((*p)<<24)|((*(p+1))<<16)|((*(p+2))<<8)|(*(p+3)));
			p+=4;
			client->erate_uplink = (((*p)<<24)|((*(p+1))<<16)|((*(p+2))<<8)|(*(p+3)));
			p+=4;
			client->rssi_uplink = rcpi_to_rssi(*p);
			p++;
#ifdef CENT_STR
			uint32_t cid = client_db_get_cid_from_mac((struct mapd_global *)ctx->back_ptr, client->client_addr);
			cli = client_db_get_client_from_sta_mac(ctx->back_ptr, client->client_addr);
			struct bss_info_db *bss = topo_srv_get_bss_by_bssid(ctx, dev, bssid);
			struct cent_steer_fail_cands *fail_cand = NULL;
			if(cli && bss && bss->radio){
			fail_cand = get_client_from_cent_steer_fail_cand_list(ctx,cli);
			cli->dl_phy_rate = client->erate_downlink;
#ifdef MAP_R6
			if (cid != cli->client_id)
				err(DEBUG_CAT_TLVPRS, "cid and client_id is not same\n");
#endif /* MAP_R6 */
			client_db_set_ul_rssi((struct mapd_global *)ctx->back_ptr, cid, client->rssi_uplink, bss->radio->band, 0);
			if (((client->is_bh_link != 1) &&
#ifdef MTK_MLO_MAP_SUPPORT
				(client->is_apcli_link != 1) &&
#endif
				(link_metrics_mon_rcpi_at_controller(client, ctx) || (fail_cand != NULL)))
#ifdef MTK_MLO_MAP_SUPPORT
				|| (ctx->cli_steer_params.force_cli_nol_steer == 1)
#endif
			) {
				//free the cand when this trigger is received
				if(fail_cand != NULL)
					remove_entry_fail_candidate_list(cli,ctx);
				cent_str_select_on_demand_str_method(ctx,cli);
#ifdef MTK_MLO_MAP_SUPPORT
				ctx->cli_steer_params.force_cli_nol_steer = 0;
#endif
			}
			}
#endif
			debug(DEBUG_CAT_TLVPRS, "time delta: %d\n", client->time_delta);
			debug(DEBUG_CAT_TLVPRS, "erate downlink: %u\n", client->erate_downlink);
			debug(DEBUG_CAT_TLVPRS, "erate uplink: %u\n", client->erate_uplink);
			debug(DEBUG_CAT_TLVPRS, "rssi uplink: %d\n", (char)client->rssi_uplink);
			break;
		}
	}

	return 0;

}
/**
* @brief Fn to add new tx link metrics info
*
* @param dev 1905 map device pointer
* @param buf msg buffer
* @param len msg len
*
* @return 0 if success else -1
*/
int insert_new_tx_link_metrics_info(
		struct _1905_map_device *dev, unsigned char *buf, unsigned short len)
{
	unsigned char *pos = buf;
	struct map_neighbor_info *neighbor_info, *t_neighbor_info = NULL;
	struct backhaul_link_info *bh_info = NULL, *tbhinfo = NULL;
	unsigned char *neighbor_dev = buf + ETH_ALEN;
	struct list_neighbor *neighbor_list;
	unsigned char found = 0;
	int bh_cnt = 0, i = 0;
#ifdef MTK_MLO_MAP_SUPPORT
	int is_nonsetup_link = 0;
	unsigned int j = 0;
#endif

	neighbor_list = &dev->neighbors_entry;


	SLIST_FOREACH_SAFE(neighbor_info, neighbor_list, next_neighbor, t_neighbor_info)
	{

		if(!os_memcmp(neighbor_info->n_almac, neighbor_dev, ETH_ALEN)) {
			info(DEBUG_CAT_TLVPRS, "neighbor dev("MACSTR") found\n",
					MAC2STR(neighbor_dev));
			break;
		}
	}

	if (!neighbor_info) {
		/* Discard this info, will be filled in next infra metrics */
		err(DEBUG_CAT_TLVPRS, "topo server doesn't have ("MACSTR") with neighbor("MACSTR")\n",
					MAC2STR(dev->_1905_info.al_mac_addr) ,MAC2STR(neighbor_dev));
		return -1;
	} else {
		pos += 2 * ETH_ALEN;
	}
	if ((len - 12) % 29 != 0) {
		err(DEBUG_CAT_TLVPRS, "tlv length error\n");
		return -1;
	} else
		bh_cnt = (len - 12) / 29;

	debug(DEBUG_CAT_TLVPRS, "bh_cnt %d\n", bh_cnt);
	for (i = 0; i < bh_cnt; i++) {
		SLIST_FOREACH_SAFE(bh_info, &neighbor_info->bh_head, next_bh, tbhinfo) {
			if (os_memcmp(bh_info->connected_iface_addr, pos, ETH_ALEN) == 0&&
				os_memcmp(bh_info->neighbor_iface_addr, pos + ETH_ALEN, ETH_ALEN) == 0) {
				info(DEBUG_CAT_TLVPRS, "found connected_iface_addr="MACSTR" , neighbor_iface_addr "MACSTR"\n",
				MAC2STR(bh_info->connected_iface_addr), MAC2STR(bh_info->neighbor_iface_addr));
				found = 1;
				break;
			}
#ifdef MTK_MLO_MAP_SUPPORT
			else if (bh_info) {
				debug(DEBUG_CAT_TLVPRS, "bh_info present, fill non-setup link metric info\n");
				if (j >= MLO_NON_SETUP_LINK_MAX) {
					err(DEBUG_CAT_TLVPRS, "MLO Non Setup Link Overflow\n");
					j = 0;
				}
				bh_info->is_nonsetup_valid = 0;
				if (os_memcmp(bh_info->mlo_tx[j].connected_iface_addr,  bh_info->connected_iface_addr, ETH_ALEN) != 0) {
					os_memcpy(bh_info->mlo_tx[j].connected_iface_addr,
					pos, ETH_ALEN);

					pos += ETH_ALEN;
					/* memcpy(bh_info->neighbor_iface_addr, pos, ETH_ALEN); */
					pos += ETH_ALEN;
					bh_info->mlo_tx[j].iface_type = ((*pos) << 8) | (*(pos + 1));
					pos += 2;
					bh_info->mlo_tx[j].is_80211_bridge = *pos;
					pos += 1;
					bh_info->mlo_tx[j].pkt_err = ((*pos) << 24) | ((*(pos + 1)) << 16) |
						((*(pos + 2)) << 8) | (*(pos + 3));
					pos += 4;
					bh_info->mlo_tx[j].tx_packet = ((*pos) << 24) | ((*(pos + 1)) << 16) |
						((*(pos + 2)) << 8) | (*(pos + 3));
					pos += 4;
					bh_info->mlo_tx[j].mac_throughput = ((*pos) << 8) | (*(pos + 1));
					pos += 2;
					bh_info->mlo_tx[j].link_availability = ((*pos) << 8) | (*(pos + 1));
					pos += 2;
					bh_info->mlo_tx[j].phy_rate = ((*pos) << 8) | (*(pos + 1));
					pos += 2;
					is_nonsetup_link = 1;
					bh_info->is_nonsetup_valid = 1;
					debug(DEBUG_CAT_TLVPRS, "MLO TX INFO iface_type:%d, %d, %d, %d, %d,%d, %d\n",
					bh_info->mlo_tx[j].iface_type,  bh_info->mlo_tx[j].is_80211_bridge,
					bh_info->mlo_tx[j].pkt_err,  bh_info->mlo_tx[j].tx_packet,
					bh_info->mlo_tx[j].mac_throughput,  bh_info->mlo_tx[j].link_availability,
					bh_info->mlo_tx[j].phy_rate);
					j += 1;
					bh_info->mlo_link_no = j;
					break;
				}
			}
#endif
		}

		if (found == 0
#ifdef MTK_MLO_MAP_SUPPORT
			&& is_nonsetup_link == 0
#endif
		) {
			/* Discard this info, will be filled in next infra metrics */
			info(DEBUG_CAT_TLVPRS, "topo server doesn't have ("MACSTR") with neighbor("MACSTR")\n",
					MAC2STR(dev->_1905_info.al_mac_addr) ,MAC2STR(neighbor_dev));
			info(DEBUG_CAT_TLVPRS, "connected("MACSTR") n_iface("MACSTR")\n",
					MAC2STR(pos), MAC2STR((pos + ETH_ALEN)));
#ifdef MTK_MLO_MAP_SUPPORT
			if (bh_info)
				bh_info->is_nonsetup_valid = 0;
#endif
			return -1;
		}


		if (found == 1 && (bh_info)
#ifdef MTK_MLO_MAP_SUPPORT
		&& is_nonsetup_link == 0
#endif
		) {
#ifdef MTK_MLO_MAP_SUPPORT
			bh_info->is_nonsetup_valid = 0;
#endif
			memcpy(bh_info->connected_iface_addr, pos, ETH_ALEN);
			pos += ETH_ALEN;
			memcpy(bh_info->neighbor_iface_addr, pos, ETH_ALEN);
			pos += ETH_ALEN;
			bh_info->tx.iface_type = ((*pos) << 8) | (*(pos + 1));
			pos += 2;
			bh_info->tx.is_80211_bridge = *pos;
			pos += 1;
			bh_info->tx.pkt_err = ((*pos) << 24) | ((*(pos + 1)) << 16) |
				((*(pos + 2)) << 8) | (*(pos + 3));
			pos += 4;
			bh_info->tx.tx_packet = ((*pos) << 24) | ((*(pos + 1)) << 16) |
				((*(pos + 2)) << 8) | (*(pos + 3));
			pos += 4;
			bh_info->tx.mac_throughput = ((*pos) << 8) | (*(pos + 1));
			pos += 2;
			bh_info->tx.link_availability = ((*pos) << 8) | (*(pos + 1));
			pos += 2;
			bh_info->tx.phy_rate = ((*pos) << 8) | (*(pos + 1));
			pos += 2;
			os_get_time(&bh_info->last_update);

			info(DEBUG_CAT_TLVPRS, "insert struct tx_metric_db\n");
			info(DEBUG_CAT_TLVPRS, "mac("MACSTR") ne mac("MACSTR")\n",
				MAC2STR(bh_info->connected_iface_addr),
				MAC2STR(bh_info->neighbor_iface_addr));
			info(DEBUG_CAT_TLVPRS, "intf_type=%d, bridge_flag=%d error_packet=%d,\n",
				bh_info->tx.iface_type, bh_info->tx.is_80211_bridge, bh_info->tx.pkt_err);
			info(DEBUG_CAT_TLVPRS, "tx_packets=%d, mac_tpcap=%d linkavl=%d, phyrate=%d\n",
				bh_info->tx.tx_packet, bh_info->tx.mac_throughput, bh_info->tx.link_availability, bh_info->tx.phy_rate);
		}

	}

	if (found == 0) {
		err(DEBUG_CAT_TLVPRS, "topo server doesn't have ("MACSTR") with neighbor("MACSTR")\n",
				MAC2STR(dev->_1905_info.al_mac_addr), MAC2STR(neighbor_dev));
		return -1;
	}

	return 0;
}

/**
* @brief Fn to parse basic radio cap tlv
*
* @param buf msg buffer
* @param dev 1905 map device ptr
* @param bcap rdio basic cap
*
* @return -1 if error else tlv lenght
*/
int parse_basic_radio_cap_tlv(unsigned char *buf, struct _1905_map_device *dev, struct ap_radio_basic_cap **bcap_buf)
{
	unsigned char *temp_buf;
	unsigned short length = 0, left_tlv_len, buff_len;
	struct radio_basic_cap *opcap;
	int i;
	unsigned char cap = 0;
	unsigned char identifier[ETH_ALEN] = {0};
	unsigned char max_bss_num, op_class_num;
	struct ap_radio_basic_cap *bcap;

	temp_buf = buf;

	if((*temp_buf) == AP_RADIO_BASIC_CAPABILITY_TYPE) {
		temp_buf++;
	} else {
		err(DEBUG_CAT_TLVPRS, "should not go here\n");
		return -1;
	}

	//calculate tlv length
	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length |(*(temp_buf+1));

	left_tlv_len = length;

	//shift to tlv value field
	temp_buf += 2;

	if (left_tlv_len < ETH_ALEN+2) {
		err(DEBUG_CAT_TLVPRS, "error in length\n");
		return -1;
	}
	memcpy(identifier, temp_buf, ETH_ALEN);
	temp_buf += ETH_ALEN;
	max_bss_num = *temp_buf;
	temp_buf++;
	op_class_num = *temp_buf;
	temp_buf++;

	if (check_subfield_length(MAX_OP_CLASS_NUM, op_class_num) == FALSE) {
		err(DEBUG_CAT_TLVPRS, "error in max op class\n");
		return -1;
	}

	buff_len = sizeof(struct ap_radio_basic_cap) + op_class_num * sizeof(struct radio_basic_cap);
	*bcap_buf = (struct ap_radio_basic_cap *) os_zalloc(buff_len);

	if (*bcap_buf == NULL) {
		err(DEBUG_CAT_TLVPRS, "memory allocation failed - %d\n", buff_len);
		return -1;
	}
	bcap = *bcap_buf;

	memcpy(bcap->identifier, identifier, ETH_ALEN);
	bcap->max_bss_num = max_bss_num;
	bcap->op_class_num = op_class_num;

	left_tlv_len -= ETH_ALEN+2;

	for (i = 0; i < bcap->op_class_num; i++) {
		if (left_tlv_len < 2) {
			err(DEBUG_CAT_TLVPRS, "error in length\n");
			return -1;
		}
		opcap = &bcap->opcap[i];
		opcap->op_class = *temp_buf;
		temp_buf++;
		opcap->max_tx_pwr = *temp_buf;
		temp_buf++;
		left_tlv_len -= 2;
		opcap->non_operch_num = *temp_buf;
		if (left_tlv_len < opcap->non_operch_num) {
			err(DEBUG_CAT_TLVPRS, "error in length\n");
			return -1;
		}
		temp_buf++;
		left_tlv_len -= 1;
		memcpy(opcap->non_operch_list, temp_buf, opcap->non_operch_num);
		temp_buf += opcap->non_operch_num;
		left_tlv_len -= opcap->non_operch_num;
		cap = get_bandcap(opcap->op_class, opcap->non_operch_num, opcap->non_operch_list);
		bcap->band |= cap;
	}

	return (length+3);

}

/**
* @brief Fn to parse ap cap tlv
*
* @param buf msg buffer
* @param dev 1905 map device pointer
* @param cap ap capability
*
* @return -1 if error else tlv lenght
*/
int parse_ap_cap_tlv(unsigned char *buf, struct _1905_map_device *dev, struct ap_capability *cap)
{
	unsigned char *temp_buf = NULL;
	unsigned char *check_buf = NULL;
	unsigned short length = 0;
	unsigned char val;

	temp_buf = buf;
	check_buf = buf;

	if((*temp_buf) == AP_CAPABILITY_TYPE) {
		temp_buf++;
	} else {
		err(DEBUG_CAT_TLVPRS, "should not go here\n");
		return -1;
	}
	//calculate tlv length
	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length |(*(temp_buf+1));

	if (!check_fixed_length_tlv(AP_CAPABILITY_TYPE_LEN, check_buf, length)) {
		err(DEBUG_CAT_TLVPRS, "error AP_CAPABILITY_TYPE length is %d incorrect\n", length);
		return -1;
	}

	//shift to tlv value field
	temp_buf += 2;

	val = *temp_buf;

	cap->sta_report_on_cop = val & 0x20;
	cap->sta_report_not_cop = val & 0x40;
	cap->rssi_steer = val & 0x80;

	return (length+3);
}

/**
* @brief Fn to parse ap ht caps tlv
*
* @param buf msg buffer
* @param cap ap ht caps tlv
*
* @return -1 if error else tlv lenght
*/
int parse_ap_ht_cap_tlv(unsigned char *buf, struct ap_ht_capability *cap)
{
	unsigned char *temp_buf = NULL;
	unsigned char *check_buf = NULL;
	unsigned short length = 0;
	unsigned char val;

	temp_buf = buf;
	check_buf = buf;

	if((*temp_buf) == AP_HT_CAPABILITY_TYPE) {
		temp_buf++;
	} else {
		err(DEBUG_CAT_TLVPRS, "should not go here\n");
		return -1;
	}
	//calculate tlv length
	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length |(*(temp_buf+1));

	if (!check_fixed_length_tlv(AP_HT_CAPABILITY_TYPE_LEN, check_buf, length)) {
		err(DEBUG_CAT_TLVPRS, "error AP_HT_CAPABILITY_TYPE length is %d incorrect\n", length);
		return -1;
	}

	//shift to tlv value field
	temp_buf += 2;

	memcpy(cap->identifier, temp_buf, ETH_ALEN);
	temp_buf += ETH_ALEN;

	val = *temp_buf;

	cap->ht_40 = (val & 0x02) >> 1;
	cap->sgi_40 = (val & 0x04) >>2;
	cap->sgi_20 = (val & 0x08) >>3;
	cap->rx_stream = (val & 0x30)>>4;
	cap->tx_stream = (val & 0xC0)>>6;

	return (length+3);
}

/**
* @brief Fn to parse ap vht caps tlbv
*
* @param buf msg buffer
* @param cap ap vht caps
*
* @return -1 if error else tlv length
*/
int parse_ap_vht_cap_tlv(unsigned char *buf, struct ap_vht_capability *cap)
{
	unsigned char *temp_buf = NULL, val;
	unsigned char *check_buf = NULL;
	unsigned short length = 0, mcs;

	temp_buf = buf;
	check_buf = buf;

	if((*temp_buf) == AP_VHT_CAPABILITY_TYPE) {
		temp_buf++;
	} else {
		err(DEBUG_CAT_TLVPRS, "should not go here\n");
		return -1;
	}

	//calculate tlv length
	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length |(*(temp_buf+1));

	if (!check_fixed_length_tlv(AP_VHT_CAPABILITY_TYPE_LEN, check_buf, length)) {
		err(DEBUG_CAT_TLVPRS, "error AP_VHT_CAPABILITY_TYPE length is %d incorrect\n", length);
		return -1;
	}

	temp_buf += 2;

	memcpy(cap->identifier, temp_buf, ETH_ALEN);
	temp_buf += ETH_ALEN;

	mcs = (*temp_buf);
	mcs = (mcs << 8) & 0xFF00;
	mcs = mcs |(*(temp_buf+1));

	temp_buf += 2;
	cap->vht_tx_mcs = mcs;

	mcs = (*temp_buf);
	mcs = (mcs << 8) & 0xFF00;
	mcs = mcs |(*(temp_buf+1));

	temp_buf += 2;
	cap->vht_rx_mcs = mcs;

	val = *temp_buf;
	temp_buf += 1;
	cap->tx_stream = (val & 0xE0) >> 5;
	cap->rx_stream = (val & 0x1C) >> 2;
	cap->sgi_80 = val & 0x02 >> 1;
	cap->sgi_160 = val & 0x01;

	val = *temp_buf;
	cap->vht_8080 = 0x80 >> 7;
	cap->vht_160 = 0x40 >> 6;
	cap->su_beamformer = 0x20 >> 5;
	cap->mu_beamformer = 0x10 >> 4;
	//TODO band
	//cap->band =

	return (length+3);
}

/**
* @brief Fn to parse ap he caps tlv
*
* @param buf msg buffer
* @param bcap ap he caps
*
* @return -1 if error else tlv length
*/
int parse_ap_he_cap_tlv(unsigned char *buf, struct ap_he_capability *bcap)
{
	unsigned char *temp_buf;
	unsigned short length, val = 0;

	temp_buf = buf;

	if((*temp_buf) == AP_HE_CAPABILITY_TYPE) {
		temp_buf++;
	} else {
		err(DEBUG_CAT_TLVPRS, "should not go here\n");
		return -1;
	}

	//calculate tlv length
	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length |(*(temp_buf+1));

	//shift to tlv value field
	temp_buf += 2;

	if (!((length == AP_HE_CAPABILITY_TYPE_MSC_2) ||
		(length == AP_HE_CAPABILITY_TYPE_MSC_4) ||
		(length == AP_HE_CAPABILITY_TYPE_MSC_8) ||
		(length == AP_HE_CAPABILITY_TYPE_MSC_12))) {
		err(DEBUG_CAT_TLVPRS, "error AP_HE_CAPABILITY_TYPE length is %d incorrect\n", length);
		return -1;
	}

	memcpy(bcap->identifier, temp_buf, ETH_ALEN);
	temp_buf += ETH_ALEN;

	//MCS Length
	bcap->he_mcs_len = *temp_buf;
	temp_buf++;

	//Supported MCS
	memcpy(bcap->he_mcs, temp_buf, bcap->he_mcs_len);
	temp_buf += bcap->he_mcs_len;

	//Spatial streams and BW support
	val = *temp_buf;
	bcap->tx_stream = (val & 0xE0) >> 5;
	bcap->rx_stream = (val & 0x1C) >> 2;
	bcap->he_8080 = (val & 0x02) >> 1;
	bcap->he_160 = val & 0x01;
	temp_buf++;

	val = *temp_buf;
	bcap->su_bf_cap = (val & 0x80) >> 7;
	bcap->mu_bf_cap= (val & 0x40) >> 6;
	bcap->ul_mu_mimo_cap = (val & 0x20) >> 5;
	bcap->ul_mu_mimo_ofdma_cap = (val & 0x10) >> 4;
	bcap->dl_mu_mimo_ofdma_cap = (val & 0x08) >> 3;
	bcap->ul_ofdma_cap = (val & 0x04) >> 2;
	bcap->dl_ofdma_cap = (val & 0x02) >> 1;
	return (length+3);
}
#ifdef MAP_R2
int parse_ap_cac_cap_tlv(
	unsigned char *buf,
	struct _1905_map_device *dev,
	int left_tlv_len)
{
	struct cac_capability cac_cap;
	struct cac_cap_tlv cap;
	unsigned char *temp_buf = NULL;
	unsigned short length = 0;
	int i,j,k,l;
	struct radio_info_db *radio = NULL;

	temp_buf = buf;

	if((*temp_buf) == CAC_CAPABILITIES_TYPE) {
		temp_buf++;
	} else {
		err(DEBUG_CAT_TLVPRS, "should not go here\n");
		return -1;
	}

	//calculate tlv length
	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length |(*(temp_buf+1));

	if (length > left_tlv_len) {
		err(DEBUG_CAT_TLVPRS, "error in length\n");
		return -1;
	}

	//shift to tlv value field
	temp_buf += 2;

	if (left_tlv_len < 3)
		return -1;
	left_tlv_len -= 3;

	cac_cap.country_code[0] =  *temp_buf;
	temp_buf ++;
	cac_cap.country_code[1] = *temp_buf;
	temp_buf++;
	if (dev)
		os_memcpy(dev->country_code, cac_cap.country_code, 2);
	cac_cap.radio_num = *temp_buf;
	temp_buf++;

	if (check_subfield_length(MAX_NUM_OF_RADIO, cac_cap.radio_num) == FALSE) {
		err(DEBUG_CAT_TLVPRS, "err in max radio\n");
		return -1;
	}
	for (i = 0; i < cac_cap.radio_num; i++) {
		if (left_tlv_len < ETH_ALEN+1) {
			err(DEBUG_CAT_TLVPRS, "error in length\n");
			return -1;
		}
		os_memcpy(cap.identifier, temp_buf, ETH_ALEN);
		temp_buf += ETH_ALEN;
		cap.cac_type_num = *temp_buf;
		temp_buf++;
		radio = topo_srv_get_radio(dev, cap.identifier);
		if(!radio) {
			err(DEBUG_CAT_TLVPRS, "dev radio not found some error\n");
			return -1;
		}
		os_memcpy(radio->cac_cap.identifier, cap.identifier, ETH_ALEN);
		radio->cac_cap.cac_type_num = cap.cac_type_num;
		topo_srv_clear_cac_cap_db(radio);
		SLIST_INIT(&radio->cac_cap.cac_capab_head);
#ifdef MAP_R6
		radio->radio_capability.wifi7_mlo_cap = NULL;
#endif
		for(j = 0 ; j < radio->cac_cap.cac_type_num ; j++)
		{
			if (left_tlv_len < 5) {
				err(DEBUG_CAT_TLVPRS, "error in length\n");
				return -1;
			}
			left_tlv_len -= 5;
			struct cac_cap_db *cac = os_zalloc(sizeof(struct cac_cap_db));
			if(!cac) {
				err(DEBUG_CAT_TLVPRS, "mem alloc fail\n");
				return -1;
			}
			SLIST_INSERT_HEAD(&radio->cac_cap.cac_capab_head, cac, cac_cap_entry);
			SLIST_INIT(&cac->cac_opcap_head);
			cac->cac_mode = *temp_buf;
			debug(DEBUG_CAT_TLVPRS, "CAC Mode: %d\n", cac->cac_mode);
			temp_buf++;
			cac->cac_interval[0] = *temp_buf;
			temp_buf++;
			cac->cac_interval[1] = *temp_buf;
			temp_buf++;
			cac->cac_interval[2] = *temp_buf;
			temp_buf++;
			cac->op_class_num = *temp_buf;
			temp_buf++;
			if (check_subfield_length(MAX_OP_CLASS_NUM, cac->op_class_num) == FALSE) {
				err(DEBUG_CAT_TLVPRS, "err in max op class\n");
				os_free(cac);
				return -1;
			}
			for(k = 0 ; k < cac->op_class_num ; k++) {
				if (left_tlv_len < 2) {
					err(DEBUG_CAT_TLVPRS, "error in length\n");
					os_free(cac);
					return -1;
				}
				left_tlv_len -= 2;
				struct cac_opcap_db *opcap = os_zalloc(sizeof(struct cac_opcap_db));
				if(!opcap) {
					err(DEBUG_CAT_TLVPRS, "mem alloc fail\n");
					os_free(cac);
					return -1;
				}
				opcap->op_class = *temp_buf;
				temp_buf++;
				opcap->ch_num = *temp_buf;
				temp_buf++;
				if (left_tlv_len < opcap->ch_num) {
					err(DEBUG_CAT_TLVPRS, "error in length\n");
					os_free(cac);
					os_free(opcap);
					return -1;
				}
				left_tlv_len -= opcap->ch_num;
				SLIST_INSERT_HEAD(&cac->cac_opcap_head, opcap, cac_opcap_entry);
				for (l = 0; l < opcap->ch_num; l++) {
					opcap->ch_list[l] = *temp_buf;
					temp_buf++;
				}
			}
		}
	}
	return (length+3);
}

int parse_ap_scan_cap_tlv(
	unsigned char *buf,
	struct _1905_map_device *dev,
	struct channel_scan_capab *ch_scan_cap)
{
	unsigned char *temp_buf;
	unsigned short length = 0, tlv_len;
	struct channel_body *ch_body;
	int i,j,k;

	temp_buf = buf;

	if ((*temp_buf) != CHANNEL_SCAN_CAPABILITY_TYPE) {
		err(DEBUG_CAT_TLVPRS, "should not go here\n");
		return -1;
	}

	//calculate tlv length
	length = get_tlv_len(temp_buf);

	//shift to tlv value field
	temp_buf += 3;
	ch_scan_cap->radio_num = *temp_buf;
	if (check_subfield_length(MAX_NUM_OF_RADIO, ch_scan_cap->radio_num) == FALSE) {
		err(DEBUG_CAT_TLVPRS, "error in parse ap scan cap tlv\n");
		return -1;
	}
	temp_buf++;
	tlv_len = length - 1;
	for (i = 0; i < ch_scan_cap->radio_num; i++) {
		if (tlv_len < 12) {
			err(DEBUG_CAT_TLVPRS, "error in length\n");
			return -1;
		}
		tlv_len -= 12;

		os_memcpy(ch_scan_cap->radio_scan_params[i].radio_id, temp_buf, ETH_ALEN);
		temp_buf += ETH_ALEN;

		ch_scan_cap->radio_scan_params[i].boot_scan_only= (*temp_buf & 0x80) >> 7;//bit 7
		ch_scan_cap->radio_scan_params[i].scan_impact= (*temp_buf & 0x60) >> 5; //bit 5 and 6
		temp_buf++;

		ch_scan_cap->radio_scan_params[i].min_scan_interval = (*temp_buf << 24) |
			(*(temp_buf + 1) << 16) | (*(temp_buf + 2) << 8) | (*(temp_buf + 3));
		temp_buf += 4;

		ch_scan_cap->radio_scan_params[i].oper_class_num = *temp_buf;
		if (check_subfield_length(OP_CLASS_PER_RADIO, ch_scan_cap->radio_scan_params[i].oper_class_num) == FALSE) {
			notice(DEBUG_CAT_TLVPRS, "input oper_class_num:%d, max num = %d\n",
			 ch_scan_cap->radio_scan_params[i].oper_class_num, OP_CLASS_PER_RADIO);
			return -1;
		}
		temp_buf++;

		for (j = 0; j < ch_scan_cap->radio_scan_params[i].oper_class_num; j++) {
			if (tlv_len < 2) {
				err(DEBUG_CAT_TLVPRS, "error in length\n");
				return -1;
			}
			tlv_len -= 2;
			ch_body = &ch_scan_cap->radio_scan_params[i].ch_body[j];
			ch_body->oper_class = *temp_buf;
			temp_buf++;
			ch_body->ch_list_num = *temp_buf;
			temp_buf++;
			if (ch_body->ch_list_num > MAX_CH_NUM) {
				err(DEBUG_CAT_TLVPRS, "Channel number: %u, which should not greater than 13\n", ch_body->ch_list_num);
#ifdef MAP_NON6E_CONTROLLER
				tlv_len -= ch_body->ch_list_num;
				temp_buf += ch_body->ch_list_num;
#endif
				continue;
			}
			if (tlv_len < ch_body->ch_list_num) {
				err(DEBUG_CAT_TLVPRS, "error in length\n");
				return -1;
			}
			tlv_len -= ch_body->ch_list_num;
			for (k = 0; k < ch_body->ch_list_num; k++) {
				ch_body->ch_list[k] = *temp_buf;
				temp_buf++;
			}
		}
	}

	return (length+3);

}
#endif
#ifdef MAP_R2
#ifdef DFS_CAC_R2
int parse_cac_status_tlv(struct own_1905_device *ctx,
		unsigned char *buf, struct _1905_map_device *dev)
{
	unsigned char *temp_buf;
	unsigned short length = 0;
	unsigned short left_tlv_len = 0;
	struct radio_info_db *radio = NULL;
	u8 i = 0;
	u8 cac_status_avail_ch_num = 0;
	u8 cac_status_not_allowed_ch_num = 0;
	u8 cac_status_ongoing_ch_num = 0;
	u8 tmp_cac_ch = 0, cac_ch = 0, cac_op = 0;
	u8 tmp_cac_op_class = 0;
	u16 tmp_cac_time, cac_time = 0xffff;
	temp_buf = buf;

	if ((*temp_buf) == CAC_STATUS_REPORT_TYPE) {
		temp_buf++;
	} else {
		err(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"should not go here\n");
		return -1;
	}

	//calculate tlv length
	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length | (*(temp_buf + 1));
	left_tlv_len = length;

	//shift to tlv value field
	temp_buf += 2;
	debug_hexdump(DEBUG_CAT_TLVPRS, "FUNCTION\n", temp_buf, length);
	if (left_tlv_len < 1) {
		err(DEBUG_CAT_TLVPRS, "error in length\n");
		return -1;
	}
	info(DEBUG_CAT_TLVPRS,
	CH_PLANING_PREX"dev("MACSTR")\n", MAC2STR(dev->_1905_info.al_mac_addr));
	cac_status_avail_ch_num = *temp_buf;
	temp_buf ++;
	left_tlv_len -= 1;
	for (i = 0; i < cac_status_avail_ch_num; i++) {
		if (left_tlv_len < 4) {
			err(DEBUG_CAT_TLVPRS, "error in length\n");
			return -1;
		}
		tmp_cac_op_class = *temp_buf;
		temp_buf++;
		tmp_cac_ch = *temp_buf;
		temp_buf++;
		tmp_cac_time = *temp_buf;
		tmp_cac_time = (tmp_cac_time << 8) & 0xFF00;
		tmp_cac_time = tmp_cac_time | (*(temp_buf + 1));
		temp_buf += 2;
		left_tlv_len -= 4;
		if((tmp_cac_time != 0) && (tmp_cac_time < cac_time)) {
			cac_time = tmp_cac_time;
			cac_ch = tmp_cac_ch;
			cac_op = tmp_cac_op_class;
		}
	}

	if (left_tlv_len < 1) {
		err(DEBUG_CAT_TLVPRS, "length error\n");
		return -1;
	}

	cac_status_not_allowed_ch_num = *temp_buf;
	temp_buf++;
	left_tlv_len -= 1;

	for (i = 0; i < cac_status_not_allowed_ch_num; i++) {
		if (left_tlv_len < 4) {
			err(DEBUG_CAT_TLVPRS, "length error\n");
			return -1;
		}
		/*Not needed currently, TODO: for non_occupancy*/
		temp_buf += 4;
		left_tlv_len -= 4;
	}

	if (left_tlv_len < 1) {
		err(DEBUG_CAT_TLVPRS, "length error\n");
		return -1;
	}

	cac_status_ongoing_ch_num = *temp_buf;
	temp_buf++;
	left_tlv_len -= 1;

	for (i = 0; i < cac_status_ongoing_ch_num; i++) {
		if (left_tlv_len < 5) {
			err(DEBUG_CAT_TLVPRS, "length error\n");
			return -1;
		}
		/*Not needed currently, TODO: for cac ongoing*/
		temp_buf += 5;
		left_tlv_len -= 5;
	}

	if (cac_time && cac_ch && cac_op) {
		radio = topo_srv_get_radio_by_band(dev, cac_ch);
		/* If CAC_on_channel is TRUE it means we are waiting for CAC response to update cac_comp_status */
		if (radio && ctx->ch_planning_R2.CAC_on_channel == 0) {
			radio->cac_comp_status.op_class = cac_op;
			radio->cac_comp_status.channel = cac_ch;
			radio->cac_comp_status.cac_status = CAC_SUCCESSFUL;
			debug(DEBUG_CAT_TLVPRS, "cac_time(%u), cac_ch(%u), cac_op(%u), radio_op(%u)\n",
			 cac_time, cac_ch, cac_op, radio->operating_class);
		} else {
			debug(DEBUG_CAT_TLVPRS, "CAC on channel(%u) is set, dont update here\n", ctx->ch_planning_R2.CAC_on_channel);
		}
	}
	return (length + 3);
}
#endif
#endif
int validate_cac_completion_tlv(unsigned char *buf)
{
	unsigned char *temp_buf;
	unsigned char radio_num = 0;
	unsigned char op_class_num = 0;
	unsigned short length = 0;
	u8 i, j;
	unsigned char left_tlv_len = 0;

	temp_buf = buf;

	if ((*temp_buf) == CAC_COMPLETION_REPORT_TYPE) {
		temp_buf++;
	} else {
		err(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"error should not go here\n");
		return -1;
	}

	/*calculate tlv length*/
	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length | (*(temp_buf + 1));
	left_tlv_len = length;

	/*shift to tlv value field*/
	temp_buf += 2;
	if (left_tlv_len < 1) {
		err(DEBUG_CAT_TLVPRS, "error in length\n");
		return -1;
	}

	radio_num = *temp_buf;
	temp_buf++;
	left_tlv_len -= 1;

	for (i = 0; i < radio_num; i++) {
		if (left_tlv_len < (ETH_ALEN + 4)) {
			err(DEBUG_CAT_TLVPRS, "error in length\n");
			return -1;
		}
		temp_buf += ETH_ALEN;
		temp_buf++;
		temp_buf++;
		temp_buf++;
		op_class_num = *temp_buf;
		temp_buf++;
		left_tlv_len -= (ETH_ALEN + 4);
		for (j = 0; j < op_class_num; j++) {
			if (left_tlv_len < 2) {
				err(DEBUG_CAT_TLVPRS, "error in length\n");
				return -1;
			}
			temp_buf++;
			temp_buf++;
			left_tlv_len -= 2;
		}
	}
	return (length + 3);
}

int parse_cac_completion_tlv(struct own_1905_device *ctx,
	unsigned char *buf, struct _1905_map_device *dev)
{
	unsigned char *temp_buf;
	unsigned short length = 0;
	struct radio_info_db *radio = NULL;
	struct cac_completion_report cac_rep;
	u8 i, j;
	temp_buf = buf;
#if 0
	struct os_reltime rem_time = {0};
#endif

	if ((*temp_buf) == CAC_COMPLETION_REPORT_TYPE) {
		temp_buf++;
	} else {
		err(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"should not go here\n");
		return -1;
	}

	//calculate tlv length
	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length | (*(temp_buf + 1));

	//shift to tlv value field
	temp_buf += 2;
	debug_hexdump(DEBUG_CAT_TLVPRS, "FUNCTION parsing dump\n", temp_buf, length);
	notice(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"dev("MACSTR")\n", MAC2STR(dev->_1905_info.al_mac_addr));
	cac_rep.radio_num = *temp_buf;
	temp_buf ++;
	for(i=0; i < cac_rep.radio_num; i++) {
		radio = topo_srv_get_radio(dev, temp_buf);
		if(radio)
		{
			os_memcpy(radio->cac_comp_status.identifier, temp_buf, ETH_ALEN);
			temp_buf+=ETH_ALEN;
			radio->cac_comp_status.op_class = *temp_buf;
			temp_buf++;
			radio->cac_comp_status.channel = *temp_buf;
			temp_buf++;
			radio->cac_comp_status.cac_status = *temp_buf;
			temp_buf++;
			radio->cac_comp_status.op_class_num = *temp_buf;
			temp_buf++;
			err(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"radio(%d) cac_op(%d) cac_ch(%d) cac_status(%d)\n",
				radio->channel[0], radio->cac_comp_status.op_class,
				radio->cac_comp_status.channel, radio->cac_comp_status.cac_status);
			topo_srv_clear_cac_completion_status(radio);
			struct cac_completion_opcap_db *opcap;
			SLIST_INIT(&radio->cac_comp_status.cac_completion_opcap_head);
#ifdef MAP_R6
			radio->radio_capability.wifi7_mlo_cap = NULL;
#endif
			for (j = 0; j < radio->cac_comp_status.op_class_num; j++)
			{
				opcap = os_zalloc(sizeof(struct cac_completion_opcap_db));
				if(!opcap) {
					err(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"mem alloc fail for opcap\n");
					return -1;
				}
				SLIST_INSERT_HEAD(&radio->cac_comp_status.cac_completion_opcap_head,opcap,opcap_db_next);
				opcap->op_class = *temp_buf;
				temp_buf++;
				opcap->ch_num = *temp_buf;
				temp_buf++;
				notice(DEBUG_CAT_TLVPRS, CH_PLANING_PREX"radar detect on op(%d) ch(%d)\n",
				 opcap->op_class, opcap->ch_num);
			}
			if (radio->cac_comp_status.cac_status == CAC_SUCCESSFUL && ctx->network_optimization.network_optimization_enabled) {
				radio->cac_channel = 0;
				radio->cac_enable = 0;
			}
#ifdef MAP_R2
			ch_planning_handle_cac_response2(ctx, dev, radio);
#endif
		}
	}
	return (length + 3);
}
#ifdef MAP_R2
int parse_metric_collection_intv_tlv(unsigned char *buf, struct _1905_map_device *dev)
{
	unsigned char *temp_buf = NULL;
	unsigned char *check_buf = NULL;
	unsigned short length = 0;

	temp_buf = buf;
	check_buf = buf;

	if ((*temp_buf) == METRIC_COLLECTION_INTERVAL_TYPE) {
		temp_buf++;
	} else {
		err(DEBUG_CAT_TLVPRS, "should not go here\n");
		return -1;
	}
	//calculate tlv length
	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length | (*(temp_buf + 1));

	if (!check_fixed_length_tlv(METRIC_COLLECTION_INTERVAL_TYPE_LEN, check_buf, length)) {
		err(DEBUG_CAT_TLVPRS, "error METRIC_COLLECTION_INTERVAL_TYPE length is %d incorrect\n", length);
		return -1;
	}

	//shift to tlv value field
	temp_buf += 2;

	dev->metric_rep_interval = ((*temp_buf) << 24) | ((*(temp_buf + 1)) << 16) |
			((*(temp_buf + 2)) << 8) | (*(temp_buf + 3));
	temp_buf += 4;
	return (length + 3);
}

int parse_r2_cap_tlv(unsigned char *buf, struct _1905_map_device *dev)
{
	unsigned char *temp_buf = NULL;
	unsigned char *check_buf = NULL;
	unsigned short length = 0;

	temp_buf = buf;
	check_buf = buf;

	if ((*temp_buf) == R2_AP_CAPABILITY_TYPE) {
		temp_buf++;
	} else {
		err(DEBUG_CAT_TLVPRS, "should not go here\n");
		return -1;
	}

	//calculate tlv length
	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length | (*(temp_buf + 1));

	if (!check_fixed_length_tlv(R2_AP_CAPABILITY_TYPE_LEN, check_buf, length)) {
		err(DEBUG_CAT_TLVPRS, "error R2_AP_CAPABILITY_TYPE length is %d incorrect\n", length);
		return -1;
	}

	//shift to tlv value field
	temp_buf += 2;

	dev->max_prio_rules = *temp_buf++;
	temp_buf++;
	debug_hexdump(DEBUG_CAT_TLVPRS, "R2 AP cap\n", temp_buf, length);
	if (*temp_buf & 0x80)
		dev->byte_cnt_unit = 2;
	else if (*temp_buf & 0x40)
		dev->byte_cnt_unit = 1;
	else if ((*temp_buf & 0xc0) == 0)
		dev->byte_cnt_unit = 0;
	temp_buf++;
	dev->max_vid = *temp_buf;
	return (length + 3);
}

#endif
#ifdef MAP_EHT_SUPPORT

int parse_ap_eht_capability_tlv(struct _1905_map_device *ctx, unsigned char *temp_buf)
{
	struct radio_info_db *radio = NULL;
	int num_radio, i;

	num_radio = *temp_buf++;

	for (i = 0 ; i < num_radio ; i++) {
		radio = topo_srv_get_radio(ctx, temp_buf);
		temp_buf += ETH_ALEN;
		if (radio) {
			radio->radio_capability.eht_cap.tx_stream = *temp_buf++;
			radio->radio_capability.eht_cap.rx_stream = *temp_buf++;
			radio->radio_capability.eht_cap.eht_ch_width = *temp_buf++;
			radio->radio_capability.eht_cap.ccfs0 = *temp_buf++;
			radio->radio_capability.eht_cap.ccfs1 = *temp_buf++;
			radio->radio_capability.eht_cap.valid = 1;
		}
	}
	return 0;
}
#endif

#ifdef MAP_R3
unsigned short parse_1905_layer_secure_cap_tlv(struct _1905_map_device *dev, unsigned char *buf)
{
	unsigned char *temp_buf = NULL;
	unsigned char *check_buf = NULL;
	unsigned short length = 0;

	temp_buf = buf;
	check_buf = buf;

	if (*temp_buf == _1905_LAYER_SECURITY_CAPABILITY_TYPE) {
		temp_buf++;
	} else {
		err(DEBUG_CAT_TLVPRS, "should not go here\n");
		return -1;
	}

	/*calculate tlv length*/
	length = *temp_buf;
	length = (length << 8) & 0xFF00;
	length = length | (*(temp_buf + 1));

	if (!check_fixed_length_tlv(_1905_LAYER_SECURITY_CAPABILITY_TYPE_LEN, check_buf, length)) {
		err(DEBUG_CAT_TLVPRS, "error _1905_LAYER_SECURITY_CAPABILITY_TYPE length is %d incorrect\n", length);
		return -1;
	}

	temp_buf += 2;

	dev->onboarding_proto = *temp_buf++;
	dev->msg_int_alg = *temp_buf++;
	dev->msg_enc_alg = *temp_buf++;

	return length + 3;
}

int parse_ap_wf6_capability_tlv(struct _1905_map_device *ctx,
	unsigned char *buf)
{
	unsigned char *temp_buf;
	unsigned short length = 0, i = 0, left_tlv_len;
	struct radio_info_db *radio = NULL;

    temp_buf = buf;

    if((*temp_buf) == AP_WF6_CAPABILITIES_TLV) {
        temp_buf++;
    }
    else {
        return -1;
    }

	length = *(unsigned short *)temp_buf;
	length = be_to_host16(length);
	temp_buf += 2;
	left_tlv_len = length;

	/* debug_hexdump(DEBUG_CAT_TLVPRS, "WF6 cap", temp_buf, length); */

	if (left_tlv_len < (ETH_ALEN + 1)) {
		err(DEBUG_CAT_TLVPRS, "tlv length error\n");
		return -1;
	}
	radio = topo_srv_get_radio(ctx, temp_buf);
	temp_buf += ETH_ALEN;
	if (radio) {
		radio->radio_capability.wf6_cap.role_supp = *temp_buf++;
		left_tlv_len -= ETH_ALEN + 1;
		if (radio->radio_capability.wf6_cap.role_supp > 2) {
			err(DEBUG_CAT_TLVPRS, "wf6 role error %d\n", radio->radio_capability.wf6_cap.role_supp);
			return -1;
		}
		radio->radio_capability.wf6_cap.valid = 1;
		for (i = 0;i < radio->radio_capability.wf6_cap.role_supp;i++) {
			if (left_tlv_len < 1) {
				err(DEBUG_CAT_TLVPRS, "tlv length error\n");
				return -1;
			}
			left_tlv_len -= 1;
			radio->radio_capability.wf6_cap.wf6_role[i].agent_role = (*temp_buf & 0xC0) >> 6;
			radio->radio_capability.wf6_cap.wf6_role[i].he_160 = (*temp_buf & 0x20) ? 1:0;
			radio->radio_capability.wf6_cap.wf6_role[i].he_8080 = (*temp_buf & 0x10) ? 1:0;
			radio->radio_capability.wf6_cap.wf6_role[i].he_mcs_len = *temp_buf & 0x0F;
			temp_buf++;
			if (left_tlv_len < radio->radio_capability.wf6_cap.wf6_role[i].he_mcs_len+5) {
				err(DEBUG_CAT_TLVPRS, "tlv length error\n");
				return -1;
			}
			left_tlv_len -= radio->radio_capability.wf6_cap.wf6_role[i].he_mcs_len+5;
			os_memcpy(radio->radio_capability.wf6_cap.wf6_role[i].he_mcs, temp_buf, radio->radio_capability.wf6_cap.wf6_role[i].he_mcs_len);
			temp_buf += radio->radio_capability.wf6_cap.wf6_role[i].he_mcs_len;
			radio->radio_capability.wf6_cap.wf6_role[i].su_bf_cap = (*temp_buf & 0x80) ? 1:0;
			radio->radio_capability.wf6_cap.wf6_role[i].su_beamformee_status = (*temp_buf & 0x40) ? 1:0;
			radio->radio_capability.wf6_cap.wf6_role[i].mu_bf_cap = (*temp_buf & 0x20) ? 1:0;
			radio->radio_capability.wf6_cap.wf6_role[i].beamformee_sts_less80 = (*temp_buf & 0x10) ? 1:0;
			radio->radio_capability.wf6_cap.wf6_role[i].beamformee_sts_more80 = (*temp_buf & 0x08) ? 1:0;
			radio->radio_capability.wf6_cap.wf6_role[i].ul_mu_mimo_cap = (*temp_buf & 0x04) ? 1:0;
			radio->radio_capability.wf6_cap.wf6_role[i].ul_ofdma_cap = (*temp_buf & 0x02) ? 1:0;
			radio->radio_capability.wf6_cap.wf6_role[i].dl_ofdma_cap = *temp_buf & 0x01;
			temp_buf++;
			radio->radio_capability.wf6_cap.wf6_role[i].max_user_dl_tx_mu_mimo = (*temp_buf & 0xF0) >> 4;
			radio->radio_capability.wf6_cap.wf6_role[i].max_user_ul_rx_mu_mimo = *temp_buf & 0x0F;
			temp_buf++;
			radio->radio_capability.wf6_cap.wf6_role[i].max_user_dl_tx_ofdma = *temp_buf;
			temp_buf++;
			radio->radio_capability.wf6_cap.wf6_role[i].max_user_ul_rx_ofdma = *temp_buf;
			temp_buf++;
			radio->radio_capability.wf6_cap.wf6_role[i].rts_status = (*temp_buf & 0x80) ? 1:0;
			radio->radio_capability.wf6_cap.wf6_role[i].mu_rts_status = (*temp_buf & 0x40) ? 1:0;
			radio->radio_capability.wf6_cap.wf6_role[i].m_bssid_status = (*temp_buf & 0x20) ? 1:0;
			radio->radio_capability.wf6_cap.wf6_role[i].mu_edca_status = (*temp_buf & 0x10) ? 1:0;
			radio->radio_capability.wf6_cap.wf6_role[i].twt_requester_status = (*temp_buf & 0x08) ? 1:0;
			radio->radio_capability.wf6_cap.wf6_role[i].twt_responder_status = (*temp_buf & 0x04) ? 1:0;
#ifdef MAP_R4_SPT
			debug(DEBUG_CAT_TLVPRS, "WF6 capability sr mode %d %d\n", *temp_buf & 0x02, *temp_buf & 0x02 ? 1:0);
			radio->radio_capability.wf6_cap.sr_mode =
				(*temp_buf & 0x02) ? 1:0;
#endif
			temp_buf++;
		}
	}
    return (length+3);
}

#endif
#ifdef MAP_R6
int parse_wifi7_mlo_capability_tlv(struct _1905_map_device *ctx, struct dl_list *cap_list, u8 *buf)
{
	int left = 0, length = 0;
	u8 *temp_buf = buf;
	struct wifi7_mlo_cap_db *cap = NULL, *cap_tmp = NULL;
	unsigned char radio_num = 0, radio_idx = 0;
	unsigned char max_num_mld = 0;
	unsigned char ap_max_link = 0;
	unsigned char bsta_max_link = 0;
	unsigned char tid_to_link_map = 0;
	unsigned char num_record = 0;
	unsigned char idx = 0;

	if ((*temp_buf) == WIFI7_AGENT_CAPABILITY_TLV_TYPE)
		temp_buf++;
	else {
		err(DEBUG_CAT_TLVPRS, TOPO_PREX"error is TLV type %d\n", *temp_buf);
		return -1;
	}

	/*calculate tlv length*/
	left = (*temp_buf);
	left = (left << 8) & 0xFF00;
	left = left | (*(temp_buf + 1));
	length = left;

	temp_buf += 2;

	if (left < 12) {
		err(DEBUG_CAT_TLVPRS, TOPO_PREX"%d: error left %d less than %d\n",
				__LINE__, left, 12);
		return -1;
	}

	/* MaxNumMLDs */
	max_num_mld = *temp_buf;
	info(DEBUG_CAT_TLVPRS, TOPO_PREX"max_num_mld %d\n", max_num_mld);
	left -= 1;
	temp_buf += 1;

	/* AP Maximum Links     bits 7-4
	 * bSTA Maximum Links   bits 3-0
	 */
	ap_max_link = ((*temp_buf) & 0xf0) > 4;
	bsta_max_link = (*temp_buf) & 0x0f;
	left -= 1;
	temp_buf += 1;

	/* TID-To-Link Mapping  */
	tid_to_link_map = *temp_buf;
	left -= 1;
	temp_buf += 1;

	/* reserved 13 bytes */
	temp_buf += 13;
	left -= 13;

	/* numRadios */
	radio_num = *temp_buf;
	info(DEBUG_CAT_TLVPRS, TOPO_PREX"radio_num %d\n", radio_num);
	left -= 1;
	temp_buf += 1;

	for (radio_idx = 0; radio_idx < radio_num; radio_idx++) {

		cap = (struct wifi7_mlo_cap_db *)os_zalloc(sizeof(struct wifi7_mlo_cap_db));
		if (!cap) {
			err(DEBUG_CAT_TLVPRS, TOPO_PREX"error malloc for wifi7 capability\n");
			goto fail;
		}

		dl_list_add(cap_list, &cap->list);

		cap->max_num_mld = max_num_mld;
		cap->ap_max_link = ap_max_link;
		cap->bsta_max_link = bsta_max_link;
		cap->tid_to_link_map = tid_to_link_map;

		/* RUID */
		os_memcpy(cap->identifier, temp_buf, ETH_ALEN);
		left -= ETH_ALEN;
		temp_buf += ETH_ALEN;
		info(DEBUG_CAT_TLVPRS, TOPO_PREX"ruid "MACSTR"\n", MAC2STR(cap->identifier));

		/* reserved 24 bytes */
		temp_buf += 24;
		left -= 24;

		/* ap str, nstr, emlsr, emlmr support */
		if (*temp_buf & 0x80)
			cap->ap_str_support = 1;
		if (*temp_buf & 0x40)
			cap->ap_nstr_support = 1;
		if (*temp_buf & 0x20)
			cap->ap_emlsr_support = 1;
		if (*temp_buf & 0x10)
			cap->ap_emlmr_support = 1;
		left -= 1;
		temp_buf += 1;

		/* sta str, nstr, emlsr, emlmr support */
		if (*temp_buf & 0x80)
			cap->sta_str_support = 1;
		if (*temp_buf & 0x40)
			cap->sta_nstr_support = 1;
		if (*temp_buf & 0x20)
			cap->sta_emlsr_support = 1;
		if (*temp_buf & 0x10)
			cap->sta_emlmr_support = 1;
		left -= 1;
		temp_buf += 1;

		/* Num_AP_STR_Records */
		num_record = *temp_buf;
		info(DEBUG_CAT_TLVPRS, TOPO_PREX"Num_AP_STR_Records %d\n", num_record);
		left -= 1;
		temp_buf += 1;
		for (idx = 0; idx < num_record; idx++) {
			/* AP_STR_RUID */
			left -= ETH_ALEN;
			temp_buf += ETH_ALEN;
			/* AP_STR_Freq_Separation */
			left -= 1;
			temp_buf += 1;
		}

		/* Num_AP_NSTR_Records */
		num_record = *temp_buf;
		info(DEBUG_CAT_TLVPRS, TOPO_PREX"Num_AP_NSTR_Records %d\n", num_record);
		left -= 1;
		temp_buf += 1;
		for (idx = 0; idx < num_record; idx++) {
			/* AP_NSTR_RUID */
			left -= ETH_ALEN;
			temp_buf += ETH_ALEN;
			/* AP_NSTR_Freq_Separation */
			left -= 1;
			temp_buf += 1;
		}

		/* Num_AP_EMLSR_Records */
		num_record = *temp_buf;
		info(DEBUG_CAT_TLVPRS, TOPO_PREX"Num_AP_EMLSR_Records %d\n", num_record);
		left -= 1;
		temp_buf += 1;
		for (idx = 0; idx < num_record; idx++) {
			/* AP_EMLSR_RUID */
			left -= ETH_ALEN;
			temp_buf += ETH_ALEN;
			/* AP_EMLSR_Freq_Separation */
			left -= 1;
			temp_buf += 1;
		}

		/* Num_AP_EMLMR_Records */
		num_record = *temp_buf;
		info(DEBUG_CAT_TLVPRS, TOPO_PREX"Num_AP_EMLMR_Records %d\n", num_record);
		left -= 1;
		temp_buf += 1;
		for (idx = 0; idx < num_record; idx++) {
			/* AP_EMLMR_RUID */
			left -= ETH_ALEN;
			temp_buf += ETH_ALEN;
			/* AP_EMLMR_Freq_Separation */
			left -= 1;
			temp_buf += 1;
		}

		/* Num_STA_STR_Records */
		num_record = *temp_buf;
		info(DEBUG_CAT_TLVPRS, TOPO_PREX"Num_STA_STR_Records %d\n", num_record);
		left -= 1;
		temp_buf += 1;
		for (idx = 0; idx < num_record; idx++) {
			/* STA_STR_RUID */
			left -= ETH_ALEN;
			temp_buf += ETH_ALEN;
			/* STA_STR_Freq_Separation */
			left -= 1;
			temp_buf += 1;
		}
		/* Num_STA_NSTR_Records */
		num_record = *temp_buf;
		info(DEBUG_CAT_TLVPRS, TOPO_PREX"Num_STA_NSTR_Records %d\n", num_record);
		left -= 1;
		temp_buf += 1;
		for (idx = 0; idx < num_record; idx++) {
			/* STA_NSTR_RUID */
			left -= ETH_ALEN;
			temp_buf += ETH_ALEN;
			/* STA_NSTR_Freq_Separation */
			left -= 1;
			temp_buf += 1;
		}

		/* Num_STA_EMLSR_Records */
		num_record = *temp_buf;
		info(DEBUG_CAT_TLVPRS, TOPO_PREX"Num_STA_EMLSR_Records %d\n", num_record);
		left -= 1;
		temp_buf += 1;
		for (idx = 0; idx < num_record; idx++) {
			/* STA_EMLSR_RUID */
			left -= ETH_ALEN;
			temp_buf += ETH_ALEN;
			/* STA_EMLSR_Freq_Separation */
			left -= 1;
			temp_buf += 1;
		}

		/* Num_STA_EMLMR_Records */
		num_record = *temp_buf;
		info(DEBUG_CAT_TLVPRS, TOPO_PREX"Num_STA_EMLMR_Records %d\n", num_record);
		left -= 1;
		temp_buf += 1;
		for (idx = 0; idx < num_record; idx++) {
			/* STA_EMLMR_RUID */
			left -= ETH_ALEN;
			temp_buf += ETH_ALEN;
			/* STA_EMLMR_Freq_Separation */
			left -= 1;
			temp_buf += 1;
		}
	}

	return (length + 3);
fail:
	dl_list_for_each_safe(cap, cap_tmp, cap_list,
			struct wifi7_mlo_cap_db, list) {
		os_free(cap);
	}
	return -1;

}
#ifdef NOT_USED
int parse_wifi7_mlo_capability_tlv(
struct _1905_map_device *ctx,
unsigned char *buf)
{
	//To Do : to be updated
	unsigned char *temp_buf = NULL;
	unsigned char *temp_buf_2 = NULL;
	unsigned char *temp_buf_3 = NULL;
	u8 i = 0, k = 0, temp_records = 0, length = 0, left_tlv_len;
	struct radio_info_db *radio = NULL;
	struct wifi7_mlo_caps *mlo_capab = NULL;
	/*TODO:*/
	/*struct mlo_caps *mlo_capability = NULL;*/
	char *buffer;
	size_t len = 0;
	struct mlo_record *record_ptr;

	temp_buf = buf;

	if ((*temp_buf) == WIFI7_AGENT_CAPABILITY_TLV_TYPE) {
		temp_buf++;
	} else {
		err(DEBUG_CAT_TLVPRS, TOPO_PREX"should not go here\n");
		return -1;
	}

	/*calculate tlv length*/
	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length | (*(temp_buf + 1));

	/*shift to tlv value field*/
	temp_buf += 2;
	left_tlv_len = length;
	debug_hexdump(DEBUG_CAT_TLVPRS, "wifi 7 agent capability tlv\n", temp_buf, length);

	if (left_tlv_len < 1) {
		err(DEBUG_CAT_TLVPRS, "error in length\n");
		return -1;
	}

	temp_buf_2 = temp_buf;
	temp_buf_2 = temp_buf_2 + 4;
	radio = topo_srv_get_radio(ctx, temp_buf_2);
	info(DEBUG_CAT_TLVPRS, "identifier("MACSTR")\n", PRINT_MAC(temp_buf_2));
	temp_buf_2 += ETH_ALEN;
	if (radio) {
		mlo_capab = radio->radio_capability.wifi7_mlo_cap;
		mlo_capab->mlo_capab.max_num_mld = *temp_buf++;
		mlo_capab->mlo_capab.ap_max_link = (*temp_buf & (BIT(4) | BIT(5) | BIT(6) | BIT(7))) >> 4;
		mlo_capab->mlo_capab.bsta_max_link = (*temp_buf & (BIT(0) | BIT(1) | BIT(2) | BIT(3)));
		temp_buf++;
		mlo_capab->mlo_capab.tid_to_link_map = (*temp_buf & (BIT(2) | BIT(3))) >> 2;
		temp_buf += (1 + ETH_ALEN);
		info(DEBUG_CAT_TLVPRS, "mlo_capab->mlo_capab->max_num_mld %d\n", mlo_capab->mlo_capab.max_num_mld);
		info(DEBUG_CAT_TLVPRS, "mlo_capab->mlo_capab->ap_max_link %d\n", mlo_capab->mlo_capab.ap_max_link);
		info(DEBUG_CAT_TLVPRS, "mlo_capab->mlo_capab->bsta_max_link %d\n", mlo_capab->mlo_capab.bsta_max_link);
		info(DEBUG_CAT_TLVPRS, "mlo_capab->mlo_capab->tid_to_link_map %d\n", mlo_capab->mlo_capab.tid_to_link_map);
		mlo_capab->mlo_capab.legacy = (*temp_buf & (BIT(7))) >> 7;
		temp_buf++;
		mlo_capab->mlo_capab.ap_str_support = (*temp_buf & (BIT(7))) >> 7;
		mlo_capab->mlo_capab.ap_nstr_support = (*temp_buf & (BIT(6))) >> 6;
		mlo_capab->mlo_capab.ap_emlsr_support = (*temp_buf & (BIT(5))) >> 5;
		mlo_capab->mlo_capab.ap_emlmr_support = (*temp_buf & (BIT(4))) >> 4;
		temp_buf++;
		mlo_capab->mlo_capab.sta_str_support = (*temp_buf & (BIT(7))) >> 7;
		mlo_capab->mlo_capab.sta_nstr_support = (*temp_buf & (BIT(6))) >> 6;
		mlo_capab->mlo_capab.sta_emlsr_support = (*temp_buf & (BIT(5))) >> 5;
		mlo_capab->mlo_capab.sta_emlmr_support = (*temp_buf & (BIT(4))) >> 4;
		temp_buf++;
		info(DEBUG_CAT_TLVPRS, "mlo_capab->mlo_capab->legacy %d\n",
			mlo_capab->mlo_capab.legacy);
		info(DEBUG_CAT_TLVPRS, "mlo_capab->mlo_capab->ap_str_support %d\n",
			mlo_capab->mlo_capab.ap_str_support);
		info(DEBUG_CAT_TLVPRS, "mlo_capab->mlo_capab->ap_nstr_support %d\n",
			mlo_capab->mlo_capab.ap_nstr_support);
		info(DEBUG_CAT_TLVPRS, "mlo_capab->mlo_capab->ap_emlsr_support %d\n",
			mlo_capab->mlo_capab.ap_emlsr_support);
		info(DEBUG_CAT_TLVPRS, "mlo_capab->mlo_capab->ap_emlmr_support %d\n",
			mlo_capab->mlo_capab.ap_emlmr_support);
		info(DEBUG_CAT_TLVPRS, "mlo_capab->mlo_capab->sta_str_support %d\n",
			mlo_capab->mlo_capab.sta_str_support);
		info(DEBUG_CAT_TLVPRS, "mlo_capab->mlo_capab->sta_nstr_support %d\n",
			mlo_capab->mlo_capab.sta_nstr_support);
		info(DEBUG_CAT_TLVPRS, "mlo_capab->mlo_capab->sta_emlsr_support %d\n",
			mlo_capab->mlo_capab.sta_emlsr_support);
		info(DEBUG_CAT_TLVPRS, "mlo_capab->mlo_capab->sta_emlmr_support %d\n",
			mlo_capab->mlo_capab.sta_emlmr_support);
		/*calculate total_ap_sta_records to allocate memory*/
		mlo_capab->mlo_capab.total_ap_sta_records = *temp_buf;
		temp_records = *temp_buf;
		temp_buf_3 = temp_buf + 1;
		for (i = 0 ; i < 7 ; i++) {
			temp_buf_3 = temp_buf_3 + (7*temp_records);
			temp_records = *temp_buf_3;
			mlo_capab->mlo_capab.total_ap_sta_records = (mlo_capab->mlo_capab.total_ap_sta_records
			+ temp_records);
			temp_buf_3++;
		}
		/*allocate memory to buf*/
		len = (mlo_capab->mlo_capab.total_ap_sta_records * sizeof(struct mlo_ap_sta_record));
		buffer = os_zalloc(len);

		if (!buffer) {
			err(DEBUG_CAT_TLVPRS, "Not available memory\n");
			return -1;
		}

		record_ptr = (struct mlo_record *)buffer;

		mlo_capab->mlo_capab.num_ap_str_records = *temp_buf;
		temp_buf++;
		for (i = 0 ; i < mlo_capab->mlo_capab.num_ap_str_records; i++) {
			os_memset(record_ptr[k].identifier, 0, ETH_ALEN);
			temp_buf += ETH_ALEN;
			info(DEBUG_CAT_TLVPRS, "identifier for AP/STA records ("MACSTR")\n", PRINT_MAC(temp_buf));
			record_ptr[k].freq_separation = (*temp_buf & (BIT(3) | BIT(4) | BIT(5) | BIT(6) | BIT(7))) >> 3;
			temp_buf++;
			info(DEBUG_CAT_TLVPRS, "mlo_capab->mlo_capab->record[k]->freq_separation %d\n",
				record_ptr[k].freq_separation);
			k++;
		}
		mlo_capab->mlo_capab.num_ap_nstr_records = *temp_buf;
		temp_buf++;
		for (i = 0 ; i < mlo_capab->mlo_capab.num_ap_nstr_records; i++) {
			os_memset(record_ptr[k].identifier, 0, ETH_ALEN);
			/*record_ptr[k].identifier = topo_srv_get_radio(ctx, temp_buf);*/
			temp_buf += ETH_ALEN;
			info(DEBUG_CAT_TLVPRS, "identifier for AP/STA records ("MACSTR")\n", PRINT_MAC(temp_buf));
			record_ptr[k].freq_separation = (*temp_buf & (BIT(3) | BIT(4) | BIT(5) | BIT(6) | BIT(7))) >> 3;
			temp_buf++;
			info(DEBUG_CAT_TLVPRS, "mlo_capab->mlo_capab->record[k]->freq_separation %d\n",
				record_ptr[k].freq_separation);
			k++;
		}

		mlo_capab->mlo_capab.num_ap_emlsr_records = *temp_buf;
		temp_buf++;
		for (i = 0 ; k < mlo_capab->mlo_capab.num_ap_emlsr_records; i++) {
			os_memset(record_ptr[k].identifier, 0, ETH_ALEN);
			temp_buf += ETH_ALEN;
			info(DEBUG_CAT_TLVPRS, "identifier for AP/STA records ("MACSTR")\n", PRINT_MAC(temp_buf));
			record_ptr[k].freq_separation = (*temp_buf & (BIT(3) | BIT(4) | BIT(5) | BIT(6) | BIT(7))) >> 3;
			temp_buf++;
			info(DEBUG_CAT_TLVPRS, "mlo_capab->mlo_capab->record[k]->freq_separation %d\n",
				record_ptr[k].freq_separation);
			k++;
			}

		mlo_capab->mlo_capab.num_ap_emlmr_records = *temp_buf;
		temp_buf++;
		for (i = 0 ; i < mlo_capab->mlo_capab.num_ap_emlmr_records; i++) {
			os_memset(record_ptr[k].identifier, 0, ETH_ALEN);
			temp_buf += ETH_ALEN;
			info(DEBUG_CAT_TLVPRS, "identifier for AP/STA records ("MACSTR")\n", PRINT_MAC(temp_buf));
			record_ptr[k].freq_separation = (*temp_buf & (BIT(3) | BIT(4) | BIT(5) | BIT(6) | BIT(7))) >> 3;
			temp_buf++;
			info(DEBUG_CAT_TLVPRS, "mlo_capab->mlo_capab->record[k]->freq_separation %d\n",
				record_ptr[k].freq_separation);
			k++;
		}

		mlo_capab->mlo_capab.num_ap_str_records = *temp_buf;
		temp_buf++;
		for (i = 0 ; i < mlo_capab->mlo_capab.num_ap_str_records; i++) {
			os_memset(record_ptr[k].identifier, 0, ETH_ALEN);
			temp_buf += ETH_ALEN;
			info(DEBUG_CAT_TLVPRS, "identifier for AP/STA records ("MACSTR")\n", PRINT_MAC(temp_buf));
			record_ptr[k].freq_separation = (*temp_buf & (BIT(3) | BIT(4) | BIT(5) | BIT(6) | BIT(7))) >> 3;
			temp_buf++;
			info(DEBUG_CAT_TLVPRS, "mlo_capab->mlo_capab->record[k]->freq_separation %d\n",
				record_ptr[k].freq_separation);
			k++;
		}

		mlo_capab->mlo_capab.num_ap_str_records = *temp_buf;
		temp_buf++;
		for (i = 0 ; i < mlo_capab->mlo_capab.num_ap_str_records; i++) {
			os_memset(record_ptr[k].identifier, 0, ETH_ALEN);
			temp_buf += ETH_ALEN;
			info(DEBUG_CAT_TLVPRS, "identifier for AP/STA records ("MACSTR")\n", PRINT_MAC(temp_buf));
			record_ptr[k].freq_separation = (*temp_buf & (BIT(3) | BIT(4) | BIT(5) | BIT(6) | BIT(7))) >> 3;
			temp_buf++;
			info(DEBUG_CAT_TLVPRS, "mlo_capab->mlo_capab->record[k]->freq_separation %d\n",
				record_ptr[k].freq_separation);
			k++;
		}

		mlo_capab->mlo_capab.num_ap_str_records = *temp_buf;
		temp_buf++;
		for (i = 0 ; i < mlo_capab->mlo_capab.num_ap_str_records; i++) {
			os_memset(record_ptr[k].identifier, 0, ETH_ALEN);
			temp_buf += ETH_ALEN;
			info(DEBUG_CAT_TLVPRS, "identifier for AP/STA records ("MACSTR")\n", PRINT_MAC(temp_buf));
			record_ptr[k].freq_separation = (*temp_buf & (BIT(3) | BIT(4) | BIT(5) | BIT(6) | BIT(7))) >> 3;
			temp_buf++;
			info(DEBUG_CAT_TLVPRS, "mlo_capab->mlo_capab->record[k]->freq_separation %d\n",
				record_ptr[k].freq_separation);
			k++;
		}

		mlo_capab->mlo_capab.num_ap_str_records = *temp_buf;
		temp_buf++;
		for (i = 0 ; i < mlo_capab->mlo_capab.num_ap_str_records; i++) {
			os_memset(record_ptr[k].identifier, 0, ETH_ALEN);
			temp_buf += ETH_ALEN;
			info(DEBUG_CAT_TLVPRS, "identifier for AP/STA records ("MACSTR")\n", PRINT_MAC(temp_buf));
			record_ptr[k].freq_separation = (*temp_buf & (BIT(3) | BIT(4) | BIT(5) | BIT(6) | BIT(7))) >> 3;
			temp_buf++;
			info(DEBUG_CAT_TLVPRS, "mlo_capab->mlo_capab->record[k]->freq_separation %d\n",
				record_ptr[k].freq_separation);
			k++;
		}
	}
#ifdef MTK_MLO_MAP_SUPPORT
	/*TODO:*/
	/*mlo_capability->MloCapPerRole[0].mlo_enable = 1;*/
	/*mlo_capability->MloCapPerRole[1].mlo_enable = 1;*/
#endif
	record_ptr = NULL;
	os_free(buffer);
	return length + 3;
	return 0;
}
#endif
#endif

#ifdef MTK_MLO_MAP_SUPPORT
void parse_mlo_capability_tlv(
struct _1905_map_device *ctx,
unsigned char *buf)
{
	unsigned char *temp_buf = NULL;
	u16 *temp = NULL;
	u8 i = 0;
	struct radio_info_db *radio = NULL;
	struct mlo_caps *mlo_capab = NULL;
	u16 mld_capab = 0, eml_capab = 0;

	temp_buf = buf;
	radio = topo_srv_get_radio(ctx, temp_buf);
	info(DEBUG_CAT_TLVPRS, "identifier("MACSTR")\n", PRINT_MAC(temp_buf));
	temp_buf += ETH_ALEN;
	if (radio) {
		mlo_capab = &radio->radio_capability.mlo_cap;
		mlo_capab->RoleNum = *temp_buf++;
		info(DEBUG_CAT_TLVPRS, "mlo_capab->RoleNum %d\n", mlo_capab->RoleNum);
		for (i = 0; i < mlo_capab->RoleNum; i++) {
			mlo_capab->MloCapPerRole[i].dev_role = (*temp_buf & (BIT(6) | BIT(7))) >> 6;
			mlo_capab->MloCapPerRole[i].static_punc_supp = (*temp_buf & BIT(5)) >> 5;
			mlo_capab->MloCapPerRole[i].mlo_enable = (*temp_buf & BIT(4)) >> 4;
			info(DEBUG_CAT_TLVPRS, "mlo_capab->MloCapPerRole[i].DeviceRole %d\n", mlo_capab->MloCapPerRole[i].dev_role);
			info(DEBUG_CAT_TLVPRS, "mlo_capab->MloCapPerRole[i].StatPunctureSupport %d\n",
			 mlo_capab->MloCapPerRole[i].static_punc_supp);
			info(DEBUG_CAT_TLVPRS, "mlo_capab->MloCapPerRole[i].MloEnable %d\n", mlo_capab->MloCapPerRole[i].mlo_enable);
			temp_buf++;
			mld_capab = *(u16 *)temp_buf;
			mld_capab = be_to_host16(mld_capab);
			temp = &mld_capab;
			mlo_capab->MloCapPerRole[i].eml_cap.emlsr_supp = (*temp & BIT(0));
			mlo_capab->MloCapPerRole[i].eml_cap.emlsr_padding = (*temp & (BIT(1) | BIT(2) | BIT(3))) >> 1;
			mlo_capab->MloCapPerRole[i].eml_cap.emlsr_trans_delay = (*temp & (BIT(4) | BIT(5) | BIT(6))) >> 4;
			mlo_capab->MloCapPerRole[i].eml_cap.emlmr_supp = (*temp & BIT(7)) >> 7;
			mlo_capab->MloCapPerRole[i].eml_cap.emlmr_delay = (*temp & (BIT(8) | BIT(9) | BIT(10))) >> 8;
			mlo_capab->MloCapPerRole[i].eml_cap.trans_to = (*temp & (BIT(11) | BIT(12) | BIT(13) | BIT(14))) >> 11;
			info(DEBUG_CAT_TLVPRS, "mlo_capab->MloCapPerRole[i].EmlCap.emlsr_supp %d\n",
				mlo_capab->MloCapPerRole[i].eml_cap.emlsr_supp);
			info(DEBUG_CAT_TLVPRS, "mlo_capab->MloCapPerRole[i].EmlCap.emlsr_padding %d\n",
				mlo_capab->MloCapPerRole[i].eml_cap.emlsr_padding);
			info(DEBUG_CAT_TLVPRS, "mlo_capab->MloCapPerRole[i].EmlCap.emlsr_trans_delay %d\n",
				mlo_capab->MloCapPerRole[i].eml_cap.emlsr_trans_delay);
			info(DEBUG_CAT_TLVPRS, "mlo_capab->MloCapPerRole[i].EmlCap.emlmr_supp %d\n",
				mlo_capab->MloCapPerRole[i].eml_cap.emlmr_supp);
			info(DEBUG_CAT_TLVPRS, "mlo_capab->MloCapPerRole[i].EmlCap.emlmr_delay %d\n",
				mlo_capab->MloCapPerRole[i].eml_cap.emlmr_delay);
			info(DEBUG_CAT_TLVPRS, "mlo_capab->MloCapPerRole[i].EmlCap.trans_to %d\n",
				mlo_capab->MloCapPerRole[i].eml_cap.trans_to);
			temp_buf = temp_buf + 2;
			eml_capab = *(u16 *)temp_buf;
			eml_capab = be_to_host16(eml_capab);
			temp = &eml_capab;
			mlo_capab->MloCapPerRole[i].mld_cap.max_simul_link = (*temp & (BIT(0) | BIT(1) | BIT(2) | BIT(3)));
			mlo_capab->MloCapPerRole[i].mld_cap.srs_supp = (*temp & BIT(4)) >> 4;
			mlo_capab->MloCapPerRole[i].mld_cap.t2l_nego_supp = (*temp & (BIT(5) | BIT(6))) >> 5;
			mlo_capab->MloCapPerRole[i].mld_cap.freq_sep_str = (*temp & (BIT(7) | BIT(8) | BIT(9) | BIT(10) | BIT(11))) >> 7;
			mlo_capab->MloCapPerRole[i].mld_cap.aar_supp = (*temp & BIT(12)) >> 12;
			info(DEBUG_CAT_TLVPRS, "mlo_capab->MloCapPerRole[i].MldCap.max_simul_link %d\n",
				mlo_capab->MloCapPerRole[i].mld_cap.max_simul_link);
			info(DEBUG_CAT_TLVPRS, "mlo_capab->MloCapPerRole[i].MldCap.srs_supp %d\n",
				mlo_capab->MloCapPerRole[i].mld_cap.srs_supp);
			info(DEBUG_CAT_TLVPRS, "mlo_capab->MloCapPerRole[i].MldCap.t2l_nego_supp %d\n",
				mlo_capab->MloCapPerRole[i].mld_cap.t2l_nego_supp);
			info(DEBUG_CAT_TLVPRS, "mlo_capab->MloCapPerRole[i].MldCap.freq_sep_str %d\n",
				mlo_capab->MloCapPerRole[i].mld_cap.freq_sep_str);
			info(DEBUG_CAT_TLVPRS, "mlo_capab->MloCapPerRole[i].MldCap.aar_supp %d\n",
				mlo_capab->MloCapPerRole[i].mld_cap.aar_supp);
			temp_buf = temp_buf + 2;
		}
	}
}
#endif
#ifdef MAP_EHT_SUPPORT
int parse_ap_vendor_specific_tlv(struct _1905_map_device *ctx,
	unsigned char *buf)
{
	unsigned char *temp_buf;
	unsigned short length = 0, left_tlv_len;
	unsigned char func_type = 0;
	unsigned char mtk_oui[3] = {0x00, 0x0C, 0xE7};

	temp_buf = buf;
	if ((*temp_buf) == VENDOR_SPECIFIC_TLV_TYPE)
		temp_buf++;
	else
		return -1;
	length = *(unsigned short *)temp_buf;
	length = be_to_host16(length);
	temp_buf += 2;
	left_tlv_len = length;
	/*err_hexdump(DEBUG_CAT_TLVPRS, "######vendor tlv ", temp_buf, length);*/
	if (left_tlv_len < sizeof(mtk_oui) + 1) {
		err(DEBUG_CAT_TLVPRS, "%d: left %d\n", __LINE__, left_tlv_len);
		return (length + 3);
	}
	if (os_memcmp(temp_buf, mtk_oui, 3)) {
		err(DEBUG_CAT_TLVPRS, "OUI not mtk_oui; do not handle!\n");
		return (length + 3);
	}
	temp_buf += 3;
	func_type = *temp_buf++;
	if (func_type == FUNC_VENDOR_EHT_CAP)
		parse_ap_eht_capability_tlv(ctx, temp_buf);
#ifdef MTK_MLO_MAP_SUPPORT
	else if (func_type == FUNC_VENDOR_MLO_CAP)
		parse_mlo_capability_tlv(ctx, temp_buf);
#endif

	return (length + 3);
}

#ifdef MAP_R6

int parse_eht_operations_tlv(struct _1905_map_device *ctx, unsigned char *buf)
{
	unsigned char *temp_buf;
	unsigned short length = 0, left_tlv_len = 0;
	unsigned char num_radio = 0;
	unsigned char num_bss = 0;
	unsigned char r_idx = 0, bss_idx = 0;
	unsigned char dscb_valid = 0;
	unsigned char eht_pe_duration = 0;
	unsigned char eht_op_info_valid = 0;
	unsigned char grp_addr_bu_ind_limit = 0;
	unsigned char grp_addr_bu_ind_exponent = 0;
	struct eht_operations_info_parse_db *db = NULL;
	struct radio_info_db *radio = NULL;
	struct eht_operations_parse_db eht_op[MAP_MAX_RADIO] = {0};

	if (ctx == NULL || buf == NULL) {
		err(DEBUG_CAT_TLVPRS, "invalid param!! ctx(%p) buf(%p) null\n",
				ctx, buf);
		return -1;
	}

	temp_buf = buf;

	if ((*temp_buf) == EHT_OPERATION_TLV_TYPE)
		temp_buf++;
	else
		return -1;

	/*calculate tlv length*/
	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length | (*(temp_buf + 1));
	left_tlv_len = length;

	temp_buf += 2;


	/*32 bytes reserved*/
	temp_buf += 32;

	left_tlv_len -= 32;

	if (left_tlv_len < 1) {
		err(DEBUG_CAT_TLVPRS, "left %d is less tha %d\n", left_tlv_len, 1);
		return -1;
	}

	for (r_idx = 0; r_idx < MAP_MAX_RADIO; r_idx++)
		dl_list_init(&eht_op[r_idx].eht_op_list);

	/*num of radios*/
	num_radio = *temp_buf;
	temp_buf++;
	left_tlv_len--;

	if (num_radio > MAP_MAX_RADIO || num_radio == 0) {
		err(DEBUG_CAT_TLVPRS, "%d: radio num for eht operation tlv %d\n", __LINE__, num_radio);
		return -1;
	}

	for (r_idx = 0; r_idx < num_radio; r_idx++) {
		if (left_tlv_len < ETH_ALEN) {
			err(DEBUG_CAT_TLVPRS, "left %d is less tha %d\n", left_tlv_len, ETH_ALEN);
			return -1;
		}
		/*radio identifier*/
		os_memcpy(eht_op[r_idx].ruid, temp_buf, ETH_ALEN);
		info(DEBUG_CAT_TLVPRS, "%d: ruid "MACSTR"\n", __LINE__, MAC2STR(eht_op[r_idx].ruid));

		temp_buf += ETH_ALEN;
		left_tlv_len -= ETH_ALEN;

		if (left_tlv_len < 1) {
			err(DEBUG_CAT_TLVPRS, "%d left %d is less tha %d\n", __LINE__, left_tlv_len, 1);
			return -1;
		}

		/* num of BSSs */
		num_bss = *temp_buf;
		info(DEBUG_CAT_TLVPRS, "%d: num_bss %d\n", __LINE__, num_bss);
		temp_buf++;
		left_tlv_len--;

		for (bss_idx = 0; bss_idx < num_bss; bss_idx++) {
			dscb_valid = 0;
			eht_pe_duration = 0;
			eht_op_info_valid = 0;
			grp_addr_bu_ind_limit = 0;
			grp_addr_bu_ind_exponent = 0;

			if (left_tlv_len < ETH_ALEN) {
				err(DEBUG_CAT_TLVPRS, "%d left %d is less tha %d\n", __LINE__, left_tlv_len, ETH_ALEN);
					return -1;
			}
			db = (struct eht_operations_info_parse_db *)os_zalloc(sizeof(struct eht_operations_info_parse_db));
			if (!db) {
				info(DEBUG_CAT_TLVPRS, "%d: error alloc\n", __LINE__);
				return -1;
			}
			/*	This add list causes crash after onboarding
			 *	dl_list_add_tail(&eht_op[r_idx].eht_op_list, &db->list);
			 *	As of now this code is not used [Needs to be fixed]
			 */
			/* BSSID */
			os_memcpy(db->bssid, temp_buf, ETH_ALEN);
			temp_buf += ETH_ALEN;
			left_tlv_len -= ETH_ALEN;

			if (left_tlv_len < 1) {
				info(DEBUG_CAT_TLVPRS, "%d: error left %d less than %d\n",
					__LINE__, left_tlv_len, 1);
				os_free(db);
				return -1;
			}
			/* EHT_Operation_Information_Valid bit 7
			 * Disabled_Subchannel_Valid	bit 6
			 * EHT Default PE Duration bit 5
			 * Group Addressed BU Indication Limit bit 4
			 * Group Addressed BU Indication Exponent	bits 3-2
			 */
			if (*temp_buf & 0x80)
				eht_op_info_valid = 1;
			if (*temp_buf & 0x40)
				dscb_valid = 1;
			if (*temp_buf & 0x20)
				eht_pe_duration = 1;
			if (*temp_buf & 0x10)
				grp_addr_bu_ind_limit = 1;
			if (*temp_buf & 0x04)
				grp_addr_bu_ind_exponent = 1;
			db->eht_operation_information_valid = eht_op_info_valid;
			temp_buf += 1;
			left_tlv_len -= 1;

			if (left_tlv_len < sizeof(struct eht_mcs_nss)) {
				info(DEBUG_CAT_TLVPRS, "%d: error left %d less than %d\n",
					__LINE__, left_tlv_len, (int)sizeof(struct eht_mcs_nss));
				os_free(db);
				return -1;
			}
			/* Basic EHT-MCS And Nss Set */
			os_memcpy(&db->eht_mcs_nss_set, temp_buf, sizeof(struct eht_mcs_nss));
			temp_buf += sizeof(struct eht_mcs_nss);
			left_tlv_len -= sizeof(struct eht_mcs_nss);

			if (left_tlv_len < 5) {
				info(DEBUG_CAT_TLVPRS, "%d: error left %d less than %d\n",
					__LINE__, left_tlv_len, 5);
				os_free(db);
				return -1;
			}
			/* control */
			db->control = *temp_buf++;
			left_tlv_len--;
			/* ccfs0 */
			db->ccfs0 = *temp_buf++;
			left_tlv_len--;
			/* ccfs1 */
			db->ccfs1 = *temp_buf++;
			left_tlv_len--;

			/*Fill eht capabilities for the radio*/
			radio = topo_srv_get_radio(ctx, eht_op[r_idx].ruid);

			if (radio) {
				radio->radio_capability.eht_cap.ccfs0 = db->ccfs0;
				radio->radio_capability.eht_cap.ccfs1 = db->ccfs1;
				radio->radio_capability.eht_cap.eht_ch_width = db->control & DOT11BE_MCS_NSS_MASK;
				radio->radio_capability.eht_cap.valid = 1;
				if (db->eht_mcs_nss_set.max_tx_rx_mcs12_13_nss != 0) {
					radio->radio_capability.eht_cap.rx_stream =
					(db->eht_mcs_nss_set.max_tx_rx_mcs12_13_nss & DOT11BE_MCS_NSS_MASK) - 1;
					radio->radio_capability.eht_cap.tx_stream =
					((db->eht_mcs_nss_set.max_tx_rx_mcs12_13_nss &
					(DOT11BE_MCS_NSS_MASK << DOT11BE_MCS_NSS_SHIFT)) >> DOT11BE_MCS_NSS_SHIFT) - 1;
				} else if (db->eht_mcs_nss_set.max_tx_rx_mcs10_11_nss != 0) {
					radio->radio_capability.eht_cap.rx_stream =
					(db->eht_mcs_nss_set.max_tx_rx_mcs10_11_nss & DOT11BE_MCS_NSS_MASK) - 1;
					radio->radio_capability.eht_cap.tx_stream =
					((db->eht_mcs_nss_set.max_tx_rx_mcs10_11_nss &
					(DOT11BE_MCS_NSS_MASK << DOT11BE_MCS_NSS_SHIFT)) >> DOT11BE_MCS_NSS_SHIFT) - 1;
				} else if (db->eht_mcs_nss_set.max_tx_rx_mcs8_9_nss != 0) {
					radio->radio_capability.eht_cap.rx_stream =
					(db->eht_mcs_nss_set.max_tx_rx_mcs8_9_nss & DOT11BE_MCS_NSS_MASK) - 1;
					radio->radio_capability.eht_cap.tx_stream =
					((db->eht_mcs_nss_set.max_tx_rx_mcs8_9_nss &
					(DOT11BE_MCS_NSS_MASK << DOT11BE_MCS_NSS_SHIFT)) >> DOT11BE_MCS_NSS_SHIFT) - 1;
				} else {
					radio->radio_capability.eht_cap.rx_stream =
					(db->eht_mcs_nss_set.max_tx_rx_mcs0_7_nss & DOT11BE_MCS_NSS_MASK) - 1;
					radio->radio_capability.eht_cap.tx_stream =
					((db->eht_mcs_nss_set.max_tx_rx_mcs0_7_nss &
					(DOT11BE_MCS_NSS_MASK << DOT11BE_MCS_NSS_SHIFT)) >> DOT11BE_MCS_NSS_SHIFT) - 1;
				}
			}

			/* dscb */
			db->dscb_bitmap = *(unsigned short *)temp_buf;
			db->dscb_bitmap = be_to_host16(db->dscb_bitmap);
			temp_buf += 2;
			left_tlv_len -= 2;

			/* reserved 16 bytes */
			if (left_tlv_len < 16) {
				info(DEBUG_CAT_TLVPRS, "%d: error left %d less than %d\n",
					__LINE__, left_tlv_len, 16);
				os_free(db);
				return -1;
			}
			temp_buf += 16;
			left_tlv_len -= 16;

			/*Free alloc memory*/
			os_free(db);
		}

		/* reserved 25 bytes */
		if (left_tlv_len < 25) {
			info(DEBUG_CAT_TLVPRS, "%d: error left %d less than %d\n",
				__LINE__, left_tlv_len, 25);
			return -1;
		}

		temp_buf += 25;
		left_tlv_len -= 25;

	}

	return length + 3;
}

#endif

#endif
#ifdef MAP_R3_DE
int parse_r3_de_inven_tlv(unsigned char *buf, struct _1905_map_device *dev)
{
	unsigned char *temp_buf;
	unsigned short length = 0, left_tlv_len;
	temp_buf = buf;
	unsigned char i = 0;

	if ((*temp_buf) == R3_DE_INVENTORY_TLV_TYPE) {
		temp_buf++;
	} else {
		err(DEBUG_CAT_TLVPRS, TOPO_PREX"should not go here\n");
		return -1;
	}

	//calculate tlv length
	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length | (*(temp_buf + 1));

	//shift to tlv value field
	temp_buf += 2;
	left_tlv_len = length;
	debug_hexdump(DEBUG_CAT_TLVPRS, "R3 DE Inven\n", temp_buf, length);

	memset(&dev->de, '\0', sizeof(struct dev_inven));

	if (left_tlv_len < 1) {
		err(DEBUG_CAT_TLVPRS, "error in length\n");
		return -1;
	}
	/*Saving Serial Num.*/
	dev->de.ser_num_len = *temp_buf++;
	left_tlv_len -= 1;
	if (left_tlv_len < dev->de.ser_num_len + 1) {
		err(DEBUG_CAT_TLVPRS, "error in length\n");
		return -1;
	}
	os_memcpy(dev->de.ser_num, temp_buf, dev->de.ser_num_len);

	debug(DEBUG_CAT_TLVPRS, TOPO_PREX"Serial num length %d - %s\n", dev->de.ser_num_len, dev->de.ser_num);
	temp_buf += dev->de.ser_num_len;

	/*Saving Software Version.*/
	dev->de.sw_ver_len = *temp_buf++;
	left_tlv_len -= dev->de.ser_num_len + 1;

	if (left_tlv_len < dev->de.sw_ver_len + 1) {
		err(DEBUG_CAT_TLVPRS, "error in length\n");
		return -1;
	}
	os_memcpy(dev->de.sw_ver, temp_buf, dev->de.sw_ver_len);

	debug(DEBUG_CAT_TLVPRS, TOPO_PREX"SW version length %d - %s\n", dev->de.sw_ver_len, dev->de.sw_ver);
	temp_buf += dev->de.sw_ver_len;

	/*Saving exec env*/
	dev->de.exec_env_len = *temp_buf++;

	if (left_tlv_len < dev->de.exec_env_len + 1) {
		err(DEBUG_CAT_TLVPRS, "error in length\n");
		return -1;
	}
	os_memcpy(dev->de.exec_env, temp_buf, dev->de.exec_env_len);

	debug(DEBUG_CAT_TLVPRS, TOPO_PREX"Exec version length %d - %s\n", dev->de.exec_env_len, dev->de.exec_env);
	temp_buf += dev->de.exec_env_len;

	/*Saving radio num.*/
	dev->de.num_radio = *temp_buf++;
	left_tlv_len -= dev->de.exec_env_len + 1;

	if (check_subfield_length(MAX_NUM_OF_RADIO, dev->de.num_radio) == FALSE) {
		err(DEBUG_CAT_TLVPRS, "err in max radio\n");
		return -1;
	}

	for (i = 0; i < dev->de.num_radio; i++) {
		if (left_tlv_len < ETH_ALEN + 1) {
			err(DEBUG_CAT_TLVPRS, "error in length\n");
			return -1;
		}
		/*Storing identifier.*/
		os_memcpy(&dev->de.ruid[i].identifier, temp_buf, ETH_ALEN);
		debug(DEBUG_CAT_TLVPRS, TOPO_PREX"Identifier-%d: "MACSTR"\n", i, MAC2STR(dev->de.ruid[i].identifier));

		temp_buf += ETH_ALEN;

		/*Storing Chip version.*/
		dev->de.ruid[i].chip_ven_len = *temp_buf++;
		left_tlv_len -= ETH_ALEN + 1;

		os_memcpy(dev->de.ruid[i].chip_ven, temp_buf, dev->de.ruid[i].chip_ven_len);
		debug(DEBUG_CAT_TLVPRS, TOPO_PREX"Chiv ven length %d - %s\n", dev->de.ruid[i].chip_ven_len, dev->de.ruid[i].chip_ven);

		temp_buf += dev->de.ruid[i].chip_ven_len;
		left_tlv_len -= dev->de.ruid[i].chip_ven_len;

	}

	return (length + 3);
}
#endif //MAP_R3_DE

/**
* @brief Fn to add new traffic stats
*
* @param ctx own 1905 device ctx
* @param traffic_stats sta_traffic_stats to be added
*
* @return 0 if success else -1
*/

int insert_new_traffic_stats_tlv(struct own_1905_device *ctx, struct stat_info *traffic_stats, struct _1905_map_device *dev)
{
	struct associated_clients *cli = NULL, *tcli = NULL;
	struct client *sta = client_db_get_client_from_sta_mac((struct mapd_global *)ctx->back_ptr,traffic_stats->mac);
	struct os_time now, sub;
	unsigned int diff_ul = 0, diff_dl = 0, ul_rate = 0, dl_rate = 0;
	int found = 0;
	long int bytes_check = 0;

	os_get_time(&now);
	SLIST_FOREACH_SAFE(cli, &dev->assoc_clients, next_client, tcli) {
		if (os_memcmp(cli->client_addr, traffic_stats->mac, ETH_ALEN) == 0) {
			found = 1;
			break;
		}
	}
	if (found == 1) {
		cli->stat_db.bytes_sent = traffic_stats->bytes_sent;
		cli->stat_db.bytes_received = traffic_stats->bytes_received;
		cli->stat_db.packets_sent = traffic_stats->packets_sent;
		cli->stat_db.packets_received = traffic_stats->packets_received;
		cli->stat_db.tx_packets_errors = traffic_stats->tx_packets_errors;
		cli->stat_db.rx_packets_errors = traffic_stats->rx_packets_errors;
		cli->stat_db.retransmission_count = traffic_stats->retransmission_count;
		if (cli->stat_db.last_bytes_recieved > cli->stat_db.bytes_received)
			diff_ul = cli->stat_db.bytes_received + 0xFFFFFFFF - cli->stat_db.last_bytes_recieved + 1;
		else
			diff_ul = cli->stat_db.bytes_received - cli->stat_db.last_bytes_recieved;
		if (cli->stat_db.last_bytes_sent > cli->stat_db.bytes_sent)
			diff_dl = cli->stat_db.bytes_sent + 0xFFFFFFFF - cli->stat_db.last_bytes_sent + 1;
		else
			diff_dl = cli->stat_db.bytes_sent - cli->stat_db.last_bytes_sent;
		os_time_sub(&now, &(cli->stat_db.last_traffic_stats_time), &sub);
		if (sub.sec > 0) {
			dl_rate = diff_dl/sub.sec;
			ul_rate = diff_ul/sub.sec;
		}
#ifdef MAP_R2
		if (dev->byte_cnt_unit == 2) {
			cli->stat_db.dl_rate = dl_rate << 3;
			cli->stat_db.ul_rate = ul_rate << 3;
			bytes_check = (dl_rate + ul_rate) * 1024 * 1024;
		} else if (dev->byte_cnt_unit == 1) {
			cli->stat_db.dl_rate = dl_rate >> 7;
			cli->stat_db.ul_rate = ul_rate >> 7;
			bytes_check = (dl_rate + ul_rate) * 1024;
		} else {
#endif
			cli->stat_db.dl_rate = dl_rate >> 17;
			cli->stat_db.ul_rate = ul_rate >> 17;
			bytes_check = dl_rate + ul_rate;
#ifdef MAP_R2
		}
#endif
		cli->stat_db.last_bytes_recieved = cli->stat_db.bytes_received;
		cli->stat_db.last_bytes_sent = cli->stat_db.bytes_sent;
		cli->stat_db.last_traffic_stats_time = now;
	}

	if (sta && found == 1) {
		sta->ul_rate = cli->stat_db.ul_rate;
		sta->dl_rate = cli->stat_db.dl_rate;
		info(DEBUG_CAT_TLVPRS, "sta->mac = " MACSTR"\n", MAC2STR(sta->mac_addr));
		info(DEBUG_CAT_TLVPRS, "sta->ul_rate = %d\n", sta->ul_rate);
		info(DEBUG_CAT_TLVPRS, "sta->dl_rate = %d\n", sta->dl_rate);
#ifndef MTK_MLO_MAP_SUPPORT
		if (dev->device_role == DEVICE_ROLE_AGENT) {
			if (bytes_check > (ctx->cli_steer_params.ActivityThreshold))
				sta->curr_activity_state = 1;
			else
				sta->curr_activity_state = 0;
		}
#else
		if (!sta->mlo_enable) {
			if (dev->device_role == DEVICE_ROLE_AGENT) {
				if (bytes_check > (ctx->cli_steer_params.ActivityThreshold))
					sta->curr_activity_state = 1;
				else
					sta->curr_activity_state = 0;
			}
		} else {
			sta->bytes_check = bytes_check;
			client_mon_mlo_fill_activity_state(
				(struct mapd_global *)ctx->back_ptr,
				sta,
				ctx->cli_steer_params.ActivityThreshold);
		}
#endif
	}

	return 0;
}
#ifdef MAP_R6
/**
* @brief Fn to add new traffic stats
*
* @param ctx own 1905 device ctx
* @param traffic_stats sta_traffic_stats to be added
*
* @return 0 if success else -1
*/

int insert_new_mld_traffic_stats_tlv(struct own_1905_device *ctx, struct stat_mld_info *traffic_stats, struct _1905_map_device *dev)
{
	struct associated_clients *cli = NULL, *tcli = NULL;
	struct client *sta = client_db_get_client_from_sta_mac((struct mapd_global *)ctx->back_ptr, traffic_stats->mac);
	struct os_time now, sub;
	unsigned int diff_ul = 0, diff_dl = 0, ul_rate = 0, dl_rate = 0;
	int found = 0;
	long int bytes_check = 0;

	os_get_time(&now);
	SLIST_FOREACH_SAFE(cli, &dev->assoc_clients, next_client, tcli) {
		if (os_memcmp(cli->client_addr, traffic_stats->mac, ETH_ALEN) == 0) {
			found = 1;
			break;
		}
	}
	if (found == 1) {
		cli->stat_db.bytes_sent = traffic_stats->bytes_sent;
		cli->stat_db.bytes_received = traffic_stats->bytes_received;
		cli->stat_db.packets_sent = traffic_stats->packets_sent;
		cli->stat_db.packets_received = traffic_stats->packets_received;
		cli->stat_db.tx_packets_errors = traffic_stats->tx_packets_errors;
		if (cli->stat_db.last_bytes_recieved_mlo > cli->stat_db.bytes_received)
			diff_ul = cli->stat_db.bytes_received + 0xFFFFFFFF - cli->stat_db.last_bytes_recieved_mlo + 1;
		else
			diff_ul = cli->stat_db.bytes_received - cli->stat_db.last_bytes_recieved_mlo;
		if (cli->stat_db.last_bytes_sent_mlo > cli->stat_db.bytes_sent)
			diff_dl = cli->stat_db.bytes_sent + 0xFFFFFFFF - cli->stat_db.last_bytes_sent_mlo + 1;
		else
			diff_dl = cli->stat_db.bytes_sent - cli->stat_db.last_bytes_sent_mlo;
		os_time_sub(&now, &(cli->stat_db.last_traffic_stats_time_mlo), &sub);
		if (sub.sec > 0) {
			dl_rate = diff_dl/sub.sec;
			ul_rate = diff_ul/sub.sec;
		}
#ifdef MAP_R2
		if (dev->byte_cnt_unit == 2) {
			cli->stat_db.dl_rate_mlo = dl_rate << 3;
			cli->stat_db.ul_rate_mlo = ul_rate << 3;
			bytes_check = (dl_rate + ul_rate) * 1024 * 1024;
		} else if (dev->byte_cnt_unit == 1) {
			cli->stat_db.dl_rate_mlo = dl_rate >> 7;
			cli->stat_db.ul_rate_mlo = ul_rate >> 7;
			bytes_check = (dl_rate + ul_rate) * 1024;
		} else {
#endif
			cli->stat_db.dl_rate_mlo = dl_rate >> 17;
			cli->stat_db.ul_rate_mlo = ul_rate >> 17;
			bytes_check = dl_rate + ul_rate;
#ifdef MAP_R2
		}
#endif
		cli->stat_db.last_bytes_recieved_mlo = cli->stat_db.bytes_received;
		cli->stat_db.last_bytes_sent_mlo = cli->stat_db.bytes_sent;
		cli->stat_db.last_traffic_stats_time_mlo = now;
	}

	if (sta && found == 1) {
#ifndef MTK_MLO_MAP_SUPPORT
		sta->ul_rate = cli->stat_db.ul_rate_mlo;
		sta->dl_rate = cli->stat_db.dl_rate_mlo;
		if (dev->device_role == DEVICE_ROLE_AGENT) {
			if (bytes_check > (ctx->cli_steer_params.ActivityThreshold))
				sta->curr_activity_state = 1;
			else
				sta->curr_activity_state = 0;
		}
#else
		if (!sta->mlo_enable) {
			sta->ul_rate = cli->stat_db.ul_rate_mlo;
			sta->dl_rate = cli->stat_db.dl_rate_mlo;
			if (dev->device_role == DEVICE_ROLE_AGENT) {
				if (bytes_check > (ctx->cli_steer_params.ActivityThreshold))
					sta->curr_activity_state = 1;
				else
					sta->curr_activity_state = 0;
			}
		} else {
			sta->bytes_check = bytes_check;
			client_mon_mlo_fill_activity_state(
				(struct mapd_global *)ctx->back_ptr,
				sta,
				ctx->cli_steer_params.ActivityThreshold);
		}
#endif
	}

	return 0;
}
#endif

int parse_assoc_sta_traffic_stats_tlv(struct own_1905_device * ctx, struct _1905_map_device *dev, unsigned char *buf)
{
	unsigned char *temp_buf = NULL;
	unsigned char *check_buf = NULL;
	unsigned short length = 0;

	temp_buf = buf;
	check_buf = buf;

	if((*temp_buf) == ASSOC_STA_TRAFFIC_STATS_TYPE) {
		temp_buf++;
	} else {
		err(DEBUG_CAT_TLVPRS, "should not go here\n");
		return -1;
	}
	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length |(*(temp_buf+1));

	if (!check_fixed_length_tlv(ASSOC_STA_TRAFFIC_STATS_TYPE_LEN, check_buf, length)) {
		err(DEBUG_CAT_TLVPRS, "error ASSOC_STA_TRAFFIC_STATS_TYPE length is %d incorrect\n", length);
		return -1;
	}

	temp_buf += 2;

	if (0 > insert_new_traffic_stats_tlv(ctx,(struct stat_info *) temp_buf, dev)) {
		debug(DEBUG_CAT_TLVPRS, "insert_new_sta_traffic_stats fail\n");
		return -1;
	}
	return (length+3);
}

#ifdef MAP_R6
int parse_aff_sta_traffic_stats_tlv(struct own_1905_device *ctx, struct _1905_map_device *dev, unsigned char *buf)
{
	unsigned char *temp_buf = NULL;
	unsigned char *check_buf = NULL;
	unsigned short length = 0;
	struct stat_mld_info *traffic_stats = NULL;

	temp_buf = buf;
	check_buf = buf;

	if ((*temp_buf) == AFFILIATED_STA_TRAFFIC_STATS_TYPE) {
		temp_buf++;
	} else {
		err(DEBUG_CAT_TLVPRS, "should not go here\n");
		return -1;
	}

	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length | (*(temp_buf+1));

	if (!check_fixed_length_tlv(AFF_STA_TRAFFIC_STATS_TYPE_LEN, check_buf, length)) {
		err(DEBUG_CAT_TLVPRS, "error AFF_STA_TRAFFIC_STATS_TYPE length is %d incorrect\n", length);
		return -1;
	}

	temp_buf += 2;
	traffic_stats = (struct stat_mld_info *)temp_buf;
	if (traffic_stats == NULL) {
		err(DEBUG_CAT_TLVPRS, "tmp_buf NULL");
		return -1;
	}

	debug(DEBUG_CAT_TLVPRS, "traffic_stats->bytes_sent:%u\n", traffic_stats->bytes_sent);
	debug(DEBUG_CAT_TLVPRS, "traffic_stats->bytes_received:%u\n", traffic_stats->bytes_received);
	debug(DEBUG_CAT_TLVPRS, "traffic_stats->packets_sent:%u\n", traffic_stats->packets_sent);
	debug(DEBUG_CAT_TLVPRS, "traffic_stats->packets_received:%u\n", traffic_stats->packets_received);
	debug(DEBUG_CAT_TLVPRS, "traffic_stats->packets_tx_error:%u\n", traffic_stats->tx_packets_errors);
	return (length+3);
}
#endif

int parse_assoc_sta_link_metrics_tlv(struct own_1905_device * ctx, struct _1905_map_device *dev, unsigned char *buf)
{
	unsigned char *temp_buf;
	unsigned short length = 0;

	temp_buf = buf;

	if((*temp_buf) == ASSOC_STA_LINK_METRICS_TYPE) {
		temp_buf++;
	} else {
		err(DEBUG_CAT_TLVPRS, "should not go here\n");
		return -1;
	}
	//calculate tlv length
	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length |(*(temp_buf+1));

	if (validate_tlv_length_specific_pattern(length,
		ASSOC_STA_LINK_METRICS_TYPE_CONST_LEN,
		ASSOC_STA_LINK_METRICS_TYPE_REPEATED_LEN) == FALSE) {
		err(DEBUG_CAT_TLVPRS, "error ASSOC_STA_LINK_METRICS_TYPE length is %d incorrect\n", length);
		return -1;
	}

	//shift to tlv value field
	temp_buf += 2;

	if (0 > insert_new_sta_metrics_info(ctx, dev, temp_buf, length)) {
		debug(DEBUG_CAT_TLVPRS, "insert_new_ap_metrics_info fail\n");
		return -1;
	}

	return (length+3);
}
/**
* @brief Fn to parse ap metrics tlv
*
* @param ctx own 1905 device ctx
* @param dev 1905 map device pointer
* @param buf msg buffer
*
* @return -1 if error else tlv length
*/
int parse_ap_metrics_tlv(struct own_1905_device * ctx, struct _1905_map_device *dev, unsigned char *buf)
{
	unsigned char *temp_buf;
	unsigned short length = 0;

	temp_buf = buf;

	if((*temp_buf) == AP_METRICS_TYPE) {
		temp_buf++;
	} else {
		err(DEBUG_CAT_TLVPRS, "should not go here\n");
		return -1;
	}

	//calculate tlv length
	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length |(*(temp_buf+1));

	if (!((length >= AP_METRICS_TYPE_CONSTANT_MIN) &&
		(length <= AP_METRICS_TYPE_CONSTANT_MAX))) {
		err(DEBUG_CAT_TLVPRS, "error AP_METRICS_TYPE length is %d incorrect\n", length);
		return -1;
	}
	//shift to tlv value field
	temp_buf += 2;
	/*insert new channel preference info*/
	if (0 > insert_new_ap_metrics_info(ctx, dev, temp_buf, length)) {
		debug(DEBUG_CAT_TLVPRS, "insert_new_ap_metrics_info fail\n");
		return -1;
	}

	return (length+3);
}

#ifdef MAP_R6
/**
 * @brief Fn to parse controller capability tlv
 *
 * @param buf msg buffer
 * @param dev 1905 map device pointer
 *@param r6_dev to check R6 device or not;

 * @return -1 if error else tlv length
 */
int parse_controller_cap_tlv(struct own_1905_device *ctx,
		struct _1905_map_device *dev,
		unsigned char *buf, int *r6_dev)
{
	unsigned char *temp_buf;
	unsigned short length = 0;
	int kibmib, early_apcap;
	unsigned char *check_buf = NULL;

	temp_buf = buf;
	check_buf = buf;

	if ((*temp_buf) == CONTROLLER_CAPABILITY_TYPE) {
		temp_buf++;
	} else {
		err(DEBUG_CAT_TLVPRS, "should not go here\n");
		return -1;
	}

	//calculate tlv length
	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length | (*(temp_buf + 1));

	if (!check_fixed_length_tlv(CONTROLLER_CAPABILITY_LEN, check_buf, length)) {
		err(DEBUG_CAT_TLVPRS, "error CONTROLLER_CAPABILITY_LEN length is %d incorrect\n", length);
		return -1;
	}
	//shift to tlv value field
	temp_buf += 2;

	if (*temp_buf & 0x80)
		kibmib = 1;
	else
		kibmib = 0;

	if (*temp_buf & 0x40)
		early_apcap = 1;
	else
		early_apcap = 0;

	*r6_dev = early_apcap;

	return (length + 3);
}


#endif /* MAP_R6 */


/**
* @brief Fn to parse rx link metrics tlv
*
* @param buf msg buffer
* @param dev 1905 map device pointer
*
* @return -1 if error else tlv length
*/
int parse_tx_link_metrics_tlv(unsigned char *buf,
		struct _1905_map_device *dev)
{
	unsigned char *temp_buf;
	unsigned short length = 0;

	temp_buf = buf;

	if ((*temp_buf) == TRANSMITTER_LINK_METRIC_TYPE) {
		temp_buf++;
	} else {
		err(DEBUG_CAT_TLVPRS, "should not go here\n");
		return -1;
	}

	//calculate tlv length
	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length | (*(temp_buf + 1));

	//shift to tlv value field
	temp_buf += 2;
	/*insert new tx link info */
	if (0 > insert_new_tx_link_metrics_info(dev, temp_buf,
				length)) {
		debug(DEBUG_CAT_TLVPRS, "insert_new_tx_link_metrics_info fail\n");
		return -1;
	}

	return (length + 3);
}

/**
* @brief Fn to insert rx link metrics query in ctx
*
* @param dev 1905 map device
* @param buf msg buffer
* @param len msg length
*
* @return 0 if success else -1
*/
int insert_new_rx_link_metrics_info(
		struct _1905_map_device *dev, unsigned char *buf, unsigned short len)
{
	unsigned char *pos = buf;
	struct map_neighbor_info *neighbor_info, *t_neighbor_info = NULL;
	struct backhaul_link_info *bh_info = NULL, *tbhinfo = NULL;
	unsigned char *neighbor_dev = buf + 6;
	struct list_neighbor *neighbor_list;
	unsigned char found = 0;
	int bh_cnt = 0, i = 0;
#ifdef MTK_MLO_MAP_SUPPORT
	int is_nonsetup_link = 0;
	unsigned int j = 0;
#endif

	neighbor_list = &dev->neighbors_entry;

	SLIST_FOREACH_SAFE(neighbor_info, neighbor_list, next_neighbor, t_neighbor_info)
	{
		if(!os_memcmp(neighbor_info->n_almac, neighbor_dev, ETH_ALEN)) {
			debug(DEBUG_CAT_TLVPRS, "neighbor dev("MACSTR") found\n",
					MAC2STR(neighbor_dev));
			break;
		}
	}

	if (!neighbor_info) {
		/* Discard this info, will be filled in next infra metrics */
		err(DEBUG_CAT_TLVPRS, "topo server doesn't have ("MACSTR") with neighbor("MACSTR")\n",
					MAC2STR(dev->_1905_info.al_mac_addr) ,MAC2STR(neighbor_dev));
		return -1;
	} else {
		pos += 2 * ETH_ALEN;
	}
	if ((len - 12) % 23 != 0) {
		err(DEBUG_CAT_TLVPRS, "tlv length error\n");
		return -1;
	} else
		bh_cnt = (len - 12) / 23;


	for (i = 0; i < bh_cnt; i++) {
		SLIST_FOREACH_SAFE(bh_info, &neighbor_info->bh_head, next_bh, tbhinfo) {
			if (os_memcmp(bh_info->connected_iface_addr, pos, ETH_ALEN) == 0&&
				os_memcmp(bh_info->neighbor_iface_addr, pos + ETH_ALEN, ETH_ALEN) == 0) {
				info(DEBUG_CAT_TLVPRS, "found connected_iface_addr="MACSTR" , neighbor_iface_addr "MACSTR"\n",
						MAC2STR(bh_info->connected_iface_addr), MAC2STR(bh_info->neighbor_iface_addr));
				found = 1;
				break;
			}
#ifdef MTK_MLO_MAP_SUPPORT
			else if (bh_info) {
				if (j >= MLO_NON_SETUP_LINK_MAX) {
					err(DEBUG_CAT_TLVPRS, "MLO NON SETUP LINK Overflow\n");
					j = 0;
				}

				if (os_memcmp(bh_info->mlo_rx[j].connected_iface_addr,  bh_info->connected_iface_addr, ETH_ALEN) != 0) {
					os_memcpy(bh_info->mlo_rx[j].connected_iface_addr,
						pos, ETH_ALEN);
						pos += ETH_ALEN;
						/* memcpy(bh_info->neighbor_iface_addr, pos, ETH_ALEN); */
						pos += ETH_ALEN;

						bh_info->mlo_rx[j].iface_type = ((*pos) << 8) | (*(pos + 1));
						pos += 2;
						bh_info->mlo_rx[j].pkt_err = ((*pos) << 24) | ((*(pos + 1)) << 16) |
						((*(pos + 2)) << 8) | (*(pos + 3));
						pos += 4;
						bh_info->mlo_rx[j].pkt_received = ((*pos) << 24) | ((*(pos + 1)) << 16) |
						((*(pos + 2)) << 8) | (*(pos + 3));
						pos += 4;
						bh_info->mlo_rx[j].rssi = *pos;
						pos += 1;
						is_nonsetup_link = 1;
						debug(DEBUG_CAT_TLVPRS, "%d, %d,%d, %d\n",
						bh_info->mlo_rx[j].iface_type, bh_info->mlo_rx[j].pkt_err, bh_info->mlo_rx[j].pkt_received,
						bh_info->mlo_rx[j].rssi);
						j += 1;
						break;
					}
			}
#endif
		}

		if (found == 0
#ifdef MTK_MLO_MAP_SUPPORT
			 && is_nonsetup_link == 0
#endif
		) {
			/* Discard this info, will be filled in next infra metrics */
			err(DEBUG_CAT_TLVPRS, "topo server doesn't have ("MACSTR") with neighbor("MACSTR")\n",
					MAC2STR(dev->_1905_info.al_mac_addr) ,MAC2STR(neighbor_dev));
			notice(DEBUG_CAT_TLVPRS, "connected("MACSTR") n_iface("MACSTR")\n",
					MAC2STR(pos), MAC2STR((pos + ETH_ALEN)));
			return -1;
		}

		if (found == 1 && (bh_info)
#ifdef MTK_MLO_MAP_SUPPORT
			&& is_nonsetup_link == 0
#endif
		) {
			memcpy(bh_info->connected_iface_addr, pos, ETH_ALEN);
			pos += ETH_ALEN;
			memcpy(bh_info->neighbor_iface_addr, pos, ETH_ALEN);
			pos += ETH_ALEN;

			bh_info->rx.iface_type = ((*pos) << 8) | (*(pos + 1));
			pos += 2;
			bh_info->rx.pkt_err = ((*pos) << 24) | ((*(pos + 1)) << 16) |
				((*(pos + 2)) << 8) | (*(pos + 3));
			pos += 4;
			bh_info->rx.pkt_received = ((*pos) << 24) | ((*(pos + 1)) << 16) |
				((*(pos + 2)) << 8) | (*(pos + 3));
			pos += 4;
			bh_info->rx.rssi = *pos;
			pos += 1;
			os_get_time(&bh_info->last_update);
			debug(DEBUG_CAT_TLVPRS, "insert struct rx_metric_db\n");
			debug(DEBUG_CAT_TLVPRS, "mac("MACSTR")\n",
				MAC2STR(bh_info->connected_iface_addr));
			debug(DEBUG_CAT_TLVPRS, "connect mac("MACSTR")\n",
				MAC2STR(bh_info->neighbor_iface_addr));
			debug(DEBUG_CAT_TLVPRS, "intf_type=%d, error_packet=%d,\n",
				bh_info->rx.iface_type, bh_info->rx.pkt_err);
			debug(DEBUG_CAT_TLVPRS, "rx_packets=%d, rssi=%d\n",
				bh_info->rx.pkt_received, bh_info->rx.rssi);
		}
	}

	if (found == 0) {
		err(DEBUG_CAT_TLVPRS, "topo server doesn't have ("MACSTR") with neighbor("MACSTR")\n",
				MAC2STR(dev->_1905_info.al_mac_addr), MAC2STR(neighbor_dev));
		return -1;
	}

	return 0;
}

/**
* @brief Fn to parse rx link metrics tlv
*
* @param buf msg buffer
* @param dev 1905 map device
*
* @return -1 if error else tlv length
*/
int parse_rx_link_metrics_tlv(unsigned char *buf, struct _1905_map_device *dev)
{
	unsigned char *temp_buf;
	unsigned short length = 0;

	temp_buf = buf;

	if ((*temp_buf) == RECEIVER_LINK_METRIC_TYPE) {
		temp_buf++;
	} else {
		err(DEBUG_CAT_TLVPRS, "should not go here\n");
		return -1;
	}

	//calculate tlv length
	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length | (*(temp_buf + 1));

	//shift to tlv value field
	temp_buf += 2;

	/*insert new channel preference info */
	if (0 > insert_new_rx_link_metrics_info(dev, temp_buf,
				length)) {
		err(DEBUG_CAT_TLVPRS, "insert_new_rx_link_metrics_info fail\n");
		return -1;
	}

	return (length + 3);
}

/**
* @brief Fn to parse beacon metrics query tlv
*
* @param buf msg buffer
* @param beacon beacon_metrics_query struct to be filled
*
* @return tlv lenght if success else -1
*/
int parse_beacon_metrics_query_tlv(unsigned char *buf,
		struct beacon_metrics_query **beacon)
{
	unsigned char *temp_buf = NULL;
	unsigned short length = 0, query_len = 0;
	struct beacon_metrics_query *bcn_query = NULL;
	unsigned char bssid[ETH_ALEN] = { 0 };
	unsigned char sta_mac[ETH_ALEN] = { 0 };
	unsigned char ssid[33] = { 0 };
	unsigned char opclass = 0, ch = 0, rpt_detail = 0;
	unsigned char ssid_len = 0, num_chrep = 0;
	unsigned char i = 0;
	struct ap_chn_rpt *chn_rpt = NULL;
	unsigned short left_tlv_len = 0;

	temp_buf = buf;

	if ((*temp_buf) == BEACON_METRICS_QUERY_TYPE) {
		temp_buf++;
	} else {
		err(DEBUG_CAT_TLVPRS, "should not go here\n");
		return -1;
	}

	//calculate tlv length
	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length | (*(temp_buf + 1));
	left_tlv_len = length;

	//shift to tlv value field
	temp_buf += 2;

	/*STA_MAC*/
	if (left_tlv_len < ETH_ALEN) {
		err(DEBUG_CAT_TLVPRS, "error in length\n");
		return -1;
	}

	memcpy(sta_mac, temp_buf, ETH_ALEN);
	temp_buf += ETH_ALEN;
	left_tlv_len -= ETH_ALEN;

	/*opclass, channel number*/
	if (left_tlv_len < 2) {
		err(DEBUG_CAT_TLVPRS, "error in length\n");
		return -1;
	}
	/*opclass */
	opclass = *temp_buf++;
	/*channel number */
	ch = *temp_buf++;
	left_tlv_len -= 2;

	/*bssid*/
	if (left_tlv_len < ETH_ALEN) {
		err(DEBUG_CAT_TLVPRS, "error in length\n");
		return -1;
	}
	/*bssid */
	memcpy(bssid, temp_buf, ETH_ALEN);
	temp_buf += ETH_ALEN;
	left_tlv_len -= ETH_ALEN;

	if (left_tlv_len < 2) {
		err(DEBUG_CAT_TLVPRS, "error in length\n");
		return -1;
	}
	/*Reporting Detail value */
	rpt_detail = *temp_buf++;
	/*ssid len & ssid */
	ssid_len = *temp_buf++;
	left_tlv_len -= 2;

	if (ssid_len != 0) {
		if (left_tlv_len < (ssid_len)) {
			err(DEBUG_CAT_TLVPRS, "error in length\n");
			return -1;
		}
		memcpy(ssid, temp_buf, ssid_len);
		temp_buf += ssid_len;
		left_tlv_len -= (ssid_len);
	}
	/*Number of AP Channel Reports */
	num_chrep = *temp_buf++;
	left_tlv_len -= 1;
	query_len = sizeof(struct beacon_metrics_query) +
		num_chrep * sizeof(struct ap_chn_rpt);
	debug(DEBUG_CAT_TLVPRS, "query_len=%d\n", query_len);
	bcn_query = (struct beacon_metrics_query *)os_malloc(query_len);
	if (!bcn_query) {
		err(DEBUG_CAT_TLVPRS, "alloc struct beacon_metrics_query fail\n");
		return -1;
	}

	memset(bcn_query, 0, query_len);
	memcpy(bcn_query->sta_mac, sta_mac, ETH_ALEN);
	notice(DEBUG_CAT_TLVPRS, "bcn_query->sta_mac "MACSTR"  ch %d , ssid %s, num_chrep %d\n",
	 MAC2STR(bcn_query->sta_mac), ch, ssid, num_chrep);
	bcn_query->oper_class = opclass;
	bcn_query->ch = ch;
	memcpy(bcn_query->bssid, bssid, ETH_ALEN);
	bcn_query->rpt_detail_val = rpt_detail;
	bcn_query->ssid_len = ssid_len;
	if (ssid_len > 0 && ssid_len <= sizeof(bcn_query->ssid))
		memcpy(bcn_query->ssid, ssid, ssid_len);
	bcn_query->ap_ch_rpt_num = num_chrep;
	chn_rpt = bcn_query->rpt;
	for (i = 0; i < num_chrep; i++) {
		if (left_tlv_len < 1) {
			err(DEBUG_CAT_TLVPRS, "error in length\n");
			os_free(bcn_query);
			return -1;
		}
		/*ap channel report info */
		chn_rpt->ch_rpt_len = *temp_buf++;
		left_tlv_len -= 1;

		if (left_tlv_len < chn_rpt->ch_rpt_len) {
			err(DEBUG_CAT_TLVPRS, "error in length\n");
			os_free(bcn_query);
			return -1;
		}

		chn_rpt->oper_class = *temp_buf++;
		memcpy(chn_rpt->ch_list, temp_buf, chn_rpt->ch_rpt_len - 1);
		temp_buf += chn_rpt->ch_rpt_len - 1;
		left_tlv_len -= chn_rpt->ch_rpt_len;
		chn_rpt++;
	}
	/*element IDs */
	if (left_tlv_len < 1) {
		err(DEBUG_CAT_TLVPRS, "error in length\n");
		os_free(bcn_query);
		return -1;
	}
	if (rpt_detail == 1) {
		bcn_query->elemnt_num = *temp_buf++;
		left_tlv_len -= 1;

		if (left_tlv_len < bcn_query->elemnt_num) {
			err(DEBUG_CAT_TLVPRS, "error in length\n");
			os_free(bcn_query);
			return -1;
		}
		if (bcn_query->elemnt_num > MAX_ELEMNT_NUM)
			bcn_query->elemnt_num = MAX_ELEMNT_NUM;
		memcpy(bcn_query->elemnt_list, temp_buf, bcn_query->elemnt_num);
	} else {
		err(DEBUG_CAT_TLVPRS, "add element num zero due to the value of rpt_detail != 1\n");
		bcn_query->elemnt_num = 0;
	}
	*beacon = bcn_query;

	return (length + 3);
}

/**
* @brief Fn to parse unassoc sta link metrics query tlv
*
* @param buf msg buff
* @param unlink unlink_metrics_query to be filled
*
* @return tlv length if success else -1
*/
int parse_unassociated_sta_link_metrics_query_tlv(unsigned char *buf, struct unlink_metrics_query
		*unlink)
{
	unsigned char *temp_buf = NULL;
	unsigned short length = 0, query_len = 0;
	struct unlink_metrics_query *unlink_query = NULL;
	unsigned char opclass = 0, num_sta = 0, num_ch = 0;
	unsigned char channels[MAX_CH_NUM] = { 0 };
	unlink_query = unlink;

	temp_buf = buf;

	if ((*temp_buf) == UNASSOC_STA_LINK_METRICS_QUERY_TYPE) {
		temp_buf++;
	} else {
		err(DEBUG_CAT_TLVPRS, "should not go here\n");
		return -1;
	}

	//calculate tlv length
	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length | (*(temp_buf + 1));

	//shift to tlv value field
	temp_buf += 2;

	opclass = *temp_buf++;
	num_ch = *temp_buf++;
	memcpy(channels, temp_buf, num_ch);
	temp_buf += num_ch;
	num_sta = *temp_buf++;

	query_len = sizeof(struct unlink_metrics_query) + num_sta * ETH_ALEN;
	debug(DEBUG_CAT_TLVPRS, "query_len=%d\n", query_len);
	//unlink_query = (struct unlink_metrics_query *)os_zalloc(sizeof(query_len));
	if (!unlink_query) {
		err(DEBUG_CAT_TLVPRS, " alloc struct unlink_metrics_query fail\n");
		return -1;
	}

	unlink_query->oper_class = opclass;
	unlink_query->ch_num = num_ch;
	if (unlink_query->ch_num == 0) {
		err(DEBUG_CAT_TLVPRS, "invalid ch num(0)\n");
		return -1;
	}
	if (num_ch <= MAX_CH_NUM)
		memcpy(unlink_query->ch_list, channels, num_ch);
	else
		memcpy(unlink_query->ch_list, channels, MAX_CH_NUM);
	unlink_query->sta_num = num_sta;
	if (unlink_query->sta_num == 0) {
		err(DEBUG_CAT_TLVPRS, "invalid sta num(0)\n");
		return -1;
	}
	memcpy(unlink_query->sta_list, temp_buf,
			unlink_query->sta_num * ETH_ALEN);

	//*unlink = unlink_query;

	return (length + 3);
}

/**
* @brief Fn to parse device info tlv
*
* @param ctx own 1905 device ctx
* @param buf msg buffer
* @param dev 1905 map device ptr
*
* @return -1 if error else tlv length
*/
int parse_device_info_type_tlv(struct own_1905_device *ctx, unsigned char *buf,
		struct _1905_map_device *dev)
{
	unsigned char *temp_buf;
	int length = 0;
	unsigned char itfs_num = 0;
	unsigned char vs_info_len = 0;
	int i = 0, j = 0;
	unsigned char mac[ETH_ALEN];
	unsigned char topo_bss_num = 0;
	char tmp = 0;

	temp_buf = buf;

	if ((*temp_buf) == DEVICE_INFO_TLV_TYPE) {
		temp_buf++;
	} else {
		err(DEBUG_CAT_TLVPRS, TOPO_PREX"should not go here\n");
		return -1;
	}

	//calculate tlv length
	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length | (*(temp_buf + 1));

	//shift to tlv value field
	temp_buf += 2;

	//skip AL MAC address field
	memcpy(dev->_1905_info.al_mac_addr, temp_buf, ETH_ALEN);
	temp_buf += ETH_ALEN;

	//get the amount of local interface
	itfs_num = *temp_buf;
	temp_buf += 1;
	struct iface_info *iface;

	for (i = 0; i < itfs_num; i++) {
		iface = topo_srv_get_iface(dev, temp_buf);
		memcpy(mac, temp_buf, ETH_ALEN);
		temp_buf += ETH_ALEN;

		if (!iface) {
			iface = (struct iface_info *)os_zalloc(sizeof(struct iface_info));
			if (!iface) {
				assert(0);
				err(DEBUG_CAT_TLVPRS, TOPO_PREX"fail to alloc iface\n");
				return -1;
			}
			iface->p1905_device = dev;
			iface->radio = NULL;
			SLIST_INSERT_HEAD(&dev->_1905_info.first_iface,
					iface, next_iface);
			iface->ap_role_set = FALSE;
		}

		memcpy(iface->iface_addr, mac, ETH_ALEN);

		iface->media_type = (*temp_buf);
		iface->media_type = (iface->media_type << 8) & 0xFF00;
		iface->media_type |= (*(temp_buf + 1));
		iface->valid = TRUE;
#ifdef MTK_MLO_MAP_SUPPORT
		iface->itf_num_mlo = itfs_num;
#endif
		temp_buf += 2;

		vs_info_len = (*temp_buf);
		temp_buf += 1;

		debug(DEBUG_CAT_TLVPRS, TOPO_PREX"vs_info_len(%d) for iface\n"MACSTR, vs_info_len, MAC2STR(iface->iface_addr));
		if (vs_info_len > 0) {
			if (vs_info_len == 10) {
				memcpy(&iface->media_info, temp_buf, vs_info_len);
				if (*((char *)(&iface->media_info) + 6) == 0x00) {
					topo_bss_num++;
				}

				if (*((char *)(&iface->media_info) + 6) == 0x40)
				{
					//TODO count station interface
				}
				//! iface bandwidth
				tmp =  *(char *)((char *)(&iface->media_info) + 7);
				iface->media_info.ap_channel_band = (u8)tmp;
				if (iface->media_info.ap_channel_band == 0x2)
				{
					//! it is a 80Mhz iface, assume primary channel as central
					// channel - 6
					iface->channel_freq_idx =
						(*((char *)(&iface->media_info) + 8)) - 6;
				} else {
					//! it is a 40/20Mhz channel, assume primary channel as
					// central freq
					iface->channel_freq_idx =
						*((char *)(&iface->media_info) + 8);
				}
			}
		}
		temp_buf += vs_info_len;
		for (j = 0; j < ctx->num_wifi_itfs; j++) {
			if (!os_memcmp(ctx->wifi_itfs[j]->mac,iface->iface_addr,ETH_ALEN)) {
				if (ctx->wifi_itfs[j]->dev_type == 0) {
					iface->ap_role = 0x0;
					info(DEBUG_CAT_TLVPRS, "MAC "MACSTR" ap_role: %x\n", MAC2STR(iface->iface_addr), iface->ap_role);
				} else if (ctx->wifi_itfs[j]->dev_type == 1) {
					iface->ap_role = 0x4;
					iface->ap_role_set = 1;
					info(DEBUG_CAT_TLVPRS, "MAC "MACSTR" ap_role: %x\n", MAC2STR(iface->iface_addr), iface->ap_role);
				}
			}
		}
	}

	topo_srv_remove_all_invalid_iface(ctx, dev);
	return (length + 3);
}

/**
* @brief Fn to parse almac type tlv
*
* @param buf msg buffer
* @param al_mac almac to be filled
*
* @return -1 if error else tlv length
*/
int parse_al_mac_addr_type_tlv(unsigned char *buf,unsigned char *al_mac)
{
	unsigned char *temp_buf;
	temp_buf = buf;

	if((*temp_buf) == AL_MAC_ADDR_TLV_TYPE)
		temp_buf++;
	else
	{
		return -1;
	}

	if(*temp_buf == 0x0 && *(temp_buf+1) == 0x6)
		temp_buf +=2;
	else
	{
		return -1;
	}

	memcpy(al_mac,temp_buf,ETH_ALEN);
#define TOTAL_AL_MAC_ADDR_TLV_LENGTH 9
	return TOTAL_AL_MAC_ADDR_TLV_LENGTH;
}

/**
* @brief Fn to parse client assoc event tlv
*
* @param buf msg buffer
* @param evt topo_notification to be filled
*
* @return -1 if error else tlv length
*/
#ifdef MAP_R6
struct mlo_config_db *topo_srv_find_ap_mld_entry_by_bss(struct _1905_map_device *dev, u8 *bssid)
{
	struct mlo_config_db *mlo_cfg = NULL;
	struct mlo_config_db *mlo_cfg_tmp = NULL;
	struct affiliated_ap_db *aff_ap = NULL;
	struct affiliated_ap_db *aff_ap_tmp = NULL;
	struct mld_bss_config_db *mld_bss = NULL;

	if (!dev) {
		err(DEBUG_CAT_TLVPRS, TOPO_PREX"invalid param!! dev(%p) null\n", dev);
		return NULL;
	}

	/*Agent AP MLD TLV info update*/
	mld_bss = &dev->mld_bss;

	dl_list_for_each_safe(mlo_cfg, mlo_cfg_tmp, &mld_bss->mlo_cfg_list,
			      struct mlo_config_db, list) {
		if (os_memcmp(mlo_cfg->mld_mac, bssid, ETH_ALEN) == 0) {
			info(DEBUG_CAT_TLVPRS, "mlo_cfg\n"MACSTR, MAC2STR(bssid));
			return mlo_cfg;
		}
		dl_list_for_each_safe(aff_ap, aff_ap_tmp, &mlo_cfg->aff_ap_list,
				      struct affiliated_ap_db, list) {
			if (os_memcmp(aff_ap->affiliated_ap_bssid, bssid, ETH_ALEN == 0)) {
				info(DEBUG_CAT_TLVPRS, "from aff mlo_cfg\n"MACSTR, MAC2STR(bssid));
				return mlo_cfg;
			}
		}
	}

	return NULL;
}
#endif


int parse_client_assoc_event_tlv(struct own_1905_device *ctx, unsigned char *buf, struct topo_notification *evt)
{
	unsigned char *temp_buf = NULL;
	unsigned char *check_buf = NULL;
	unsigned short length = 0;
	unsigned char *pos =NULL;
	struct client_assoc *assoc;
	struct bss_info_db *bss_info = NULL;
	struct mapd_global *global = ctx->back_ptr;
#ifdef MAP_R6
	struct _1905_map_device *dev = NULL;
	struct mlo_config_db *mlo_cfg = NULL;
	struct topo_connected_ap_sta_map *assoc_data = NULL;
	int is_mld = 0;
#endif

	temp_buf = buf;
	check_buf = buf;

	if((*temp_buf) == CLIENT_ASSOCIATION_EVENT_TYPE)
		temp_buf++;
	else
		return -1;


	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length |(*(temp_buf+1));

	if (!check_fixed_length_tlv(CLIENT_ASSOCIATION_EVENT_TYPE_LEN, check_buf, length)) {
		debug(DEBUG_CAT_TLVPRS, "length(%d) error\n", length);
		return -1;
	}

	temp_buf+=2;

	assoc = &evt->assoc[evt->assoc_cnt];
	evt->assoc_cnt++;
	memcpy(assoc->sta_addr, temp_buf, ETH_ALEN);
	debug(DEBUG_CAT_TLVPRS, "client("MACSTR")\n", MAC2STR(temp_buf));
	temp_buf += ETH_ALEN;
	memcpy(assoc->bssid, temp_buf, ETH_ALEN);
	pos = temp_buf;
	temp_buf += ETH_ALEN;
	assoc->is_joined = *temp_buf;

#ifdef MAP_R6
	dev = topo_srv_get_1905_device(ctx, evt->al_mac);
	if (!dev)
		err(DEBUG_CAT_TLVPRS, TOPO_PREX"mld case fail to get dev\n"MACSTR, MAC2STR(evt->al_mac));
#endif
	bss_info = topo_srv_get_bss_by_bssid(ctx, NULL, assoc->bssid);

#ifdef MAP_R6
	if (!bss_info) {
		err(DEBUG_CAT_TLVPRS, TOPO_PREX"bss info "MACSTR" not found finding MLD addr\n", MAC2STR(assoc->bssid));
		/*need to find the MLD addr given bssid, in dev as sta is assoc with this dev.*/
		mlo_cfg = topo_srv_find_ap_mld_entry_by_bss(dev, assoc->bssid);

		if (mlo_cfg) {
			bss_info = topo_srv_get_bss_by_bssid(ctx, dev, mlo_cfg->mld_mac);
			is_mld = 1;
		}
	}
#endif

	if (assoc->is_joined) {
		if (bss_info
#ifdef MAP_R6
		    || mlo_cfg
#endif
		) {
#if 0
			if (is_local_adm_ether_addr(assoc->sta_addr))
				always("inform local wifi APCLI join\n");
			else
#endif
			always("inform local wifi APCLI/STA join\n");
#ifdef MAP_R6
			if (mlo_cfg) {
				mapd_user_wireless_client_join(global,
					assoc->sta_addr, assoc->bssid,
					mlo_cfg->ssid);
			} else {
#endif
				mapd_user_wireless_client_join(global,
					assoc->sta_addr, assoc->bssid,
					(char *)bss_info->ssid);
#ifdef MAP_R6
			}
#endif
		}
	} else {
		if (bss_info
#ifdef MAP_R6
		    || mlo_cfg
#endif
		) {
#if 0
			if (is_local_adm_ether_addr(assoc->sta_addr))
				always("inform local wifi APCLI left\n");
			else
#endif
			always("inform local wifi APCLI/STA left\n");
#ifdef MAP_R6
			if (mlo_cfg) {
				mapd_user_wireless_client_leave(global,
					assoc->sta_addr, assoc->bssid,
					mlo_cfg->ssid);
			} else {
#endif
				mapd_user_wireless_client_leave(
					global,
					assoc->sta_addr, assoc->bssid,
					(char *)bss_info->ssid);
#ifdef MAP_R6
			}
#endif
		}
	}

	info(DEBUG_CAT_TLVPRS, "%s the ", (*temp_buf) ? "join" : "left\n");
	info(DEBUG_CAT_TLVPRS, "bss("MACSTR")", MAC2STR(pos));

#ifdef MAP_R6
	if (dev && assoc->is_joined) {
		assoc_data = os_zalloc(sizeof(struct topo_connected_ap_sta_map));
		if (!assoc_data) {
			err(DEBUG_CAT_TLVPRS, "allocation fail\n");
			goto fail;
		}
		os_memcpy(assoc_data->sta_mac, assoc->sta_addr, ETH_ALEN);
		os_memcpy(assoc_data->bssid_mac, assoc->bssid, ETH_ALEN);
		assoc_data->is_mld_sta = is_mld;
		dl_list_add(&dev->ap_sta_map_head, &assoc_data->entry);
	}
fail:
#endif /* MAP_R6 */
	return (length+3);

}

/**
* @brief Fn to parse topology event
*
* @param ctx own 1905 device ctx
* @param buf msg buffer
* @param evt topology notification event
*
* @return 0 if success else -1
*/

#ifdef MAP_R6
int find_al_mac_topo_noti_evt(struct own_1905_device *ctx, u8 *buf,
			      struct topo_notification *evt, u16 len)
{
	int length = 0;
	u8 *temp_buf = NULL;
	u16 check_len = 0;
	u16 tlv_len = 0;

	temp_buf = buf;

	while (1) {
		check_len = get_tlv_len(temp_buf);
		tlv_len = check_len + 3;

		if (len < tlv_len) {
			err(DEBUG_CAT_TLVPRS, "Error TLV len, type = %d, len %d less than tlv_len %d\n",
				*temp_buf, len, tlv_len);
			return -1;
		}

		if (*temp_buf == AL_MAC_ADDR_TLV_TYPE) {
			length = parse_al_mac_addr_type_tlv(temp_buf, evt->al_mac);
			if (length < 0) {
				err(DEBUG_CAT_TLVPRS, "error al mac tlv\n");
				return -1;
			}
			temp_buf += length;
			return 0;
		}
		info(DEBUG_CAT_TLVPRS, "ignore TLV in topology notification message %d\n", *temp_buf);
		/*ignore extra tlv*/
		length = get_cmdu_tlv_length(temp_buf);
		temp_buf += length;
		len -= tlv_len;
	}
	return -1;
}
#endif

int parse_topology_notification_evt(struct own_1905_device *ctx, unsigned char *buf, struct topo_notification *evt, unsigned short len)
{
	int length =0;
	unsigned char *temp_buf;
	unsigned int integrity = 0;
	unsigned int right_integrity = 0x1;
	unsigned short check_len = 0;
	unsigned short tlv_len = 0;

	temp_buf = buf;
	evt->assoc_cnt = 0;

#ifdef MAP_R6
	/*AL_MAC should be know to get 1905_dev, reordering TLV case.*/
	if (find_al_mac_topo_noti_evt(ctx, buf, evt, len)) {
		err(DEBUG_CAT_TLVPRS, "wrong topo notification as al_mac_tlv not present\n");
		return -1;
	}

	notice(DEBUG_CAT_TLVPRS, TOPO_PREX"topo_notification from almac "MACSTR"\n", MAC2STR(evt->al_mac));
#endif

	while (1) {
		check_len = get_tlv_len(temp_buf);
		tlv_len = check_len + 3;

		if (len < tlv_len) {
			err(DEBUG_CAT_TLVPRS, "Error TLV len, type = %d, len %d less than tlv_len %d\n",
				*temp_buf, len, tlv_len);
			return -1;
		}

		if (*temp_buf == AL_MAC_ADDR_TLV_TYPE) {
			integrity |= (1<<0);
			length=parse_al_mac_addr_type_tlv(temp_buf, evt->al_mac);

			if (length < 0) {
				err(DEBUG_CAT_TLVPRS, "error al mac tlv\n");
				return -1;
			}
			temp_buf += length;
		} else if (*temp_buf == CLIENT_ASSOCIATION_EVENT_TYPE) {
			length = parse_client_assoc_event_tlv(ctx, temp_buf, evt);

			if(length < 0) {
				err(DEBUG_CAT_TLVPRS, "error client_assoc_event tlv\n");
				return -1;
			}

			temp_buf += length;
			} else if (*temp_buf == END_OF_TLV_TYPE) {
			break;
		} else {
			err(DEBUG_CAT_TLVPRS, "wrong TLV in topology notification messagn\n");
			/*ignore extra tlv*/
			length = get_cmdu_tlv_length(temp_buf);
			temp_buf += length;
		}
		len -= tlv_len;
	}

	/*check integrity*/
	if (integrity != right_integrity) {
		err(DEBUG_CAT_TLVPRS, "incomplete topology notification 0x%x 0x%x\n",
				integrity, right_integrity);
		return -1;
	}

	return 0;
}


/**
* @brief Fn to parse bridge capability tlv
*
* @param ctx own 1905 device ctx
* @param buf msg buffer
* @param dev 1905 map device pointer
*
* @return tlv length if success else -1
*/
int parse_bridge_capability_type_tlv(struct own_1905_device *ctx, unsigned char *buf,
		struct _1905_map_device *dev)
{
	unsigned char *temp_buf;
	int length = 0;
	unsigned char br_num = 0;
	int i = 0;
	unsigned char br_itfs_num = 0;
	struct _1905_device *_1905_info = &dev->_1905_info;
	struct _1905_bridge *tmp_br, *br = SLIST_FIRST(&_1905_info->first_bridge);

	temp_buf = buf;

	if ((*temp_buf) == BRIDGE_CAPABILITY_TLV_TYPE) {
		temp_buf++;
	} else {
		err(DEBUG_CAT_TLVPRS, TOPO_PREX"should not go here\n");
		return -1;
	}

	//calculate tlv length
	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length | (*(temp_buf + 1));
	//shift to tlv value field
	temp_buf += 2;

	//the field of total number of bridge tuple
	br_num = *temp_buf;
	temp_buf++;

	while (br) {
		tmp_br = SLIST_NEXT(br, next_bridge);
		if (br->interface_mac_tuple)
			free(br->interface_mac_tuple);
		free(br);
		br = tmp_br;
	}
	SLIST_INIT(&_1905_info->first_bridge);

	for (i = 0; i < br_num; i++) {
		br_itfs_num = *temp_buf;
		temp_buf++;

		br = (struct _1905_bridge *)
			os_malloc(sizeof(struct _1905_bridge));
		if(br == NULL) {
			err(DEBUG_CAT_TLVPRS, TOPO_PREX"alloc br fail\n");
			return -1;
		}
		os_memset(br, 0, sizeof(struct _1905_bridge));
		br->interface_count = br_itfs_num;

		if (br_itfs_num > 0)
			br->interface_mac_tuple =
				(unsigned char *)os_malloc(br_itfs_num * ETH_ALEN);

		if(br->interface_mac_tuple == NULL) {
			err(DEBUG_CAT_TLVPRS, TOPO_PREX"alloc interface_mac_tuple fail\n");
			if (br)
				os_free(br);
			return -1;
		}
		os_memset(br->interface_mac_tuple, 0, br_itfs_num * ETH_ALEN);
		memcpy(br->interface_mac_tuple, temp_buf,
				(br_itfs_num * ETH_ALEN));
		SLIST_INSERT_HEAD(&dev->_1905_info.first_bridge, br, next_bridge);

		temp_buf += br_itfs_num * ETH_ALEN;
	}

	return (length + 3);
}

struct map_neighbor_info *topo_srv_create_insert_neighbor_entry(struct own_1905_device *ctx,
			struct _1905_map_device *dev, unsigned char *al_mac,
			unsigned char *own_iface, unsigned char *n_iface)
{
	struct backhaul_link_info *bh;
	struct map_neighbor_info *neighbor = os_zalloc(sizeof(struct map_neighbor_info));
	//Remove entry from client DB
	uint32_t client_id;
	u8 already_seen = 2;
	struct mapd_global *mapd_ctx = (struct mapd_global *)ctx->back_ptr;
	struct iface_info *iface = NULL;

	if (neighbor == NULL) {
		err(DEBUG_CAT_TLVPRS, TOPO_PREX"alloc neighbor memory fail\n");
		assert(0);
		return NULL;
	}
	memcpy(neighbor->n_almac, al_mac, ETH_ALEN);
	neighbor->parent = dev;
	SLIST_INSERT_HEAD(&dev->neighbors_entry, neighbor, next_neighbor);

	SLIST_INIT(&neighbor->bh_head);
	/* Since we are allcating it, there is a link available */
	bh = os_zalloc(sizeof(struct backhaul_link_info));
	if (!bh) {
		err(DEBUG_CAT_TLVPRS, TOPO_PREX"failed to allocate memory for bh info\n");
		assert(0);
		return NULL;
	}
	bh->is_valid = 1;
	SLIST_INSERT_HEAD(&neighbor->bh_head, bh, next_bh);
	neighbor->insert_new_link = 1;

	/* update interface info if available */
	if (own_iface) {
		os_memcpy(bh->connected_iface_addr, own_iface, ETH_ALEN);
		iface = topo_srv_get_iface(dev, own_iface);
		if (iface && iface->media_type < IEEE802_11_GROUP) {
			neighbor->insert_new_link = 2;
		} else if (iface && iface->media_type >= IEEE802_11_GROUP) {
			neighbor->insert_new_link = 3;
		}
	}
	if (n_iface) {
		os_memcpy(bh->neighbor_iface_addr, n_iface, ETH_ALEN);
	}
	notice(DEBUG_CAT_TLVPRS, TOPO_PREX"neighbor almac ("MACSTR")\n", MAC2STR(neighbor->n_almac));
	notice(DEBUG_CAT_TLVPRS, TOPO_PREX"conn_iface ("MACSTR") new_link (%u)\n",
	 MAC2STR(bh->connected_iface_addr), neighbor->insert_new_link);
	notice(DEBUG_CAT_TLVPRS, TOPO_PREX"neighbor_iface ("MACSTR")\n", MAC2STR(bh->neighbor_iface_addr));


	if (n_iface) {
#ifdef EM_PLUS_SUPPORT
		struct client *cli = NULL;

		cli = get_client_from_sta_mac(ctx, bh->neighbor_iface_addr);
		if (cli && cli->bcn_query) {
			info(DEBUG_CAT_TLVPRS, "bh sta is still in mutil beacon query flow" MACSTR
			"\n", MAC2STR(bh->neighbor_iface_addr));
			return neighbor;
		}
#endif
		client_id = client_db_track_add(mapd_ctx, bh->neighbor_iface_addr, &already_seen);
		if (client_id == (uint32_t)-1) {
			err(DEBUG_CAT_TLVPRS, "No more room to accommodate" MACSTR
						", that has joined a BSS on another device\n", MAC2STR(bh->neighbor_iface_addr));
		}
	}

	return neighbor;
}

/**
* @brief Fn to parse 1905 neighbor device tlv
*
* @param ctx own 1905 device ctx
* @param buf msg buffer
* @param dev 1905 map device pointer
*
* @return -1 if error else tlv length
*/
struct _1905_map_device *topo_srv_create_1905_device(struct own_1905_device *ctx, unsigned char *almac);
int parse_p1905_neighbor_device_type_tlv(struct own_1905_device *ctx, unsigned char *buf,
		struct _1905_map_device *dev)
{
	unsigned char *temp_buf;
	int length = 0;
	struct iface_info *iface, *tiface = NULL;
	unsigned char local_mac[ETH_ALEN];
	unsigned char al_mac[ETH_ALEN];
	unsigned char exist = 0;
	unsigned char new_db = 1;
	int tuple_num = 0;
#ifdef REMOVE
	unsigned char up_device_invalid = FALSE;
#endif
	struct mapd_global *mapd_ctx = (struct mapd_global *)ctx->back_ptr;
	int i = 0;
	struct map_neighbor_info *neighbor, *tmp_neighbor, *t_neighbor = NULL, *t_tmp_neighbor = NULL;
	struct _1905_map_device *tmp_dev;
	struct _1905_map_device * own_1905_map_device = topo_srv_get_1905_device(ctx, NULL);
	char skip  = 0;
	struct bh_link_entry *bh_entry = NULL, *tbh_entry = NULL;

	if (own_1905_map_device != dev) {
		own_1905_map_device = NULL;
	}
	temp_buf = buf;

	if ((*temp_buf) == P1905_NEIGHBOR_DEV_TLV_TYPE) {
		temp_buf++;
	} else {
		err(DEBUG_CAT_TLVPRS, "should not go here\n");
		return -1;
	}

	/* calculate tlv length */
	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length | (*(temp_buf + 1));
	/*shift to tlv value field */
	temp_buf += 2;

	memcpy(local_mac, temp_buf, ETH_ALEN);
	temp_buf += ETH_ALEN;

	/* tlv value has one local mac address field(6 bytes) and several
	 * (al mac address field(6 bytes) + 802.1 exist field(1 byte)),
	 * so tlv (value length - 6 ) % 7 must be zero
	 */
	if (((length - 6) % 7) == 0) {
		tuple_num = (length - 6) / 7;
	} else {
		err(DEBUG_CAT_TLVPRS, TOPO_PREX"len (%d) error! ignore dev("MACSTR")\n", length, MAC2STR(dev->_1905_info.al_mac_addr));
		return (length + 3);
	}

	SLIST_FOREACH_SAFE(iface, &(dev->_1905_info.first_iface), next_iface, tiface) {
		if (!os_memcmp(local_mac, iface->iface_addr, ETH_ALEN)) {
			/*it means it has map neighbor device, so it is backhaul interface*/
			if (tuple_num > 0) {
				info(DEBUG_CAT_TLVPRS, NETOPT_PREX"set iface is_map_if=%d of "MACSTR"\n",
				 iface->is_map_if, MAC2STR(iface->iface_addr));
				iface->is_map_if = 1;
			}
			exist = 1;
			break;
		}
	}

	if (exist == 0) {
#ifdef EM_PLUS_EXT_SUPPORT
		iface = (struct iface_info *)os_zalloc(sizeof(struct iface_info));
		if (!iface) {
			assert(0);
			err(DEBUG_CAT_TLVPRS, TOPO_PREX"fail to alloc iface");
			return -1;
		}

		iface->p1905_device = dev;
		iface->radio = NULL;
		SLIST_INSERT_HEAD(&dev->_1905_info.first_iface,
			iface, next_iface);
		iface->ap_role_set = FALSE;
		memcpy(iface->iface_addr, local_mac, ETH_ALEN);
		iface->media_type = 0x0001;
		iface->valid = TRUE;
		iface->ap_role = 0x0;
		iface->is_map_if = 1;
#else
		err(DEBUG_CAT_TLVPRS, TOPO_PREX"interface not found! local_mac("MACSTR") dev("MACSTR")",
			MAC2STR(local_mac), MAC2STR(dev->_1905_info.al_mac_addr));
		return (length + 3);
#endif
	}

	if (own_1905_map_device && tuple_num > 0 &&
		iface->media_type >= IEEE802_11_GROUP &&
		iface->ap_role == 0x04) {
		SLIST_FOREACH_SAFE(bh_entry, &ctx->bh_link_head, next_bh_link, tbh_entry) {
			if (!mapd_ctx->params.Certification && !os_memcmp(local_mac, bh_entry->mac_addr, ETH_ALEN) &&
				bh_entry->bh_assoc_state == WAPP_APCLI_DISASSOCIATED) {
					err(DEBUG_CAT_TLVPRS, TOPO_PREX"own apcli("MACSTR
					") link down!!! drop stale own rsp\n", MAC2STR(local_mac));
					return (length + 3);
			}
		}
	}

	for (i = 0; i < tuple_num; i++) {
		skip = 0;
		memcpy(al_mac, temp_buf, ETH_ALEN);
		temp_buf += ETH_ALEN;

		/*do not use the topology rsp of my neighbor device to update all the link related
		*to me. it may be incorrect due to the asynchronous updating neighbor time between
		*two directly connected device
		*/
		if (!os_memcmp(ctx->al_mac, al_mac, ETH_ALEN))
			skip = 1;

        new_db = 1;
 		SLIST_FOREACH_SAFE(neighbor, &dev->neighbors_entry, next_neighbor, t_neighbor) {
 			if (!os_memcmp(al_mac, neighbor->n_almac, ETH_ALEN)) {
 				new_db = 0;
				break;
            }
        }

		if (skip) {
			/*update link info*/
			if (!new_db) {
				topo_srv_update_neighbor_entry(ctx, neighbor, local_mac, dev, al_mac, skip);
				tmp_dev = topo_srv_get_1905_device(ctx, al_mac);
				SLIST_FOREACH_SAFE(tmp_neighbor, &tmp_dev->neighbors_entry, next_neighbor, t_tmp_neighbor)
				{
					if (!os_memcmp(tmp_neighbor->n_almac, dev->_1905_info.al_mac_addr, ETH_ALEN))
						break;
				}
				if (tmp_neighbor)
					topo_srv_update_neighbor_entry_peer(ctx, tmp_neighbor, local_mac, dev, al_mac, skip);
			}
			temp_buf += 1;
			continue;
		}

		if (new_db) {
			notice(DEBUG_CAT_TLVPRS, TOPO_PREX"new_db!!! create neighbor("MACSTR") for dev("MACSTR")\n",
				MAC2STR(al_mac), MAC2STR(dev->_1905_info.al_mac_addr));
			neighbor = topo_srv_create_insert_neighbor_entry(ctx, dev, al_mac, local_mac, NULL);
			tmp_dev = topo_srv_get_1905_device(ctx, al_mac);
			if (!tmp_dev) {
				tmp_dev = topo_srv_create_1905_device(ctx, al_mac);
				neighbor->neighbor = tmp_dev;
				/* Add one entry in its neighbor and bh for ourself */
				notice(DEBUG_CAT_TLVPRS, TOPO_PREX"create neighbor("MACSTR") for dev("MACSTR")\n",
					MAC2STR(dev->_1905_info.al_mac_addr), MAC2STR(al_mac));
				tmp_neighbor = topo_srv_create_insert_neighbor_entry(ctx, tmp_dev,
							dev->_1905_info.al_mac_addr, NULL, local_mac);
				tmp_neighbor->neighbor = dev;
			} else {
				tmp_neighbor = SLIST_FIRST(&tmp_dev->neighbors_entry);
				while (tmp_neighbor) {
					if (!os_memcmp(tmp_neighbor->n_almac, dev->_1905_info.al_mac_addr, ETH_ALEN))
						break;
					tmp_neighbor = SLIST_NEXT(tmp_neighbor, next_neighbor);
				}
				if (!tmp_neighbor) {
					notice(DEBUG_CAT_TLVPRS, TOPO_PREX"create neighbor("MACSTR") for dev("MACSTR")\n",
						MAC2STR(dev->_1905_info.al_mac_addr), MAC2STR(al_mac));
					tmp_neighbor = topo_srv_create_insert_neighbor_entry(ctx, tmp_dev,
							dev->_1905_info.al_mac_addr, NULL, local_mac);
					tmp_neighbor->neighbor = dev;
				}
			}
		} else {
			debug(DEBUG_CAT_TLVPRS, TOPO_PREX"exist db!!! dev("MACSTR")has neighbor("MACSTR")\n",
               MAC2STR(dev->_1905_info.al_mac_addr),
               MAC2STR(al_mac));

			tmp_dev = topo_srv_get_1905_device(ctx, al_mac);
			/* there is only one backhaul info, TODO modify it for multiple links */
			if(tmp_dev) {
				t_tmp_neighbor = NULL;
				SLIST_FOREACH_SAFE(tmp_neighbor, &tmp_dev->neighbors_entry, next_neighbor, t_tmp_neighbor)
				{
					if (!os_memcmp(tmp_neighbor->n_almac, dev->_1905_info.al_mac_addr, ETH_ALEN))
						break;
				}
				if (!tmp_neighbor) {
					err(DEBUG_CAT_TLVPRS, TOPO_PREX"error!!! create neighbor("MACSTR") for dev("MACSTR")\n",
						MAC2STR(dev->_1905_info.al_mac_addr), MAC2STR(al_mac));
					tmp_neighbor = topo_srv_create_insert_neighbor_entry(ctx, tmp_dev,
							dev->_1905_info.al_mac_addr, NULL, local_mac);
					tmp_neighbor->neighbor = dev;
				}
				/*update bh link of dev which is the neighbor of the device reporting topology response*/
				if (topo_srv_update_neighbor_entry_peer(ctx, tmp_neighbor, local_mac, dev, al_mac, skip) < 0)
					return (length + 3);
				/*update bh link of dev which report the topology response*/
				if (topo_srv_update_neighbor_entry(ctx, neighbor, local_mac, dev, al_mac, skip) < 0)
					return (length + 3);
			} else {
				err(DEBUG_CAT_TLVPRS, TOPO_PREX"error!!! dev("MACSTR") not found\n", MAC2STR(al_mac));
					return (length + 3);
			}
		}
		neighbor->neighbor = tmp_dev;
		neighbor->neighbor->in_network = 1;
		neighbor->is_valid = 1;
		os_get_time(&neighbor->neighbor->last_seen);
		/* Assumption, AP is always upstream device when operating as cli, correct? */
		if (iface->ap_role_set) {
			if ((iface->media_type >= IEEE802_11_GROUP) && (iface->ap_role == 0x4)) {
				if (dev->upstream_device != tmp_dev) {
					dev->upstream_device = tmp_dev;
					notice(DEBUG_CAT_TLVPRS, TOPO_PREX"set dev("MACSTR") iface("MACSTR") upstream dev to ("MACSTR")\n",
						MAC2STR(dev->_1905_info.al_mac_addr), MAC2STR(iface->iface_addr),
						MAC2STR(tmp_dev->_1905_info.al_mac_addr));
				}
			}
		}

		if (((*temp_buf) & 0x80) == 0x80)
			neighbor->ieee_802_1_bridge_exist = 1;
		else
			neighbor->ieee_802_1_bridge_exist = 0;

		temp_buf += 1;
	}
	return (length + 3);
}

/**
* @brief Fn to parse non 1905 neighbor device tlv
*
* @param ctx own 1905 device ctx
* @param buf msg buffer
* @param dev 1905 map device
*
* @return -1 if error else tlv length
*/
int parse_non_p1905_neighbor_device_type_tlv(struct own_1905_device *ctx, unsigned char *buf,
		struct _1905_map_device *dev)
{
	unsigned char *temp_buf;
	int length = 0;
	int tuple_num = 0;
	unsigned char local_mac[ETH_ALEN];
	unsigned char neighbor_mac[ETH_ALEN];
	struct iface_info *iface, *tiface = NULL;
	struct connected_clients *client, *tclient = NULL;

	unsigned char exist = 0;
	unsigned char new_db = 1;
	int i = 0;

	temp_buf = buf;

	if ((*temp_buf) == NON_P1905_NEIGHBOR_DEV_TLV_TYPE)
		temp_buf++;
	else {
		return -1;
	}

	/*calculate tlv length */
	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length | (*(temp_buf + 1));
	/*shift to tlv value field */
	temp_buf += 2;

	/*get local interface field */
	memcpy(local_mac, temp_buf, ETH_ALEN);
	temp_buf += ETH_ALEN;

	/*calculate how many non-1905.1 device */
	if (((length - 6) % 6) == 0) {
		tuple_num = (length - 6) / 6;
		//debug(DEBUG_CAT_TLVPRS, "tuple_num = %d",tuple_num);
	} else {
		//debug(DEBUG_CAT_TLVPRS, "ignore non p1905.1 neighbor tlv");
		return (length + 3);
	}

	SLIST_FOREACH_SAFE(iface, &(dev->_1905_info.first_iface), next_iface, tiface) {
		if (!os_memcmp(local_mac, iface->iface_addr, ETH_ALEN)) {
			exist = 1;
			break;
		}
	}

	if (exist) {
		for (i = 0; i < tuple_num; i++) {
			memcpy(neighbor_mac, temp_buf, ETH_ALEN);
			temp_buf += ETH_ALEN;

			new_db = 1;
			/* maybe we don't need to do this check because the old topology
			 * response db will be deleted when we get a new topology response
			 * message.
			 */

			SLIST_FOREACH_SAFE(client, &(dev->wlan_clients),
					next_client, tclient) {
				if (!os_memcmp(neighbor_mac, client->client_addr,
						 ETH_ALEN) &&
					!os_memcmp(local_mac, client->_1905_iface_addr, ETH_ALEN)) {
					new_db = 0;
					break;
				}
			}

			if (new_db) {
				client = (struct connected_clients *)os_zalloc(sizeof
								(struct connected_clients));
				if (client == NULL) {
					err(DEBUG_CAT_TLVPRS, TOPO_PREX"Error in os_malloc\n");
					return -1;
				}
				memcpy(client->client_addr, neighbor_mac,
						ETH_ALEN);
				memcpy(client->_1905_iface_addr, local_mac, ETH_ALEN);
				client->is_bh_link = 0;
				SLIST_INSERT_HEAD(&(dev->wlan_clients),
						client, next_client);

				client->is_APCLI = 0;
				if (iface->media_type < IEEE802_11_GROUP) {
					struct mapd_global *global = ctx->back_ptr;
					mapd_user_eth_client_join(global,
						client->client_addr, dev->_1905_info.al_mac_addr);
				}
			}
			client->entry_valid = TRUE;
		}
	}
	return (length + 3);
}

extern void mapd_start_wired_iface_monitor(void *eloop_ctx, void *timeout_ctx);

/**
* @brief Fn to parse supported service tlv
*
* @param ctx own 1905 device ctx
* @param buf msg buffer
* @param dev 1905 map device
*
* @return -1 if error else tlv length
*/
int parse_supported_service_tlv(struct own_1905_device *ctx, unsigned char *buf,
		struct _1905_map_device *dev)
{

	unsigned char *temp_buf;
	int length = 0;
	int role_old = 0, supported_services_old = 0;
	struct _1905_map_device *_1905_device = topo_srv_get_next_1905_device(ctx, NULL);

#ifdef EM_PLUS_SUPPORT
	int sup_service[2] = { 0 };
#endif /*EM_PLUS_SUPPORT*/

	temp_buf = buf;

	if ((*temp_buf) == SUPPORTED_SERVICE_TLV_TYPE)
		temp_buf++;
	else {
		return -1;
	}

	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length | (*(temp_buf + 1));
	temp_buf += 2;

	/* as per specs, List of supported service + type(agent/controller/agent+controller)
	 * so the length can be either 2 or 3
	 */
	role_old = dev->device_role;
	supported_services_old = dev->supported_services;
	if (length == 2) {
		temp_buf++;
		dev->supported_services = *temp_buf;
		if (dev->supported_services)
			dev->device_role = DEVICE_ROLE_AGENT;
		else
			dev->device_role = DEVICE_ROLE_CONTROLLER;
	} else if (length == 3) {
		temp_buf++;
		dev->supported_services = 2;
#ifdef EM_PLUS_SUPPORT
		sup_service[0] = *temp_buf;
		temp_buf++;
		sup_service[1] = *temp_buf;

		if (sup_service[0] == DEVICE_ROLE_EMPLUS_AGENT || sup_service[1] == DEVICE_ROLE_EMPLUS_AGENT) {
			dev->device_role = DEVICE_ROLE_AGENT;
			dev->supported_services = 1;
		}  else if (sup_service[0] == DEVICE_ROLE_EMPLUS_CONTROLLER || sup_service[1] == DEVICE_ROLE_EMPLUS_CONTROLLER) {
			dev->device_role = DEVICE_ROLE_CONTROLLER;
			dev->supported_services = 0;
		} else
#endif /* EM_PLUS_SUPPORT*/
		{
			dev->supported_services = 2;
			dev->device_role = DEVICE_ROLE_CONTRAGENT;
		}
	} else {
		return (length + 3);
	}

	if (role_old != dev->device_role)
		notice(DEBUG_CAT_TLVPRS, TOPO_PREX"reset role to %d for dev "MACSTR"\n",
			dev->device_role, MAC2STR(dev->_1905_info.al_mac_addr));

	if (supported_services_old != dev->supported_services)
		notice(DEBUG_CAT_TLVPRS, TOPO_PREX"reset supp_services to %d for dev "MACSTR"\n",
			dev->supported_services, MAC2STR(dev->_1905_info.al_mac_addr));

	if ((dev->device_role == DEVICE_ROLE_CONTROLLER || dev->device_role == DEVICE_ROLE_CONTRAGENT) &&
		(ctx->device_role == DEVICE_ROLE_UNCONFIGURED)) {
		ctx->device_role = DEVICE_ROLE_AGENT;
		_1905_device->device_role = DEVICE_ROLE_AGENT;
		notice(DEBUG_CAT_TLVPRS, TOPO_PREX"updated device role as agent for Dev" MACSTR"\n",
		 MAC2STR(_1905_device->_1905_info.al_mac_addr));
	}

	return (length + 3);
}

#ifdef BR_IP_TLV_SUPPORT
/* bridge info VS TLV parser code */
int parse_br_ip_vendor_tlv(struct own_1905_device *ctx, unsigned char *buf, struct _1905_map_device *dev)
{
	unsigned char *temp_buf;
	int left = 0, length = 0;
	u8 MTK_OUI[OUI_LEN] = {0x00, 0x0C, 0xE7};
	struct br_info *pbr_info = NULL;
	struct in_addr sin_addr;

	temp_buf = buf;

	if (dev->br_info)
		os_free(dev->br_info);

	dev->br_info = os_zalloc(sizeof(struct br_info));

	if (!dev->br_info) {
		err(DEBUG_CAT_TLVPRS, "fail to allocate memory\n");
		return -1;
	}

	if ((*temp_buf) == VENDOR_SPECIFIC_TLV_TYPE)
		temp_buf++;
	else
		goto err_exit;

	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length | (*(temp_buf + 1));
	temp_buf += 2;

	left = length;
	info(DEBUG_CAT_TLVPRS, "len:%d\n", length);

	if (left < sizeof(MTK_OUI)) {
		err(DEBUG_CAT_TLVPRS, "mtk oui left %d less than %d\n",
			left, (unsigned int)(sizeof(MTK_OUI) + 1));
		goto err_exit;
	}

	left -= sizeof(MTK_OUI);

	if (os_memcmp(temp_buf, MTK_OUI, sizeof(MTK_OUI))) {
		err(DEBUG_CAT_TLVPRS, "OUI not mtk_oui; do not handle!\n");
		goto err_exit;
	}
	temp_buf += 3;

	if (*temp_buf == FUNC_VENDOR_BR_IP_TLV) {
		temp_buf += 1;
		left -= 1;
		if (left == sizeof(struct br_info)) {
			memcpy(dev->br_info, temp_buf, sizeof(struct br_info));
			pbr_info = (struct br_info *)dev->br_info;
			info(DEBUG_CAT_TLVPRS, "br-name:%s\n", pbr_info->br_name);
			info(DEBUG_CAT_TLVPRS, "br-addr:%02x:%02x:%02x:%02x:%02x:%02x\n", MAC2STR(pbr_info->br_addr));
			info(DEBUG_CAT_TLVPRS, "br-ip[hex]:0x%x\n", pbr_info->br_ip);
			sin_addr.s_addr = pbr_info->br_ip;
			info(DEBUG_CAT_TLVPRS, "br-ip[dot]:%s\n", inet_ntoa(sin_addr));
		} else {
			notice(DEBUG_CAT_TLVPRS, "left:%d, struct size:%d\n", left, (unsigned int)sizeof(struct br_info));
			goto err_exit;
		}
	}
	return length;

err_exit:
	os_free(dev->br_info);
	dev->br_info = NULL;
	return -1;
}
#endif /* BR_IP_TLV_SUPPORT */

/**
* @brief Fn to parse ap operation type bss
*
* @param ctx own 1905 device ctx
* @param buf msg buffer
* @param dev 1905 map device
*
* @return  -1 if error else tlv length
*/
int parse_ap_operational_bss_type_tlv(struct own_1905_device *ctx, unsigned char *buf,
		struct _1905_map_device *dev)
{
	unsigned char *temp_buf = NULL;
	int count = 0, i = 0, bss_count = 0, j = 0;
	int length = 0;
	struct radio_info_db *radio  = NULL;
	struct bss_info_db *bss = NULL;

	if(!ctx || !buf || !dev) {
		err(DEBUG_CAT_TLVPRS, TOPO_PREX"invalid input, ctx: %p, buf: %p, dev: %p\n", ctx, buf, dev);
		return -1;
	}

	temp_buf = buf;

	if ((*temp_buf) == AP_OPERATIONAL_BSS_TYPE)
		temp_buf++;
	else {
		return -1;
	}

	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length | (*(temp_buf + 1));
	temp_buf += 2;

	count = *temp_buf;
	temp_buf++;

	for (i = 0; i < count; i++) {
		radio = topo_srv_get_radio(dev, temp_buf);
		if (!radio) {
#ifdef MAP_NON6E_CONTROLLER
			if (dev->tear_down_6g) {
				err(DEBUG_CAT_TLVPRS, "failed to create radio with given identifier due to tear down bit\n");
				return 1;
			}
#endif
#ifdef MAP_RADIO_TEARDOWN
			if (is_radio_teardown(ctx, temp_buf)) {
				err(DEBUG_CAT_TLVPRS, "radio is tear down not created\n");
				temp_buf += ETH_ALEN;
				temp_buf++;
				continue;
			}
#endif
			radio = os_zalloc(sizeof(*radio));
			if (!radio) {
				err(DEBUG_CAT_TLVPRS, TOPO_PREX"alloc memory fail for radio\n");
				return -1;
			}
			memcpy(radio->identifier, temp_buf, ETH_ALEN);
			radio->parent_1905 = dev;
			SLIST_INSERT_HEAD(&dev->first_radio, radio, next_radio);
			SLIST_INIT(&radio->link_estimate_cb_head);
			SLIST_INIT(&radio->chan_preferance.prefer_info_head);
			SLIST_INIT(&radio->chan_restrict.restrict_head);
#ifdef MAP_R2
			SLIST_INIT(&radio->first_scan_result);
			SLIST_INIT(&radio->cac_cap.cac_capab_head);
			SLIST_INIT(&radio->cac_comp_status.cac_completion_opcap_head);
#endif
#ifdef MAP_R6
			radio->radio_capability.wifi7_mlo_cap = NULL;
#endif
			radio->bh_priority = 1;
		}
		topo_srv_mark_all_oper_bss_invalid(ctx, dev, radio);
		temp_buf += ETH_ALEN;
		bss_count = *temp_buf;
		temp_buf++;
		for (j = 0; j < bss_count; j++) {
			bss = topo_srv_get_bss_by_bssid(ctx, dev, temp_buf);
			if (!bss) {
				bss = os_malloc(sizeof(*bss));
				if (!bss) {
					err(DEBUG_CAT_TLVPRS, TOPO_PREX"alloc memory fail for bss\n");
					return -1;
				}
				os_memset(bss, 0, sizeof(*bss));
				memcpy(bss->bssid, temp_buf, ETH_ALEN);

#ifdef DATA_ELEMENT_SUPPORT
				os_get_reltime(&bss->first_ts);
#endif
				SLIST_INIT(&bss->esp_head);
				SLIST_INSERT_HEAD(&(dev->first_bss), bss, next_bss);
#ifdef ACL_CTRL
				dl_list_init(&bss->acl_cli_list);
#endif
			}
			temp_buf += ETH_ALEN;
			bss->ssid_len = 0;
			bss->ssid_len = *temp_buf;
			temp_buf++;
			bss->radio = radio;
			bss->valid = TRUE;
			os_memset(bss->ssid, 0, MAX_SSID_LEN);
			memcpy(bss->ssid, temp_buf, bss->ssid_len);
			temp_buf += bss->ssid_len;
		}
	}

	return (length + 3);
}

#ifdef MAP_R6
void topo_srv_create_assoc_cli_sta_mld(struct own_1905_device *ctx, struct _1905_map_device *dev)
{
	struct mlo_sta_config_db *mld_sta_cfg = NULL, *tmld_sta_cfg = NULL;
	struct mlo_sta_db *mld_sta = NULL, *tmld_sta = NULL;
	struct associated_clients *assoc_client = NULL, *tassoc_client = NULL;
	struct bss_info_db *bss = NULL;
	int new_assoc_cli = 0;
	struct mapd_global *global = ctx->back_ptr;

	if (SLIST_EMPTY(&(dev->first_mld_sta_cnf_rpt))) {
		info(DEBUG_CAT_TLVPRS, "mld_sta_cfg is not present "MACSTR"\n",
		MAC2STR(dev->_1905_info.al_mac_addr));
		return;
	}

	mld_sta_cfg = SLIST_FIRST(&(dev->first_mld_sta_cnf_rpt));

	while (mld_sta_cfg) {
		tmld_sta_cfg = SLIST_NEXT(mld_sta_cfg, list);

		/*first delete any assoc_client made by mld_addr.*/
		assoc_client = topo_srv_get_associate_client(ctx, dev, mld_sta_cfg->sta_mld_mac);

		/*clear_invalid_client_info will clear all invalid entry*/
		if (assoc_client)
			assoc_client->entry_valid = FALSE;

		if (SLIST_EMPTY(&(mld_sta_cfg->mlo_sta_list))) {
			err(DEBUG_CAT_TLVPRS, "sta_mld_list empty"MACSTR"\n", MAC2STR(mld_sta_cfg->sta_mld_mac));
			mld_sta_cfg = tmld_sta_cfg;
			continue;
		}

		mld_sta = SLIST_FIRST(&(mld_sta_cfg->mlo_sta_list));

		/*Making new assoc clients if not present.*/
		info(DEBUG_CAT_TLVPRS, "mld_sta_cfg->is_present = %d\n", mld_sta_cfg->is_present);
		while (mld_sta_cfg->is_present && mld_sta) {
			tmld_sta = SLIST_NEXT(mld_sta, list);
			if (is_zero_ether_addr(mld_sta->bssid)) {

				info(DEBUG_CAT_TLVPRS, "invalid bssid "MACSTR", not create bss for it\n", MAC2STR(mld_sta->bssid));
				mld_sta = tmld_sta;
				continue;
			}

			bss = topo_srv_get_bss_by_bssid(ctx, dev, mld_sta->bssid);
			if (!bss) {

				info(DEBUG_CAT_TLVPRS, "bssid "MACSTR" of assoc bss not found\n", MAC2STR(mld_sta->bssid));
				bss = os_zalloc(sizeof(*bss));
				if (!bss) {
					err(DEBUG_CAT_TLVPRS, TOPO_PREX"alloc memory fail for bss for dev\n"MACSTR,
						MAC2STR(dev->_1905_info.al_mac_addr));
					return;
				}
				SLIST_INIT(&bss->esp_head);
				os_memcpy(bss->bssid, mld_sta->bssid, ETH_ALEN);
				SLIST_INSERT_HEAD(&dev->first_bss, bss, next_bss);
#ifdef ACL_CTRL
				dl_list_init(&bss->acl_cli_list);
#endif
				bss->valid = TRUE;
			}
			/*only this affilated sta entry added.*/
			bss->assoc_sta_cnt += 1;

			tassoc_client = topo_srv_get_associate_client(ctx, dev, mld_sta->affiliated_sta_mac);

			if (!tassoc_client) {
				tassoc_client = (struct associated_clients *)os_zalloc(sizeof(struct associated_clients));
				if (!tassoc_client) {
					err(DEBUG_CAT_TLVPRS, TOPO_PREX"Memory allocation error\n");
					return;
				}
				os_memcpy(tassoc_client->client_addr, mld_sta->affiliated_sta_mac, ETH_ALEN);
				SLIST_INSERT_HEAD(&dev->assoc_clients, tassoc_client, next_client);
			}
			os_memcpy(tassoc_client->mld_addr, mld_sta_cfg->sta_mld_mac, ETH_ALEN);
			tassoc_client->mld_enable = 1;
			tassoc_client->bss = bss;
			tassoc_client->is_bh_link = 0;
			tassoc_client->is_APCLI = 0;
			tassoc_client->entry_valid = TRUE;
			info(DEBUG_CAT_TLVPRS, "tassoc_client->client_addr "MACSTR " entry_valid = TRUE\n",
			 MAC2STR(tassoc_client->client_addr));
			tassoc_client->mld_sta_cfg = mld_sta_cfg;

			new_assoc_cli = 1;

			mld_sta = tmld_sta;
		}
#ifdef CENT_STR
	if (ctx->cent_str_en && ctx->device_role == DEVICE_ROLE_CONTROLLER) {
		//struct mapd_global *global = (struct mapd_global *)ctx->back_ptr;
		struct client *cli;

		if (tassoc_client) {
			cli = client_db_get_client_from_sta_mac(global, tassoc_client->client_addr);
			info(DEBUG_CAT_TLVPRS, "tassoc_client->client_addr "MACSTR"\n", MAC2STR(tassoc_client->client_addr));
			if (cli) {
				info(DEBUG_CAT_TLVPRS, "Client id = %u\n", cli->client_id);
				info(DEBUG_CAT_TLVPRS, "cli->bssid = " MACSTR, MAC2STR(cli->bssid));
			}
			if ((cli && is_zero_ether_addr(cli->bssid)) || (!cli && new_assoc_cli == 1)) {
				info(DEBUG_CAT_TLVPRS, "going to call client capability\n");
				info(DEBUG_CAT_TLVPRS, "mld_sta_cfg->ap_mld_mac = "MACSTR"\n", MAC2STR(mld_sta_cfg->ap_mld_mac));
				info(DEBUG_CAT_TLVPRS, "mld_sta_cfg->sta_mld_mac = "MACSTR"\n", MAC2STR(mld_sta_cfg->sta_mld_mac));
				map_1905_Send_Client_Capability_Query_Message(global->_1905_ctrl,
							(char *)dev->_1905_info.al_mac_addr,
							mld_sta_cfg->ap_mld_mac,
							mld_sta_cfg->sta_mld_mac);
			}
		}
	}
#endif
		mld_sta_cfg = tmld_sta_cfg;
	}
	//dump_mld_sta_cfg(dev);
}

void topo_srv_update_affiliated_bssid(struct own_1905_device *ctx, struct _1905_map_device *dev)
{
	//struct mapd_global *global;
	struct mlo_sta_config_db *mld_sta_cfg, *tmld_sta_cfg;
	struct mlo_sta_db *mld_sta, *tmld_sta;
	//uint32_t cli_id = 0;
	//u8 already_seen = 0;
	struct client *cli;

//	global = (struct mapd_global *)ctx->back_ptr;

	if (SLIST_EMPTY(&(dev->first_mld_sta_cnf_rpt))) {
		info(DEBUG_CAT_TLVPRS, "mld_sta_cfg is not present "MACSTR, MAC2STR(dev->_1905_info.al_mac_addr));
		return;
	}
	info(DEBUG_CAT_TLVPRS, "first_mld_sta_cnf_rpt present for "MACSTR, MAC2STR(dev->_1905_info.al_mac_addr));
	//dump_mld_sta_cfg(dev);

	mld_sta_cfg = SLIST_FIRST(&(dev->first_mld_sta_cnf_rpt));
	while (mld_sta_cfg) {
		tmld_sta_cfg = SLIST_NEXT(mld_sta_cfg, list);
		mld_sta = SLIST_FIRST(&(mld_sta_cfg->mlo_sta_list));
		while (mld_sta) {
			tmld_sta = SLIST_NEXT(mld_sta, list);
			cli = get_client_from_sta_mac_r6(ctx, mld_sta->affiliated_sta_mac);
			if (!cli) {
				info(DEBUG_CAT_TLVPRS, "client not found for affiliated sta mac " MACSTR"\n",
				 MAC2STR(mld_sta->affiliated_sta_mac));
				mld_sta = tmld_sta;
				continue;
			}
			info(DEBUG_CAT_TLVPRS, "Cli_id = %u for mld_sta->affiliated_sta_mac " MACSTR"\n",
			cli->client_id, MAC2STR(mld_sta->affiliated_sta_mac));
			if (mld_sta_cfg->is_present) {
				info(DEBUG_CAT_TLVPRS, "before cli->bssid = " MACSTR"\n", MAC2STR(cli->bssid));
				info(DEBUG_CAT_TLVPRS, "before cli->sta_mld_bssid = " MACSTR"\n", MAC2STR(cli->sta_mld_bssid));
				os_memcpy(cli->bssid, mld_sta->bssid, ETH_ALEN);
				//os_memcpy(cli->sta_mld_bssid, mld_sta->bssid, ETH_ALEN);
				os_memcpy(cli->sta_mld_bssid, mld_sta_cfg->ap_mld_mac, ETH_ALEN);
				info(DEBUG_CAT_TLVPRS, "AFTER cli->bssid = " MACSTR"\n", MAC2STR(cli->bssid));
				info(DEBUG_CAT_TLVPRS, "AFTER cli->sta_mld_bssid = " MACSTR"\n", MAC2STR(cli->sta_mld_bssid));
			}
			mld_sta = tmld_sta;
		}
		mld_sta_cfg = tmld_sta_cfg;
	}

}

void dump_wlan_client(struct _1905_map_device *dev)
{
	struct connected_clients *conn_client = NULL, *tconn_client = NULL;

	SLIST_FOREACH_SAFE(conn_client, &dev->wlan_clients, next_client, tconn_client) {
		notice(DEBUG_CAT_TLVPRS, "conn_client->client_addr " MACSTR"\n", MAC2STR(conn_client->client_addr));
		notice(DEBUG_CAT_TLVPRS, "conn_client->_1905_iface_addr " MACSTR"\n", MAC2STR(conn_client->_1905_iface_addr));
		notice(DEBUG_CAT_TLVPRS, "conn_client->bss_addr " MACSTR"\n", MAC2STR(conn_client->bss_addr));
	}
}

void topo_srv_create_wlan_cli_sta_mld(struct own_1905_device *ctx, struct _1905_map_device *dev)
{
	/*need to go through each mld_sta_cfg*/
	/*1) find any mld addr wlan_client delete that*/
	/*2) go through each sta_mld_db to check if any not present in wlan list add them.*/
	struct mlo_sta_config_db *mld_sta_cfg = NULL, *tmld_sta_cfg = NULL;
	struct mlo_sta_db *mld_sta = NULL, *tmld_sta = NULL;
	struct connected_clients *client = NULL, *tclient = NULL;
	struct connected_clients *nclient = NULL;

	if (SLIST_EMPTY(&(dev->first_mld_sta_cnf_rpt))) {
		info(DEBUG_CAT_TLVPRS, "mld_sta_cfg is not present "MACSTR"\n",
		MAC2STR(dev->_1905_info.al_mac_addr));
		return;
	}

	mld_sta_cfg = SLIST_FIRST(&(dev->first_mld_sta_cnf_rpt));

	while (mld_sta_cfg) {
		tmld_sta_cfg = SLIST_NEXT(mld_sta_cfg, list);

		/*first delete any wlan_client made by mld_addr.*/
		SLIST_FOREACH_SAFE(client, &(dev->wlan_clients), next_client, tclient) {
			if (!os_memcmp(client->client_addr, mld_sta_cfg->sta_mld_mac, ETH_ALEN)) {
				client->entry_valid = FALSE;
				break;
			}
		}

		if (SLIST_EMPTY(&(mld_sta_cfg->mlo_sta_list))) {
			info(DEBUG_CAT_TLVPRS, "sta_mld_list empty"MACSTR"\n", MAC2STR(mld_sta_cfg->sta_mld_mac));
			mld_sta_cfg = tmld_sta_cfg;
			continue;
		}

		mld_sta = SLIST_FIRST(&(mld_sta_cfg->mlo_sta_list));

		/*Making new wlan clients if not present.*/
		info(DEBUG_CAT_TLVPRS, "mld_sta_cfg->is_present = %d\n", mld_sta_cfg->is_present);
		while (mld_sta_cfg->is_present && mld_sta) {
		//	err(DEBUG_CAT_TLVPRS, "");
			tmld_sta = SLIST_NEXT(mld_sta, list);

			client = NULL;
			tclient = NULL;
			SLIST_FOREACH_SAFE(client, &(dev->wlan_clients), next_client, tclient) {
				if (!os_memcmp(client->client_addr, mld_sta->affiliated_sta_mac, ETH_ALEN)) {
					os_memcpy(client->_1905_iface_addr, mld_sta->bssid, ETH_ALEN);
					os_memcpy(client->bss_addr, mld_sta->bssid, ETH_ALEN);
					client->entry_valid = TRUE;
					client->mld_sta_cfg = mld_sta_cfg;
					nclient = client;
					break;
				}
				nclient = NULL;
			}

			if (!nclient) {
				nclient = os_zalloc(sizeof(*nclient));
				if (!nclient) {
					err(DEBUG_CAT_TLVPRS, TOPO_PREX"Error in os_zalloc\n");
					return;
				}
				SLIST_INSERT_HEAD(&(dev->wlan_clients), nclient, next_client);
				os_memcpy(nclient->_1905_iface_addr, mld_sta->bssid, ETH_ALEN);
				os_memcpy(nclient->bss_addr, mld_sta->bssid, ETH_ALEN);
				os_memcpy(nclient->client_addr, mld_sta->affiliated_sta_mac, ETH_ALEN);
				nclient->entry_valid = TRUE;
				nclient->mld_sta_cfg = mld_sta_cfg;

				nclient->is_bh_link = 0;
				nclient->is_APCLI = 0;

			}
			mld_sta = tmld_sta;
		}
		mld_sta_cfg = tmld_sta_cfg;
	}

	//dump_mld_sta_cfg(dev);
}
#endif
void clear_all_client_info(struct own_1905_device *ctx, struct _1905_map_device *dev)
{
	struct associated_clients *client = NULL, *next_cli = NULL;
	struct connected_clients *conn_client = NULL, *next_conn_client = NULL;
	client = SLIST_FIRST(&dev->assoc_clients);
	while (client) {
		next_cli = SLIST_NEXT(client, next_client);
#ifdef MAP_6E_SUPPORT
		client->entry_valid = FALSE;
#else
		SLIST_REMOVE(&dev->assoc_clients, client, associated_clients, next_client);
		os_free(client);
#endif
		client = next_cli;
	}
#ifndef MAP_6E_SUPPORT
	SLIST_INIT(&dev->assoc_clients);
#endif
	conn_client = SLIST_FIRST(&dev->wlan_clients);
	while(conn_client) {
		struct bss_info_db *bss = NULL;
		bss = topo_srv_get_bss_by_bssid(ctx, dev, conn_client->_1905_iface_addr); //removing wireless clients
		next_conn_client = SLIST_NEXT(conn_client, next_client);
		if (bss == NULL) {
#if 1
			conn_client->entry_valid = FALSE;
#else
			info(DEBUG_CAT_TLVPRS, "%s deleted eth sta=%02x:%02x:%02x:%02x:%02x:%02x",
			 PRINT_MAC(conn_client->client_addr));
			SLIST_REMOVE(&dev->wlan_clients, conn_client, connected_clients, next_client);
			os_free(conn_client);
#endif
		}
		conn_client = next_conn_client;
	}
#ifdef MAP_R6
	mark_all_sta_mld_cnf_invalid(dev);
#endif
	return;
}
void clear_invalid_client_info(struct own_1905_device *ctx, struct _1905_map_device *dev)
{
	struct connected_clients *conn_client = NULL, *next_conn_client = NULL;
#ifdef MAP_6E_SUPPORT
	struct associated_clients *assoc_client = NULL, *next_assoc_client = NULL;
#endif

#ifdef MAP_R6
	del_sta_mld_cfg_invalid(dev);
#endif

	conn_client = SLIST_FIRST(&dev->wlan_clients);
	while(conn_client) {
		struct bss_info_db *bss = NULL;
		bss = topo_srv_get_bss_by_bssid(ctx, dev, conn_client->_1905_iface_addr); //removing wireless clients
		next_conn_client = SLIST_NEXT(conn_client, next_client);
		if ((bss == NULL) && (conn_client->entry_valid == FALSE)) {
			struct mapd_global *global = ctx->back_ptr;

			info(DEBUG_CAT_TLVPRS, "deleted eth sta= "MACSTR"\n",
			 MAC2STR(conn_client->client_addr));
			mapd_user_eth_client_leave(global,
				conn_client->client_addr, dev->_1905_info.al_mac_addr);
			SLIST_REMOVE(&dev->wlan_clients, conn_client, connected_clients, next_client);
			os_free(conn_client);
		}
		conn_client = next_conn_client;
	}
#ifdef MAP_6E_SUPPORT
	if (SLIST_EMPTY(&dev->wlan_clients))
		SLIST_INIT(&dev->wlan_clients);
#endif

#ifdef MAP_6E_SUPPORT
	assoc_client = SLIST_FIRST(&dev->assoc_clients);
	while (assoc_client) {
		next_assoc_client = SLIST_NEXT(assoc_client, next_client);
		if (assoc_client->entry_valid == FALSE) {
			info(DEBUG_CAT_TLVPRS, "Delete sta: "MACSTR" from dev: "MACSTR"\n",
				MAC2STR(assoc_client->client_addr), MAC2STR(dev->_1905_info.al_mac_addr));
			SLIST_REMOVE(&dev->assoc_clients, assoc_client, associated_clients, next_client);
			os_free(assoc_client);
		}
		assoc_client = next_assoc_client;
	}
	if (SLIST_EMPTY(&dev->assoc_clients))
		SLIST_INIT(&dev->assoc_clients);
#endif
	return;
}

int check_bssid_oper_bss_list(char *list_bss, int bss_count, u8 *bss_id)
{
	int i = 0;

	if (list_bss == NULL)
		return 0;

	for (i = 0; i < bss_count; i++) {
		if (!memcmp((list_bss + (i*ETH_ALEN)), bss_id, ETH_ALEN))
			return 1;
	}

	return 0;
}

#ifdef MAP_R6
int validate_associated_sta_mld_config_type_tlv(unsigned char *buf)
{
	unsigned char *temp_buf;
	int length = 0;
	int left_tlv_len = 0;
	int num_af_sta = 0;

	temp_buf = buf;

	if ((*temp_buf) == ASSOCIATED_STA_MLD_CONFIG_REPORT_TLV_TYPE)
		temp_buf++;
	else
		return -1;

	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length | (*(temp_buf + 1));
	left_tlv_len = length;
	temp_buf += 2;

	/*sta MLD addr(6), AP MLD Addr(6), MLD config(1), rsvd(18)*/
	/*num of affiliated sta(1)*/
	if (left_tlv_len < 32) {
		err(DEBUG_CAT_TLVPRS, "length error\n");
		return -1;
	}

	/*sta MLD addr(6), AP MLD Addr(6), MLD config(1), rsvd(18)*/
	temp_buf += 31;
	left_tlv_len -= 31;

	num_af_sta = *temp_buf;
	temp_buf++;
	left_tlv_len -= 1;

	/*num_af_sta*(sta bssid(6), af_sta_mac(6), rsvd(19))*/

	if (left_tlv_len < (num_af_sta*31)) {
		err(DEBUG_CAT_TLVPRS, "length error\n");
		return -1;
	}

	return (length + 3);
}

#endif


int validate_ap_associated_clients_type_tlv(unsigned char *buf)
{
	unsigned char *temp_buf;
	int length = 0;
	int left_tlv_len = 0;
	u8 bss_cnt = 0, j = 0;
	u16 sta_cnt = 0, i = 0;

	temp_buf = buf;

	if ((*temp_buf) == AP_ASSOCIATED_CLIENTS_TYPE)
		temp_buf++;
	else
		return -1;

	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length | (*(temp_buf + 1));
	left_tlv_len = length;
	temp_buf += 2;

	if (left_tlv_len < 1) {
		err(DEBUG_CAT_TLVPRS, "length error\n");
		return -1;
	}

	bss_cnt = *temp_buf;
	temp_buf++;
	left_tlv_len -= 1;
	for (j = 0; j < bss_cnt; j++) {
		if (left_tlv_len < (ETH_ALEN+2)) {
			err(DEBUG_CAT_TLVPRS, "length error\n");
			return -1;
		}
		temp_buf += ETH_ALEN;

		sta_cnt = *((u16 *)temp_buf);
		sta_cnt = be_to_host16(sta_cnt);
		temp_buf += 2;
		left_tlv_len -= (ETH_ALEN+2);
		if (sta_cnt > MAX_STA_SEEN) {
			err(DEBUG_CAT_TLVPRS, "stations are more than maximum\n");
			return -1;
		}
		for (i = 0; i < sta_cnt; i++) {
			if (left_tlv_len < (ETH_ALEN+2)) {
				err(DEBUG_CAT_TLVPRS, "length error\n");
				return -1;
			}
			temp_buf += ETH_ALEN;
			temp_buf += 2;
			left_tlv_len -= (ETH_ALEN+2);
		}
	}
	/*TODO do we need to parse this tlv further? */
	return (length + 3);
}

#ifdef MAP_R6

void mark_all_sta_mld_cnf_invalid(struct _1905_map_device *dev)
{
	struct mlo_sta_config_db *mld_sta_cfg = NULL, *tmld_sta_cfg = NULL;

	SLIST_FOREACH_SAFE(mld_sta_cfg, &dev->first_mld_sta_cnf_rpt, list, tmld_sta_cfg)
		mld_sta_cfg->is_present = 0;
}

struct mlo_sta_config_db *find_mld_cfg_by_mld(struct _1905_map_device *dev, unsigned char *sta_mld_mac)
{
	struct mlo_sta_config_db *mld_sta_cfg = NULL, *tmld_sta_cfg = NULL;

	SLIST_FOREACH_SAFE(mld_sta_cfg, &dev->first_mld_sta_cnf_rpt, list, tmld_sta_cfg) {
		if (!sta_mld_mac)
			return mld_sta_cfg;

		if (!os_memcmp(mld_sta_cfg->sta_mld_mac, sta_mld_mac, ETH_ALEN)) {
			info(DEBUG_CAT_TLVPRS, TOPO_PREX"found the mld_mac_cfg "MACSTR"\n", MAC2STR(sta_mld_mac));
			return mld_sta_cfg;
		}
	}
	return NULL;
}

/*caller of this will fill is_present bit.*/
struct mlo_sta_config_db *check_and_add_mld_cfg(struct _1905_map_device *dev, unsigned char *sta_mld_mac)
{
	struct mlo_sta_config_db *mld_sta_cfg = NULL;

	mld_sta_cfg = find_mld_cfg_by_mld(dev, sta_mld_mac);
	if (!mld_sta_cfg) {
		mld_sta_cfg = os_zalloc(sizeof(*mld_sta_cfg));

		os_memcpy(mld_sta_cfg->sta_mld_mac, sta_mld_mac, ETH_ALEN);

		SLIST_INSERT_HEAD(&dev->first_mld_sta_cnf_rpt, mld_sta_cfg, list);
	}
	return mld_sta_cfg;
}

void del_sta_mld(struct _1905_map_device *dev, struct mlo_sta_config_db *mld_sta_cfg)
{
	struct mlo_sta_db *mld_sta = NULL;

	if (!mld_sta_cfg)
		return;

	while (!SLIST_EMPTY(&(mld_sta_cfg->mlo_sta_list))) {
		mld_sta = SLIST_FIRST(&(mld_sta_cfg->mlo_sta_list));
		if (mld_sta->assoc_cli)
			mld_sta->assoc_cli->mld_sta_cfg = NULL;
		SLIST_REMOVE_HEAD(&mld_sta_cfg->mlo_sta_list, list);
		os_free(mld_sta);
	}
}

void del_sta_mld_cfg_invalid(struct _1905_map_device *dev)
{
	struct mlo_sta_config_db *mld_sta_cfg = NULL, *tmld_sta_cfg = NULL;

	if (SLIST_EMPTY(&(dev->first_mld_sta_cnf_rpt))) {
		info(DEBUG_CAT_TLVPRS, "mld_sta_cfg is empty\n");
		return;
	}

	mld_sta_cfg = SLIST_FIRST(&(dev->first_mld_sta_cnf_rpt));

	while (mld_sta_cfg) {
		tmld_sta_cfg = SLIST_NEXT(mld_sta_cfg, list);
		if (!mld_sta_cfg->is_present) {
			del_sta_mld(dev, mld_sta_cfg);
			SLIST_REMOVE(&(dev->first_mld_sta_cnf_rpt),
				     mld_sta_cfg,
				     mlo_sta_config_db,
				     list);
			os_free(mld_sta_cfg);
		}
		mld_sta_cfg = tmld_sta_cfg;
	}
}
void dump_mld_sta_cfg(struct _1905_map_device *dev)
{
	struct mlo_sta_config_db *mld_sta_cfg = NULL, *tmld_sta_cfg = NULL;
	struct mlo_sta_db *mld_sta = NULL, *tmld_sta = NULL;

	SLIST_FOREACH_SAFE(mld_sta_cfg, &dev->first_mld_sta_cnf_rpt, list, tmld_sta_cfg) {
		notice(DEBUG_CAT_TLVPRS, "mld_sta_cfg->is_present = %d", mld_sta_cfg->is_present);
		notice(DEBUG_CAT_TLVPRS, "mld_sta_cfg->sta_mld_mac " MACSTR, MAC2STR(mld_sta_cfg->sta_mld_mac));
		notice(DEBUG_CAT_TLVPRS, "mld_sta_cfg->ap_mld_mac " MACSTR, MAC2STR(mld_sta_cfg->ap_mld_mac));
		notice(DEBUG_CAT_TLVPRS, "mld_sta_cfg->num_affiliates_sta = %d", mld_sta_cfg->num_affiliates_sta);

		SLIST_FOREACH_SAFE(mld_sta, &(mld_sta_cfg->mlo_sta_list), list, tmld_sta) {
			notice(DEBUG_CAT_TLVPRS, "mld_sta->bssid " MACSTR, MAC2STR(mld_sta->bssid));
			notice(DEBUG_CAT_TLVPRS, "mld_sta->affiliated_sta_mac " MACSTR, MAC2STR(mld_sta->affiliated_sta_mac));
		}
	}
}

void clear_bw_phycap_setting(struct client *cli)
{
	int i;

	for (i = 0; i < IEEE_NUM_BANDS; i++) {
		cli->phy_capab.max_bw[i] = 0;
		cli->phy_capab.phy_mode[i] = 0;
		cli->phy_cap_known[i] = 0;
	}
	cli->known_bands = 0;
}

void update_cli_db_channel_band_from_assoc_sta_mld_helper(struct mapd_global *global,
	uint32_t client_id, struct bss_info_db *bss,
	struct own_1905_device *ctx,
	struct _1905_map_device *dev)
{
	struct client *cli;
	unsigned char band_idx = 0;

	if (client_id == (uint32_t)-1) {
		info(DEBUG_CAT_TLVPRS, "client id not found = %u", client_id);
		return;
	}

	info(DEBUG_CAT_TLVPRS, "bss->radio->channel[0] = %d", bss->radio->channel[0]);
	info(DEBUG_CAT_TLVPRS, "bss->radio->band = %d", bss->radio->band);
	client_db_set_curr_channel(global, client_id, bss->radio->channel[0]);
	client_db_set_curr_band(global, client_id, bss->radio->band);
	cli = client_db_get_client_from_client_id(global, client_id);
	//clear_bw_phycap_setting(cli);
	if (!cli) {
		err(DEBUG_CAT_TLVPRS, "cli is null");
		return;
	}

	if (os_memcmp(ctx->al_mac, dev->_1905_info.al_mac_addr, ETH_ALEN))
		cli->radio_idx = get_radio_idx_by_band(bss->radio->band, ctx);

	info(DEBUG_CAT_TLVPRS, "cli MAC = "MACSTR " cli->radio_idx = %d", MAC2STR(cli->mac_addr), cli->radio_idx);

	if (IS_BAND_24G(bss->radio->band))
		band_idx = BAND_2G_IDX;
	else if (IS_BAND_5G(bss->radio->band))
		band_idx = BAND_5G_IDX;
	else
		band_idx = BAND_6G_IDX;
	info(DEBUG_CAT_TLVPRS, "cli->mlo_setup_link = %d\n", cli->mlo_setup_link);
	info(DEBUG_CAT_TLVPRS, "cli->mld_sta_profile_len = %d\n", cli->mld_sta_profile_len);
	debug_hexdump(DEBUG_CAT_TLVPRS, "sta profile dump1\n", (char *)cli->mld_sta_profile,
		cli->mld_sta_profile_len);
	if (!cli->mlo_setup_link) {
		client_db_update_cli_ht_vht_cap(global, client_id, (u8 *)cli->mld_sta_profile,
		cli->mld_sta_profile_len, band_idx);
		topo_srv_update_mld_clients(global, cli);
	} else {
		if (cli->is_assoc_reassoc == REASSOC_REQ_TYPE)
			client_db_update_cli_ht_vht_cap(global, client_id, (u8 *)cli->assoc_req_ie + 10,
			cli->assoc_req_ie_len - 10, band_idx);
		else if (cli->is_assoc_reassoc == ASSOC_REQ_TYPE)
			client_db_update_cli_ht_vht_cap(global, client_id, (u8 *)cli->assoc_req_ie + 4,
			cli->assoc_req_ie_len - 4, band_idx);
		topo_srv_update_mld_clients(global, cli);
	}
}

void update_cli_db_channel_band_from_assoc_sta_mld(struct own_1905_device *ctx,
	struct _1905_map_device *dev)
{
	struct mlo_sta_config_db *mld_sta_cfg, *tmld_sta_cfg;
	struct mlo_sta_db *mld_sta, *tmld_sta;
	struct client *cli;
	uint32_t client_id;
	struct mapd_global *global;
	struct _1905_map_device *_1905_dev;
	struct bss_info_db *bss;

	if (SLIST_EMPTY(&(dev->first_mld_sta_cnf_rpt))) {
		info(DEBUG_CAT_TLVPRS, "mld_sta_cfg is not present "MACSTR"\n", MAC2STR(dev->_1905_info.al_mac_addr));
		return;
	}
	info(DEBUG_CAT_TLVPRS, "first_mld_sta_cnf_rpt present for "MACSTR"\n", MAC2STR(dev->_1905_info.al_mac_addr));

	global = (struct mapd_global *)ctx->back_ptr;
	_1905_dev = topo_srv_get_1905_device(&global->dev, dev->_1905_info.al_mac_addr);

	mld_sta_cfg = SLIST_FIRST(&(dev->first_mld_sta_cnf_rpt));
	while (mld_sta_cfg) {
		tmld_sta_cfg = SLIST_NEXT(mld_sta_cfg, list);
		mld_sta = SLIST_FIRST(&(mld_sta_cfg->mlo_sta_list));
		while (mld_sta) {
			tmld_sta = SLIST_NEXT(mld_sta, list);
			client_id = client_db_get_cid_from_mac(global, mld_sta->affiliated_sta_mac);
			if (client_id != (uint32_t)-1) {
				cli = client_db_get_client_from_client_id(global, client_id);
				if (cli) {
					info(DEBUG_CAT_TLVPRS, "clear phy cap setting for client id = %u", cli->client_id);
					clear_bw_phycap_setting(cli);
				} else {
					err(DEBUG_CAT_TLVPRS, "cli is null no calling phycap setting");
				}
			}
			mld_sta = tmld_sta;
		}
		mld_sta_cfg = tmld_sta_cfg;
	}

	mld_sta_cfg = SLIST_FIRST(&(dev->first_mld_sta_cnf_rpt));

	while (mld_sta_cfg) {
		tmld_sta_cfg = SLIST_NEXT(mld_sta_cfg, list);
		mld_sta = SLIST_FIRST(&(mld_sta_cfg->mlo_sta_list));
		while (mld_sta) {
			tmld_sta = SLIST_NEXT(mld_sta, list);
			bss = topo_srv_get_bss(_1905_dev, (char *)mld_sta->bssid);
			if (bss) {
				if (!bss->radio) {
					err(DEBUG_CAT_TLVPRS, "bss radio is null\n");
					return;
				}
				client_id = client_db_get_cid_from_mac(global, mld_sta->affiliated_sta_mac);
				update_cli_db_channel_band_from_assoc_sta_mld_helper(global, client_id, bss, ctx, dev);
			}
			mld_sta = tmld_sta;
		}
		mld_sta_cfg = tmld_sta_cfg;
	}
}

void clear_unused_client_based_on_assoc_sta_mld(struct own_1905_device *ctx,
	struct _1905_map_device *dev)
{
	struct mlo_sta_config_db *mld_sta_cfg, *tmld_sta_cfg;
	struct mlo_sta_db *mld_sta, *tmld_sta;
	struct client *cli;
	struct mapd_global *global;

	global = (struct mapd_global *)ctx->back_ptr;
	mld_sta_cfg = SLIST_FIRST(&(dev->first_mld_sta_cnf_rpt));
	info(DEBUG_CAT_TLVPRS, "enter -->");
	while (mld_sta_cfg) {
		tmld_sta_cfg = SLIST_NEXT(mld_sta_cfg, list);
		mld_sta = SLIST_FIRST(&(mld_sta_cfg->mlo_sta_list));
		while (mld_sta) {
			tmld_sta = SLIST_NEXT(mld_sta, list);
			cli = get_client_from_sta_mac_r6(ctx, mld_sta->affiliated_sta_mac);
			if (cli)
				info(DEBUG_CAT_TLVPRS, "client found client id = %u", cli->client_id);
			if (cli && is_zero_ether_addr(cli->mld_addr)) {
				info(DEBUG_CAT_TLVPRS, "client found need to deinit this client id = %u", cli->client_id);
				info(DEBUG_CAT_TLVPRS, "client mac = " MACSTR, MAC2STR(cli->mac_addr));
				remove_steer_candidate_list(global, cli);
				cancel_steer_timer(global, cli);
				client_db_deinit_client(global, cli);
				client_db_init_client(cli);
			}
			mld_sta = tmld_sta;
		}
		mld_sta_cfg = tmld_sta_cfg;
	}
}
void update_cli_db_mac_from_assoc_sta_mld(struct own_1905_device *ctx,
	struct _1905_map_device *dev)
{
	struct mlo_sta_config_db *mld_sta_cfg, *tmld_sta_cfg;
	struct mlo_sta_db *mld_sta, *tmld_sta;
	struct client *cli = NULL;
	struct client *cli1 = NULL;

	if (SLIST_EMPTY(&(dev->first_mld_sta_cnf_rpt))) {
		info(DEBUG_CAT_TLVPRS, "mld_sta_cfg is not present "MACSTR"\n", MAC2STR(dev->_1905_info.al_mac_addr));
		return;
	}

	info(DEBUG_CAT_TLVPRS, "first_mld_sta_cnf_rpt present for "MACSTR"\n", MAC2STR(dev->_1905_info.al_mac_addr));
	// clear if any existing client present with affiliated mac
	clear_unused_client_based_on_assoc_sta_mld(ctx, dev);
	mld_sta_cfg = SLIST_FIRST(&(dev->first_mld_sta_cnf_rpt));
	while (mld_sta_cfg) {
		tmld_sta_cfg = SLIST_NEXT(mld_sta_cfg, list);
		cli = get_client_from_sta_mac_r6(ctx, mld_sta_cfg->sta_mld_mac);
		if (!cli) {
			info(DEBUG_CAT_TLVPRS, "client not found for sta mld mac " MACSTR"\n", MAC2STR(mld_sta_cfg->sta_mld_mac));
			mld_sta_cfg = tmld_sta_cfg;
			continue;
		}
		info(DEBUG_CAT_TLVPRS, "cli mac = "MACSTR, MAC2STR(cli->mac_addr));
		if (!cli->mlo_setup_link) {
			info(DEBUG_CAT_TLVPRS, "client found but not setup link client id = %u cli mac = " MACSTR"\n",
			 cli->client_id, MAC2STR(cli->mac_addr));
			mld_sta_cfg = tmld_sta_cfg;
			cli = NULL;
			continue;
		}
		info(DEBUG_CAT_TLVPRS, "cli_id = %u found for mld_sta_cfg->sta_mld_mac " MACSTR"\n",
		 cli->client_id, MAC2STR(mld_sta_cfg->sta_mld_mac));
		break;
	}
	if (!cli) {
		info(DEBUG_CAT_TLVPRS, "return client not found\n");
		return;
	}
	mld_sta = SLIST_FIRST(&(mld_sta_cfg->mlo_sta_list));
	while (mld_sta) {
		tmld_sta = SLIST_NEXT(mld_sta, list);
		cli1 = get_client_from_sta_mac_r6(ctx, mld_sta->affiliated_sta_mac);
		if (!cli1) {
			info(DEBUG_CAT_TLVPRS, "client not found for mld_sta->affiliated_sta_mac " MACSTR"\n",
			 MAC2STR(mld_sta->affiliated_sta_mac));
			info(DEBUG_CAT_TLVPRS, "before cli->mac_addr = " MACSTR"\n", MAC2STR(cli->mac_addr));
			os_memcpy(cli->mac_addr, mld_sta->affiliated_sta_mac, ETH_ALEN);
			info(DEBUG_CAT_TLVPRS, "after cli->mac_addr = " MACSTR"\n", MAC2STR(cli->mac_addr));
			break;
		}
		info(DEBUG_CAT_TLVPRS, "client id = %u found for mld_sta->affiliated_sta_mac " MACSTR"\n",
		 cli1->client_id, MAC2STR(mld_sta->affiliated_sta_mac));
		mld_sta = tmld_sta;
	}
}


int parse_assoc_sta_mld_cnf_rpt_tlv(struct own_1905_device *ctx, unsigned char *buf,
				    struct _1905_map_device *dev)
{
	unsigned char *temp_buf;
	int length = 0;
	u16 sta_af_cnt = 0, i = 0;
	u8 *sta_mld_mac = NULL;
	struct mlo_sta_config_db *mld_sta_cfg = NULL;
	struct mlo_sta_db *mld_sta = NULL, *tmld_sta = NULL;
	struct mlo_sta_db *new_mld_sta = NULL, *prev_mld_sta = NULL;

	temp_buf = buf;

	if ((*temp_buf) == ASSOCIATED_STA_MLD_CONFIG_REPORT_TLV_TYPE)
		temp_buf++;
	else
		return -1;

	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length | (*(temp_buf + 1));
	temp_buf += 2;

	sta_mld_mac = temp_buf;
	mld_sta_cfg = check_and_add_mld_cfg(dev, temp_buf);

	os_memcpy(mld_sta_cfg->sta_mld_mac, temp_buf, ETH_ALEN);
	temp_buf += ETH_ALEN;

	os_memcpy(mld_sta_cfg->ap_mld_mac, temp_buf, ETH_ALEN);
	temp_buf += ETH_ALEN;

	/* one byte for
	 * STR          bit 7
	 * NSTR         bit 6
	 * EMLSR        bit 5
	 * EMLMR        bit 4
	 */

	mld_sta_cfg->str_support = *temp_buf & 0x80;
	mld_sta_cfg->nstr_support = *temp_buf & 0x40;
	mld_sta_cfg->emlsr_support = *temp_buf & 0x20;
	mld_sta_cfg->emlmr_support = *temp_buf & 0x10;

	temp_buf++;

	/*rsvd 18 bytes*/
	temp_buf += 18;

	mld_sta_cfg->num_affiliates_sta = *temp_buf;
	sta_af_cnt = *temp_buf;

	temp_buf++;

	mld_sta_cfg->is_present = 1;

	del_sta_mld(dev, mld_sta_cfg);

	if (SLIST_EMPTY(&(mld_sta_cfg->mlo_sta_list)))
		SLIST_INIT(&mld_sta_cfg->mlo_sta_list);

	for (i = 0; i < sta_af_cnt; i++) {
		new_mld_sta = os_zalloc(sizeof(*new_mld_sta));

		os_memcpy(new_mld_sta->bssid, temp_buf, ETH_ALEN);
		temp_buf += ETH_ALEN;

		os_memcpy(new_mld_sta->affiliated_sta_mac, temp_buf, ETH_ALEN);
		temp_buf += ETH_ALEN;

		/*rsvd 19 bytes*/
		temp_buf += 19;

		SLIST_FOREACH_SAFE(mld_sta, &(mld_sta_cfg->mlo_sta_list), list, tmld_sta)
			prev_mld_sta = mld_sta;

		if (prev_mld_sta) {
			info(DEBUG_CAT_TLVPRS, "add after existing mld_cfg "MACSTR, MAC2STR(new_mld_sta->affiliated_sta_mac));
			SLIST_INSERT_AFTER(prev_mld_sta, new_mld_sta, list);
		} else {
			info(DEBUG_CAT_TLVPRS, "Insert into head "MACSTR, MAC2STR(new_mld_sta->affiliated_sta_mac));
			SLIST_INSERT_HEAD(&(mld_sta_cfg->mlo_sta_list),
					  new_mld_sta, list);
		}
	}

	//dump_mld_sta_cfg(dev);
	update_cli_db_mac_from_assoc_sta_mld(ctx, dev);
	update_cli_db_channel_band_from_assoc_sta_mld(ctx, dev);
	/*TODO do we need to parse this tlv further? */
	return (length + 3);
}

#endif

/**
* @brief Fn to parse ap associated clients tlv
*
* @param ctx own 1905 device ctx
* @param buf msg buffer
* @param dev 1905 map device
*
* @return -1 if error else tlv length
*/
int parse_ap_associated_clients_type_tlv(struct own_1905_device *ctx, unsigned char *buf,
		struct _1905_map_device *dev, char *list_bss, int bss_count)
{
	unsigned char *temp_buf;
	int length = 0;
	u8 bss_cnt = 0, j = 0;
	u16 sta_cnt = 0, i = 0;
	u8 *bssid = NULL;
	struct associated_clients *assoc_client = NULL;
	struct bss_info_db *bss = NULL;
#ifdef MAP_6E_SUPPORT
	unsigned char mac_addr[ETH_ALEN] = {0};
#endif
	u8 new_client = 0;
	struct os_reltime assoc_time = { 0 };

	temp_buf = buf;

	if ((*temp_buf) == AP_ASSOCIATED_CLIENTS_TYPE)
		temp_buf++;
	else {
		return -1;
	}

	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length | (*(temp_buf + 1));
	temp_buf += 2;

	bss_cnt = *temp_buf;
	temp_buf++;
	for (j = 0; j < bss_cnt; j++) {
		bssid = temp_buf;
		temp_buf += ETH_ALEN;

		if (!check_bssid_oper_bss_list(list_bss, bss_count, bssid))
			continue;

		bss = topo_srv_get_bss_by_bssid(ctx, dev, bssid);
		if (!bss) {
			bss = os_malloc(sizeof(*bss));
			if (!bss) {
				err(DEBUG_CAT_TLVPRS, TOPO_PREX"alloc memory fail for bss for dev"MACSTR"\n",
					MAC2STR(dev->_1905_info.al_mac_addr));
				return -1;
			}
			os_memset(bss, 0, sizeof(*bss));
			SLIST_INIT(&bss->esp_head);
			memcpy(bss->bssid, bssid, ETH_ALEN);
			SLIST_INSERT_HEAD(&dev->first_bss, bss, next_bss);
#ifdef ACL_CTRL
			dl_list_init(&bss->acl_cli_list);
#endif
			bss->valid = TRUE;
		}
		sta_cnt = *((u16*)temp_buf);
		sta_cnt = be_to_host16(sta_cnt);
		temp_buf += 2;
		bss->assoc_sta_cnt = sta_cnt;
		if (sta_cnt > MAX_STA_CONNECT_LIMIT) {
			err(DEBUG_CAT_TLVPRS, "Station count exceeded max Connect limit\n");
			continue;
		}
		for (i = 0; i < sta_cnt; i++) {
#ifdef MAP_6E_SUPPORT
			os_memcpy(mac_addr, temp_buf, ETH_ALEN);
			assoc_client = topo_srv_get_associate_client(ctx, dev, mac_addr);
			if (assoc_client) {
				assoc_client->bss = bss;
				temp_buf += ETH_ALEN;
				assoc_client->last_assoc_time = *((u16 *)temp_buf);
				assoc_client->last_assoc_time = be_to_host16(assoc_client->last_assoc_time);
				if (!assoc_client->assoc_time) {
					os_get_reltime(&assoc_time);
					assoc_client->assoc_time = assoc_time.sec;
				}
				assoc_client->is_bh_link = 0;
				assoc_client->is_APCLI = 0;
				assoc_client->entry_valid = TRUE;
				temp_buf += 2;
			} else
#endif
			{
				assoc_client = (struct associated_clients *)os_zalloc(sizeof(struct associated_clients));
				if (assoc_client == NULL) {
					err(DEBUG_CAT_TLVPRS, TOPO_PREX"Memory allocation error\n");
					return -1;
				}
				assoc_client->bss = bss;
				os_memcpy(assoc_client->client_addr, temp_buf, ETH_ALEN);
				temp_buf += ETH_ALEN;
				assoc_client->last_assoc_time = *((u16 *)temp_buf);
				assoc_client->last_assoc_time = be_to_host16(assoc_client->last_assoc_time);
				if (!assoc_client->assoc_time) {
					os_get_reltime(&assoc_time);
					assoc_client->assoc_time = assoc_time.sec;
				}
				assoc_client->is_bh_link = 0;
				assoc_client->is_APCLI = 0;
				temp_buf += 2;
#ifdef MAP_6E_SUPPORT
				assoc_client->entry_valid = TRUE;
#endif
				if (dev) {
					SLIST_INSERT_HEAD(&dev->assoc_clients, assoc_client, next_client);
					new_client = 1;
				} else {
					if (assoc_client) {
						os_free(assoc_client);
						assoc_client = NULL;
					}
				}
			}
#ifdef CENT_STR
			if (ctx->cent_str_en && ctx->device_role == DEVICE_ROLE_CONTROLLER && assoc_client) {
				struct mapd_global *global = (struct mapd_global *)ctx->back_ptr;
				struct client *cli = client_db_get_client_from_sta_mac(global, assoc_client->client_addr);

#ifdef MAP_R6
				if (!cli) {
					err(DEBUG_CAT_TLVPRS, TOPO_PREX"cli is NULL try by using mld mac");
					cli = client_db_get_client_from_mld_mac(global, assoc_client->client_addr);
					if (!cli)
						err(DEBUG_CAT_TLVPRS, TOPO_PREX"cli is NULL not found by mld mac");
				}
#endif /* MAP_R6 */

#ifdef MTK_MLO_MAP_SUPPORT
				if (cli && cli->mlo_enable) {
					assoc_client->mld_enable = cli->mlo_enable;
					assoc_client->link_id = cli->link_id;
					os_memcpy(assoc_client->mld_addr, cli->mld_addr, ETH_ALEN);
				}
#endif
				if (cli) {
					info(DEBUG_CAT_TLVPRS, TOPO_PREX"cli = " MACSTR, MAC2STR(cli->mac_addr));
#ifdef MAP_R6
					info(DEBUG_CAT_TLVPRS, TOPO_PREX"client id = %u", cli->client_id);
					info(DEBUG_CAT_TLVPRS, TOPO_PREX"cli->mlo_enable = %d", cli->mlo_enable);
#endif /* MAP_R6 */
				}
				if ((cli && (os_memcmp(cli->bssid, ZERO_MAC_ADDR, ETH_ALEN) == 0)) || (cli == NULL && new_client == 1)) {
					info(DEBUG_CAT_TLVPRS, "going to call client capability bssid = " MACSTR, MAC2STR(bssid));
					info(DEBUG_CAT_TLVPRS, "assoc_client->client_addr = " MACSTR, MAC2STR(assoc_client->client_addr));
					map_1905_Send_Client_Capability_Query_Message(global->_1905_ctrl,
								(char *)dev->_1905_info.al_mac_addr,
								bssid, assoc_client->client_addr);
				}
			}
#endif
			new_client = 0;
		}
	}
	/*TODO do we need to parse this tlv further? */
	return (length + 3);
}

/**
* @brief Fn to parse radio basic caps tlv
*
* @param buf msg buffer
* @param identifier radio identifier
* @param max_bss_num max bss number count
* @param band_cap band caps
*
* @return -1 if error else tlv length
*/
int parse_ap_radio_basic_cap_tlv(unsigned char *buf,
		unsigned char *identifier,
		unsigned char *max_bss_num,
		unsigned char *band_cap)
{
	unsigned char *temp_buf = NULL;
	unsigned short length = 0;
	unsigned char opnum = 0, i = 0, non_opch_num = 0;
	unsigned char opclass = 0;
	unsigned char cap = 0;

	temp_buf = buf;

	if ((*temp_buf) == AP_RADIO_BASIC_CAPABILITY_TYPE)
		temp_buf++;
	else
		return -1;

	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length | (*(temp_buf + 1));
	temp_buf += 2;

	/*here only parse identifier of ap_radio_basic_cap_tlv */
	memcpy(identifier, temp_buf, 6);
	temp_buf += 6;
	*max_bss_num = *temp_buf++;
	/*Number of operating classes */
	opnum = *temp_buf++;
	*band_cap = 0;
	for (i = 0; i < opnum; i++) {
		opclass = *temp_buf;
		temp_buf += 2;
		non_opch_num = *temp_buf++;
		cap = get_bandcap(opclass, non_opch_num, temp_buf);
		*band_cap |= cap;
		temp_buf += non_opch_num;
	}
	debug(DEBUG_CAT_TLVPRS, "this m1 bandcap=%d\n", *band_cap);

	debug(DEBUG_CAT_TLVPRS, "radio_id("MACSTR")\n",
			MAC2STR(identifier));

	return (length + 3);
}

/**
* @brief Fn to parse backhaul steer request msg
*
* @param ctx own 1905 device ctx
* @param buf msg buffer
*
* @return 0 if success else -1
*/
int parse_backhaul_steering_request_message(struct own_1905_device *ctx,
		unsigned char *buf, unsigned short len)
{
	int length = 0;
	unsigned char *temp_buf;
	unsigned char integrity = 0;
	unsigned short check_len = 0;
	unsigned short tlv_len = 0;

	temp_buf = buf;

	while (1) {
		check_len = get_tlv_len(temp_buf);
		tlv_len = check_len + 3;

		if (len < tlv_len) {
			err(DEBUG_CAT_TLVPRS, "Error TLV len, type = %d, len %d less than tlv_len %d\n",
				*temp_buf, len, tlv_len);
			return -1;
		}

		if (*temp_buf == BACKHAUL_STEERING_REQUEST_TYPE) {
			integrity |= 0x1;
			length =
				parse_backhaul_steering_request_tlv(temp_buf, ctx);
			if (length < 0) {
				err(DEBUG_CAT_TLVPRS, "error backhaul steering request tlv\n");
				return -1;
			}
			temp_buf += length;
		} else if (*temp_buf == END_OF_TLV_TYPE) {
			break;
		} else {
			length = get_cmdu_tlv_length(temp_buf);
			temp_buf += length;
		}
		len -= tlv_len;
	}
	/*check integrity */
	if (integrity != 0x1) {
		err(DEBUG_CAT_TLVPRS, "no backhaul steering request tlv\n");
		return -1;
	}

	return 0;
}

int topo_srv_update_neighbor_entry(struct own_1905_device *ctx,
	struct map_neighbor_info *neighbor, unsigned char *local_mac, struct _1905_map_device *dev, unsigned char *al_mac, char skip)
{
	struct backhaul_link_info *bh = NULL, *tbh = NULL;
	unsigned char zero_mac[ETH_ALEN] = {0};
	struct iface_info *niface = NULL, *ciface = NULL;
	struct iface_info *iface = NULL;
	struct _1905_map_device *own_dev = topo_srv_get_1905_device(ctx, NULL);

	//Remove entry from client DB
	uint32_t client_id;
	u8 already_seen = 2;
	struct mapd_global *mapd_ctx = (struct mapd_global *)ctx->back_ptr;

	SLIST_FOREACH_SAFE(bh, &neighbor->bh_head, next_bh, tbh)
	{
		if (!os_memcmp(bh->connected_iface_addr, local_mac, ETH_ALEN)) {
			bh->is_valid = 1;
			if (os_memcmp(zero_mac, bh->neighbor_iface_addr, ETH_ALEN)) {
#ifdef EM_PLUS_SUPPORT
				struct client *cli = NULL;

				cli = get_client_from_sta_mac(ctx, bh->neighbor_iface_addr);
				if (cli && cli->bcn_query) {
					info(DEBUG_CAT_TLVPRS, "bh sta is still in mutil beacon query flow" MACSTR
					"\n", MAC2STR(bh->neighbor_iface_addr));
					return 0;
				}
#endif
				client_id = client_db_track_add(mapd_ctx, bh->neighbor_iface_addr, &already_seen);
				if (client_id == (uint32_t)-1) {
					err(DEBUG_CAT_TLVPRS, "No more room to accommodate " MACSTR
					", that has joined a BSS on another device\n", MAC2STR(bh->neighbor_iface_addr));
				}
			}
			return 0;
		}
	}

	ciface = topo_srv_find_iface_by_mac(ctx, local_mac);
	if (!ciface) {
		err(DEBUG_CAT_TLVPRS, TOPO_PREX"err! ciface("MACSTR") not belongs to MAP dev\n",
			MAC2STR(local_mac));
		return -1;
	}

	if (os_memcmp(own_dev->_1905_info.al_mac_addr, al_mac, ETH_ALEN) &&
			os_memcmp(own_dev->_1905_info.al_mac_addr, dev->_1905_info.al_mac_addr, ETH_ALEN)) {
			skip = 1;
	}

	if (skip == 1) {
		tbh = NULL;
		SLIST_FOREACH_SAFE(bh, &neighbor->bh_head, next_bh, tbh)
		{
			/*check if need update connected_iface_addr of exist link  */
			if (os_memcmp(bh->neighbor_iface_addr, zero_mac, ETH_ALEN)) {
				niface = topo_srv_find_iface_by_mac(ctx, bh->neighbor_iface_addr);
				if (!niface) {
					err(DEBUG_CAT_TLVPRS, TOPO_PREX"err! niface("MACSTR") not belongs to MAP dev\n",
						MAC2STR(bh->neighbor_iface_addr));
					return -1;
				}

				if ((niface->media_type >= IEEE802_11_GROUP) && (ciface->media_type >= IEEE802_11_GROUP)) {
					os_memcpy(bh->connected_iface_addr, local_mac, ETH_ALEN);
					bh->is_valid = 1;
					notice(DEBUG_CAT_TLVPRS, TOPO_PREX"conn_iface set!!! niface("MACSTR
					") ciface-apcli("MACSTR") dev("MACSTR")\n",
						MAC2STR(niface->iface_addr), MAC2STR(local_mac), MAC2STR(neighbor->n_almac));
					break;
				/*if neighbor interface and local_mac is eth interface*/
				} else if (niface->media_type < ieee_802_11_b) {
					if (ciface->media_type < ieee_802_11_b) {
						os_memcpy(bh->connected_iface_addr, local_mac, ETH_ALEN);
						bh->is_valid = 1;
						notice(DEBUG_CAT_TLVPRS, TOPO_PREX"conn_iface set!!! niface("MACSTR") ciface-eth("
						MACSTR") dev("MACSTR")\n",
							MAC2STR(niface->iface_addr), MAC2STR(local_mac), MAC2STR(neighbor->n_almac));
						break;
					}
				}
				/* MAP R2 cert iot: bring eth interface(media type = IEEE802_3_GROUP) when wifi on boarding */
#ifndef EM_PLUS_EXT_SUPPORT
				if (mapd_ctx->params.Certification)
#endif
				{
					os_memcpy(bh->connected_iface_addr, local_mac, ETH_ALEN);
					bh->is_valid = 1;
					notice(DEBUG_CAT_TLVPRS, TOPO_PREX"Cert: conn_iface set!!! niface("MACSTR") ciface-apcli("
					MACSTR") dev("MACSTR")\n",
						MAC2STR(niface->iface_addr), MAC2STR(local_mac), MAC2STR(neighbor->n_almac));
					break;
				}
			}
		}
	} else if (!bh && !skip) {
		bh = os_zalloc(sizeof(struct backhaul_link_info));
		if (!bh) {
			err(DEBUG_CAT_TLVPRS, TOPO_PREX"failed to allocate memory for bh info\n");
			assert(0);
			return -1;
		}
		bh->is_valid = 1;
		SLIST_INSERT_HEAD(&neighbor->bh_head, bh, next_bh);
		os_memcpy(bh->connected_iface_addr, local_mac, ETH_ALEN);
		neighbor->insert_new_link = 1;
		notice(DEBUG_CAT_TLVPRS, TOPO_PREX"create bh link!!! niface(NULL) ciface("MACSTR") dev("MACSTR")\n",
			MAC2STR(local_mac), MAC2STR(neighbor->n_almac));

		if (neighbor->parent) {
			iface = topo_srv_get_iface(neighbor->parent, local_mac);
			if (iface && iface->media_type < IEEE802_11_GROUP) {
				neighbor->insert_new_link = 2;
			} else if (iface && iface->media_type >= IEEE802_11_GROUP) {
				neighbor->insert_new_link = 3;
			}
		}
	}

	if (bh) {
		client_id = client_db_track_add(mapd_ctx, bh->neighbor_iface_addr, &already_seen);
		if (client_id == (uint32_t)-1) {
			err(DEBUG_CAT_TLVPRS, "No more room to accommodate" MACSTR
						", that has joined a BSS on another device\n", MAC2STR(bh->neighbor_iface_addr));
		}
	}

	return 0;
}
#ifdef MAP_R2
int parse_unsuccessful_association_policy_tlv(unsigned char *buf,
		struct own_1905_device *ctx)
{
	unsigned char *temp_buf;
	unsigned short length = 0/*, i =0*/;
	struct unsuccessful_association_policy *assoc_failed_policy = &ctx->map_policy.assoc_failed_policy;
	temp_buf = buf;
	int report_rate = 0;

	if((*temp_buf) == UNSUCCESSFUL_ASSOCIATION_POLICY_TYPE) {
		temp_buf++;
	}
	else {
		err(DEBUG_CAT_TLVPRS, TOPO_PREX"should not go here\n");
		return -1;
	}

	//calculate tlv length
	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length |(*(temp_buf+1));

	//shift to tlv value field
	temp_buf += 2;

	//assoc_failed_policy = (struct unsuccessful_association_policy *)os_malloc(sizeof(struct unsuccessful_association_policy));
	//if (!assoc_failed_policy) {
		//err(DEBUG_CAT_TLVPRS, "alloc struct unsuccessful_association_policy fail");
	//	return -1;
	//}
	if (*temp_buf & 0x80)
		assoc_failed_policy->report_unsuccessful_association = 1;
	else
		assoc_failed_policy->report_unsuccessful_association = 0;
	temp_buf += 1;
	//assoc_failed_policy->max_supporting_rate = *temp_buf;
	report_rate = (*((unsigned int *)temp_buf));

	assoc_failed_policy->max_supporting_rate = host_to_be32(report_rate);
	temp_buf += 4;

	debug(DEBUG_CAT_TLVPRS, TOPO_PREX"supporting rate = %d\n",
	 ctx->map_policy.assoc_failed_policy.max_supporting_rate);
	return length+3;
}
int parse_map_version_tlv(unsigned char *buf,
	unsigned char *almac, unsigned char *profile)
{
	unsigned char *temp_buf = NULL;
	unsigned char *check_buf = NULL;
	unsigned short length = 0;

	temp_buf = buf;
	check_buf = buf;

	if((*temp_buf) == MULTI_AP_VERSION_TYPE) {
		temp_buf++;
	}
	else {
		return -1;
	}
	//calculate tlv length
	length = *(unsigned short *)temp_buf;
	length = be_to_host16(length);

	if (!check_fixed_length_tlv(MULTI_AP_VERSION_TYPE_LEN, check_buf, length)) {
		err(DEBUG_CAT_TLVPRS, "error MULTI_AP_VERSION_TYPE_LEN length is %d incorrect\n", length);
		return -1;
	}

	//shift to tlv value field
	temp_buf += 2;
	*profile = *temp_buf;

	debug(DEBUG_CAT_TLVPRS, TOPO_PREX"peer("MACSTR") multi-ap profile=%02x\n",
		MAC2STR(almac), *profile);

	return (length+3);
}

#endif

int topo_srv_update_neighbor_entry_peer(struct own_1905_device *ctx,
	struct map_neighbor_info *neighbor, unsigned char *local_mac, struct _1905_map_device *dev, unsigned char *al_mac, char skip)
{
	struct backhaul_link_info *bh = NULL, *tbh = NULL;
	unsigned char zero_mac[ETH_ALEN] = {0};
	struct iface_info *niface = NULL, *ciface = NULL;
	struct _1905_map_device *own_dev = topo_srv_get_1905_device(ctx, NULL);
#ifndef EM_PLUS_EXT_SUPPORT
	struct mapd_global *mapd_ctx = (struct mapd_global *)ctx->back_ptr;
#endif
	SLIST_FOREACH_SAFE(bh, &neighbor->bh_head, next_bh, tbh)
	{
		if (!os_memcmp(bh->neighbor_iface_addr, local_mac, ETH_ALEN))
			return 0;
	}

	niface = topo_srv_find_iface_by_mac(ctx, local_mac);
	if (!niface) {
		err(DEBUG_CAT_TLVPRS, TOPO_PREX"err! niface("MACSTR") not belongs to MAP dev\n",
			MAC2STR(local_mac));
		return -1;
	}

	if (os_memcmp(own_dev->_1905_info.al_mac_addr, al_mac, ETH_ALEN) &&
			os_memcmp(own_dev->_1905_info.al_mac_addr, dev->_1905_info.al_mac_addr, ETH_ALEN)) {
			skip = 1;
	}
	if (skip == 1) {
		tbh = NULL;
		SLIST_FOREACH_SAFE(bh, &neighbor->bh_head, next_bh, tbh)
		{
			/*check if need update neighbor_iface_addr of exist link  */
			if (os_memcmp(bh->connected_iface_addr, zero_mac, ETH_ALEN)) {
				ciface = topo_srv_find_iface_by_mac(ctx, bh->connected_iface_addr);
				if (!ciface) {
					err(DEBUG_CAT_TLVPRS, TOPO_PREX"err! ciface("MACSTR") not belongs to MAP dev\n",
						MAC2STR(bh->connected_iface_addr));
					return -1;
				}
				if ((ciface->media_type >= IEEE802_11_GROUP) && (niface->media_type >= IEEE802_11_GROUP)) {
					os_memcpy(bh->neighbor_iface_addr, local_mac, ETH_ALEN);
					notice(DEBUG_CAT_TLVPRS, TOPO_PREX"neighbor_iface set!!! niface("MACSTR") ciface("
					MACSTR") dev("MACSTR")\n",
						MAC2STR(local_mac), MAC2STR(ciface->iface_addr), MAC2STR(neighbor->n_almac));
					break;
				/*if connected interface and local_mac is eth interface*/
				} else if (ciface->media_type < ieee_802_11_b) {
					if (niface->media_type < ieee_802_11_b) {
						os_memcpy(bh->neighbor_iface_addr, local_mac, ETH_ALEN);
						notice(DEBUG_CAT_TLVPRS, TOPO_PREX"neighbor_iface set!!! niface-eth("MACSTR") ciface("
						MACSTR") dev("MACSTR")\n",
							MAC2STR(local_mac), MAC2STR(ciface->iface_addr), MAC2STR(neighbor->n_almac));
						break;
					}
				}

				/* MAP R2 Cert iot: bring eth interface(media type = IEEE802_3_GROUP) when wifi on boarding */
#ifndef EM_PLUS_EXT_SUPPORT
				if (mapd_ctx->params.Certification)
#endif
				{
					os_memcpy(bh->neighbor_iface_addr, local_mac, ETH_ALEN);
					err(DEBUG_CAT_TLVPRS, TOPO_PREX"Cert: neighbor_iface set!!! niface-eth("MACSTR") ciface("
					MACSTR") dev("MACSTR")\n",
						MAC2STR(local_mac), MAC2STR(ciface->iface_addr), MAC2STR(neighbor->n_almac));
					break;
				}
			}
		}
	} else if (!bh && !skip) {
		bh = os_zalloc(sizeof(struct backhaul_link_info));
		if (!bh) {
			err(DEBUG_CAT_TLVPRS, TOPO_PREX"failed to allocate memory for bh info\n");
			assert(0);
			return -1;
		}
		bh->is_valid = 1;
		SLIST_INSERT_HEAD(&neighbor->bh_head, bh, next_bh);
		os_memcpy(bh->neighbor_iface_addr, local_mac, ETH_ALEN);
		neighbor->insert_new_link = 1;
		notice(DEBUG_CAT_TLVPRS, TOPO_PREX"create bh link!!! niface("MACSTR") ciface(NULL) dev("MACSTR")\n",
			MAC2STR(local_mac), MAC2STR(neighbor->n_almac));
	}

	return 0;
}
int parse_backhaul_steering_rsp_tlv(unsigned char *buf,
	struct own_1905_device *ctx)
{
	unsigned char *temp_buf = NULL;
	unsigned short length = 0;
	struct backhaul_steer_rsp *steer_rsp;
	temp_buf = buf;
	if((*temp_buf) == BACKHAUL_STEERING_RESPONSE_TYPE) {
		temp_buf++;
	} else {
		return -1;
	}
	//calculate tlv length
	length = *(unsigned short *)temp_buf;
	//length = be2cpu16(length);
	length = (length << 8) & 0xFF00;
	length = length | (*(temp_buf + 1));
	temp_buf += 2;
	steer_rsp = (struct backhaul_steer_rsp *)temp_buf;
	notice(DEBUG_CAT_TLVPRS, BH_STEER_PREX"bh mac"MACSTR"\n", MAC2STR(steer_rsp->backhaul_mac));
	notice(DEBUG_CAT_TLVPRS, BH_STEER_PREX"target bssid"MACSTR"\n", MAC2STR(steer_rsp->target_bssid));
	notice(DEBUG_CAT_TLVPRS, BH_STEER_PREX"status %d\n", steer_rsp->status);
	if (steer_rsp->status == 0)
		{
			notice(DEBUG_CAT_TLVPRS, BH_STEER_PREX"success\n");
		}
	else
		{
			err(DEBUG_CAT_TLVPRS, BH_STEER_PREX"fail\n");
		}
	return (length+3);
}
int parse_error_code_tlv(unsigned char *buf,
	struct own_1905_device *ctx)
{
	unsigned char *temp_buf = NULL;
	unsigned short length = 0;
	temp_buf = buf;
	if((*temp_buf) == ERROR_CODE_TYPE) {
		temp_buf++;
	}
	else {
		return -1;
	}
	//calculate tlv length
	length = *(unsigned short *)temp_buf;
	length = (length << 8) & 0xFF00;
	length = length | (*(temp_buf + 1));
	if (length != 7) {
		return -1;
	}
	return (length+3);
}
int parse_backhaul_steering_rsp_message(struct own_1905_device *ctx,
	unsigned char *buf)
{
	int length =0;
	unsigned char *temp_buf;
	unsigned char integrity = 0;
	temp_buf = buf;
	while(1) {
		if (*temp_buf == BACKHAUL_STEERING_RESPONSE_TYPE) {
			integrity |= 0x1;
			length = parse_backhaul_steering_rsp_tlv(temp_buf, ctx);
			if(length < 0) {
				err(DEBUG_CAT_TLVPRS, "error backhaul steering response tlv\n");
				return -1;
			}
			temp_buf += length;
		} else if (*temp_buf == ERROR_CODE_TYPE) {
			length = parse_error_code_tlv(temp_buf, ctx);
			if(length < 0) {
				err(DEBUG_CAT_TLVPRS, "error error code tlv\n");
				return -1;
			}
			temp_buf += length;
		} else if (*temp_buf == END_OF_TLV_TYPE) {
			break;
		} else {
			length = get_cmdu_tlv_length(temp_buf);
			temp_buf += length;
		}
	}
	if(integrity != 0x1) {
		err(DEBUG_CAT_TLVPRS, "no backhaul steering response tlv\n");
		return -1;
	}
	return 0;
}
#ifdef CENT_STR

int parse_client_info_tlv(unsigned char *buf,
	struct own_1905_device *ctx, unsigned char *bssid, unsigned char *sta_mac)
{
	unsigned char *temp_buf = NULL;
	unsigned short length = 0;

	temp_buf = buf;

	if((*temp_buf) == CLIENT_INFO_TYPE)
		temp_buf++;
	else
		return -1;

	length = *(unsigned short *)temp_buf;
	length = be_to_host16(length);

	temp_buf+=2;

	debug(DEBUG_CAT_TLVPRS, "BSSID ("MACSTR")\n", MAC2STR(temp_buf));
	os_memcpy(bssid, temp_buf, ETH_ALEN);
	temp_buf += ETH_ALEN;
	debug(DEBUG_CAT_TLVPRS, "client ("MACSTR")\n", MAC2STR(temp_buf));
	os_memcpy(sta_mac, temp_buf, ETH_ALEN);
	return (length+3);

}

int parse_client_capability_report_tlv(struct own_1905_device *ctx,
	unsigned char *buf, unsigned char *assoc_req)
{
    unsigned char *temp_buf = NULL;
    unsigned short length = 0;

    temp_buf = buf;
	if (!temp_buf) {
		err(DEBUG_CAT_TLVPRS, "buf is null\n");
		return -1;
    }
    if((*temp_buf) == CLIENT_CAPABILITY_REPORT_TYPE) {
        temp_buf++;
    }
    else {
        return -1;
    }

    //calculate tlv length
    length = *(unsigned short *)temp_buf;
    length = be_to_host16(length);
	temp_buf += 2;
	if (length < 1) {
		err(DEBUG_CAT_TLVPRS, "assoc length is invalid\n");
		return -1;
	} else if (length == 1)
		return 1;

	if(length - sizeof(unsigned char) > ASSOC_REQ_LEN_MAX)
		os_memcpy(assoc_req, temp_buf + 1, ASSOC_REQ_LEN_MAX);
	else
		os_memcpy(assoc_req, temp_buf + 1, length - sizeof(unsigned char));

    return (length+3);
}

int parse_client_capability_report_message(struct own_1905_device *ctx,
		unsigned char *buf, unsigned int left_tlv_len, unsigned char *temp_bssid, unsigned char *temp_sta,
		unsigned char *assoc_req, unsigned int *assoc_len)
{
	int length = 0, len = 0, tlv_len = 0;
	unsigned char *temp_buf;
	temp_buf = buf;
	while(1)
	{
		len = get_tlv_len(temp_buf);
		tlv_len = len + 3;
		if (left_tlv_len < tlv_len) {
			err(DEBUG_CAT_TLVPRS, "Error TLV len, type = %d, left_tlv_length %d less than tlv_len %d\n",
					*temp_buf, left_tlv_len, tlv_len);
			return -1;
		}
		if(*temp_buf == CLIENT_INFO_TYPE)
		{
			if (check_fixed_length_tlv(CLIENT_INFO_TLV_LEN, temp_buf, left_tlv_len) == FALSE) {
				err(DEBUG_CAT_TLVPRS, "error client info tlv\n");
				return -1;
			}
			length = parse_client_info_tlv(temp_buf, ctx, temp_bssid, temp_sta);
			temp_buf += length;
		} else if (*temp_buf == CLIENT_CAPABILITY_REPORT_TYPE) {
			length = parse_client_capability_report_tlv(ctx, temp_buf, assoc_req);
			if(length < 0)
			{
				err(DEBUG_CAT_TLVPRS, "error client capability report tlv\n");
				return -1;
			} else if (length == 1)
				return 1;

			*assoc_len = length - 4;
			temp_buf += length;
		} else if (*temp_buf == ERROR_CODE_TYPE) {
			if (check_fixed_length_tlv(ERROR_CODE_TLV_LEN, temp_buf, left_tlv_len) == FALSE) {
				err(DEBUG_CAT_TLVPRS, "error client info tlv\n");
				return -1;
			}
			length = parse_error_code_tlv(temp_buf, ctx);
			temp_buf += length;
		} else if(*temp_buf == END_OF_TLV_TYPE) {
			break;
		} else {
			length = get_cmdu_tlv_length(temp_buf);
			temp_buf += length;
		}
		left_tlv_len -= tlv_len;
	}
	return 0;
}
#endif
#ifdef MAP_R3
int parse_bss_config_report_tlv(struct own_1905_device *ctx, unsigned char *buf, struct _1905_map_device *dev)
{
	unsigned char *temp_buf = NULL;
	struct radio_info_db *radio = NULL;
	struct bss_info_db *bss = NULL;
	unsigned short length = 0;
	unsigned short left_tlv_len = 0;
	unsigned char i = 0, j = 0;
	unsigned char num_ra = 0, num_bss = 0;
	unsigned char ssid_len = 0;

	if (!ctx || !buf || !dev) {
		debug(DEBUG_CAT_TLVPRS, TOPO_PREX"invalid param!! ctx(%p) buf(%p) or dev(%p) null\n",
			ctx, buf, dev);
		return -1;
	}

	temp_buf = buf;

	if((*temp_buf) == BSS_CONFIG_REPORT_TYPE) {
		temp_buf++;
	} else {
		return -1;
	}

	//calculate tlv length
	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length | (*(temp_buf + 1));

	left_tlv_len = length;
	temp_buf += 2;

	if (left_tlv_len < 1) {
		err(DEBUG_CAT_TLVPRS, "error left %d less than %d\n", left_tlv_len, 1);
		return -1;
	}

	num_ra = *temp_buf++;
	left_tlv_len -= 1;

	if (num_ra > MAP_MAX_RADIO) {
		err(DEBUG_CAT_TLVPRS, "error radios are more than support %d\n", num_ra);
		return -1;
	}

	for (i = 0; i < num_ra; i++) {
		if (left_tlv_len < ETH_ALEN+1) {
			err(DEBUG_CAT_TLVPRS, "left %d less than %d\n", left_tlv_len, ETH_ALEN+1);
			goto out;
		}
		radio = topo_srv_get_radio(dev, temp_buf);
		if (!radio) {
			err(DEBUG_CAT_TLVPRS, TOPO_PREX"radio mapping not done! wait for another turn\n");
			goto out ;
		}
		temp_buf += ETH_ALEN;
		num_bss = *temp_buf++;
		left_tlv_len -= ETH_ALEN+1;
		for (j = 0; j < num_bss; j++) {
			if (left_tlv_len < ETH_ALEN+2) {
				err(DEBUG_CAT_TLVPRS, "left %d less than %d", left_tlv_len, ETH_ALEN+2);
				goto out;
			}

			bss = topo_srv_get_bss_by_bssid(ctx, dev, temp_buf);
			if (!bss) {
				err(DEBUG_CAT_TLVPRS, TOPO_PREX"bss mapping not done! wait for another turn\n");
				goto out ;
			}
			temp_buf += ETH_ALEN;
			left_tlv_len -= ETH_ALEN;
			bss->backhual_in_use = (*temp_buf & 0x80) >> 7;
			bss->fronthaul_in_use = (*temp_buf & 0x40) >> 6;
			bss->r1_disallowed = (*temp_buf & 0x20) >> 5;
			bss->r2_disallowed = (*temp_buf & 0x10) >> 4;
			bss->multi_bssid= (*temp_buf & 0x08) >> 3;
			bss->r2_disallowed = (*temp_buf & 0x04) >> 2;
			temp_buf++;
			left_tlv_len--;
			temp_buf++;
			left_tlv_len--;
			ssid_len = *temp_buf++;
			left_tlv_len--;
			if (left_tlv_len < ssid_len) {
				err(DEBUG_CAT_TLVPRS, "left %d less than %d\n", left_tlv_len, ETH_ALEN+1);
				goto out;
			}
			temp_buf += ssid_len;
		}
	}

out:
	return (length+3);
}

#ifdef MTK_MLO_MAP_SUPPORT
u8 parse_bss_is_dev_mld(struct own_1905_device *ctx, struct _1905_map_device *dev)
{
	/*
	 * loop on bss, check if any mld index is less then 17
	 * then only mark as mld_enabled = 1 else 0
	 */
	struct bss_info_db *bss = NULL;
	u8 mld_enabled = 0;

	do {
		bss = topo_srv_get_next_bss(dev, bss);
		if (!bss) {
			debug(DEBUG_CAT_TLVPRS, "mac not found\n");
			goto done;
		}

		if ((bss->mlo_info.mld_idx >= MIN_MULTI_MLD_IDX)
		    && (bss->mlo_info.mld_idx <= MAX_MULTI_MLD_IDX)) {
			mld_enabled = 1;
			info(DEBUG_CAT_TLVPRS, "MLD_IDX is in range bss->mlo_info.mld_idx %d\n", bss->mlo_info.mld_idx);
			break;
		}

		info(DEBUG_CAT_TLVPRS, "MLD_IDX: %d\n", bss->mlo_info.mld_idx);

	} while (bss);

done:
	return mld_enabled;
}


int parse_bss_mld_report_tlv(struct own_1905_device *ctx, unsigned char *buf, struct _1905_map_device *dev)
{
	unsigned char *temp_buf = NULL;
	struct radio_info_db *radio = NULL;
	struct bss_info_db *bss = NULL;
	unsigned short length = 0;
	unsigned short left_tlv_len = 0;
	unsigned char i = 0, j = 0;
	unsigned char num_ra = 0, num_bss = 0;
	unsigned char mtk_oui[3] = {0x00, 0x0C, 0xE7};
	unsigned char func_type = 0;

	if (!ctx || !buf || !dev) {
		debug(DEBUG_CAT_TLVPRS, TOPO_PREX"invalid param!! ctx(%p) buf(%p) or dev(%p) null\n",
			ctx, buf, dev);
		return -1;
	}

	temp_buf = buf;

	if ((*temp_buf) == VENDOR_SPECIFIC_TLV_TYPE)
		temp_buf++;
	else
		return -1;

	/* calculate tlv length */
	length = *(unsigned short *)temp_buf;
	length = be_to_host16(length);
	left_tlv_len = length;
	temp_buf += 2;

	/* info_hexdump(DEBUG_CAT_TLVPRS, "######MLD VENDOR CAP", temp_buf, length); */
	if (left_tlv_len < sizeof(mtk_oui) + 1) {
		err(DEBUG_CAT_TLVPRS, "%d: left %d\n", __LINE__, left_tlv_len);
		return -1;
	}

	if (os_memcmp(temp_buf, mtk_oui, 3)) {
		err(DEBUG_CAT_TLVPRS, "OUI not mtk_oui; do not handle!\n");
		return 0;
	}

	temp_buf += 3;
	func_type = *temp_buf++;
	if (func_type != FUNC_VENDOR_MLO_MLD_RSP)
		return -1;

	num_ra = *temp_buf++;
	left_tlv_len -= 1;

	if (num_ra > MAP_MAX_RADIO) {
		err(DEBUG_CAT_TLVPRS, "error radios are more than support %d\n", num_ra);
		return -1;
	}

	for (i = 0; i < num_ra; i++) {
		if (left_tlv_len < ETH_ALEN+1) {
			err(DEBUG_CAT_TLVPRS, "left %d less than %d\n", left_tlv_len, ETH_ALEN+1);
			goto out;
		}
		radio = topo_srv_get_radio(dev, temp_buf);
		if (!radio) {
			err(DEBUG_CAT_TLVPRS, TOPO_PREX"radio mapping not done! wait for another turn\n");
			goto out;
		}
		temp_buf += ETH_ALEN;
		num_bss = *temp_buf++;
		left_tlv_len -= ETH_ALEN + 1;
		for (j = 0; j < num_bss; j++) {
			if (left_tlv_len < ETH_ALEN + 2) {
				err(DEBUG_CAT_TLVPRS, "left %d less than %d\n", left_tlv_len, ETH_ALEN+2);
				goto out;
			}

			bss = topo_srv_get_bss_by_bssid(ctx, dev, temp_buf);
			if (!bss) {
				err(DEBUG_CAT_TLVPRS, TOPO_PREX"bss mapping not done! wait for another turn\n");
				goto out;
			}
			temp_buf += ETH_ALEN;
			//bss->backhual_in_use = (*temp_buf & 0x80) >> 7;
			//bss->fronthaul_in_use = (*temp_buf & 0x40) >> 6;
			temp_buf++;
			bss->mlo_info.mld_idx = *temp_buf;
			temp_buf++;
			os_memcpy(bss->mlo_info.mld_addr, temp_buf, ETH_ALEN);
			temp_buf += ETH_ALEN;
		}
	}

	/* MLD Enable for 1905 Device */
	dev->mld_enabled = parse_bss_is_dev_mld(ctx, dev);
out:
	return (length+3);
}
#endif
#endif

#ifdef MAP_R2
#ifdef MAP_R6
int parse_static_puncture_tlv_r6(struct own_1905_device *ctx, unsigned char *buf, struct _1905_map_device *dev)
{
	unsigned char *temp_buf;
	unsigned short length = 0, left_tlv_len = 0;
	unsigned char num_radio = 0;
	unsigned char num_bss = 0;
	unsigned char r_idx = 0, bss_idx = 0;
	unsigned char dscb_valid = 0;
	unsigned char eht_pe_duration = 0;
	unsigned char eht_op_info_valid = 0;
	unsigned char grp_addr_bu_ind_limit = 0;
	unsigned char grp_addr_bu_ind_exponent = 0;
	struct eht_operations_info_parse_db *db = NULL;
	struct radio_info_db *radio = NULL;
	struct eht_operations_parse_db eht_op[MAP_MAX_RADIO] = {0};

	if (ctx == NULL || buf == NULL) {
		err(DEBUG_CAT_TLVPRS, "invalid param!! ctx(%p) buf(%p) null\n",
				ctx, buf);
		return -1;
	}

	temp_buf = buf;

	if ((*temp_buf) == EHT_OPERATION_TLV_TYPE)
		temp_buf++;
	else
		return -1;

	/*calculate tlv length*/
	length = *(unsigned short *)temp_buf;
	length = be_to_host16(length);
	left_tlv_len = length;
	temp_buf += 2;


	/*32 bytes reserved*/
	temp_buf += 32;

	left_tlv_len -= 32;

	if (left_tlv_len < 1) {
		err(DEBUG_CAT_TLVPRS, "left %d is less tha %d\n", left_tlv_len, 1);
		return -1;
	}

	for (r_idx = 0; r_idx < MAP_MAX_RADIO; r_idx++)
		dl_list_init(&eht_op[r_idx].eht_op_list);

	/*num of radios*/
	num_radio = *temp_buf;
	temp_buf++;
	left_tlv_len--;

	if (num_radio > MAP_MAX_RADIO || num_radio == 0) {
		err(DEBUG_CAT_TLVPRS, "%d: radio num for eht operation tlv %d\n", __LINE__, num_radio);
		return -1;
	}

	for (r_idx = 0; r_idx < num_radio; r_idx++) {
		if (left_tlv_len < ETH_ALEN) {
			err(DEBUG_CAT_TLVPRS, "left %d is less tha %d\n", left_tlv_len, ETH_ALEN);
			return -1;
		}
		/*radio identifier*/
		os_memcpy(eht_op[r_idx].ruid, temp_buf, ETH_ALEN);

		temp_buf += ETH_ALEN;
		left_tlv_len -= ETH_ALEN;

		if (left_tlv_len < 1) {
			err(DEBUG_CAT_TLVPRS, "%d left %d is less tha %d\n", __LINE__, left_tlv_len, 1);
			return -1;
		}

		/* num of BSSs */
		num_bss = *temp_buf;
		temp_buf++;
		left_tlv_len--;

		for (bss_idx = 0; bss_idx < num_bss; bss_idx++) {
			dscb_valid = 0;
			eht_pe_duration = 0;
			eht_op_info_valid = 0;
			grp_addr_bu_ind_limit = 0;
			grp_addr_bu_ind_exponent = 0;

			if (left_tlv_len < ETH_ALEN) {
				err(DEBUG_CAT_TLVPRS, "%d left %d is less tha %d\n", __LINE__, left_tlv_len, ETH_ALEN);
				return -1;
			}
			db = (struct eht_operations_info_parse_db *)os_zalloc(sizeof(struct eht_operations_info_parse_db));
			if (!db) {
				info(DEBUG_CAT_TLVPRS, "%d: error alloc\n", __LINE__);
				return -1;
			}
			/*	This add list causes crash after onboarding
			 *	dl_list_add_tail(&eht_op[r_idx].eht_op_list, &db->list);
			 *	As of now this code is not used [Needs to be fixed]
			 */
			/* BSSID */
			os_memcpy(db->bssid, temp_buf, ETH_ALEN);
			temp_buf += ETH_ALEN;
			left_tlv_len -= ETH_ALEN;

			if (left_tlv_len < 1) {
				info(DEBUG_CAT_TLVPRS, "%d: error left %d less than %d\n",
					__LINE__, left_tlv_len, 1);
				os_free(db);
				return -1;
			}
			/* EHT_Operation_Information_Valid bit 7
			 * Disabled_Subchannel_Valid	bit 6
			 * EHT Default PE Duration bit 5
			 * Group Addressed BU Indication Limit bit 4
			 * Group Addressed BU Indication Exponent	bits 3-2
			 */
			if (*temp_buf & 0x80)
				eht_op_info_valid = 1;
			if (*temp_buf & 0x40)
				dscb_valid = 1;
			if (*temp_buf & 0x20)
				eht_pe_duration = 1;
			if (*temp_buf & 0x10)
				grp_addr_bu_ind_limit = 1;
			if (*temp_buf & 0x04)
				grp_addr_bu_ind_exponent = 1;
			db->eht_operation_information_valid = eht_op_info_valid;
			temp_buf += 1;
			left_tlv_len -= 1;

			if (left_tlv_len < sizeof(struct eht_mcs_nss)) {
				info(DEBUG_CAT_TLVPRS, "%d: error left %d less than %d\n",
					__LINE__, left_tlv_len, (int)sizeof(struct eht_mcs_nss));
				os_free(db);
				return -1;
			}
			/* Basic EHT-MCS And Nss Set */
			os_memcpy(&db->eht_mcs_nss_set, temp_buf, sizeof(struct eht_mcs_nss));
			temp_buf += sizeof(struct eht_mcs_nss);
			left_tlv_len -= sizeof(struct eht_mcs_nss);

			if (left_tlv_len < 5) {
				info(DEBUG_CAT_TLVPRS, "%d: error left %d less than %d\n",
					__LINE__, left_tlv_len, 5);
				os_free(db);
				return -1;
			}
			/* control */
			db->control = *temp_buf++;
			left_tlv_len--;
			/* ccfs0 */
			db->ccfs0 = *temp_buf++;
			left_tlv_len--;
			/* ccfs1 */
			db->ccfs1 = *temp_buf++;
			left_tlv_len--;

			/*Fill eht capabilities for the radio*/
			radio = topo_srv_get_radio(dev, eht_op[r_idx].ruid);

			if (radio) {
				radio->radio_capability.eht_cap.ccfs0 = db->ccfs0;
				radio->radio_capability.eht_cap.ccfs1 = db->ccfs1;
				radio->radio_capability.eht_cap.eht_ch_width = db->control & DOT11BE_MCS_NSS_MASK;
				if (db->eht_mcs_nss_set.max_tx_rx_mcs12_13_nss != 0) {
					radio->radio_capability.eht_cap.rx_stream =
					(db->eht_mcs_nss_set.max_tx_rx_mcs12_13_nss & DOT11BE_MCS_NSS_MASK) - 1;
					radio->radio_capability.eht_cap.tx_stream =
					((db->eht_mcs_nss_set.max_tx_rx_mcs12_13_nss &
					(DOT11BE_MCS_NSS_MASK << DOT11BE_MCS_NSS_SHIFT)) >> DOT11BE_MCS_NSS_SHIFT) - 1;
				} else if (db->eht_mcs_nss_set.max_tx_rx_mcs10_11_nss != 0) {
					radio->radio_capability.eht_cap.rx_stream =
					(db->eht_mcs_nss_set.max_tx_rx_mcs10_11_nss & DOT11BE_MCS_NSS_MASK) - 1;
					radio->radio_capability.eht_cap.tx_stream =
					((db->eht_mcs_nss_set.max_tx_rx_mcs10_11_nss &
					(DOT11BE_MCS_NSS_MASK << DOT11BE_MCS_NSS_SHIFT)) >> DOT11BE_MCS_NSS_SHIFT) - 1;
				} else if (db->eht_mcs_nss_set.max_tx_rx_mcs8_9_nss != 0) {
					radio->radio_capability.eht_cap.rx_stream =
					(db->eht_mcs_nss_set.max_tx_rx_mcs8_9_nss & DOT11BE_MCS_NSS_MASK) - 1;
					radio->radio_capability.eht_cap.tx_stream =
					((db->eht_mcs_nss_set.max_tx_rx_mcs8_9_nss &
					(DOT11BE_MCS_NSS_MASK << DOT11BE_MCS_NSS_SHIFT)) >> DOT11BE_MCS_NSS_SHIFT) - 1;
				} else {
					radio->radio_capability.eht_cap.rx_stream =
					(db->eht_mcs_nss_set.max_tx_rx_mcs0_7_nss & DOT11BE_MCS_NSS_MASK) - 1;
					radio->radio_capability.eht_cap.tx_stream =
					((db->eht_mcs_nss_set.max_tx_rx_mcs0_7_nss &
					(DOT11BE_MCS_NSS_MASK << DOT11BE_MCS_NSS_SHIFT)) >> DOT11BE_MCS_NSS_SHIFT) - 1;
				}
			}

			/* dscb */
			db->dscb_bitmap = *(unsigned short *)temp_buf;
			db->dscb_bitmap = be_to_host16(db->dscb_bitmap);
			if (eht_op_info_valid && dscb_valid)
				ch_planning_static_punture(dev, eht_op[r_idx].ruid, db->dscb_bitmap);
			temp_buf += 2;
			left_tlv_len -= 2;

			/* reserved 16 bytes */
			if (left_tlv_len < 16) {
				info(DEBUG_CAT_TLVPRS, "%d: error left %d less than %d\n",
					__LINE__, left_tlv_len, 16);
				os_free(db);
				return -1;
			}
			temp_buf += 16;
			left_tlv_len -= 16;

			/*free memory*/
			os_free(db);
		}

		/* reserved 25 bytes */
		if (left_tlv_len < 25) {
			info(DEBUG_CAT_TLVPRS, "%d: error left %d less than %d\n",
				__LINE__, left_tlv_len, 25);
			return -1;
		}

		temp_buf += 25;
		left_tlv_len -= 25;

	}

	return length + 3;
}
#endif
int parse_static_puncture_tlv(struct own_1905_device *ctx, unsigned char *buf, struct _1905_map_device *dev)
{
	int left = 0, len = 0;
	unsigned char *temp_buf = buf;
	unsigned char r_num = 0, bss_num = 0;
	unsigned char r_idx = 0, bss_idx = 0;
	unsigned short dscb_bitmap = 0;
	unsigned char ruid[ETH_ALEN], bssid[ETH_ALEN];

	if ((*temp_buf) == STATIC_PUNCTURING_CONFIGURATION_TLV_TYPE)
		temp_buf++;
	else
		return -1;

	/*calculate tlv length*/
	len = *(unsigned short *)temp_buf;
	len = be_to_host16(len);
	left = len;
	temp_buf += 2;

	if (left < 32) {
		err(DEBUG_CAT_TLVPRS, "%d: error left %d less than %d\n",
				__LINE__, left, 32);
		return -1;
	}
	temp_buf += 32;
	left -= 32;

	if (left < 1) {
		err(DEBUG_CAT_TLVPRS, "%d: error left %d less than %d\n",
				__LINE__, left, 1);
		return -1;
	}
	/* numRadios */
	r_num = *temp_buf;
	temp_buf++;
	left--;
	if (r_num > MAP_MAX_RADIO || r_num == 0) {
		info(DEBUG_CAT_TLVPRS, "%d: radio num for static puncturing tv %d\n", __LINE__, r_num);
		return (len + 3);
	}
	for (r_idx = 0; r_idx < r_num; r_idx++) {
		if (left < ETH_ALEN) {
			err(DEBUG_CAT_TLVPRS, "%d: error left %d less than %d\n",
					__LINE__, left, ETH_ALEN);
			return -1;
		}
		/* RUID */
		os_memcpy(ruid, temp_buf, ETH_ALEN);
		temp_buf += ETH_ALEN;
		left -= ETH_ALEN;

		if (left < 1) {
			err(DEBUG_CAT_TLVPRS, "%d: error left %d less than %d\n",
				__LINE__, left, 1);
			return -1;
		}

		/* numBSSs */
		bss_num = *temp_buf;
		temp_buf++;
		left--;
		for (bss_idx = 0; bss_idx < bss_num; bss_idx++) {
			if (left < ETH_ALEN) {
				err(DEBUG_CAT_TLVPRS, "%d: error left %d less than %d\n",
					 __LINE__, left, ETH_ALEN);
					return -1;
			}
			/* BSSID */
			os_memcpy(bssid, temp_buf, ETH_ALEN);
			temp_buf += ETH_ALEN;
			left -= ETH_ALEN;

			if (left < 1) {
				err(DEBUG_CAT_TLVPRS, "%d: error left %d less than %d\n",
					__LINE__, left, 1);
				return -1;
			}
			temp_buf += 1;
			left -= 1;
			if (left < sizeof(struct eht_mcs_nss)) {
				err(DEBUG_CAT_TLVPRS, "%d: error left %d less than %d\n", __LINE__, left, (int)sizeof(struct eht_mcs_nss));
				return -1;
			}
			/* Basic EHT-MCS And Nss Set */
			temp_buf += sizeof(struct eht_mcs_nss);
			left -= sizeof(struct eht_mcs_nss);

			if (left < 5) {
				err(DEBUG_CAT_TLVPRS, "%d: error left %d less than %d\n",  __LINE__, left, 5);
				return -1;
			}
			/* control */
			temp_buf += 1;
			left--;
			/* ccfs0 */
			temp_buf += 1;
			left--;
			/* ccfs1 */
			temp_buf += 1;
			left--;
			/* dscb */
			dscb_bitmap = *(unsigned short *)temp_buf;
			dscb_bitmap = be_to_host16(dscb_bitmap);
			ch_planning_static_punture(dev, ruid, dscb_bitmap);
			temp_buf += 2;
			left -= 2;

			/* reserved 16 bytes */
			if (left < 16) {
				err(DEBUG_CAT_TLVPRS, "%d: error left %d less than %d\n", __LINE__, left, 16);
				return -1;
			}
			temp_buf += 16;
			left -= 16;
		}
		if (left < 25) {
			err(DEBUG_CAT_TLVPRS, "%d: error left %d less than %d\n",
				__LINE__, left, 25);
			return -1;
		}
		temp_buf += 25;
		left -= 25;
	}
	return (len + 3);
}
#endif


#ifdef MAP_R3_WF6
int parse_assoc_sta_wifi6_status_report_tlv(unsigned char *buf, struct _1905_map_device *dev)
{
	unsigned char *pos = NULL;
	struct associated_clients *sta = NULL, *tsta = NULL;
	unsigned short length = 0;
	unsigned char i = 0;


	if (!buf || !dev) {
		debug(DEBUG_CAT_TLVPRS, TOPO_PREX"invalid param!! buf(%p) or dev(%p) null\n",
			buf, dev);
		return -1;
	}

	pos = buf;

	if ((*pos) == BSS_CONFIG_REPORT_TYPE) {
		pos++;
	} else {
		return -1;
	}

	//calculate tlv length
	length = *(unsigned short *)pos;
	length = be_to_host16(length);
	pos += 2;

	if (validate_tlv_length_specific_pattern(length,
		ASSOC_STA_WF6_STATUS_REPORT_TLV_CONST_LEN,
		ASSOC_STA_WF6_STATUS_REPORT_TLV_REPEATED_LEN) == FALSE) {
		err(DEBUG_CAT_TLVPRS, "error ASSOC_STA_WF6_STATUS_REPORT_TLV length is %d incorrect\n", length);
		return -1;
	}

	SLIST_FOREACH_SAFE(sta, &dev->assoc_clients, next_client, tsta) {
		if (os_memcmp(sta->client_addr, pos, ETH_ALEN) == 0) {
			/*clear tid field*/
			if (sta->tid) {
				os_free(sta->tid);
				sta->tid = NULL;
			}
			if (sta->tid_queue_size) {
				os_free(sta->tid_queue_size);
				sta->tid_queue_size = NULL;
			}
			pos += ETH_ALEN;
			sta->num_tid = *pos++;
			sta->tid = os_zalloc(sta->num_tid);
			if (!sta->tid) {
				err(DEBUG_CAT_TLVPRS, "alloc memory for sta->tid fail\n");
				sta->num_tid = 0;
				return -1;
			}
			sta->tid_queue_size = os_zalloc(sta->num_tid);
			if (!sta->tid_queue_size) {
				err(DEBUG_CAT_TLVPRS, "alloc memory for sta->tid_queue_size fail\n");
				os_free(sta->tid);
				sta->tid = NULL;
				sta->num_tid = 0;
				return -1;
			}
			for (i = 0; i < sta->num_tid; i++) {
				sta->tid[i] = *pos++;
				sta->tid_queue_size[i] = *pos++;
			}
			break;
		}
	}

	return length + 3;
}

#endif
/* OOB vulnerability: Rule No 2: Length field with specific pattern*/
Boolean validate_tlv_length_specific_pattern(uint16_t tlv_length, uint16_t constant_field, uint16_t pattern_length)
{
	int remain_len = tlv_length - constant_field;

	if (tlv_length == 0 || pattern_length == 0 || remain_len < 0)
		return FALSE;

	if ((remain_len % pattern_length) == 0)
		return TRUE;

	return FALSE;
}

Boolean check_metrics_fixed_length_tlv(uint16_t fixed_tlv_length, unsigned char *tlv_buf, uint16_t buf_length)
{
	uint16_t length = get_tlv_len(tlv_buf);

	if (length > buf_length || length < fixed_tlv_length)
		return FALSE;
	else
		return TRUE;
}

/* OOB vulnerability: Rule No 1: Fixed length TLV*/

Boolean check_fixed_length_tlv(uint16_t fixed_tlv_length, unsigned char *tlv_buf, uint16_t buf_length)
{
	uint16_t length = get_tlv_len(tlv_buf);

	if (length > buf_length || length != fixed_tlv_length)
		return FALSE;
	else
		return TRUE;
}

/* OOB vulnerability: Rule No 3: Length field with maximum size limitation*/
Boolean check_subfield_length(uint16_t max_subfield_length, uint16_t tlv_subfield_len)
{
	if (tlv_subfield_len > max_subfield_length)
		return FALSE;
	else
		return TRUE;
}

int get_tlv_len(unsigned char *buf)
{
	unsigned char *temp_buf = buf;
	unsigned short length = 0;

	temp_buf += 1; /* shift to length field */

	length = *(unsigned short *)temp_buf;
	length = be_to_host16(length);

	return length;
}

