/*
 * ***************************************************************************
 * *  Mediatek Inc.
 * * 4F, No. 2 Technology 5th Rd.
 * * Science-based Industrial Park
 * * Hsin-chu, Taiwan, R.O.C.
 * *
 * * (c) Copyright 2002-2011, Mediatek, Inc.
 * *
 * * All rights reserved. Mediatek's source code is an unpublished work and the
 * * use of a copyright notice does not imply otherwise. This source code
 * * contains confidential trade secret material of Ralink Tech. Any attemp
 * * or participation in deciphering, decoding, reverse engineering or in any
 * * way altering the source code is stricitly prohibited, unless the prior
 * * written consent of Mediatek, Inc. is obtained.
 * ***************************************************************************
 *
 *  Module Name:
 *  AP Estimator
 *
 *  Abstract:
 *  AP Estimator
 *
 *  Revision History:
 *  Who         When          What
 *  --------    ----------    -----------------------------------------
 *  Neelansh.M   2018/05/02     First implementation of the ap est. Module
 * */
#include "includes.h"
#include "interface.h"
#ifdef SUPPORT_MULTI_AP
#include "data_def.h"
#endif
#include "common.h"
#include "steer_fsm.h"
#include "list.h"
#include "client_db.h"
#include "mapd_i.h"
#include "chan_mon.h"
#ifdef SUPPORT_MULTI_AP
#include "topologySrv.h"
#include "tlv_parsor.h"
#endif
#include "client_mon.h"
#include "steer_action.h"
#include "ap_est.h"
#include "wapp_if.h"
#include "eloop.h"
#include <assert.h>

#include <sys/un.h>
#ifdef SUPPORT_MULTI_AP
#include "1905_map_interface.h"
#include "ch_planning.h"
#if defined(MAP_6E_SUPPORT) && defined(MAP_R6)
#include "mapd_cosr.h"
#endif /* MAP_6E_SUPPORT and MAP_R6 */

#endif
#ifdef CENT_STR
#include "ap_cent_str.h"
#endif


static void ap_est_handle_11k_timeout(void *eloop_ctx, void *timeout_ctx)
{
	struct mapd_global *global = (struct mapd_global *)eloop_ctx;
	struct client *cli = (struct client *)timeout_ctx;
	u8 idx = cli->meas_data.curr_measurement_chan_idx;

#ifdef MAP_6E_SUPPORT
#ifdef SUPPORT_MULTI_AP
	struct _1905_map_device *own_device = topo_srv_get_1905_by_bssid(&global->dev, cli->bssid);
#endif
#endif

	err(DEBUG_CAT_AP_EST, STEER_CHAN_MEAS_PREX"11k Timedout for channel = %d",
					cli->meas_data.measurement_channels[idx].channel);

	if (cli->meas_data.cli_measurement_state != MEAS_STATE_11K_TRIGGERED) {
		err(DEBUG_CAT_AP_EST, STEER_CHAN_MEAS_PREX"Timeout when not triggered!!");
		mapd_ASSERT(0);
	}




	if (cli->meas_data.measurement_retries_11k < MAX_11K_RETRIES) {
		cli->meas_data.measurement_retries_11k ++;
		info(DEBUG_CAT_AP_EST, STEER_CHAN_MEAS_PREX"11k Retry(%d) on channel = %d",
						 cli->meas_data.measurement_retries_11k,
						 cli->meas_data.measurement_channels[idx].channel);

		if (ap_est_trigger_11k_channel_measurement(global,cli) == FALSE) {
			err(DEBUG_CAT_AP_EST, STEER_CHAN_MEAS_PREX"Channel meas Failed");
			steer_fsm_trigger(global, cli->client_id, CHAN_MEASUREMENT_FAIL, NULL);
		}
		return;
	}
	info(DEBUG_CAT_AP_EST, STEER_CHAN_MEAS_PREX"Retries exhausted for channel = %d",
					cli->meas_data.measurement_channels[idx].channel);

	cli->meas_data.measurement_retries_11k = 0;
#ifdef MAP_6E_SUPPORT
	while (
#ifdef SUPPORT_MULTI_AP
		own_device &&
#endif
		(cli->meas_data.curr_measurement_chan_idx < (cli->meas_data.meas_chan_cnt - 1))) {
		idx = cli->meas_data.curr_measurement_chan_idx + 1;
#ifdef SUPPORT_MULTI_AP
		if (global->dev.cent_str_en) {
			u8 next_band = get_band_6E(own_device, cli->meas_data.measurement_channels[idx].channel
				, cli->meas_data.measurement_channels[idx].op_class);
#else
			u8 next_band = bs_get_band_6E(global,
				cli->meas_data.measurement_channels[idx].channel,
				cli->meas_data.measurement_channels[idx].op_class);
#endif
			err(DEBUG_CAT_AP_EST, "curr_meas_band %d next_band %d bit %d", cli->meas_data.curr_measured_band,
			 next_band, BIT(next_band));
			if (cli->meas_data.curr_measured_band & BIT(next_band)) {
				cli->meas_data.curr_measurement_chan_idx++;
				continue;
			} else
				break;
#ifdef SUPPORT_MULTI_AP
		} else
			break;
#endif
	}
#endif

	/* Move to next channel */
	if(cli->meas_data.curr_measurement_chan_idx < (cli->meas_data.meas_chan_cnt - 1)) {
			cli->meas_data.curr_measurement_chan_idx++;
			idx = cli->meas_data.curr_measurement_chan_idx;
			err(DEBUG_CAT_AP_EST, STEER_CHAN_MEAS_PREX" Triggering 11k for next channel = %d",
							cli->meas_data.measurement_channels[idx].channel);
		if (ap_est_trigger_11k_channel_measurement(global,cli) == FALSE) {
			err(DEBUG_CAT_AP_EST, STEER_CHAN_MEAS_PREX" Channel meas Failed");
			steer_fsm_trigger(global, cli->client_id, CHAN_MEASUREMENT_FAIL, NULL);

		}
	} else {
		/* Trigger Complete */
		info(DEBUG_CAT_AP_EST, STEER_CHAN_MEAS_PREX" Channel meas completed");
		steer_fsm_trigger(global, cli->client_id, CHAN_MEASUREMENT_COMPLETE, NULL);
	}
}
#ifdef MTK_MLO_MAP_SUPPORT
struct client *find_main_setup_link(struct client *cli)
{
	struct client *mld_main_cli = NULL;
	int i;

	for (i = 0; i < MAX_MLD_CLI; i++) {
		if (!cli->mld_clients[i])
			continue;
		if (cli->mld_clients[i]->mlo_setup_link) {
			err(DEBUG_CAT_AP_EST, "setup link found");
			mld_main_cli = cli->mld_clients[i];
			break;
		}
	}
	return mld_main_cli;
}
#endif
/**
 * @brief : Call the beacon metrics query function within wlanif to initiate a
 * beacon request for a client
 *
 * @param global: global device pointer
 * @param cli: client for which beacon metrics query is being initiated
 */
Boolean ap_est_trigger_11k_channel_measurement(struct mapd_global *global,
				struct client *cli)
{
	u8 *ssid = NULL;
	u8 idx = cli->meas_data.curr_measurement_chan_idx;
	u8 wildcard[] = {0xff,0xff,0xff,0xff,0xff,0xff};
#ifdef CENT_STR
	struct _1905_map_device *dev = NULL;
	struct bss_info_db * bss_db = NULL;

	dev = topo_srv_get_1905_by_bssid(&global->dev,cli->bssid);


	if(!dev)
	 return FALSE;

	bss_db = topo_srv_get_bss_by_bssid(&global->dev, dev, cli->bssid);

	if(!bss_db)
	 return FALSE;


	if (global->dev.cent_str_en)
		ssid = bss_db->ssid;
	else
#endif
	{
		ssid = mapd_get_ssid_from_bssid(global, cli->bssid);
		if (ssid == NULL)
			return FALSE;
	}

	if (
#ifdef SUPPORT_MULTI_AP
		global->params.Certification ||
#endif
		idx <= cli->meas_data.meas_chan_cnt - 1) {
		err(DEBUG_CAT_AP_EST, STEER_CHAN_MEAS_PREX MACSTR " BSSID " MACSTR" idx=%d SSID=%s Channel=%d OpClass=%d",
						MAC2STR(cli->mac_addr), MAC2STR(cli->bssid), idx, (char *)ssid,
						cli->meas_data.measurement_channels[idx].channel,
						cli->meas_data.measurement_channels[idx].op_class);
#ifdef CENT_STR
		if((!global->dev.cent_str_en) || 
			(global->dev.cent_str_en && ((dev->device_role == DEVICE_ROLE_CONTROLLER)
			|| (dev->device_role == DEVICE_ROLE_CONTRAGENT))))
#endif
#ifdef MTK_MLO_MAP_SUPPORT
		{
			if (cli->mlo_setup_link) {
				err(DEBUG_CAT_AP_EST,
				 STEER_CHAN_MEAS_PREX MACSTR " MLD_MAINlink BSSID " MACSTR" idx=%d SSID=%s Ch=%d OpClas=%d",
				  MAC2STR(cli->mac_addr), MAC2STR(cli->bssid), idx, (char *)ssid,
				  cli->meas_data.measurement_channels[idx].channel,
				   cli->meas_data.measurement_channels[idx].op_class);
				wlanif_beacon_metrics_query(global, cli->mac_addr, cli->bssid, strlen((char *)ssid), ssid,
						cli->meas_data.measurement_channels[idx].channel,
						cli->meas_data.measurement_channels[idx].op_class, wildcard,
						0, 0, NULL, 0, NULL);
			} else {
				struct client *mld_main_cli = NULL;

				mld_main_cli = find_main_setup_link(cli);
				if (mld_main_cli) {
					err(DEBUG_CAT_AP_EST,
					 STEER_CHAN_MEAS_PREX MACSTR "MLD MAINlink BSSID" MACSTR" idx=%d SSID=%s Ch=%d OpClas=%d",
					  MAC2STR(mld_main_cli->mac_addr), MAC2STR(mld_main_cli->bssid), idx,
					  (char *)ssid, cli->meas_data.measurement_channels[idx].channel,
					   cli->meas_data.measurement_channels[idx].op_class);
					wlanif_beacon_metrics_query(global, mld_main_cli->mac_addr, mld_main_cli->bssid,
						strlen((char *)ssid), ssid,
						cli->meas_data.measurement_channels[idx].channel,
						cli->meas_data.measurement_channels[idx].op_class, wildcard,
						0, 0, NULL, 0, NULL);
				} else {
					err(DEBUG_CAT_AP_EST, "setup primary link not found trigger on cli mac itself");
					wlanif_beacon_metrics_query(global, cli->mac_addr, cli->bssid, strlen((char *)ssid), ssid,
						cli->meas_data.measurement_channels[idx].channel,
						cli->meas_data.measurement_channels[idx].op_class, wildcard,
						0, 0, NULL, 0, NULL);
					}
			}
		}
#else
		wlanif_beacon_metrics_query(global, cli->mac_addr, cli->bssid, strlen((char *)ssid), ssid,
						cli->meas_data.measurement_channels[idx].channel,
						cli->meas_data.measurement_channels[idx].op_class, wildcard,
						0, 0, NULL, 0, NULL);
#endif
#ifdef CENT_STR
			else 
			topo_srv_trigger_beacon_metrics_query(global, dev, cli->mac_addr, cli->bssid, strlen((char *)ssid), ssid,
									cli->meas_data.measurement_channels[idx].channel,
									cli->meas_data.measurement_channels[idx].op_class, wildcard,
									0, 0, NULL, 0, NULL);

#endif
		cli->meas_data.cli_measurement_state = MEAS_STATE_11K_TRIGGERED;
		eloop_register_timeout(1, 250000, ap_est_handle_11k_timeout, global, cli);
		cli->steer_stats.num_11k ++;
		return TRUE;
	} else {
		err(DEBUG_CAT_AP_EST, STEER_CHAN_MEAS_PREX" No channels");
		mapd_ASSERT(0);
	}
	return FALSE;
}
#ifdef MTK_MLO_MAP_SUPPORT
struct client *find_mld_client_11kmeasure(struct client *cli)
{
	struct client *mld_cli_11kmeasure = NULL;
	int i;

	for (i = 0; i < MAX_MLD_CLI; i++) {
		if (!cli->mld_clients[i])
			continue;
		if (cli->mld_clients[i]->meas_data.cli_measurement_state ==  MEAS_STATE_11K_TRIGGERED) {
			mld_cli_11kmeasure = cli->mld_clients[i];
			break;
		}
	}
	return mld_cli_11kmeasure;
}
#endif

/**
 * @brief : handle 11k report from driver (by noting the dl_rssi) called from the
 * wlanif
 *
 * @param global: Global device pointer
 * @param mac_addr: Mac Adress of the client from which report is received
 * @param isSuccess: If the channel measurement was successful, 1 means success
 * @param bssid: bssid on which dl_rssi has been received
 * @param rcpi: the dl_rcpi value received from the beacon report
 */
void ap_est_handle_11k_report(struct mapd_global *global, u8 *mac_addr,
		uint8_t isSuccess, u8 *bssid, u8 channel, u8 rcpi, u8 islastreport
#ifdef MAP_6E_SUPPORT
		, uint8_t band
#endif
) {
	struct cli_rssi *dl_rssi = NULL, *rssi_obj = NULL;
	struct client *cli = client_db_get_client_from_sta_mac(global, mac_addr);
	u8 idx = 0, is_dup_bssid = 0;
	int8_t curr_rssi = 0;
#ifdef SUPPORT_MULTI_AP
	struct bss_info_db *bss = NULL;
#endif
#ifdef CENT_STR
	struct _1905_map_device * own_device = NULL;
	struct associated_clients * client_dev = NULL;
	

#endif

	if (cli == NULL || cli->client_id == (uint32_t)-1) {
		err(DEBUG_CAT_AP_EST, STEER_CHAN_MEAS_PREX MACSTR " not in DB", MAC2STR(mac_addr));
		return;
	}

	err(DEBUG_CAT_AP_EST, STEER_CHAN_MEAS_PREX MACSTR " receive the 11k report", MAC2STR(mac_addr));
#ifdef CENT_STR
	if(global->dev.cent_str_en){


		own_device = topo_srv_get_1905_by_bssid(&global->dev, cli->bssid);

		if (!own_device) {
			err(DEBUG_CAT_AP_EST, STEER_CHAN_MEAS_PREX"own device is NULL");
			return;
		}
		
		client_dev = topo_srv_get_associate_client(&global->dev,own_device, cli->mac_addr);

		if (!client_dev) {
			err(DEBUG_CAT_AP_EST, STEER_CHAN_MEAS_PREX" client dev is NULL");
			return;
		}

	}
#endif
#ifndef MTK_MLO_MAP_SUPPORT
	idx = cli->meas_data.curr_measurement_chan_idx;
#endif

	/* for BS update band and channel capability from beacon report  */
	if (channel) {
#ifdef MAP_6E_SUPPORT
		if (!is_chan_supported(cli->known_channels, channel, BW_20, band))
			client_db_update_from_bcnrpt(global, cli->client_id, channel, band);
#else
		if (!is_chan_supported(cli->known_channels, channel, BW_20))
			client_db_update_from_bcnrpt(global, cli->client_id, channel, 0);
#endif
	}

#ifdef MAP_6E_SUPPORT
	if (cli->meas_data.cli_measurement_state == MEAS_STATE_11K_TEST) {
		if (IS_BAND_24G(band))
			cli->known_bands |= BAND_2G_SUPPORTED;
		else if (IS_BAND_5G(band))
			cli->known_bands |= BAND_5G_SUPPORTED;
		else if (IS_BAND_6G(band))
			cli->known_bands |= BAND_6G_SUPPORTED;
		cli->meas_data.cli_measurement_state = MEAS_STATE_IDLE;
		err(DEBUG_CAT_AP_EST, STEER_CHAN_MEAS_PREX" supported client bands %d", cli->known_bands);
		return;
	}
#endif
#ifndef MTK_MLO_MAP_SUPPORT
	if (cli->meas_data.cli_measurement_state != MEAS_STATE_11K_TRIGGERED) {
		err(DEBUG_CAT_AP_EST, STEER_CHAN_MEAS_PREX" Stale 11k report/Channel_ID --ignore");
		return;
	}
#else
	if (cli->meas_data.cli_measurement_state != MEAS_STATE_11K_TRIGGERED) {
		if (cli->mlo_enable) {
			struct client *mld_cli_11kmeasure = find_mld_client_11kmeasure(cli);

			if (!mld_cli_11kmeasure) {
				err(DEBUG_CAT_AP_EST, STEER_CHAN_MEAS_PREX" Stale 11k report/Channel_ID --ignore");
				return;
			}
			cli = mld_cli_11kmeasure;
			err(DEBUG_CAT_AP_EST, "replace cli with mld cli");
		} else {
			err(DEBUG_CAT_AP_EST, STEER_CHAN_MEAS_PREX" Stale 11k report/Channel_ID --ignore");
			return;
		}
	}
#endif
#ifdef MTK_MLO_MAP_SUPPORT
		idx = cli->meas_data.curr_measurement_chan_idx;
		info(DEBUG_CAT_AP_EST, "idx found finally is %d", idx);
#endif
	if(!isSuccess || (channel == 0)) {
		eloop_cancel_timeout(ap_est_handle_11k_timeout, global, cli);
		err(DEBUG_CAT_AP_EST, STEER_CHAN_MEAS_PREX" 11k Failed for channel = %d",
						cli->meas_data.measurement_channels[idx].channel);

#ifdef CENT_STR
			/*Disable steering if radar detected orchannel planning or network opt is ongoing*/
			if(global->dev.cent_str_en && is_chplan_netopt_ongoing(global)){
				steer_fsm_trigger(global, cli->client_id, CHAN_MEASUREMENT_DISALLOWED, NULL);
				return;
			}
#endif
		/* Move to Next Channel */
		if(cli->meas_data.curr_measurement_chan_idx < (cli->meas_data.meas_chan_cnt - 1)) {
			cli->meas_data.curr_measurement_chan_idx++;
			idx = cli->meas_data.curr_measurement_chan_idx;
			err(DEBUG_CAT_AP_EST, STEER_CHAN_MEAS_PREX" Triggering 11k for next channel = %d",
							cli->meas_data.measurement_channels[idx].channel);
			if(ap_est_trigger_11k_channel_measurement(global,cli) == FALSE){
				err(DEBUG_CAT_AP_EST, STEER_CHAN_MEAS_PREX" Channel meas Fail");
				steer_fsm_trigger(global, cli->client_id, CHAN_MEASUREMENT_FAIL, NULL);
			}


		} else {
			err(DEBUG_CAT_AP_EST, STEER_CHAN_MEAS_PREX" Channel meas completed");
			steer_fsm_trigger(global, cli->client_id, CHAN_MEASUREMENT_COMPLETE, NULL);
		}
		return;
	}

	if(channel == 0) {
		err(DEBUG_CAT_AP_EST, STEER_CHAN_MEAS_PREX" 11k report for a 0 channel--ignore");
		return;
	}
	err(DEBUG_CAT_AP_EST, "cli->meas_data.measurement_channels[%d].channel %d, opclass %d",
		idx, cli->meas_data.measurement_channels[idx].channel,
		cli->meas_data.measurement_channels[idx].op_class);
	if (cli->meas_data.measurement_channels[idx].channel != channel) {
		err(DEBUG_CAT_AP_EST, STEER_CHAN_MEAS_PREX" 11k report for a different channel %d %d",
									cli->meas_data.measurement_channels[idx].channel,channel);
	}

	dl_rssi = (struct cli_rssi *)os_zalloc(sizeof(struct cli_rssi));
	if (dl_rssi == NULL) {
		err(DEBUG_CAT_AP_EST, STEER_CHAN_MEAS_PREX" OOM");
		assert(0);
		return;
	}

#ifdef VENDOR1_FEATURE_EXTEND
	err(DEBUG_CAT_AP_EST, STEER_CHAN_MEAS_PREX" STA:" MACSTR " BSSID:" MACSTR " RCPI:%d(0x%x) RSSI:%d",
	 MAC2STR(mac_addr), MAC2STR(bssid), rcpi, ((rcpi) & 0xff),
		rcpi_to_rssi(rcpi));
#endif //VENDOR1_FEATURE_EXTEND

#if 0
	/* 
	As per spec, a STA should awalys send RCPI in the Beacon Report.
	But its observed that most of the Non-HE STAs sending RSSI.
	Needs to  be revisted
	*/
        if(cli->phy_capab.phy_mode[band_idx] >= HE_MODE)
                dl_rssi->rssi = rcpi_to_rssi(rcpi);
        else
                dl_rssi->rssi = rcpi;

#endif
	dl_rssi->rssi = rcpi;
	curr_rssi = cli->ul_rssi[cli->radio_idx];
#ifdef CENT_STR
	if(global->dev.cent_str_en)
		curr_rssi = (signed char)client_dev->rssi_uplink;
#endif
	

	if (rcpi > 220 /*0 dbm*/
		|| (rcpi < 10 && (curr_rssi - rcpi_to_rssi(rcpi)) > 60)
		/*RCPI=-105dBm but RSSI=10 dBm*/
		|| (rcpi > 148 && (rcpi_to_rssi(rcpi) + dl_rssi->rssi - 2*curr_rssi) > 20)
		/*RCPI=-36 dBm  but RSSI = -108dBm*/
	)
		cli->rssi_based_rcpi = 1;
	else
		cli->rssi_based_rcpi = 0;

	if (!cli->rssi_based_rcpi)
		dl_rssi->rssi = rcpi_to_rssi(rcpi);

	err(DEBUG_CAT_AP_EST, MACSTR STEER_CHAN_MEAS_PREX" RSSI=%d BSSID= " MACSTR " channel %d",
		MAC2STR(mac_addr), dl_rssi->rssi, MAC2STR(bssid), channel);

	dl_rssi->channel = channel;
#ifdef MAP_6E_SUPPORT
	dl_rssi->band = band;
	cli->meas_data.curr_measured_band |= BIT(band);
#endif
	os_memcpy(&dl_rssi->bssid[0], bssid, ETH_ALEN);

#ifdef SUPPORT_MULTI_AP
	bss = topo_srv_get_bss_by_bssid(&global->dev, NULL, dl_rssi->bssid);
	if (bss == NULL) {
		err(DEBUG_CAT_AP_EST, STEER_CHAN_MEAS_PREX"bssid does not belongs to map");
		os_free(dl_rssi);
		dl_rssi = NULL;
		is_dup_bssid = 1;
	}
#endif

	dl_list_for_each(rssi_obj,&cli->meas_data.dl_rssi_list,struct cli_rssi,rssi_entry){
		if (is_dup_bssid)
			break;
#ifdef MAP_6E_SUPPORT
		if (!os_memcmp(rssi_obj->bssid, dl_rssi->bssid, ETH_ALEN))
#else
		if (!os_memcmp(rssi_obj->bssid, dl_rssi->bssid, ETH_ALEN) && rssi_obj->channel == dl_rssi->channel)
#endif
		{
			warn(DEBUG_CAT_AP_EST, "duplicate bssid: client mac:"MACSTR" bssid:"MACSTR"\n",
				MAC2STR(cli->mac_addr), MAC2STR(rssi_obj->bssid));
			warn(DEBUG_CAT_AP_EST, "channel: %d, rssi: old rssi(%d) new rssi(%d)",
				rssi_obj->channel, rssi_obj->rssi, dl_rssi->rssi);
			rssi_obj->rssi = dl_rssi->rssi;
			os_free(dl_rssi);
			dl_rssi = NULL;
			is_dup_bssid = 1;
			break;
		}
	}
	if (!is_dup_bssid)
		dl_list_add(&cli->meas_data.dl_rssi_list, &dl_rssi->rssi_entry);
	if(islastreport) {
		eloop_cancel_timeout(ap_est_handle_11k_timeout, global, cli);
		err(DEBUG_CAT_AP_EST, STEER_CHAN_MEAS_PREX" 11k Success for channel = %d",
						cli->meas_data.measurement_channels[idx].channel);
		cli->steer_stats.num_11k_succ ++;
		if(!cli->rssi_based_rcpi) {
			dl_list_for_each(rssi_obj,&cli->meas_data.dl_rssi_list,struct cli_rssi,rssi_entry){
				debug(DEBUG_CAT_AP_EST, "client mac:"MACSTR" bssid:"MACSTR" channel: %d, rssi: %d",
				MAC2STR(cli->mac_addr), MAC2STR(rssi_obj->bssid), rssi_obj->channel, rssi_obj->rssi);
			}
		}

#ifdef CENT_STR
		/*Disable steering if radar detected orchannel planning or network opt is ongoing*/
		if(global->dev.cent_str_en && is_chplan_netopt_ongoing(global)){
			steer_fsm_trigger(global, cli->client_id, CHAN_MEASUREMENT_DISALLOWED, NULL);
			return;
		}
#endif

#ifdef MAP_6E_SUPPORT
		while (cli->meas_data.curr_measurement_chan_idx < (cli->meas_data.meas_chan_cnt - 1)) {
			idx = cli->meas_data.curr_measurement_chan_idx + 1;
#ifdef SUPPORT_MULTI_AP
			if (global->dev.cent_str_en) {
				u8 next_band = get_band_6E(own_device, cli->meas_data.measurement_channels[idx].channel
					, cli->meas_data.measurement_channels[idx].op_class);
#else
				u8 next_band = bs_get_band_6E(global,
					cli->meas_data.measurement_channels[idx].channel,
					cli->meas_data.measurement_channels[idx].op_class);
#endif
				if (cli->meas_data.curr_measured_band & BIT(next_band)) {
					cli->meas_data.curr_measurement_chan_idx++;
					continue;
				} else
					break;
#ifdef SUPPORT_MULTI_AP
			} else
				break;
#endif
		}
#endif
		/* Move to next channel */
		if ((cli->meas_data.curr_measurement_chan_idx < (cli->meas_data.meas_chan_cnt - 1))) {
			cli->meas_data.curr_measurement_chan_idx++;
			idx = cli->meas_data.curr_measurement_chan_idx;
			err(DEBUG_CAT_AP_EST, STEER_CHAN_MEAS_PREX" Triggering 11k for next channel = %d",
							cli->meas_data.measurement_channels[idx].channel);
			if (ap_est_trigger_11k_channel_measurement(global,cli) == FALSE) {
				err(DEBUG_CAT_AP_EST, STEER_CHAN_MEAS_PREX" Channel meas Failed");
				steer_fsm_trigger(global, cli->client_id, CHAN_MEASUREMENT_FAIL, NULL);
			}
		} else {
			/* Trigger Complete */
			err(DEBUG_CAT_AP_EST, STEER_CHAN_MEAS_PREX" Channel meas completed");
			steer_fsm_trigger(global, cli->client_id, CHAN_MEASUREMENT_COMPLETE, NULL);
		}
	}
}
#ifdef SUPPORT_MULTI_AP
/**
* @brief timeout happened for air monitor response. trigger the state machine
*
* @param eloop_ctx pointer to the global structure
* @param user_ctx client for which air monitor timeout happened
*/
static void ap_est_air_mon_timeout(void *eloop_ctx, void *user_ctx)
{
	struct mapd_global *pGlobal_dev = eloop_ctx;
	struct client *map_client = user_ctx;


	info(DEBUG_CAT_AP_EST, "Air Mon Timedout");
	info(DEBUG_CAT_AP_EST, "Trigger FSM (CHAN_MEASUREMENT_COMPLETE)");

				steer_fsm_trigger(pGlobal_dev, map_client->client_id, CHAN_MEASUREMENT_COMPLETE, NULL);
}

/**
* @brief trigger air monitor for the client. send un-assoc link metric query to all devices that support it and wait for their response.
*
* @param pGlobal_dev pointer to the global structure
* @param client_id client for which air monitor see
*/
Boolean ap_est_trigger_air_mon(struct mapd_global *pGlobal_dev,int client_id)
{
	struct _1905_map_device *_1905_device = NULL;
	struct client *map_client = client_db_get_client_from_client_id(pGlobal_dev, client_id);

	if(map_client == NULL) {
		err(DEBUG_CAT_AP_EST, "invalid client id");
		assert(0);
	}
	
	_1905_device = topo_srv_get_next_1905_device(&pGlobal_dev->dev, NULL); /*Get own device struct.*/
	_1905_device = topo_srv_get_next_1905_device(&pGlobal_dev->dev, _1905_device);

	if(_1905_device == NULL) {
		err(DEBUG_CAT_AP_EST, "Multiple devices not present. Can't reach here.");
		return FALSE;
	}

	while(_1905_device) {
		struct bss_info_db *map_bss = topo_srv_get_next_bss(_1905_device, NULL);

		while (_1905_device->in_network && map_bss != NULL) {

		if (map_bss && !map_bss->radio) {
			err(DEBUG_CAT_AP_EST, CENT_STEER_PREX"radio is null");
			map_bss = topo_srv_get_next_bss(_1905_device, map_bss);
			continue;
		}

			if(map_client->current_chan == map_bss->radio->channel[0] ||
				map_client->current_chan == map_bss->radio->channel[1] ||
				map_client->current_chan == map_bss->radio->channel[2] ||
				map_client->current_chan == map_bss->radio->channel[3] ||
				map_client->current_chan == map_bss->radio->channel[4] ||
				map_client->current_chan == map_bss->radio->channel[5] ||
				map_client->current_chan == map_bss->radio->channel[6] ||
#ifdef MAP_EHT_SUPPORT
				map_client->current_chan == map_bss->radio->channel[7] ||
				map_client->current_chan == map_bss->radio->channel[8] ||
				map_client->current_chan == map_bss->radio->channel[9] ||
				map_client->current_chan == map_bss->radio->channel[10] ||
				map_client->current_chan == map_bss->radio->channel[11] ||
				map_client->current_chan == map_bss->radio->channel[12] ||
				map_client->current_chan == map_bss->radio->channel[13] ||
				map_client->current_chan == map_bss->radio->channel[14] ||
				map_client->current_chan == map_bss->radio->channel[15]) {
#else
				map_client->current_chan == map_bss->radio->channel[7]) {
#endif
				struct unassoc_sta_link_metrics_query *metric_query = os_zalloc(sizeof(struct unassoc_sta_link_metrics_query ) + sizeof(struct unassoc_sta_link_metrics_query_sub));
				int ret = 0;
				struct bss_air_mon_report *air_mon_bss = os_zalloc(sizeof(struct bss_air_mon_report));
				if (!metric_query) {
					err(DEBUG_CAT_AP_EST, "can't alloc mem\n");
					assert(0);
				}
				if(air_mon_bss == NULL) {
					err(DEBUG_CAT_AP_EST, "can't alloc mem\n");
					if (metric_query)
						os_free(metric_query);
					assert(0);
				}
				//os_memset(&metric_query,0,sizeof(struct unassoc_sta_link_metrics_query));
				os_memcpy(air_mon_bss->al_mac, _1905_device->_1905_info.al_mac_addr, ETH_ALEN);
				os_memcpy(air_mon_bss->bssid, map_bss->bssid, ETH_ALEN);
				air_mon_bss->report_received = 0;
				air_mon_bss->rssi = -110;
				metric_query->ch_num = 1;
				metric_query->op_class = map_bss->radio->operating_class;
				
				metric_query->unassoc_link_query_sub[0].channel = map_client->current_chan;
				metric_query->unassoc_link_query_sub[0].sta_num = 1;
				os_memcpy(&metric_query->unassoc_link_query_sub[0].sta_mac[0], map_client->mac_addr, ETH_ALEN);
				
				ret = map_1905_Send_Unassociated_STA_Link_Metrics_Query_Message(pGlobal_dev->_1905_ctrl,
						(char *)_1905_device->_1905_info.al_mac_addr, metric_query);
				os_free(metric_query);
				if(ret == 0) {
					SLIST_INSERT_HEAD(&map_client->meas_data.air_mon_bss_head, air_mon_bss,air_mon_bss_entry);
					// Make sure to free this memory after steering.
					map_client->meas_data.air_mon_sent_cnt++;
					break;
				}
				else
					os_free(air_mon_bss);
			}
			map_bss = topo_srv_get_next_bss(_1905_device, map_bss);
		}
		_1905_device = topo_srv_get_next_1905_device(&pGlobal_dev->dev,_1905_device);
	}
	
	if(!SLIST_EMPTY(&(map_client->meas_data.air_mon_bss_head))) {
		map_client->meas_data.cli_measurement_state = MEAS_STATE_AIR_MON_TRIGGERED;
		map_client->meas_data.air_mon_timer_running = TRUE;
		err(DEBUG_CAT_AP_EST, "Air Mon Triggered on channel %d", map_client->current_chan);
		eloop_register_timeout(AIR_MON_TIMEOUT, 0,ap_est_air_mon_timeout,pGlobal_dev,map_client);
	}
	else
		return FALSE;

	return TRUE;
}

#ifdef CENT_STR
#ifdef MTK_MLO_MAP_SUPPORT
/* We need to Trigger Air monitor for all MLD stations corresponding to map_client in assoc client list*/
int trigger_mlo_stas_air_mon(
	struct mapd_global *pGlobal_dev,
	struct client *map_client,
	struct _1905_map_device *_1905_device,
	struct bss_info_db *map_bss)
{
	uint32_t idx = 0;
	int ret = 0;
	struct client *mld_client;
	struct bss_air_mon_report *air_mon_bss = NULL;
	struct _1905_map_device *curr_1905_device = NULL;
	struct bss_info_db *new_bss = NULL, *curr_bss = NULL, *tbss = NULL;

	for (idx = 0; idx < MAX_MLD_CLI; ++idx) {
		if (!map_client->mld_clients[idx]) {
			err(DEBUG_CAT_AP_EST, "Continue as mld sister is NULL");
			continue;
		}
		if (os_memcmp(map_client->mld_clients[idx]->mld_addr, map_client->mld_addr, ETH_ALEN)) {
			err(DEBUG_CAT_AP_EST, "continue as MLD address mismatch");
			continue;
		}
		mld_client = map_client->mld_clients[idx];
		err(DEBUG_CAT_AP_EST, "mld_client-mac address "MACSTR"\n", MAC2STR(mld_client->mac_addr));
		air_mon_bss = os_zalloc(sizeof(struct bss_air_mon_report));
		if (!air_mon_bss) {
			err(DEBUG_CAT_AP_EST, "Memory allocation fail return");
			return -1;
		}
		curr_1905_device = topo_srv_get_1905_by_bssid(&pGlobal_dev->dev, (unsigned char *)mld_client->bssid);
		if (!curr_1905_device) {
			err(DEBUG_CAT_AP_EST, "curr_1905_device is NULL fail return");
			os_free(air_mon_bss);
			continue;
		}
		err(DEBUG_CAT_AP_EST, "mld_client->bssid "MACSTR" curr_1905_device almac "MACSTR"\n",
			MAC2STR(mld_client->bssid), MAC2STR(curr_1905_device->_1905_info.al_mac_addr));
		curr_bss = topo_srv_get_bss(curr_1905_device, (char *)mld_client->bssid);
		if (curr_bss == NULL) {
			if (air_mon_bss) {
				os_free(air_mon_bss);
//				air_mon_bss = NULL;
			}
			continue;
		}
		SLIST_FOREACH_SAFE(new_bss, &_1905_device->first_bss, next_bss, tbss) {
#ifdef MAP_R6
			if (!new_bss->radio) {
				err(DEBUG_CAT_AP_EST, "new_bss radio is null for bssid " MACSTR"\n", MAC2STR(new_bss->bssid));
				continue;
			}
			if (!curr_bss->radio) {
				err(DEBUG_CAT_AP_EST, "curr_bss radio is null for bssid " MACSTR"\n", MAC2STR(curr_bss->bssid));
				continue;
			}
#endif /* MAP_R6 */
			if (new_bss->radio->band != curr_bss->radio->band)
				continue;
			if (os_memcmp(curr_bss->ssid, new_bss->ssid, curr_bss->ssid_len))
				continue;
			os_memcpy(air_mon_bss->bssid, new_bss->bssid, ETH_ALEN);
			break;
		}
		if (_1905_device->device_role == DEVICE_ROLE_AGENT) {
			struct unassoc_sta_link_metrics_query *metric_query =
				os_zalloc(sizeof(struct unassoc_sta_link_metrics_query) +
				sizeof(struct unassoc_sta_link_metrics_query_sub));
			if (!metric_query) {
				err(DEBUG_CAT_AP_EST, CENT_STEER_PREX"can't alloc mem\n");
				os_free(air_mon_bss);
				return -1;
			}
			os_memcpy(air_mon_bss->al_mac, _1905_device->_1905_info.al_mac_addr, ETH_ALEN);
			air_mon_bss->report_received = 0;
			air_mon_bss->rssi = -110;
			metric_query->ch_num = 1;
			metric_query->op_class =
				chan_mon_get_op_class_frm_channel(mld_client->current_chan, BW20, mld_client->current_band);
			metric_query->unassoc_link_query_sub[0].channel = mld_client->current_chan;
			metric_query->unassoc_link_query_sub[0].sta_num = 1;
			os_memcpy(&metric_query->unassoc_link_query_sub[0].sta_mac[0], &mld_client->mac_addr[0], ETH_ALEN);
			err(DEBUG_CAT_AP_EST,
			 "send air mon req to agent on channel %d air_mon_bss->al_mac "MACSTR" air_mon_bss->bssid "MACSTR"\n",
			  mld_client->current_chan, MAC2STR(air_mon_bss->al_mac),
			   MAC2STR(air_mon_bss->bssid));
			ret = map_1905_Send_Unassociated_STA_Link_Metrics_Query_Message(pGlobal_dev->_1905_ctrl,
					(char *)_1905_device->_1905_info.al_mac_addr, metric_query);
			os_free(metric_query);
		} else {
			u8 unlink_query[100];
			struct unlink_metrics_query *p_unlink_query = (struct unlink_metrics_query *)unlink_query;
			int query_len = 0;

			os_memcpy(air_mon_bss->al_mac, _1905_device->_1905_info.al_mac_addr, ETH_ALEN);
			air_mon_bss->report_received = 0;
			air_mon_bss->rssi = -110;
			p_unlink_query->ch_num = 1;
			p_unlink_query->oper_class =
				chan_mon_get_op_class_frm_channel(mld_client->current_chan, BW20, mld_client->current_band);
			p_unlink_query->ch_list[0] = mld_client->current_chan;
			p_unlink_query->sta_num = 1;
			os_memcpy(&p_unlink_query->sta_list[0], &mld_client->mac_addr[0], ETH_ALEN);
			query_len = sizeof(struct unlink_metrics_query) + p_unlink_query->sta_num * ETH_ALEN;
			err(DEBUG_CAT_AP_EST,
			 "send air mon to own dev on ch %d air_mon_bss->al_mac "MACSTR" air_mon_bss->bssid "MACSTR"\n",
				mld_client->current_chan, MAC2STR(air_mon_bss->al_mac), MAC2STR(air_mon_bss->bssid));
			ret = map_get_info_from_wapp(&pGlobal_dev->dev,
					WAPP_USER_SET_AIR_MONITOR_REQUEST,
					0, NULL, NULL,
					(void *)p_unlink_query, query_len);
		}
		if (ret == 0) {
			SLIST_INSERT_HEAD(&map_client->meas_data.air_mon_bss_head, air_mon_bss, air_mon_bss_entry);
			map_client->meas_data.air_mon_sent_cnt++;
		} else {
			os_free(air_mon_bss);
			return 1;
		}
	}
	return 0;
}
#endif
#if defined(MAP_6E_SUPPORT) && defined(MAP_R6)
int cosr_create_multi_sta_air_mon_list(
	struct client *map_client,
	struct _1905_map_device *_1905_device,
	struct bss_info_db *map_bss,
	unsigned char *buf)
{
	struct bss_air_mon_report *air_mon_bss = NULL;
	int sta_num = 0;

	if (!buf || !map_bss) {
		err(DEBUG_CAT_AP_EST, "input buf or map_bss is null");
		return -1;
	}

#ifdef MAP_R6
	if (!map_bss->radio) {
		err(DEBUG_CAT_AP_EST, "map_bss->radio is null for bssid " MACSTR"\n", MAC2STR(map_bss->bssid));
		return -1;
	}
#endif /* MAP_R6 */

	air_mon_bss = os_zalloc(sizeof(struct bss_air_mon_report));

	if (!air_mon_bss) {
		err(DEBUG_CAT_AP_EST, "Memory allocation fail return");
		return -1;
	}

	os_memcpy(air_mon_bss->al_mac, _1905_device->_1905_info.al_mac_addr, ETH_ALEN);
	os_memcpy(air_mon_bss->bssid, map_bss->bssid, ETH_ALEN);
	air_mon_bss->report_received = 0;
	air_mon_bss->rssi = -110;
	if (_1905_device->device_role == DEVICE_ROLE_AGENT) {
		struct unassoc_sta_link_metrics_query *metric_query = (struct unassoc_sta_link_metrics_query *) buf;

		sta_num = metric_query->unassoc_link_query_sub[0].sta_num;
		if (sta_num == 0) {
			metric_query->ch_num = 1;
			metric_query->op_class = map_bss->radio->operating_class;
			metric_query->unassoc_link_query_sub[0].channel = map_client->current_chan;
		}
		metric_query->unassoc_link_query_sub[0].sta_num++;
		os_memcpy(&metric_query->unassoc_link_query_sub[0].sta_mac[ETH_ALEN * sta_num]
						, map_client->mac_addr, ETH_ALEN);
	} else {
		struct unlink_metrics_query *p_unlink_query = (struct unlink_metrics_query *)buf;

		sta_num = p_unlink_query->sta_num;
		if (sta_num == 0) {
			p_unlink_query->ch_num = 1;
			p_unlink_query->oper_class = map_bss->radio->operating_class;
			p_unlink_query->ch_list[0] = map_client->current_chan;
		}
		p_unlink_query->sta_num++;
		os_memcpy(&p_unlink_query->sta_list[ETH_ALEN * sta_num], map_client->mac_addr, ETH_ALEN);
	}
	SLIST_INSERT_HEAD(&map_client->meas_data.air_mon_bss_head, air_mon_bss, air_mon_bss_entry);
	map_client->meas_data.air_mon_sent_cnt++;
	err(DEBUG_CAT_AP_EST, ".");
	return 0;
}
#endif /* MAP_6E_SUPPORT and MAP_R6 */


int trigger_sta_air_mon(
	struct mapd_global *pGlobal_dev,
	struct client *map_client,
	struct _1905_map_device *_1905_device,
	struct bss_info_db *map_bss)
{
	struct bss_air_mon_report *air_mon_bss = os_zalloc(sizeof(struct bss_air_mon_report));
	int ret = 0;

	if (!air_mon_bss) {
		err(DEBUG_CAT_AP_EST, "Memory allocation fail return");
		return -1;
	}
#ifdef MAP_R6
	if (!map_bss->radio) {
		err(DEBUG_CAT_AP_EST,
		 "map_bss->radio is null for bssid " MACSTR"\n", MAC2STR(map_bss->bssid));
		os_free(air_mon_bss);
		return -1;
	}
#endif /* MAP_R6 */

	if (_1905_device->device_role == DEVICE_ROLE_AGENT) {
		struct unassoc_sta_link_metrics_query *metric_query =
			os_zalloc(sizeof(struct unassoc_sta_link_metrics_query) + sizeof(struct unassoc_sta_link_metrics_query_sub));
		if (!metric_query) {
			os_free(air_mon_bss);
			err(DEBUG_CAT_AP_EST, CENT_STEER_PREX"can't alloc mem\n");
			return -1;
		}
		os_memcpy(air_mon_bss->al_mac, _1905_device->_1905_info.al_mac_addr, ETH_ALEN);
		os_memcpy(air_mon_bss->bssid, map_bss->bssid, ETH_ALEN);
		air_mon_bss->report_received = 0;
		air_mon_bss->rssi = -110;
		metric_query->ch_num = 1;
		metric_query->op_class = map_bss->radio->operating_class;
		metric_query->unassoc_link_query_sub[0].channel = map_client->current_chan;
		metric_query->unassoc_link_query_sub[0].sta_num = 1;
		os_memcpy(&metric_query->unassoc_link_query_sub[0].sta_mac[0], map_client->mac_addr, ETH_ALEN);
		ret = map_1905_Send_Unassociated_STA_Link_Metrics_Query_Message(pGlobal_dev->_1905_ctrl,
				(char *)_1905_device->_1905_info.al_mac_addr, metric_query);
		os_free(metric_query);
	} else {
		u8 unlink_query[100];
		struct unlink_metrics_query *p_unlink_query = (struct unlink_metrics_query *)unlink_query;
		int query_len = 0;

		os_memcpy(air_mon_bss->al_mac, _1905_device->_1905_info.al_mac_addr, ETH_ALEN);
		os_memcpy(air_mon_bss->bssid, map_bss->bssid, ETH_ALEN);
		air_mon_bss->report_received = 0;
		air_mon_bss->rssi = -110;
		p_unlink_query->ch_num = 1;
		p_unlink_query->oper_class = map_bss->radio->operating_class;
		p_unlink_query->ch_list[0] = map_client->current_chan;
		p_unlink_query->sta_num = 1;
		os_memcpy(&p_unlink_query->sta_list[0], map_client->mac_addr, ETH_ALEN);
		query_len = sizeof(struct unlink_metrics_query) + p_unlink_query->sta_num * ETH_ALEN;
		ret = map_get_info_from_wapp(&pGlobal_dev->dev,
				WAPP_USER_SET_AIR_MONITOR_REQUEST,
				0, NULL, NULL,
				(void *)p_unlink_query, query_len);
	}
	if (ret == 0) {
		SLIST_INSERT_HEAD(&map_client->meas_data.air_mon_bss_head, air_mon_bss, air_mon_bss_entry);
		map_client->meas_data.air_mon_sent_cnt++;
	} else {
		os_free(air_mon_bss);
		return 1;
	}
	return 0;
}
Boolean ap_est_trigger_air_mon_cent_str(struct mapd_global *pGlobal_dev,int client_id)
{

	struct client *map_client = client_db_get_client_from_client_id(pGlobal_dev, client_id);
	struct _1905_map_device *cur_1905_device = NULL;
	struct _1905_map_device *_1905_device = NULL;
	struct bss_info_db *map_bss = NULL;
	int ret = 0;

	if (map_client == NULL) {
		err(DEBUG_CAT_AP_EST, CENT_STEER_PREX"invalid client id");
		return FALSE;
	}
	cur_1905_device = topo_srv_get_1905_by_bssid(&pGlobal_dev->dev, map_client->bssid);
	if (cur_1905_device == NULL) {
		err(DEBUG_CAT_AP_EST, CENT_STEER_PREX"current 1905 device is NULL");
		return FALSE;
	}
	_1905_device = topo_srv_get_next_1905_device(&pGlobal_dev->dev, NULL); /*Get own device struct.*/
	if (_1905_device == NULL) {
		err(DEBUG_CAT_AP_EST, CENT_STEER_PREX"Multiple devices not present. Can't reach here.");
		return FALSE;
	}
	while(_1905_device) {
		
		if(_1905_device == cur_1905_device){
			_1905_device = topo_srv_get_next_1905_device(&pGlobal_dev->dev,_1905_device);
			continue;
		}
		
		map_bss = topo_srv_get_next_bss(_1905_device, NULL);
		while (_1905_device->in_network && map_bss != NULL) {
#ifdef MAP_R6
			if (!map_bss->radio) {
				err(DEBUG_CAT_AP_EST, "map_bss->radio is null for bssid " MACSTR"\n", MAC2STR(map_bss->bssid));
				map_bss = topo_srv_get_next_bss(_1905_device, map_bss);
				continue;
			}
#endif /* MAP_R6 */

			if (match_channel_from_ch_grp(map_bss->radio->channel, map_client->current_chan)) {
#ifndef MTK_MLO_MAP_SUPPORT
				ret = trigger_sta_air_mon(pGlobal_dev, map_client, _1905_device, map_bss);
#else
				if (map_client->mlo_enable)
					ret = trigger_mlo_stas_air_mon(pGlobal_dev, map_client, _1905_device, map_bss);
				else
					ret = trigger_sta_air_mon(pGlobal_dev, map_client, _1905_device, map_bss);
#endif
				if (ret == 0)
					break;
			}
			map_bss = topo_srv_get_next_bss(_1905_device, map_bss);
		}
		_1905_device = topo_srv_get_next_1905_device(&pGlobal_dev->dev,_1905_device);
	}
	
	if(!SLIST_EMPTY(&(map_client->meas_data.air_mon_bss_head))) {
		map_client->meas_data.cli_measurement_state = MEAS_STATE_AIR_MON_TRIGGERED;
		map_client->meas_data.air_mon_timer_running = TRUE;
		err(DEBUG_CAT_AP_EST, CENT_STEER_PREX"Air Mon Triggered on channel %d", map_client->current_chan);
		eloop_register_timeout(AIR_MON_TIMEOUT, 0,ap_est_air_mon_timeout,pGlobal_dev,map_client);
	}
	else
		return FALSE;

	return TRUE;
}

#if defined(MAP_6E_SUPPORT) && defined(MAP_R6)
void ap_est_handle_own_unassoc_ap_metric_rsp(struct mapd_global *pGlobal_dev,
						char *al_mac, struct unassoc_sta_1905_link_metric *metrics)
{
	struct own_1905_device *ctx = &pGlobal_dev->dev;
	struct _1905_map_device *_1905_device = NULL;

	_1905_device = topo_srv_get_1905_device(&pGlobal_dev->dev, NULL);

	if (_1905_device == NULL)
		return;

	cosr_fill_ap_air_mon_results(ctx, _1905_device, (u8 *)al_mac, metrics);
}
#endif /* MAP_6E_SUPPORT and MAP_R6 */


void ap_est_handle_own_unassoc_sta_link_metric_rsp(struct mapd_global *pGlobal_dev,
						struct unassoc_link_metric_rsp *unassoc_link_metric_msg,
						u32 msg_len)
{
	struct _1905_map_device *_1905_device = NULL;
	struct client * map_client = NULL;
	u8 cli_cnt = 0, i=0;
#ifdef MTK_MLO_MAP_SUPPORT
	u8 j = 0;
	struct client *reported_client = NULL;
#endif
	struct bss_air_mon_report *air_mon_report = NULL, *tmp_air_mon_report = NULL;
#ifdef CENT_STR	
	struct own_1905_device *dev = &pGlobal_dev->dev;
#endif
	_1905_device = topo_srv_get_1905_device(&pGlobal_dev->dev,NULL);


	cli_cnt = unassoc_link_metric_msg->sta_num;
/*
	if(cli_cnt > 1) {
		err(DEBUG_CAT_AP_EST, CENT_STEER_PREX"Cli cnt: %d. Something is wrong\n", cli_cnt);
	}
*/

	for(i=0; i < cli_cnt; i++) {
		u8 *cli_mac = unassoc_link_metric_msg->sta_link_metric[i].cli_mac;

		map_client = client_db_get_client_from_sta_mac(pGlobal_dev,cli_mac);
		err(DEBUG_CAT_AP_EST, "cli mac is "MACSTR"", MAC2STR(cli_mac));
		if (!map_client) {
			err(DEBUG_CAT_AP_EST, "map_client is NULL");
#if defined(MAP_6E_SUPPORT) && defined(MAP_R6)
			if (dev->cosr_mode != 0) {
				struct _1905_map_device *cosr_air_dev = topo_srv_get_1905_by_bssid(dev,
									unassoc_link_metric_msg->sta_link_metric[i].cli_mac);

				if (cosr_air_dev != NULL)
					ap_est_handle_own_unassoc_ap_metric_rsp(pGlobal_dev, (char *)cosr_air_dev->_1905_info.al_mac_addr,
					(struct unassoc_sta_1905_link_metric *)&unassoc_link_metric_msg->sta_link_metric[i]);
			}
#endif /* MAP_6E_SUPPORT and MAP_R6 */
		} else {
			err(DEBUG_CAT_AP_EST, "cli_steer_state %d, cli_measurement_state %d",
			 map_client->cli_steer_state, map_client->meas_data.cli_measurement_state);
		}

/*For MLO case need to add check that either map_client_or any of the mld_clients of this map client have air monitor triggered*/
#ifndef MTK_MLO_MAP_SUPPORT
		if (map_client == NULL
		|| map_client->cli_steer_state != CLI_STATE_STEER_DECISION
		|| map_client->meas_data.cli_measurement_state != MEAS_STATE_AIR_MON_TRIGGERED) {
			err(DEBUG_CAT_AP_EST, "continue");
			continue;
		}
#else
		if (map_client == NULL)
			continue;
		reported_client = map_client;
		if (!map_client->mlo_enable) {
			if (!((map_client->cli_steer_state == CLI_STATE_STEER_DECISION
			&& map_client->meas_data.cli_measurement_state == MEAS_STATE_AIR_MON_TRIGGERED)
#if defined(MAP_6E_SUPPORT) && defined(MAP_R6)
			|| map_client->cosr_air_monitor == 1
#endif /* MAP_6E_SUPPORT and MAP_R6 */
			))
				continue;
		} else {
			for (j = 0; j < MAX_MLD_CLI; j++) {
				if (!map_client->mld_clients[j])
					continue;
				if (map_client->mld_clients[j]->cli_steer_state == CLI_STATE_STEER_DECISION
					|| map_client->mld_clients[j]->meas_data.cli_measurement_state == MEAS_STATE_AIR_MON_TRIGGERED) {
					map_client = map_client->mld_clients[j];
					err(DEBUG_CAT_AP_EST, "map_client was steer cand , mld client was , so replace");
					break;
				}
			}
		}
#endif
		err(DEBUG_CAT_AP_EST, "map_client is on channel %d", map_client->current_chan);
		if(!SLIST_EMPTY(&(map_client->meas_data.air_mon_bss_head)))
		{
			SLIST_FOREACH_SAFE(air_mon_report, &(map_client->meas_data.air_mon_bss_head),
												air_mon_bss_entry, tmp_air_mon_report)
			{
				if(!os_memcmp(air_mon_report->al_mac, _1905_device->_1905_info.al_mac_addr, ETH_ALEN)) {
#ifdef MTK_MLO_MAP_SUPPORT
					struct bss_info_db *bss = topo_srv_get_bss(_1905_device, (char *)air_mon_report->bssid);
					err(DEBUG_CAT_AP_EST, "map_client is on channel %d", map_client->current_chan);
					if (bss == NULL)
						continue;
#ifdef MAP_R6
					if (!bss->radio) {
						err(DEBUG_CAT_AP_EST, "bss radio is null for bssid " MACSTR"\n", MAC2STR(bss->bssid));
						continue;
					}
#endif /* MAP_R6 */
					err(DEBUG_CAT_AP_EST,
					 "bss->band %d air mon bssid "MACSTR" reported_client current band %d channel %d",
					  bss->radio->band,
					  MAC2STR(air_mon_report->bssid),
						reported_client->current_band,
						reported_client->current_chan);
					if (bss->radio->band != reported_client->current_band)
						continue;
#endif
					err(DEBUG_CAT_AP_EST,
					 " air_mon_report->report_received %d, map_client->meas_data.air_mon_rx_cnt %d",
					  air_mon_report->report_received, map_client->meas_data.air_mon_rx_cnt);
					if (air_mon_report->report_received  == 1)
						continue;
					air_mon_report->rssi = (unassoc_link_metric_msg->sta_link_metric[i].rssi);
					air_mon_report->delta_time = unassoc_link_metric_msg->sta_link_metric[i].delta_time;
					air_mon_report->report_received  = 1;
					err(DEBUG_CAT_CH_PL,
					CENT_STEER_PREX"AirMon result :BSS: %x:%x:%x:%x:%x:%x AL= %x:%x:%x:%x:%x:%x: RSSI: %d",
						PRINT_MAC(air_mon_report->bssid),
						PRINT_MAC(air_mon_report->al_mac),
						air_mon_report->rssi);
#if defined(MAP_6E_SUPPORT) && defined(MAP_R6)
					if (map_client->cosr_air_monitor != 1)
#endif /* MAP_6E_SUPPORT and MAP_R6 */
						map_client->meas_data.air_mon_rx_cnt++;
					break;
				}
			}
		}

#ifdef CENT_STR
			/*Disable steering if radar detected orchannel planning or network opt is ongoing*/
			if(dev->cent_str_en && is_chplan_netopt_ongoing(pGlobal_dev)){
				eloop_cancel_timeout(ap_est_air_mon_timeout, pGlobal_dev,map_client);
				steer_fsm_trigger(pGlobal_dev, map_client->client_id, CHAN_MEASUREMENT_DISALLOWED, NULL);
				return;					
			
			}
#endif
		err(DEBUG_CAT_AP_EST, "map_client->meas_data.air_mon_sent_cnt %d, map_client->meas_data.air_mon_rx_cnt %d",
		map_client->meas_data.air_mon_sent_cnt, map_client->meas_data.air_mon_rx_cnt);
#if defined(MAP_6E_SUPPORT) && defined(MAP_R6)
		if (map_client->cosr_air_monitor == 1) {
			if (dev->air_mon_sta_cnt > 0) {
				dev->airmon_complete_cnt++;
				if (dev->air_mon_sta_cnt == dev->airmon_complete_cnt) {
					if (eloop_is_timeout_registered(cosr_sta_airmonitor_timeout_handler, dev, NULL))
						eloop_cancel_timeout(cosr_sta_airmonitor_timeout_handler, dev, NULL);
					cosr_sta_airmonitor_timeout_handler((void *)dev, NULL);
				}
			}
		} else
#endif /* MAP_6E_SUPPORT and MAP_R6 */
			if (map_client->meas_data.air_mon_rx_cnt == map_client->meas_data.air_mon_sent_cnt) {

				err(DEBUG_CAT_AP_EST, CENT_STEER_PREX"All air mon rsp received-->SUCCESS");
				eloop_cancel_timeout(ap_est_air_mon_timeout, pGlobal_dev, map_client);
				info(DEBUG_CAT_AP_EST, CENT_STEER_PREX"Trigger FSM (CHAN_MEASUREMENT_COMPLETE)");
				steer_fsm_trigger(pGlobal_dev, map_client->client_id, CHAN_MEASUREMENT_COMPLETE, NULL);
			}
	}
}


void topo_srv_trigger_beacon_metrics_query(struct mapd_global *global, struct _1905_map_device *dev,u8 *sta_mac,
				u8 *assoc_bssid, u8 ssid_len, u8 *ssid,
				u8 channel, u8 op_class, u8 *bssid,
				u8 rpt_detail, u8 num_elem, char *elem_list,
				u8 num_chrep, struct ap_chn_rpt *chan_rpt)
{
	struct beacon_metrics_query *bcn_query = NULL;
	struct ap_chn_rpt *chn_rpt = NULL;
	uint8_t i = 0;


	if (!dev) {
		err(DEBUG_CAT_AP_EST, CENT_STEER_PREX"dev is NULL");
		return;
	}

	err(DEBUG_CAT_AP_EST, CENT_STEER_PREX"Preparing to send Beacon metrics query to agent (" MACSTR ")",
	 MAC2STR(dev->_1905_info.al_mac_addr));

	bcn_query = (struct beacon_metrics_query *)
			os_zalloc(sizeof(struct beacon_metrics_query) + num_chrep * sizeof(struct ap_chn_rpt));
	if (!bcn_query) {
		err(DEBUG_CAT_AP_EST, CENT_STEER_PREX"FAILED OOM");
		return;
	}

	os_memcpy(bcn_query->sta_mac, sta_mac, ETH_ALEN);
	os_memcpy(bcn_query->bssid, bssid, ETH_ALEN);
	bcn_query->ssid_len = ssid_len;
	bcn_query->ch = channel;
	bcn_query->oper_class = op_class;
	os_memcpy(bcn_query->ssid, ssid, ssid_len);
	bcn_query->rpt_detail_val = rpt_detail;

	/*ap channel report info*/
	bcn_query->ap_ch_rpt_num = num_chrep;
	chn_rpt = bcn_query->rpt;
	for (i = 0; i < num_chrep; i++) {
			chn_rpt->ch_rpt_len = chan_rpt->ch_rpt_len;
			chn_rpt->oper_class = chan_rpt->oper_class;
			if (chan_rpt->ch_rpt_len - 1 <= ARRAY_SIZE(chn_rpt->ch_list))
				memcpy(chn_rpt->ch_list, chan_rpt->ch_list, chan_rpt->ch_rpt_len - 1);
			else
				memcpy(chn_rpt->ch_list, chan_rpt->ch_list, ARRAY_SIZE(chn_rpt->ch_list));
			chn_rpt++;
	}

	bcn_query->elemnt_num = num_elem;
	if (num_elem > MAX_ELEMNT_NUM)
			bcn_query->elemnt_num = MAX_ELEMNT_NUM;
	os_memcpy(bcn_query->elemnt_list, elem_list, bcn_query->elemnt_num);

	map_1905_Send_Beacon_Metrics_Query_Message(global->_1905_ctrl,(char *)dev->_1905_info.al_mac_addr ,bcn_query);
	
	os_free(bcn_query);
}

#endif

#endif
/**
 * @brief : Trigger channel measurement (802.11k or air monitor as required), called
 * from the state machine when decision state is active for a client
 *
 * @param pGlobal_dev: Global device pointer
 * @param client_id: client ID of client for which measurement is to be triggered
 * @param data: Decision state specific data containing steering type
 */
Boolean ap_est_trigger_channel_measurement(struct mapd_global *pGlobal_dev,
		int client_id, DECISION_DATA *data)
{
	struct client *map_client = client_db_get_client_from_client_id(pGlobal_dev, client_id);
#if defined(ROAM_CALIB)
	char str[150] = {0};
	int res;
#endif

	if(map_client == NULL) {
		err(DEBUG_CAT_AP_EST, STEER_CHAN_MEAS_PREX" invalid client id:%d", client_id);
		mapd_ASSERT(0);
		return FALSE;
	}
	if((map_client->capab & CLI_CAP_11K) &&
		(map_client->force_airmon != 1)) {
#if defined(ROAM_CALIB)
		if (pGlobal_dev->dev.RoamCalibEnable) {
			res = os_snprintf(str, sizeof(str), "11k Beacon measurement trigger");
			if (os_snprintf_error(sizeof(str), res)) {
				err(DEBUG_CAT_AP_EST, "Too long GET command.\n");
				return FALSE;
			}
			if (map_client)
				RoamingCaldata(&pGlobal_dev->dev, (u8 *)map_client->mac_addr, NULL, str, __func__);
		}
#endif
		return ap_est_trigger_11k_channel_measurement(pGlobal_dev, map_client);
	} else {
#ifdef SUPPORT_MULTI_AP
		/* Should reach here only when the clien is idle */
		/* For Legacy(non 11k) or 11k failed(force_airmon) idle clients */
		map_client->force_airmon = 0;
#if defined(ROAM_CALIB)
		if (pGlobal_dev->dev.RoamCalibEnable) {
			res = os_snprintf(str, sizeof(str), "Airmonitor trigger");
			if (os_snprintf_error(sizeof(str), res)) {
				err(DEBUG_CAT_AP_EST, "Too long GET command.\n");
				return FALSE;
			}
			if (map_client)
				RoamingCaldata(&pGlobal_dev->dev, (u8 *)map_client->mac_addr, NULL, str, __func__);
		}
#endif
#ifdef CENT_STR
			if (pGlobal_dev->dev.cent_str_en)
				return ap_est_trigger_air_mon_cent_str(pGlobal_dev, client_id);
			else
#endif		
		return ap_est_trigger_air_mon(pGlobal_dev, client_id);
#else
		return FALSE;
#endif
	}
}
#ifdef SUPPORT_MULTI_AP
/**
 * @brief : handle unassoc sta link metrics
 *
 * @param pGlobal_dev
 * @param unassoc_link_metric_msg
 * @param msg_len
 */
#if defined(MAP_6E_SUPPORT) && defined(MAP_R6)
void ap_est_handle_unassoc_ap_metric_rsp(struct mapd_global *pGlobal_dev, struct _1905_map_device *dev,
						char *al_mac, struct unassoc_sta_1905_link_metric *metrics)
{
	struct own_1905_device *ctx = &pGlobal_dev->dev;
	struct _1905_map_device *_1905_device = NULL;

	_1905_device = topo_srv_get_1905_by_bssid(ctx, metrics->cli_mac);

	if (_1905_device == NULL)
		return;

	cosr_fill_ap_air_mon_results(ctx, dev, (u8 *)_1905_device->_1905_info.al_mac_addr, metrics);
}
#endif /* MAP_6E_SUPPORT and MAP_R6 */

void ap_est_handle_unassoc_sta_link_metric_rsp(struct mapd_global *pGlobal_dev,
						struct unassoc_link_1905_metric_tlv_rsp *rsp,
						u32 msg_len)
{
	struct _1905_map_device *_1905_device = NULL;
	struct unassoc_link_1905_metric_rsp *unassoc_link_metric_msg = NULL;
	struct client * map_client = NULL;
	u8 cli_cnt = 0, i=0;
	struct bss_air_mon_report *air_mon_report = NULL, *tmp_air_mon_report = NULL;
#ifdef CENT_STR	
	struct own_1905_device *dev = &pGlobal_dev->dev;	
#endif
#ifdef MTK_MLO_MAP_SUPPORT
	struct client *reported_client = NULL;
#endif


	unassoc_link_metric_msg = &rsp->unasssoc_link_rsp;
	_1905_device = topo_srv_get_1905_device(&pGlobal_dev->dev,rsp->al_mac);

	if(_1905_device == NULL) {
		err(DEBUG_CAT_AP_EST, "Unknown 1905 device. Drop\n");
		return;
	}
	if(msg_len < sizeof(struct unassoc_link_metric_rsp)) {
		err(DEBUG_CAT_AP_EST, "Invalid msg len\n");
	}
	
	cli_cnt = unassoc_link_metric_msg->sta_num;

	err(DEBUG_CAT_AP_EST, "Cli cnt: %d. Something!!\n", cli_cnt);
/*
	if(cli_cnt > 1) {
		err(DEBUG_CAT_AP_EST, "Cli cnt: %d. Something is wrong\n", cli_cnt);
	}
*/
	for(i=0; i < cli_cnt; i++) {
		u8 *cli_mac = unassoc_link_metric_msg->sta_link_metric[i].cli_mac;

		map_client = client_db_get_client_from_sta_mac(pGlobal_dev,cli_mac);
#ifndef MTK_MLO_MAP_SUPPORT
		if (map_client == NULL
		|| map_client->cli_steer_state != CLI_STATE_STEER_DECISION
		|| map_client->meas_data.cli_measurement_state != MEAS_STATE_AIR_MON_TRIGGERED)
			continue;
#else
		if (map_client == NULL) {
#if defined(MAP_6E_SUPPORT) && defined(MAP_R6)
			if (dev->cosr_mode != 0) {
				struct _1905_map_device *cosr_air_dev = topo_srv_get_1905_by_bssid(dev,
									unassoc_link_metric_msg->sta_link_metric[i].cli_mac);

				if (cosr_air_dev != NULL)
					ap_est_handle_unassoc_ap_metric_rsp(pGlobal_dev, _1905_device, (char *)rsp->al_mac,
										&unassoc_link_metric_msg->sta_link_metric[i]);
			}
#endif /* MAP_6E_SUPPORT and MAP_R6 */
			continue;
		}
		u8 j;

		reported_client = map_client;
#if defined(MAP_6E_SUPPORT) && defined(MAP_R6)
		if (map_client->cosr_air_monitor != 1) {
#endif /* MAP_6E_SUPPORT and MAP_R6 */
			if (!map_client->mlo_enable) {
				if (map_client->cli_steer_state != CLI_STATE_STEER_DECISION
					|| map_client->meas_data.cli_measurement_state != MEAS_STATE_AIR_MON_TRIGGERED)
					continue;
			} else {
				for (j = 0; j < MAX_MLD_CLI; j++) {
					if (!map_client->mld_clients[j])
						continue;
					if (map_client->mld_clients[j]->cli_steer_state == CLI_STATE_STEER_DECISION
						|| map_client->mld_clients[j]->meas_data.cli_measurement_state
												== MEAS_STATE_AIR_MON_TRIGGERED) {
						map_client = map_client->mld_clients[j];
						err(DEBUG_CAT_AP_EST, "map_client was steer cand , mld client was , so replace");
						break;
					}
				}
			}
#if defined(MAP_6E_SUPPORT) && defined(MAP_R6)
		}
#endif /* MAP_6E_SUPPORT and MAP_R6 */

#endif
		err(DEBUG_CAT_AP_EST, "map_client is on channel %d", map_client->current_chan);

		if(!SLIST_EMPTY(&(map_client->meas_data.air_mon_bss_head)))
		{
#if defined(MAP_6E_SUPPORT) && defined(MAP_R6)
			SLIST_FOREACH_SAFE(air_mon_report, &(map_client->meas_data.air_mon_bss_head),
				air_mon_bss_entry, tmp_air_mon_report) {
				info(DEBUG_CAT_AP_EST, CENT_STEER_PREX"air_mon_report almac "MACSTR"", MAC2STR(air_mon_report->al_mac));
				info(DEBUG_CAT_AP_EST, CENT_STEER_PREX"rsp almac "MACSTR"", MAC2STR(rsp->al_mac));
				info(DEBUG_CAT_AP_EST, CENT_STEER_PREX"air_mon_report bssid "MACSTR"", MAC2STR(air_mon_report->bssid));
				info(DEBUG_CAT_AP_EST, CENT_STEER_PREX"air_mon_report rssi %d", air_mon_report->rssi);
				info(DEBUG_CAT_AP_EST, CENT_STEER_PREX"air_mon_report report received %d", air_mon_report->report_received);
			}
#endif /* MAP_6E_SUPPORT and MAP_R6 */

			err(DEBUG_CAT_AP_EST, "not empty");
			SLIST_FOREACH_SAFE(air_mon_report, &(map_client->meas_data.air_mon_bss_head),
												air_mon_bss_entry, tmp_air_mon_report)
			{
				if(!os_memcmp(air_mon_report->al_mac, rsp->al_mac, ETH_ALEN)) {
#ifdef MTK_MLO_MAP_SUPPORT
					struct bss_info_db *bss = topo_srv_get_bss(_1905_device, (char *)air_mon_report->bssid);
					err(DEBUG_CAT_AP_EST, "map_client is on channel %d "MACSTR"\n",
								map_client->current_chan, MAC2STR((char *)air_mon_report->bssid));
					if (bss == NULL)
						continue;
#ifdef MAP_R6
					if (!bss->radio) {
						err(DEBUG_CAT_AP_EST, "bss radio is null for bssid " MACSTR, MAC2STR(bss->bssid));
						continue;
					}
#endif /* MAP_R6 */

					err(DEBUG_CAT_AP_EST,
					 "bss->band %d air mon bssid "MACSTR" reported_client current band %d channel %d", bss->radio->band,
						MAC2STR(air_mon_report->bssid),
						reported_client->current_band,
						reported_client->current_chan);
					if (bss->radio->band != reported_client->current_band)
						continue;
#endif
					air_mon_report->rssi = rcpi_to_rssi(unassoc_link_metric_msg->sta_link_metric[i].rssi);
					air_mon_report->delta_time = unassoc_link_metric_msg->sta_link_metric[i].delta_time;
					if (air_mon_report->report_received == 1)
						break;
					air_mon_report->report_received  = 1;
					err(DEBUG_CAT_AP_EST, "AirMon result: BSS: "MACSTR " AL= " MACSTR " RSSI: %d",
							MAC2STR(air_mon_report->bssid),
							MAC2STR(air_mon_report->al_mac),
							air_mon_report->rssi);
#if defined(MAP_6E_SUPPORT) && defined(MAP_R6)
					if (map_client->cosr_air_monitor != 1)
#endif /* MAP_6E_SUPPORT and MAP_R6 */
						map_client->meas_data.air_mon_rx_cnt++;
					break;
				}
			}
		}


#ifdef CENT_STR
#if defined(MAP_6E_SUPPORT) && defined(MAP_R6)
			if (map_client->cosr_air_monitor == 1) {
#endif /* MAP_6E_SUPPORT and MAP_R6 */
				/*Disable steering if radar detected orchannel planning or network opt is ongoing*/
				if (dev->cent_str_en && is_chplan_netopt_ongoing(pGlobal_dev)) {
					eloop_cancel_timeout(ap_est_air_mon_timeout, pGlobal_dev, map_client);
					steer_fsm_trigger(pGlobal_dev, map_client->client_id, CHAN_MEASUREMENT_DISALLOWED, NULL);
					return;
				}
#if defined(MAP_6E_SUPPORT) && defined(MAP_R6)
			}
#endif /* MAP_6E_SUPPORT and MAP_R6 */
#endif
#if defined(MAP_6E_SUPPORT) && defined(MAP_R6)
		err(DEBUG_CAT_AP_EST, "map_client->air_mon_rx_cnt %d map_client->air_mon_sent_cnt %d map_client->cosr_air_monitor %d",
		map_client->meas_data.air_mon_rx_cnt, map_client->meas_data.air_mon_sent_cnt, map_client->cosr_air_monitor);
		if (map_client->cosr_air_monitor == 1) {
			if (dev->air_mon_sta_cnt > 0) {
				dev->airmon_complete_cnt++;
				if (dev->air_mon_sta_cnt == dev->airmon_complete_cnt)
					cosr_sta_airmonitor_timeout_handler((void *)dev, NULL);
			}
		} else
#endif /* MAP_6E_SUPPORT and MAP_R6 */
			if (map_client->meas_data.air_mon_rx_cnt == map_client->meas_data.air_mon_sent_cnt) {

				info(DEBUG_CAT_AP_EST, CENT_STEER_PREX"All air mon rsp received-->SUCCESS");
				eloop_cancel_timeout(ap_est_air_mon_timeout, pGlobal_dev, map_client);
				info(DEBUG_CAT_AP_EST, CENT_STEER_PREX"Trigger FSM (CHAN_MEASUREMENT_COMPLETE)");
				steer_fsm_trigger(pGlobal_dev, map_client->client_id, CHAN_MEASUREMENT_COMPLETE, NULL);
			}
	}
}
#endif
void ap_est_11k_cleanup(struct mapd_global *global, struct client *cli)
{
       eloop_cancel_timeout(ap_est_handle_11k_timeout, global, cli);
}

