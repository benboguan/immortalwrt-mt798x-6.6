/* SPDX-License-Identifier: LicenseRef-Proprietary
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2023-2024  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#ifndef __DEBUG_H__
#define __DEBUG_H__

#include <syslog.h>
#include <stddef.h>
extern int mapd_debug_level;
extern int hex_debug_level;
extern int mapd_debug_timestamp;

/* Debug Category */
#define DEBUG_CAT_MISC                  0
#define DEBUG_CAT_INIT                  1
#define DEBUG_CAT_CH_PL					2
#define DEBUG_CAT_DFS                   3
#define DEBUG_CAT_AUTOCONFIG            4
#define DEBUG_CAT_WPS                   5
#define DEBUG_CAT_BEST_AP               6
#define DEBUG_CAT_NETOPT                7
#define DEBUG_CAT_WSC_M8                8
#define DEBUG_CAT_AFC                   9
#define DEBUG_CAT_STEERING              10
#define DEBUG_CAT_BSS                   11
#define DEBUG_CAT_VENDOR                12
#define DEBUG_CAT_COSR                  13
#define DEBUG_CAT_EVENT                 14
#define DEBUG_CAT_AP_ROAM               15
#define DEBUG_CAT_AP_EST                16
#define DEBUG_CAT_LIB_SCORE             17
#define DEBUG_CAT_TOPO					18
#define DEBUG_CAT_METRIC				19
#define DEBUG_CAT_TLVPRS				20
#define DEBUG_CAT_BLA					21
#define DEBUG_CAT_CLIENT_DB				22
#define DEBUG_CAT_CLIENT_MON			23
#define DEBUG_CAT_ELOOP					24
#define DEBUG_CAT_RADIO					25
#define DEBUG_CAT_MAX                   DEBUG_CAT_RADIO
#define DEBUG_CAT_ALL                   DEBUG_CAT_MISC



enum {
	MSG_EXCESSIVE, MSG_MSGDUMP, MSG_DEBUG, MSG_INFO, MSG_WARNING, MSG_ERROR, MSG_OFF
};
#ifdef CONFIG_NO_STDOUT_DEBUG
#define mapd_printf(args...) do { } while (0)
#else
#define mapd_printf(...) mapd_printf_debug(__func__, __LINE__, __VA_ARGS__)
void  mapd_printf_debug(const char *func, int line, int level, const char *fmt, ...)
PRINTF_FORMAT(4, 5);
#endif
#ifdef RELEASE_EXCLUDE
#define mapd_ASSERT(a)					\
	do {						\
		if (!(a)) {				\
			printf("mapd_ASSERT FAILED '" #a "' "	\
			       "%s %s:%d\n",			\
			       __func__, __FILE__, __LINE__);	\
		}					\
	} while (0)
#else
#define mapd_ASSERT(a)							\
	do {								\
		if (!(a)) {						\
			printf("mapd_ASSERT FAILED '" #a "' "		\
			"%s %s:%d\n",				\
			 __func__, __FILE__, __LINE__);		\
			exit(1);					\
		}							\
	} while (0)
#endif
#define PRINT_MAC(a) a[0], a[1], a[2], a[3], a[4], a[5]
#ifdef CONFIG_NO_STDOUT_DEBUG
#define mapd_hexdump(l,t,b,le) do { } while (0)
#define mapd_hexdump_buf(l,t,b) do { } while (0)
#define mapd_hexdump_key(l,t,b,le) do { } while (0)
#define mapd_hexdump_buf_key(l,t,b) do { } while (0)
#define mapd_hexdump_ascii(l,t,b,le) do { } while (0)
#define mapd_hexdump_ascii_key(l,t,b,le) do { } while (0)
#define mapd_debug_setup_stdout() do { } while (0)
#else
void mapd_debug_setup_stdout(void);
void mapd_hexdump_ascii(int level, const char *title, const void *buf,
		       size_t len);
#endif

void _log_hexdump(int level, int category, const char *title, const unsigned char *buf,
			 size_t len, int show, int only_syslog);
void _log_hexdump_ascii(int level, int category, const char *title, const void *buf,
			       size_t len, int show);
void _log_printf(int level, int category, int prefix, const char *func_name,
	int func_line, const char *fmt, ...) PRINTF_FORMAT(6, 7);


extern int debug_level;
extern int debug_category;
extern int debug_show_keys;
extern int debug_syslog;
extern int debug_timestamp;
extern int debug_funcline;

/*below defination is called for external module*/
#define LOG_VERSION "1.0"

/* Debug Level */
/* no log shall be printed at DEBUG_OFF.
 * When set to DEBUG_OFF, all the log is disabled.
 */
#define DEBUG_OFF		0

/* DEBUG_ERROR is designated for logging errors that the program cannot
 * autonomously recover from, leading to a total failure of its functionalities.
 */
#define DEBUG_ERROR		1

/* DEBUG_WARN used to log unexpected events that occur, but the program
 * can continue running
 */
#define DEBUG_WARN		2

/* DEBUG_NOTICE is used to log normal yet noteworthy conditions. Logs at
 * this level should not impact performance and must not be generated too
 * frequently or be excessively verbose
 */
#define DEBUG_NOTICE	3

/* DEBUG_INFO is used for conditions that are normal and not of high significance.
 * It is utilized for informational messages that convey less critical information.
 */
#define DEBUG_INFO		4

/* DEBUG_DEBUG is used to print detailed information for RD personal use.
 */
#define DEBUG_DEBUG		5

#define DEBUG_LVL_MAX	DEBUG_DEBUG
#define DEBUG_MAPD_DEFAULT 0
#define log_printf(level, category, ...)						\
	_log_printf(level, category, 1, __func__, __LINE__, __VA_ARGS__)

/* Printing log without prefix, np: No prefix */
#define log_printf_np(level, category, ...)	\
	_log_printf(level, category, 1, __func__, __LINE__, __VA_ARGS__)

static inline void log_hexdump(int level, int category, const char *title, const void *buf, size_t len)
{
	_log_hexdump(hex_debug_level, category, title, buf, len, 1, 1);  // To correct level
}

static inline void log_hexdump_key(int level, int category, const char *title, const void *buf, size_t len)
{
	_log_hexdump(level, category, title, buf, len, debug_show_keys, 1);
}

static inline void log_hexdump_ascii(int level, int category, const char *title,
	const void *buf, size_t len)
{
	_log_hexdump_ascii(level, category, title, buf, len, 1);
}

static inline void log_hexdump_ascii_key(int level, int category, const char *title, const void *buf, size_t len)
{
	_log_hexdump_ascii(level, category, title, buf, len, debug_show_keys);
}

#define err(category, ...) log_printf(DEBUG_ERROR, category, __VA_ARGS__)
#define warn(category, ...) log_printf(DEBUG_WARN, category, __VA_ARGS__)
#define notice(category, ...) log_printf(DEBUG_NOTICE, category, __VA_ARGS__)
#define info(category, ...) log_printf(DEBUG_INFO, category, __VA_ARGS__)
#define debug(category, ...) log_printf(DEBUG_DEBUG, category, __VA_ARGS__)
#define always(...) log_printf(DEBUG_ERROR, DEBUG_MAPD_DEFAULT, __VA_ARGS__)
/* Printing log without prefix, np: No prefix */
#define err_np(category, ...) log_printf_np(DEBUG_ERROR, category, __VA_ARGS__)
#define warn_np(category, ...) log_printf_np(DEBUG_WARN, category, __VA_ARGS__)
#define notice_np(category, ...) log_printf_np(DEBUG_NOTICE, category, __VA_ARGS__)
#define info_np(category, ...) log_printf_np(DEBUG_INFO, category, __VA_ARGS__)
#define debug_np(category, ...) log_printf_np(DEBUG_DEBUG, category, __VA_ARGS__)

#define err_hexdump(category, ...) log_hexdump(DEBUG_ERROR, category, __VA_ARGS__)
#define warn_hexdump(category, ...) log_hexdump(DEBUG_WARN, category, __VA_ARGS__)
#define notice_hexdump(category, ...) log_hexdump(DEBUG_NOTICE, category, __VA_ARGS__)
#define info_hexdump(category, ...) log_hexdump(DEBUG_INFO, category, __VA_ARGS__)
#define debug_hexdump(category, ...) log_hexdump(DEBUG_DEBUG, category, __VA_ARGS__)

#define err_hexdump_key(category, ...) log_hexdump_key(DEBUG_ERROR, category, __VA_ARGS__)
#define warn_hexdump_key(category, ...) log_hexdump_key(DEBUG_WARN, category, __VA_ARGS__)
#define notice_hexdump_key(category, ...) log_hexdump_key(DEBUG_NOTICE, category, __VA_ARGS__)
#define info_hexdump_key(category, ...) log_hexdump_key(DEBUG_INFO, category, __VA_ARGS__)
#define debug_hexdump_key(category, ...) log_hexdump_key(DEBUG_DEBUG, category, __VA_ARGS__)

#define err_hexdump_ascii(category, ...) log_hexdump_ascii(DEBUG_ERROR, category, __VA_ARGS__)
#define warn_hexdump_ascii(category, ...) log_hexdump_ascii(DEBUG_WARN, category, __VA_ARGS__)
#define notice_hexdump_ascii(category, ...) log_hexdump_ascii(DEBUG_NOTICE, category, __VA_ARGS__)
#define info_hexdump_ascii(category, ...) log_hexdump_ascii(DEBUG_INFO, category, __VA_ARGS__)
#define debug_hexdump_ascii(category, ...) log_hexdump_ascii(DEBUG_DEBUG, category, __VA_ARGS__)

#define err_hexdump_ascii_key(category, ...) log_hexdump_ascii_key(DEBUG_ERROR, category, __VA_ARGS__)
#define warn_hexdump_ascii_key(category, ...) log_hexdump_ascii_key(DEBUG_WARN, category, __VA_ARGS__)
#define notice_hexdump_ascii_key(category, ...) log_hexdump_ascii_key(DEBUG_NOTICE, category, __VA_ARGS__)
#define info_hexdump_ascii_key(category, ...) log_hexdump_ascii_key(DEBUG_INFO, category, __VA_ARGS__)
#define debug_hexdump_ascii_key(category, ...) log_hexdump_ascii_key(DEBUG_DEBUG, category, __VA_ARGS__)

/*
 * @name: daemon name; a maximum 32 characters string.
 * @cat: debug category name array; each element is a maximum 32 characters string.
 * the first element must be "MISC". "MISC" category is used to print log by default.
 * @cat_num: category number. maximum number is 32.
 */
int log_init(char *name, char cat[][32], size_t cat_num);
void log_deinit(void);

/* format str: set_log_option <dbg_lvl>:<dbg_category>:<syslog>:<prt_timestamp>:<prt_funcline>
 * dbg_lvl:			print the debug level; valid value is 0-5.
 * dbg_category:	print the debug category; valid value is bit0-bit31.
 * syslog:			print log to syslog file; valid 0-1; 1: to syslog; 0: to console.
 * prt_timestamp:	add timestamp with format s.us when print log on console; valid 0-1.
 * prt_funcline:	print function name and line number; valid 0-1.
 */
void set_log_option_str(char *arg);
int get_log_info(char *buf, size_t max_len);
int set_debug_level(int level);
void mapd_hexdump(int level, const char *title, const void *buf, size_t len);
void mapd_hexdump1(int level, const char *title, const void *buf, size_t len);
void set_log_category_str(char *arg);

static inline void set_debug_category(int category)
{
	debug_category = category | 0x1;
}

static inline void set_debug_syslog(int syslog)
{
	debug_syslog = syslog ? 1 : 0;
}

static inline void set_debug_timestamp(int timestamp)
{
	debug_timestamp = timestamp ? 1 : 0;
}

static inline void set_debug_funcline(int funcline)
{
	debug_funcline = funcline ? 1 : 0;
}

static inline void hex_dump(const char *title, const void *buf, size_t len)
{
	err_hexdump(DEBUG_MAPD_DEFAULT, title, buf, len);
}

#endif /* __DEBUG_H__ */
