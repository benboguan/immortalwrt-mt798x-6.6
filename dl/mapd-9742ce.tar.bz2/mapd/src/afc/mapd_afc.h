/* SPDX-License-Identifier: MediaTekProprietary */
/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2024-2025  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#ifndef MAPD_AFC_H
#define MAPD_AFC_H

#ifdef MAP_R6

#define _MAP_AFC_INQ_FILE "/tmp/afc_spectrum_inquiry"
#define _MAP_AFC_RESP_FILE "/tmp/afc_resp"
#define MAX_AFC_INQ_RES 4096
#define AFC_RESPONSE_EXPIRY_OFFSET 30

enum responseStatus {
	RESPONSE_VALID,
	RESPONSE_INVALID,
	RETRY_WAIT,
	CONNECTION_ERROR = 7,
	RESPONSE_TIMEOUT = 28,
	RESPONSE_EMPTY = 52,
	RESPONSE_INITIAL = 0xFF,
};

enum AFC_OP_CLASS_CHANNEL_NUM {
	AFC_OP_CLASS_131_CHL_NUM = 59,
	AFC_OP_CLASS_132_CHL_NUM = 29,
	AFC_OP_CLASS_133_CHL_NUM = 14,
	AFC_OP_CLASS_134_CHL_NUM = 7,
	AFC_OP_CLASS_135_CHL_NUM = 14,
	AFC_OP_CLASS_136_CHL_NUM = 3,
	AFC_OP_CLASS_137_CHL_NUM = 2
};

enum AFC_OP_CLASS_6G {
	AFC_OP_CLASS_131 = 131,
	AFC_OP_CLASS_132,
	AFC_OP_CLASS_133,
	AFC_OP_CLASS_134,
	AFC_OP_CLASS_135,
	AFC_OP_CLASS_136,
	AFC_OP_CLASS_137,
	AFC_OP_CLASS_NUM
};

enum AFC_OP_CLASS_INDEX_6G {
	AFC_OP_CLASS_IDX_131 = 0,
	AFC_OP_CLASS_IDX_132,
	AFC_OP_CLASS_IDX_133,
	AFC_OP_CLASS_IDX_134,
	AFC_OP_CLASS_IDX_135,
	AFC_OP_CLASS_IDX_136,
	AFC_OP_CLASS_IDX_137,
	AFC_OP_CLASS_IDX_NUM
};

enum tags {
	MAP_TAG_OPCLASS,
	MAP_TAG_CH_LIST,
	MAP_TAG_EIRP
};

unsigned char check_if_ch_present_in_afc_skip_list(struct _1905_map_device *dev, unsigned char ch);
int get_afc_opclass_index_for_dev(struct _1905_map_device *dev, unsigned char opclass, unsigned char preference);
void ch_planning_trigger_for_bootup_afc(void *eloop_ctx, void *timeout_ctx);
unsigned short parse_afc_map_response_payload(struct own_1905_device *ctx, struct _1905_map_device *dev, unsigned char *payload);
void mapd_handle_afc_spectrum_inquiry_msg(struct mapd_global *global, unsigned char *buf, int buf_len);
int map_1905_send_afc_report2(struct _1905_context *ctx, char *almac,
		unsigned short spectrum_inquiry_len, unsigned char *spectrum_inquiry_req,
		unsigned short inquiry_resp_len, unsigned char *spectrum_inquiry_resp,
		unsigned short ch_prefer_cnt, struct ch_prefer_lib *ch_prefers);
time_t calculate_expiry_time(const char *expiry_str);
void afc_map_send_spectrum_inquiry_msg(struct mapd_global *global);
void clear_afc_skip_list(struct _1905_map_device *dev);
void update_afc_ch_for_dev(struct own_1905_device *ctx, struct _1905_map_device *dev);
#endif /* MAP_R6 */
#endif
