// SPDX-License-Identifier: MediaTekProprietary
/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2024-2025  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#ifdef MAP_R6
#include <sys/un.h>
#include <sys/time.h>
#include <asm/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <net/if.h>
#include <netinet/in.h>
#include <linux/netlink.h>
#include <linux/rtnetlink.h>
#include <stdlib.h>
#include <sys/time.h>
#include <sys/types.h>
#include <curl/curl.h>
#include<json-c/json.h>
#include <pthread.h>
#include <sys/ioctl.h>
#include <linux/wireless.h>
#include <inttypes.h>
#include <fcntl.h>
#include <sys/time.h>
#define UINT8 unsigned char
#define UINT16 unsigned short
#define UINT32 unsigned long

#include "includes.h"
#include "common.h"
#include "mapd_debug.h"

#include "interface.h"
#include "data_def.h"
#include "client_db.h"
#include "mapd_i.h"
#include "topologySrv.h"
#include "eloop.h"
#include "wapp_if.h"
#include "tlv_parsor.h"
#include "client_db.h"
#include "ap_est.h"
#include "1905_map_interface.h"
#include "mapd_afc.h"
#include "ch_planning.h"

void trigger_bootup_ch_planning_for_AFC(struct own_1905_device *ctx, struct radio_info_db *radio)
{
	u8 radio_idx = get_radio_idx_by_band(radio->band, ctx);

	ctx->ch_planning_R2.bootup_scanstatus[radio_idx].bootup_run = BOOTUP_SCAN_NEEDED;
	ctx->ch_planning_R2.bootup_scanstatus[radio_idx].band = radio->band;
	ctx->ch_planning_R2.bootup_scanstatus[radio_idx].channel = radio->channel[0];

	if (ctx->ch_planning_R2.ch_plan_state == CHPLAN_STATE_IDLE && ctx->user_triggered_scan == FALSE
		&& ctx->network_optimization.network_opt_state == NETOPT_STATE_IDLE) {
		ctx->ch_planning_R2.bootup_scanstatus[radio_idx].bootup_run = BOOTUP_SCAN_ONGOING;
		ch_planning_R2_force_trigger(ctx->back_ptr,
			ctx->ch_planning_R2.bootup_scanstatus[radio_idx].channel,
			ctx->ch_planning_R2.bootup_scanstatus[radio_idx].band);
	} else {
		eloop_register_timeout(CH_SCAN_RETRIGGER_TIMEOUT, 0, ch_planning_trigger_for_bootup_afc, ctx->back_ptr, radio);
	}

}

void ch_planning_trigger_for_bootup_afc(void *eloop_ctx, void *timeout_ctx)
{
	struct mapd_global *global = (struct mapd_global *)eloop_ctx;
	struct own_1905_device *ctx = &global->dev;
	struct radio_info_db *radio = (struct radio_info_db *)timeout_ctx;

	if ((!radio) || (!global)) {
		err(DEBUG_CAT_CH_PL, " dev|global ctx is null\n");
		return;
	}

	trigger_bootup_ch_planning_for_AFC(ctx, radio);
}

int get_afc_opclass_index_for_dev(struct _1905_map_device *dev, UINT8 opclass, UINT8 preference)
{
	int j = 0, ret = -1;

	if (preference == 0) {
		debug(DEBUG_CAT_AFC, "return for preference 0:%u\n", opclass);
		return ret;
	}

	for (j = AFC_OP_CLASS_IDX_131; j < AFC_OP_CLASS_IDX_NUM; j++) {
		if (dev->glblOperClass[j].Opclass == opclass) {
			ret = j;
			break;
		}
	}

	return ret;
}

unsigned char check_if_ch_present_in_afc_skip_list(struct _1905_map_device *dev, unsigned char  ch)
{
	UINT8 ret = 0, i = 0;

	if (dev->afcSkipChannelNum > AFC_OP_CLASS_131_CHL_NUM) {
		debug(DEBUG_CAT_AFC, "Channel num:%d", dev->afcSkipChannelNum);
		return ret;
	}

	for (i = 0; i < dev->afcSkipChannelNum; i++) {
		if (dev->afcSkipChannelList[i] == ch) {
			ret = 1;
			break;
		}
	}

	return ret;
}

UINT8 process_if_ch_not_present_in_afc_list(struct own_1905_device *ctx, struct _1905_map_device *dev, UINT8 ch_num,
					UINT8 *ch_list, int op_idx)
{
	int i = 0, j = 0;
	UINT8 ch_found = 0;
	UINT8 nop_afc = 0;

	if (dev == NULL)
		return nop_afc;

	/* If op class index is not found in AFC channel list, mark all list as skiplist*/
	if (op_idx == -1) {
		for (i = 0; i < ch_num && i < AFC_OP_CLASS_131_CHL_NUM; i++) {
			if (dev->afcSkipChannelNum < MAX_NUM_OF_CHANNELS
				&& check_if_ch_present_in_afc_skip_list(dev, ch_list[i]) == 0) {
				dev->afcSkipChannelList[dev->afcSkipChannelNum] = ch_list[i];
				dev->afcSkipChannelNum += 1;
			}
		}

		return 1;
	}

	if (op_idx < 0 || op_idx >= AFC_OP_CLASS_IDX_NUM) {
		debug(DEBUG_CAT_AFC, "op idx not valid %d", op_idx);
		return nop_afc;
	}

	for (i = 0; i < ch_num && i < AFC_OP_CLASS_131_CHL_NUM; i++) {
		ch_found = 0;
		if (dev->glblOperClass[op_idx].ch_index > AFC_OP_CLASS_131_CHL_NUM) {
			debug(DEBUG_CAT_AFC, "Error ch_index:%d\n",  dev->glblOperClass[op_idx].ch_index);
			continue;
		}

		for (j = 0; j < dev->glblOperClass[op_idx].ch_index; j++) {
			if (ch_list[i] ==  dev->glblOperClass[op_idx].ChannelList[j]) {
				debug(DEBUG_CAT_AFC, "skip ch case1 found");
				ch_found = 1;
				break;
			}
		}

		if (ch_found == 0 &&  dev->afcSkipChannelNum < MAX_NUM_OF_CHANNELS
				&& check_if_ch_present_in_afc_skip_list(dev, ch_list[i]) == 0) {
			dev->afcSkipChannelList[dev->afcSkipChannelNum] = ch_list[i];
			dev->afcSkipChannelNum += 1;
			nop_afc = 1;
		}
	}

	return nop_afc;
}

void delete_element_by_value(UINT8 arr[], UINT8 value, UINT8 *n)
{
	int i;

	for (i = 0; i < *n; i++) {
		if (arr[i] == value) {
			for (; i < *n - 1; i++)
				arr[i] = arr[i + 1];
			*n -= 1;
			break;
		}
	}
}


void update_ch_pref_for_AFC(struct own_1905_device *ctx, struct _1905_map_device *dev,
				struct radio_info_db *radio, UINT8 op_class,
				UINT8 *ch_num, UINT8 *ch_list)
{
	UINT8 ch_val = 0;
	UINT8 i = 0, j = 0;
	UINT8 afc_nop_ch_num = 0;
	struct prefer_info_db *prefer_t = NULL;
	struct prefer_info_db *afc_prefer_info = NULL, *t_afc_prefer_info = NULL;
	UINT8 ch_add[MAX_NUM_OF_CHANNELS] = {0};

	if (dev == NULL)
		return;

	ch_val = *ch_num;
	for (i = 0; i < dev->afcSkipChannelNum; i++) {
		for (j = 0; j < ch_val; j++) {
			if (dev->afcSkipChannelList[i] == ch_list[j]) {
				ch_add[afc_nop_ch_num] = ch_list[j];
				delete_element_by_value(ch_list, ch_list[j], ch_num);
				afc_nop_ch_num += 1;
				break;
			}
		}
	}

	if (afc_nop_ch_num == 0 || *ch_num == 0)
		return;

	SLIST_FOREACH_SAFE(afc_prefer_info, &(radio->chan_preferance.prefer_info_head),
		prefer_info_entry, t_afc_prefer_info) {
		if (IS_OP_CLASS_6G(afc_prefer_info->op_class) && op_class == afc_prefer_info->op_class
				&& afc_prefer_info->reason == 0x0d) {

			debug(DEBUG_CAT_AFC, "find prefer db");
			prefer_t = afc_prefer_info;
		}
	}

	if (prefer_t == NULL) {
		prefer_t = (struct prefer_info_db *)os_malloc(sizeof(struct prefer_info_db));
		if (!prefer_t) {
			err(DEBUG_CAT_CH_PL, CH_PLANING_PREX"alloc struct prefer_info_db fail");
			return;
		}
		debug(DEBUG_CAT_AFC, "new prefer db");
		if (radio->chan_preferance.op_class_num < (MAX_OP_CLASS_NUM - 1))
			radio->chan_preferance.op_class_num += 1;
		SLIST_INSERT_HEAD(&(radio->chan_preferance.prefer_info_head), prefer_t,
				prefer_info_entry);
	}

	prefer_t->op_class = op_class;
	prefer_t->ch_num = afc_nop_ch_num;
	memcpy(prefer_t->ch_list, ch_add, afc_nop_ch_num);
	prefer_t->perference = 0;
	prefer_t->reason = 0x0d;

	for (i = 0; i < prefer_t->ch_num; i++) {
#ifndef MAP_VENDOR_SUPPORT
		ch_planning_add_ch_to_preferred_list(ctx,
			prefer_t->ch_list[i],
			radio,
			prefer_t->ch_list[i] > 14,
			prefer_t->perference,
			prefer_t->reason,
			prefer_t->op_class);
#else
			ch_planning_add_ch_to_preferred_list(ctx, dev,
					prefer_t->ch_list[i],
					radio,
					prefer_t->ch_list[i] > 14,
					prefer_t->perference,
					prefer_t->reason,
					prefer_t->op_class);
#endif
	}
}

void clear_afc_skip_list(struct _1905_map_device *dev)
{
	int i;

	for (i = 0; i < MAX_NUM_OF_CHANNELS; i++)
		dev->afcSkipChannelList[i] = 0;

	dev->afcSkipChannelNum = 0;
}

void update_afc_ch_for_dev(struct own_1905_device *ctx, struct _1905_map_device *dev)
{
	struct radio_info_db *radio = NULL;
	int ret = -1;
	UINT8 nop_afc = 0;
	struct prefer_info_db *prefer_info = NULL, *t_prefer_info = NULL;

	radio = topo_srv_get_next_radio(dev, radio);
	while (radio) {
		if (radio->band == BAND_6G) {
			debug(DEBUG_CAT_AFC, "6E radio found");
			break;
		}
		radio = topo_srv_get_next_radio(dev, radio);
	}

	if (!radio) {
		err(DEBUG_CAT_AFC, "can't find radio for 6E\n");
		return;
	}

	if (dev->afcEnabled == 0) {
		debug(DEBUG_CAT_AFC, "AFC response is not complete\n");
		return;
	}

	SLIST_FOREACH_SAFE(prefer_info, &(radio->chan_preferance.prefer_info_head),
		prefer_info_entry, t_prefer_info) {
		ret = get_afc_opclass_index_for_dev(dev, prefer_info->op_class, prefer_info->perference);
		if (ret == -1 && !IS_OP_CLASS_6G(prefer_info->op_class)) {
			debug(DEBUG_CAT_AFC, "continue for opclass:%d", prefer_info->op_class);
			continue;
		}

		/*BW increase case*/

		nop_afc = process_if_ch_not_present_in_afc_list(ctx, dev, prefer_info->ch_num, prefer_info->ch_list, ret);
		if (nop_afc == 1) {
			update_ch_pref_for_AFC(ctx, dev, radio, prefer_info->op_class, &prefer_info->ch_num,
						prefer_info->ch_list);
		} else if (prefer_info->ch_num == 0 && ret != -1 && dev->glblOperClass[ret].ch_index > 0) {
			debug(DEBUG_CAT_AFC, "dev->glblOperClass[ret].ch_index %d", dev->glblOperClass[ret].ch_index);
			for (int j = 0; j < dev->glblOperClass[ret].ch_index; j++)
				debug(DEBUG_CAT_AFC, "dev->glblOperClass[ret].ch_index %d", dev->glblOperClass[ret].ch_index);
			prefer_info->ch_num = dev->glblOperClass[ret].ch_index;
			os_memcpy(prefer_info->ch_list, dev->glblOperClass[ret].ChannelList, dev->glblOperClass[ret].ch_index);
		}

		if (prefer_info->ch_num == 0) {
			SLIST_REMOVE(&(radio->chan_preferance.prefer_info_head), prefer_info, prefer_info_db, prefer_info_entry);
				for (int i = 0; i < prefer_info->ch_num; i++) {
					debug(DEBUG_CAT_AFC, "%d ", prefer_info->ch_list[i]);
					ch_planning_remove_ch_from_preferred_list(ctx,
						prefer_info->ch_list[i],
						radio, prefer_info->ch_list[i] > 14);
				}

			free(prefer_info);
			radio->chan_preferance.op_class_num -= 1;
			continue;
		}
	}
}

UINT8 is_check_valid_6E_ch(UINT8 opclass, UINT8 index)
{
	int ret = 0;

	if (opclass == AFC_OP_CLASS_131 && index < AFC_OP_CLASS_131_CHL_NUM)
		ret = 1;
	else if (opclass == AFC_OP_CLASS_132 && index < AFC_OP_CLASS_132_CHL_NUM)
		ret = 1;
	else if (opclass == AFC_OP_CLASS_133 && index < AFC_OP_CLASS_133_CHL_NUM)
		ret = 1;
	else if (opclass == AFC_OP_CLASS_134 && index < AFC_OP_CLASS_134_CHL_NUM)
		ret = 1;
	else if (opclass == AFC_OP_CLASS_135 && index < AFC_OP_CLASS_135_CHL_NUM)
		ret = 1;
	else if (opclass == AFC_OP_CLASS_136 && index < AFC_OP_CLASS_136_CHL_NUM)
		ret = 1;
	else if (opclass == AFC_OP_CLASS_137 && index < AFC_OP_CLASS_137_CHL_NUM)
		ret = 1;

	return ret;
}

static int afc_map_index_opclass(struct _1905_map_device *dev, UINT8 op_class)
{
	int i = 0;

	for (i = AFC_OP_CLASS_IDX_131; i < AFC_OP_CLASS_IDX_NUM; i++) {
		if (dev->glblOperClass[i].Opclass == op_class)
			return i;
		else if (dev->glblOperClass[i].Opclass == 0) {
			dev->glblOperClass[i].Opclass = op_class;
			dev->glblAFCOperClassNum++;
			return i;
		}
	}

	return -1;
}

void afc_timeout_handler(void *eloop_ctx, void *timeout_ctx)
{
	struct _1905_map_device *dev = (struct _1905_map_device *)timeout_ctx;

	if (dev == NULL)
		return;

	dev->afcEnabled = 0;
	dev->afc_spectrum_query = 0;
	dev->afc_spectrum_resp_flag = 0;
	/*TODO: need to check trigger channel planning or not.*/
}


time_t calculate_expiry_time(const char *expiry_str)
{
	char *token;
	struct tm expiry_time;
	time_t expiry_epoch_time;
	unsigned char count = 0;
	int year = 0, mon = 0, date = 0, hour = 0, min = 0, sec = 0;
	token = strtok((char *)expiry_str, "-");
	while (token) {
		switch (count) {
			case 0:
				year = strtol(token, NULL, 10);
				if (errno == ERANGE || year < 0) {
					err(DEBUG_CAT_MISC,
					"strtol fail for year\n");
					return -1;
				}

				token = strtok(NULL, "-");
				break;

			case 1:
				mon = strtol(token, NULL, 10);
				if (errno == ERANGE || mon < 0 || mon > UCHAR_MAX) {
					err(DEBUG_CAT_MISC,
					"strtol fail for mon.\n");
					return -1;
				}
				token = strtok(NULL, "T");
				break;

			case 2:
				date = strtol(token, NULL, 10);
				if (date == ERANGE || date < 0 || date > UCHAR_MAX) {
					err(DEBUG_CAT_MISC,
					"strtol fail for date.\n");
					return -1;
				}
				token = strtok(NULL, ":");
				break;

			case 3:
				hour = strtol(token, NULL, 10);
				if (errno == ERANGE || hour < 0 || hour > UCHAR_MAX) {
					err(DEBUG_CAT_MISC,
					"strtol fail for hour.\n");
					return -1;
				}
				token = strtok(NULL, ":");
				break;
			case 4:

				min = strtol(token, NULL, 10);
				if (errno == ERANGE || min < 0 || min > UCHAR_MAX) {
					err(DEBUG_CAT_MISC,
					"strtol fail for min.\n");
					return -1;
				}
				token = strtok(NULL, "Z");
				break;

			case 5:
				sec = strtol(token, NULL, 10);
				if (errno == ERANGE || sec < 0 || sec > UCHAR_MAX) {
					err(DEBUG_CAT_MISC,
					"strtol fail for sec.\n");
					return -1;
				}
				break;

		}
		count++;
		if (count > 5)
			break;

	}
	notice(DEBUG_CAT_AFC, "year = %d, Mon = %d, day = %d, hour = %d, min = %d, sec = %d\n",
						year, mon, date, hour, min, sec);

	expiry_time.tm_year = year - 1900;
	expiry_time.tm_mon = mon - 1;
	expiry_time.tm_mday = date;
	expiry_time.tm_hour = hour;
	expiry_time.tm_min = min;
	expiry_time.tm_sec = sec;
	expiry_time.tm_isdst = -1;
	expiry_epoch_time = mktime(&expiry_time);
	if (expiry_epoch_time == -1)
		err(DEBUG_CAT_MISC,
	"mktime fail for AFC");

	err(DEBUG_CAT_AFC, "expiry_time = %lu\n", expiry_epoch_time);

	return expiry_epoch_time;
}

static void clear_afc_channel_list(struct _1905_map_device *dev)
{
	int i, j;

	dev->glblAFCOperClassNum = 0;
	for (i = AFC_OP_CLASS_IDX_131; i < AFC_OP_CLASS_IDX_NUM; i++) {
		dev->glblOperClass[i].Opclass = 0;
		dev->glblOperClass[i].ch_index = 0;
		dev->glblOperClass[i].eirp_index = 0;
		for (j = 0; j < MAX_NUM_OF_CHANNELS; j++) {
			dev->glblOperClass[i].ChannelList[j] = 0;
			dev->glblOperClass[i].MaxEirp[j] = 0;
		}
	}
}

static void dump_afc_channel_list(struct _1905_map_device *dev)
{
	int i, j;

	notice(DEBUG_CAT_AFC, "==================AFC Standard Power Channel List=================\n");
	notice(DEBUG_CAT_AFC, "Total Number of op class %d\n", dev->glblAFCOperClassNum);
	for (i = 0; i <  dev->glblAFCOperClassNum; i++) {
		notice(DEBUG_CAT_AFC, "op_class value %d: \tChannel List:\t", dev->glblOperClass[i].Opclass);
		for (j = 0; j < dev->glblOperClass[i].ch_index; j++)
			notice(DEBUG_CAT_AFC, "%d %d\t", dev->glblOperClass[i].ChannelList[j], dev->glblOperClass[i].MaxEirp[j]);
		notice(DEBUG_CAT_AFC, "\n");
	}
	notice(DEBUG_CAT_AFC, "=================================================================\n");
}


unsigned short parse_afc_map_response_payload(struct own_1905_device *ctx, struct _1905_map_device *dev, unsigned char *payload)
{
	struct json_object *parsed_json;
	struct json_object *version;
	struct json_object *afcResponse;
	struct json_object *response;
	struct json_object *json_obj1, *json_obj2, *json_obj3, *json_obj4, *json_obj5, *json_obj6, *json_obj7;
	struct json_object *temp;
	int n_Response = 0, n_frequency = 0, n_Channel = 0;
	int i = 0, j = 0, k = 0, len = 0, no_need_trigger_all = 0;
	UINT16 status = RESPONSE_INVALID;
	UINT16 *pfreq_data = NULL;
	struct radio_info_db *radio = NULL;
	time_t afc_resp_time, now;
	int ret = 0;
	struct _1905_map_device *_1905_dev = NULL, *t_1905_dev = NULL;
	int mem_alloc = 0;

	if (!dev || !ctx) {
		err(DEBUG_CAT_AFC, "1905 dev is missing\n");
		return status;
	}

	struct mapd_global *global = (struct mapd_global *)ctx->back_ptr;

	char *tempPayload = "{\"version\": \"1.2\", \"availableSpectrumInquiryResponses\": [{\"requestId\": \"california\", \"rulesetId\": \"US_47_CFR_PART_15_SUBPART_E\", \"availableChannelInfo\": [{\"globalOperatingClass\": 131, \"channelCfi\": [1, 5, 9, 13, 17, 21, 25, 29, 33, 37, 41, 45, 49, 53, 57, 61, 65, 69, 73, 77, 81, 85, 89, 93, 117, 121, 125, 129, 133, 137, 141, 145, 149, 153, 157, 161, 165, 169, 173, 177, 181], \"maxEirp\": [36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0]}, {\"globalOperatingClass\": 132, \"channelCfi\": [3, 11, 19, 27, 35, 43, 51, 59, 67, 75, 83, 91, 123, 131, 139, 147, 155, 163, 171, 179], \"maxEirp\": [36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0]}, {\"globalOperatingClass\": 133, \"channelCfi\": [7, 23, 39, 55, 71, 87, 135, 151, 167], \"maxEirp\": [36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0, 36.0]}], \"availabilityExpireTime\": \"2023-02-16T08:49:19\", \"response\": {\"responseCode\": 0, \"shortDescription\": \"Success.\"}}]}";

	if (payload == NULL) {
		payload = os_malloc(strlen(tempPayload) + 1);
		if (payload == NULL) {
			err(DEBUG_CAT_MISC,
			"payload is NULL for AFC");
			goto END;
		}
		mem_alloc = 1;
		os_strcpy((char *)payload, tempPayload);
		payload[strlen(tempPayload)] = '\0';
		notice(DEBUG_CAT_AFC, "Response %s\n", payload);
	}
	notice(DEBUG_CAT_AFC, "Response %s\n", payload);

	radio = topo_srv_get_radio_by_band_type(dev, BAND_6G);

	if (radio == NULL) {
		err(DEBUG_CAT_AFC, "radio not found!!\n");
		goto END;
	}

	dev->afcEnabled = 0;
	map_get_info_from_wapp(ctx, WAPP_USER_GET_CHANNEL_PREFERENCE, WAPP_CHANNLE_PREFERENCE,
			       radio->identifier, NULL, NULL, 0);

	parsed_json = json_tokener_parse((char *)payload);
	if (!json_object_object_get_ex(parsed_json, "version", &version)) {
		err(DEBUG_CAT_AFC, "Required Key Version not available\n");
		goto END;
	}

	notice(DEBUG_CAT_AFC, "version is %s\n", json_object_get_string(version));
	notice(DEBUG_CAT_AFC, ".");

	if (!json_object_object_get_ex(parsed_json, "availableSpectrumInquiryResponses", &afcResponse)) {
		err(DEBUG_CAT_AFC, "Required Key SpectrumInquiryResponses not available\n");
		goto END;
	}

	notice(DEBUG_CAT_AFC, "afcResponse %s", json_object_to_json_string(afcResponse));

	n_Response = json_object_array_length(afcResponse);

	clear_afc_channel_list(dev);

	// need to check if loop needed
	for (i = 0; i < n_Response; i++) {
		notice(DEBUG_CAT_AFC, "Count=%d\n", i);

		response = json_object_array_get_idx(afcResponse, i);

		notice(DEBUG_CAT_AFC, "response %s\n", json_object_to_json_string(response));

		if (!json_object_object_get_ex(response, "requestId", &temp)) {
			err(DEBUG_CAT_AFC, "Required Key requestId not available\n");
			goto END;
		}

		notice(DEBUG_CAT_AFC, "requestId is %s\n", json_object_get_string(temp));
		if (!json_object_object_get_ex(response, "rulesetId", &temp)) {
			err(DEBUG_CAT_AFC, "Required Key rulesetId not available\n");
			goto END;
		}

		notice(DEBUG_CAT_AFC, "%d. rulesetId is %s\n", i+1, json_object_get_string(temp));
		if (json_object_object_get_ex(response, "availableFrequencyInfo", &temp)) {
			n_frequency = json_object_array_length(temp);
			debug(DEBUG_CAT_AFC, "n_frequency=%d\n", n_frequency);
			for (j = 0; j < n_frequency; j++) {
				json_obj1 = json_object_array_get_idx(temp, j);
				if (!json_object_object_get_ex(json_obj1, "frequencyRange", &json_obj2)) {
					err(DEBUG_CAT_AFC, "Required Key frequencyRange not available\n");
					goto END;
				}

				if (!json_object_object_get_ex(json_obj2, "lowFrequency", &json_obj3)) {
					err(DEBUG_CAT_AFC, "Required Key lowFrequency not available\n");
					goto END;
				}

				if (!json_object_object_get_ex(json_obj2, "highFrequency", &json_obj4)) {
					err(DEBUG_CAT_AFC, "Required Key highFrequency not available\n");
					goto END;
				}

				if (json_object_object_get_ex(json_obj1, "maxPsd", &json_obj5) ||
						(json_object_object_get_ex(json_obj1, "maxPSD", &json_obj5))) {
					len = strlen(json_object_get_string(json_obj5)) + 1;
				} else {
					err(DEBUG_CAT_AFC, "Required Key maxPsd not available\n");
					goto END;
				}

				pfreq_data = os_malloc(len + 4);
				if (pfreq_data == NULL) {
					err(DEBUG_CAT_MISC,
					"malloc pfreq_data fail\n");
					goto END;
				}

				pfreq_data[0] = (UINT16)json_object_get_int(json_obj3);
				pfreq_data[1] = (UINT16)json_object_get_int(json_obj4);
				strncpy((char *)&pfreq_data[2], json_object_get_string(json_obj5), len);
				debug(DEBUG_CAT_AFC, "freq Range (%d, %d) MaxPsd = %s\n", pfreq_data[0],
					pfreq_data[1], (char *)&pfreq_data[2]);
				os_free(pfreq_data);
			}
		}

		if (json_object_object_get_ex(response, "availableChannelInfo", &temp)) {
			notice(DEBUG_CAT_AFC, "availableChannelInfo\n");
			n_frequency = json_object_array_length(temp);
			for (j = 0; j < n_frequency; j++) {
				json_obj1 = json_object_array_get_idx(temp, j);
				if (!json_object_object_get_ex(json_obj1, "globalOperatingClass", &json_obj3)) {
					err(DEBUG_CAT_AFC, "Required Key globalOperatingClass not available\n");
					goto END;
				}

				UINT8 opClass = (unsigned char)json_object_get_int(json_obj3);

				int opclass_index = afc_map_index_opclass(dev, opClass);

				notice(DEBUG_CAT_AFC, "opclass_index %d", opclass_index);
				if (opclass_index < 0) {
					err(DEBUG_CAT_AFC, "opclass_index is negative, fail\n");
					goto END;
				}

				dev->glblOperClass[opclass_index].Opclass = opClass;


				if (!json_object_object_get_ex(json_obj1, "channelCfi", &json_obj4)) {
					err(DEBUG_CAT_AFC, "Required Key channelCfi not available\n");
					goto END;
				}

				if (!json_object_object_get_ex(json_obj1, "maxEirp", &json_obj6)) {
					err(DEBUG_CAT_AFC, "Required Key maxEirp not available\n");
					goto END;
				}

				n_Channel = json_object_array_length(json_obj4);
				notice(DEBUG_CAT_AFC, " Operating Class = %d\n", opClass);
				notice(DEBUG_CAT_AFC, " Channel      %d  Max EIRP\n", n_Channel);

				for (k = 0; k < n_Channel; k++) {
					json_obj5 = json_object_array_get_idx(json_obj4, k);
					json_obj7 = json_object_array_get_idx(json_obj6, k);

					notice(DEBUG_CAT_AFC, "channel %d EIRP %d", json_object_get_int(json_obj5),
						json_object_get_int(json_obj7));
					dev->glblOperClass[opclass_index].ChannelList[k] = json_object_get_int(json_obj5);
					dev->glblOperClass[opclass_index].MaxEirp[k] = json_object_get_int(json_obj7);
					dev->glblOperClass[opclass_index].ch_index++;
					dev->glblOperClass[opclass_index].eirp_index++;
				}
				err(DEBUG_CAT_AFC, "\n");
			}
			dump_afc_channel_list(dev);

			if (!json_object_object_get_ex(response, "response", &temp)) {
				err(DEBUG_CAT_AFC, "Required Key response not available\n");
				goto END;
			} else {
				if (json_object_object_get_ex(temp, "responseCode", &json_obj1)) {
					status = (UINT16)json_object_get_int(json_obj1);
					notice(DEBUG_CAT_AFC, "responseCode is %u\n", status);
				}

				if (json_object_object_get_ex(temp, "shortDescription", &json_obj1)) {
					debug(DEBUG_CAT_AFC, "responseCode is %s\n", json_object_get_string(json_obj1));
					notice(DEBUG_CAT_AFC, "responseCode is %s\n", json_object_get_string(json_obj1));
				}
			}

			if (json_object_object_get_ex(response, "availabilityExpireTime", &temp)) {
				afc_resp_time = calculate_expiry_time(json_object_get_string(temp));

				ret = time(&now);
				if (ret < 0)
					err(DEBUG_CAT_AFC, "time command fail for AFC\n");
				notice(DEBUG_CAT_AFC, "remaining time in sec: %ld", now - afc_resp_time);
				notice(DEBUG_CAT_AFC, "remaining time in sec: %ld %ld, %ld", dev->afc_time - afc_resp_time,
						afc_resp_time, dev->afc_time);
				if (now < afc_resp_time) {
					notice(DEBUG_CAT_AFC, "remaining time in sec: %ld", afc_resp_time - now);
					eloop_cancel_timeout(afc_timeout_handler, ctx, dev);
					eloop_register_timeout((afc_resp_time - now) + AFC_RESPONSE_EXPIRY_OFFSET, 0,
								afc_timeout_handler, (void *)ctx, (void *)dev);
				} else {
					err(DEBUG_CAT_AFC, "AFC response is expired..\n");
				}
				notice(DEBUG_CAT_AFC, "AFC DEBUG VALID Response");
				dev->afcEnabled = 1;
				clear_afc_skip_list(dev);
				update_afc_ch_for_dev(ctx, dev);

				if (ctx->device_role == DEVICE_ROLE_CONTROLLER) {
					SLIST_FOREACH_SAFE(_1905_dev, &(global->dev._1905_dev_head), next_1905_device, t_1905_dev) {
						notice(DEBUG_CAT_AFC, "aLMAC "MACSTR"_1905_dev->channel_planning_completed %d\n",
							MAC2STR(_1905_dev->_1905_info.al_mac_addr), _1905_dev->channel_planning_completed);
						if (_1905_dev->channel_planning_completed == TRUE) {
							no_need_trigger_all = 1;
							notice(DEBUG_CAT_AFC, "need to trigger specially");
						}
					}
					mapd_restart_channel_plannig(global);
					SLIST_FOREACH_SAFE(_1905_dev, &(global->dev._1905_dev_head), next_1905_device, t_1905_dev) {
						radio = topo_srv_get_radio_by_band_type(_1905_dev, BAND_6G);
						if (no_need_trigger_all)
							global->dev.ch_planning_R2.ch_plan_state = CHPLAN_STATE_CH_CHANGE_TRIGGERED;
						if (radio)
							ch_planning_update_all_dev_state((u8)CHPLAN_STATE_CH_CHANGE_TRIGGERED,
								radio->band, &global->dev);
					}
				}
#if defined(SUPPORT_1905) && defined(SUPPORT_MULTI_AP)
				else {
					notice(DEBUG_CAT_AFC, "sending response");
					struct mapd_global *global = (struct mapd_global *)ctx->back_ptr;

					map_1905_send_afc_report2(global->_1905_ctrl, NULL, dev->afc_spectrum_inquiry_len,
						(u8 *) dev->afc_spectrum_inquiry,
						dev->afc_spectrum_resp_len, (u8 *)dev->afc_spectrum_resp, 0, NULL);
				}
#endif
			}
		}
	}
END:
	if (mem_alloc == 1)
		os_free(payload);

	return status;
}
#ifdef SUPPORT_MULTI_AP
void check_ret_value(int res)
{
	if (res < 0)
		err(DEBUG_CAT_AFC, "error in close file2 pointer\n");
}

int mapd_read_afc_json_file(struct own_1905_device *dev)
{
	FILE *fil = NULL, *file_2 = NULL;
	char buf[MAX_AFC_INQ_RES], *pos, *token;
	int line = 0, res = 0;
	struct _1905_map_device *_1905_dev = topo_srv_get_1905_device(dev, NULL);

	if (_1905_dev == NULL)
		return 0;

	if (_1905_dev->afc_spectrum_query == 1 && _1905_dev->afc_spectrum_resp_flag == 1)
		return 0;

	if ((access(_MAP_AFC_INQ_FILE, F_OK) == 0) && _1905_dev->afc_spectrum_query == 0) {
		fil = fopen(_MAP_AFC_INQ_FILE, "r");

		if (fil == NULL) {
			notice(DEBUG_CAT_AFC, "open MAP cfg file (%s) fail\n", _MAP_AFC_INQ_FILE);
			return 0;
		}

		while (mapd_config_get_line(buf, sizeof(buf), fil, &line, &pos)) {
			if (_1905_dev->afc_spectrum_inquiry == NULL) {
				_1905_dev->afc_spectrum_inquiry = (char *)os_zalloc(MAX_AFC_INQ_RES);
				if (_1905_dev->afc_spectrum_inquiry == NULL) {
					err(DEBUG_CAT_AFC, "malloc fail");
					res = fclose(fil);
					if (res < 0)
						err(DEBUG_CAT_AFC, "error in close file pointer\n");
					return -1;
				}
			}
			res = os_snprintf(_1905_dev->afc_spectrum_inquiry, MAX_AFC_INQ_RES, "%s", pos);
			if (res < 0) {
				err(DEBUG_CAT_AFC, "afc_spectrum_inquiry copy fail\n");
				os_free(_1905_dev->afc_spectrum_inquiry);
				_1905_dev->afc_spectrum_inquiry = NULL;
			}
			_1905_dev->afc_spectrum_inquiry_len = res;
			notice(DEBUG_CAT_AFC, "AFC json %s\n", _1905_dev->afc_spectrum_inquiry);
			break;
		}
		_1905_dev->afc_spectrum_query = 1;

		res = fclose(fil);
		if (res < 0)
			err(DEBUG_CAT_MISC,
		"error in close file pointer\n");

	} else if (_1905_dev->afc_spectrum_query == 1) {
		if (access(_MAP_AFC_RESP_FILE, F_OK) == 0) {
			file_2 = fopen(_MAP_AFC_RESP_FILE, "r");

			if (file_2 == NULL) {
				err(DEBUG_CAT_AFC, "open MAP cfg file (%s) fail\n", _MAP_AFC_RESP_FILE);
				return 0;
			}
			while (mapd_config_get_line(buf, sizeof(buf), file_2, &line, &pos)) {
				token = os_strtok(pos, "=");
				if (token != NULL) {
					if (os_strcmp(token, "Timestamp") == 0) {
						token = os_strtok(NULL, "\n");
						if(token){
							notice(DEBUG_CAT_AFC, "Timestamp %s", token);
							_1905_dev->afc_time = calculate_expiry_time(token);
						}
					} else if (os_strcmp(token, "AFC_RESPONSE") == 0) {
						token = os_strtok(NULL, "\n");
						if(token){
							if (_1905_dev->afc_spectrum_resp == NULL) {
								_1905_dev->afc_spectrum_resp = (char *)os_zalloc(MAX_AFC_INQ_RES);
								if (_1905_dev->afc_spectrum_resp == NULL) {
									err(DEBUG_CAT_AFC, "malloc fail\n");
									res = fclose(file_2);
									check_ret_value(res);
									return -1;
								}
							}
							res = os_snprintf(_1905_dev->afc_spectrum_resp, MAX_AFC_INQ_RES, "%s", token);
							if (res < 0) {
								err(DEBUG_CAT_AFC, "afc_spectrum_inquiry copy fail");
								os_free(_1905_dev->afc_spectrum_inquiry);
								_1905_dev->afc_spectrum_inquiry = NULL;
							}
							_1905_dev->afc_spectrum_resp_len = res;
							notice(DEBUG_CAT_AFC, "AFC json %s\n", _1905_dev->afc_spectrum_resp);
							notice(DEBUG_CAT_AFC, "AFC Response is %s\n", token);
							parse_afc_map_response_payload(dev, _1905_dev, (unsigned char *)token);
							_1905_dev->afc_spectrum_resp_flag = 1;
						}
					} else {
						err(DEBUG_CAT_AFC, "failed to parse AFC response");
						break;
					}
				}
			}
			res = fclose(file_2);
			if (res < 0)
				err(DEBUG_CAT_MISC,
			"error in close file2 pointer\n");
		}
	}
	return 0;
}

void mapd_handle_afc_spectrum_inquiry_msg(struct mapd_global *global, unsigned char *buf, int buf_len)
{
	unsigned char *temp_buf;
	unsigned char almac[ETH_ALEN] = {0};
	int tlv_len = 0, left_tlv_len = buf_len, len, length;
	struct _1905_map_device *dev = NULL;
	struct own_1905_device *ctx = &global->dev;

	temp_buf = (unsigned char *)buf;

	os_memcpy(almac, temp_buf, ETH_ALEN);
	temp_buf += ETH_ALEN;

	dev = topo_srv_get_1905_device(ctx, almac);

	if (dev == NULL) {
		err(DEBUG_CAT_AFC, "device is not found"MACSTR, MAC2STR(almac));
		return;
	}
	notice(DEBUG_CAT_AFC, "AFC Spectrum tlv");

	while (1) {
		len = get_tlv_len(temp_buf);
		tlv_len = len + 3;
		if (left_tlv_len < tlv_len) {
			err(DEBUG_CAT_AFC, "Error TLV len, type = %d, left_tlv_length %d less than tlv_len %d\n",
					*temp_buf, left_tlv_len, tlv_len);
			return;
		}

		if (*temp_buf == CH_PREFERENCE_TYPE) {
			notice(DEBUG_CAT_AFC, "0. AFC Spectrum tlv");
			length = parse_channel_preference_tlv(ctx, temp_buf, dev, len);
			if (length < 0) {
				err(DEBUG_CAT_AFC, "error channel preference tlv");
				return;
			}
			temp_buf += length;
		} else if (*temp_buf == AFC_SPECTRUM_INQUIRY_REQUEST_TLV_TYPE) {
			notice(DEBUG_CAT_AFC, "1. AFC Spectrum tlv");
			temp_buf += tlv_len;
		} else if (*temp_buf == AFC_SPECTRUM_INQUIRY_RESPONSE_TLV_TYPE) {
			notice(DEBUG_CAT_AFC, "2. AFC Spectrum tlv");
			length = get_tlv_len(temp_buf);
			if (length < 0) {
				notice(DEBUG_CAT_AFC, "error AFC Spectrum tlv");
				return;
			}
			temp_buf += 3;
			parse_afc_map_response_payload(ctx, dev, temp_buf);
			temp_buf += tlv_len - 3;
		} else if (*temp_buf == END_OF_TLV_TYPE) {
			break;
		} else {
			notice(DEBUG_CAT_AFC, "3. AFC Spectrum tlv");
			temp_buf += tlv_len;
		}
	}
}
#endif /* SUPPORT_MULTI_AP*/
#endif /* MAP_R6 */
