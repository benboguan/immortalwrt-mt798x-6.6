// SPDX-License-Identifier: MediaTekProprietary
/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2023-2024  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#include <sys/un.h>
#include <sys/time.h>
#include "includes.h"
#include "common.h"
#include "mapd_debug.h"

#include "interface.h"
#include "data_def.h"
#include "client_db.h"
#include "mapd_i.h"
#include "topologySrv.h"
#include "eloop.h"
#include "wapp_if.h"
#include "tlv_parsor.h"
#include "client_db.h"
#include "ap_est.h"
#include "1905_map_interface.h"
#include "BlaT2lmAlgo.h"

#define OFFSET_6G_FH 7000
#define BLA_MAX_DEV_CNT 3

#if defined(MAP_6E_SUPPORT) && defined(MTK_MLO_MAP_SUPPORT)
void mapd_handle_t2lm_response(struct own_1905_device *ctx, struct _1905_map_device *dev, unsigned char *buf)
{
	int length = 0, tlv_len = 0;
	unsigned char *temp_buf, *t2lm_buf, band = 0;
	unsigned int i = 0, j = 0, link_id = 0;
	struct sp_t2lm_request *t2lm_resp = NULL;
	struct associated_clients *client_t2 = NULL;

	if (!ctx || !dev || !buf || dev->device_role == DEVICE_ROLE_CONTROLLER || !dev->upstream_device)
		return;

	temp_buf = buf;
	tlv_len = get_tlv_len(temp_buf);

	length = validate_T2LM_TLV(temp_buf, tlv_len);
	if (length <= 0) {
		err(DEBUG_CAT_BLA,
		"error length");
		return;
	}
	t2lm_resp = (struct sp_t2lm_request *) os_zalloc(length);

	if (t2lm_resp == NULL) {
		err(DEBUG_CAT_BLA,
		"error in memory allocation");
		return;
	}
	t2lm_buf = (unsigned char *)t2lm_resp;

	parse_t2lm_tlv(temp_buf, t2lm_buf);

	client_t2 = topo_srv_get_associate_client(ctx, dev->upstream_device, t2lm_resp->mld_mac);

	debug(DEBUG_CAT_BLA,
	"length %d tlv_len %d t2lm_resp %p client %p", length, tlv_len, t2lm_resp, client_t2);

	if (client_t2 == NULL) {
		os_free(t2lm_resp);
		return;
	}

	for (i = 0; i < 14; i++) {
		if (t2lm_resp->ap_t2lm_mapping[0].t2lm[0] & BIT(i)) {
			link_id = i;
			for (j = 0; j < 3; j++) {
				if (dev->bh_link_id[j] == link_id) {
					switch (j) {
					case 0:
						band |= BAND_2G;
					break;
					case 1:
						band |= BAND_5GL;
					break;
					case 2:
						band |= BAND_6G;
					break;
					default:
						break;
					}
				}
			}
		}
	}
	debug(DEBUG_CAT_BLA,
	"-----------------------------------> band %d", band);
	dev->topo_current_t2lm_conf = band;
	os_free(t2lm_resp);
}

void mapd_handle_t2lm_request(struct mapd_global *global, unsigned char *tmpbuf, int buf_len)
{
	unsigned char *temp_buf;
	unsigned char almac[ETH_ALEN] = {0};
	int tlv_len = 0, left_tlv_len = buf_len, len, length;

	struct sp_t2lm_request *buf = NULL;

	temp_buf = (unsigned char *)tmpbuf;

	os_memcpy(almac, temp_buf, ETH_ALEN);
	temp_buf += ETH_ALEN;

	while (1) {
		len = get_tlv_len(temp_buf);
		tlv_len = len + 3;
		if (left_tlv_len < tlv_len) {
			err(DEBUG_CAT_BLA,
			"Error TLV len, type = %d, left_tlv_length %d less than tlv_len %d\n",
					*temp_buf, left_tlv_len, tlv_len);
			return;
		}
		if (*temp_buf == TID_TO_LINK_MAPPING_POLICY_TLV) {
			err(DEBUG_CAT_BLA,
			"left_tlv_len %d len %d", left_tlv_len, len);
			length = validate_T2LM_TLV(temp_buf, left_tlv_len);
			if (length < 0) {
				err(DEBUG_CAT_BLA,
				"T2LM tlv is not parsed");
				return;
			}

			buf = (struct sp_t2lm_request *) os_zalloc(length);
			parse_t2lm_tlv(temp_buf, (unsigned char *)buf);
			wlanif_issue_wapp_command(global,
				WAPP_USER_SET_TID_TO_LINK_MAP, 0, NULL, NULL, buf,
				length, 0, 0, 0);

			temp_buf += tlv_len;
			os_free(buf);

		} else {
			break;
		}
		left_tlv_len -= tlv_len;
	}

}

int validate_T2LM_TLV(unsigned char *tlv_buf, int left_tlv_len)
{
	unsigned char *buf = tlv_buf;
	int length = 0, tlv_len = get_tlv_len(buf), i, k, j = 0;
	unsigned short num_mapping = 0, link_map_ind = 0;

	if (left_tlv_len < tlv_len || left_tlv_len < 32) {
		err(DEBUG_CAT_BLA,
		"validation failed");
		return -1;
	}
	/*skip tlvType & tlvLenght*/
	buf += 3;

	/*skip is_bSTA_Config(1), MLD_MAC_Addr(6), TID-To-Link_Mapping_Negotiation(1), Reserved(22)*/
	buf += 30;
	num_mapping = be_to_host16(*(unsigned short *)buf);
	/*skip Num_Mapping(2)*/
	buf += 2;
	left_tlv_len -= 32;

	/*is_bSTA_Config(1), MLD_MAC_Addr(6), TID-To-Link_Mapping_Negotiation(1), Num_Mapping(2)*/
	length += 10;

	if (num_mapping > 64) {
		num_mapping = 64;
		err(DEBUG_CAT_BLA,
		"Num_Mapping greater than 64");
	}

	for (i = 0; i < num_mapping && i < 64; i++) {
		if (left_tlv_len < 12) {
			err(DEBUG_CAT_BLA,
			"validation failed");
			return -1;
		}
		/*skip addRemove(1), STA_MLD_MAC_Addr(6), TID-to-Link_Control(1)*/
		buf += 8;

		link_map_ind = *buf;
		/*skip Link_Mapping_Presence_Indicator(1), Expected_Duration(3)*/
		buf += 4;
		for (k = 0; k < MAX_TID_PER_LINK; k++) {
			if (link_map_ind & BIT(k))
				j++;
		}
		length += 12;
		left_tlv_len -= 12;
		if (left_tlv_len < (2*j + 7)) {
			err(DEBUG_CAT_BLA,
			"validation failed");
			return -1;
		}
		left_tlv_len -= (2*j + 7);
		length += 2*j;
	}
	info(DEBUG_CAT_BLA,
	"length %d", length);
	return length;
}

void parse_t2lm_tlv(unsigned char *tlv_buf, unsigned char *out_buf)
{
	unsigned short i, k;
	struct sp_t2lm_request *tid_link_map = (struct sp_t2lm_request *)out_buf;

	/*skip tlvType & tlvLenght*/
	tlv_buf += 3;

	/* is_bSTA_Config */
	tid_link_map->is_bsta_config = (*tlv_buf & 0x80)?1:0;
	tlv_buf++;
	/* MLD_MAC_Addr */
	os_memcpy(tid_link_map->mld_mac, tlv_buf, ETH_ALEN);
	tlv_buf += ETH_ALEN;

	/* TID-To-Link_Mapping_Negotiation */
	tid_link_map->t2lm_negotiation = (*tlv_buf & 0x80)?1:0;
	tlv_buf++;

	/* Reserved */
	tlv_buf += 22;

	/* Num_Mapping */
	tid_link_map->num_mapping = be_to_host16(*(unsigned short *)tlv_buf);
	tlv_buf += 2;

	info(DEBUG_CAT_BLA,
	"tid_link_map->num_mapping %d", tid_link_map->num_mapping);

	if (tid_link_map->num_mapping > 64) {
		tid_link_map->num_mapping = 64;
		err(DEBUG_CAT_BLA,
		"Num_Mapping greater than 64");
	}

	for (i = 0; i < tid_link_map->num_mapping && i < 64; i++) {
		/* addRemove */
		tid_link_map->ap_t2lm_mapping[i].add_remove = (*tlv_buf & 0x80)?1:0;
		tlv_buf++;

		/* STA_MLD_MAC_Addr */
		os_memcpy(tid_link_map->ap_t2lm_mapping[i].sta_ml_mac, tlv_buf, ETH_ALEN);
		tlv_buf += ETH_ALEN;

		/* TID-to-Link_Control */
		tid_link_map->ap_t2lm_mapping[i].t2l_control = *tlv_buf++;
		/* Link_Mapping_Presence_Indicator */
		tid_link_map->ap_t2lm_mapping[i].lm_Presence_Indicator = *tlv_buf++;
		/* Expected_Duration */
		os_memcpy(tid_link_map->ap_t2lm_mapping[i].expected_duration, tlv_buf, 3);
		tlv_buf += 3;

		info(DEBUG_CAT_BLA,
		"lm_Presence_Indicator %d", tid_link_map->ap_t2lm_mapping[i].lm_Presence_Indicator);

		for (k = 0; k < MAX_TID_PER_LINK; k++) {
			if (tid_link_map->ap_t2lm_mapping[i].lm_Presence_Indicator & BIT(k)) {
				tid_link_map->ap_t2lm_mapping[i].t2lm[k] = be_to_host16(*(unsigned short *)tlv_buf);
				err(DEBUG_CAT_BLA,
				"tid_link_map->ap_t2lm_mapping[i].t2lm[%d] %d", k, tid_link_map->ap_t2lm_mapping[i].t2lm[k]);
				tlv_buf += 2;
			}
		}
		/* Reserved */
		tlv_buf += 7;
	}
}

void bla_create_t2lm_request(struct own_1905_device *ctx, struct _1905_map_device *dev,
							 u8 desired_bh_conf, u8 *link_id)
{
	struct sp_t2lm_request *bla_bh_t2lm_req = NULL;
	int len = sizeof(struct sp_t2lm_request) + sizeof(struct ap_t2lm_mapping);
	struct associated_clients *assoc_client = NULL;
	struct map_neighbor_info *neighbor_info = NULL, *t_neighbor_info = NULL;
	struct backhaul_link_info *bh_info = NULL, *tbh_info = NULL;
#ifdef SUPPORT_1905
	struct mapd_global *global = NULL;
#endif
	int i = 0;

	if (ctx == NULL || dev == NULL) {
		err(DEBUG_CAT_BLA,
		"ctx or dev is NULL");
		return;
	}

	SLIST_FOREACH_SAFE(neighbor_info, &dev->neighbors_entry, next_neighbor, t_neighbor_info) {
		if (is_backhaul_ethernet(neighbor_info, dev))
			continue;

		SLIST_FOREACH_SAFE(bh_info, &neighbor_info->bh_head, next_bh, tbh_info) {

			assoc_client = topo_srv_get_associate_client(ctx, dev->upstream_device,
											bh_info->connected_iface_addr);
		}
	}

	if (assoc_client == NULL) {
		err(DEBUG_CAT_BLA,
		"assoc client is null");
		return;
	}

	bla_bh_t2lm_req = (struct sp_t2lm_request *) os_zalloc(len);

	os_memcpy(bla_bh_t2lm_req->mld_mac, assoc_client->mld_addr, ETH_ALEN);
	bla_bh_t2lm_req->is_bsta_config = 1;
	bla_bh_t2lm_req->t2lm_negotiation = 1;
	bla_bh_t2lm_req->num_mapping = 1;
	os_memcpy(bla_bh_t2lm_req->ap_t2lm_mapping->sta_ml_mac, assoc_client->mld_addr, ETH_ALEN);
	bla_bh_t2lm_req->ap_t2lm_mapping->add_remove = 1;
	bla_bh_t2lm_req->ap_t2lm_mapping->t2l_control = 1;
	bla_bh_t2lm_req->ap_t2lm_mapping->lm_Presence_Indicator = 0xFF;

	os_memset(bla_bh_t2lm_req->ap_t2lm_mapping->expected_duration, 0xFF, 3);

	for (i = 0; i < MAX_TID_PER_LINK; i++) {
		if (desired_bh_conf == MLO_2G)
			bla_bh_t2lm_req->ap_t2lm_mapping->t2lm[i] = BIT(link_id[0]);
		else if (desired_bh_conf == MLO_5G)
			bla_bh_t2lm_req->ap_t2lm_mapping->t2lm[i] = BIT(link_id[1]);
		else if (desired_bh_conf == MLO_2G_5G) {
			bla_bh_t2lm_req->ap_t2lm_mapping->t2lm[i] = BIT(link_id[0]);
			bla_bh_t2lm_req->ap_t2lm_mapping->t2lm[i] |= BIT(link_id[1]);
		} else if (desired_bh_conf == MLO_6G)
			bla_bh_t2lm_req->ap_t2lm_mapping->t2lm[i] = BIT(link_id[2]);
		else if (desired_bh_conf == MLO_6G_2G) {
			bla_bh_t2lm_req->ap_t2lm_mapping->t2lm[i] = BIT(link_id[0]);
			bla_bh_t2lm_req->ap_t2lm_mapping->t2lm[i] |= BIT(link_id[2]);
		} else if (desired_bh_conf == MLO_6G_5G) {
			bla_bh_t2lm_req->ap_t2lm_mapping->t2lm[i] = BIT(link_id[1]);
			bla_bh_t2lm_req->ap_t2lm_mapping->t2lm[i] |= BIT(link_id[2]);
		} else {
			bla_bh_t2lm_req->ap_t2lm_mapping->t2lm[i] = BIT(link_id[0]);
			bla_bh_t2lm_req->ap_t2lm_mapping->t2lm[i] |= BIT(link_id[1]);
			bla_bh_t2lm_req->ap_t2lm_mapping->t2lm[i] |= BIT(link_id[2]);
		}
		info(DEBUG_CAT_BLA,
		"bla_bh_t2lm_req->ap_t2lm_mapping->t2lm[%d] %d", i, bla_bh_t2lm_req->ap_t2lm_mapping->t2lm[i]);
	}

#ifdef SUPPORT_1905
	global = (struct mapd_global *)ctx->back_ptr;
	if (global)
		send_t2lm_configuration(global->_1905_ctrl, (char *) dev->_1905_info.al_mac_addr, len, (u8 *)bla_bh_t2lm_req);
#endif
	os_free(bla_bh_t2lm_req);

}
char *bla_bh_conf_to_string(int config)
{
	switch (config) {
	case MLO_2G:
		return "MLO_2G";
	case MLO_5G:
		return "MLO_5G";
	case MLO_2G_5G:
		return "MLO_2G_5G";
	case MLO_6G:
		return "MLO_6G";
	case MLO_6G_2G:
		return "MLO_2G_6G";
	case MLO_6G_5G:
		return "MLO_5G_6G";
	case MLO_2G_5G_6G:
		return "MLO_2G_5G_6G";
	default:
		return "No Mapping";
	}
}

unsigned char bla_check_fronthaul_active(struct own_1905_device *ctx, struct _1905_map_device *dev)
{
	struct mapd_global *global = (struct mapd_global *)ctx->back_ptr;
	u8 active_band = 0;
	struct associated_clients *assoc_cli = NULL;
	struct _1905_map_device *cli_dev = NULL;
	struct client *client;
	uint32_t  idx = 0;

	for (idx = 0; idx < MAX_STA_SEEN; ++idx) {
		if (!is_zero_ether_addr(global->dev.client_db[idx].bssid)) {
			client = &global->dev.client_db[idx];
			if (client == NULL || client->client_id == (uint32_t)-1)
				continue;
			info(DEBUG_CAT_BLA,
			"client->curr_activity_state %d client->activity_state %d" MACSTR,
						client->curr_activity_state, client->activity_state, MAC2STR(client->mac_addr));
			cli_dev = topo_srv_get_1905_by_bssid(ctx, client->bssid);
			if (cli_dev == NULL)
				continue;
			assoc_cli = topo_srv_get_associate_client(ctx, cli_dev, client->mac_addr);
			if (assoc_cli == NULL)
				continue;

			if (client->activity_state) {
				switch (client->current_band) {
				case BAND_2G:
					active_band |= BIT(0);
					break;

				case BAND_5GL:
					active_band |= BIT(1);
					break;
				case BAND_6G:
					active_band |= BIT(2);
					break;
				default:
					break;
				}
			}
		}
	}
	return active_band;
}

unsigned int get_max_fh_phy_rate_band(struct own_1905_device *ctx, unsigned char band)
{
	struct associated_clients *assoc_client = NULL, *temp_assoc_client = NULL;
	struct client *map_client = NULL;
	unsigned char current_rssi = 0;
	uint32_t estimated_rate = 0, max_estimate_rate = 0;
	struct bss_info_db *own_bss = NULL;
	struct _1905_map_device *dev = NULL, *tmp_dev = NULL;

	SLIST_FOREACH_SAFE(dev, &(ctx->_1905_dev_head), next_1905_device, tmp_dev) {
		if (!dev->in_network)
			continue;
		SLIST_FOREACH_SAFE(assoc_client, &(dev->assoc_clients), next_client, temp_assoc_client) {
			current_rssi = assoc_client->rssi_uplink;

			own_bss = assoc_client->bss;
			if (own_bss == NULL || own_bss->radio == NULL) {
				err(DEBUG_CAT_BLA,
				BLA_ALGO_PREX"bss not found "MACSTR, MAC2STR(assoc_client->client_addr));
				continue;
			}

			if (own_bss->radio->band != band)
				continue;

			map_client = client_db_get_client_from_sta_mac((struct mapd_global *)ctx->back_ptr, assoc_client->client_addr);

			if (map_client == NULL || map_client->client_id == (uint32_t)-1) {
				debug(DEBUG_CAT_BLA,
				BLA_ALGO_PREX"map client not found "MACSTR, MAC2STR(assoc_client->client_addr));
				continue;
			}

			estimated_rate = ap_est_map_dl_rssi_to_phyrate_1905_radio((struct mapd_global *)ctx->back_ptr,
							own_bss->radio, map_client, current_rssi);

			estimated_rate = estimated_rate*10;

			info(DEBUG_CAT_BLA,
			"estimated_rate %d current_rssi %d", estimated_rate, current_rssi);
			max_estimate_rate = max_estimate_rate > estimated_rate ? max_estimate_rate : estimated_rate;
		}
	}

	return max_estimate_rate;
}

unsigned int get_max_phy_rate_apcli_link(struct own_1905_device *ctx, struct _1905_map_device *dev,
					u8 apcli_band, u8 apcli_rssi)
{
	unsigned int wireless_mode = 0, bandwidth = 0, streams = 0;
	struct radio_info_db *radio = NULL, *uplink_radio = NULL;
	unsigned int estimate_rate;

	radio = topo_srv_get_radio_by_band_type(dev, apcli_band);
	uplink_radio  = topo_srv_get_radio_by_band_type(dev->upstream_device, apcli_band);

	if (radio == NULL || uplink_radio == NULL)
		return 0;

	wireless_mode = topo_srv_get_wireless_mode(radio->wireless_mode);
	if (wireless_mode == MODE_HE) {
		bandwidth = radio->radio_capability.he_cap.he_160?BW_160:BW_80;
		streams = radio->radio_capability.he_cap.tx_spatial_stream + 1;
#ifdef MAP_EHT_SUPPORT
	} else if (wireless_mode == MODE_EHT) {
		bandwidth = radio->radio_capability.eht_cap.eht_ch_width;
		streams = radio->radio_capability.eht_cap.tx_stream + 1;
#endif
	} else if (wireless_mode == MODE_VHT) {
		bandwidth = radio->radio_capability.vht_cap.vht_160?BW_160:BW_80;
		streams = radio->radio_capability.vht_cap.tx_stream + 1;
	} else if ((wireless_mode == MODE_HTMIX) || (wireless_mode == MODE_HTGREENFIELD)) {
		bandwidth = radio->radio_capability.ht_cap.ht_40?BW_40:BW_20;
		streams = radio->radio_capability.ht_cap.rx_stream + 1;
	}

	info(DEBUG_CAT_BLA,
	"rssi %d mode %d streams %d bw %d", apcli_rssi, wireless_mode, streams, bandwidth);

	estimate_rate = estimate_radio_phyrate(ctx, uplink_radio, apcli_rssi, wireless_mode, streams, bandwidth, dev);

	return (estimate_rate * 4)/3;
}

void find_bh_estimate_rates(struct own_1905_device *ctx, struct _1905_map_device *dev,
		u32 *max_phyrate_apcli_6g, u32 *max_phyrate_apcli_5g, u32 *max_phyrate_apcli_2g, u8 *link_id)
{
	struct map_neighbor_info *neighbor_info = NULL, *t_neighbor_info = NULL;
	struct backhaul_link_info *bh_info = NULL, *tbh_info = NULL;
	unsigned char i, apcli_band, apcli_rssi;
	struct associated_clients *assoc_cli_link = NULL;
#ifdef MAP_R6
	struct affiliated_sta_db *aff_sta = NULL, *aff_sta_tmp = NULL;
#endif /* MAP_R6 */

	SLIST_FOREACH_SAFE(neighbor_info, &dev->neighbors_entry, next_neighbor, t_neighbor_info) {
		if (is_backhaul_ethernet(neighbor_info, dev))
			continue;

		SLIST_FOREACH_SAFE(bh_info, &neighbor_info->bh_head, next_bh, tbh_info) {

			assoc_cli_link = topo_srv_get_associate_client(ctx, dev->upstream_device,
											bh_info->connected_iface_addr);

			if (assoc_cli_link == NULL || assoc_cli_link->bss == NULL)
				continue;
#ifdef MAP_R6
			if (!assoc_cli_link->bss->radio) {
				err(DEBUG_CAT_BLA,
				"assoc_cli_link->bss->radio is null for bssid " MACSTR, MAC2STR(assoc_cli_link->bss->bssid));
				continue;
			}
#endif /* MAP_R6 */
			apcli_band = assoc_cli_link->bss->radio->band;
			apcli_rssi = assoc_cli_link->rssi_uplink;

			if (IS_BAND_6G(apcli_band)) {
				*max_phyrate_apcli_6g = get_max_phy_rate_apcli_link(ctx, dev, apcli_band, apcli_rssi);
#ifdef MAP_R6
				if (dev->R6_dev)
					link_id[2] = assoc_cli_link->bss->mlo_info.link_id;
				else
#endif /* MAP_R6 */
					link_id[2] = assoc_cli_link->link_id;
			} else if (IS_BAND_5G(apcli_band)) {
				*max_phyrate_apcli_5g = get_max_phy_rate_apcli_link(ctx, dev, apcli_band, apcli_rssi);
#ifdef MAP_R6
				if (dev->R6_dev)
					link_id[1] = assoc_cli_link->bss->mlo_info.link_id;
				else
#endif /* MAP_R6 */
					link_id[1] = assoc_cli_link->link_id;
			} else {
				*max_phyrate_apcli_2g = get_max_phy_rate_apcli_link(ctx, dev, apcli_band, apcli_rssi);
#ifdef MAP_R6
				if (dev->R6_dev)
					link_id[0] = assoc_cli_link->bss->mlo_info.link_id;
				else
#endif /* MAP_R6 */
					link_id[0] = assoc_cli_link->link_id;
			}

#ifdef MAP_R6
			if (dev->R6_dev && dev->device_role == DEVICE_ROLE_AGENT) {
				dl_list_for_each_safe(aff_sta, aff_sta_tmp, &dev->mld_bsta.affiliated_sta_list,
						struct affiliated_sta_db, list) {

					if (is_zero_ether_addr(aff_sta->affiliated_sta_bssid))
						continue;

					if (os_memcmp(aff_sta->affiliated_sta_bssid,
								bh_info->connected_iface_addr, ETH_ALEN) == 0) {
						continue;
					}

					assoc_cli_link = topo_srv_get_associate_client(ctx, dev->upstream_device,
							aff_sta->affiliated_sta_bssid);

					if (assoc_cli_link == NULL || assoc_cli_link->bss == NULL) {
						err(DEBUG_CAT_BLA,
						"non set up link is not found");
							continue;
					}
#ifdef MAP_R6
					if (!assoc_cli_link->bss->radio) {
						err(DEBUG_CAT_BLA,
						"assoc_cli_link->bss->radio is null for bssid " MACSTR,
							MAC2STR(assoc_cli_link->bss->bssid));
						continue;
					}
#endif /* MAP_R6 */

					apcli_band = assoc_cli_link->bss->radio->band;
					apcli_rssi = assoc_cli_link->rssi_uplink;

					if (IS_BAND_6G(apcli_band)) {
						*max_phyrate_apcli_6g = get_max_phy_rate_apcli_link(ctx, dev, apcli_band, apcli_rssi);
						link_id[2] = assoc_cli_link->bss->mlo_info.link_id;
					} else if (IS_BAND_5G(apcli_band)) {
						*max_phyrate_apcli_5g = get_max_phy_rate_apcli_link(ctx, dev, apcli_band, apcli_rssi);
						link_id[1] = assoc_cli_link->bss->mlo_info.link_id;
					} else {
						*max_phyrate_apcli_2g = get_max_phy_rate_apcli_link(ctx, dev, apcli_band, apcli_rssi);
						link_id[0] = assoc_cli_link->bss->mlo_info.link_id;
					}
				}
			} else
#endif /* MAP_R6 */
			if (neighbor_info->neighbor->mld_enabled && dev->device_role == DEVICE_ROLE_AGENT) {
				for (i = 0; i < MLO_NON_SETUP_LINK_MAX; i++) {
					if (is_zero_ether_addr(bh_info->mlo_tx[i].connected_iface_addr) ||
						is_zero_ether_addr(bh_info->mlo_rx[i].connected_iface_addr))
						continue;

					assoc_cli_link = topo_srv_get_associate_client(ctx, dev->upstream_device,
											bh_info->mlo_tx[i].connected_iface_addr);

					if (assoc_cli_link == NULL || assoc_cli_link->bss == NULL) {
						err(DEBUG_CAT_BLA,
						"non set up link is not found");
						continue;
					}
#ifdef MAP_R6
					if (!assoc_cli_link->bss->radio) {
						err(DEBUG_CAT_BLA,
						"assoc_cli_link->bss->radio is null for bssid " MACSTR,
							MAC2STR(assoc_cli_link->bss->bssid));
						continue;
					}
#endif /* MAP_R6 */

					apcli_band = assoc_cli_link->bss->radio->band;
					apcli_rssi = assoc_cli_link->rssi_uplink;

					if (IS_BAND_6G(apcli_band)) {
						*max_phyrate_apcli_6g = get_max_phy_rate_apcli_link(ctx, dev, apcli_band, apcli_rssi);
#ifdef MAP_R6
						if (dev->R6_dev)
							link_id[2] = assoc_cli_link->bss->mlo_info.link_id;
						else
#endif /* MAP_R6 */
							link_id[2] = assoc_cli_link->link_id;
					} else if (IS_BAND_5G(apcli_band)) {
						*max_phyrate_apcli_5g = get_max_phy_rate_apcli_link(ctx, dev, apcli_band, apcli_rssi);
#ifdef MAP_R6
						if (dev->R6_dev)
							link_id[1] = assoc_cli_link->bss->mlo_info.link_id;
						else
#endif /* MAP_R6 */
							link_id[1] = assoc_cli_link->link_id;
					} else {
						*max_phyrate_apcli_2g = get_max_phy_rate_apcli_link(ctx, dev, apcli_band, apcli_rssi);
#ifdef MAP_R6
						if (dev->R6_dev)
							link_id[0] = assoc_cli_link->bss->mlo_info.link_id;
						else
#endif /* MAP_R6 */
							link_id[0] = assoc_cli_link->link_id;
					}
				}
			}
		}
	}
}

unsigned char find_bh_t2lm_configuration(struct own_1905_device *ctx, struct _1905_map_device *dev, u8 dev_count)
{
	unsigned char fh_active_band = 0, desired_t2lm_cnf = 0;
	u32 max_dowlink_sta_6g, max_dowlink_sta_5g, max_dowlink_sta_2g;
	u32 max_phyrate_apcli_6g = 0, max_phyrate_apcli_5g = 0, max_phyrate_apcli_2g = 0;
	u8 link_id[3] = {0};
	u8 mlo_1905_band = 0;

	fh_active_band = bla_check_fronthaul_active(ctx, dev);

	info(DEBUG_CAT_BLA,
	"fh_active_band %d", fh_active_band);

	find_bh_estimate_rates(ctx, dev, &max_phyrate_apcli_6g, &max_phyrate_apcli_5g, &max_phyrate_apcli_2g, link_id);

	/*if all link ID is zero means, apcli entry deleted before assoc parsing*/
	if (link_id[0] == 0 && link_id[1] == 0 && link_id[2] == 0) {
		link_id[0] = 0;
		link_id[1] = 1;
		link_id[2] = 2;
	}

	if (dev_count == BLA_MAX_DEV_CNT) {
		max_phyrate_apcli_6g /= 2;
		max_phyrate_apcli_5g /= 2;
		max_phyrate_apcli_2g /= 2;
	}

	info(DEBUG_CAT_BLA,
	"max_phyrate_apcli_6g %d max_phyrate_apcli_5g %d max_phyrate_apcli_2g %d",
				max_phyrate_apcli_6g, max_phyrate_apcli_5g, max_phyrate_apcli_2g);

	info(DEBUG_CAT_BLA,
	"link_id[0]v %d link_id[1] %d link_id[2] %d", link_id[0], link_id[1], link_id[2]);

	os_memcpy(dev->bh_link_id, link_id, 3);

	max_dowlink_sta_6g = get_max_fh_phy_rate_band(ctx, BAND_6G);
	max_dowlink_sta_5g = get_max_fh_phy_rate_band(ctx, BAND_5GL);
	max_dowlink_sta_2g = get_max_fh_phy_rate_band(ctx, BAND_2G);

	info(DEBUG_CAT_BLA,
	"max_dowlink_sta_6g %d max_dowlink_sta_5g %d max_dowlink_sta_2g %d",
				max_dowlink_sta_6g, max_dowlink_sta_5g, max_dowlink_sta_2g);

	if (max_phyrate_apcli_6g == 0 && max_phyrate_apcli_5g != 0 && max_phyrate_apcli_2g != 0)
		mlo_1905_band = MLO_2G_5G;
	else if (max_phyrate_apcli_6g != 0 && max_phyrate_apcli_5g == 0 && max_phyrate_apcli_2g != 0)
		mlo_1905_band = MLO_6G_2G;
	else if (max_phyrate_apcli_6g != 0 && max_phyrate_apcli_5g != 0 && max_phyrate_apcli_2g == 0)
		mlo_1905_band = MLO_6G_5G;
	else
		mlo_1905_band = MLO_2G_5G_6G;

	desired_t2lm_cnf = mlo_1905_band;

	info(DEBUG_CAT_BLA,
	"desired_t2lm_cnf %d", desired_t2lm_cnf);

	switch (fh_active_band) {
	case BAND_NO_ACTIVE:
			desired_t2lm_cnf = mlo_1905_band;
		break;
	case BAND_2G_ACTIVE:
		if (mlo_1905_band == MLO_2G_5G) {
			if (max_phyrate_apcli_5g > max_dowlink_sta_2g)
				desired_t2lm_cnf = MLO_5G;
		} else if (mlo_1905_band == MLO_6G_2G) {
			if (max_phyrate_apcli_6g > max_dowlink_sta_2g)
				desired_t2lm_cnf = MLO_6G;
		} else if (mlo_1905_band == MLO_6G_5G)
			desired_t2lm_cnf = MLO_6G_5G;
		else
			if (max_phyrate_apcli_5g + max_phyrate_apcli_6g > max_dowlink_sta_2g)
				desired_t2lm_cnf = MLO_6G_5G;
		break;
	case BAND_5G_ACTIVE:
		if (mlo_1905_band == MLO_2G_5G) {
			if (max_phyrate_apcli_2g > max_dowlink_sta_5g)
				desired_t2lm_cnf = MLO_2G;
		} else if (mlo_1905_band == MLO_6G_2G)
			desired_t2lm_cnf = MLO_6G_2G;
		else if (mlo_1905_band == MLO_6G_5G) {
			if (max_phyrate_apcli_6g > max_dowlink_sta_5g)
				desired_t2lm_cnf = MLO_6G;
		} else
			if (max_phyrate_apcli_2g + max_phyrate_apcli_6g > max_dowlink_sta_5g)
				desired_t2lm_cnf = MLO_6G_2G;
		break;
	case BAND_2G_5G_ACTIVE:
		if (mlo_1905_band == MLO_2G_5G)
			desired_t2lm_cnf = MLO_2G_5G;
		else if (mlo_1905_band == MLO_6G_2G) {
			if (max_phyrate_apcli_6g > max_dowlink_sta_2g + max_dowlink_sta_5g)
				desired_t2lm_cnf = MLO_6G;
		} else if (mlo_1905_band == MLO_6G_5G) {
			if (max_phyrate_apcli_6g > max_dowlink_sta_2g + max_dowlink_sta_5g)
				desired_t2lm_cnf = MLO_6G;
		} else
			if (max_phyrate_apcli_6g > max_dowlink_sta_2g + max_dowlink_sta_5g)
				desired_t2lm_cnf = MLO_6G;

		break;
	case BAND_6G_ACTIVE:
		if (mlo_1905_band == MLO_2G_5G)
			desired_t2lm_cnf = MLO_2G_5G;
		else if (mlo_1905_band == MLO_6G_2G) {
			if (max_phyrate_apcli_2g > max_dowlink_sta_6g)
				desired_t2lm_cnf = MLO_2G;
		} else if (mlo_1905_band == MLO_6G_5G) {
			if (max_phyrate_apcli_5g > max_dowlink_sta_6g)
				desired_t2lm_cnf = MLO_5G;
		} else
			/*
			 * Consider 6G offset only in case of hop count 2
			 */
			if (dev_count == BLA_MAX_DEV_CNT) {
				if (max_phyrate_apcli_2g + max_phyrate_apcli_5g > (max_dowlink_sta_6g + OFFSET_6G_FH))
					desired_t2lm_cnf = MLO_2G_5G;
			} else {
				if (max_phyrate_apcli_2g + max_phyrate_apcli_5g > max_dowlink_sta_6g)
					desired_t2lm_cnf = MLO_2G_5G;
			}
		break;
	case BAND_6G_2G_ACTIVE:
		if (mlo_1905_band == MLO_2G_5G) {
			if (max_phyrate_apcli_5g > max_dowlink_sta_2g)
				desired_t2lm_cnf = MLO_2G_5G;
		} else if (mlo_1905_band == MLO_6G_2G)
			desired_t2lm_cnf = MLO_6G_2G;
		else if (mlo_1905_band == MLO_6G_5G) {
			if (max_phyrate_apcli_5g > max_dowlink_sta_6g)
				desired_t2lm_cnf = MLO_5G;
		} else
			if (max_phyrate_apcli_5g > max_dowlink_sta_6g + max_dowlink_sta_2g)
				desired_t2lm_cnf = MLO_5G;
		break;
	case BAND_6G_5G_ACTIVE:
		if (mlo_1905_band == MLO_2G_5G) {
			if (max_phyrate_apcli_2g > max_dowlink_sta_5g)
				desired_t2lm_cnf = MLO_2G;
		} else if (mlo_1905_band == MLO_6G_2G) {
			if (max_phyrate_apcli_2g > max_dowlink_sta_6g)
				desired_t2lm_cnf = MLO_2G;
		} else if (mlo_1905_band == MLO_6G_5G)
			desired_t2lm_cnf = MLO_6G_5G;
		else
			if (max_phyrate_apcli_2g > max_dowlink_sta_6g + max_dowlink_sta_5g)
				desired_t2lm_cnf = MLO_2G;
		break;
	case BAND_6G_5G_2G_ACTIVE:
		desired_t2lm_cnf = mlo_1905_band;
		break;
	default:
		err(DEBUG_CAT_BLA,
		"wrong activity state");
		break;
	}

	if (dev->current_t2lm_conf != desired_t2lm_cnf) {
		err(DEBUG_CAT_BLA,
		"need to configure default MLO %s %d", bla_bh_conf_to_string(desired_t2lm_cnf), desired_t2lm_cnf);
		bla_create_t2lm_request(ctx, dev, desired_t2lm_cnf, link_id);
		dev->current_t2lm_conf = desired_t2lm_cnf;
	}
	return 0;
}

void execute_bla_algoritm(struct mapd_global *global)
{
	struct own_1905_device *ctx = &global->dev;
	struct _1905_map_device *dev = NULL, *tmp_dev = NULL;
	struct _1905_map_device *nxt_dev = NULL;
	struct map_neighbor_info *neighbor_info = NULL, *t_neighbor_info = NULL;
	struct backhaul_link_info *bh_info = NULL, *tbh_info = NULL;
	struct radio_info_db *radio = NULL, *tradio = NULL;
	u8 wireless_mode = 0, stop_bla = 0, count = 0;

	SLIST_FOREACH_SAFE(dev, &ctx->_1905_dev_head, next_1905_device, tmp_dev) {
		if (!dev->in_network)
			continue;
		count++;
		SLIST_FOREACH_SAFE(radio, &dev->first_radio, next_radio, tradio) {
			wireless_mode = topo_srv_get_wireless_mode(radio->wireless_mode);
			if (wireless_mode < MODE_EHT) {
				info(DEBUG_CAT_BLA,
				"wireless mode is not supported for bla %d", wireless_mode);
				stop_bla = 1;
				break;
			}
		}
	}

	if (count  > BLA_MAX_DEV_CNT || stop_bla == 1) {
		info(DEBUG_CAT_BLA,
		"More 1905 device than supported in BLA!!");
		return;
	}

	if (count == BLA_MAX_DEV_CNT) {
		stop_bla = 0;
		/* Add check for STAR topology */
		SLIST_FOREACH_SAFE(dev, &ctx->_1905_dev_head, next_1905_device, tmp_dev) {
			if (!dev->in_network || dev->device_role == DEVICE_ROLE_CONTROLLER)
				continue;

			nxt_dev = topo_srv_get_next_1905_device(ctx, dev);
			if (!nxt_dev)
				continue;

			if (!dev->upstream_device ||  !nxt_dev->upstream_device)
				continue;

			if (os_memcmp(dev->upstream_device->_1905_info.al_mac_addr,
						nxt_dev->upstream_device->_1905_info.al_mac_addr, ETH_ALEN) == 0) {
				info(DEBUG_CAT_BLA,
				"STAR topology detected, not supported for BLA");
				stop_bla = 1;
				break;
			}
		}

		if (stop_bla == 1) {
			info(DEBUG_CAT_BLA,
			"Topology not supported in BLA!!");
			return;
		}
	}

	SLIST_FOREACH_SAFE(dev, &ctx->_1905_dev_head, next_1905_device, tmp_dev) {
		if (dev->device_role == DEVICE_ROLE_AGENT && dev->in_network) {
#ifdef MAP_R6
			if (dev->R6_dev && dev->mld_bsta.num_affiliated_sta >= 1) {
				if (dev->policy_config_interval == 0)
					update_policy_config(global, dev, 1);
				dev->policy_config_interval = 5;
				find_bh_t2lm_configuration(ctx, dev, count);
			} else {
#endif /* MAP_R6 */
				SLIST_FOREACH_SAFE(neighbor_info, &dev->neighbors_entry, next_neighbor, t_neighbor_info) {
					if (is_backhaul_ethernet(neighbor_info, dev))
						continue;
					SLIST_FOREACH_SAFE(bh_info, &neighbor_info->bh_head, next_bh, tbh_info) {
						if (bh_info->mlo_link_no >= 1) {
							if (dev->policy_config_interval == 0)
								update_policy_config(global, dev, 1);
							dev->policy_config_interval = 5;
							find_bh_t2lm_configuration(ctx, dev, count);
						}
					}
				}
#ifdef MAP_R6
			}
#endif /* MAP_R6 */
		}
	}
}
#endif
