/* SPDX-License-Identifier: MediaTekProprietary*/
/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2023-2024  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#ifndef BLA_T2LM_ALGO_H
#define BLA_T2LM_ALGO_H

enum band_activity {
	BAND_NO_ACTIVE,
	BAND_2G_ACTIVE,
	BAND_5G_ACTIVE,
	BAND_2G_5G_ACTIVE,
	BAND_6G_ACTIVE,
	BAND_6G_2G_ACTIVE,
	BAND_6G_5G_ACTIVE,
	BAND_6G_5G_2G_ACTIVE,
};

enum mlo_tid_conf {
	MLO_2G = 1,
	MLO_5G,
	MLO_2G_5G,
	MLO_6G,
	MLO_6G_2G,
	MLO_6G_5G,
	MLO_2G_5G_6G,
};

struct GNU_PACKED ap_t2lm_mapping {
	unsigned char sta_ml_mac[ETH_ALEN];
	unsigned char add_remove;
	unsigned char t2l_control;
	unsigned char lm_Presence_Indicator;
	unsigned char expected_duration[3];
	unsigned short t2lm[MAX_TID_PER_LINK];
};

struct GNU_PACKED sp_t2lm_request {
	unsigned char mld_mac[ETH_ALEN];
	unsigned char is_bsta_config;
	unsigned char t2lm_negotiation;
	unsigned short num_mapping;
	struct ap_t2lm_mapping ap_t2lm_mapping[];
};

void mapd_handle_t2lm_response(struct own_1905_device *ctx, struct _1905_map_device *dev, unsigned char *buf);
void mapd_handle_t2lm_request(struct mapd_global *global, unsigned char *tmpbuf, int buf_len);
void execute_bla_algoritm(struct mapd_global *global);
int validate_T2LM_TLV(unsigned char *tlv_buf, int left_tlv_len);
void parse_t2lm_tlv(unsigned char *tlv_buf, unsigned char *out_buf);
int send_t2lm_configuration(IN struct _1905_context *ctx, char *almac,
	unsigned short len, unsigned char *payload);
void bla_create_t2lm_request(struct own_1905_device *ctx, struct _1905_map_device *dev,
	u8 desired_bh_conf, u8 *link_id);
void find_bh_estimate_rates(struct own_1905_device *ctx, struct _1905_map_device *dev,
	u32 *max_phyrate_apcli_6g, u32 *max_phyrate_apcli_5g, u32 *max_phyrate_apcli_2g, u8 *link_id);
#endif

