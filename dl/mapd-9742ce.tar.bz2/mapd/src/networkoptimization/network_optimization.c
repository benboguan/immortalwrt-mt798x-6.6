/*
***************************************************************************
*  Mediatek Inc.
* 4F, No. 2 Technology 5th Rd.
* Science-based Industrial Park
* Hsin-chu, Taiwan, R.O.C.
*
* (c) Copyright 2002-2011, Mediatek, Inc.
*
* All rights reserved. Mediatek's source code is an unpublished work and the
* use of a copyright notice does not imply otherwise. This source code
* contains confidential trade secret material of Ralink Tech. Any attemp
* or participation in deciphering, decoding, reverse engineering or in any
* way altering the source code is stricitly prohibited, unless the prior
* written consent of Mediatek, Inc. is obtained.
***************************************************************************

                Module Name:
                Network Optmization

                Abstract:
                Network Optmization in MAP network

                Revision History:
                Who         When          What
                --------    ----------    -----------------------------------------
                Avishad.V   2018/05/02		First implementation of the Netowork Optimization feature
*/
#include "includes.h"
#include "common.h"
#include "steer_fsm.h"
#include "list.h"
#include "client_db.h"
#include "mapd_i.h"
#include "db.h"
#include "data_def.h"
#include "chan_mon.h"
#include "data_def.h"
#include "topologySrv.h"
#include "client_mon.h"
	//#include <sys/queue.h>
#include "eloop.h"
#include "steer_action.h"
#include "ap_est.h"
#include "eloop.h"
#include "wapp_if.h"
#include <assert.h>
#include <sys/un.h>
#include "1905_map_interface.h"
#include "network_optimization.h"
#ifdef WIFI_MD_COEX_SUPPORT
#include "ch_planning.h"
#endif
#include "tlv_parsor.h"
extern u8 ZERO_MAC_ADDR[ETH_ALEN];

/*set / reset Network optimziation */
void update_ntwrk_opt_in_dat_file(unsigned char value)
{
	char cmd[200];
	memset(cmd,0,sizeof(cmd));

#ifndef CONFIG_SUPPORT_OPENWRT
	if (os_snprintf(cmd, sizeof(cmd), "nvram_set 2860 NetworkOptimizationEnabled %d &", value) < 0)
		err(DEBUG_CAT_NETOPT, NETOPT_PREX"os_snprintf cmd error\n");
	if (system((const char *)cmd) == -1)
		err(DEBUG_CAT_NETOPT, NETOPT_PREX"system() call return value is equal to -1\n");
#else
	if (os_snprintf(cmd, sizeof(cmd), "wificonf -f %s set NetworkOptimizationEnabled %d",
		g_map_cfg_path, value) < 0)
		err(DEBUG_CAT_NETOPT, NETOPT_PREX"os_snprintf cmd error\n");
	if (system((const char *)cmd) == -1)
		err(DEBUG_CAT_NETOPT, NETOPT_PREX"system() call return value is equal to -1\n");
#endif
}

unsigned char is_all_dev_state_done(struct own_1905_device *dev)
{
	struct _1905_map_device *_1905_dev = NULL, *t_1905_dev = NULL;
	unsigned char state = REALIZATION_DONE; //if all are complete
	struct os_time now;
	os_get_time(&now);
	SLIST_FOREACH_SAFE(_1905_dev, &dev->_1905_dev_head, next_1905_device, t_1905_dev) {
		notice(DEBUG_CAT_NETOPT, NETOPT_PREX" ALMAC "MACSTR" State %d\n",
		 MAC2STR(_1905_dev->_1905_info.al_mac_addr), _1905_dev->network_opt_per1905.network_opt_device_state);
		if (!(_1905_dev->in_network) &&
			!(_1905_dev->network_opt_per1905.network_opt_device_state == NETOPT_STATE_OPT_NET_REALIZATION_ONGOING)) {
			_1905_dev->network_opt_per1905.network_opt_device_state = NETOPT_STATE_COMPLETE;
				continue;
		}
		if((_1905_dev->network_opt_per1905.network_opt_device_state == NETOPT_STATE_OPT_NET_REALIZATION_ONGOING) ||
			(_1905_dev->network_opt_per1905.network_opt_device_state == NETOPT_STATE_OPT_NET_BHSTEER_DONE))
		{	
			if (now.sec > (_1905_dev->network_opt_per1905.bh_steer_start_ts.sec + 
						dev->network_optimization.bh_steer_wait_time)) {
				notice(DEBUG_CAT_NETOPT, NETOPT_PREX" BHSteer timeout, mark complete\n");
				_1905_dev->network_opt_per1905.network_opt_device_state = NETOPT_STATE_COMPLETE;
				continue;
			} else {
				state = REALIZATION_ONGOING;
				break;
			}
		} else if (_1905_dev->network_opt_per1905.network_opt_device_state == NETOPT_STATE_OPT_NET_NEED_TO_REALIZE){
			notice(DEBUG_CAT_NETOPT, NETOPT_PREX" Trigger new realization\n");
			state = TRIGGER_NEW_REALIZATION;
		}
	}
	return state;
}
struct _1905_map_device * find_est_dev_least_hop_cnt(struct own_1905_device *dev)
{
	struct _1905_map_device *least_hop_1905 = NULL;
	struct optimized_network *opt_1905_device = NULL, *t_opt_1905_device = NULL;

	if(SLIST_EMPTY(&(dev->network_optimization.first_opt_net_dev)))
	{ 
		err(DEBUG_CAT_NETOPT, NETOPT_PREX" opt network list is empty\n");
		network_opt_reset(dev->back_ptr);
		dev->network_optimization.NetOptReason = REASON_TRY_AGAIN;
#ifdef MAP_R2
		handle_task_completion(dev);
#endif
		return NULL;
	}
	SLIST_FOREACH_SAFE( opt_1905_device,&dev->network_optimization.first_opt_net_dev, next_opt_net_dev, t_opt_1905_device)
	{
		if(opt_1905_device->opt_net_dev->network_opt_per1905.network_opt_device_state == NETOPT_STATE_OPT_NET_NEED_TO_REALIZE)
		{	
			info(DEBUG_CAT_NETOPT, NETOPT_PREX" least hop count dev init\n");
			least_hop_1905 = opt_1905_device->opt_net_dev;
			break;
		}
	}

	if (!least_hop_1905)
		return NULL;
	t_opt_1905_device = NULL;
	SLIST_FOREACH_SAFE( opt_1905_device,&dev->network_optimization.first_opt_net_dev, next_opt_net_dev, t_opt_1905_device)
	{
		if(opt_1905_device->opt_net_dev->network_opt_per1905.est_hop_count < least_hop_1905->network_opt_per1905.est_hop_count)
		{ 
			if(opt_1905_device->opt_net_dev->network_opt_per1905.network_opt_device_state == NETOPT_STATE_OPT_NET_NEED_TO_REALIZE)
			{ 
				least_hop_1905 = opt_1905_device->opt_net_dev;
			}
		}	
	}

	return least_hop_1905;
}
unsigned char is_eth_BH(struct _1905_map_device *_1905_device)
{
	unsigned char is_eth = 0;
	struct backhaul_link_info *bh_entry = NULL, *tbh_entry = NULL;
	struct map_neighbor_info *neighbor = NULL, *tneighbor = NULL;
	struct iface_info *iface = NULL;
	if (_1905_device->upstream_device == NULL)
		return 0;

	SLIST_FOREACH_SAFE(neighbor, &_1905_device->neighbors_entry, next_neighbor, tneighbor) {
		if(os_memcmp(neighbor->n_almac, _1905_device->upstream_device->_1905_info.al_mac_addr,ETH_ALEN) ==0)
		{
			break;
		}
	}
	if (neighbor) {	
	SLIST_FOREACH_SAFE(bh_entry, &neighbor->bh_head, next_bh, tbh_entry) {
		if(bh_entry) {
			iface = topo_srv_get_iface(_1905_device , bh_entry->connected_iface_addr);
			if(!iface)
				return -1;
			if(iface->media_type == ieee_802_3_ab || iface->media_type == ieee_802_3_u) {
				is_eth = 1;
				break;
			}
		}
	}
		}
return is_eth;
}
void Optimized_network_realization(struct mapd_global *global)
{
	struct own_1905_device *dev = &global->dev;
	struct _1905_map_device *_1905_dev = NULL, *target_1905 = NULL;
	struct bss_info_db *target_bss = NULL;
	struct radio_info_db *max_radio = NULL;
	struct N_O_link_estimate_cb *max_link = NULL;
	struct iface_info *iface = NULL, *tiface = NULL;
	struct radio_info_db *radio_apcli_t = NULL, *radio_apcli = NULL;
#ifdef MTK_MLO_MAP_SUPPORT
	struct radio_info_db *radio_t = NULL, *tradio = NULL;
#endif
	int min_op_class = 0;
//find the first device on which BH steer needs to be triggered
	while (1) {
		_1905_dev = find_est_dev_least_hop_cnt(dev);
		if (_1905_dev == NULL) {
			err(DEBUG_CAT_NETOPT, NETOPT_PREX" 1905 dev is NULL return and move to netopt idle state\n");
			return;
		}
		if (_1905_dev->device_role == DEVICE_ROLE_CONTROLLER)
		{	
			_1905_dev->network_opt_per1905.network_opt_device_state = NETOPT_STATE_COMPLETE;
			notice(DEBUG_CAT_NETOPT, NETOPT_PREX" controller state update as complete\n");
			continue;
		}
		if (!_1905_dev->in_network) {
			_1905_dev->network_opt_per1905.network_opt_device_state = NETOPT_STATE_COMPLETE;
			notice(DEBUG_CAT_NETOPT, NETOPT_PREX" device is not in network\n");
			continue;
		}
		if (_1905_dev && _1905_dev->device_role == DEVICE_ROLE_AGENT && _1905_dev->upstream_device == NULL) {
			_1905_dev->network_opt_per1905.network_opt_device_state = NETOPT_STATE_COMPLETE;
			err(DEBUG_CAT_NETOPT, NETOPT_PREX" topology response not received yet.\n");
			return;
		}
		if (is_eth_BH(_1905_dev)) {
			_1905_dev->network_opt_per1905.network_opt_device_state = NETOPT_STATE_COMPLETE;
			notice(DEBUG_CAT_NETOPT, NETOPT_PREX" ethernet BH device mark state as complete\n");
			continue;
		}
		if (_1905_dev->network_opt_per1905.network_opt_device_state == NETOPT_STATE_COMPLETE)
		{	
			notice(DEBUG_CAT_NETOPT, NETOPT_PREX" dev state is already realization done, no need for BH steer\n");
			continue;
		}
		if (_1905_dev->network_opt_per1905.network_opt_device_state == NETOPT_STATE_OPT_NET_NEED_TO_REALIZE)
		{
			_1905_dev->network_opt_per1905.network_opt_device_state = NETOPT_STATE_OPT_NET_REALIZATION_ONGOING;
			notice(DEBUG_CAT_NETOPT, NETOPT_PREX" realize for ALMAC "MACSTR"\n", MAC2STR(_1905_dev->_1905_info.al_mac_addr));
			break;
		}
	}
	if (_1905_dev->network_opt_per1905.max_score_radio)
	{
		max_radio = _1905_dev->network_opt_per1905.max_score_radio;
		if (max_radio->network_opt_1905dev_radio.max_score_link)
		{
			max_link = max_radio->network_opt_1905dev_radio.max_score_link;
		}
		else
		{
			err(DEBUG_CAT_NETOPT, NETOPT_PREX" max score link is null\n");
			network_opt_reset(global);
			dev->network_optimization.NetOptReason = REASON_TRY_AGAIN;
#ifdef MAP_R2
			handle_task_completion(dev);
#endif
			return;
		}
	}
	else
		{
			err(DEBUG_CAT_NETOPT, NETOPT_PREX" max score radio is NULL\n");
			network_opt_reset(global);
			dev->network_optimization.NetOptReason = REASON_TRY_AGAIN;
#ifdef MAP_R2
			handle_task_completion(dev);
#endif
			return;
		}
//find the target 1905 BSSID 
	if (_1905_dev->network_opt_per1905.est_upstream_device)
		target_1905=_1905_dev->network_opt_per1905.est_upstream_device;
	else {
		err(DEBUG_CAT_NETOPT, NETOPT_PREX" no valid upstream dev present\n");
		network_opt_reset(global);
		dev->network_optimization.NetOptReason = REASON_TRY_AGAIN;
#ifdef MAP_R2
		handle_task_completion(dev);
#endif
		return;
	}
// if the current upstream device is the target upstream then 
//check if the _1905 dev in opt network under consideration is connected to upstream with same radio now as per the max link
//directly move state to realization done for this dev , no need to BH steer 
	notice(DEBUG_CAT_NETOPT, NETOPT_PREX"max_radio->uplink_bh_present = %d\n", max_radio->uplink_bh_present);
	if ((_1905_dev->network_opt_per1905.est_upstream_device == _1905_dev->upstream_device) &&
		(max_radio->uplink_bh_present))
	{
		notice(DEBUG_CAT_NETOPT, NETOPT_PREX" current upstream same as est upstream return\n");
		_1905_dev->network_opt_per1905.network_opt_device_state = NETOPT_STATE_COMPLETE;
		return;
	}		

#ifdef MTK_MLO_MAP_SUPPORT
	/* Customer needs to not do bh steer if the MLD device final
	 * is same as connected MLD,
	 * as no benefit from taking best link as setup link.
	 */
	if (_1905_dev->upstream_device)
		err(DEBUG_CAT_NETOPT, NETOPT_PREX"1905_dev uplink dev = "MACSTR"\n", MAC2STR(_1905_dev->upstream_device->_1905_info.al_mac_addr));
	if (dev->mlo_bh_priority == 1 && _1905_dev->mld_same_bh_priority) {
		if ((_1905_dev->network_opt_per1905.est_upstream_device == _1905_dev->upstream_device) &&
		     max_radio->radio_capability.mlo_cap.MloCapPerRole[1].mlo_enable) {
			/*find radio to get the correct op_class*/
			radio_t = topo_srv_get_next_radio(_1905_dev, radio_t);
			while (radio_t) {
				if (radio_t->uplink_bh_present &&
					radio_t->radio_capability.mlo_cap.MloCapPerRole[1].mlo_enable) {
					notice(DEBUG_CAT_NETOPT, BH_STEER_PREX"MLO case: BH steer is avoided as the current BH band:%d "
					MACSTR" of mld group\n", radio_t->band, MAC2STR(radio_t->identifier));
					_1905_dev->network_opt_per1905.network_opt_device_state = NETOPT_STATE_COMPLETE;
					return;
				}
				radio_t = topo_srv_get_next_radio(_1905_dev, radio_t);
			}
			radio_t = NULL;
		}
	}
#endif

	target_bss = topo_srv_get_bss_by_bssid(&global->dev, target_1905, max_link->peer_mac);
	if(target_bss == NULL) {
		err(DEBUG_CAT_NETOPT, NETOPT_PREX" target bss not found\n");
		network_opt_reset(global);
		dev->network_optimization.NetOptReason = REASON_TRY_AGAIN;
#ifdef MAP_R2
		handle_task_completion(dev);
#endif
		return ;
	}
#ifdef MAP_R6
	if (!target_bss->radio) {
		err(DEBUG_CAT_NETOPT, NETOPT_PREX" target bss radio not found\n");
		network_opt_reset(global);
		dev->network_optimization.NetOptReason = REASON_TRY_AGAIN;
#ifdef MAP_R2
		handle_task_completion(dev);
#endif
		return;
	}
#endif /* MAP_R6 */
	/*find radio to get the correct op_class*/
	radio_apcli_t = topo_srv_get_next_radio(_1905_dev, radio_apcli_t);
	while (radio_apcli_t) {
		if (target_bss->radio->band == radio_apcli_t->band) {
			notice(DEBUG_CAT_NETOPT, BH_STEER_PREX"apcli radio band match\n");
			radio_apcli = radio_apcli_t;
			break;
		}
		radio_apcli_t = topo_srv_get_next_radio(_1905_dev, radio_apcli_t);
	}

	if (!radio_apcli) {
		notice(DEBUG_CAT_NETOPT, BH_STEER_PREX"apcli radio band match not found\n");
		return;
	}

	/*find the relevant apcli mac address*/
	SLIST_FOREACH_SAFE(iface, &(_1905_dev->_1905_info.first_iface), next_iface, tiface) {
		if ((iface->media_type >= ieee_802_11_b &&
			iface->media_type < ieee_1901_wavelet
			) && iface->ap_role == 0x4 && iface->is_map_if == 1){
			info(DEBUG_CAT_NETOPT, NETOPT_PREX" iface->is_map_if %d\n", iface->is_map_if);
			info(DEBUG_CAT_NETOPT, NETOPT_PREX" iface->media_type %d\n", iface->media_type);
			info(DEBUG_CAT_NETOPT, NETOPT_PREX" iface->ap_role  %u\n", iface->ap_role);
			info(DEBUG_CAT_NETOPT, NETOPT_PREX" iface->channel %u\n", iface->channel);
			info(DEBUG_CAT_NETOPT, NETOPT_PREX" max_radio->channel[0] %d\n",max_radio->channel[0]);
			info(DEBUG_CAT_NETOPT, NETOPT_PREX" selected agent "MACSTR"\n", MAC2STR(iface->iface_addr));
			break;
		}
	}

	if (iface == NULL)
	{
		err(DEBUG_CAT_NETOPT, NETOPT_PREX" iface is null\n");
		network_opt_reset(global);
		dev->network_optimization.NetOptReason = REASON_TRY_AGAIN;
#ifdef MAP_R2
		handle_task_completion(dev);
#endif
		return;
	}

	/*ax7800 IOT issue BW 320 not known to ax7800 hence BH steer dropped.*/
	min_op_class = (chan_mon_get_bw_from_op_class(target_bss->radio->operating_class)
			> chan_mon_get_bw_from_op_class(radio_apcli->operating_class))
			? radio_apcli->operating_class : target_bss->radio->operating_class;

	notice(DEBUG_CAT_NETOPT, NETOPT_PREX" #### Network Opt BH steer command data ####\n");
	notice(DEBUG_CAT_NETOPT, NETOPT_PREX" max_radio "MACSTR"\n", MAC2STR(max_radio->identifier));
	notice(DEBUG_CAT_NETOPT, NETOPT_PREX" Device "MACSTR"\n", MAC2STR(_1905_dev->_1905_info.al_mac_addr));
	notice(DEBUG_CAT_NETOPT, NETOPT_PREX" Iface "MACSTR"\n", MAC2STR(iface->iface_addr));
	notice(DEBUG_CAT_NETOPT, NETOPT_PREX" peer_mac "MACSTR"\n", MAC2STR(max_link->peer_mac));
	notice(DEBUG_CAT_NETOPT, NETOPT_PREX" class %d ,channel %d\n", min_op_class, target_bss->radio->channel[0]);
	os_get_time(&_1905_dev->network_opt_per1905.bh_steer_start_ts);
//give BH steer command
	os_memcpy(iface->uplink_bss, ZERO_MAC_ADDR, ETH_ALEN);
	map_1905_Send_Backhaul_Steering_Request_Message(global->_1905_ctrl, 
		(char *)_1905_dev->_1905_info.al_mac_addr,
		(unsigned char *)iface->iface_addr,
		(unsigned char *)max_link->peer_mac,
		min_op_class,
		target_bss->radio->channel[0]);
#ifdef MTK_MLO_MAP_SUPPORT
	_1905_dev->mld_same_bh_priority = 1;
	for (int i = 0; i < MAX_NUM_OF_RADIO; i++) {
		SLIST_FOREACH_SAFE(radio_t, &_1905_dev->first_radio, next_radio, tradio) {
			radio_t->bh_priority = 1;
		}
	}
#endif

	dev->network_optimization.network_opt_state = NETOPT_STATE_OPT_NET_REALIZATION_ONGOING;
}

#ifdef MTK_MLO_MAP_SUPPORT
void dump_max_score_device_info_mld(struct _1905_map_device *max_score_dev)
{
	if (max_score_dev->network_opt_per1905.max_score_radio) {
		notice(DEBUG_CAT_NETOPT, NETOPT_PREX" max device almac "MACSTR"\n", MAC2STR(max_score_dev->_1905_info.al_mac_addr));
		notice(DEBUG_CAT_NETOPT, NETOPT_PREX" max radio identifier "MACSTR"\n",
		 MAC2STR(max_score_dev->network_opt_per1905.max_score_radio->identifier));
		notice(DEBUG_CAT_NETOPT, NETOPT_PREX" max radio channel %d\n",
		 max_score_dev->network_opt_per1905.max_score_radio->channel[0]);
		if (max_score_dev->network_opt_per1905.max_mld_dev) {
			notice(DEBUG_CAT_NETOPT, NETOPT_PREX" DEV ALMAC "MACSTR"\n",
			 MAC2STR(max_score_dev->network_opt_per1905.max_mld_dev->dev_almac));
			notice(DEBUG_CAT_NETOPT, NETOPT_PREX" MLD MAC "MACSTR"\n",
			 MAC2STR(max_score_dev->network_opt_per1905.max_mld_dev->mld_mac));
			notice(DEBUG_CAT_NETOPT, NETOPT_PREX" max_score of link %d , latched est max_score %d\n",
				max_score_dev->network_opt_per1905.max_score_radio->network_opt_1905dev_radio.max_score_link->estimated_score,
				max_score_dev->network_opt_per1905.score_mld.est_max_score_mld);
		}
		notice(DEBUG_CAT_NETOPT, NETOPT_PREX" estimated hop count mld %d\n",
		 max_score_dev->network_opt_per1905.score_mld.est_hop_count_mld);
	}
}
#endif

void dump_max_score_device_info(struct _1905_map_device *max_score_dev)
{
	if (max_score_dev->network_opt_per1905.max_score_radio) {
		notice(DEBUG_CAT_NETOPT, NETOPT_PREX" max device almac\n"MACSTR,
		 MAC2STR(max_score_dev->_1905_info.al_mac_addr));
		notice(DEBUG_CAT_NETOPT, NETOPT_PREX" max radio identifier\n"MACSTR,
		 MAC2STR(max_score_dev->network_opt_per1905.max_score_radio->identifier));
		notice(DEBUG_CAT_NETOPT, NETOPT_PREX" max radio channel %d\n",
		 max_score_dev->network_opt_per1905.max_score_radio->channel[0]);
		if(max_score_dev->network_opt_per1905.max_score_radio->network_opt_1905dev_radio.max_score_link)
		{
			notice(DEBUG_CAT_NETOPT, NETOPT_PREX" peer_MAC or BSSID\n"MACSTR,
			 MAC2STR(max_score_dev->network_opt_per1905.max_score_radio->network_opt_1905dev_radio.max_score_link->peer_mac));
			notice(DEBUG_CAT_NETOPT, NETOPT_PREX" PEER ALMAC "MACSTR"\n",
			 MAC2STR(max_score_dev->network_opt_per1905.max_score_radio->network_opt_1905dev_radio.max_score_link->dev_almac));
			notice(DEBUG_CAT_NETOPT, NETOPT_PREX" max_score of link %d , latched est max_score %d\n",
				max_score_dev->network_opt_per1905.max_score_radio->network_opt_1905dev_radio.max_score_link->estimated_score,
				max_score_dev->network_opt_per1905.est_max_score);
		}
		notice(DEBUG_CAT_NETOPT, NETOPT_PREX" estimated hop count %d\n",
		 max_score_dev->network_opt_per1905.est_hop_count);
	}
}
void dump_est_opt_net(struct own_1905_device *dev)
{
	struct optimized_network *opt_1905_device = NULL, *t_opt_1905_device = NULL;
	if(SLIST_EMPTY(&(dev->network_optimization.first_opt_net_dev)))
	{
		err(DEBUG_CAT_NETOPT, NETOPT_PREX" opt network link list is empty\n");
		return;
	}
	SLIST_FOREACH_SAFE( opt_1905_device,&dev->network_optimization.first_opt_net_dev, next_opt_net_dev, t_opt_1905_device)
	{
		notice(DEBUG_CAT_NETOPT, NETOPT_PREX" device "MACSTR"\n", MAC2STR(opt_1905_device->opt_net_dev->_1905_info.al_mac_addr));
		notice(DEBUG_CAT_NETOPT, NETOPT_PREX" est hop_count %d est max_score  %d\n",
			opt_1905_device->opt_net_dev->network_opt_per1905.est_hop_count,
			opt_1905_device->opt_net_dev->network_opt_per1905.est_max_score);
#ifdef MTK_MLO_MAP_SUPPORT
		notice(DEBUG_CAT_NETOPT, NETOPT_PREX" est hop_count_mld %d est max_score_mld  %d\n",
			opt_1905_device->opt_net_dev->network_opt_per1905.score_mld.est_hop_count_mld,
			opt_1905_device->opt_net_dev->network_opt_per1905.score_mld.est_max_score_mld);
#endif
		if(opt_1905_device->opt_net_dev->network_opt_per1905.est_upstream_device) {
			notice(DEBUG_CAT_NETOPT, NETOPT_PREX" upstream device "MACSTR"\n",
			 MAC2STR(opt_1905_device->opt_net_dev->network_opt_per1905.est_upstream_device->_1905_info.al_mac_addr));
		} else {
			err(DEBUG_CAT_NETOPT, NETOPT_PREX" upstream is NULL\n");
		}
	}
}
void add_dev_to_opt_net(
	struct _1905_map_device *_1905_dev,
	struct own_1905_device *dev)
{
	struct optimized_network *opt_1905_device = NULL;
	opt_1905_device = 	os_zalloc(sizeof(struct optimized_network));
	if (!opt_1905_device) {
		err(DEBUG_CAT_NETOPT, "mem allocation failed\n");
		return;
	}
	opt_1905_device->opt_net_dev = _1905_dev;
	SLIST_INSERT_HEAD(
		&(dev->network_optimization.first_opt_net_dev),
		opt_1905_device,
		next_opt_net_dev);
}

unsigned char is_link_already_present(struct N_O_link_estimate_cb  *link,struct _1905_map_device *_1905_device)
{
	struct _1905_map_device *upstream_dev = _1905_device->upstream_device;
	notice(DEBUG_CAT_NETOPT, NETOPT_PREX" link ALMAC "MACSTR"\n", MAC2STR(link->dev_almac));
	notice(DEBUG_CAT_NETOPT, NETOPT_PREX" upstream_dev ALMAC "MACSTR"\n", MAC2STR(upstream_dev->_1905_info.al_mac_addr));
	if (os_memcmp(link->dev_almac,upstream_dev->_1905_info.al_mac_addr,ETH_ALEN) == 0)
	{
		return 1;
	}
	return 0;
}

#ifdef MTK_MLO_MAP_SUPPORT
u8 compute_and_compare_NO_score_6G(struct radio_info_db *max_score_link_5G,
				   struct radio_info_db *max_score_link_6G,
				   u8 reduce_per_5G)
{
	unsigned int new_score_5G = 0;

	/* new score reduced of 5G by = curr_estimated_5G(100 - diff of ch_utils)*/
	new_score_5G = (max_score_link_5G->network_opt_1905dev_radio.max_score_link->estimated_score
			* (reduce_per_5G))/100;

	notice(DEBUG_CAT_NETOPT, NETOPT_PREX" reduced 5G score %u reduced by %d\n", new_score_5G, reduce_per_5G);
	info(DEBUG_CAT_NETOPT, NETOPT_PREX" old 6G score = %u, old 5G score = %u\n",
			max_score_link_6G->network_opt_1905dev_radio.max_score_link->estimated_score,
			max_score_link_5G->network_opt_1905dev_radio.max_score_link->estimated_score);

	if (max_score_link_6G->network_opt_1905dev_radio.max_score_link->estimated_score >= new_score_5G) {
		max_score_link_5G->network_opt_1905dev_radio.max_score_link->estimated_score = new_score_5G;
		return 1;
	}

	return 0;
}

u8 compare_estimated_rate(struct radio_info_db *max_score_link_5G,
			  struct radio_info_db *max_score_link_6G)
{
	if (max_score_link_5G->network_opt_1905dev_radio.max_score_link->estimated_score
	    > max_score_link_6G->network_opt_1905dev_radio.max_score_link->estimated_score)
		return 1;

	return 0;
}

u32 ch_util_by_per(u32 ch_util)
{
	return ((ch_util*100)/255);
}

int compare_ch_util_5G_6G(struct own_1905_device *dev,
			  struct radio_info_db *max_score_link_5G,
			  struct radio_info_db *max_score_link_6G)
{
	u8 ch_util_entry_5G = 0;
	u8 ch_util_entry_6G = 0;
	u32 average_ch_util_5G = 0;
	u32 average_ch_util_6G = 0;
	u8 i = 0;

	ch_util_entry_5G = max_score_link_5G->netopt_ch_util_cnt_completed ?
			   dev->network_optimization.netopt_ch_util_sec :
			   max_score_link_5G->netopt_ch_util_cnt;

	ch_util_entry_6G = max_score_link_6G->netopt_ch_util_cnt_completed ?
			   dev->network_optimization.netopt_ch_util_sec :
			   max_score_link_6G->netopt_ch_util_cnt;

	if (ch_util_entry_5G == 0 || ch_util_entry_6G == 0) {
		err(DEBUG_CAT_NETOPT, NETOPT_PREX" No Data of ch_util to compare\n");
		return 0;
	}

	for (i = 0; i < ch_util_entry_5G; i++)
		average_ch_util_5G += max_score_link_5G->netopt_ch_util[i];

	for (i = 0; i < ch_util_entry_6G; i++)
		average_ch_util_6G += max_score_link_6G->netopt_ch_util[i];

	info(DEBUG_CAT_NETOPT, NETOPT_PREX" average 5G = %u, avg 6G = %u\n", average_ch_util_5G, average_ch_util_6G);

	average_ch_util_5G = ch_util_by_per((average_ch_util_5G/ch_util_entry_5G));

	average_ch_util_6G = ch_util_by_per(average_ch_util_6G/ch_util_entry_6G);

	info(DEBUG_CAT_NETOPT, NETOPT_PREX" diff ch util %d\n", average_ch_util_6G - average_ch_util_5G);
	return (average_ch_util_6G - average_ch_util_5G);
}


struct radio_info_db *find_link_with_max_score_6G(struct own_1905_device *dev,
						  struct radio_info_db *max_score_link_5G,
						  struct radio_info_db *max_score_link_6G)
{
	u8 diff_estimated = 0;
	u8 check_new_score = 0;
	u8 reduce_per_5G = 0;
	int better_ch_util = 0;

	info(DEBUG_CAT_NETOPT, NETOPT_PREX" enter NETOPT ch util algo\n");

	if (max_score_link_5G == NULL || max_score_link_6G == NULL) {
		err(DEBUG_CAT_NETOPT, NETOPT_PREX" NULL radio\n");
		return NULL;
	}

	/* if SLIST is empty case handle. */
	if (max_score_link_5G->network_opt_1905dev_radio.max_score_link == NULL
	    || max_score_link_6G->network_opt_1905dev_radio.max_score_link == NULL) {
		err(DEBUG_CAT_NETOPT, NETOPT_PREX" link has no max score link\n");
		return NULL;
	}

	/*
	 * cond1: find if 5G estimated score is better then 6G.
	 */
	diff_estimated = compare_estimated_rate(max_score_link_5G, max_score_link_6G);

	if (diff_estimated == 0) {
		notice(DEBUG_CAT_NETOPT, NETOPT_PREX" choose existing 6G or same score 6G BH\n");
		return max_score_link_6G;
	}

	/*
	 * cond2: find if 6G ch util for netopt_ch_util_sample_size time is better
	 * 5G, by netopt_ch_util_6G_threshold.
	 */
	better_ch_util = compare_ch_util_5G_6G(dev, max_score_link_5G, max_score_link_6G);

	if (better_ch_util >= dev->network_optimization.netopt_ch_util_6G_diff) {
		notice(DEBUG_CAT_NETOPT, NETOPT_PREX" ch_util of 6G %d lower the thresh %d.\n",
				 better_ch_util,
				 dev->network_optimization.netopt_ch_util_6G_diff);
		return NULL;
	}

	/* If 6G util is low better_ch_util will always negative. */
	reduce_per_5G = 100 + better_ch_util;

	/*
	 * cond3: compare weight2 for 5G reduced by ch_util;
	 */
	check_new_score = compute_and_compare_NO_score_6G(max_score_link_5G, max_score_link_6G, reduce_per_5G);

	if (check_new_score == 0) {
		err(DEBUG_CAT_NETOPT, NETOPT_PREX" new score for 6G is still low.\n");
		return NULL;
	}

	notice(DEBUG_CAT_NETOPT, NETOPT_PREX" Setting 6G dev as per ch_util algo.\n");
	/* return 6G link*/
	return max_score_link_6G;
}

void fill_max_radio_comp(struct radio_info_db **max_score_radio_5G,
			 struct radio_info_db **max_score_radio_6G,
			 struct radio_info_db *max_score_radio)
{
	if (IS_BAND_5G(max_score_radio->band))
		*max_score_radio_5G = max_score_radio;
	else if (IS_BAND_6G(max_score_radio->band))
		*max_score_radio_6G = max_score_radio;
}
#endif

#ifdef MTK_MLO_MAP_SUPPORT

u8 NO_find_conn_bh_priority(struct _1905_map_device *_1905_dev,
		struct radio_info_db *same_bh[MAX_NUM_OF_RADIO])
{
	struct radio_info_db *radio = NULL;
	u8 i = 0;

	do {
		radio = topo_srv_get_next_radio(_1905_dev, radio);
		if (!radio) {
			info(DEBUG_CAT_NETOPT, NETOPT_PREX" no radio\n");
			break;
		}

		if (radio->bh_priority == MAX_POSSIBLE_BH_PRIORITY) {
			info(DEBUG_CAT_NETOPT, NETOPT_PREX" radio of max bh added at same_bh[%d]=%p i = %d\n", radio->band, radio, i);
			same_bh[radio->band] = radio;
			i++;
		}
	} while (radio);

	return i;
}

void NO_avoid_5G_conn_bh_priority_mld(struct _1905_map_device *_1905_dev,
		struct radio_info_db *same_bh[MAX_NUM_OF_RADIO])
{

#ifdef MAP_R6
	/*Need to enable bsta_mld_enable only when aff_staNum > 1.*/
	if (_1905_dev->bsta_mld_enabled || _1905_dev->mld_enabled)
#else
	if (_1905_dev->mld_enabled)
#endif
	{
		if (same_bh[BAND_5GL] && same_bh[BAND_5GH]) {
			info(DEBUG_CAT_NETOPT, NETOPT_PREX" clearing BAND_5GH in 5GL/H case\n");
			same_bh[BAND_5GH] = NULL;
		} else if (same_bh[BAND_5GL]) {
			info(DEBUG_CAT_NETOPT, NETOPT_PREX" clearing BAND_5GL case\n");
			same_bh[BAND_5GL] = NULL;
		} else if (same_bh[BAND_5GH]) {
			info(DEBUG_CAT_NETOPT, NETOPT_PREX" clearing BAND_5GH case\n");
			same_bh[BAND_5GH] = NULL;
		}
	}

}

/*function to find the best link in same bh priority*/
/*this will return radio, should work for both mld/non_mld*/
struct radio_info_db *check_find_best_in_bh_priority(struct _1905_map_device *_1905_dev)
{
	struct radio_info_db *radio = NULL;
	struct radio_info_db *same_bh[MAX_NUM_OF_RADIO] = {NULL};
	u8 high_bh = 0, j = 0;

	high_bh = NO_find_conn_bh_priority(_1905_dev, same_bh);

	/*Avoid 5G in mld device*/
	if (high_bh > 1)
		NO_avoid_5G_conn_bh_priority_mld(_1905_dev, same_bh);

	/*to get the highest band of same_bh*/
	for (j = MAX_NUM_OF_RADIO - 1; j > 0; j--) {
		if (same_bh[j] != NULL) {
			radio = same_bh[j];
			info(DEBUG_CAT_NETOPT, NETOPT_PREX" returning j=%d radio band=%d\n", j, radio->band);
			break;
		}
	}
	return radio;
}

/*return radio of that best bh priority of the input 1905_dev*/
struct radio_info_db *find_max_bh_priority_radio(struct _1905_map_device *_1905_dev)
{
	struct radio_info_db *radio = NULL;

	/*find if this dev is given all bh_priority of same*/
	if (_1905_dev->mld_same_bh_priority)
		return NULL;

	/*find if 2 link in mld is of same bh_priority*/
	radio = check_find_best_in_bh_priority(_1905_dev);

	if (!radio)
		return NULL;

	return radio;
}
#endif

#ifdef MTK_MLO_MAP_SUPPORT
void set_max_score_dev_db_mld(struct own_1905_device *dev, struct _1905_map_device *max_score_dev)
{
	struct _1905_map_device *upstream_dev = NULL;

	notice(DEBUG_CAT_NETOPT, NETOPT_PREX" final max score dev almac "MACSTR"\n", MAC2STR(max_score_dev->_1905_info.al_mac_addr));
	if (max_score_dev->network_opt_per1905.max_mld_dev &&
		max_score_dev->network_opt_per1905.max_score_radio) {
		notice(DEBUG_CAT_NETOPT, NETOPT_PREX" update max_score dev Upstream\n");
		upstream_dev = topo_srv_get_1905_device(dev, max_score_dev->network_opt_per1905.max_mld_dev->dev_almac);

		/**< pointer to upstream device */
		max_score_dev->network_opt_per1905.est_upstream_device = upstream_dev;
		max_score_dev->network_opt_per1905.network_opt_device_state = NETOPT_STATE_OPT_NET_NEED_TO_REALIZE;
		max_score_dev->network_opt_per1905.score_mld.est_hop_count_mld =
			max_score_dev->network_opt_per1905.max_mld_dev->estimated_hop_count_mld;
		max_score_dev->network_opt_per1905.score_mld.est_max_score_mld =
			max_score_dev->network_opt_per1905.max_mld_dev->estimated_score_mld;
		max_score_dev->network_opt_per1905.score_mld.est_max_uplink_rate_mld =
			max_score_dev->network_opt_per1905.max_mld_dev->estimated_rate_mld;

		max_score_dev->network_opt_per1905.est_hop_count =
			max_score_dev->network_opt_per1905.max_score_radio->network_opt_1905dev_radio.max_score_link->estimated_hop_count;
		max_score_dev->network_opt_per1905.est_max_score =
			max_score_dev->network_opt_per1905.max_score_radio->network_opt_1905dev_radio.max_score_link->estimated_score;
		max_score_dev->network_opt_per1905.est_max_uplink_rate =
			max_score_dev->network_opt_per1905.max_score_radio->network_opt_1905dev_radio.max_score_link->estimated_rate;

	} else {
		info(DEBUG_CAT_NETOPT, NETOPT_PREX" keep existing upstream dev\n");
		upstream_dev = max_score_dev->upstream_device;
		/**< pointer to upstream device */
		max_score_dev->network_opt_per1905.est_upstream_device = upstream_dev;
		max_score_dev->network_opt_per1905.network_opt_device_state = NETOPT_STATE_OPT_NET_NEED_TO_REALIZE;
		max_score_dev->network_opt_per1905.score_mld.est_hop_count_mld = upstream_dev->network_opt_per1905.est_hop_count;
	}
}

void set_max_score_dev_db_non_mld(struct own_1905_device *dev,
				  struct _1905_map_device *max_score_dev)
{
	struct _1905_map_device *upstream_dev = NULL;

	notice(DEBUG_CAT_NETOPT, NETOPT_PREX" final max score dev almac "MACSTR"\n", MAC2STR(max_score_dev->_1905_info.al_mac_addr));
	if (max_score_dev->network_opt_per1905.max_score_radio->network_opt_1905dev_radio.max_score_link) {
		notice(DEBUG_CAT_NETOPT, NETOPT_PREX" update max_score dev Upstream\n");
		upstream_dev = topo_srv_get_1905_device(dev,
			       max_score_dev->network_opt_per1905.max_score_radio->network_opt_1905dev_radio.max_score_link->dev_almac);
		/**< pointer to upstream device */
		max_score_dev->network_opt_per1905.est_upstream_device = upstream_dev;
		max_score_dev->network_opt_per1905.network_opt_device_state = NETOPT_STATE_OPT_NET_NEED_TO_REALIZE;
		max_score_dev->network_opt_per1905.est_hop_count =
			max_score_dev->network_opt_per1905.max_score_radio->network_opt_1905dev_radio.max_score_link->estimated_hop_count;
		max_score_dev->network_opt_per1905.est_max_score =
			max_score_dev->network_opt_per1905.max_score_radio->network_opt_1905dev_radio.max_score_link->estimated_score;
		max_score_dev->network_opt_per1905.est_max_uplink_rate =
			max_score_dev->network_opt_per1905.max_score_radio->network_opt_1905dev_radio.max_score_link->estimated_rate;
	} else {
		notice(DEBUG_CAT_NETOPT, NETOPT_PREX" keep existing upstream dev\n");
		upstream_dev = max_score_dev->upstream_device;
		/**< pointer to upstream device */
		max_score_dev->network_opt_per1905.est_upstream_device = upstream_dev;
		max_score_dev->network_opt_per1905.network_opt_device_state = NETOPT_STATE_OPT_NET_NEED_TO_REALIZE;
		max_score_dev->network_opt_per1905.est_hop_count = upstream_dev->network_opt_per1905.est_hop_count;
	}
}

u8 ch_planning_check_cac_cap_present(struct _1905_map_device *_1905_dev, u8 band)
{
	struct radio_info_db *radio = NULL;
	struct cac_cap_db *cap = NULL, *t_cap = NULL;

	radio = topo_srv_get_radio_by_band_type(_1905_dev, band);
	if (!radio) {
		err(DEBUG_CAT_NETOPT, CH_PLANING_PREX"radio(%d) not found\n", band);
		return 0;
	}

	SLIST_FOREACH_SAFE(cap, &radio->cac_cap.cac_capab_head, cac_cap_entry, t_cap) {
		if (cap->op_class_num != 0)
			return 1;
	}

	return 0;
}

void find_best_link_in_mld(struct own_1905_device *dev, struct _1905_map_device *max_dev_mld)
{
	struct radio_info_db *radio = NULL;
	struct radio_info_db *max_radio = NULL;
	struct N_O_link_estimate_mld_cb *mld_link = NULL;

	/*go in each radio, compare estimated rate, find max.
	 *assign max score radio to per_dev_1905_NetOpt's max_score_radio
	 *why estimated_rate, because this is only because if own capability
	 *uplink not needed because we want best connection, uplink already
	 *helped us find best best in network for this postion.
	 */
	radio = topo_srv_get_radio(max_dev_mld, NULL);
	mld_link = max_dev_mld->network_opt_per1905.max_mld_dev;
	while (radio) {

#ifdef MAP_NO_5G_MLO
		/*Also Consider DFS disable case, check if no CAC cap means disable.*/
		/*To avoid 5G BH in case of MLD, DFS CAC under development.*/
		if (IS_BAND_5G(radio->band) &&
		    ch_planning_check_cac_cap_present(max_dev_mld, radio->band)) {
			radio = topo_srv_get_next_radio(max_dev_mld, radio);
			continue;
		}
#endif

		if (mld_link->mld_links[radio->band] == NULL) {
			radio = topo_srv_get_next_radio(max_dev_mld, radio);
			continue;
		}

		if (radio->network_opt_1905dev_radio.max_score_link) {
			if (max_radio == NULL)
				max_radio = radio;
			else if (radio->network_opt_1905dev_radio.max_score_link->estimated_score >=
				 max_radio->network_opt_1905dev_radio.max_score_link->estimated_score)
				max_radio = radio;
		}
		radio = topo_srv_get_next_radio(max_dev_mld, radio);

	}
	radio = NULL;
	if (max_radio) {
		if (dev->mlo_bh_priority) {
			radio = find_max_bh_priority_radio(max_dev_mld);
			if (radio) {
				if (radio->band != max_radio->band)
					max_radio = radio;
			}
		}
		max_dev_mld->network_opt_per1905.max_score_radio = max_radio;
	}
}

u8 find_skip_mld_dev_bh_priority(struct _1905_map_device *_1905_dev,
				 struct N_O_link_estimate_mld_cb *mld_link)
{
	struct radio_info_db *same_bh[MAX_NUM_OF_RADIO] = {NULL};
	u8 high_bh = 0, no_links_matches = 0;
	u8 i = 0;

	high_bh = NO_find_conn_bh_priority(_1905_dev, same_bh);
	/*all same bh priority case.*/
	/*find if this dev is given all bh_priority of same*/
	if (_1905_dev->mld_same_bh_priority || high_bh == 0) {
		info(DEBUG_CAT_NETOPT, NETOPT_PREX" all same bh priority case.\n");
		return 1;
	}

	for (i = 0; i < MAX_NUM_OF_RADIO; i++) {
		if (same_bh[i] && mld_link->mld_links[i]) {
			info(DEBUG_CAT_NETOPT, NETOPT_PREX" found BH priority of same\n");
			no_links_matches++;
		}
	}

	if (no_links_matches == 0)
		return 0;

	return 1;
}

void find_link_with_max_score_mld(struct own_1905_device *dev,
				  struct _1905_map_device **new_max_dev)
{
	struct N_O_link_estimate_mld_cb  *link = NULL, *tlink = NULL;
	struct N_O_link_estimate_mld_cb  *max_link = NULL;
	struct _1905_map_device *max_score_dev = NULL;
	struct _1905_map_device *_1905_device = NULL;

	notice(DEBUG_CAT_NETOPT, NETOPT_PREX" ******************\n");
	_1905_device = topo_srv_get_next_1905_device(dev, NULL); /*Get own device struct.*/
	while (_1905_device) {
		if (_1905_device->network_opt_per1905.network_opt_device_state != NETOPT_STATE_NEED_TO_ESTIMATE) {
			notice(DEBUG_CAT_NETOPT, NETOPT_PREX" continue "MACSTR"\n", MAC2STR(_1905_device->_1905_info.al_mac_addr));
			_1905_device = topo_srv_get_next_1905_device(dev, _1905_device);
			continue;
		}
		notice(DEBUG_CAT_NETOPT, NETOPT_PREX" loop 1905 dev for ALMAC "MACSTR"\n", MAC2STR(_1905_device->_1905_info.al_mac_addr));
		SLIST_FOREACH_SAFE(link, &(_1905_device->link_estimate_cb_mld_head), link_estimate_cb_mld_entry, tlink) {
			if (dev->mlo_bh_priority) {
				if (!find_skip_mld_dev_bh_priority(_1905_device, link)) {
					notice(DEBUG_CAT_NETOPT, NETOPT_PREX" skip this mld node as the requested BH not present.\n");
					continue;
				}
			}
			if (max_link == NULL) {
				notice(DEBUG_CAT_NETOPT, NETOPT_PREX" set max_mld_link %p and score %u\n", link, link->estimated_score_mld);
				max_link = link;
			} else if (max_link->estimated_score_mld <= link->estimated_score_mld) {
				notice(DEBUG_CAT_NETOPT, NETOPT_PREX" set max_mld_link %p and score %u\n", link, link->estimated_score_mld);
				max_link = link;
			} else
				notice(DEBUG_CAT_NETOPT, NETOPT_PREX" max_link_score %u > link score %u\n",
					max_link->estimated_score_mld, link->estimated_score_mld);
		}

		if (max_link) {
			_1905_device->network_opt_per1905.max_mld_dev = max_link;
			notice(DEBUG_CAT_NETOPT, NETOPT_PREX" final max_link "MACSTR"\n", MAC2STR(max_link->dev_almac));
			notice(DEBUG_CAT_NETOPT, NETOPT_PREX" final max_link score %d\n", max_link->estimated_score_mld);
			if (max_score_dev == NULL)
				max_score_dev = _1905_device;
			else if (max_score_dev->network_opt_per1905.max_mld_dev->estimated_score_mld
				 <= max_link->estimated_score_mld)
				max_score_dev = _1905_device;
		}

		max_link = NULL;
		_1905_device = topo_srv_get_next_1905_device(dev, _1905_device);
	}

	if (max_score_dev)
		*new_max_dev = max_score_dev;

}

void find_link_with_max_score_wrapper(struct own_1905_device *dev)
{
	struct _1905_map_device *max_score_dev = NULL;
	struct _1905_map_device *max_score_dev_mld = NULL;
	struct N_O_link_estimate_cb *max_non_mld_dev = NULL;
	struct N_O_link_estimate_mld_cb *max_mld_dev = NULL;

	find_link_with_max_score(dev, &max_score_dev);

	find_link_with_max_score_mld(dev, &max_score_dev_mld);

	if (max_score_dev)
		max_non_mld_dev = max_score_dev->network_opt_per1905.max_score_radio->network_opt_1905dev_radio.max_score_link;

	if (max_score_dev_mld)
		max_mld_dev = max_score_dev_mld->network_opt_per1905.max_mld_dev;

	if (max_mld_dev != NULL && max_non_mld_dev != NULL) {
		if (max_non_mld_dev->estimated_score <= max_mld_dev->estimated_score_mld) {
			notice(DEBUG_CAT_NETOPT, NETOPT_PREX" estimated_score_mld >= estimated_score\n");
			find_best_link_in_mld(dev, max_score_dev_mld);
			set_max_score_dev_db_mld(dev, max_score_dev_mld);
			add_dev_to_opt_net(max_score_dev_mld, dev);
			dump_max_score_device_info_mld(max_score_dev_mld);
			dump_max_score_device_info(max_score_dev_mld);
		} else {
			notice(DEBUG_CAT_NETOPT, NETOPT_PREX" estimated_score_mld < estimated_score\n");
			set_max_score_dev_db_non_mld(dev, max_score_dev);
			add_dev_to_opt_net(max_score_dev, dev);
			dump_max_score_device_info(max_score_dev);
		}
	} else if (max_mld_dev != NULL && max_non_mld_dev == NULL) {
		notice(DEBUG_CAT_NETOPT, NETOPT_PREX" estimated_score_mld high, as no non_mld_dev found\n");
		find_best_link_in_mld(dev, max_score_dev_mld);
		set_max_score_dev_db_mld(dev, max_score_dev_mld);
		add_dev_to_opt_net(max_score_dev_mld, dev);
		dump_max_score_device_info_mld(max_score_dev_mld);
		dump_max_score_device_info(max_score_dev_mld);
	} else if (max_mld_dev == NULL && max_non_mld_dev != NULL) {
		notice(DEBUG_CAT_NETOPT, NETOPT_PREX" estimated_score high, as no mld_dev found\n");
		set_max_score_dev_db_non_mld(dev, max_score_dev);
		add_dev_to_opt_net(max_score_dev, dev);
		dump_max_score_device_info(max_score_dev);
	}
}
#endif

void find_link_with_max_score(struct own_1905_device *dev
#ifdef MTK_MLO_MAP_SUPPORT
				, struct _1905_map_device **max_dev
#endif
)
{
	struct _1905_map_device *_1905_device = NULL;
	struct radio_info_db *radio = NULL;
	struct N_O_link_estimate_cb  *link = NULL, *tlink = NULL;
	struct _1905_map_device *max_score_dev= NULL;
	struct radio_info_db *max_score_radio = NULL;
	struct N_O_link_estimate_cb *max_score_link= NULL;
#ifndef MTK_MLO_MAP_SUPPORT
	struct _1905_map_device *upstream_dev = NULL;
#else
	struct radio_info_db *max_score_radio_5G = NULL;
	struct radio_info_db *max_score_radio_6G = NULL;
	struct radio_info_db *max_score_radio_new = NULL;
	struct radio_info_db *radio_bh = NULL;
#endif

	notice(DEBUG_CAT_NETOPT, NETOPT_PREX" ********FUNCTION ENTRY TO FIND LINK SCORE**********\n");
	_1905_device = topo_srv_get_next_1905_device(dev, NULL); /*Get own device struct.*/
	while(_1905_device) {
		if(_1905_device->network_opt_per1905.network_opt_device_state != NETOPT_STATE_NEED_TO_ESTIMATE)
		{
			info(DEBUG_CAT_NETOPT, NETOPT_PREX" continue "MACSTR"\n", MAC2STR(_1905_device->_1905_info.al_mac_addr));
			_1905_device = topo_srv_get_next_1905_device(dev, _1905_device);
			continue;
		}
		info(DEBUG_CAT_NETOPT, NETOPT_PREX" loop 1905 dev for ALMAC "MACSTR"\n", MAC2STR(_1905_device->_1905_info.al_mac_addr));
		radio = topo_srv_get_radio(_1905_device, NULL);
		max_score_radio = NULL;
		_1905_device->network_opt_per1905.max_score_radio = NULL;
		while (radio) {
			info(DEBUG_CAT_NETOPT, NETOPT_PREX" loop radio ID "MACSTR"\n", MAC2STR(radio->identifier));
			max_score_link = NULL;
			radio->network_opt_1905dev_radio.max_score_link = NULL;
#ifdef MTK_MLO_MAP_SUPPORT
			if (dev->mlo_bh_priority) {
				radio_bh = find_max_bh_priority_radio(_1905_device);
				if (radio_bh && radio->band != radio_bh->band) {
					radio = topo_srv_get_next_radio(_1905_device, radio);
					continue;
				}
			}
#endif
			SLIST_FOREACH_SAFE(link, &(radio->link_estimate_cb_head), link_estimate_cb_entry, tlink)
			{
				if (max_score_link == NULL) {
					max_score_link = link;
					continue;
				}
				if(link->estimated_score > max_score_link->estimated_score){
					max_score_link = link;
				}	
				else if (link->estimated_score == max_score_link->estimated_score)
				{
					info(DEBUG_CAT_NETOPT, NETOPT_PREX" link score is the same\n");
					if(is_link_already_present(link, _1905_device)){
						/*the current link is already present , so update max link with current link*/
						info(DEBUG_CAT_NETOPT, NETOPT_PREX" current link already present\n");
						max_score_link = link;
					}			
				}
			}
			radio->network_opt_1905dev_radio.max_score_link = max_score_link;
			if (radio->network_opt_1905dev_radio.max_score_link) {
				info(DEBUG_CAT_NETOPT, NETOPT_PREX" final max_score_link almac "MACSTR"\n",
				 MAC2STR(max_score_link->dev_almac));
				info(DEBUG_CAT_NETOPT, NETOPT_PREX" final max_score_link  score %d\n", max_score_link->estimated_score);
				if (max_score_radio == NULL) {
					max_score_radio = radio;
				} else if (radio->network_opt_1905dev_radio.max_score_link->estimated_score >
					(max_score_radio->network_opt_1905dev_radio.max_score_link->estimated_score)) {
					max_score_radio = radio;
				} else if (radio->network_opt_1905dev_radio.max_score_link->estimated_score ==
						max_score_radio->network_opt_1905dev_radio.max_score_link->estimated_score) {
					info(DEBUG_CAT_NETOPT, NETOPT_PREX" radio score same\n");
					if (IS_BAND_5G(radio->band)
#ifdef MAP_6E_SUPPORT
					    || IS_BAND_6G(radio->band)
#endif
					) {
						if (radio->uplink_bh_present) {
							info(DEBUG_CAT_NETOPT,
							 NETOPT_PREX" radio scores same , update max radio as uplink bh present\n");
							max_score_radio = radio;
						}
					}
				}
			}
#ifdef MTK_MLO_MAP_SUPPORT
			if (IS_BAND_5G(radio->band) || IS_BAND_6G(radio->band)) {
				fill_max_radio_comp(&max_score_radio_5G, &max_score_radio_6G, radio);
				info(DEBUG_CAT_NETOPT, NETOPT_PREX" 5G=%p 6G=%p radio=%p\n", max_score_radio_5G, max_score_radio_6G, radio);
			}
#endif
			radio = topo_srv_get_next_radio(_1905_device, radio);
#ifdef MAP_R6
			if (_1905_device->R6_dev) {
				info(DEBUG_CAT_NETOPT, NETOPT_PREX" Dev is MLO so not need to change setup_link\n");
				max_score_radio_6G = NULL;
				max_score_radio_5G = NULL;
			}
#endif
		}

#ifdef MTK_MLO_MAP_SUPPORT
		if (dev->network_optimization.netopt_ch_util_enable != FALSE) {
			max_score_radio_new = find_link_with_max_score_6G(dev, max_score_radio_5G, max_score_radio_6G);
			if ((max_score_radio_new != NULL) && (max_score_radio_new != max_score_radio)) {
				info(DEBUG_CAT_NETOPT, NETOPT_PREX" final max radio dev almac need swap "MACSTR"\n",
					MAC2STR(max_score_radio->parent_1905->_1905_info.al_mac_addr));
				notice(DEBUG_CAT_NETOPT, NETOPT_PREX" new final max radio score dev almac "MACSTR"\n",
					MAC2STR(max_score_radio_new->parent_1905->_1905_info.al_mac_addr));
				max_score_radio = max_score_radio_new;
			}
		}
#endif

		_1905_device->network_opt_per1905.max_score_radio = max_score_radio;
		if (max_score_radio != NULL){
			if (max_score_dev == NULL) {
				max_score_dev = _1905_device;
			} else if(max_score_radio->network_opt_1905dev_radio.max_score_link->estimated_score > 
				(max_score_dev->network_opt_per1905.max_score_radio->network_opt_1905dev_radio.max_score_link->estimated_score)) {
					max_score_dev = _1905_device;
			} 
		}

#ifdef MTK_MLO_MAP_SUPPORT
		max_score_radio_new = NULL;
		max_score_radio_6G = NULL;
		max_score_radio_5G = NULL;
#endif

		_1905_device = topo_srv_get_next_1905_device(dev, _1905_device);
	}
	if (max_score_dev) {
#ifndef MTK_MLO_MAP_SUPPORT
		info(DEBUG_CAT_NETOPT, NETOPT_PREX" final max score dev almac "MACSTR"\n",
		 MAC2STR(max_score_dev->_1905_info.al_mac_addr));
		if (max_score_dev->network_opt_per1905.max_score_radio->network_opt_1905dev_radio.max_score_link) {
			info(DEBUG_CAT_NETOPT, NETOPT_PREX" update max_score dev Upstream\n");
			upstream_dev = topo_srv_get_1905_device(dev,max_score_dev->network_opt_per1905.max_score_radio->network_opt_1905dev_radio.max_score_link->dev_almac);
			max_score_dev->network_opt_per1905.est_upstream_device = upstream_dev; /**< pointer to upstream device */
			max_score_dev->network_opt_per1905.network_opt_device_state = NETOPT_STATE_OPT_NET_NEED_TO_REALIZE;
			max_score_dev->network_opt_per1905.est_hop_count =
				max_score_dev->network_opt_per1905.max_score_radio->network_opt_1905dev_radio.max_score_link->estimated_hop_count;
			max_score_dev->network_opt_per1905.est_max_score =
				max_score_dev->network_opt_per1905.max_score_radio->network_opt_1905dev_radio.max_score_link->estimated_score;
			max_score_dev->network_opt_per1905.est_max_uplink_rate =
				max_score_dev->network_opt_per1905.max_score_radio->network_opt_1905dev_radio.max_score_link->estimated_rate;
		}
		else
		{
			info(DEBUG_CAT_NETOPT, NETOPT_PREX" keep existing upstream dev\n");
			upstream_dev = max_score_dev->upstream_device;
			max_score_dev->network_opt_per1905.est_upstream_device = upstream_dev; /**< pointer to upstream device */
			max_score_dev->network_opt_per1905.network_opt_device_state = NETOPT_STATE_OPT_NET_NEED_TO_REALIZE;
			max_score_dev->network_opt_per1905.est_hop_count = upstream_dev->network_opt_per1905.est_hop_count;//estimate_hop_count(dev, max_score_dev);
		}
		add_dev_to_opt_net(max_score_dev,dev);
		dump_max_score_device_info(max_score_dev);
#else
		*max_dev = max_score_dev;
#endif
	}
}
void clear_estimated_scores(struct own_1905_device *dev)
{
	struct radio_info_db *radio = NULL;
	struct _1905_map_device *_1905_device = NULL;
	struct N_O_link_estimate_cb  *link = NULL, *tlink = NULL;
#ifdef MTK_MLO_MAP_SUPPORT
	struct N_O_link_estimate_mld_cb  *link_mld = NULL, *tlink_mld = NULL;
#endif
	_1905_device = topo_srv_get_next_1905_device(dev, NULL); /*Get own device struct.*/
	while(_1905_device) {
		radio = topo_srv_get_radio(_1905_device, NULL);
		while (radio) {
			if(!SLIST_EMPTY(&(radio->link_estimate_cb_head)))
			{ 
				SLIST_FOREACH_SAFE(link, &(radio->link_estimate_cb_head), link_estimate_cb_entry, tlink)
				{
					link->estimated_score = 0;
				}
			}
			radio = topo_srv_get_next_radio(_1905_device, radio);
		}
#ifdef MTK_MLO_MAP_SUPPORT
		if (!SLIST_EMPTY(&(_1905_device->link_estimate_cb_mld_head))) {
			SLIST_FOREACH_SAFE(link_mld, &(_1905_device->link_estimate_cb_mld_head), link_estimate_cb_mld_entry, tlink_mld)
				link_mld->estimated_score_mld = 0;
		}
#endif
		_1905_device = topo_srv_get_next_1905_device(dev, _1905_device);
	}
}
void remove_all_dev_from_opt_net(
	struct own_1905_device *dev)
{
	struct optimized_network *opt_1905_device = NULL;
	while (!SLIST_EMPTY(&(dev->network_optimization.first_opt_net_dev))) {			/* List Deletion. */
			opt_1905_device = SLIST_FIRST(&(dev->network_optimization.first_opt_net_dev));
			SLIST_REMOVE_HEAD(&(dev->network_optimization.first_opt_net_dev), next_opt_net_dev);
			free(opt_1905_device);
	}
}
void remove_all_entry_link_est_db(
	struct _1905_map_device *_1905_device)
{
	struct radio_info_db *radio = NULL;
	struct N_O_link_estimate_cb *link = NULL;
#ifdef MTK_MLO_MAP_SUPPORT
	struct N_O_link_estimate_mld_cb *link_mld = NULL;
#endif

	radio = topo_srv_get_next_radio(_1905_device, radio);
	while (radio) {
		while (!SLIST_EMPTY(&(radio->link_estimate_cb_head))) {			/* List Deletion. */
				link = SLIST_FIRST(&(radio->link_estimate_cb_head));
				SLIST_REMOVE_HEAD(&(radio->link_estimate_cb_head), link_estimate_cb_entry);
				os_free(link);
		}
		radio = topo_srv_get_next_radio(_1905_device, radio);
	}

#ifdef MTK_MLO_MAP_SUPPORT
	while (!SLIST_EMPTY(&(_1905_device->link_estimate_cb_mld_head))) {
		link_mld = SLIST_FIRST(&(_1905_device->link_estimate_cb_mld_head));
		SLIST_REMOVE_HEAD(&(_1905_device->link_estimate_cb_mld_head), link_estimate_cb_mld_entry);
		os_free(link_mld);
	}
#endif
}

unsigned int find_max_uplink_rate(struct _1905_map_device *_1905_device)
{
	unsigned int est_max_score =0;
	struct radio_info_db *radio = NULL;
	radio = topo_srv_get_radio(_1905_device, NULL);
	while (radio) {
		if (radio->uplink_rate > est_max_score)
			est_max_score = radio->uplink_rate;
		radio = topo_srv_get_next_radio(_1905_device, radio);
	}
	return est_max_score;
}

void network_opt_init(struct mapd_global *pGlobal_dev)
{
	struct own_1905_device *dev = &pGlobal_dev->dev;
	dev->network_optimization.NetOptReason = REASON_NOT_REQUIRED;
	if (dev->network_optimization.wait_time == 0 )
		dev->network_optimization.wait_time = 45;
	if (dev->network_optimization.data_collection_wait_time == 0 )
		dev->network_optimization.data_collection_wait_time = 60;
	if (dev->network_optimization.bh_steer_wait_time == 0 )
		dev->network_optimization.bh_steer_wait_time = 60;
	if (dev->network_optimization.disconnect_wait_time == 0)
		dev->network_optimization.disconnect_wait_time = 45;
	if (dev->network_optimization.connect_wait_time == 0)
		dev->network_optimization.connect_wait_time = 45;
	if (dev->network_optimization.post_cac_trigger_time== 0)
		dev->network_optimization.post_cac_trigger_time = 30;
#ifdef MTK_MLO_MAP_SUPPORT
	if (dev->network_optimization.netopt_ch_util_6G_diff == 0)
		dev->network_optimization.netopt_ch_util_6G_diff = -20;
	if (dev->network_optimization.netopt_ch_util_sec == 0)
		dev->network_optimization.netopt_ch_util_sec = 10;
	if (dev->network_optimization.netopt_ch_util_enable == 0)
		dev->network_optimization.netopt_ch_util_enable = 0;
	if (dev->network_optimization.netopt_mld_bh_priority == 1)
		dev->mlo_bh_priority = 1;
	else
		dev->mlo_bh_priority = 0;
#endif
	err(DEBUG_CAT_NETOPT, NETOPT_PREX" conn %d dis %d",
	 dev->network_optimization.connect_wait_time, dev->network_optimization.disconnect_wait_time);
	dev->network_optimization.network_opt_state = NETOPT_STATE_IDLE; 
}
void network_opt_reset(struct mapd_global *pGlobal_dev)
{
	struct own_1905_device *dev = &pGlobal_dev->dev;
	struct _1905_map_device *_1905_device = NULL;
	dev->network_optimization.NetOptReason = REASON_NOT_REQUIRED;
	dev->network_optimization.network_opt_state = NETOPT_STATE_IDLE;
	notice(DEBUG_CAT_NETOPT, NETOPT_PREX"\n");
	_1905_device = topo_srv_get_next_1905_device(dev, NULL); /*Get own device struct.*/
	while(_1905_device) {
			_1905_device->network_opt_per1905.network_opt_device_state =
				NETOPT_STATE_IDLE;
			_1905_device->network_opt_per1905.data_col_retry_count = 0;
			remove_all_entry_link_est_db(_1905_device);
		if (_1905_device->net_opt_scan_report)
			os_free(_1905_device->net_opt_scan_report);

		_1905_device->net_opt_scan_report = NULL;
		_1905_device = topo_srv_get_next_1905_device(&pGlobal_dev->dev,_1905_device);
	}
	reset_last_uplink_rate(pGlobal_dev);
	remove_all_dev_from_opt_net(dev);
	os_get_time(&dev->network_optimization.trigger_netopt_ts);
}

#ifdef MTK_MLO_MAP_SUPPORT
u8 single_link_mld_NO(struct N_O_link_estimate_mld_cb *NO_cb_mld)
{
	u8 i = 0;
	u8 links = 0;

	for (i = 0; i < MAX_NUM_OF_RADIO; i++) {
		if (NO_cb_mld->mld_links[i] != NULL)
			links++;
	}

	return (links <= 1 ? 1 : 0);
}
void remove_single_link_mld_per_dev(struct _1905_map_device *_1905_device)
{
	struct N_O_link_estimate_mld_cb *NO_cb_mld = NULL, *tno_cb_mld = NULL;

	SLIST_FOREACH_SAFE(NO_cb_mld, &_1905_device->link_estimate_cb_mld_head, link_estimate_cb_mld_entry, tno_cb_mld) {
		if (single_link_mld_NO(NO_cb_mld)) {
			SLIST_REMOVE(&_1905_device->link_estimate_cb_mld_head,
					NO_cb_mld, N_O_link_estimate_mld_cb,
					link_estimate_cb_mld_entry);
			os_free(NO_cb_mld);
		}
	}
}
#endif

void dump_link_estimate_db_per_dev(struct _1905_map_device *_1905_device)
{
	struct	N_O_link_estimate_cb *NO_cb = NULL, *tno_cb = NULL;
	struct radio_info_db *radio = NULL;
	signed char Link_RSSI = 0;
#ifdef MTK_MLO_MAP_SUPPORT
	struct  N_O_link_estimate_mld_cb *NO_cb_mld = NULL, *tno_cb_mld = NULL;
#endif

	radio = topo_srv_get_radio(_1905_device, NULL);
	while (radio) {		
		notice(DEBUG_CAT_NETOPT, NETOPT_PREX" radio->identifier:"MACSTR"\n", MAC2STR(radio->identifier));
		if(!SLIST_EMPTY(&(radio->link_estimate_cb_head))) {
			SLIST_FOREACH_SAFE(NO_cb, &radio->link_estimate_cb_head, link_estimate_cb_entry, tno_cb) {
				notice(DEBUG_CAT_NETOPT, NETOPT_PREX" ALMAC:"MACSTR"\n", MAC2STR(NO_cb->dev_almac));
				notice(DEBUG_CAT_NETOPT, NETOPT_PREX" STA_MAC/BSSID:"MACSTR"\n", MAC2STR(NO_cb->peer_mac));
				Link_RSSI = rcpi_to_rssi(NO_cb->rcpi);
				notice(DEBUG_CAT_NETOPT, NETOPT_PREX" RCPI [%d] RSSI is %d\n", NO_cb->rcpi, Link_RSSI);
			}
		}
		else
		{
			err(DEBUG_CAT_NETOPT, NETOPT_PREX" SLIST empty for this radio\n");
		}
		radio = topo_srv_get_next_radio(_1905_device, radio);
	}

#ifdef MTK_MLO_MAP_SUPPORT
	if (!SLIST_EMPTY(&(_1905_device->link_estimate_cb_mld_head))) {
		SLIST_FOREACH_SAFE(NO_cb_mld, &_1905_device->link_estimate_cb_mld_head, link_estimate_cb_mld_entry, tno_cb_mld) {
			notice(DEBUG_CAT_NETOPT, NETOPT_PREX" ALMAC:"MACSTR"\n", MAC2STR(NO_cb_mld->dev_almac));
			notice(DEBUG_CAT_NETOPT, NETOPT_PREX" MLD_MAC:"MACSTR"\n", MAC2STR(NO_cb_mld->mld_mac));
		}
	} else
		err(DEBUG_CAT_NETOPT, NETOPT_PREX" MLD empty for this dev"MACSTR"\n", MAC2STR(_1905_device->_1905_info.al_mac_addr));
#endif

}
struct	N_O_link_estimate_cb *topo_srv_get_next_N_O_link(struct radio_info_db *radio,struct N_O_link_estimate_cb *NO_cb)
{
	struct list_link_estimate_cb *NO_cb_list;
	if (!radio) {
		err(DEBUG_CAT_NETOPT, NETOPT_PREX" radio is null\n");
		return NULL;
	}
	NO_cb_list = &radio->link_estimate_cb_head;
	if (SLIST_EMPTY(NO_cb_list))
		return NULL;
	if (!NO_cb)
		return SLIST_FIRST(NO_cb_list);
	return SLIST_NEXT(NO_cb, link_estimate_cb_entry);
}
struct	N_O_link_estimate_cb *find_existing_entry_in_cb(struct radio_info_db *radio,struct neighbor_info *nb_info)
{
	struct	N_O_link_estimate_cb *NO_cb = NULL;
	do {
		NO_cb = topo_srv_get_next_N_O_link(radio, NO_cb);
		if (!NO_cb) {
			info(DEBUG_CAT_NETOPT, NETOPT_PREX" failed to find existing NO_cb\n");
			break;
		}
		if (os_memcmp(NO_cb->peer_mac, nb_info->bssid, ETH_ALEN) == 0)
			return NO_cb;
	} while (NO_cb);
	return NULL;
}

int is_that_a_bh_nb_info(struct mapd_global *global, char *ssid)
{
	int a;
	for (a = 0; a < MAX_SET_BSS_INFO_NUM; a++) {
		if ((os_strcmp(global->dev.bss_config[a].ssid, ssid) == 0)
			&& (global->dev.bss_config[a].wfa_vendor_extension & BSS_BH)) {
			return TRUE;
		}
	}
	return FALSE;
}

#ifdef MTK_MLO_MAP_SUPPORT
struct N_O_link_estimate_mld_cb *find_existing_entry_in_mld_cb(
		struct _1905_map_device *_1905_device, unsigned char *ifaddr)
{
	struct	N_O_link_estimate_mld_cb *NO_mld_cb = NULL;
	struct	N_O_link_estimate_mld_cb *NO_mld_cb_tmp = NULL;

	notice(DEBUG_CAT_NETOPT, NETOPT_PREX" searching mld "MACSTR" in dev list\n", MAC2STR(ifaddr));

	SLIST_FOREACH_SAFE(NO_mld_cb, &_1905_device->link_estimate_cb_mld_head, link_estimate_cb_mld_entry, NO_mld_cb_tmp) {
		if (os_memcmp(NO_mld_cb->mld_mac, ifaddr, ETH_ALEN) == 0) {
			notice(DEBUG_CAT_NETOPT, NETOPT_PREX" found in mld "MACSTR" in dev list\n", MAC2STR(NO_mld_cb->mld_mac));
			return NO_mld_cb;
		}
	}
	return NULL;
}

void netopt_fill_mld_links_per_mld(struct N_O_link_estimate_mld_cb *NO_mld_link,
				   struct N_O_link_estimate_cb *NO_cb_link,
				   struct radio_info_db *radio)
{

	if (IS_BAND_24G(radio->band))
		NO_mld_link->mld_links[BAND_2G] = NO_cb_link;
	else if (IS_BAND_5GL(radio->band))
		NO_mld_link->mld_links[BAND_5GL] = NO_cb_link;
	else if (IS_BAND_5GH(radio->band))
		NO_mld_link->mld_links[BAND_5GH] = NO_cb_link;
	else if (IS_BAND_6G(radio->band))
		NO_mld_link->mld_links[BAND_6G] = NO_cb_link;

}

u8 is_1905dev_radio_mld_capable(struct _1905_map_device *_1905_device, struct radio_info_db *radio)
{
	struct bss_info_db *bss = NULL;

#ifdef MAP_R6
	if ((radio->radio_capability.mlo_cap.MloCapPerRole[1].mlo_enable == 0) || (radio->bsta_mlo_enable == 0))
		return 0;
#else
	if (!radio->radio_capability.mlo_cap.MloCapPerRole[1].mlo_enable) {
		err(DEBUG_CAT_NETOPT, "MLO is disable for this radio\n");
		return 0;
	}
#endif
	/*in this function checking this radio in 1905 mld capable*/
	do {
		bss = topo_srv_get_next_bss(_1905_device, bss);

		if (!bss) {
			err(DEBUG_CAT_NETOPT, NETOPT_PREX" no BSS found\n");
			break;
		}

		if (!bss->radio) {
			info(DEBUG_CAT_NETOPT, NETOPT_PREX" BSS has no radio\n");
			continue;
		}

		if (bss->radio->band != radio->band) {
			info(DEBUG_CAT_NETOPT, NETOPT_PREX" BSS is of diff radio\n");
			continue;
		}

		/*If no bss is having mld_mac present then radio not mlo capable.*/
		if (os_memcmp(bss->mlo_info.mld_addr, ZERO_MAC_ADDR, ETH_ALEN) == 0)
			break;

		return 1;

	} while (bss);

	return 0;
}


void Update_link_estimation_db_mld_per_dev(struct own_1905_device *ctx, struct _1905_map_device *_1905_device)
{
	struct N_O_link_estimate_cb *NO_cb = NULL, *tno_cb = NULL;
	struct radio_info_db *radio = NULL;
	struct bss_info_db *bss = NULL;
	struct N_O_link_estimate_mld_cb *NO_mld_cb = NULL;
	struct _1905_map_device *peer_map_device = NULL;
	int i = 0;
#ifdef MAP_R6
	struct radio_info_db *peer_map_radio = NULL;
#endif

	radio = topo_srv_get_radio(_1905_device, NULL);
	while (radio) {
		notice(DEBUG_CAT_NETOPT, NETOPT_PREX" al_mac "MACSTR"\n", MAC2STR(_1905_device->_1905_info.al_mac_addr));
		notice(DEBUG_CAT_NETOPT, NETOPT_PREX" radio->identifier:"MACSTR"\n", MAC2STR(radio->identifier));

		if (!is_1905dev_radio_mld_capable(_1905_device, radio)) {
			notice(DEBUG_CAT_NETOPT, NETOPT_PREX" 1905_dev's this radio not mld capable\n");
			radio = topo_srv_get_next_radio(_1905_device, radio);
			continue;
		}

		notice(DEBUG_CAT_NETOPT, NETOPT_PREX" 1905_dev's this radio mld capable\n");
		if (!SLIST_EMPTY(&(radio->link_estimate_cb_head))) {
			SLIST_FOREACH_SAFE(NO_cb, &radio->link_estimate_cb_head, link_estimate_cb_entry, tno_cb) {
				notice(DEBUG_CAT_NETOPT, NETOPT_PREX" ALMAC:"MACSTR"\n", MAC2STR(NO_cb->dev_almac));
				notice(DEBUG_CAT_NETOPT, NETOPT_PREX" STA_MAC/BSSID:"MACSTR"\n", MAC2STR(NO_cb->peer_mac));

				/*Peer map device is 1905 device comes in scan result of _1905_device.*/
				peer_map_device = topo_srv_get_1905_by_bssid(ctx, NO_cb->peer_mac);
				if (peer_map_device == NULL) {
					notice(DEBUG_CAT_NETOPT,
					 NETOPT_PREX" peer map dev "MACSTR" not found continue\n", MAC2STR(NO_cb->dev_almac));
					continue;
#ifdef MAP_R6
				} else if (peer_map_device->R6_dev == 1) {
					notice(DEBUG_CAT_NETOPT,
					 NETOPT_PREX" Peer map dev "MACSTR" is R6 dev\n", MAC2STR(NO_cb->dev_almac));
					peer_map_radio = topo_srv_get_radio_by_band_type(peer_map_device, radio->band);
					if (peer_map_radio && !peer_map_radio->ap_mlo_enable) {
						notice(DEBUG_CAT_NETOPT,
						 NETOPT_PREX" peer map dev "MACSTR" does not support mld continue\n",
							MAC2STR(NO_cb->dev_almac));
						continue;
					}
#endif
				} else if (peer_map_device->mld_enabled == 0) {
					/*Peer map device is 1905 device comes in scan result of _1905_device.*/
					notice(DEBUG_CAT_NETOPT,
					 NETOPT_PREX" peer map dev "MACSTR" does not support mld continue\n", MAC2STR(NO_cb->dev_almac));
					continue;
				}

				bss = topo_srv_get_bss_by_bssid(ctx, peer_map_device, NO_cb->peer_mac);
				if (bss == NULL) {
					notice(DEBUG_CAT_NETOPT,
					 NETOPT_PREX" peer map dev does not have bss "MACSTR"\n", MAC2STR(NO_cb->peer_mac));
					continue;
				} else if (os_memcmp(bss->mlo_info.mld_addr, ZERO_MAC_ADDR, ETH_ALEN) == 0) {
					/*BH BSS only presnet in scan result hence BH BSS not part of MLD group.*/
					notice(DEBUG_CAT_NETOPT,
					 NETOPT_PREX" bssid "MACSTR" is not a part of any mld device\n", MAC2STR(NO_cb->peer_mac));
					continue;
				}

				NO_mld_cb = find_existing_entry_in_mld_cb(_1905_device, bss->mlo_info.mld_addr);
				if (!NO_mld_cb) {
					/*no mld mac bss entry already present in the link_estimated_db_mld_list*/
					NO_mld_cb = os_zalloc(sizeof(struct N_O_link_estimate_mld_cb));
					if (!NO_mld_cb) {
						err(DEBUG_CAT_NETOPT, NETOPT_PREX" mem allocation failed\n");
						return;
					}
					for (i = 0; i < MAX_NUM_OF_RADIO; i++)
						NO_mld_cb->mld_links[i] = NULL;

					SLIST_INSERT_HEAD(
							  &(_1905_device->link_estimate_cb_mld_head),
							  NO_mld_cb,
							  link_estimate_cb_mld_entry);
				}
				os_memcpy(NO_mld_cb->dev_almac, NO_cb->dev_almac, ETH_ALEN);
				os_memcpy(NO_mld_cb->mld_mac, bss->mlo_info.mld_addr, ETH_ALEN);
				netopt_fill_mld_links_per_mld(NO_mld_cb, NO_cb, radio);
			}
		} else
			err(DEBUG_CAT_NETOPT, NETOPT_PREX" SLIST empty for this radio\n");

		radio = topo_srv_get_next_radio(_1905_device, radio);
	}
}
#endif

int Update_link_estimation_db_per_dev(struct own_1905_device *ctx,struct _1905_map_device *_1905_device)
{
	u8 i;
	u16 j;
	struct	N_O_link_estimate_cb *NO_cb = NULL;
	struct _1905_map_device *peer_map_device = NULL;
	struct radio_info_db *radio= NULL;
	u8 *buf = NULL;
	struct mapd_global *global = ctx->back_ptr;
	if(_1905_device->net_opt_scan_report == NULL)
	{
		notice(DEBUG_CAT_NETOPT,
		 NETOPT_PREX" no off channel scan report received from "MACSTR"\n", MAC2STR(_1905_device->_1905_info.al_mac_addr));
		return -1;
	}
	buf = (u8 *)_1905_device->net_opt_scan_report->scan_result; 
	for(i=0;i<_1905_device->net_opt_scan_report->scan_result_num;i++)
	{	
		struct net_opt_scan_result_event *scan_result_evt = (struct net_opt_scan_result_event *)buf;
		radio= topo_srv_get_radio(_1905_device, scan_result_evt->radio_id);
		if(radio == NULL)
		{
			err(DEBUG_CAT_NETOPT, NETOPT_PREX" radio not found\n");
			continue;
		}
#ifdef WIFI_MD_COEX_SUPPORT
		/*to check if the channel is operable when doing network optimization*/
#ifndef MAP_6E_SUPPORT
		if (ch_planning_check_channel_operable_wrapper(ctx, scan_result_evt->channel))
#else
		u8 band = get_band_6E(_1905_device, scan_result_evt->channel, scan_result_evt->oper_class);

		if (ch_planning_check_channel_operable_wrapper(ctx, scan_result_evt->channel, band, NULL))
#endif
#endif
		if (scan_result_evt->neighbor_num > MAX_LEN_OF_BSS_TABLE) {
			err(DEBUG_CAT_NETOPT,
			 NETOPT_PREX"maximum scan result neighbor_num(%u) exceeded than 256\n", scan_result_evt->neighbor_num);
			return -1;
		}
		for(j=0;j<scan_result_evt->neighbor_num;j++)
		{	
			struct neighbor_info *nb_info = &scan_result_evt->nb_info[j];
			peer_map_device = topo_srv_get_1905_by_bssid(ctx,nb_info->bssid);
			if(!peer_map_device) {
				info(DEBUG_CAT_NETOPT, NETOPT_PREX" peer map dev "MACSTR" not found continue\n", MAC2STR(nb_info->bssid));
				continue;
			}
			/*Check if the ssid supports bh as given by controller*/
			if (!is_that_a_bh_nb_info(global, (char *)nb_info->ssid))
				continue;
			NO_cb = find_existing_entry_in_cb(radio,nb_info);
			if(!NO_cb)//bssid not already present in the link_estimated_db_list
			{
				NO_cb = os_zalloc(sizeof(*NO_cb));
				if (!NO_cb) {
					err(DEBUG_CAT_NETOPT, NETOPT_PREX" mem allocation failed\n");
					return -1;
				}
				os_memcpy(NO_cb->peer_mac, &nb_info->bssid, ETH_ALEN);
				os_memcpy(NO_cb->dev_almac,peer_map_device->_1905_info.al_mac_addr,ETH_ALEN);
				SLIST_INSERT_HEAD(&(radio->link_estimate_cb_head), NO_cb, link_estimate_cb_entry);
			}
			NO_cb->rcpi=nb_info->RCPI;//for all entries (existing and new) update RSSI
		}
		buf += sizeof(struct net_opt_scan_result_event)+ (scan_result_evt->neighbor_num*sizeof(struct neighbor_info));
	}
#ifndef MTK_MLO_MAP_SUPPORT
	dump_link_estimate_db_per_dev(_1905_device);
#endif
	return 0;
}

void Update_link_estimation_db (struct mapd_global *pGlobal_dev)
{
	struct _1905_map_device *_1905_device = NULL;
	struct own_1905_device *ctx = &pGlobal_dev->dev;
	_1905_device = topo_srv_get_1905_device(ctx, NULL); 
	while(_1905_device) {
		if(_1905_device->device_role != DEVICE_ROLE_CONTROLLER) 
		{
			notice(DEBUG_CAT_NETOPT,
			 NETOPT_PREX" for dev with almac "MACSTR"\n", MAC2STR(_1905_device->_1905_info.al_mac_addr));
			Update_link_estimation_db_per_dev(ctx,_1905_device);
#ifdef MTK_MLO_MAP_SUPPORT
			Update_link_estimation_db_mld_per_dev(ctx, _1905_device);
			remove_single_link_mld_per_dev(_1905_device);
#endif
			dump_link_estimate_db_per_dev(_1905_device);
		}
		_1905_device = topo_srv_get_next_1905_device(&pGlobal_dev->dev,_1905_device);
	}
}
#ifndef MAP_6E_SUPPORT
void network_opt_get_unique_channel_list(struct own_1905_device *ctx,
	unsigned char *channel_arr, unsigned char ch_arr_len)
{
	struct _1905_map_device *_1905_device = NULL;
	struct radio_info_db *radio = NULL;
	unsigned char channel_count = 0;
#ifndef MAP_6E_SUPPORT
	struct bss_info_db *bss = NULL, *tbss = NULL;
#else
	int a = 0;
#endif
	reset_net_opt_allowed(ctx);
	_1905_device = topo_srv_get_1905_device(ctx,NULL);
#ifndef MAP_6E_SUPPORT
	if (_1905_device) {
		/* For every bss */
		SLIST_FOREACH_SAFE(bss, &(_1905_device->first_bss), next_bss, tbss) {
			net_opt_check_bh_scan_allowed(ctx, bss);
		}
	}
#else
	for (a = 0; a < MAX_SET_BSS_INFO_NUM; a++) {
		if (ctx->bss_config[a].oper_class[0] == '8') {
			if (ctx->bss_config[a].wfa_vendor_extension & BSS_BH)
				ctx->network_optimization.scan_2g_allow = 1;
		} else if (ctx->bss_config[a].oper_class[1] == '1') {
			if (ctx->bss_config[a].wfa_vendor_extension & BSS_BH)
				ctx->network_optimization.scan_5gl_allow = 1;
		} else if (ctx->bss_config[a].oper_class[1] == '2') {
			if (ctx->bss_config[a].wfa_vendor_extension & BSS_BH)
				ctx->network_optimization.scan_5gh_allow = 1;
		}
	}
#endif

	while (_1905_device) {
		if (!_1905_device->in_network) {
			_1905_device = topo_srv_get_next_1905_device(ctx, _1905_device);
			continue;
		}
		radio = topo_srv_get_radio(_1905_device,NULL);
		while (radio) {
			if((radio->band == BAND_2G && !ctx->network_optimization.scan_2g_allow) ||
				(radio->band == BAND_5GL && !ctx->network_optimization.scan_5gl_allow) ||
				(radio->band == BAND_5GH && !ctx->network_optimization.scan_5gh_allow)) {
				radio = topo_srv_get_next_radio(_1905_device, radio);
				continue;
			}
			if(radio->channel[0] == 0) {
				radio = topo_srv_get_next_radio(_1905_device, radio);
				continue;
			}

			int i = 0;
			while (i < channel_count) {
				if (channel_arr[i] == radio->channel[0]) {
					break;
				}
				i++;
			}
			if (i == channel_count) {
				channel_arr[i] = radio->channel[0];
				notice(DEBUG_CAT_NETOPT, NETOPT_PREX" scan ch [%d] = %d\n", i, channel_arr[i]);
				channel_count++;
				if(channel_count >= ch_arr_len) {
					err(DEBUG_CAT_NETOPT, NETOPT_PREX" channel_arr[%d] is full (%d)\n", channel_count, ch_arr_len);
					return;
				}
			}
			radio = topo_srv_get_next_radio(_1905_device, radio);
		}
		_1905_device = topo_srv_get_next_1905_device(ctx,_1905_device);
	}
}
#else /*MAP_6E_SUPPORT*/
void network_opt_get_unique_channel_list(struct own_1905_device *ctx,
	struct NO_ch_scan_list *channel_arr, unsigned char ch_arr_len)
{
	struct _1905_map_device *_1905_device = NULL;
	struct radio_info_db *radio = NULL;
	unsigned char channel_count = 0;
	struct bss_info_db *bss = NULL, *tbss = NULL;

	reset_net_opt_allowed(ctx);
	_1905_device = topo_srv_get_1905_device(ctx, NULL);
	if (_1905_device) {
		/* For every bss */
		SLIST_FOREACH_SAFE(bss, &(_1905_device->first_bss), next_bss, tbss) {
			net_opt_check_bh_scan_allowed(ctx, bss);
		}
	}

	while (_1905_device) {
		if (!_1905_device->in_network) {
			_1905_device = topo_srv_get_next_1905_device(ctx, _1905_device);
			continue;
		}
		radio = topo_srv_get_radio(_1905_device, NULL);
		while (radio) {
			if ((radio->band == BAND_2G && !ctx->network_optimization.scan_2g_allow) ||
				(radio->band == BAND_5GL && !ctx->network_optimization.scan_5gl_allow) ||
				(radio->band == BAND_5GH && !ctx->network_optimization.scan_5gh_allow) ||
				(radio->band == BAND_6G && !ctx->network_optimization.scan_6g_allow)) {
				radio = topo_srv_get_next_radio(_1905_device, radio);
				continue;
			}
			if (radio->channel[0] == 0) {
				radio = topo_srv_get_next_radio(_1905_device, radio);
				continue;
			}

			int i = 0;

			while (i < channel_count) {
				if (channel_arr[i].channel == radio->channel[0] &&
						(channel_arr[i].band == radio->band))
					break;
				i++;
			}
			if (i == channel_count) {
				channel_arr[i].channel = radio->channel[0];
				channel_arr[i].op_class = radio->operating_class;
				channel_arr[i].band = radio->band;
				notice(DEBUG_CAT_NETOPT, NETOPT_PREX" scan ch [%d] = %d OP_CL(%d) Band %d\n", i, channel_arr[i].channel,
					channel_arr[i].op_class, channel_arr[i].band);
				channel_count++;
				if (channel_count >= ch_arr_len) {
					err(DEBUG_CAT_NETOPT, NETOPT_PREX" channel_arr[%d] is full (%d)\n", channel_count, ch_arr_len);
					return;
				}
			}
			radio = topo_srv_get_next_radio(_1905_device, radio);
		}
		_1905_device = topo_srv_get_next_1905_device(ctx, _1905_device);
	}
}

#endif /*MAP_6E_SUPPORT*/
#ifdef MAP_R6
void network_opt_scan_list_mlo_bsta(struct _1905_map_device *_1905_device,
				    struct NO_ch_scan_list *scan_ch_list,
				    struct NO_ch_scan_list *scan_ch_list_out)
{
	struct radio_info_db *radio = NULL;
	int i = 0, j = 0;

	if (!_1905_device->in_network)
		return;

	radio = topo_srv_get_radio(_1905_device, NULL);
	while (radio) {
		if (radio->bsta_mlo_enable) {
			notice(DEBUG_CAT_NETOPT, NETOPT_PREX" dev:"MACSTR" radio:"MACSTR" R6 bsta mlo enable %d\n",
				MAC2STR(_1905_device->_1905_info.al_mac_addr),
				MAC2STR(radio->identifier),
				radio->bsta_mlo_enable);
			for (i = 0; i < MAX_OFF_CH_SCAN_CH; i++) {
				if (scan_ch_list[i].band == radio->band) {
					scan_ch_list_out[j].band = scan_ch_list[i].band;
					scan_ch_list_out[j].op_class = scan_ch_list[i].op_class;
					scan_ch_list_out[j].channel = scan_ch_list[i].channel;
					j++;
				}
			}
		}
		radio = topo_srv_get_next_radio(_1905_device, radio);
	}
}
#endif



void network_opt_data_collection(struct mapd_global *pGlobal_dev)
{
	struct _1905_map_device *_1905_device = NULL;
	struct own_1905_device *dev = &pGlobal_dev->dev;
#ifndef MAP_6E_SUPPORT
	unsigned char scan_ch_list[MAX_OFF_CH_SCAN_CH] = {0};
#else
	struct NO_ch_scan_list scan_ch_list[MAX_OFF_CH_SCAN_CH] = {0};
	int i;
#endif /*MAP_6E_SUPPORT*/
#ifdef MAP_R6
	struct NO_ch_scan_list scan_ch_list_r6[MAX_OFF_CH_SCAN_CH] = {0};
#endif

	notice(DEBUG_CAT_NETOPT, NETOPT_PREX" N.O. data collection\n");

	network_opt_get_unique_channel_list(dev, scan_ch_list, MAX_OFF_CH_SCAN_CH);
#ifdef MAP_6E_SUPPORT
	for (i = 0; i < MAX_OFF_CH_SCAN_CH; i++)
		debug(DEBUG_CAT_NETOPT,
		 NETOPT_PREX"band %d ch %d op_class %d\n", scan_ch_list[i].band, scan_ch_list[i].channel, scan_ch_list[i].op_class);
#endif
	_1905_device = topo_srv_get_next_1905_device(dev, NULL); /*Get own device struct.*/
	while(_1905_device) {
		if (!_1905_device->in_network) {
			_1905_device = topo_srv_get_next_1905_device(&pGlobal_dev->dev,_1905_device);
			continue;
		}
		if (_1905_device->device_role == DEVICE_ROLE_CONTROLLER) {
			_1905_device->network_opt_per1905.network_opt_device_state = NETOPT_STATE_DATA_COLLECTION_COMPLETE;
	} else {
			//avoid sending off channel scan req here if the BH of 1905 device is ethernet.
			if (is_eth_BH(_1905_device) == 0){
				_1905_device->network_opt_per1905.network_opt_device_state= NETOPT_STATE_DATA_COLLECTION_ONGOING;
				_1905_device->network_opt_per1905.data_col_retry_count = 0;
				os_get_time(&_1905_device->network_opt_per1905.data_collection_start_ts);
#ifdef MAP_R6
				if (_1905_device->R6_dev == 1)
					network_opt_scan_list_mlo_bsta(_1905_device, scan_ch_list, scan_ch_list_r6);
#endif
#ifdef MAP_R2
			if(
#ifdef MAP_R3
				(
#endif
					dev->map_version == DEV_TYPE_R2
#ifdef MAP_R3
					|| dev->map_version == DEV_TYPE_R3
				)
#endif
				&& 
#ifdef MAP_R3
				(
#endif
					_1905_device->map_version == DEV_TYPE_R2
#ifdef MAP_R3
					|| _1905_device->map_version == DEV_TYPE_R3
				)
#endif
			)
			{
				notice(DEBUG_CAT_NETOPT, NETOPT_PREX" Send R2 device Channel Scan Request to "MACSTR"\n",
						MAC2STR(_1905_device->_1905_info.al_mac_addr));
				/*Wait for 250 ms so that no two devices scan same channel at the same time
				if two devices scan at the same time on same channel, they won't receive
				each other's beacon*/
				os_sleep(0, 250000);
#ifdef MAP_R6
				if (_1905_device->R6_dev == 1)
					send_channel_scan_req(pGlobal_dev, _1905_device, scan_ch_list_r6, MAX_OFF_CH_SCAN_CH);
				else
					send_channel_scan_req(pGlobal_dev, _1905_device, scan_ch_list, MAX_OFF_CH_SCAN_CH);
#else
				send_channel_scan_req(pGlobal_dev,_1905_device, scan_ch_list, MAX_OFF_CH_SCAN_CH);
#endif
			} else {
				notice(DEBUG_CAT_NETOPT, NETOPT_PREX" Send R1 device Channel Scan Request to "MACSTR"\n",
						MAC2STR(_1905_device->_1905_info.al_mac_addr));
				/* when sending scan request from netopt
				 * to multiple agents ,Added delay of 250 ms
				 * between multiple agents while sending
				 * scan request as done for R2 Controller
				 */
				os_sleep(0, 250000);
				send_off_ch_scan_req(pGlobal_dev, _1905_device, SCAN_MODE_CH, 0, scan_ch_list, 0,0);
			}
#else
				send_off_ch_scan_req(pGlobal_dev, _1905_device, SCAN_MODE_CH, 0, scan_ch_list, 0,0);
#endif
			}
			else {
				_1905_device->network_opt_per1905.network_opt_device_state = NETOPT_STATE_DATA_COLLECTION_COMPLETE;
				notice(DEBUG_CAT_NETOPT, NETOPT_PREX" ethernet BH so don't do off channel scan\n");
			}	
		}
		_1905_device = topo_srv_get_next_1905_device(&pGlobal_dev->dev,_1905_device);
	}
}
void retry_data_collection(struct mapd_global *pGlobal_dev,struct _1905_map_device * _1905_device)
{
#ifndef MAP_6E_SUPPORT
	unsigned char scan_ch_list[MAX_OFF_CH_SCAN_CH] = {0};
#else
	struct NO_ch_scan_list scan_ch_list[MAX_OFF_CH_SCAN_CH] = {0};
#endif

	network_opt_get_unique_channel_list(&pGlobal_dev->dev,
		scan_ch_list, MAX_OFF_CH_SCAN_CH);
#ifdef MAP_R2
	if  (
#ifdef MAP_R3
			(
#endif
				pGlobal_dev->dev.map_version == DEV_TYPE_R2
#ifdef MAP_R3
				|| pGlobal_dev->dev.map_version == DEV_TYPE_R3
			)
#endif
			&& 
#ifdef MAP_R3
			(
#endif
				_1905_device->map_version == DEV_TYPE_R2
#ifdef MAP_R3
				|| _1905_device->map_version == DEV_TYPE_R3
			)
#endif
		)
	{
		send_channel_scan_req(pGlobal_dev,_1905_device, scan_ch_list, MAX_OFF_CH_SCAN_CH);
	} else
#endif
	send_off_ch_scan_req(pGlobal_dev, _1905_device, SCAN_MODE_CH, 0, scan_ch_list, 0,0);
}
unsigned char is_net_opt_data_collection_complete(struct mapd_global *pGlobal_dev)
{
	struct own_1905_device *dev = &pGlobal_dev->dev;
	struct _1905_map_device *_1905_device = NULL;	
	_1905_device = topo_srv_get_next_1905_device(dev, NULL); /*Get own device struct.*/
	while(_1905_device) {
		if (_1905_device->device_role != DEVICE_ROLE_CONTROLLER) {
			if(_1905_device->network_opt_per1905.network_opt_device_state == NETOPT_STATE_DATA_COLLECTION_ONGOING) {
				info(DEBUG_CAT_NETOPT,
				 NETOPT_PREX" Not complete yet "MACSTR"\n", MAC2STR(_1905_device->_1905_info.al_mac_addr));
				dev->network_optimization.network_opt_state = NETOPT_STATE_DATA_COLLECTION_ONGOING;
				return 0;
				break;
			}
		}
		_1905_device = topo_srv_get_next_1905_device(&pGlobal_dev->dev,_1905_device);
	}
	return 1;//complete
}
unsigned char periodic_network_opt_checking(struct mapd_global *pGlobal_dev)
{
	struct own_1905_device *dev = &pGlobal_dev->dev;
	struct os_time now;
	struct _1905_map_device *_1905_device = NULL;	
	unsigned char is_Data_collection_complete = 0;
	os_get_time(&now);
	_1905_device = topo_srv_get_next_1905_device(dev, NULL); /*Get own device struct.*/
	while(_1905_device) {
			if(_1905_device->network_opt_per1905.network_opt_device_state == NETOPT_STATE_DATA_COLLECTION_ONGOING) {
				if (now.sec > (_1905_device->network_opt_per1905.data_collection_start_ts.sec + 
						dev->network_optimization.data_collection_wait_time)) {
						if(_1905_device->network_opt_per1905.data_col_retry_count < 5){
							_1905_device->network_opt_per1905.data_col_retry_count++;
							os_get_time(&_1905_device->network_opt_per1905.data_collection_start_ts);
							err(DEBUG_CAT_NETOPT,
							 NETOPT_PREX" retry data collection , report not received. Count %d\n",
							  _1905_device->network_opt_per1905.data_col_retry_count);
							retry_data_collection(pGlobal_dev,_1905_device);
						}
						else {
							err(DEBUG_CAT_NETOPT,
							 NETOPT_PREX" retry count expired , put state as data collection complete\n");
							_1905_device->network_opt_per1905.network_opt_device_state = NETOPT_STATE_DATA_COLLECTION_COMPLETE;
							_1905_device->network_opt_per1905.data_col_retry_count = 0;
					}
				}
			}
		_1905_device = topo_srv_get_next_1905_device(&pGlobal_dev->dev,_1905_device);
	}	
	is_Data_collection_complete = is_net_opt_data_collection_complete(pGlobal_dev);
	info(DEBUG_CAT_NETOPT, NETOPT_PREX" is_Data_collection_complete %d\n", is_Data_collection_complete);
	return is_Data_collection_complete;
}
/*
* Check if Network Optimization is Required
*/
void is_network_opt_required_rate(struct mapd_global *pGlobal_dev)
{
	struct _1905_map_device *_1905_device = NULL;
	struct own_1905_device *ctx = &pGlobal_dev->dev;
	struct radio_info_db *radio = NULL;
	unsigned char count_threshold = 5;
	_1905_device = topo_srv_get_next_1905_device(ctx, NULL); /*Get own device struct.*/
	while(_1905_device) {
		if (_1905_device->device_role != DEVICE_ROLE_CONTROLLER) {
			radio = topo_srv_get_radio(_1905_device, NULL);
			while(radio) {
				if(radio->network_opt_1905dev_radio.rate_deviate_count > count_threshold) {
					ctx->network_optimization.NetOptReason = REASON_RSSI_VARIATION;
					err(DEBUG_CAT_NETOPT,
					 NETOPT_PREX" device radio uplink rate deviates for more than 5mins , reset last uplink rate\n");
					radio->network_opt_1905dev_radio.last_uplink_rate = 0;
					radio->network_opt_1905dev_radio.rate_deviate_count = 0;
					break;
				}	
				radio = topo_srv_get_next_radio(_1905_device,radio);
			}
		}
		if (ctx->network_optimization.NetOptReason == REASON_RSSI_VARIATION)
			break;
		_1905_device = topo_srv_get_next_1905_device(ctx,_1905_device);
	}
		return;
}
unsigned char is_all_dev_idle(struct own_1905_device *dev)
{
	struct _1905_map_device *_1905_device = NULL;	
	unsigned char is_idle =1;
	_1905_device = topo_srv_get_next_1905_device(dev, NULL); /*Get own device struct.*/
	while(_1905_device) {
		if ((_1905_device->network_opt_per1905.network_opt_device_state != NETOPT_STATE_IDLE ))
		{
			is_idle = 0;
			break;
		}
		_1905_device = topo_srv_get_next_1905_device(dev,_1905_device);
	}

	return is_idle;
}
void reset_last_uplink_rate(struct mapd_global *pGlobal_dev)
{
	struct _1905_map_device *_1905_device = NULL;
	struct own_1905_device *ctx = &pGlobal_dev->dev;
	struct radio_info_db *radio = NULL;
	_1905_device = topo_srv_get_next_1905_device(ctx, NULL); /*Get own device struct.*/
	while(_1905_device) {
		if (_1905_device->device_role != DEVICE_ROLE_CONTROLLER) {
			radio = topo_srv_get_radio(_1905_device, NULL);
			while(radio) {
				info(DEBUG_CAT_NETOPT, NETOPT_PREX" reset last uplink rate %d  to 0\n",
				 radio->network_opt_1905dev_radio.last_uplink_rate);
				radio->network_opt_1905dev_radio.last_uplink_rate = 0;
				radio->network_opt_1905dev_radio.rate_deviate_count = 0;
				radio = topo_srv_get_next_radio(_1905_device,radio);
			}
		}
		_1905_device = topo_srv_get_next_1905_device(ctx,_1905_device);
	}
}

#ifdef MAP_6E_SUPPORT
Boolean is_netopt_band_map_done(struct _1905_map_device *_1905_device)
{
	struct radio_info_db *radio = NULL;

	radio = topo_srv_get_next_radio(_1905_device, NULL);

	if (!radio) {
		err(DEBUG_CAT_NETOPT, NETOPT_PREX"radio is not created, try again!\n");
		return FALSE;
	}

	while (radio) {
		if (radio->band == 0) {
			err(DEBUG_CAT_NETOPT, NETOPT_PREX"radio->band mapping is not completed, try again!\n");
			return FALSE;
		}
		radio = topo_srv_get_next_radio(_1905_device, radio);
	}
	return TRUE;
}
#endif
int is_network_opt_required(struct mapd_global *pGlobal_dev)
{
	struct own_1905_device *dev = &pGlobal_dev->dev;
	struct os_time now;
	unsigned int count = 0;
	struct _1905_map_device *_1905_device = NULL;	
	int status = REASON_NOT_REQUIRED;
#ifdef MAP_6E_SUPPORT
	u8 radio_mapping = 1;
#endif
	if(is_all_dev_idle(dev) == 0) {
		notice(DEBUG_CAT_NETOPT, NETOPT_PREX" all 1905 devs are not idle so REASON_NOT_REQUIRED\n");
		status = REASON_NOT_REQUIRED;
			return status;
	}
	_1905_device = topo_srv_get_next_1905_device(dev, NULL); /*Get own device struct.*/
	while(_1905_device) {
		if (_1905_device->in_network) {
			info(DEBUG_CAT_NETOPT, NETOPT_PREX" In Network ALMAC" MACSTR"\n", MAC2STR(_1905_device->_1905_info.al_mac_addr));
			count++;
		}
#ifdef MAP_6E_SUPPORT
		if (_1905_device->in_network
			&& (!_1905_device->radio_mapping_completed
			|| !_1905_device->ch_preference_available
			|| !is_netopt_band_map_done(_1905_device))) {
			info(DEBUG_CAT_NETOPT, NETOPT_PREX" radio_mapping not done, don't run Net Opt map %d pref %d\n",
			_1905_device->radio_mapping_completed, _1905_device->ch_preference_available);
			radio_mapping = 0;
		}
#endif

		_1905_device = topo_srv_get_next_1905_device(dev,_1905_device);
	}
#ifdef MAP_6E_SUPPORT
	if (radio_mapping == 0) {
		info(DEBUG_CAT_NETOPT, NETOPT_PREX" radio_mapping not done, don't run Net Opt\n");
		return status;
	}
#endif
	if(count < MINIMUM_AGENTS_COUNT_FOR_NETWORK_OPTIMIZATION) {
		status = REASON_NOT_REQUIRED;
		dev->network_optimization.NetOptReason = status;
		info(DEBUG_CAT_NETOPT, NETOPT_PREX" no agent present, don't run Net Opt\n");
		return status;
	}
	if (dev->network_optimization.NetOptReason == REASON_ENABLED_BY_USER) {
		err(DEBUG_CAT_NETOPT, NETOPT_PREX" REASON_ENABLED_BY_USER\n");
		status = dev->network_optimization.NetOptReason;
		return status;
	}
	os_get_time(&now);
	if (dev->network_optimization.NetOptReason == REASON_TRY_AGAIN && (now.sec > dev->network_optimization.trigger_netopt_ts.sec + dev->network_optimization.wait_time)) {
		notice(DEBUG_CAT_NETOPT, NETOPT_PREX" REASON_TRY_AGAIN\n");
		status = dev->network_optimization.NetOptReason;
		return status;
	}
	if (dev->network_optimization.NetOptReason == REASON_TOPOLOGY_CHANGE) {
		//err(DEBUG_CAT_NETOPT, "dev->network_optmization.ntwrk_change_ts.sec %ld",dev->network_optimization.ntwrk_change_ts.sec);
		//err(DEBUG_CAT_NETOPT, "dev->network_optmization.wait_time %d",dev->network_optimization.wait_time);
		if((now.sec > dev->network_optimization.ntwrk_change_ts.sec +
			dev->network_optimization.wait_time)) {
			notice(DEBUG_CAT_NETOPT, NETOPT_PREX" now %ld\n", now.sec);
			notice(DEBUG_CAT_NETOPT, NETOPT_PREX" REASON_TOPOLOGY_CHANGE\n");
			status = dev->network_optimization.NetOptReason;
			return status;
		} else {
			info(DEBUG_CAT_NETOPT, NETOPT_PREX" Wait Time %ld\n", now.sec);
			status = REASON_NOT_REQUIRED; //as wait time is not over
			return status;
		}
	}
	//RSSI comparison in current topology with the last captured one , 
	//if it varies more than uplink rate margin 
	//for more than count allowed then only trigger NetOpt
	if (!dev->network_optimization.nep_opt_disable_rssi_var)
		is_network_opt_required_rate(pGlobal_dev);
	else
		info(DEBUG_CAT_NETOPT, NETOPT_PREX" RSSI based NetOpt disabled\n");

	if (dev->network_optimization.NetOptReason == REASON_RSSI_VARIATION)
	{
		notice(DEBUG_CAT_NETOPT, NETOPT_PREX" REASON_RSSI_VARIATION\n");
		status = REASON_RSSI_VARIATION;
		reset_last_uplink_rate(pGlobal_dev);
	}

	return status;
}

int get_net_opt_dev_count(struct mapd_global *pGlobal_dev)
{
	struct own_1905_device *dev = &pGlobal_dev->dev;
	unsigned int count = 0;
	struct _1905_map_device *_1905_device = NULL;	
	_1905_device = topo_srv_get_next_1905_device(dev, NULL); /*Get own device struct.*/
	while(_1905_device) {
		if (_1905_device->in_network)
		{
			info(DEBUG_CAT_NETOPT, NETOPT_PREX" In Network ALMAC\n" MACSTR, MAC2STR(_1905_device->_1905_info.al_mac_addr));
			count++;
		}
		_1905_device = topo_srv_get_next_1905_device(dev,_1905_device);
	}
	return count;
}

void ntwrk_opt_device_conn_disconnect_handle(struct own_1905_device *ctx, unsigned char IsConnect, struct _1905_map_device *_1905_dev)
{
	struct radio_info_db *radio = NULL, *tmp_radio = NULL;
	notice(DEBUG_CAT_NETOPT, NETOPT_PREX" Connect %d\n", IsConnect);

	_1905_dev->policy_config_interval = 0;
#if defined(MAP_6E_SUPPORT) && defined(MAP_R6)
	ctx->cosr_state = COSR_CONN_DISCONN_CHG;
	ctx->cosr_prev_state = COSR_CONN_DISCONN_CHG - 1;
#endif /* MAP_6E_SUPPORT and MAP_R6 */

	if(ctx->network_optimization.network_optimization_enabled == 0){
		return;
	}

	if(IsConnect == DEVICE_CONNECT) {
		ctx->network_optimization.wait_time = ctx->network_optimization.connect_wait_time;
	} else {
		ctx->network_optimization.wait_time = ctx->network_optimization.disconnect_wait_time;
#ifdef MAP_VENDOR_SUPPORT
		_1905_dev->bootup_ch_sel_send = 0;
#endif /* MAP_VENDOR_SUPPORT */
		SLIST_FOREACH_SAFE(radio, &_1905_dev->first_radio, next_radio, tmp_radio)
			radio->support_ch_sync = 0;
	}

	os_get_time(&ctx->network_optimization.ntwrk_change_ts);
	notice(DEBUG_CAT_NETOPT, NETOPT_PREX" Network Connect Disconnect state %d timestamp  %ld\n",
	 IsConnect, ctx->network_optimization.ntwrk_change_ts.sec);
	notice(DEBUG_CAT_NETOPT, NETOPT_PREX" for neighbor("MACSTR")\n", MAC2STR(_1905_dev->_1905_info.al_mac_addr));
		if ((_1905_dev->network_opt_per1905.network_opt_device_state == NETOPT_STATE_OPT_NET_REALIZATION_ONGOING) ) {
			if(IsConnect)
			{
				notice(DEBUG_CAT_NETOPT, NETOPT_PREX" Net Opt complete\n");
				_1905_dev->network_opt_per1905.network_opt_device_state = NETOPT_STATE_COMPLETE;
			}
		} else {
			notice(DEBUG_CAT_NETOPT, NETOPT_PREX" topo changed\n");
			network_opt_reset(ctx->back_ptr);
			ctx->network_optimization.NetOptReason = REASON_TOPOLOGY_CHANGE;
			if(ctx->network_optimization.prefer_5G_bh)
				ctx->network_optimization.prefer_5G_bh_try_cnt_curr = 0;
		}	
}
void Update_controller_state(struct own_1905_device *dev )
{
	struct _1905_map_device *_1905_device = NULL;	
	_1905_device = topo_srv_get_next_1905_device(dev, NULL); /*Get own device struct.*/
	while(_1905_device) {
		if (_1905_device->device_role == DEVICE_ROLE_CONTROLLER)
		{
			_1905_device->network_opt_per1905.network_opt_device_state = NETOPT_STATE_COMPLETE;
		}
		_1905_device = topo_srv_get_next_1905_device(dev,_1905_device);
	}
}



void trigger_net_opt(void *eloop_ctx, void *timeout_ctx)
{
	struct own_1905_device *dev= eloop_ctx;
	struct _1905_map_device *_1905_dev = topo_srv_get_1905_device(dev, NULL);
	struct radio_info_db *radio = NULL;
	if(dev->network_optimization.network_optimization_enabled){
		dev->network_optimization.NetOptReason = REASON_TOPOLOGY_CHANGE;
		notice(DEBUG_CAT_NETOPT, NETOPT_PREX" topo changed\n");
		if(dev->network_optimization.prefer_5G_bh)
			dev->network_optimization.prefer_5G_bh_try_cnt_curr = 0;
	}
	while (_1905_dev) {
		radio = topo_srv_get_radio(_1905_dev, NULL);
		while (radio) {
			radio->cac_channel = 0;
			radio->cac_enable = 0;
			radio->cac_timer = 0;
			radio = topo_srv_get_next_radio(_1905_dev, radio);
		}
		_1905_dev = topo_srv_get_next_1905_device(dev, _1905_dev);
	}
#if defined(MAP_6E_SUPPORT) && defined(MAP_R6)
	_1905_dev = topo_srv_get_1905_device(dev, NULL);
	if (dev->device_role == DEVICE_ROLE_CONTROLLER && _1905_dev->cosr_enable == 1)
		dev->cosr_state = COSR_CONN_DISCONN_CHG;
#endif /* MAP_6E_SUPPORT and MAP_R6 */
}

void trigger_5G_net_opt(void *eloop_ctx, void *timeout_ctx)
{
	struct own_1905_device *dev= eloop_ctx;
	struct _1905_map_device *map_dev, *tmap_dev = NULL;
	struct radio_info_db *radio = NULL;

	always(NETOPT_PREX" Nw opt trigger timer function\n");
	SLIST_FOREACH_SAFE(map_dev, &(dev->_1905_dev_head), next_1905_device, tmap_dev) {
		do {
			radio = topo_srv_get_next_radio(map_dev, radio);
			if (radio) {
				if ((radio->channel[0] > 14) && (radio->uplink_bh_present == TRUE)){
					err(DEBUG_CAT_NETOPT, NETOPT_PREX" do nothing, already on 5Gv\n");
					return;
					}
				}
			}while(radio);
	}

	if(dev->network_optimization.network_optimization_enabled){
		notice(DEBUG_CAT_NETOPT, NETOPT_PREX" topo changed\n");
		dev->network_optimization.NetOptReason = REASON_TOPOLOGY_CHANGE;
		dev->network_optimization.prefer_5G_bh_try_cnt_curr = 0;
	}
	dev->nw_opt_triggered_5G = FALSE;
	dev->nw_opt_triggered_5G_in_process = TRUE;
}

void network_optimization_state_handler(struct mapd_global *global)
{
	struct own_1905_device *dev = &global->dev;
	NETOPT_STATE netopt_state;
	int status;
	unsigned char is_Data_collection_complete = 0;
	unsigned char all_dev_state = 0;
	netopt_state = dev->network_optimization.network_opt_state;
	info(DEBUG_CAT_NETOPT, NETOPT_PREX" netopt_state %d\n", netopt_state);
	switch(netopt_state)
	{
	 case NETOPT_STATE_IDLE:
			status = is_network_opt_required(global);
			info(DEBUG_CAT_NETOPT, NETOPT_PREX" is_network_opt_required status %d\n", status);
			if(status != REASON_NOT_REQUIRED) {
#ifdef MAP_R2
				if((dev->ch_planning_R2.ch_plan_enable == TRUE) &&
					((dev->ch_planning_R2.ch_plan_state != CHPLAN_STATE_IDLE) ||
						(dev->user_triggered_scan == TRUE)))
				{ 
					dev->network_optimization.network_optimization_enabled = 0;
					network_opt_reset(global);
					dev->network_optimization.NetOptReason = REASON_ENABLED_BY_USER;
					notice(DEBUG_CAT_NETOPT, NETOPT_PREX" REASON_ENABLED_BY_USER\n");
					insert_into_task_list(dev,TASK_NETWORK_OPT_TRIGGER, NULL, NULL, NULL);
					break;
				}
#endif
				network_opt_reset(global);
				dev->network_optimization.network_opt_state = NETOPT_STATE_DATA_COLLECTION_ONGOING;
				network_opt_data_collection(global);
				notice(DEBUG_CAT_NETOPT, NETOPT_PREX" triggered collection\n");
			}
			break;
	case NETOPT_STATE_DATA_COLLECTION_ONGOING:
			info(DEBUG_CAT_NETOPT, NETOPT_PREX" NETOPT_STATE_DATA_COLLECTION_ONGOING\n");
			is_Data_collection_complete = periodic_network_opt_checking(global);
			if(is_Data_collection_complete) {
				Update_link_estimation_db(global);
				Optimized_Link_estimation_algo(global);
				dev->network_optimization.network_opt_state = NETOPT_STATE_OPT_NET_NEED_TO_REALIZE;
			} else {
				break;
			}
	 case NETOPT_STATE_OPT_NET_NEED_TO_REALIZE:
			//send BH steer command per device
			Optimized_network_realization(global);
			dev->network_optimization.network_opt_state = NETOPT_STATE_OPT_NET_REALIZATION_ONGOING;
			break;
	 case NETOPT_STATE_OPT_NET_REALIZATION_ONGOING:
	 		//if all devices are having state done , then move global state done.
			all_dev_state = is_all_dev_state_done(dev) ;
		 	if (all_dev_state == REALIZATION_DONE){
				notice(DEBUG_CAT_NETOPT, NETOPT_PREX" all devices BH steer complete\n");
	 			network_opt_reset(global);
				dev->network_optimization.network_opt_state = NETOPT_STATE_IDLE;
#ifdef MAP_R2
				handle_task_completion(&global->dev);
#endif
				if(dev->nw_opt_triggered_5G_in_process == TRUE) {
					dev->nw_opt_triggered_5G_in_process = FALSE;
				}
		 	} else if (all_dev_state == TRIGGER_NEW_REALIZATION){
		 		Optimized_network_realization(global);
				dev->network_optimization.network_opt_state = NETOPT_STATE_OPT_NET_REALIZATION_ONGOING;
		 	}
			break;
	 default:
			err(DEBUG_CAT_NETOPT, NETOPT_PREX" invalid state for network optimization\n");
			break;
	}
}
