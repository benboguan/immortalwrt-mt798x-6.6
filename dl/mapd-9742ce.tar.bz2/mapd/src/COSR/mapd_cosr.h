/* SPDX-License-Identifier: MediaTekProprietary*/
/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2023-2024  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#ifndef MAPD_COSR_H
#define MAPD_COSR_H

#if defined(MAP_6E_SUPPORT) && defined(MAP_R6)
#include "mapd_i.h"

#define MAX_NUM_OF_COSR_STA 8
#define MAX_NUM_OF_COSR_AP 3


enum COSR_STATE {
	COSR_DISABLE,
	COSR_INIT,
	COSR_CONN_DISCONN_CHG,
	COSR_AP_RSSI_LIST_UPDATE,
	COSR_STA_LIST_PREP,
	COSR_PATH_LOSS_CALCULATION,
	COSR_PATH_LOSS_COMPLETE,
	COSR_COMPLETE,
};

struct GNU_PACKED cosr_station_profile {
	u8 sta_mac[ETH_ALEN];
	u8 sta_rcpi;
	int pathlossA1;
	int pathlossA2;
	int pathlossA3;
	u8 sta_status;
};


struct GNU_PACKED cosr_ap_profile {
	u8 ap_mac[ETH_ALEN];
	u8 indentifier[ETH_ALEN];
	u8 band;
	s8 rcpi;
	u8 cosr_status;
	u8 is_controller;
};

struct GNU_PACKED cosr_sta_list {
	u8 identifier[ETH_ALEN];
	struct cosr_station_profile station_list[MAX_NUM_OF_COSR_STA];
};

struct GNU_PACKED cosr_ap_list {
	u8 almac[ETH_ALEN];
	u8 valid;
	u8 ap_idx;
	struct cosr_ap_profile cosr_ap_pro[MAX_NUM_OF_RADIO];
};

struct GNU_PACKED cosr_apinfo_data {
	u8 identifier[ETH_ALEN];
	struct cosr_ap_profile ap_list[MAX_NUM_OF_COSR_AP];
};

void cosr_sta_airmonitor_timeout_handler(void *eloop_ctx, void *eloop_data);
//void cosr_execute(struct mapd_global *global);
#endif /* MAP_6E_SUPPORT and MAP_R6 */

#endif

