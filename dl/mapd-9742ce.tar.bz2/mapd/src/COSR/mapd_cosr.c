// SPDX-License-Identifier: MediaTekProprietary
/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2023-2024  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#if defined(MAP_6E_SUPPORT) && defined(MAP_R6)
#include <sys/un.h>
#include <sys/time.h>
#include "includes.h"
#include "common.h"
#include "mapd_debug.h"
#include "interface.h"
#include "data_def.h"
#include "client_db.h"
#include "mapd_i.h"
#include "topologySrv.h"
#include "eloop.h"
#include "wapp_if.h"
#include "tlv_parsor.h"
#include "client_db.h"
#include "ap_est.h"
#ifdef SUPPORT_MULTI_AP
#include "1905_map_interface.h"
#endif
#include "mapd_cosr.h"
#include "ch_planning.h"
#include "network_optimization.h"


int find_cosr_ap_list(struct _1905_map_device *dev, u8 *almac)
{
	int i = 0;

	if (dev == NULL || almac == NULL)
		return -1;

	if (is_zero_ether_addr(almac))
		return -1;

	for (i = 0; i < MAX_NUM_OF_COSR_AP; i++) {
		if (os_memcmp(dev->cosr_ap[i].almac, almac, ETH_ALEN) == 0)
			return i;
	}
	return -1;
}

int check_avialble_space_cosr_list(struct _1905_map_device *dev)
{
	int i = 0;

	if (dev == NULL)
		return -1;

	for (i = 0; i < MAX_NUM_OF_COSR_AP; i++) {
		if (dev->cosr_ap[i].valid == 0)
			return i;
	}
	return -1;
}

static int check_station_list_empty(struct associated_clients *assoc_chk_sta, struct _1905_map_device *dev, int band)
{
	int i = 0;

	if (band < 0 || band >= MAX_NUM_OF_RADIO) {
		err(DEBUG_CAT_COSR, "Wrong band range %d\n", band);
		return 0;
	}
	while (i < MAX_NUM_OF_COSR_STA) {
		if (dev->cosr_sta_list[band][i].sta_status == 0)
			return 1;

		i++;
	}
	return 0;
}

static int find_station_inside_cosr_list(struct associated_clients *assoc_findsta, struct _1905_map_device *dev, int band)
{
	int i = 0;

	if (band < 0 || band >= MAX_NUM_OF_RADIO) {
		err(DEBUG_CAT_COSR, "Wrong band range %d\n", band);
		return 0;
	}

	while (i < MAX_NUM_OF_COSR_STA) {
		if (os_memcmp(assoc_findsta->client_addr, dev->cosr_sta_list[band][i].sta_mac, ETH_ALEN) == 0
		  && dev->cosr_sta_list[band][i].sta_status == 3)
			return i;

		i++;
	}
	return -1;
}

static void add_entry_into_sta_list(struct _1905_map_device *dev, struct associated_clients *assoc_cosr_add, int band)
{
	int i = 0;

	if (band < 0 || band >= MAX_NUM_OF_RADIO) {
		err(DEBUG_CAT_COSR, "Wrong band range %d\n", band);
		return;
	}

	for (i = 0; i < MAX_NUM_OF_COSR_STA; i++) {
		if (dev->cosr_sta_list[band][i].sta_status == 0) {
			os_memcpy(dev->cosr_sta_list[band][i].sta_mac, assoc_cosr_add->client_addr, ETH_ALEN);
			dev->cosr_sta_list[band][i].sta_rcpi = rssi_to_rcpi(assoc_cosr_add->rssi_uplink);
			dev->cosr_sta_list[band][i].sta_status = 3;
			dev->cosr_sta_list[band][i].pathlossA1 = -110;
			dev->cosr_sta_list[band][i].pathlossA2 = -110;
			dev->cosr_sta_list[band][i].pathlossA3 = -110;
			break;
		}
	}
}

static void cosr_update_sta_list(struct own_1905_device *ctx, struct _1905_map_device *dev)
{
	int i, j, count = 0;
	struct associated_clients *assoc_client;

	for (i = 0; i < MAX_NUM_OF_RADIO; i++) {
		dev->cosr_sta_num[i] = count;
		for (j = 0; j < MAX_NUM_OF_COSR_STA; j++) {
			if (dev->cosr_sta_list[i][j].sta_status == 3) {
				assoc_client = topo_srv_get_associate_client(ctx,
										dev, dev->cosr_sta_list[i][j].sta_mac);
				if (assoc_client == NULL) {
					dev->cosr_sta_list[i][j].sta_status = 0;
					continue;
				}
				count++;
			}
		}
		dev->cosr_sta_num[i] = count;
		count = 0;
	}
}

static void cosr_do_rssi_comparison(struct _1905_map_device *dev, struct associated_clients *assoc_cosr_rssi_cmp, int band)
{
	int i = 0, cnt = -1;
	int max_rssi = assoc_cosr_rssi_cmp->rssi_uplink;
	if (band < 0 || band >= MAX_NUM_OF_RADIO) {
		err(DEBUG_CAT_COSR, "Wrong band range %d\n", band);
		return;
	}
	while (i < MAX_NUM_OF_COSR_STA) {
		if (max_rssi < rcpi_to_rssi(dev->cosr_sta_list[band][i].sta_rcpi)) {
			max_rssi = rcpi_to_rssi(dev->cosr_sta_list[band][i].sta_rcpi);
			cnt = i;
		}
		i++;
	}
	if (cnt < 0 || cnt >= MAX_NUM_OF_COSR_STA) {
		err(DEBUG_CAT_COSR, "Count value not in range %d\n", cnt);
		return;
	}

	os_memcpy(dev->cosr_sta_list[band][cnt].sta_mac, assoc_cosr_rssi_cmp->client_addr, ETH_ALEN);
	dev->cosr_sta_list[band][cnt].sta_rcpi = rssi_to_rcpi(assoc_cosr_rssi_cmp->rssi_uplink);
	dev->cosr_sta_list[band][cnt].sta_status = 3;
}

void cosr_sta_airmonitor_timeout_handler(void *eloop_ctx, void *eloop_data)
{
	struct own_1905_device *ctx = (struct own_1905_device *) eloop_ctx;

	ctx->airmon_complete_cnt = 0;
	ctx->air_mon_sta_cnt = 0;
	ctx->cosr_state = COSR_PATH_LOSS_CALCULATION;
}

void cosr_ap_airmonitor_timeout_handler(void *eloop_ctx, void *eloop_data)
{
	struct own_1905_device *ctx = (struct own_1905_device *) eloop_ctx;

	ctx->airmon_ap_complete_cnt = 0;
	ctx->air_mon_ap_cnt = 0;
	ctx->cosr_state = COSR_STA_LIST_PREP;
}

void cosr_complete_timeout_handler(void *eloop_ctx, void *eloop_data)
{
	struct own_1905_device *ctx = (struct own_1905_device *) eloop_ctx;

	if (ctx->cosr_ap_list_update == 10) {
		ctx->cosr_state = COSR_CONN_DISCONN_CHG;
		ctx->cosr_ap_list_update = 0;
	} else {
		ctx->cosr_state = COSR_STA_LIST_PREP;
		ctx->cosr_ap_list_update += 1;
	}
}

int cosr_update_upstream_link_rssi(struct own_1905_device *ctx, struct _1905_map_device *dev, u8 band)
{
	struct map_neighbor_info *neighbor_info = NULL, *t_neighbor_info = NULL;
	struct backhaul_link_info *bh_info = NULL, *tbh_info = NULL;
	unsigned char i, apcli_band;
	struct associated_clients *assoc_cli_link = NULL;
	struct affiliated_sta_db *aff_sta = NULL, *aff_sta_tmp = NULL;

	SLIST_FOREACH_SAFE(neighbor_info, &dev->neighbors_entry, next_neighbor, t_neighbor_info) {
		if (is_backhaul_ethernet(neighbor_info, dev))
			return 0;

		SLIST_FOREACH_SAFE(bh_info, &neighbor_info->bh_head, next_bh, tbh_info) {

			assoc_cli_link = topo_srv_get_associate_client(ctx, dev->upstream_device,
											bh_info->connected_iface_addr);

			if (assoc_cli_link == NULL || assoc_cli_link->bss == NULL)
				continue;

#ifdef MAP_R6
			if (!assoc_cli_link->bss->radio) {
				err(DEBUG_CAT_COSR, "bssid radio is null for bssid " MACSTR, MAC2STR(assoc_cli_link->bss->bssid));
				continue;
			}
#endif /* MAP_R6 */
			apcli_band = assoc_cli_link->bss->radio->band;
			if (apcli_band == band)
				return assoc_cli_link->rssi_uplink;

			if (dev->R6_dev && dev->device_role == DEVICE_ROLE_AGENT) {
				if (dev->R6_dev && dev->mld_bsta.num_affiliated_sta <= 1)
					return 0;

				dl_list_for_each_safe(aff_sta, aff_sta_tmp, &dev->mld_bsta.affiliated_sta_list,
						struct affiliated_sta_db, list) {

					if (is_zero_ether_addr(aff_sta->affiliated_sta_bssid))
						continue;

					if (os_memcmp(aff_sta->affiliated_sta_bssid,
								bh_info->connected_iface_addr, ETH_ALEN) == 0) {
						continue;
					}

					assoc_cli_link = topo_srv_get_associate_client(ctx, dev->upstream_device,
							aff_sta->affiliated_sta_bssid);

					if (assoc_cli_link == NULL || assoc_cli_link->bss == NULL) {
						err(DEBUG_CAT_COSR, "non set up link is not found");
							continue;
					}
#ifdef MAP_R6
					if (!assoc_cli_link->bss->radio) {
						err(DEBUG_CAT_COSR, "bssid radio is null for bssid " MACSTR,
						MAC2STR(assoc_cli_link->bss->bssid));
						continue;
					}
#endif /* MAP_R6 */

					apcli_band = assoc_cli_link->bss->radio->band;

					if (apcli_band == band)
						return assoc_cli_link->rssi_uplink;
				}
			} else if (neighbor_info->neighbor->mld_enabled && dev->device_role == DEVICE_ROLE_AGENT) {
				for (i = 0; i < MLO_NON_SETUP_LINK_MAX; i++) {
					if (is_zero_ether_addr(bh_info->mlo_tx[i].connected_iface_addr) ||
						is_zero_ether_addr(bh_info->mlo_rx[i].connected_iface_addr))
						continue;

					assoc_cli_link = topo_srv_get_associate_client(ctx, dev->upstream_device,
											bh_info->mlo_tx[i].connected_iface_addr);

					if (assoc_cli_link == NULL || assoc_cli_link->bss == NULL) {
						err(DEBUG_CAT_COSR, "non set up link is not found");
						continue;
					}
#ifdef MAP_R6
					if (!assoc_cli_link->bss->radio) {
						err(DEBUG_CAT_COSR, "bssid radio is null for bssid " MACSTR,
						MAC2STR(assoc_cli_link->bss->bssid));
						continue;
					}
#endif /* MAP_R6 */

					apcli_band = assoc_cli_link->bss->radio->band;
					if (apcli_band == band)
						return assoc_cli_link->rssi_uplink;
				}
			}
		}
	}
	return 0;
}

void cosr_ap_trigger_air_mon(struct mapd_global *pGlobal_dev)
{
	struct own_1905_device *ctx = &pGlobal_dev->dev;
	struct _1905_map_device *dev = NULL, *tdev = NULL;
	struct _1905_map_device *airm_dev = NULL;
	struct cosr_ap_list *cosr_ap = NULL;
	struct bss_info_db *map_bss = NULL;
	//struct client *map_client = NULL;
	//struct unassoc_sta_link_metrics_query *metric_query = NULL;
	//struct unlink_metrics_query *p_unlink_query = NULL;
	unsigned char *buf = (unsigned char *)os_malloc(500);
	struct unlink_metrics_query *unlink_query = (struct unlink_metrics_query *)buf;
	int i, j;
	int band, rssi;

	if (buf == NULL) {
		err(DEBUG_CAT_COSR, "memory allocation failed!!");
		return;
	}
	ctx->air_mon_ap_cnt = 0;

	SLIST_FOREACH_SAFE(dev, &(ctx->_1905_dev_head), next_1905_device, tdev) {
		if (dev->cosr_enable == 0)
			continue;
		cosr_ap = dev->cosr_ap;
		os_memset(buf, 0, 500);
		for (j = 0; j < MAX_NUM_OF_COSR_AP; j++) {
			if (cosr_ap[j].valid == 0)
				continue;
			for (i = 0; i < MAX_NUM_OF_RADIO; i++) {
				if (cosr_ap[j].cosr_ap_pro[i].cosr_status == 0)
					continue;

				airm_dev = topo_srv_get_1905_device(ctx, cosr_ap[j].almac);
				if (airm_dev == NULL)
					continue;

				if (dev->upstream_device == airm_dev) {
					notice(DEBUG_CAT_COSR, "No need of air monitor");
					/* update RSSI from link metrics*/
					switch (i) {
					case BAND_2G_IDX:
						band = BAND_2G;
					break;
					case BAND_5G_IDX:
						band = BAND_5GL;
					break;
					case BAND_6G_IDX:
						band = BAND_6G;
					break;
					default:
						band = -1;
					}
					rssi = cosr_update_upstream_link_rssi(ctx, dev, band);
					if (rssi != 0) {
						cosr_ap[j].cosr_ap_pro[i].rcpi = rssi;
						notice(DEBUG_CAT_COSR, "updating rssi from neibhor info rssi %d", rssi);
						continue;
					}
				}

				map_bss = topo_srv_get_bss(airm_dev, (char *)cosr_ap[j].cosr_ap_pro[i].ap_mac);
				if (map_bss == NULL || map_bss->radio == NULL)
					continue;
				if (dev->device_role == DEVICE_ROLE_AGENT) {
					struct unassoc_sta_link_metrics_query *metric_query =
						os_zalloc(sizeof(struct unassoc_sta_link_metrics_query) +
									sizeof(struct unassoc_sta_link_metrics_query_sub));
					if (!metric_query) {
						err(DEBUG_CAT_COSR, CENT_STEER_PREX"can't alloc mem\n");
						os_free(buf);
						return;
					}

					metric_query->ch_num = 1;
					metric_query->op_class = map_bss->radio->operating_class;
					metric_query->unassoc_link_query_sub[0].channel = map_bss->radio->channel[0];
					metric_query->unassoc_link_query_sub[0].sta_num = 1;
					os_memcpy(&metric_query->unassoc_link_query_sub[0].sta_mac[0],
										cosr_ap[j].cosr_ap_pro[i].ap_mac, ETH_ALEN);

					notice(DEBUG_CAT_COSR,
					"Air Monitor AP Mac:"MACSTR" op class %d channel %d",
					MAC2STR(cosr_ap[j].cosr_ap_pro[i].ap_mac),
							map_bss->radio->operating_class, map_bss->radio->channel[0]);
					map_1905_Send_Unassociated_STA_Link_Metrics_Query_Message(pGlobal_dev->_1905_ctrl,
							(char *)dev->_1905_info.al_mac_addr, metric_query);
					ctx->air_mon_ap_cnt++;
					os_free(metric_query);
				} else {
					struct unlink_metrics_query *p_unlink_query = (struct unlink_metrics_query *)unlink_query;
					int query_len = 0;

					p_unlink_query->ch_num = 1;
					p_unlink_query->oper_class = map_bss->radio->operating_class;
					p_unlink_query->ch_list[0] = map_bss->radio->channel[0];
					p_unlink_query->sta_num = 1;
					os_memcpy(&p_unlink_query->sta_list[0], cosr_ap[j].cosr_ap_pro[i].ap_mac, ETH_ALEN);

					notice(DEBUG_CAT_COSR, "Air Monitor con AP Mac:"MACSTR"op class %d channel %d",
						MAC2STR(cosr_ap[j].cosr_ap_pro[i].ap_mac),
						map_bss->radio->operating_class, map_bss->radio->channel[0]);
					query_len = sizeof(struct unlink_metrics_query) + p_unlink_query->sta_num * ETH_ALEN;
					ctx->air_mon_ap_cnt++;
					map_get_info_from_wapp(&pGlobal_dev->dev,
							WAPP_USER_SET_AIR_MONITOR_REQUEST,
							0, NULL, NULL,
							(void *)p_unlink_query, query_len);
				}
			}
		}
	}
	eloop_register_timeout(5, 0, cosr_ap_airmonitor_timeout_handler, (void *)ctx, NULL);
	os_free(buf);
}

void cosr_sta_trigger_air_mon(struct mapd_global *pGlobal_dev)
{
	struct own_1905_device *ctx = &pGlobal_dev->dev;
	struct _1905_map_device *dev = NULL, *tdev = NULL;
	struct _1905_map_device *airm_dev = NULL, *airm_tdev = NULL;
	//struct cosr_station_profile **cosr_assoc_clients = NULL;
	struct bss_info_db *map_bss = NULL;
	struct client *map_client = NULL;
	struct unassoc_sta_link_metrics_query *metric_query = NULL;
	//struct unlink_metrics_query *p_unlink_query = NULL;
	unsigned char *buf = (unsigned char *)os_malloc(500);
	//struct bss_air_mon_report *air_mon_bss = os_zalloc(sizeof(struct bss_air_mon_report));
	int i, j;

	if (buf == NULL) {
		err(DEBUG_CAT_COSR, "memory allocation failed!!");
		return;
	}
	ctx->air_mon_sta_cnt = 0;

	SLIST_FOREACH_SAFE(dev, &(ctx->_1905_dev_head), next_1905_device, tdev) {
		os_memset(buf, 0, 500);
		for (i = 0; i < MAX_NUM_OF_RADIO; i++) {
			for (j = 0; j < MAX_NUM_OF_COSR_STA; j++) {
				SLIST_FOREACH_SAFE(airm_dev, &(ctx->_1905_dev_head), next_1905_device,
				airm_tdev) {
					if (dev == airm_dev)
						continue;
					if (airm_dev->cosr_sta_num[i] == 0)
						continue;
					if (airm_dev->cosr_sta_list[i][j].sta_status == 0)
						continue;
					map_client = get_client_from_sta_mac(ctx,
									airm_dev->cosr_sta_list[i][j].sta_mac);
					if (map_client == NULL) {
						err(DEBUG_CAT_COSR, "map client is null "MACSTR,
						MAC2STR(airm_dev->cosr_sta_list[i][j].sta_mac));
						continue;
					}
					map_bss = topo_srv_get_bss_by_band(ctx, dev, map_client->current_band);
					if (map_bss == NULL) {
						err(DEBUG_CAT_COSR, "map bss is null");
						continue;
					}
					cosr_create_multi_sta_air_mon_list(map_client, dev, map_bss, buf);
					map_client->cosr_air_monitor = 1;
					ctx->air_mon_sta_cnt += 1;
				}
			}

			if (dev->device_role == DEVICE_ROLE_AGENT) {
				metric_query = (struct unassoc_sta_link_metrics_query *)buf;
				if (metric_query->unassoc_link_query_sub[0].sta_num == 0) {
					notice(DEBUG_CAT_COSR, "No station for this dev!!");
					continue;
				}
				notice(DEBUG_CAT_COSR, "Air Monitor station num:%d op class %d channel %d",
				 metric_query->unassoc_link_query_sub[0].sta_num, metric_query->op_class, metric_query->ch_num);
				map_1905_Send_Unassociated_STA_Link_Metrics_Query_Message(pGlobal_dev->_1905_ctrl,
						(char *)dev->_1905_info.al_mac_addr, metric_query);
			} else {
				struct unlink_metrics_query *p_unlink_query = (struct unlink_metrics_query *)buf;

				if (p_unlink_query->sta_num == 0) {
					notice(DEBUG_CAT_COSR, "sta num is zero");
					continue;
				}
				notice(DEBUG_CAT_COSR, "Air Monitor station num:%d op class %d channel %d", p_unlink_query->sta_num,
								p_unlink_query->oper_class, p_unlink_query->ch_num);
				int query_len = 0;

				query_len = sizeof(struct unlink_metrics_query) + p_unlink_query->sta_num * ETH_ALEN;
				map_get_info_from_wapp(&pGlobal_dev->dev,
						WAPP_USER_SET_AIR_MONITOR_REQUEST,
						0, NULL, NULL,
						(void *)p_unlink_query, query_len);
			}
			os_memset(buf, 0, 500);
		}
	}
	eloop_register_timeout(5, 0, cosr_sta_airmonitor_timeout_handler, (void *)ctx, NULL);
	os_free(buf);
}

void cosr_agent_connect_handle(void *eloop_ctx, void *eloop_data)
{
	struct own_1905_device *ctx = (struct own_1905_device *)eloop_ctx;
	struct _1905_map_device *dev = NULL, *tmp_dev = NULL;
	struct _1905_map_device *dev2 = NULL, *tmp_dev2 = NULL;
	struct bss_info_db *bss = NULL, *tmp_bss = NULL;
	struct mapd_global *pGlobal_dev = (struct mapd_global *) ctx->back_ptr;
	int ap_idx, band_index;

	SLIST_FOREACH_SAFE(dev, &ctx->_1905_dev_head, next_1905_device, tmp_dev) {

		if (dev->cosr_enable != 1 || dev->in_network != 1) {
			dev->cosr_enable = 0;
			for (int i = 0; i < MAX_NUM_OF_COSR_AP; i++)
				os_memset(&dev->cosr_ap[i], 0, sizeof(struct cosr_ap_list));
			continue;
		}

		SLIST_FOREACH_SAFE(dev2, &ctx->_1905_dev_head, next_1905_device, tmp_dev2) {

			ap_idx = find_cosr_ap_list(dev, dev2->_1905_info.al_mac_addr);
			if (dev2->cosr_enable != 1 || dev2->in_network != 1) {
				if (ap_idx != -1)
					dev->cosr_ap[ap_idx].valid = 0;
				continue;
			}
		}

		SLIST_FOREACH_SAFE(dev2, &ctx->_1905_dev_head, next_1905_device, tmp_dev2) {
			ap_idx = find_cosr_ap_list(dev, dev2->_1905_info.al_mac_addr);
			if (dev2->cosr_enable != 1 || dev2->in_network != 1)
				continue;

			if (dev == dev2)
				continue;

			if (ap_idx == -1) {
				ap_idx = check_avialble_space_cosr_list(dev);
				if (ap_idx == -1) {
					notice(DEBUG_CAT_COSR, "COSR AP list is Full!!!");
					continue;
				}
			}
			os_memset(&dev->cosr_ap[ap_idx], 0, sizeof(struct cosr_ap_list));
			os_memcpy(dev->cosr_ap[ap_idx].almac, dev2->_1905_info.al_mac_addr, ETH_ALEN);
			dev->cosr_ap[ap_idx].valid = 1;
			dev->cosr_ap[ap_idx].ap_idx = ap_idx;
			SLIST_FOREACH_SAFE(bss, &dev2->first_bss, next_bss, tmp_bss) {
				if (!is_that_a_bh_nb_info(pGlobal_dev, (char *)bss->ssid)) {
					notice(DEBUG_CAT_COSR, "%s is not a bh bss "MACSTR, (char *)bss->ssid, MAC2STR(bss->bssid));
					continue;
				}

				if (bss->radio == NULL) {
					err(DEBUG_CAT_COSR, "bss radio is null!!");
					continue;
				}
				switch (bss->radio->band) {
				case BAND_2G:
					band_index = 0;
				break;
				case BAND_5GL:
					band_index = 1;
				break;
				case BAND_6G:
					band_index = 2;
				break;
				default:
					band_index = -1;
				}

				if (band_index != -1 && ap_idx >= 0) {
					os_memcpy(dev->cosr_ap[ap_idx].cosr_ap_pro[band_index].indentifier,
						bss->radio->identifier, ETH_ALEN);
					os_memcpy(dev->cosr_ap[ap_idx].cosr_ap_pro[band_index].ap_mac,
									bss->bssid, ETH_ALEN);
					dev->cosr_ap[ap_idx].cosr_ap_pro[band_index].band = bss->radio->band;
					dev->cosr_ap[ap_idx].cosr_ap_pro[band_index].cosr_status = 3;
				}
			}
		}
	}
	//topo_srv_get_cosr_ap_list(ctx, NULL, 0);
	ctx->cosr_state = COSR_AP_RSSI_LIST_UPDATE;
}

void create_cosr_station_list_per_dev(struct own_1905_device *ctx, struct _1905_map_device *dev)
{
    /*need to create station list for each band for every dev with min 8 stations for each band */
	struct associated_clients *assoc_clients, *tclient = NULL;
	//struct cosr_station_profile **cosr_sta_ls = dev->cosr_sta_list;
	int cosr_sta_index = -1, band_index = -1;

	SLIST_FOREACH_SAFE(assoc_clients, &dev->assoc_clients, next_client, tclient) {

		if (assoc_clients->bss == NULL || assoc_clients->bss->radio == NULL)
			continue;
		if (assoc_clients->is_APCLI || assoc_clients->is_apcli_link || assoc_clients->is_bh_link)
			continue;

		switch (assoc_clients->bss->radio->band) {
		case BAND_2G:
			band_index = 0;
		break;
		case BAND_5GL:
			band_index = 1;
		break;
		case BAND_6G:
			band_index = 2;
		break;
		default:
			band_index = -1;
		}

		if (band_index < 0) {
			err(DEBUG_CAT_COSR, "band_index %d invalid", band_index);
			return;
		}

		cosr_sta_index = find_station_inside_cosr_list(assoc_clients, dev, band_index);
		notice(DEBUG_CAT_COSR, "cosr_sta_index %d %d", cosr_sta_index, (s8)assoc_clients->rssi_uplink);
		if (cosr_sta_index != -1) {
			/*Already entry, Just update entry */
			dev->cosr_sta_list[band_index][cosr_sta_index].sta_rcpi =
							rssi_to_rcpi((s8)assoc_clients->rssi_uplink);
			continue;
		}

		/* Check station list have space, otherwise do rssi comparisons*/
		if (check_station_list_empty(assoc_clients, dev, band_index)) {
			add_entry_into_sta_list(dev, assoc_clients, band_index);
			topo_srv_get_cosr_sta_list(ctx, NULL, 0);
		} else
			cosr_do_rssi_comparison(dev, assoc_clients, band_index);
		topo_srv_get_cosr_sta_list(ctx, NULL, 0);
	}

	cosr_update_sta_list(ctx, dev);
}

void create_cosr_station_list(struct own_1905_device *ctx)
{
	struct _1905_map_device *dev = NULL, *tmp_dev = NULL;

	SLIST_FOREACH_SAFE(dev, &ctx->_1905_dev_head, next_1905_device, tmp_dev) {
		if (!dev->in_network || !dev->cosr_enable)
			continue;
		create_cosr_station_list_per_dev(ctx, dev);
	}
}

void update_pathloss_per_dev(struct _1905_map_device *dev, struct client *map_client,
								int i, int j, int ap_idx, s8 rssi)
{
	int pathloss, sta_rssi;

	if ((i < 0 || i >= MAX_NUM_OF_RADIO) || (j < 0 || j >= MAX_NUM_OF_COSR_STA)) {
		err(DEBUG_CAT_COSR, "radius for index is %d and sta_index is %d thus no pathloss updated\n", i, j);
		return;
	}
	sta_rssi = rcpi_to_rssi(dev->cosr_sta_list[i][j].sta_rcpi);
	pathloss = sta_rssi - rssi;


	if (rssi == -110) {
		if (map_client->phy_capab.phy_mode[0] == EHT_MODE)
			pathloss = 38;
		else
			pathloss = 32;
	}

	switch (ap_idx) {
	case 0:
		if (dev->cosr_sta_list[i][j].pathlossA1 == -110)
			dev->cosr_sta_list[i][j].pathlossA1 = pathloss;
		else
			dev->cosr_sta_list[i][j].pathlossA1 = ((3 * dev->cosr_sta_list[i][j].pathlossA1) / 4) +
													(pathloss / 4);
		break;
	case 1:
		if (dev->cosr_sta_list[i][j].pathlossA2 == -110)
			dev->cosr_sta_list[i][j].pathlossA2 = pathloss;
		else
			dev->cosr_sta_list[i][j].pathlossA2 = (3 * dev->cosr_sta_list[i][j].pathlossA2) / 4 +
													(pathloss / 4);
		break;
	case 2:
		if (dev->cosr_sta_list[i][j].pathlossA3 == -110)
			dev->cosr_sta_list[i][j].pathlossA3 = pathloss;
		else
			dev->cosr_sta_list[i][j].pathlossA3 = (3 * dev->cosr_sta_list[i][j].pathlossA3) / 4 +
													(pathloss / 4);
		break;
	default:
		notice(DEBUG_CAT_COSR, "AP %d is not present Now", ap_idx);
	}
}

void calculate_cosr_path_loss(struct own_1905_device *ctx)
{
	struct _1905_map_device *dev = NULL, *tmp_dev = NULL;
	struct client *map_client = NULL;
	struct bss_air_mon_report *air_mon_report = NULL, *tmp_air_mon_report = NULL;
	int i, j, ap_idx;

	SLIST_FOREACH_SAFE(dev, &ctx->_1905_dev_head, next_1905_device, tmp_dev) {
		if (!dev->in_network || !dev->cosr_enable)
			continue;

		for (i = 0; i < MAX_NUM_OF_RADIO; i++) {
			if (dev->cosr_sta_num[i] == 0)
				continue;
			for (j = 0; j < MAX_NUM_OF_COSR_STA; j++) {
				if (dev->cosr_sta_list[i][j].sta_status == 0)
					continue;

				map_client = get_client_from_sta_mac(ctx,
									dev->cosr_sta_list[i][j].sta_mac);
				if (map_client == NULL)
					continue;
				map_client->cosr_air_monitor = 0;
				if (!SLIST_EMPTY(&(map_client->meas_data.air_mon_bss_head))) {
					SLIST_FOREACH_SAFE(air_mon_report, &(map_client->meas_data.air_mon_bss_head),
										air_mon_bss_entry, tmp_air_mon_report) {

						ap_idx = find_cosr_ap_list(dev, air_mon_report->al_mac);

						notice(DEBUG_CAT_COSR, "ap idx %d almac "MACSTR, ap_idx, MAC2STR(air_mon_report->al_mac));

						update_pathloss_per_dev(dev, map_client, i, j, ap_idx, air_mon_report->rssi);
					}
					SLIST_FOREACH_SAFE(air_mon_report, &(map_client->meas_data.air_mon_bss_head),
								air_mon_bss_entry, tmp_air_mon_report) {
						SLIST_REMOVE(&(map_client->meas_data.air_mon_bss_head), air_mon_report,
									bss_air_mon_report, air_mon_bss_entry);
						if (air_mon_report)
							os_free(air_mon_report);
						if (SLIST_EMPTY(&(map_client->meas_data.air_mon_bss_head)))
							break;
					}
				}
			}
		}
	}
}

void cosr_fill_ap_air_mon_results(struct own_1905_device *ctx,
					struct _1905_map_device *device,
					u8 *al_mac, struct unassoc_sta_1905_link_metric *metrics)
{
	int ap_idx = 0, i = 0;

	ap_idx = find_cosr_ap_list(device, al_mac);

	notice(DEBUG_CAT_COSR, "air monitor results RSSI %d mac "MACSTR" almac "MACSTR,
							metrics->rssi, MAC2STR(metrics->cli_mac), MAC2STR(al_mac));
	notice(DEBUG_CAT_COSR, "air monitor results ap_idx %d mac "MACSTR, ap_idx, MAC2STR(device->_1905_info.al_mac_addr));

	if (ap_idx < 0 || ap_idx >= MAX_NUM_OF_COSR_AP)
		return;

	for (i = 0; i < MAX_NUM_OF_RADIO; i++) {
		if (os_memcmp(device->cosr_ap[ap_idx].cosr_ap_pro[i].ap_mac, metrics->cli_mac, ETH_ALEN) == 0) {
			if (device->device_role == DEVICE_ROLE_CONTROLLER)
				device->cosr_ap[ap_idx].cosr_ap_pro[i].rcpi = metrics->rssi;
			else
				device->cosr_ap[ap_idx].cosr_ap_pro[i].rcpi = rcpi_to_rssi(metrics->rssi);
			ctx->airmon_ap_complete_cnt++;

			if (ctx->air_mon_ap_cnt == ctx->airmon_ap_complete_cnt) {
				cosr_ap_airmonitor_timeout_handler((void *)ctx, NULL);
				if (eloop_is_timeout_registered(cosr_ap_airmonitor_timeout_handler, ctx, NULL))
					eloop_cancel_timeout(cosr_ap_airmonitor_timeout_handler, ctx, NULL);
			}
		}
	}
}

void cosr_update_station_list_to_dev(struct own_1905_device *ctx)
{
	struct mapd_global *global = (struct mapd_global *)ctx->back_ptr;
	struct _1905_map_device *dev = NULL, *tmp_dev = NULL;
	struct cosr_sta_tlv *sta_list_tlv = NULL;
	struct cosr_sta_list *cosr_info;
	struct radio_info_db *radio = NULL;
	int i, band, send_len;
	char *buf = NULL;

	buf = (char *)os_zalloc(sizeof(struct cosr_sta_tlv)
						+ sizeof(struct cosr_sta_list) * MAX_NUM_OF_RADIO);
	if (!buf) {
		err(DEBUG_CAT_COSR, "alloc memory fail");
		return;
	}

	sta_list_tlv = (struct cosr_sta_tlv *)buf;

	SLIST_FOREACH_SAFE(dev, &ctx->_1905_dev_head, next_1905_device, tmp_dev) {

		os_memset(sta_list_tlv, 0, sizeof(struct cosr_sta_tlv)
						+ sizeof(struct cosr_sta_list) * MAX_NUM_OF_RADIO);

		sta_list_tlv->tlv.tlv_type = TLV_802_11_VENDOR_SPECIFIC;
		os_memcpy(sta_list_tlv->tlv.oui, MTK_OUI, OUI_LEN);
		sta_list_tlv->tlv.func_type = FUNC_VENDOR_MAP_COSR_STALIST;

		for (i = 0; i < MAX_NUM_OF_RADIO; i++) {

			switch (i) {
			case BAND_2G_IDX:
				band = BAND_2G;
			break;
			case BAND_5G_IDX:
				band = BAND_5GL;
			break;
			case BAND_6G_IDX:
				band = BAND_6G;
			break;
			default:
				band = -1;
			}
			if (band == -1)
				continue;
			radio = topo_srv_get_radio_by_band_type(dev, band);
			if (radio == NULL)
				continue;

			sta_list_tlv->radio_num++;

			notice(DEBUG_CAT_COSR, "sta_list_tlv->radio_num %d", sta_list_tlv->radio_num);

			os_memcpy(sta_list_tlv->cosr_sta[i].identifier, radio->identifier, ETH_ALEN);
			os_memcpy(sta_list_tlv->cosr_sta[i].station_list, dev->cosr_sta_list[i],
				MAX_NUM_OF_COSR_STA * sizeof(struct cosr_station_profile));
		}

		send_len = sizeof(struct cosr_sta_tlv)
						+ sizeof(struct cosr_sta_list) * sta_list_tlv->radio_num;
		sta_list_tlv->tlv.tlv_len = host_to_be16(send_len - TLV_TYPE_SIZE - TLV_LEN_SIZE);

		notice(DEBUG_CAT_COSR, "dev almac "MACSTR, MAC2STR(dev->_1905_info.al_mac_addr));

		for (int k = 0; k < sta_list_tlv->radio_num; k++) {
			notice(DEBUG_CAT_COSR, "COSR Radio List for dev from ("MACSTR") -\n", MAC2STR(sta_list_tlv->cosr_sta[k].identifier));
			for (int l = 0; l < MAX_NUM_OF_COSR_STA; l++) {
				info(DEBUG_CAT_COSR, "\tCOSR sta mac - "MACSTR,
				 MAC2STR(sta_list_tlv->cosr_sta[k].station_list[l].sta_mac));
				info(DEBUG_CAT_COSR, "\tCOSR rcpi - %d", sta_list_tlv->cosr_sta[k].station_list[l].sta_rcpi);
				info(DEBUG_CAT_COSR, "\tCOSR Status - %d", sta_list_tlv->cosr_sta[k].station_list[l].sta_status);
				info(DEBUG_CAT_COSR, "\tCOSR pathloss - A1: %d, A2: %d, A3 %d",
					sta_list_tlv->cosr_sta[k].station_list[l].pathlossA1,
					sta_list_tlv->cosr_sta[k].station_list[l].pathlossA2,
					sta_list_tlv->cosr_sta[k].station_list[l].pathlossA3);
			}
		}

		if (dev->device_role == DEVICE_ROLE_CONTROLLER) {
			for (i = 0; i < sta_list_tlv->radio_num; i++) {
				cosr_info = &sta_list_tlv->cosr_sta[i];
				wlanif_issue_wapp_command(global, WAPP_SEND_COSR_STA_LIST, 0,
					cosr_info->identifier, NULL, (void *)cosr_info, sizeof(struct cosr_sta_list), 0, 0, 0);
			}
		} else
			map_1905_Send_Vendor_Specific_Message(
				global->_1905_ctrl,
				(char *)dev->_1905_info.al_mac_addr,
				(char *)sta_list_tlv,
				send_len);
	}
	os_free(buf);
}

void cosr_update_ap_list_to_dev(struct own_1905_device *ctx)
{
	struct mapd_global *global = (struct mapd_global *)ctx->back_ptr;
	struct _1905_map_device *dev = NULL, *tmp_dev = NULL;
	struct cosr_ap_tlv *ap_tlv = NULL;
	struct radio_info_db *radio = NULL;
	int i, j, band, send_len, ap_idx;
	struct cosr_apinfo_data *cosr_ap_info;
	char *buf = NULL;

	buf = (char *)os_zalloc(sizeof(struct cosr_ap_tlv)
						+ sizeof(struct cosr_apinfo_data) * MAX_NUM_OF_RADIO);

	if (!buf) {
		err(DEBUG_CAT_COSR, "alloc memory fail");
		return;
	}

	ap_tlv = (struct cosr_ap_tlv *)buf;

	SLIST_FOREACH_SAFE(dev, &ctx->_1905_dev_head, next_1905_device, tmp_dev) {

		os_memset(ap_tlv, 0, sizeof(struct cosr_ap_tlv)
						+ sizeof(struct cosr_apinfo_data) * MAX_NUM_OF_RADIO);

		ap_tlv->tlv.tlv_type = TLV_802_11_VENDOR_SPECIFIC;
		os_memcpy(ap_tlv->tlv.oui, MTK_OUI, OUI_LEN);
		ap_tlv->tlv.func_type = FUNC_VENDOR_MAP_COSR_APLIST;

		for (i = 0; i < MAX_NUM_OF_COSR_AP; i++) {
			if (dev->cosr_ap[i].valid == 0)
				continue;
			for (j = 0; j < MAX_NUM_OF_RADIO; j++) {
				switch (j) {
				case BAND_2G_IDX:
					band = BAND_2G;
				break;
				case BAND_5G_IDX:
					band = BAND_5GL;
				break;
				case BAND_6G_IDX:
					band = BAND_6G;
				break;
				default:
					band = -1;
				}
				if (band == -1)
					continue;
				radio = topo_srv_get_radio_by_band_type(dev, band);
				if (radio == NULL)
					continue;
				ap_idx = dev->cosr_ap[i].ap_idx;
				if (ap_idx >= MAX_NUM_OF_COSR_AP || ap_idx < 0) {
					err(DEBUG_CAT_COSR, "index of ap [%d] is wrong", ap_idx);
					break;
				}
				os_memcpy(ap_tlv->apinfo_data[j].identifier, radio->identifier, ETH_ALEN);
				os_memcpy(&ap_tlv->apinfo_data[j].ap_list[ap_idx],
							&dev->cosr_ap[i].cosr_ap_pro[j], sizeof(struct cosr_ap_profile));
			}
		}
		if (check_is_triband(dev))
			ap_tlv->radio_num = 3;
		else
			ap_tlv->radio_num = 2;
		send_len = sizeof(struct cosr_ap_tlv)
						+ sizeof(struct cosr_apinfo_data) * ap_tlv->radio_num;
		ap_tlv->tlv.tlv_len = host_to_be16(send_len - TLV_TYPE_SIZE - TLV_LEN_SIZE);


		notice(DEBUG_CAT_COSR, "dev almac "MACSTR, MAC2STR(dev->_1905_info.al_mac_addr));

		for (int k = 0; k < ap_tlv->radio_num; k++) {
			notice(DEBUG_CAT_COSR, "COSR Radio List for dev from ("MACSTR") -\n",
			 MAC2STR(ap_tlv->apinfo_data[k].identifier));
			for (int l = 0; l < MAX_NUM_OF_COSR_AP; l++) {
				info(DEBUG_CAT_COSR, "\tCOSR ap mac - "MACSTR, MAC2STR(ap_tlv->apinfo_data[k].ap_list[l].ap_mac));
				info(DEBUG_CAT_COSR, "\tCOSR band - %d", ap_tlv->apinfo_data[k].ap_list[l].band);
				info(DEBUG_CAT_COSR, "\tCOSR Status - %d", ap_tlv->apinfo_data[k].ap_list[l].cosr_status);
				info(DEBUG_CAT_COSR, "\tCOSR rcpi - %d", ap_tlv->apinfo_data[k].ap_list[l].rcpi);
			}
		}

		if (dev->device_role == DEVICE_ROLE_CONTROLLER) {
			for (i = 0; i < ap_tlv->radio_num; i++) {
				cosr_ap_info = &ap_tlv->apinfo_data[i];
				wlanif_issue_wapp_command(global, WAPP_SEND_COSR_AP_LIST, 0,
					cosr_ap_info->identifier, NULL, (void *)cosr_ap_info, sizeof(struct cosr_apinfo_data), 0, 0, 0);
			}
		} else
			map_1905_Send_Vendor_Specific_Message(
				global->_1905_ctrl,
				(char *)dev->_1905_info.al_mac_addr,
				(char *)ap_tlv,
				send_len);
	}
	os_free(buf);
}

void handle_cosr_stalist(struct mapd_global *pGlobal_dev,
	struct cosr_sta_tlv *msg)
{
	int i = 0;
	struct cosr_sta_list *cosr_info;

	for (i = 0; i < msg->radio_num; i++) {
		cosr_info = &msg->cosr_sta[i];
		wlanif_issue_wapp_command(pGlobal_dev, WAPP_SEND_COSR_STA_LIST, 0,
			cosr_info->identifier, NULL, (void *)cosr_info, sizeof(struct cosr_sta_list), 0, 0, 0);
	}
}

void handle_cosr_aplist(struct mapd_global *pGlobal_dev,
	struct cosr_ap_tlv *msg)
{
	int i = 0;
	struct cosr_apinfo_data *cosr_ap_info;

	for (i = 0; i < msg->radio_num; i++) {
		cosr_ap_info = &msg->apinfo_data[i];
		wlanif_issue_wapp_command(pGlobal_dev, WAPP_SEND_COSR_AP_LIST, 0,
			cosr_ap_info->identifier, NULL, (void *)cosr_ap_info, sizeof(struct cosr_apinfo_data), 0, 0, 0);
	}
}

char *print_cosr_state(int state)
{
	switch (state) {
	case COSR_DISABLE:
		return "COSR_DISABLE STATE";
	case COSR_INIT:
		return "COSR_INIT STATE";
	case COSR_CONN_DISCONN_CHG:
		return "COSR_CONN_DISCONN_CHG STATE";
	case COSR_AP_RSSI_LIST_UPDATE:
		return "COSR_AP_RSSI_LIST_UPDATE STATE";
	case COSR_STA_LIST_PREP:
		return "COSR_STA_LIST_PREP STATE";
	case COSR_PATH_LOSS_CALCULATION:
		return "COSR_PATH_LOSS_CALCULATION STATE";
	case COSR_PATH_LOSS_COMPLETE:
		return "COSR_PATH_LOSS_COMPLETE STATE";
	case COSR_COMPLETE:
		return "COSR_COMPLETE STATE";

	default:
		return "!!Wrong State of COSR!!";

	}

}

void handle_cosr_mode(struct mapd_global *pGlobal_dev,
	struct cosr_mode_tlv *msg,
	struct _1905_map_device *device)
{
	device->cosr_enable = msg->mode & 0x08 ? 1:0;
	notice(DEBUG_CAT_COSR, "device->_1905_cosr_mode = 0x%2X msg->mode %d %d\n "MACSTR,
	device->cosr_enable, msg->mode, msg->mode, MAC2STR(device->_1905_info.al_mac_addr));
}

void topo_srv_get_cosr_mode(struct own_1905_device *ctx)
{
	map_get_info_from_wapp(ctx, WAPP_USER_GET_COSR_MODE_QRY, 0, NULL, NULL, NULL, 0);
}

void topo_srv_parse_wapp_cosr_mode_result(struct own_1905_device *ctx)
{
	struct _1905_map_device *dev = NULL;

	dev = topo_srv_get_1905_device(ctx, NULL);
	dev->_1905_cosr_mode = ctx->cosr_mode;
	dev->cosr_enable = ctx->cosr_mode & 0x08 ? 1:0;
	notice(DEBUG_CAT_COSR, "mapd- msg->mode %2X dev->cosr_enable %d",
		ctx->cosr_mode, dev->cosr_enable);
	ctx->cosr_state = COSR_CONN_DISCONN_CHG;
}

void cosr_init(struct own_1905_device *ctx)
{
	ctx->cosr_state = COSR_INIT;
}

void cosr_execute(struct mapd_global *global)
{
	struct own_1905_device *ctx = (struct own_1905_device *)&global->dev;

	if (is_chplan_netopt_ongoing(global)) {
		notice(DEBUG_CAT_COSR, "Wait for channl planning or netopt to run COSR!!");
		return;
	}

	notice(DEBUG_CAT_COSR, "COSR State %d %s", ctx->cosr_prev_state, print_cosr_state(ctx->cosr_prev_state));

	ctx->cosr_prev_state = ctx->cosr_state;

	if (ctx->cosr_state != COSR_COMPLETE)
		if (eloop_is_timeout_registered(cosr_complete_timeout_handler, ctx, NULL))
			eloop_cancel_timeout(cosr_complete_timeout_handler, ctx, NULL);

	switch (ctx->cosr_state) {
	case COSR_DISABLE:
		info(DEBUG_CAT_COSR, "COSR is Disable");
		notice(DEBUG_CAT_COSR, "COSR State %d %s", ctx->cosr_state, print_cosr_state(ctx->cosr_state));
		cosr_init(ctx);
		break;
	case COSR_INIT:
		notice(DEBUG_CAT_COSR, "COSR State %d %s", ctx->cosr_state, print_cosr_state(ctx->cosr_state));
		topo_srv_get_cosr_mode(ctx);
		break;
	case COSR_CONN_DISCONN_CHG:
		notice(DEBUG_CAT_COSR, "COSR State %d %s", ctx->cosr_state, print_cosr_state(ctx->cosr_state));
		ctx->cosr_ap_list_update = 0;
		if (eloop_is_timeout_registered(cosr_agent_connect_handle, ctx, NULL))
			eloop_cancel_timeout(cosr_agent_connect_handle, ctx, NULL);
		eloop_register_timeout(10, 0, cosr_agent_connect_handle, (void *)ctx, NULL);
		break;
	case COSR_AP_RSSI_LIST_UPDATE:
		notice(DEBUG_CAT_COSR, "COSR State %d %s", ctx->cosr_state, print_cosr_state(ctx->cosr_state));
		if (eloop_is_timeout_registered(cosr_ap_airmonitor_timeout_handler, ctx, NULL))
			eloop_cancel_timeout(cosr_ap_airmonitor_timeout_handler, ctx, NULL);
		cosr_ap_trigger_air_mon((struct mapd_global *)ctx->back_ptr);
		break;
	case COSR_STA_LIST_PREP:
		notice(DEBUG_CAT_COSR, "COSR State %d %s", ctx->cosr_state, print_cosr_state(ctx->cosr_state));
		cosr_update_ap_list_to_dev(ctx);
		create_cosr_station_list(ctx);
		cosr_sta_trigger_air_mon((struct mapd_global *)ctx->back_ptr);
		break;
	case COSR_PATH_LOSS_CALCULATION:
		notice(DEBUG_CAT_COSR, "COSR State %d %s", ctx->cosr_state, print_cosr_state(ctx->cosr_state));
		if (eloop_is_timeout_registered(cosr_sta_airmonitor_timeout_handler, ctx, NULL))
			eloop_cancel_timeout(cosr_sta_airmonitor_timeout_handler, ctx, NULL);
		calculate_cosr_path_loss(ctx);
		ctx->cosr_state = COSR_PATH_LOSS_COMPLETE;
		break;
	case COSR_PATH_LOSS_COMPLETE:
		notice(DEBUG_CAT_COSR, "COSR State %d %s", ctx->cosr_state, print_cosr_state(ctx->cosr_state));
		cosr_update_station_list_to_dev(ctx);
		ctx->cosr_state = COSR_COMPLETE;
		break;
	case COSR_COMPLETE:
		notice(DEBUG_CAT_COSR, "COSR State %d %s", ctx->cosr_state, print_cosr_state(ctx->cosr_state));
		if (eloop_is_timeout_registered(cosr_complete_timeout_handler, ctx, NULL))
			eloop_cancel_timeout(cosr_complete_timeout_handler, ctx, NULL);
		eloop_register_timeout(60, 0, cosr_complete_timeout_handler, (void *) ctx, NULL);
		break;

	default:
		err(DEBUG_CAT_COSR, "!!Wrong State of COSR!!");

	}
}
#endif /* MAP_6E_SUPPORT and MAP_R6 */


