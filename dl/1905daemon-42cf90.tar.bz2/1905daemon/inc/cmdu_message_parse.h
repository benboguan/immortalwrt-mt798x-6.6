/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#ifndef CMDU_MESSAGE_PARSE_H
#define CMDU_MESSAGE_PARSE_H

#include "p1905_managerd.h"

int parse_topology_discovery_message(struct p1905_managerd_ctx *ctx,
				     unsigned char *buf, unsigned int left_tlv_len,
				     unsigned char *query, unsigned char *notify,
				     unsigned char *discovery, unsigned char *al_mac, unsigned char *mac_addr,
				     unsigned char *smac);
int parse_topology_notification_message(struct p1905_managerd_ctx *ctx,
					unsigned char *buf, unsigned int left_tlv_len,
					unsigned char *al_mac, unsigned char *bssid,
					unsigned char *mac, unsigned char *event, unsigned char *neth_almac);
int parse_topology_response_message(struct p1905_managerd_ctx *ctx, unsigned char *buf,
	unsigned int left_tlv_len,
	unsigned char *almac, unsigned char *profile);
unsigned char is_internal_used_vendor_specific(unsigned char *vs_info);
int parse_vendor_specific_message(struct p1905_managerd_ctx *ctx, unsigned char *buf, unsigned int left_tlv_len,
				  struct p1905_vs_info *vs_info, unsigned char *internal_vendor_message);
int parse_1905_internal_vendor_specific_message(struct p1905_managerd_ctx *ctx, unsigned char *buf,
		unsigned int left_tlv_len, unsigned char *almac);
int parse_link_metric_query_message(struct p1905_managerd_ctx *ctx, unsigned char *buf, unsigned int left_tlv_len);
int parse_ap_autoconfig_search_message(struct p1905_managerd_ctx *ctx,
				       unsigned char *buf, unsigned int left_tlv_len, unsigned char *al_mac,
				       unsigned char *profile);
int parse_ap_autoconfig_response_message(struct p1905_managerd_ctx *ctx,
					unsigned char *buf, unsigned int left_tlv_len,
					unsigned char *band, unsigned char *service,
					unsigned char *service_cnt,
					unsigned char *role_register, unsigned char *al_mac, unsigned char *profile,
					struct controller_capability *contr_cap);
int parse_ap_autoconfig_renew_message(struct p1905_managerd_ctx *ctx,
				      unsigned char *buf, unsigned int left_tlv_len,
				      unsigned char *al_mac, unsigned char *band);
int parse_ap_autoconfig_wsc_message(struct p1905_managerd_ctx *ctx,
				    unsigned char *almac, unsigned char *buf, unsigned int left_tlv_len,
				    struct agent_radio_info *r, unsigned char *radio_cnt,
				    unsigned char *radio_identifier);
int parse_link_metrics_response_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len);
/*MAP spec defined*/
int parse_1905_ack_message(struct p1905_managerd_ctx *ctx, unsigned char *buf, unsigned int left_tlv_len);
int parse_client_capability_query_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len);
int parse_channel_selection_request_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len);
int parse_map_policy_config_request_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len);
int parse_client_steering_request_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len, struct err_sta_db *err_sta);
int parse_cli_assoc_control_request_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len);
int parse_ap_metrics_query_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len,
	unsigned char *radio_identifier);
int parse_associated_sta_link_metrics_query_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len);
int parse_associated_sta_link_metrics_rsp_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len);
int parse_unassociated_sta_link_metrics_query_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf,
	unsigned int left_tlv_len);
int parse_backhaul_steering_request_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len);
int parse_backhaul_steering_rsp_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len);
int parse_ap_metrics_response_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len);
int parse_combined_infra_metrics_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len);
int parse_ap_capability_report_message(struct p1905_managerd_ctx *ctx,
	unsigned char *almac, unsigned char *buf, unsigned int left_tlv_len);
int parse_channel_selection_rsp_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len);
int parse_operating_channel_report_message(struct p1905_managerd_ctx *ctx,
		unsigned char *buf, unsigned int left_tlv_len);
int parse_client_capability_report_message(struct p1905_managerd_ctx *ctx,
		unsigned char *buf, unsigned int left_tlv_len);
int parse_unassoc_sta_link_metrics_response_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len);
int parse_beacon_metrics_response_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len);
int parse_client_steering_btm_report_message(struct p1905_managerd_ctx *ctx,
		unsigned char *buf, unsigned int left_tlv_len);
int parse_higher_layer_data_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len);
int parse_channel_scan_request_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len);
int parse_channel_scan_report_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len);
int parse_tunneled_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len, unsigned char *msg_type);
int parse_assoc_status_notification_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len);
int parse_cac_request_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len);
int parse_cac_terminate_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len);
int parse_client_disassciation_stats_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len);
int parse_backhaul_sta_cap_report_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len);
int parse_failed_connection_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len);
int parse_channel_preference_report_message(struct p1905_managerd_ctx *ctx,
	struct agent_list_db *agent, unsigned char *buf, unsigned int left_tlv_len);
/*MAP dpp protocol defined message parsing*/
int parse_proxied_encap_dpp_message(
	struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len,
	unsigned char *al_mac,
	unsigned char *frame_type,
	unsigned short *frame_offset,
	unsigned short *frame_len);
int parse_1905_encap_eapol_message(
	struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len,
	unsigned short *eapol_offset, unsigned short *eapol_len);
int parse_dpp_bootstraping_uri_notification_message(
	struct p1905_managerd_ctx *ctx,
	unsigned char *buf,
	unsigned int left_tlv_len);
int parse_dpp_cce_indication_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len);
int parse_direct_encap_dpp_message_tlv(
	struct p1905_managerd_ctx *ctx, unsigned char *buf, unsigned short len,
	unsigned char *frame_type, unsigned short *frame_offset, unsigned short *frame_len,
	unsigned char *al_mac);
int parse_direct_encap_dpp_message(
	struct p1905_managerd_ctx *ctx, unsigned char *buf, unsigned int left_tlv_len,
	unsigned char *frame_type, unsigned short *frame_offset, unsigned short *frame_len,
	unsigned char *al_mac);
int parse_1905_rekey_request_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len);
int parse_1905_decryption_failure_message(struct p1905_managerd_ctx *ctx,
			unsigned char *buf, unsigned int left_tlv_len, unsigned char *al_mac);
int parse_chirp_notification_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len, unsigned char *al_mac);
int parse_dpp_bootstrapping_uri_query_message(struct p1905_managerd_ctx *ctx, unsigned char *buf,
	unsigned char *al_mac);
int parse_1905_bss_configuration_request_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len, unsigned char *al_mac);
int parse_bss_configuration_response_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len, unsigned char *al_mac);
int parse_agent_list_message(unsigned char *buf, unsigned int left_tlv_len);
int parse_beacon_metrics_query_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len);
int parse_cmdu_message(struct p1905_managerd_ctx *ctx, unsigned char *buf,
		       unsigned char *dmac, unsigned char *smac, int len);

#ifdef MAP_R3
int cmdu_r3_handle(struct p1905_managerd_ctx *ctx,
	unsigned char *dmac, unsigned char *smac,
	unsigned char *cmdu_hdr, unsigned short *cmdu_len, unsigned short mtype,
	unsigned char *vsinfo, unsigned short *vsinfo_len,
	unsigned char *tlv_buf, int tlv_total_len,
	unsigned char *restore_flag, unsigned char *mid_check);
#endif

#ifdef EM_PLUS_SUPPORT
int update_vlan_tag_inf(struct p1905_managerd_ctx *ctx, unsigned char *ifname, int add);
#endif

#endif /* CMDU_MESSAGEPARSE_H */
