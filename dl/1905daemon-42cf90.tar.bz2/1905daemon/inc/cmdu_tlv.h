/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#ifndef CMDU_TLV_H
#define CMDU_TLV_H

#include "p1905_managerd.h"

/*CMDU tlv type value*/
#define END_OF_TLV_TYPE 0
#define AL_MAC_ADDR_TLV_TYPE 1
#define MAC_ADDR_TLV_TYPE 2
#define DEVICE_INFO_TLV_TYPE 3
#define BRIDGE_CAPABILITY_TLV_TYPE 4
#define NON_P1905_NEIGHBOR_DEV_TLV_TYPE 6
#define P1905_NEIGHBOR_DEV_TLV_TYPE 7
#define LINK_METRICS_QUERY_TLV_TYPE 8
#define TRANSMITTER_LINK_METRIC_TYPE 9
#define RECEIVER_LINK_METRIC_TYPE 10
#define VENDOR_SPECIFIC_TLV_TYPE 11
#define RESULT_CODE_TLV_TYPE 12
#define SEARCH_ROLE_TLV_TYPE 13
#define AUTO_CONFIG_FREQ_BAND_TLV_TYPE 14
#define SUPPORT_ROLE_TLV_TYPE 15
#define SUPPORT_FREQ_BAND_TLV_TYPE 16
#define WSC_TLV_TYPE 17
#define PUSH_BUTTON_EVENT_NOTIFICATION_TYPE 18
#define PUSH_BUTTON_JOIN_NOTIFICATION_TYPE 19
#define CONTROLLER_CAPABILITY_TYPE 0XDD

/*vendor tlv functype*/
#define BSS_MLD_REPORT_TYPE 0x01
#define MLO_CAP_ANNOUNCE_TYPE 0x02
#define MLO_CAPABILITY_TYPE 0x03
#ifdef BR_IP_TLV_SUPPORT
#define BR_IP_TYPE 0x05
#endif

/*CMDU tlv length(fixed part)*/
#define END_OF_TLV_LENGTH 0
#define AL_MAC_ADDR_TLV_LENGTH 6
#define MAC_ADDR_TLV_LENGTH 6
#define LINK_METRIC_RESULT_CODE_LENGTH 1
#define PUSH_BUTTON_JOIN_NOTIFICATION_LENGTH 20
#define BACKHAUL_STEERING_RESPONSE_LENGTH 13

#define SEARCH_ROLE_LENGTH 1
#define AUTOCONFIG_FREQ_BAND_LENGTH 1
#define SUPPORTED_ROLE_LENGTH 1
#define SUPPORTED_FREQ_BAND_LENGTH 1

/*link metrics query target*/
#define QUERY_ALL_NEIGHBOR 0
#define QUERY_SPECIFIC_NEIGHBOR 1

/*link metrics query type*/
#define TX_METRICS_ONLY 0
#define RX_METRICS_ONLY 1
#define BOTH_TX_AND_RX_METRICS 2



/*for searched role tlv and support role tlv use*/
#define ROLE_REGISTRAR 0x00

/*for auto freq band tlv and supported freq band tlv use*/
#define IEEE802_11_band_2P4G 0x00
#define IEEE802_11_band_5G   0x01
#define IEEE802_11_band_60G  0x02
#define IEEE802_11_band_6G	 0x03
typedef enum
{
    ieee_802_3_u = IEEE802_3_GROUP,
    ieee_802_3_ab,

    ieee_802_11_b = IEEE802_11_GROUP,
    ieee_802_11_g,
    ieee_802_11_a,
    ieee_802_11_n_2_4G,
    ieee_802_11_n_5G,
    ieee_802_11_ac,
    ieee_802_11_ad,
    ieee_802_11_af,

    ieee_1901_wavelet = IEEE1901_GROUP,
    ieee_1901_FFT,

    moca_v1_1 = MOCA_GROUP,
}itftype;

#ifdef MAP_R2
struct GNU_PACKED ap_radio_advan_cap {
	unsigned char radioid[6];
	unsigned char flag;
};
#endif

#ifdef BR_IP_TLV_SUPPORT
struct GNU_PACKED br_info {
	unsigned char br_name[IFNAMSIZ];
	char br_addr[ETH_ALEN];
	unsigned int br_ip;
};
unsigned short append_br_ip_vendor_tlv(unsigned char *pkt, struct p1905_managerd_ctx *ctx);
#endif /* BR_IP_TLV_SUPPORT */

unsigned short append_1905_al_mac_addr_type_tlv(unsigned char *pkt, unsigned char *al_mac);
unsigned short append_mac_addr_type_tlv(unsigned char *pkt,
    unsigned char *itf_mac);
unsigned short append_device_info_type_tlv(unsigned char *pkt,
    unsigned char *al_mac,struct p1905_managerd_ctx *ctx);
unsigned short append_device_bridge_capability_type_tlv(unsigned char *pkt,
    struct bridge_capabiltiy *br_cap_list);
unsigned short append_p1905_neighbor_device_type_tlv(unsigned char *pkt,
    struct p1905_neighbor *devlist, int num, unsigned char *seperate);
#ifdef EM_PLUS_EXT_SUPPORT
unsigned short append_gw_agent_p1905_neighbor_device_type_tlv(unsigned char *pkt,
	struct topology_discovery_db *atpg_db, int num, unsigned char *separate);
#endif
unsigned short append_non_p1905_neighbor_device_type_tlv(unsigned char *pkt,
    struct non_p1905_neighbor *devlist, int num, unsigned char *seperate);
unsigned short append_end_of_tlv(unsigned char *pkt);
unsigned short append_vendor_specific_type_tlv(unsigned char *pkt,
	struct p1905_vs_info *vs_info);
unsigned short append_link_metrics_query_type_tlv(unsigned char *pkt,
	unsigned char *target_al_mac, unsigned char type);
unsigned short append_link_metrics_result_code_tlv(unsigned char *pkt);
unsigned short append_push_button_event_notification_tlv(unsigned char *pkt,
                    struct p1905_interface *itf_list);
unsigned short append_push_button_join_notification_tlv(unsigned char *pkt,
                unsigned char *al_id, unsigned short mid,
                unsigned char *local_mac, unsigned char *new_device_mac);
unsigned short append_searched_role_tlv(unsigned char *pkt);
unsigned short append_autoconfig_freq_band_tlv(unsigned char *pkt, unsigned char band);
unsigned short append_supported_role_tlv(unsigned char *pkt);
unsigned short append_supported_freq_band_tlv(unsigned char *pkt, unsigned char band);
unsigned short append_WSC_tlv(unsigned char *pkt, struct p1905_managerd_ctx *ctx,
	unsigned char wsc_type, WSC_CONFIG *config_data,
	unsigned char wfa_vendor_extension);
unsigned short append_send_tlv(unsigned char *pkt, struct p1905_managerd_ctx *ctx);
unsigned short append_send_tlv_relayed(unsigned char *pkt, struct p1905_managerd_ctx *ctx);
unsigned short append_supported_service_tlv(unsigned char *pkt, unsigned char service);
unsigned short append_controller_cap_tlv(unsigned char *pkt, struct controller_capability contr_cap);
unsigned short append_searched_service_tlv(unsigned char *pkt);
unsigned short append_ap_radio_identifier_tlv(unsigned char *pkt, unsigned char *identifier);
unsigned short append_ap_radio_basic_capability_tlv(struct p1905_managerd_ctx* ctx, unsigned char *pkt,
	struct radio_info *r);
unsigned short append_ap_capability_tlv(unsigned char *pkt, struct ap_capability *ap_cap);
unsigned short append_ap_ht_capability_tlv(unsigned char *pkt, struct ap_ht_cap_db* ht_cap);
unsigned short append_ap_vht_capability_tlv(unsigned char *pkt, struct ap_vht_cap_db *vht_cap);
unsigned short append_ap_eht_capability_tlv(struct p1905_managerd_ctx *ctx, unsigned char *temp_buf);
unsigned short append_ap_he_capability_tlv(unsigned char *pkt, struct ap_he_cap_db *he_cap);
unsigned short append_client_steering_request_tlv(unsigned char *pkt);
unsigned short append_client_steering_btm_report_tlv(unsigned char *pkt,
	struct cli_steer_btm_event *btm_evt);
unsigned short append_map_policy_config_request_tlv(unsigned char *pkt);
unsigned short append_cli_assoc_cntrl_request_tlv(unsigned char *pkt);
unsigned short append_channel_preference_tlv(unsigned char *pkt,
	struct ch_prefer_db *prefer_db);
unsigned short append_transmit_power_limit_tlv(unsigned char *pkt,
	unsigned char *identifier, signed char tx_power_limit);
unsigned short append_channel_selection_response_tlv(unsigned char *pkt,
	struct ch_stat_info *stat);
unsigned short append_operating_channel_report_tlv(unsigned char *pkt,
	struct ch_rep_info *rep_info);
unsigned short append_operating_channel_report_tlv_bw80(unsigned char *pkt,
	struct ch_rep_info *rep_info);
int append_error_code_tlv(struct p1905_managerd_ctx* ctx, unsigned char *pkt,
		int error_code, unsigned char *mac);
int append_reason_code_tlv(unsigned char *pkt,unsigned short reason);
unsigned short append_sta_unlink_metrics_response_tlv(unsigned char *pkt,
	struct unlink_metrics_info *metrics);
unsigned short append_beacon_metrics_response_tlv(unsigned char *pkt,
	struct beacon_metrics_rsp *beacon_rsp);
unsigned short append_backhaul_steer_response_tlv(unsigned char *pkt,
	struct backhaul_steer_rsp *steer_rsp);
unsigned short append_tx_link_metric_tlv(unsigned char *pkt,
	struct tx_link_metric_db *tx_link_metric);
unsigned short append_rx_link_metric_tlv(unsigned char *pkt,
	struct rx_link_metric_db *rx_link_metric);
void build_ap_metric_query_tlv(struct p1905_managerd_ctx *ctx);
unsigned short create_vs_info_for_specific_discovery(unsigned char *vs_info);
unsigned short create_vs_info_for_specific_notification(struct p1905_managerd_ctx *ctx,
	unsigned char *vs_info);
int append_map_version_tlv(unsigned char *pkt, unsigned char version);
unsigned short append_wts_content_vendor_tlv(unsigned char *pkt,
	FILE *f, int offset, int size);
unsigned short append_bss_prio_vendor_tlv(unsigned char *pkt,
	unsigned char *str, unsigned short str_len);
unsigned short append_bss_prio_ack_vendor_tlv(unsigned char *pkt);
int append_operational_bss_tlv(struct p1905_managerd_ctx *ctx,
	unsigned char *pkt,
	struct list_head_oper_bss *opbss_head);
int append_associated_clients_tlv(unsigned char *pkt,
	struct list_head_assoc_clients *asscli_head);
int append_client_assoc_event_tlv(unsigned char *pkt,
		struct map_client_association_event *assoc_evt);
int append_cli_info_tlv(unsigned char *pkt, struct client_info *info);
int append_cli_capability_report_tlv(struct p1905_managerd_ctx* ctx,
	unsigned char *pkt, int *error_code);


#ifdef MAP_R2
int append_r2_cap_tlv(unsigned char *pkt, struct ap_r2_capability *r2_cap);
int append_metric_collection_interval_tlv(unsigned char *pkt, unsigned int interval);
int append_default_8021Q_tlv(struct p1905_managerd_ctx *ctx,
	unsigned char *pkt, unsigned char *al_mac,
	unsigned char bss_num, struct set_config_bss_info *bss_info);
int append_traffic_separation_tlv(struct p1905_managerd_ctx *ctx,
	unsigned char *pkt, unsigned char *al_mac,
	unsigned char bss_num, struct set_config_bss_info *bss_info);
int append_transparent_vlan_tlv(struct p1905_managerd_ctx *ctx, unsigned char *pkt);
int append_ap_radio_advan_tlv(unsigned char *pkt, struct ap_radio_advan_cap *radio_adv_capab);
unsigned short append_backhaul_sta_radio_cap_tlv(unsigned char *pkt,
    unsigned char *rid, unsigned char *itf_mac);
#endif

#ifdef MAP_R3
int append_agent_list_tlv(unsigned char *pkt, struct p1905_managerd_ctx *ctx);
int append_dpp_cce_indication_tlv(unsigned char *pkt, struct p1905_managerd_ctx* ctx);
int append_akm_suite_cap_tlv(unsigned char *pkt, struct p1905_managerd_ctx* ctx);
int append_bss_config_response_tlv(unsigned char *pkt, struct p1905_managerd_ctx* ctx, unsigned char *al_mac);
int append_bss_config_report_tlv(unsigned char *pkt, struct p1905_managerd_ctx* ctx);
int append_dpp_chirp_value_tlv(unsigned char *pkt, struct chirp_tlv_info *chirp);
int append_1905_layer_security_tlv(unsigned char *pkt);
int append_1905_encap_eapol_tlv(unsigned char *pkt, struct p1905_managerd_ctx* ctx);
int append_bootstrap_uri_notification_tlv(unsigned char *pkt, struct p1905_managerd_ctx* ctx);
int append_bss_configuration_request_tlv(unsigned char *pkt, struct p1905_managerd_ctx* ctx);
#ifdef MAP_R3_WF6
unsigned short append_ap_wf6_capability_tlv(unsigned char *pkt, struct ap_wf6_role_db *wf6_cap);
#endif
#ifdef MAP_R3_DE
unsigned short append_dev_inven_tlv(unsigned char *pkt, struct dev_inven *de);
#endif /*MAP_R3_DE*/
#ifdef MAP_R4_SPT
unsigned short append_spatial_report_tlv(unsigned char *pkt,
	struct ap_spt_reuse_resp *rep_info);

#endif
#endif
/*MLO related API*/
unsigned short append_bss_mld_report_vendor_tlv(unsigned char *pkt, struct p1905_managerd_ctx *ctx);
unsigned short append_mlo_cap_vendor_tlv(unsigned char *pkt, struct ap_mlo_cap_db *cap);
unsigned short append_mlo_cap_announce_vendor_tlv(unsigned char *pkt, struct ap_mlo_cap_db *mlo_cap);
unsigned short append_eht_operations_tlv(struct p1905_managerd_ctx *ctx, unsigned char *pkt);
int append_agent_ap_mld_config_tlv(unsigned char *pkt, struct p1905_managerd_ctx *ctx, unsigned char *al_mac);
int append_own_ap_mld_config_tlv(unsigned char *pkt, struct p1905_managerd_ctx *ctx);
#if defined(MAP_R6) || defined(EM_PLUS_SUPPORT)
unsigned short append_wifi7_cap_tlv(struct p1905_managerd_ctx *, unsigned char *);
#endif
#ifdef MAP_R6
int append_bsta_mld_config_tlv(unsigned char *, struct p1905_managerd_ctx *, unsigned char *);

unsigned short append_assoc_sta_mld_cfg_rpt_tlv(struct mlo_sta_config_db *cfg, unsigned char *pkt);
#endif
int append_agent_t2lm_config_tlv(unsigned char *pkt, struct p1905_managerd_ctx *ctx);
#endif /*CMDU_TLV_H*/
