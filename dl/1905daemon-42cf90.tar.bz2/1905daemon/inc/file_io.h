/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#ifndef FILE_IO_H
#define FILE_IO_H

#include "p1905_ap_autoconfig.h"

struct p1905_managerd_ctx;

#define MAP_CFG_FILE "/etc/map/1905d.cfg"
#define MAP_WTS_BSS_CFG_FILE "/etc/map/wts_bss_info_config"
#define MAP_WTS_BSTA_CFG_FILE "/etc/map/wts_bsta_mlo_config"
#define MAP_BSTA_WSC_RECONFIG_FILE "/etc/map/bsta_wsc_reconfig"
#define MAP_MLO_LINK_CFG_FILE "/etc/map/mlo_link_config"
#define MAP_MLO_MAX_LINKS "/tmp/mlo_max_links"
#define MAX_FILE_PATH_LENGTH 64

char * map_config_get_line(char *s,
	int size, FILE *stream, int *line, char **_pos);
int _1905_write_mid(char* name, unsigned short mid);
int _1905_read_set_config(struct p1905_managerd_ctx *ctx, char *name,
	struct set_config_bss_info bss_info[], unsigned char max_bss_num,
	unsigned char *config_bss_num);
char* get_raw_data_end(char *content);
char* str_locate(char *org_string, char *t_string);
int _1905_read_dev_send_1905(struct p1905_managerd_ctx *ctx,
	char *name, unsigned char *almac, unsigned short *_type, unsigned short *tlv_len, unsigned char *pay_load);
int _1905_write_wts_file_content(char *buf, char *name);
int write_almac_to_1905_cfg_file(char *cfg_file_name, unsigned char *almac);
int write_bss_prio_to_1905_cfg_file(char *cfg_file_name, char *bss_prio);
int map_read_config_file(struct p1905_managerd_ctx *ctx);

#ifdef MAP_R6
void _1905_read_mld_link_config(struct p1905_managerd_ctx *ctx);
void _1905_read_mlo_max_links(struct p1905_managerd_ctx *ctx);
void _1905_read_bsta_config(struct p1905_managerd_ctx *ctx);
#endif /* MAP_R6 */

#endif /*FILE_IO_H*/

