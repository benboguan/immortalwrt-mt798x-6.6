/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#ifndef MAP_H
#define MAP_H

#include "p1905_managerd.h"

#define IN
#define OUT

#define wapp_utils_success 0
#define wapp_utils_error (-1)

#define IEEE802_11_band_2P4G 0x00
#define IEEE802_11_band_5GL  0x01
#define IEEE802_11_band_5GH  0x02

#define BAND_INVALID_CAP 0x00
#define BAND_2G_CAP 0x01
#define BAND_5GL_CAP  0x02
#define BAND_5GH_CAP  0x04
#define BAND_5G_CAP  0x06
#define BAND_6G_CAP  0x10

#define DETECT_NEIGHBOR_TIME 120
#define RECV_CONFIG_RSP_TIME 3
#define RECV_WSC_M1_TIME 5
#define RECV_WSC_M2_TIME 5
#define RECV_WSC_M2_ACK_TIME 5
#define M1_RETRY_CNT 2
#define ONE_RADIO_CONFIG_TIME_MAX (M1_RETRY_CNT * RECV_WSC_M2_TIME)

#define BSS_PRIO_WAIT_TIME 4
#define BSS_PRIO_DONE_TIME (3 * BSS_PRIO_WAIT_TIME)
#define AGENT_EXPIRE_WAIT_TIME	60

#define SERVICE_CONTROLLER 0x00
#define SERVICE_AGENT 0x01
#define SERVICE_KIBMIB_BYTE_COUNTER 0x02

#define BYTE_COUNT_UNIT_BYTES 0x00
#define BYTE_COUNT_UNIT_KBYTES 0x01
#define BYTE_COUNT_UNIT_MBYTES 0x02

/*Multi-AP tlv type*/
#define SUPPORTED_SERVICE_TLV_TYPE 0x80
#define SEARCHED_SERVICE_TLV_TYPE 0x81
#define AP_RADIO_IDENTIFIER_TYPE 0x82
#define AP_OPERATIONAL_BSS_TYPE 0x83
#define AP_ASSOCIATED_CLIENTS_TYPE 0x84
#define AP_RADIO_BASIC_CAPABILITY_TYPE 0x85
#define AP_HT_CAPABILITY_TYPE 0x86
#define AP_VHT_CAPABILITY_TYPE 0x87
#define AP_HE_CAPABILITY_TYPE 0x88
#define STEERING_POLICY_TYPE 0x89
#define METRIC_REPORTING_POLICY_TYPE 0x8A
#define CH_PREFERENCE_TYPE 0x8B
#define RADIO_OPERATION_RESTRICTION_TYPE 0x8C
#define TRANSMIT_POWER_LIMIT_TYPE 0x8D
#define CH_SELECTION_RESPONSE_TYPE 0x8E
#define OPERATING_CHANNEL_REPORT_TYPE 0x8F

#define CLIENT_INFO_TYPE 0x90
#define CLIENT_CAPABILITY_REPORT_TYPE 0x91
#define CLIENT_ASSOCIATION_EVENT_TYPE 0x92
#define AP_METRICS_QUERY_TYPE 0x93
#define AP_METRICS_TYPE 0x94
#define STA_MAC_ADDRESS_TYPE 0x95
#define ASSOC_STA_LINK_METRICS_TYPE 0x96
#define UNASSOC_STA_LINK_METRICS_QUERY_TYPE 0x97
#define UNASSOC_STA_LINK_METRICS_RSP_TYPE 0x98
#define BEACON_METRICS_QUERY_TYPE 0x99
#define BEACON_METRICS_RESPONSE_TYPE 0x9A
#define STEERING_REQUEST_TYPE 0x9B
#define STEERING_BTM_REPORT_TYPE 0x9C
#define CLI_ASSOC_CONTROL_REQUEST_TYPE 0x9D
#define BACKHAUL_STEERING_REQUEST_TYPE 0x9E
#define BACKHAUL_STEERING_RESPONSE_TYPE 0x9F
#define HIGH_LAYER_DATA_TYPE 0xA0
#define AP_CAPABILITY_TYPE 0xA1
#define ASSOC_STA_TRAFFIC_STATS_TYPE 0xA2
#define ERROR_CODE_TYPE 0xA3

//#ifdef MAP_R2

#define CHANNEL_SCAN_REPORTING_POLICY_TYPE 0xA4
#define CHANNEL_SCAN_CAPABILITY_TYPE 0xA5
#define CHANNEL_SCAN_REQUEST_TYPE 0xA6
#define CHANNEL_SCAN_RESULT_TYPE 0xA7
#define TIMESTAMP_TYPE 0xA8
#define _1905_LAYER_SECURITY_CAPABILITY_TYPE 0xA9
#define GROUP_INTEGRITY_KEY_TYPE 0xAA
#define MIC_TYPE 0xAB
#define ENCRYPTED_TYPE 0xAC
#define CAC_REQUEST_TYPE 0xAD
#define CAC_TERMINATION_TYPE 0xAE
#define CAC_COMPLETION_REPORT_TYPE 0xAF
#define CAC_STATUS_REQUEST_TYPE 0xB0
#define CAC_STATUS_REPORT_TYPE 0xB1
#define CAC_CAPABILITIES_TYPE 0xB2
#define MULTI_AP_VERSION_TYPE 0xB3
#define R2_AP_CAPABILITY_TYPE 0xB4
#define DEFAULT_8021Q_SETTING_TYPE 0xB5
#define TRAFFIC_SEPARATION_POLICY_TYPE 0xB6
#define PACKET_FILTERING_POLICY_TYPE 0xB7
#define ETHERNET_CONFIGURATION_POLICY_TYPE 0xB8
#define SERVICE_PRIORITIZATION_RULE_TYPE 0xB9
#define DSCP_MAPPING_TABLE_TYPE 0xBA
#define SERVICE_PRIORITIZATION_INTERFACE_EXCEPTION_TYPE 0xBB
#define R2_ERROR_CODE_TYPE 0xBC
#define AP_OPERATIONAL_BACKHAUL_BSS_TYPE 0xBD
#define AP_RADIO_ADVANCED_CAPABILITIES_TYPE 0xBE
#define ASSOCIATION_STATUS_NOTIFICATION_TYPE 0xBF
//below value should be confirmed by the formal released MAP R2 spec
#define SOURCE_INFO_TYPE 0xC0
#define TUNNELED_MESSAGE_TYPE 0xC1
#define TUNNELED_TYPE 0xC2
#define R2_STEERING_REQUEST_TYPE 0xC3
#define UNSUCCESSFUL_ASSOCIATION_POLICY_TYPE 0xC4
#define METRIC_COLLECTION_INTERVAL_TYPE 0xC5
#define RADIO_METRIC_TYPE 0xC6
#define AP_EXTENDED_METRIC_TYPE 0xC7
#define ASSOCIATED_STA_EXTENDED_LINK_METRIC_TYPE 0xC8
#define ASSOCIATED_STATUS_CODE_TYPE 0xC9
#define REASON_CODE_TYPE 0xCA
//#define BH_STA_RADIA_CAPABILITY_TYPE 0xCB
#define BACKHAUL_STA_RADIA_CAPABILITY_TYPE 0xCB
//#endif // #ifdef MAP_R2
//#ifdef MAP_R3
#define AKM_SUITE_CAPABILITY_TYPE 0xCC
#define PROXIED_ENCAP_DPP_MESSAGE_TYPE 0xCD
#define _1905_ENCAP_EAPOL_MESSAGE_TYPE 0xCE
#define DPP_BOOTSTRAP_URI_NOTIFY_TYPE 0xCF
#define BACKHAUL_BSS_CONFIG_TYPE 0xD0
#define DIRECT_ENCAP_DPP_MESSAGE_TYPE 0xD1
#define DPP_CCE_INDICATION_TYPE 0xD2
#define DPP_CHIRP_VALUE_TYPE 0xD3
#define AGENT_LIST_TLV_TYPE 0xD5
#define BSS_CONFIG_REQUEST_TYPE 0xBB
#define BSS_CONFIG_RESPONSE_TYPE 0xBD
#define BSS_CONFIG_REPORT_TYPE 0xB7
#define R3_DE_INVENTORY_TLV_TYPE 0xD4
#define SPATIAL_REUSE_REQ_TYPE 0xD8
#define SPATIAL_REUSE_REPORT_TYPE 0xD9
#define SPATIAL_REUSE_CONFIG_RESP_TYPE 0xDA
#define QOS_MANAGEMENT_POLICY_TYPE 0xDB
#define QOS_MANAGEMENT_DESCRIPTOR_TLV_TYPE 0xDC
#define CONTROLLER_CAPABILITY_TYPE 0XDD
#define AP_MLD_EXTENDED_METRICS_TLV_TYPE 0xDE
#define WIFI7_AGENT_CAPABILITY_TLV_TYPE 0xDF
#define AGENT_AP_MLD_CONFIG_TLV_TYPE 0xE0
#define BSTA_MLD_CONFIG_TLV_TYPE 0xE1
#define ASSOCIATED_STA_MLD_CONFIG_REPORT_TLV_TYPE 0xE2
#define MLD_STRUCTURE_TLV_TYPE 0xE3
#define AFFILIATED_STA_METRICS_TLV_TYPE 0xE4
#define AFFILIATED_AP_METRICS_TLV_TYPE 0xE5
#define TID_2_LINK_MAPPING_POLICY_TLV_TYPE 0xE6
#define EHT_OPERATION_TLV_TYPE 0xE7
#define WSC_M8_TLV_TYPE 0xE8
#define AFC_SPECTRUM_INQUIRY_REQUEST_TLV_TYPE 0xE8
#define AFC_SPECTRUM_INQUIRY_RESPONSE_TLV_TYPE 0xE9

#define FUNC_VENDOR_EHT_CAP 22

typedef enum {
	DPP_AUTH_REQUEST = 0,
	DPP_AUTH_RESPONSE,
	DPP_AUTH_CONFIRM,
	DPP_DISCOVERY_REQUEST = 5,
	DPP_DISCOVERY_RESPONSE,
	DPP_PKEX_EXCHANGE_REQUEST,
	DPP_PKEX_EXCHANGE_RESPONSE,
	DPP_PKEX_COMMIT_REVEAL_REQUEST,
	DPP_PKEX_COMMIT_REVEAL_RESPONSE,
} DPP_ACTION_TYPE;
//#endif //MAP_R3

#define MAP_R6_NOT_SUPPORT 0
#define MAP_PRE_R6_SUPPORT 1
#define MAP_R6_SUPPORT 2

/*Multi-AP tlv length*/
#ifdef EM_PLUS_SUPPORT
#define SUPPORTED_SERVICE_LENGTH 3
#else
#define SUPPORTED_SERVICE_LENGTH 2
#endif
#define SUPPORTED_SERVICE2_LENGTH 3
#define SEARCHED_SERVICE_LENGTH 2
#define AP_RADIO_IDENTIFIER_LENGTH 6
#define AP_CAPABILITY_LENGTH 1
#define AP_HT_CAPABILITY_LENGTH 7
#define AP_VHT_CAPABILITY_LENGTH 12
#define CLIENT_ASSOCIATION_EVENT_LENGTH 13
#define CLIENT_INFO_LENGTH 12
#define TRANSMIT_POWER_LIMIT_LENGTH 7
#define ERROR_CODE_TLV_LENGTH 7


enum internal_vendor_subtype{
	internal_vendor_discovery_message_subtype = 0,
	internal_vendor_notification_message_subtype = 1,
	transparent_vlan_message_subtype,
	internal_vendor_wts_content_message_subtype,
	service_prioritization_vendor_rule_message_subtype,
	internal_vendor_bss_prio_message_subtype,
	internal_vendor_bss_prio_ack_message_subtype,
};

typedef enum {
	MAP_BH_ETH,
	MAP_BH_WIFI,
	MAP_BH_UNKNOWN,
} MAP_BH_TYPE;

enum MAP_ONBOARDING_TYPE {
	MAP_ONBOARDING_TYPE_DPP = 1,
	MAP_ONBOARDING_TYPE_WSC = 2,
	MAP_ONBOARDING_TYPE_UNKNOWN,
};

#define LINK_MODE_MASK_MAX_KERNEL_NU32 32
#define LINK_MODE_MASK_INT_NBITS 32
#define LINK_MODE_MASK_MAX_KERNEL_NBITS		\
	(LINK_MODE_MASK_INT_NBITS * LINK_MODE_MASK_MAX_KERNEL_NU32)


struct wfa_subelements_attr
{
	unsigned char attribute;
	unsigned char attribute_length;
	unsigned char attribute_value[0];
};

struct operational_bss {
	struct dl_list entry;
	unsigned char mac[ETH_ALEN];
	char ssid[33];
	unsigned char almac[ETH_ALEN];
#ifdef MAP_R2
	unsigned short vid;
#endif
};

struct assoc_client {
	struct dl_list entry;
	unsigned char mac[ETH_ALEN];
	unsigned char bssid[ETH_ALEN];
	unsigned short vlan_id;
	unsigned char disassoc;
	unsigned char ssid_len;
	char ssid[MAX_SSID_LEN];
	unsigned char al_mac[ETH_ALEN];
	unsigned char apply_2_mapfilter;
#ifdef MAP_R6
	struct mlo_sta_config_db sta_mld;
#endif
};

#define INVALID_VLAN_ID 4095

#ifdef MAP_R2
#define INVALID_PCP 8
#endif

#ifndef BIT
#define BIT(x) (1U << (x))
#endif

#define BIT_BH_STA BIT(7)
#define BIT_BH_BSS BIT(6)
#define BIT_FH_BSS BIT(5)
#define BIT_TEAR_DOWN BIT(4)
#define BIT_PROFILE1_DISALLOW BIT(3)
#define BIT_PROFILE2_DISALLOW BIT(2)
#define RESERVED BIT(1)
#define REUSE_RESERVED_NO_6G BIT(0)

void AtoH(char *src, char *dest, int destlen);

unsigned char get_mversion_from_msg_hdr(unsigned char *buf);
unsigned short get_mtype_from_msg_hdr(unsigned char *buf);
char *get_mtype_str_from_msg_hdr(unsigned char *buf);
unsigned short get_mid_from_msg_hdr(unsigned char *buf);
unsigned char get_fid_from_msg_hdr(unsigned char *buf);
unsigned char get_last_fragment_ind_from_msg_hdr(unsigned char *buf);
unsigned char get_relay_ind_from_msg_hdr(unsigned char *buf);
int check_relay_message(unsigned char relay_ind, unsigned short mtype);
int check_recv_mid(struct p1905_managerd_ctx *ctx, unsigned char *salmac, unsigned short mid, unsigned short mtype);


void relay_fragment_send(struct p1905_managerd_ctx *ctx,
			 unsigned char *tlv, unsigned int tlv_len, unsigned char *eth_hdr, unsigned char *almac);
int set_bss_config_priority_by_str(struct p1905_managerd_ctx *ctx);
void update_radio_bss_priority(struct p1905_managerd_ctx *ctx);
int fill_send_tlv(struct p1905_managerd_ctx *ctx, unsigned char *buf, unsigned short len);
int reset_send_tlv(struct p1905_managerd_ctx *ctx);
void reset_stored_tlv(struct p1905_managerd_ctx *ctx);
int store_revd_tlvs(struct p1905_managerd_ctx* ctx, unsigned char *revd_buf, unsigned short len);
int get_tlv_len_by_tlvtype(unsigned char *ptlvtype);
struct radio_info *get_rainfo_by_id(struct p1905_managerd_ctx *ctx, unsigned char* identifier);
int delete_exist_radio_basic_capability(struct p1905_managerd_ctx *ctx, unsigned char* identifier);
int update_radio_basic_capability(struct p1905_managerd_ctx *ctx, struct ap_radio_basic_cap *bcap,
	unsigned short cap_len);
int delete_exist_operational_bss(struct p1905_managerd_ctx *ctx, unsigned char *identifier);
int check_sta_in_oper_bss(struct list_head_oper_bss *opbss_head,
		struct map_client_association_event *assc_evt
#ifdef MAP_R6
		, struct mld_bss_config_db *mld_cfg
#endif
);
int insert_new_operational_bss(struct p1905_managerd_ctx *ctx, struct oper_bss_cap *opcap);
void delete_legacy_assoc_clients_db(struct p1905_managerd_ctx *ctx);
int update_assoc_sta_info(struct p1905_managerd_ctx *ctx,
	struct map_client_association_event *cinfo);
int get_bandcap(struct p1905_managerd_ctx *ctx, unsigned char opclass,
	unsigned char non_opch_num, unsigned char *non_opch);
int update_ap_ht_cap(struct p1905_managerd_ctx* ctx, struct ap_ht_capability *pcap);
int update_ap_eht_cap(struct p1905_managerd_ctx *ctx, struct ap_eht_capability *pcap);
int update_ap_vht_cap(struct p1905_managerd_ctx* ctx, struct ap_vht_capability *pcap);
int update_ap_he_cap(struct p1905_managerd_ctx* ctx, struct ap_he_capability *pcap);
int delete_exist_ch_prefer_info(struct p1905_managerd_ctx *ctx,
	unsigned char *identifier);
int delete_all_ch_prefer_info(struct list_head_ch_prefer *ch_prefer_head);
int insert_new_channel_prefer_info(struct p1905_managerd_ctx *ctx,
	struct ch_prefer *prefer);
int delete_exist_ch_prefer(struct list_head_ch_prefer *ch_prefer_head, unsigned char *identifier);
void update_ch_prefer_list_info(struct list_head_ch_prefer *dest_ch_prefer_head,
	struct list_head_ch_prefer *src_ch_prefer_head);
void update_ch_prefer_info(struct p1905_managerd_ctx *ctx, struct list_head_ch_prefer *ch_prefer_head);
int insert_new_ch_prefer_info(struct list_head_ch_prefer *ch_prefer_head,
	unsigned short len, unsigned char *val);
int delete_exist_restriction_info(struct p1905_managerd_ctx *ctx, unsigned char *identifier);
int insert_new_restriction_info(struct p1905_managerd_ctx *ctx,
	struct restriction *op_restrict);
int update_tx_power_limit_info(struct p1905_managerd_ctx *ctx,
	unsigned char *identifier, signed char power);
unsigned char check_invalid_channel(unsigned char op_class,
	unsigned char ch_num, unsigned char *ch_list);
unsigned char find_oper_channel(unsigned char op_class,
	unsigned char ch_num, unsigned char *ch_list);
unsigned char find_first_oper_channel(unsigned char op_class);
int update_channel_report_info(struct p1905_managerd_ctx *ctx,
	struct channel_report *rep, unsigned char len);
int delete_exist_steering_policy(struct steer_policy *spolicy);
void add_control_policy_info(struct control_policy *steer_cntrl, struct control_policy_db *new_policy);
void update_control_policy_info(struct control_policy *dst_steer_cntrl, struct control_policy *src_steer_cntrl);
int delete_exist_metrics_policy(struct p1905_managerd_ctx *ctx, struct metrics_policy *mpolicy);
int fill_metrics_policy(struct p1905_managerd_ctx *ctx, struct metrics_policy *mpolicy);
void update_metrics_policy(struct p1905_managerd_ctx *ctx, struct metrics_policy *mpolicy);
void delete_ap_metrics_query_head(struct list_head_metrics_query *head);
int delete_exist_metrics_info(struct p1905_managerd_ctx *ctx,
	unsigned char *bssid);
int insert_new_metrics_info(struct p1905_managerd_ctx *ctx,
	struct ap_metrics_info *minfo);
unsigned short append_ap_metrics_tlv(
        unsigned char *pkt, struct mrsp_db *mrsp);
unsigned short append_sta_traffic_stats_tlv(unsigned char *pkt, struct stats_db *stats
#ifdef MAP_R2
, unsigned char unit
#endif
);
unsigned short append_sta_link_metrics_tlv(
        unsigned char *pkt, struct metrics_db *metrics);
int delete_exist_traffic_stats_info(struct p1905_managerd_ctx *ctx,
	unsigned char *identifier);
int insert_new_traffic_stats_info(struct p1905_managerd_ctx *ctx,
	struct sta_traffic_stats *traffic_stats);
int delete_exist_link_metrics_info(struct p1905_managerd_ctx *ctx,
	unsigned char *identifier);
int insert_new_link_metrics_info(struct p1905_managerd_ctx *ctx,
	struct sta_link_metrics *metrics_info);
int update_one_sta_link_metrics_info(struct p1905_managerd_ctx *ctx,
	struct link_metrics *metrics);
int delete_exist_unlink_metrics_rsp(struct unlink_metrics_info *unlink_metrics);
int update_unlink_metrics_rsp(struct unlink_metrics_info *unlink_metrics_ctx,
	struct unlink_metrics_rsp *unlink_metrics);
int dev_send_1905(struct p1905_managerd_ctx* ctx, struct _1905_cmdu_request* request);
/*process event from 1905.1 library*/
int process_1905_request(struct p1905_managerd_ctx* ctx, struct _1905_cmdu_request* request);
struct agent_list_db *insert_agent_info(struct p1905_managerd_ctx *ctx, unsigned char *almac);
void delete_agent_info(struct agent_list_db *agent_info);
struct agent_radio_info *insert_agent_radio_info(struct agent_list_db *agent, unsigned char *id);
struct agent_radio_info *find_agent_radio_info(struct agent_list_db *agent, unsigned char *id);
int update_agent_radio_info(struct agent_list_db *agent, struct agent_radio_info *r);
void find_agent_info(struct p1905_managerd_ctx *ctx,
	unsigned char *almac, struct agent_list_db **agent);
void set_agent_wsc_doing_radio(struct agent_list_db *agent, unsigned char *id);
unsigned char find_agent_wsc_doing_radio(struct agent_list_db *agent);
void clear_agent_all_radio_config_stat(struct agent_list_db *agent);
void config_agent_all_radio_config_stat(struct agent_list_db *agent);
void set_agent_radio_config_stat(struct agent_list_db *agent,
	unsigned char *radio_id, unsigned char state);
/*
 * get radio config status
 * return:0-not been configured 1-configured
 */
int get_agent_all_radio_config_state(struct agent_list_db *agent);
int get_agent_total_config_bss_num(struct agent_list_db *agent);
int get_agent_total_bss_num(struct agent_list_db *agent);
int get_current_bss_num(struct p1905_managerd_ctx *ctx, unsigned char *almac);
void clear_agent_config_bss_num(struct agent_list_db *agent);
int delete_agent_ch_prefer_info(struct p1905_managerd_ctx *ctx,
	struct agent_list_db *agent);
int delete_all_radio_oper_restrict_info(struct list_head_oper_restrict *oper_restrict_head);
int delete_agent_ap_metrics_info(struct list_head_metrics_rsp_agent *metrics_head);
int insert_new_ap_metrics_info(struct list_head_metrics_rsp_agent *metrics_head,
	unsigned char *buf, unsigned short len);
int delete_agent_tx_link_metrics_info(struct list_head_tx_metrics_agent *tx_metrics_head);
int delete_agent_rx_link_metrics_info(struct list_head_rx_metrics_agent *rx_metrics_head);
int insert_new_tx_link_metrics_info(struct list_head_tx_metrics_agent *tx_metrics_head,
	unsigned char *buf, unsigned short len);
int free_all_the_agents_info(struct list_head_agent *agent_head);
void show_1905_mapfilter_version(struct p1905_managerd_ctx* ctx);
void send_1905_raw_data(struct p1905_managerd_ctx* ctx, char *file);
void read_1905_bss_config(struct p1905_managerd_ctx* ctx, char *file);
#ifdef SUPPORT_CMDU_RELIABLE
void cmdu_reliable_send(struct p1905_managerd_ctx *ctx, unsigned short msg_type,
		unsigned short mid, unsigned int ifidx);
#endif
int update_bss_prio_str(struct p1905_managerd_ctx *ctx,
	unsigned char *prio_str, unsigned short prio_str_len);
void clear_all_agent_bss_prio(struct p1905_managerd_ctx *ctx);
void sync_bss_prio_to_agent(void *eloop_ctx, void *data);
void sync_bss_prio_done(void *eloop_ctx, void *data);
void set_bss_prio_for_agent(struct p1905_managerd_ctx *ctx, unsigned char *almac);
int check_all_agent_sync_bss_prio(struct p1905_managerd_ctx *ctx);
int check_device_in_topo(struct p1905_managerd_ctx *ctx, unsigned char *almac);
void check_and_delete_expired_agent(struct p1905_managerd_ctx *ctx, int sec);
int map_event_handler(struct p1905_managerd_ctx *ctx, char *buf, int len, unsigned char type,
	unsigned char *reply, int *reply_len);
int change_role_dynamic(struct p1905_managerd_ctx* ctx, unsigned char role);
int get_local_device_info(struct p1905_managerd_ctx* ctx, unsigned char *buf,
	unsigned int buf_len, unsigned short *len);
int set_bss_config(struct p1905_managerd_ctx *ctx, enum BSS_CONFIG_OPERATION operation,
	struct bss_config_info* info);
int read_bss_conf_and_renew_v2(struct p1905_managerd_ctx *ctx, unsigned char local_only);
int read_bss_conf_and_renew(struct p1905_managerd_ctx *ctx, unsigned char local_only);
void init_radio_info_by_intf(struct p1905_managerd_ctx* ctx, struct p1905_interface *itf);
void metrics_report_timeout(void *eloop_data, void *user_ctx);
void attach_action(void *eloop_data, void *user_ctx);
void reset_controller_connect_ifname(struct p1905_managerd_ctx *ctx,
	unsigned char *link_down_ifname);
int find_al_mac_address(struct p1905_managerd_ctx *ctx, unsigned char *mac_addr, unsigned char *al_mac_addr);
int init_interface_socket(struct p1905_managerd_ctx *ctx);
int init_wireless_interface(struct p1905_managerd_ctx *ctx,
	struct interface_info_list_hdr *info);
int common_info_init(struct p1905_managerd_ctx *ctx);
int delete_exist_steer_cntrl_db(struct p1905_managerd_ctx *ctx);
int check_add_error_code_tlv(struct p1905_managerd_ctx *ctx, unsigned char *pkt,
	unsigned char max_sta_cnt, unsigned short msgtype);
void set_trx_config_for_bss(struct p1905_managerd_ctx*ctx, unsigned char map_vendor_extension, unsigned char *bss_mac);
/*delaying meesage handling function-init*/
int dm_init(struct p1905_managerd_ctx *ctx);
struct delayed_message_buf *get_dm_buf_entry(struct dl_list *list_head, IN unsigned char *almac,
	IN unsigned char event, IN char *if_name);
/*delaying meesage handling function-store*/
int store_dm_buffer(IN struct p1905_managerd_ctx *ctx, IN unsigned char *almac, IN unsigned char event,
	IN unsigned short mid, IN char *if_name);
/*delaying meesage handling function-pop*/
int pop_dm_buffer(IN struct p1905_managerd_ctx *ctx, IN unsigned char event, OUT unsigned char *almac,
	OUT unsigned short *mid, OUT char *if_name);
/*delaying meesage handling function-clear_expired*/
int clear_expired_dm_buffer(IN struct p1905_managerd_ctx *ctx);
/*delaying meesage handling function-deinit*/
int dm_deinit(struct p1905_managerd_ctx *ctx);
unsigned char find_band_by_opclass(char *opclass);
const char *band_2_string(unsigned char band);
int clear_all_exist_radio_basic_capability(struct p1905_managerd_ctx *ctx);
void clear_ap_capability_db(struct ap_capability_db *apcap_entry);
void clear_metric_db(struct metrics_info *metrics_entry);
int cmd_show_map_r6_support(struct p1905_managerd_ctx *ctx, char *buf, int len);


#ifdef MAP_R2
void delete_agent_ts_cap_info(struct list_head_ts_cap_agent *ts_cap_head);
void map_rm_hnat_session();
struct operational_bss *get_bss_by_bssid(struct p1905_managerd_ctx *ctx,
	unsigned char *mac);
struct operational_bss *create_oper_bss(struct p1905_managerd_ctx *ctx,
	unsigned char *mac, char *ssid, unsigned char ssid_len, unsigned char *almac, struct dl_list *bss_list);
struct assoc_client *get_cli_by_mac(struct dl_list *clients_table, unsigned char mac[]);
struct assoc_client *add_new_assoc_cli(struct dl_list *clients_table, unsigned char mac[], unsigned char *al_mac);
struct assoc_client *get_assoc_cli_by_mac(struct p1905_managerd_ctx *ctx, unsigned char mac[]);
struct assoc_client *create_assoc_cli(struct p1905_managerd_ctx *ctx, unsigned char mac[],
	unsigned char *al_mac);
/***channel scan***/
int delete_exist_channel_scan_capability(struct p1905_managerd_ctx *ctx, unsigned char *identifier);
int insert_new_channel_scan_capability(struct p1905_managerd_ctx *ctx, struct scan_capability_lib *scap);
unsigned short append_channel_scan_capability_tlv(unsigned char *pkt, struct list_head_ch_scan_cap *shead);
/***dfs cac***/
int delete_exist_cac_capability(struct p1905_managerd_ctx *ctx, unsigned char *identifier);
int insert_new_cac_capability(struct p1905_managerd_ctx *ctx, struct cac_capability_lib *cac_capab_in);
unsigned short append_cac_capability_tlv(unsigned char *pkt, struct radio_cac_capability_db *cachead);
int update_r2_ap_capability(struct p1905_managerd_ctx *ctx, struct ap_r2_capability *ap_r2_cap);
int insert_new_ap_extended_capability(struct p1905_managerd_ctx *ctx, struct ap_extended_metrics_lib *metric);
int insert_new_radio_metric(struct p1905_managerd_ctx *ctx, struct radio_metrics_lib *metric);
int delete_assoc_sta_extended_link_metric(struct p1905_managerd_ctx *ctx, struct sta_extended_metrics_lib *metric);
int insert_assoc_sta_extended_link_metric(struct p1905_managerd_ctx *ctx, struct sta_extended_metrics_lib *metric);
int delete_exist_traffic_policy(struct p1905_managerd_ctx *ctx, struct traffics_policy *tpolicy);
unsigned char check_traffic_policy_config_updated(struct p1905_managerd_ctx *ctx, struct traffics_policy *old_tpolicy,
	struct traffics_policy *new_tpolicy);
int delete_exist_pfilter_policy(struct p1905_managerd_ctx *ctx, struct pfiltering_policy *fpolicy);
int delete_exist_eth_config_policy(struct p1905_managerd_ctx *ctx, struct ethernets_policy *epolicy);
void map_r2_notify_ts_config(void *eloop_ctx, void *timeout_ctx);
void cmd_set_ts_pvlan(struct p1905_managerd_ctx *ctx, char* buf);
void cmd_set_ts_policy(struct p1905_managerd_ctx *ctx, char* buf);
void cmd_set_ts_policy_done(struct p1905_managerd_ctx *ctx);
void cmd_set_ts_policy_clear(struct p1905_managerd_ctx *ctx);
void assoc_client_table_init(struct p1905_managerd_ctx *ctx);
void traffic_separation_init(struct p1905_managerd_ctx *ctx);
void ts_traffic_separation_deinit(struct p1905_managerd_ctx *ctx);
int update_traffic_separation_policy(struct p1905_managerd_ctx *ctx,
	struct set_config_bss_info bss_info[], unsigned char bss_num);
int update_traffic_separation_policy_ex(struct p1905_managerd_ctx *ctx, struct traffics_policy *policy,
	struct set_config_bss_info bss_info[], unsigned char bss_num);
void map_notify_transparent_vlan_setting(void *eloop_ctx, void *timeout_ctx);
struct operational_bss *get_operational_bss_by_bssid(struct dl_list *bss_head,
	unsigned char bssid[]);
unsigned short get_vlan_by_ssid_from_ts_policy(char *ssid, unsigned char ssid_len,
	struct traffics_policy *policy);
void update_operation_bss_vlan(struct p1905_managerd_ctx *ctx,struct dl_list *bss_head,
	struct traffics_policy *policy, unsigned char *al_mac);
void maintain_all_assoc_clients(struct p1905_managerd_ctx *ctx);
void show_all_assoc_clients(struct p1905_managerd_ctx *ctx);
void show_all_operational_bss(struct p1905_managerd_ctx *ctx);
void delete_exist_radio_identifier(struct p1905_managerd_ctx *ctx);
void add_new_radio_identifier(struct p1905_managerd_ctx *ctx, unsigned char *identifier);
void clear_assoc_client_table(struct p1905_managerd_ctx *ctx);
#endif/*MAP_R2*/


#ifdef MAP_R3
#define FRAME_INFO_FILE "/tmp/map_frameinfo.txt"
#define RETURN_CONTENT_TLV 1
#define RETURN_CONTENT_HEXDUMP 2
#define RETURN_CONTENT_CACMethod 3
#define FILTER_FLAG_FIRST 1
#define FILTER_FLAG_LAST 2
#define FILTER_FLAG_ALL  4

void buf_huge(struct buf_info *buf, unsigned int pkt_len,
	unsigned char bcopy);
void buf_reset(struct buf_info *buf);
void tm_reset_buf_size(void *eloop_data, void *user_ctx);
int cont_handle_bss_configuration_request(struct p1905_managerd_ctx *ctx, unsigned char *al_mac);
void dev_get_frame_info_init(struct p1905_managerd_ctx *ctx);
void dev_get_frame_info_deinit(struct p1905_managerd_ctx *ctx);
void cmd_dev_start_buffer(struct p1905_managerd_ctx *ctx, char *buf);
void cmd_dev_stop_buffer(struct p1905_managerd_ctx *ctx);
void cmd_dev_stop_buffer_timeout(void *eloop_data, void *user_ctx);
void get_tlv_data(struct p1905_managerd_ctx *ctx,
		  unsigned int msg_type,
		  unsigned int mid,
		  unsigned int tlv[], unsigned int flag, unsigned int pkt_num, unsigned int return_content);
void cmd_dev_get_frame_info(struct p1905_managerd_ctx *ctx, char *buf);
void dev_buffer_frame(struct p1905_managerd_ctx *ctx, unsigned short mtype,
		      unsigned short mid, unsigned char *tlv_pos, int tlv_len);
int init_akm_capability(struct p1905_managerd_ctx *ctx);
void deinit_akm_capability(struct p1905_managerd_ctx *ctx);
#ifdef PTK_REKEY
void resend_ptk_rekey_request_msg(void *eloop_ctx, void *timeout_ctx);
void resend_ptk_rekey_request_timer(void *eloop_ctx, void *timeout_ctx);
#endif /*PTK_REKEY*/
void resend_gtk_timer(void *eloop_ctx, void *timeout_ctx);
void cmd_send_bss_reconfiguration_trigger(struct p1905_managerd_ctx *ctx, char *buf);
void del_chirp_from_hash_list(struct p1905_managerd_ctx *ctx,
	struct chirp_tlv_info *chirp_tlv);
void add_chirp_hash_list(struct p1905_managerd_ctx *ctx,
	struct chirp_tlv_info *chirp_tlv, unsigned char *almac);
void report_akm_suit_cap_to_mapd(void *eloop_ctx, void *timeout_ctx);
void report_1905_secure_cap_to_mapd(void *eloop_ctx, void *timeout_ctx);
void report_sp_standard_rule_to_mapd_timeout(void *eloop_ctx, void *timeout_ctx);
void report_sp_standard_rule_to_mapd(struct p1905_managerd_ctx *ctx);
#ifdef MAP_R3_WF6
int update_ap_wf6_cap(struct p1905_managerd_ctx* ctx, struct ap_wf6_cap_roles *pcap);
#endif
#ifdef MAP_R3_DE
int update_ap_dev_inven(struct p1905_managerd_ctx* ctx, struct dev_inven *de);
#endif /*MAP_R3_DE*/
#endif/*MAP_R3*/
/*MLO related change*/
#ifdef EM_PLUS_SUPPORT
int get_dev_inven(struct p1905_managerd_ctx *ctx);
int is_dev_wf7(struct p1905_managerd_ctx *ctx);
#endif
int delete_exist_mlo_cap_by_ruid(struct p1905_managerd_ctx *ctx, unsigned char *identifier);
int delete_exist_mlo_cap(struct p1905_managerd_ctx *ctx);
int update_radio_mlo_cap(struct p1905_managerd_ctx *ctx, struct ap_mlo_cap_lib *mlo_cap);
void update_eht_operations(struct p1905_managerd_ctx *ctx, unsigned char *data);
void delete_eht_operations(struct eht_operations_db *db);
void delete_ap_mld_conf(struct mld_bss_config_db *mld_bss);
void update_ap_mld_conf(struct mld_bss_config_db *mlo_bss, struct mld_bss_config_db *mlo_bss_new);
void wts_2_mlo_agent(struct p1905_managerd_ctx *ctx, unsigned char *al_mac);
void wts_2_mlo_cntrl(struct p1905_managerd_ctx *ctx, unsigned char *al_mac, struct radio_info *r);
void update_agt_ap_mld_info(struct mld_bss_config_db *mlo_bss, struct mld_bss_config_db *mlo_bss_new);
struct mld_bss_config_db *get_agent_ap_mld(struct p1905_managerd_ctx *ctx, unsigned char *al_mac);
void delete_agent_ap_mld_list(struct dl_list *head);
void trans_opbss_2_mlo(struct p1905_managerd_ctx *ctx, struct mld_bss_config_db *mld_bss, unsigned char *ruid);
void info_dump_agent_ap_mld(struct mld_bss_config_db *mld_bss);
void notice_dump_agent_ap_mld(struct mld_bss_config_db *mld_bss);
#if defined(MAP_R6) || defined(EM_PLUS_SUPPORT)
void delete_exist_wifi7_mlo_cap(struct dl_list *mlo_list);
void delete_wifi7_mld_cap_by_ruid(struct p1905_managerd_ctx *ctx, unsigned char *ruid);
int update_wifi7_mlo_cap(struct p1905_managerd_ctx *ctx, struct wifi7_ap_mlo_cap_lib *mlo_cap);
void update_agent_wifi7_mlo_cap(struct agent_list_db *agent_info, struct dl_list *wifi7_mlo_cap_list);
#endif
#ifdef MAP_R6
void update_affilliated_sta_mac(struct mld_bsta_config_db *bsta_mld, struct mld_bsta_config_db *bsta_mld_new);
void update_affilliated_sta_ruid(struct mld_bsta_config_db *bsta_mld, struct agent_list_db *agent);
void delete_agent_bsta_cfg(struct dl_list *bsta_list);
void delete_bsta_mld_conf(struct mld_bsta_config_db *bsta_mld);
void update_bsta_mld_conf(struct mld_bsta_config_db *bsta_mlo, struct mld_bsta_config_db *bsta_mlo_new);
void update_akm_capability(struct p1905_managerd_ctx *ctx, unsigned char *data);
void update_sta_mld_cfg_rpt(struct mlo_sta_config_db *sta_mld, struct mlo_sta_config *in_cfg);
void delete_sta_mld_cfg_rpt(struct mlo_sta_config_db *sta_mld, unsigned char *sta_mld_mac);
void update_wps_credential_reconfig(struct p1905_managerd_ctx *ctx, unsigned char *data);
void cmd_send_ap_mld_config_request(struct p1905_managerd_ctx *ctx);
void cmd_send_bsta_mld_config_request(struct p1905_managerd_ctx *ctx);
#endif

void del_radio_info_by_intf(struct p1905_managerd_ctx *ctx, struct p1905_interface *itf);
void handle_new_interface_event(struct p1905_managerd_ctx *ctx, unsigned char *buf);
void handle_del_interface_event(struct p1905_managerd_ctx *ctx, unsigned char *buf);
void update_eth_intf_media_type(struct p1905_managerd_ctx *ctx);

#endif /*MAP_H*/

