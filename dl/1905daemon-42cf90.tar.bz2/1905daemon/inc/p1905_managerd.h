/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#ifndef P1905_MANAGERD_H
#define P1905_MANAGERD_H
#include <sys/un.h>
#include <linux/if_packet.h>
#include "_1905_interface.h"
#include "p1905_database.h"
#include "file_io.h"
#include "stack.h"
#ifdef SUPPORT_WIFI
#include "wifi_utils.h"
#include "p1905_ap_autoconfig.h"
#endif
#include "service_prioritization.h"
#ifdef MAP_R3
#include "map_dpp.h"
#endif
#ifdef MAP_R5
#include "qos.h"
#endif

#define VERSION_1905 "v5.0.0.0"
#ifdef EM_PLUS_SUPPORT
#include "mapfilter_if.h"
#endif

struct contro_conn_port {
	unsigned char is_set;
	int port_num;
	unsigned char filter_almac[ETH_ALEN];
};

#ifdef EM_PLUS_SUPPORT
/*product info*/
struct product_info {
	char *ser_num;
	unsigned char ser_num_len;
};
#endif /* EM_PLUS_SUPPORT */

/** Context structure */
struct p1905_managerd_ctx {
	unsigned char role;
	unsigned char br_name[IFNAMSIZ];
	int br_ifid;
	unsigned char al_inf[IFNAMSIZ];
	char map_cfg_file[MAX_FILE_PATH_LENGTH];
	char wts_bss_cfg_file[MAX_FILE_PATH_LENGTH];
	int sock_br;                       /*bridge socket*/
	int ctrl_sock;
	char br_addr[ETH_ALEN];
#ifdef BR_IP_TLV_SUPPORT
	unsigned int br_ip;
	unsigned char include_brinfo_tlv;  /*flag for adding vs-tlv bridge info to topology rsp*/
#endif /* BR_IP_TLV_SUPPORT */
	int sock_inf_recv_1905[ITF_NUM];   /*recv socket array*/
	int sock_netlink;				   /*netlink socket to receive the netlink message*/
	struct nl_sock *genl_sock;
	int sock_internal;				   /*internal socket to receive the command from worker task*/
	struct sockaddr_un sock_addr;
	int sock_lldp[ITF_NUM];  /* lldp socket*/
	int discovery_cnt;
	struct _1905_interface_ctrl _1905_ctrl;
	struct sockaddr_ll lldp_sll;
	unsigned char p1905_al_mac_addr[ETH_ALEN];
#ifdef SUPPORT_WIFI
	ap_config_para ap_config;
	unsigned char uuid[16];
	unsigned char is_ap_config_by_eth;
	unsigned char *last_rx_data;
	unsigned short last_rx_buf_len;
	unsigned short last_rx_length;
	unsigned char *last_tx_data;
	unsigned short last_tx_buf_len;
	unsigned short last_tx_length;
	unsigned char *current_rx_data;
	unsigned short current_rx_length;
	unsigned char is_authenticator_exist_in_M2;
	unsigned char is_in_encrypt_settings;
	unsigned char get_config_attr_kind;
	enrolle_config_stage enrolle_state;
	renew_bss_state renew_state;
	unsigned short autoconfig_search_mid;
	unsigned char controller_search_cnt;
	controller_search_stage controller_search_state;
	WSC_CONFIG ap_config_data;
#endif
	unsigned char MAP_Cer;			/*for MAP Certification*/
	unsigned short mid;
	unsigned short dev_send_1905_mid;
	unsigned char need_relay;

	/*for link metric query/response use*/
	link_metrics_query link_metric_query_para;
	/*contain the cmdu matirial to make the corresponding cmdu*/
	unsigned char send_tlv[MAX_PKT_LEN];
	unsigned short send_tlv_len;
	unsigned long send_tlv_cookie;

	struct os_time own_topo_rsp_update_time; 						   /*last own topology response update time*/
	unsigned int recent_cmdu_rx_if_number;
	unsigned int itf_number;
	struct p1905_interface itf[ITF_NUM];                       /*first itf is the virtual interface*/
	struct bridge_capabiltiy br_cap[BRIDGE_NUM];
	struct non_p1905_neighbor non_p1905_neighbor_dev[ITF_NUM];
	struct p1905_neighbor p1905_neighbor_dev[ITF_NUM];
#ifdef EM_PLUS_EXT_SUPPORT
	struct topology_discovery_db gw_agent_dcv;
#endif
	struct p1905_topology_db topology_entry;
	struct p1905_topodevice_db topodev_entry;
	struct leaf *root_leaf;									/*root leaf of the topology tree*/
	unsigned int cnt;
	unsigned char radio_number;
	char bss_priority_str[MAX_RADIO_NUM * (IFNAMSIZ + 1) * MAX_BSS_NUM];
	struct radio_info rinfo[MAX_RADIO_NUM];
	unsigned char service;
	unsigned char byte_count_unit;
	unsigned char authenticated;
	struct auto_config_info  current_autoconfig_info;
	struct controller_info cinfo;
	struct ap_capability_db ap_cap_entry;
	struct sta_info sinfo;
	unsigned char sta_notifier;
	struct channel_setting *ch_set;
	struct channel_status *ch_stat;
	struct channel_report *ch_rep;
	/*map policy configuration*/
	struct policy_config map_policy;
	/*client assciation control of steering request*/
	struct control_policy steer_cntrl;
	/*ap metrics info*/
	struct metrics_info metric_entry;
	/*store 1905 link metrics info */
	struct _1905_link_stat link_stat;
	unsigned char *pcmdu_tx_buf;         /*pointer to the DEV_SEND_1905  tx content from wapp, e.g high layer data*/
	unsigned short cmdu_tx_buf_len;      /* DEV_SEND_1905 length*/
	unsigned short cmdu_tx_msg_type;     /*type of DEV_SEND_1905*/
	SLIST_HEAD(list_head_agent, agent_list_db) agent_head;
	/*for MAP controller*/
	unsigned int bss_config_bitmap[4];
	unsigned char bss_config_num;
	struct set_config_bss_info bss_config[MAX_SET_BSS_INFO_NUM];
	unsigned char peer_search_band;
	unsigned char core_dump;

	struct buf_info trx_buf;
	struct buf_info reassemble_buf;
	struct buf_info tlv_buf;
	/*to store the recevied tlvs*/
	struct buf_info revd_tlv;
#ifdef MAP_R3
	struct buf_info encr_buf;
#endif
	/*for controller use*/
	stack topo_stack;/*store the pre-order travel result of topology tree*/
	struct renew_context renew_ctx;
	struct _config_buf_ctrl config_buffer;
	/*used for PON*/
	struct contro_conn_port conn_port;
	SLIST_HEAD(list_head_neighbor, neighbor_list_db) query_neighbor_head;
	unsigned char map_version; /*1:DEV_TYPE_R1, 2:DEV_TYPE_R2*/
#ifdef MAP_R2
	struct dl_list clients_table[HASH_TABLE_SIZE];
	struct dl_list bss_head;
#endif
#ifdef MAP_R3
	struct r3_dpp_information r3_dpp;

	/* struct wpa_parameter */
	void *wpa;
	unsigned int gtk_rekey_interval;
	unsigned int decrypt_fail_threshold;
	struct akm_suite_cap bsta_akm;
	struct akm_suite_cap fh_akm;
	struct akm_suite_cap bh_akm;
	struct r3_onboarding_info r3_oboard_ctx;
	struct r3_reconfig_info r3_reconfig;
	/* store msg for ucc check */
	unsigned int frame_buff_switch;
	/* msg type list head */
	struct dl_list frame_buff_head;
	char dpp_keys_file[MAX_FILE_PATH_LENGTH];
#endif
#ifdef MAP_R3_DE
	struct dev_inven de;
#endif
	unsigned char switch_polling;
#ifdef MAP_R3_SP
	/*sp rule lists*/
	struct dl_list sp_rule_static_list;
	struct dl_list sp_rule_dynamic_list;
	struct dl_list sp_rule_del_list;
	struct dl_list sp_rule_learn_complete_list;
	/*sp dscp mapping table*/
	struct sp_dscp_pcp_mapping_table sp_dp_table;
	/*sp contex when send sp request*/
	struct sp_request_send_config sp_req_conf;
#endif
#ifdef SINGLE_BAND_SUPPORT
	unsigned char wifi_present;
#endif
	struct delayed_message_context dm_ctx;
#ifdef MAP_R4_SPT
	struct spt_reuse_report *spt_report;
#endif
#ifdef MAP_R5
	unsigned char config_adv_capability;
	struct dl_list qos_mgmt_desc_list;
	struct tunnelled_dscp_policy_act_frm dscp_policy_act_frm;

	unsigned char mscs_list_cnt;
	unsigned char scs_list_cnt;
	struct dl_list mscs_list;
	struct dl_list scs_list;
	struct dl_list qosmap_list;
	struct dl_list disallowed_list;
	int qos_operation_errorcode;
#endif
#ifdef MTK_MLO_MAP_SUPPORT
	unsigned char setup_link_num;
	/* struct mlo_non_setup_linkinfo linkinfo[MLO_LINK_MAX]; */
#endif
#ifdef MAP_R6
	/* bsta info from wts bsta file */
	struct dl_list agent_bsta_list;
	/* bsta info from bh ready event */
	struct bh_mld_bsta_config mld_bsta_info;
	/* cred from mapd on controller
	 * cred from WSC M8 on Agent
	*/
	struct bsta_wps_cred_reconf cred_reconfig;
	unsigned char wsc_msg_type;

	/* bsta mld from controller */
	unsigned char bsta_mld_cfg;
	struct mld_bsta_config_db mld_bsta;
	/* ucc configed max links */
	unsigned char mlo_max_links;
#endif
	/* eht op tlv from controller */
	unsigned char eht_op_cfg;
	struct eht_operations_db eht_op[MAX_RADIO_NUM];

	/* ap mld cfg flag from controller */
	unsigned char ap_mld_cfg;
	/* ap mld cfg from controller */
	struct mld_bss_config_db mld_bss;

	/* mlo link addition/removal */
	struct mld_link_chage mld_chg;
	/* mld bss config from wts file */
	struct mld_bss_config_db wts_ctrl_mld_cfg;
	struct dl_list agent_ap_mld_list;
	/* mld bss config from opclass */
	struct mld_bss_config_db opcls_mld_cfg;

	unsigned int restrict_wan_onboarding;
	unsigned char swtich_rule_set;
#ifdef EM_PLUS_SUPPORT
	struct emplus_feature_prof feature_prof;
	unsigned int boot_id;
	unsigned char *client_id;
	unsigned char client_id_len;
	unsigned char *client_secret;
	unsigned char client_secret_len;
	unsigned char emplus_product_class;
	unsigned char emplus_role;
	struct emplus_service_info service_info;
	unsigned char bh_bss_number;
	unsigned char bh_bss_name[MAX_RADIO_NUM][IFNAMSIZ];
	unsigned char guest_bss_number;
	unsigned char guest_bss_name[MAX_RADIO_NUM * MAX_BSS_NUM][IFNAMSIZ];
	unsigned char guest_br_name[IFNAMSIZ];
#ifdef EM_PLUS_EXT_SUPPORT
	unsigned char security_enabled;
#endif
	char ignore_renew;
#endif /* EM_PLUS_SUPPORT */
	struct block_bss_struct block_bss_info;
	struct mld_t2lm_config_db mlo_t2lm_db;
	unsigned char disable_tear_down;

#ifdef EM_PLUS_SUPPORT
	struct product_info product;
#endif /* EM_PLUS_SUPPORT */
	char rx_from_all;
	char auto_role_sync_wts_file;
};

#ifdef EM_PLUS_SUPPORT
enum PRODUCT_CLASS {
	GATWAY = 0,
	EXTENDER,
	STB,
};
#endif /* EM_PLUS_SUPPORT */

#ifdef EM_PLUS_SUPPORT
void get_dev_boot_id(struct p1905_managerd_ctx *ctx);
#endif /* EM_PLUS_SUPPORT */

#ifdef BR_IP_TLV_SUPPORT
int get_inf_ip(unsigned char *inf_name, unsigned int *ip);
void get_br_ip_proc(void *eloop_ctx, void *timeout_ctx);
#endif /* BR_IP_TLV_SUPPORT */
char *get_trx_config_str(unsigned char trx_conf, char *buf, int len);
int dump_intf_info(struct p1905_managerd_ctx *ctx, char *buf, int max_len);
int dump_init_info(struct p1905_managerd_ctx *ctx, char *buf, int len);
int dump_autoconfig_info(struct p1905_managerd_ctx *ctx, char *buf, int max_len);
char *get_media_type_str(unsigned short type);
int update_mapfilter_wan_tag(struct p1905_managerd_ctx *ctx, unsigned char status);

#endif /* P1905_MANAGERD_H */
