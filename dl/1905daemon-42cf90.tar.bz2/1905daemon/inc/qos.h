/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2021-2022  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

/*
 * qos.h, it's used to support MAP R4 qos management
 *
 */

#ifndef _QOS_MANAGEMENT_H
#define _QOS_MANAGEMENT_H

#include "list.h"

#ifndef GNU_PACKED
#define GNU_PACKED  __attribute__ ((packed))
#endif /* GNU_PACKED */

#define IE_TCLAS_ELEMENT_ID		14  /*0x0e*/
#define IE_TCLAS_PROCESSING_ID		44  /*0x2c*/
#define IE_INTRA_ACCESS_CATE_PRI_ID	184 /*0xb8*/
#define IE_SCS_DESCRIPTOR_ELEMENT_ID	185 /*0xb9*/

#define IE_QOS_CHARACTERISTICS_ID	113 /*0x71*/
#define MIN_QOS_CHARACTERISTICS_IE_LEN	19
#define MAX_QOS_CHARACTERISTICS_IE_LEN	39
#define QOS_MGMT_ELEMENT_ID	0xDD
#define MAX_TCLAS_NUM		5
#define MAX_DOMAIN_NAME_LEN	64
#define MAX_POLICY_NUM		10

/*Attribute ID*/
#define ATTR_ID_PORT_RANGE	1
#define ATTR_ID_DSCP_POLICY	2
#define ATTR_ID_TCLAS		3
#define ATTR_ID_DOMAIN_NAME	4

/*OUI Type*/
#define QOS_ACT_FRM_OUI_TYPE	0x1A
#define QOS_MGMT_IE_OUI_TYPE	0x22

/*OUI Subtype*/
#define DSCP_POLICY_QRY		0
#define DSCP_POLICY_REQ		1
#define DSCP_POLICY_RSP		2

#ifdef MAP_R5
#define MAC_ADDR_LEN	6

/*QoS Management Descriptor TLV*/
#define QOS_MGMT_DESCRIPTOR_TLV 0xDC
#define QOS_MGMT_DES_TLV_HEADER_LEN (2 + 2 * MAC_ADDR_LEN)

#define MAX_DESCRIPTOR_LEN	512
#define MAX_FRAME_BODY_LEN	512

#define MAX_NUM_DISALLOWED	5
#define MAX_EXCEPT_CNT	21
#define MAX_UP 8
#define DSCP_TBL_SIZE 64

#define TYPE4_CS_MASK_VERSION	 1   /*(1 << 0)*/
#define	TYPE4_CS_MASK_SRC_IP	 2   /*(1 << 1)*/
#define	TYPE4_CS_MASK_DST_IP	 4   /*(1 << 2)*/
#define	TYPE4_CS_MASK_SRC_PORT	 8   /*(1 << 3)*/
#define	TYPE4_CS_MASK_DST_PORT	 16  /*(1 << 4)*/
#define	TYPE4_CS_MASK_DSCP	 32  /*(1 << 5)*/
#define	TYPE4_CS_MASK_PROTOCOL	 64  /*(1 << 6)*/
#define	TYPE4_CS_MASK_NXT_HEAD	 64  /*(1 << 6)*/
#define	TYPE4_CS_MASK_FLOW_LABEL 128 /*(1 << 7)*/

#define QCHAR_MASK_DIR			1   /*(1 << 0)*/
#define	QCHAR_MASK_MIN_INTERVAL		2   /*(1 << 1)*/
#define	QCHAR_MASK_MAX_INTERVAL		4   /*(1 << 2)*/
#define	QCHAR_MASK_MIN_DATA_RATE	8   /*(1 << 3)*/
#define	QCHAR_MASK_DELAY_BOUND		16  /*(1 << 4)*/

#define MIN(x, y) (((x) < (y)) ? (x) : (y))
#define mac_addr_equal(pAddr1, pAddr2) !os_memcmp((void *)(pAddr1), (void *)(pAddr2), MAC_ADDR_LEN)
#define IPV6_ADDR_LEN 16
#define IPV6_ADDR_EQUAL(Addr1, Addr2) (!memcmp((void *)(Addr1), (void *)(Addr2), IPV6_ADDR_LEN))

enum {
	TUNNELLED_DSCP_QUERY = 5,
	TUNNELLED_DSCP_RESPONSE = 6,
};

enum {
	VER_IPV4 = 4,
	VER_IPV6 = 6,
};

enum {
	IP_TYPE_ICMP = 1,
	IP_TYPE_IGMP = 2,
	IP_TYPE_TCP = 6,
	IP_TYPE_UDP = 17,
	IP_TYPE_ESP = 50,
	IP_TYPE_IGRP = 88,
	IP_TYPE_OSPF = 89,
	IP_TYPE_UNKNOWN = 0xFF
};

enum {
	DIR_UPLINK = 0,
	DIR_DIRECTLINK = 1,
	DIR_DOWNLINK = 2,
	DIR_UNKNOWN,
};

enum {
	REQUEST_TYPE_ADD = 0,
	REQUEST_TYPE_REMOVE = 1,
	REQUEST_TYPE_CHANGE = 2,
	REQUEST_TYPE_SAVE = 3,
	REQUEST_TYPE_UNKNOWN
};

enum {
	CONFIG_TYPE_UNKNOWN = 0,
	CONFIG_TYPE_MSCS,
	CONFIG_TYPE_SCS,
	CONFIG_TYPE_QOSMAP,
	CONFIG_TYPE_DISALLOW,
};

enum RETURN_STATUS_CODE {
	STATUS_SUCCESS = 0,
	STATUS_INVALID_POINTER = -1,
	STATUS_INVALID_PARAM = -2,
	STATUS_INVALID_CMD_TYPE = -3,
	STATUS_INVALID_ALMAC = -4,
	STATUS_INVALID_STAMAC = -5,
	STATUS_INVALID_BSSID = -6,
	STATUS_INVALID_ACTION = -7,
	STATUS_INVALID_BITMAP = -8,
	STATUS_INVALID_UP = -9,
	STATUS_INVALID_VERSION = -10,
	STATUS_INVALID_IP = -11,
	STATUS_INVALID_PORT = -12,
	STATUS_INVALID_PROTOCOL = -13,
	STATUS_INVALID_DIR = -14,
	STATUS_INVALID_QOSCHAR = -15,
	STATUS_INVALID_DSCP_EXCEPTION = -16,
	STATUS_INVALID_DSCP_RANGE = -17,
	STATUS_INVALID_BUFLEN = -18,
	STATUS_CFG_EXISTED = -19,
	STATUS_CFG_NOT_EXISTED = -20,
	STATUS_CFG_IS_THE_SAME = -21,
	STATUS_ALLOC_MEM_FAIL = -22,
	STATUS_INSUFFICIENT_PARAM = -23,
	STATUS_NO_CLIENT_FOUND = -24,
	STATUS_CMD_NOT_SUPPORT = -25,
	STATUS_INSUFFICIENT_RESOURCE = -26,
	STATUS_MEMORY_OVERFLOW = -27,
	STATUS_UNKNOWN = 0xFF,
};

struct GNU_PACKED qos_management_policy {
	unsigned char numMSCSDisallowed;
	unsigned char numSCSDisallowed;
	unsigned char MSCSDisallowed[MAX_NUM_DISALLOWED][MAC_ADDR_LEN];
	unsigned char SCSDisallowed[MAX_NUM_DISALLOWED][MAC_ADDR_LEN];

	unsigned char reserved:6;
	unsigned char dscp_policy_en:1;
	unsigned char dscp_to_up_en:1;
};

struct GNU_PACKED qos_management_descriptor_tlv {
	unsigned char type;	/*QoS Management Descriptor TLV*/
	unsigned short length;
	unsigned short qmid;
	unsigned char bssid[MAC_ADDR_LEN];
	unsigned char sta_mac[MAC_ADDR_LEN];
	unsigned char descriptor[MAX_DESCRIPTOR_LEN];
};

struct qos_mgmt_descriptor {
	struct dl_list list;
	struct qos_management_descriptor_tlv qosmgmttlv;
};

struct GNU_PACKED tunnelled_dscp_policy_act_frm {
	unsigned char protocol_type;
	unsigned char sta_mac[MAC_ADDR_LEN];
	unsigned char frmbody[MAX_FRAME_BODY_LEN];
};

struct mscs_cfg {
	struct dl_list list;
	unsigned char index;
	unsigned char sta_mac[MAC_ADDR_LEN];
	unsigned char request_type;
	unsigned char up_bitmap;
	unsigned char cs_mask;
	unsigned char agent_almac[MAC_ADDR_LEN];
};

struct scs_cfg {
	struct dl_list list;
	unsigned char index;
	unsigned char sta_mac[MAC_ADDR_LEN];
	unsigned char scsid;
	unsigned char request_type;
	unsigned char up;

	/*tclas parameters*/
	unsigned char cs_mask;
	unsigned char version;
	union {
		unsigned int ipv4;
		unsigned short	ipv6[8];
	} srcIp;
	union {
		unsigned int	ipv4;
		unsigned short	ipv6[8];
	} destIp;
	unsigned short	srcPort;
	unsigned short	destPort;
	unsigned char	protocol;

	/*qos characteristics parameters*/
	unsigned char qchar_mask;
	unsigned char qoschar_dir;
	unsigned int qoschar_min_interval;
	unsigned int qoschar_max_interval;
	unsigned int qoschar_min_datarate;
	unsigned int qoschar_delaybound;

	unsigned char agent_almac[MAC_ADDR_LEN];
};

struct dscp_exception {
	unsigned char dscp;
	unsigned char up;
};

struct dscp_range {
	unsigned char low;
	unsigned char high;
};

struct qos_map {
	struct dl_list list;
	unsigned char al_mac[MAC_ADDR_LEN];
	unsigned char num;	/*dscp exception number*/
	struct dscp_exception dscp_ex[MAX_EXCEPT_CNT];
	struct dscp_range dscp_rg[MAX_UP];
};

struct mscs_scs_disallowed {
	struct dl_list list;
	unsigned char al_mac[MAC_ADDR_LEN];
	struct qos_management_policy qpolicy;
};

struct GNU_PACKED qchar_control_info {
	unsigned int dir:2;
	unsigned int tid:4;
	unsigned int up:3;
	unsigned int prenence_bitmap:16;
	unsigned int linkid:4;
	unsigned int reserved:3;
};

void qos_mgmt_init(void *context);
void qos_mgmt_deinit(void *context);
int qos_management_tlv_process(void *context, unsigned char *rcv_buf, unsigned short len);
unsigned short create_qos_management_notification_message(
	unsigned char *tlv_buf, unsigned char *buf, unsigned char *al_mac);
int process_qos_management_notification_message(void *context,
			unsigned char *buf, unsigned int left_tlv_len);
int parse_qos_management_policy_tlv(unsigned char *buf, unsigned short len,
	struct qos_management_policy *qos_policy);
int parse_qos_management_descriptor_tlv(unsigned char *buf, unsigned short len,
	struct qos_management_descriptor_tlv *tlv);
void qos_management_policy_check(void *context, void *timeout_ctx);
void qos_management_descriptor_tlv_check(void *context, void *timeout_ctx);
void qos_management_dscp_mapping_tbl_check(void *context, void *timeout_ctx);
int set_qos_config(void *context, char *buf);
int get_qos_config(void *context, char *cmdstr, char *reply_buf, int *reply_len);
int get_qos_error_code(void *context, char *reply_buf, int *reply_len);
int save_qos_config(void *context);
int load_qos_config(void *context);
void recheck_and_apply_qos_config(void *context);
void show_qos_config(void *context);

#endif /* MAP_R5 */

#endif /* _QOS_MANAGEMENT_H */
