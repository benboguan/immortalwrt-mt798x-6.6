/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#ifndef P1905_AP_AUTOCONFIG_H
#define P1905_AP_AUTOCONFIG_H

#include "p1905_database.h"

struct p1905_managerd_ctx;

#define WSC_RF_BAND_24G 0x01
#define WSC_RF_BAND_5G 0x02
#define WSC_RF_BAND_6G 0x08

#define DUAL_BAND_MAX_BSS_NUM 56
#define TRI_BAND_MAX_BSS_NUM 76

struct auto_config_info {
	signed char radio_index;
	unsigned char config_number;
	WSC_CONFIG config_data[MAX_BSS_NUM];
} ;

struct set_config_bss_info{
	unsigned char mac[ETH_ALEN];
	char oper_class[4];
	char band_support;
	char ssid[MAX_SSID_LEN];
	unsigned short authmode;
	unsigned short encryptype;
	char key[65];
	unsigned char wfa_vendor_extension;
	unsigned char hidden_ssid;
	unsigned short pvid;
	unsigned char pcp;
	unsigned char ssid_len;
	unsigned short vid;
	unsigned char mlo_grp_id;
};

struct renew_context {
	unsigned char trigger_renew;
	/*for agent use*/
	unsigned char is_renew_ongoing;
	unsigned char wait_apply;
};

typedef struct _ap_config_para
{
	unsigned char e_nonce[16];
	unsigned char r_nonce[16];
	unsigned char private_key[192];
	unsigned char public_key[192];
	unsigned char security_key[192];
	unsigned char peer_public_key[192];
	unsigned char enrolle_mac[6];

	unsigned char authKey[32];
	unsigned char keyWrapKey[16];
	unsigned short auth_type;
} ap_config_para;

typedef enum
{
    no_ap_autoconfig = 1,
    wait_4_send_ap_autoconfig_search, //not used
    wait_4_recv_ap_autoconfig_resp,  //not used
    wait_4_send_m1,
    wait_4_recv_m2,
    wait_4_set_config,

} enrolle_config_stage;

typedef enum {
	no_renew_bss = 1,
	wait_4_dump_topo,
	wait_4_pop_node,
	wait_4_send_renew,
	wait_4_check_renew_result,
	wait_4_apply_local,
	/* R3 */
	wait_4_send_bss_reconfig_trigger,
	wait_4_recv_bss_autoconfig_req,
	wait_4_send_bss_autoconfig_resp,
	wait_4_recv_bss_autoconfig_result,
}renew_bss_state;

typedef enum
{
	controller_search_idle = 0,
	bk_link_ready = 1,
	wait_4_send_controller_search,
	wait_4_recv_controller_search_rsp,
	controller_search_done,

} controller_search_stage;

typedef enum
{
	MAP_CONF_UNCONF,
	MAP_CONF_CONFED,
} radio_config_stage;

#ifdef MAP_R3
typedef enum
{
	no_r3_autoconfig = 0,
	wait_4_send_bss_autoconfig_req,
	wait_4_recv_bss_autoconfig_resp,
	wait_4_set_r3_config,
	r3_autoconfig_done,
} r3_enrolle_config_stage;


struct r3_config_data {
	unsigned char radio_identifier[ETH_ALEN];
	unsigned char bssid[ETH_ALEN];
	WSC_CONFIG config_data;
};


enum r3_onboarding_stage {
	R3_ONBOARDING_STAGE_INVALID = 0,
	R3_ONBOARDING_STAGE_PEER_DISCOVERY = 1,
	R3_ONBOARDING_STAGE_4_WAY_HS = 2,
	R3_ONBOARDING_STAGE_BSS_CONFIG = 3,
	R3_ONBOARDING_STAGE_DONE = 4,
};

struct r3_onboarding_info {
	unsigned char active;
	unsigned char peer_profile;
	unsigned char peer_service_type;
	unsigned char bh_type;
	unsigned char peer_almac[ETH_ALEN];
	r3_enrolle_config_stage r3_config_state;
	unsigned char total_config_num;
	unsigned char bss_req_retry_cnt;
	unsigned char bss_renew;
	unsigned char onboarding_stage;
	struct r3_config_data bss_config_data[MAX_SET_BSS_INFO_NUM];
};

struct r3_reconfig_info {
	unsigned char reconfig_state;
	unsigned char reconfig_cnt;
};


struct hash_value_item {
    unsigned short hashLen;
    unsigned char hashValue[32];
    unsigned char almac[ETH_ALEN];
    unsigned char mac_apcli[ETH_ALEN];
    struct dl_list member;
};

/* packets store related structure */

struct frame_list_struct{
	unsigned int mid;
	unsigned short len;
	unsigned char *data;
	struct dl_list data_list;
};

struct frame_buff_struct{
    unsigned short msg_type;
    unsigned short msg_cnt;
    /* msg data list for the msg type */
    struct dl_list frame_data_list;
    /* msg type list */
    struct dl_list frame_info_list;
};
#endif/*MAP_R3*/

struct block_bss_struct {
unsigned char block_bss_autoconfig;
unsigned char max_bss_count;/*the maximum BSS count in topology*/
unsigned char auto_config_num;/*the total auto config BSS num in controller*/
};

char *get_encryption_str(unsigned short encrypt);
char *get_authmode_str(unsigned short authmode, char *buf, int max_len);
char *get_map_vendor_extension_str(unsigned char extension, char *buf, int max_len);
char *get_search_state_str(int state);
char *get_enrollee_state_str(int state);
char *get_band_cap_str(int band);
int ap_autoconfig_init(struct p1905_managerd_ctx *ctx);
void ap_autoconfig_search(struct p1905_managerd_ctx* ctx, unsigned short mid);
void ap_controller_search_step(void *eloop_ctx, void *timeout_ctx);
void multi_ap_controller_search_sm(struct p1905_managerd_ctx* ctx);
void ap_autoconfig_enrolle_step(void *eloop_ctx, void *timeout_ctx);
void ap_autoconfig_enrolle_sm(struct p1905_managerd_ctx *ctx);
int pop_node_from_stack(struct p1905_managerd_ctx *ctx);
int controller_send_renew(struct p1905_managerd_ctx *ctx);
void controller_check_agent_renew_state(struct p1905_managerd_ctx *ctx);
void controller_renew_bss_step(void *eloop_ctx, void *timeout_ctx);
void controller_renew_bss_sm(struct p1905_managerd_ctx *ctx);
void agent_apply_new_config(void *eloop_ctx, void *timeout_ctx);
void reset_radio_config_state(struct p1905_managerd_ctx *ctx);
unsigned char get_left_unconfig_radio(struct p1905_managerd_ctx *ctx);
void trigger_auto_config_flow(struct p1905_managerd_ctx *ctx);
int cont_handle_autoconfig_wsc(struct p1905_managerd_ctx *ctx, unsigned char *al_mac,
	unsigned char *if_name, unsigned short mid, struct agent_radio_info *r,
	unsigned char radio_cnt, unsigned char *radio_identifier);
int cont_handle_autoconfig_renew(struct p1905_managerd_ctx *ctx, unsigned char *al_mac,
	unsigned char *if_name, unsigned char band);
int cont_handle_autoconfig_response(struct p1905_managerd_ctx *ctx, unsigned char *al_mac,
	unsigned char *if_name, unsigned char band, unsigned char role,
	unsigned char profile, struct controller_capability contr_cap);
int cont_handle_autoconfig_search(struct p1905_managerd_ctx *ctx, unsigned char *al_mac,
	unsigned char *if_name, unsigned char profile, unsigned short mid);
WIFI_UTILS_STATUS get_wsc_config(void *pctx, WSC_CONFIG* wsc,
	unsigned char *wfa_vendor_extension, struct agent_radio_info *agent_radio,
	unsigned char is_block);
WIFI_UTILS_STATUS set_wsc_config(void *pctx);
WIFI_UTILS_STATUS flash_wsc_config(void *pctx) ;
void *create_m2_thread_func(void *arg);
int create_all_m2s(struct p1905_managerd_ctx *ctx, unsigned char *buf,
	unsigned char num, unsigned short *total_len, struct agent_radio_info *agent_radio,
	unsigned char is_block);
int triger_autoconfiguration(struct p1905_managerd_ctx *ctx);
void auto_configuration_done(struct p1905_managerd_ctx *ctx);
int set_radio_autoconf_prepare(struct p1905_managerd_ctx* ctx,
	unsigned int band, unsigned char set_value);
int set_radio_autoconf_trriger(struct p1905_managerd_ctx *ctx,
	unsigned char radio_id, unsigned char set_value);
unsigned char determin_band_config(struct p1905_managerd_ctx *ctx,
	unsigned char *almac, unsigned char band_cap);
WIFI_UTILS_STATUS config_bss_by_band(struct p1905_managerd_ctx *ctx, unsigned char band,
	WSC_CONFIG *wsc, unsigned char *wfa_vendor_extension);
void config_sync_error_handler(void *context, void* parent_leaf, void *current_leaf, void *data);
int precheck_obj_num(struct p1905_managerd_ctx *ctx, unsigned char *al_mac);

#ifdef MAP_R3
void periodic_send_autoconfig_search(void *eloop_ctx, void *timeout_ctx);
int r3_send_bss_reconfig_trigger(struct p1905_managerd_ctx *ctx);
/* action frame type from DPP SPEC R2 */
char *actionFrame_typeNum2str(unsigned char type);
char *GasFrame_actionNum2str(unsigned char action);
int dev_send_eapol(void *ctx, unsigned char *dst_almac, unsigned char *eapol_frame, unsigned short eapol_len);
int r3_send_bss_config_req(struct p1905_managerd_ctx *ctx);
int transfer_r3_config_2_wireless_setting(struct p1905_managerd_ctx *ctx);
void r3_set_config(void *eloop_ctx, void *timeout_ctx);
void r3_set_config_state(struct p1905_managerd_ctx *ctx, unsigned char state);
void r3_config_sm(struct p1905_managerd_ctx *ctx);
void r3_config_sm_step(void *eloop_ctx, void *timeout_ctx);
void wait_send_bss_configuration_result(void *eloop_ctx, void *timeout_ctx);
#endif

int dump_bss_config_info(struct p1905_managerd_ctx *ctx, char *buf, int max_len);
int dump_sm_state_info(struct p1905_managerd_ctx *ctx, char *buf, int max_len);
int dump_controller_info(struct p1905_managerd_ctx *ctx, char *buf, int max_len);
int controller_trigger_block_bss_r2(struct p1905_managerd_ctx *ctx, unsigned char *almac);
int controller_trigger_block_bss_r3(struct p1905_managerd_ctx *ctx, unsigned char *almac);
void controller_block_bss_configuration_mechanism(struct p1905_managerd_ctx *ctx);
void controller_block_bss_configuration(void *eloop_ctx, void *user_ctx);
#ifdef EM_PLUS_SUPPORT
void reset_ignore_renew_flag(void *eloop_ctx, void *timeout_ctx);
#endif

#endif /* P1905_AP_AUTOCONFIG_H */
