/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#ifndef CMDU_TLV_PARSE_H
#define CMDU_TLV_PARSE_H

#include "p1905_managerd.h"

#define MAX_GRP_ID_CNT 128
struct vs_value {
	unsigned char discovery;
	unsigned char itf_mac[ETH_ALEN];
	unsigned char neth_almac[ETH_ALEN];
#ifdef EM_PLUS_SUPPORT
	char ifname[IFNAMSIZ];
#endif
#ifdef MAP_R2
	struct transparent_vlan_setting trans_vlan;
	int parse_ts;
#endif
	unsigned char mlo_cap_valid;
	unsigned char grp_id_valid;
	union {
		struct {
			unsigned char identifier[ETH_ALEN];
			unsigned char ap_mlo_cap;
			unsigned char sta_mlo_cap;
		} mlo_cap;
		struct {
			unsigned char cnt;
			unsigned char id[MAX_GRP_ID_CNT];
		} mlo_grp_id;
	} mlo_data;
};

int get_tlv_len(unsigned char *buf);
int get_cmdu_tlv_length(unsigned char *buf);
int cmdu_sanity_check(unsigned char *buf, int len);
int parse_al_mac_addr_type_tlv(unsigned char *al_mac, unsigned short len, unsigned char *value);
int parse_mac_addr_type_tlv(unsigned char *mac, unsigned short len, unsigned char *value);
int parse_vs_tlv(struct vs_value *vs_info, unsigned short len, unsigned char *value);
int parse_device_info_type_tlv(struct p1905_managerd_ctx *ctx,
	struct list_head_devinfo *devinfo_head, unsigned short len, unsigned char *value);
int parse_bridge_capability_type_tlv(struct list_head_brcap *brcap_head,
	unsigned short len, unsigned char *value);
int parse_p1905_neighbor_device_type_tlv(struct list_head_devinfo *devinfo_head,
	unsigned short len, unsigned char *value);
int parse_non_p1905_neighbor_device_type_tlv(struct list_head_devinfo *devinfo_head,
	unsigned short len, unsigned char *value);
int parse_search_role_tlv(unsigned short len, unsigned char *value);
int parse_auto_config_freq_band_tlv(unsigned char *band, unsigned short len, unsigned char *value);
int parse_supported_role_tlv(unsigned short len, unsigned char *value);
int parse_supported_freq_band_tlv(unsigned char *band, unsigned short len, unsigned char *value);
int parse_wsc_tlv(struct p1905_managerd_ctx *ctx, unsigned short len, unsigned char *value);
int parse_map_version_tlv(unsigned char *buf, unsigned char *profile);
int parse_supported_service_tlv(unsigned char *service, unsigned short len,
					unsigned char *value, unsigned char *service_cnt);
int parse_ap_radio_basic_cap_tlv(struct p1905_managerd_ctx *ctx, struct agent_radio_info *rinfo,
					unsigned short len, unsigned char *value);
int parse_ap_radio_identifier_tlv(struct p1905_managerd_ctx *ctx,
	unsigned char *radio_identifier
#ifdef MAP_R2
	, unsigned char need_store
#endif
	, unsigned short len, unsigned char *val);
int parse_client_assoc_event_tlv(struct p1905_managerd_ctx *ctx, unsigned char *mac,
	unsigned char *bssid, unsigned char *event, unsigned char *al_mac, unsigned short len,
	unsigned char *value, struct dl_list *clients_table);
int parse_client_info_tlv(struct p1905_managerd_ctx *ctx, unsigned char *bssid, unsigned char *sta_mac,
			unsigned short len, unsigned char *value);
int parse_channel_preference_tlv(struct p1905_managerd_ctx *ctx,
	struct list_head_ch_prefer *ch_prefer_head,
	unsigned short len, unsigned char *value);
int parse_steering_request_tlv(struct p1905_managerd_ctx *ctx,
	unsigned short len, unsigned char *val, struct err_sta_db *err_sta);
int parse_steering_policy_tlv(unsigned char *buf,
	struct p1905_managerd_ctx *ctx);
int parse_cli_assoc_control_request_tlv(struct p1905_managerd_ctx *ctx,
	unsigned short len, unsigned char *val, struct control_policy *steer_cntrl);
int parse_metric_reporting_policy_tlv(struct p1905_managerd_ctx *ctx,
	unsigned short len, unsigned char *val, struct metrics_policy *mpolicy);
int parse_ap_metrics_query_tlv(unsigned char *buf,
	struct p1905_managerd_ctx *ctx);
int parse_associated_sta_link_metrics_query_tlv(unsigned char *buf,
	struct p1905_managerd_ctx *ctx);
int parse_associated_sta_link_metrics_rsp_tlv(unsigned char *buf,
	struct p1905_managerd_ctx *ctx);
int parse_error_code_tlv(struct p1905_managerd_ctx *ctx, unsigned short len, unsigned char *value);
int parse_unassociated_sta_link_metrics_query_tlv(struct p1905_managerd_ctx *ctx,
	unsigned short len, unsigned char *val);
int parse_beacon_metrics_query_tlv(struct p1905_managerd_ctx *ctx,
	unsigned short len, unsigned char *val);
int parse_assoc_sta_link_metrics_tlv(struct p1905_managerd_ctx* ctx, unsigned char *buf);
int parse_assoc_sta_traffic_stats_tlv(struct p1905_managerd_ctx* ctx, unsigned char *buf);
int parse_tx_link_metrics_tlv(struct p1905_managerd_ctx* ctx, unsigned char *buf,
	struct list_head_tx_metrics_agent *tx_metrics_head);
int parse_rx_link_metrics_tlv(struct p1905_managerd_ctx* ctx, unsigned char *buf,
	struct list_head_rx_metrics_agent *rx_metrics_head);
int parse_ap_capability_tlv(struct p1905_managerd_ctx *ctx,
				unsigned short len, unsigned char *value, unsigned char *ap_cap);
int parse_ap_ht_capability_tlv(struct p1905_managerd_ctx *ctx,
				unsigned short len, unsigned char *value);
int parse_ap_vht_capability_tlv(struct p1905_managerd_ctx *ctx,
				unsigned short len, unsigned char *value);
int parse_unassociated_sta_link_metrics_rsp_tlv(struct p1905_managerd_ctx *ctx,
	unsigned char *buf);
int parse_beacon_metrics_rsp_tlv(struct p1905_managerd_ctx *ctx,
	unsigned char *buf);
#ifdef MAP_R2
int parse_ap_operational_bss_tlv(struct p1905_managerd_ctx *ctx, unsigned char *almac,
		unsigned short len, unsigned char *value, struct dl_list *bss_list);
int parse_assoc_clients_tlv(struct p1905_managerd_ctx *ctx, unsigned char *al_mac,
		unsigned short len, unsigned char *value, struct dl_list *clients_table);
int parse_traffic_separation_policy_tlv(struct traffics_policy *tpolicy,
	unsigned short len, unsigned char *val);
int parse_default_802_1q_setting_tlv(struct def_8021q_setting *setting,
	unsigned short len, unsigned char *val);
int parse_ap_radio_advanced_capability_tlv(struct p1905_managerd_ctx *ctx,
		unsigned char *almac, struct ts_cap_db **ts_cap,
		unsigned short len, unsigned char *value);
int parse_r2_ap_capability_tlv(struct ap_r2_capability *r2_cap, unsigned char *almac,
				  unsigned short len, unsigned char *value);
#endif
#ifdef MAP_R3
int parse_controller_cap_tlv(unsigned char *buf, struct controller_capability *contr_cap);
int parse_bh_sta_radio_cap_tlv(unsigned char *buf, unsigned short len);
int parse_ap_wf6_capability_tlv(struct p1905_managerd_ctx *ctx,
	unsigned char *buf);
int parse_bss_configuration_request_tlv(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned short len);
int parse_1905_layer_security_capability_tlv(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned char *onboardingProto,
	unsigned char *msgIntAlg, unsigned char *msgEncAlg);
int parse_agent_list_tlv(unsigned char *buf, unsigned short len,
	unsigned char *agent_cnt, struct r3_member *peer);
int parse_akm_suit_capability_tlv(
	unsigned char *buf, unsigned short len,
	struct akm_suite_cap *bh_akm, struct akm_suite_cap *fh_akm);
int parse_proxied_encap_dpp_type_tlv(unsigned char *buf, unsigned short len,
	unsigned char *frame_type, unsigned short *frame_offset, unsigned short *frame_len);
int parse_dpp_chirp_value_tlv(unsigned char *buf,
	unsigned short len, struct chirp_tlv_info *chirp);
int parse_bss_configuration_response_tlv(unsigned char *buf, unsigned short len,
	struct r3_onboarding_info *r3_ctx);
#endif
int parse_eht_operations_tlv(struct eht_operations_db *eht_op, unsigned char *buf, unsigned short len);
int parse_agent_ap_mld_config_tlv(struct mld_bss_config_db *mld_bss, unsigned char *al_mac,
	unsigned char *buf, unsigned short len);
#ifdef MAP_R6
int parse_bsta_mld_config_tlv(struct mld_bsta_config_db *mld_bsta, unsigned char *buf, unsigned short len);
int parse_wifi7_cap_tlv(struct p1905_managerd_ctx *ctx, unsigned char *al_mac,
	struct dl_list *cap_list, unsigned char *buf, unsigned short len);
int parse_affiliated_sta_metrics_tlv(struct p1905_managerd_ctx *ctx, unsigned char *buf);
#endif



#endif /*CMDU_TLV_PARSE_H*/
