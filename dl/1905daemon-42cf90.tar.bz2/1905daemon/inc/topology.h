/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#ifndef TOPOLOGY_H
#define TOPOLOGY_H
#include "p1905_managerd.h"

#define UNCONFIGURED 0x00
#define CONFIGURED_2G 0x01
#define CONFIGURED_5G 0x02

#define DISC_RETRY_TIME 3
#define NEIGHBOR_TOPOLOGY_QUERY_TIME 20
#define NEIGHBOR_TOPOLOGY_EXPIRE_TIME 40
#define TOPOLOGY_EXPIRE_TIME 70
#define TOPOLOGY_EXPIRE_DEL_TIME 90

typedef void (*topology_tree_cb_func)(void *context, void* parent_leaf, void *current_leaf, void *data);


struct leaf {
	struct dl_list entry;
	unsigned char al_mac[ETH_ALEN];
	unsigned char renew_send_round;
	struct os_time create_time;
#ifdef MAP_R3_SP
	enum rule_sync_status sp_rule_sync_status;
#endif
	/*maybe add the local interface mac to distinguish the backhaul link change in the same device*/
	struct dl_list children;
};

int get_ifid_by_almac(struct p1905_managerd_ctx *ctx, unsigned char *almac);
void discovery_at_boot_up(void *eloop_data, void *user_ctx);
struct leaf *create_leaf(unsigned char *al_mac);
void free_leaf(struct p1905_managerd_ctx *ctx, struct leaf *del_leaf);
struct topology_response_db *lookup_tprdb_by_almac(struct p1905_managerd_ctx *ctx, unsigned char *al_mac);
unsigned char is_neighbor(struct topology_response_db *rpdb, unsigned char *al_mac);
struct leaf *lookup_childleaf_by_almac(struct leaf *current_leaf, unsigned char *almac);
void find_leaf_handler(void *context, void* parent_leaf, void *current_leaf, void *data);
unsigned char is_leaf_exist(struct p1905_managerd_ctx * ctx, struct leaf *current_leaf, unsigned char *almac);
unsigned char build_tree_from_current_leaf(struct p1905_managerd_ctx *ctx,
	struct topology_response_db *current_rsp,
	struct leaf *current_leaf, struct leaf *parent_leaf);
int delete_tree_from_current_leaf(struct p1905_managerd_ctx *ctx, struct leaf *current_leaf);
int detect_deleted_leaf_from_current_leaf(struct p1905_managerd_ctx *ctx, struct leaf *current_leaf);
int create_topology_tree(struct p1905_managerd_ctx* ctx);
int update_topology_tree(struct p1905_managerd_ctx* ctx);
int clear_topology_tree(struct p1905_managerd_ctx* ctx);
int trace_topology_tree_cb(struct p1905_managerd_ctx* ctx,
	struct leaf *current_leaf, topology_tree_cb_func cb, void *data);
int topology_tree_travel_preorder(struct p1905_managerd_ctx* ctx, struct leaf *current_leaf);
void detect_neighbor_existence(struct p1905_managerd_ctx *ctx,
	unsigned char *neth_almac, unsigned char *sta_mac);
void delete_non_p1905_neighbor_dev_info(struct non_p1905_neighbor *non_p1905_dev);
void recv_neighbor_disc_timeout(void *eloop_data, void *user_ctx);
void check_neighbor_discovery(struct p1905_managerd_ctx *ctx,
	unsigned char *al_mac, unsigned char *itf_mac);
void topology_discovery_action(struct p1905_managerd_ctx *ctx, unsigned char *peer_al_mac,
	unsigned char need_query, unsigned char need_notify);
int update_p1905_neighbor_dev_info(struct p1905_managerd_ctx *ctx,
	unsigned char *al_mac, unsigned char *neighbor_itf_mac,
	unsigned char *itf_mac_addr, unsigned char *notify);
void delete_exist_topology_response_database(struct p1905_managerd_ctx *ctx, unsigned char *al_mac);
void update_bridge_cap(struct list_head_brcap *dst_br_head, struct list_head_brcap *src_br_head);
void update_dev_info(struct list_head_devinfo *dst_devinfo_head, struct list_head_devinfo *src_devinfo_head);
struct topology_response_db *delete_exist_topology_response_content(struct p1905_managerd_ctx *ctx,
	unsigned char *al_mac);
void delete_exist_topology_discovery_database(struct p1905_managerd_ctx *ctx,
					      unsigned char *al_mac, unsigned char *itf_mac);
void delete_topo_response_db_by_port_interface(struct p1905_managerd_ctx *ctx, int port);
int delete_topo_disc_db_by_port(struct p1905_managerd_ctx *ctx, int port, unsigned char *exclude_almac);
int delete_p1905_neighbor_dev_info(struct p1905_managerd_ctx *ctx,
	unsigned char *al_mac, unsigned char *recvif_mac);
struct topology_discovery_db *get_tpd_db_by_mac(struct p1905_managerd_ctx *ctx, unsigned char *mac);
struct topology_response_db *get_trsp_db_by_mac(struct p1905_managerd_ctx *ctx, unsigned char *mac);
int delete_not_exist_p1905_neighbor_device(struct p1905_managerd_ctx *ctx, int sec);
void delete_not_exist_p1905_topology_device(struct p1905_managerd_ctx *ctx, int sec);
void query_neighbor_info(struct p1905_managerd_ctx *ctx, unsigned char *almac, unsigned int if_number);
int insert_topology_discovery_database(struct p1905_managerd_ctx *ctx,
	unsigned char *al_mac, unsigned char *itf_mac, unsigned char *recv_itf_mac);
struct topology_discovery_db *find_discovery_by_almac(struct p1905_managerd_ctx *ctx, unsigned char *al_mac);
void find_neighbor_almac_by_intf_mac(struct p1905_managerd_ctx *ctx,
	unsigned char *itf_mac, unsigned char *almac);
struct topology_response_db *find_response_by_almac(struct p1905_managerd_ctx *ctx, unsigned char *al_mac);
int find_almac_by_connect_mac(struct p1905_managerd_ctx *ctx, unsigned char *mac, unsigned char *almac);
void mask_control_conn_port(struct p1905_managerd_ctx *ctx, struct topology_response_db *tpgr_db);
void unmask_control_conn_port(struct p1905_managerd_ctx *ctx, int port);
void report_own_topology_rsp(struct p1905_managerd_ctx *ctx,
	unsigned char *al_mac, struct bridge_capabiltiy *br_cap_list,
	struct p1905_neighbor *p1905_dev, struct non_p1905_neighbor *non_p1905_dev,
	unsigned char service, struct list_head_oper_bss *opbss_head,
    struct list_head_assoc_clients *asscli_head, unsigned int cnt);
void discovery_at_interface_link_up(void *eloop_data, void *user_ctx);
void mark_valid_topo_rsp_node(struct p1905_managerd_ctx *ctx);
void update_topology_info(struct p1905_managerd_ctx *ctx,
	struct topology_response_db *tpgr);
struct topology_response_db *find_topology_rsp_by_almac(struct p1905_managerd_ctx *ctx,
	unsigned char *almac);
int check_C_and_A_concurrent_by_topology_rsp(struct p1905_managerd_ctx *ctx,
	struct topology_response_db *tpgr_db);
int check_C_and_A_concurrent_by_discovery(struct p1905_managerd_ctx *ctx,
unsigned char *al_mac_addr, unsigned char *mac_addr);
unsigned char delete_non_p1905_neighbor_dev_info_byport(struct non_p1905_neighbor *non_p1905_dev, unsigned char port);
unsigned char delete_non_p1905_neighbor_dev_info_bymac(struct non_p1905_neighbor *non_p1905_dev, unsigned char *mac);
struct non_p1905_neighbor_info *get_non_p1905_neighbor_dev_info_bymac(struct non_p1905_neighbor *non_p1905_dev,
	unsigned char *mac, unsigned char port);
void non_1905_neighbor_update(void *eloop_data, void *user_ctx);
void check_topology_rsp_expired(struct p1905_managerd_ctx *ctx);
void send_discovery_periodic(void *eloop_data, void *user_ctx);
void clear_topology_db(struct p1905_topology_db *topo_entry);
void clear_topology_neighbor_db(struct p1905_neighbor *neighbor, unsigned char itf_number);
void clear_topology_device_db(struct p1905_topodevice_db *topodev_entry);
int dump_topology_info(struct p1905_managerd_ctx *ctx, char *buf, int max_len);
void dump_topology_tree(struct p1905_managerd_ctx *ctx);
void dump_radio_info(struct p1905_managerd_ctx *ctx);

int is_topology_changed(struct list_head_tpddb *tpd_head,
            struct non_p1905_neighbor *dev);
void update_non_1905_device_from_fdb(struct list_head_tpddb *tpd_head,
    struct non_p1905_neighbor *dev);
void show_PON_dev(struct p1905_managerd_ctx *ctx);
int dump_controller_num_in_topo(struct p1905_managerd_ctx *ctx, char *buf, int max_len);
int cal_controller_num_in_topo(struct p1905_managerd_ctx *ctx);
#endif
