/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#ifndef __1905_INTERFACE_H__
#define __1905_INTERFACE_H__

#include <sys/socket.h>
#include <sys/un.h>
#include "list.h"
#include "os.h"

struct _1905_interface_cli
{
	struct dl_list list;
	/*client daemon name*/
	char daemon_name[32];
	/*client sock addr*/
	struct sockaddr_un addr;
	socklen_t addrlen;
	int errors;
};
struct _1905_interface_ctrl
{
	/*wapp interface face ctrl socket, server*/
	int sock;
	/*sock addr*/
	struct sockaddr_un addr;
	/*peer client list*/
	struct dl_list daemon_cli_list;
	char *sock_buf;
	unsigned short  own_recv_buf_len;
	unsigned short  default_own_recv_len;
	unsigned short  peer_recv_buf_len;
	unsigned short  default_peer_recv_len;
};

int _1905_interface_set_sock_buf(void *in_ctx, unsigned short len);
int _1905_interface_init(void *in_ctx);
void _1905_interface_receive_process(int sock, void *eloop_ctx, void *sock_ctx);
void _1905_interface_deinit(void *in_ctx);
int _1905_interface_send_int(void *in_ctx, unsigned char* buf, size_t buf_len, char *dst_dameon);
int _1905_interface_send(void *in_ctx, unsigned char* buf, size_t buf_len, char *dst_dameon);
int _1905_interface_recv(void *in_ctx, unsigned char* buf, int buf_len);
int _1905_interface_pending(void *in_ctx, struct timeval *tv);

#endif
