/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#include <stdio.h>
#include <string.h>
#include <syslog.h>
#include <assert.h>
#include <linux/if_ether.h>
#include <asm/byteorder.h>
#include <stdlib.h>
#include "p1905_managerd.h"
#include "cmdu_message.h"
#include "cmdu_tlv_parse.h"
#include "cmdu.h"
#include "debug.h"
#include "_1905_lib_io.h"
#include "file_io.h"
#include "lldp_message_parse.h"
#include "topology.h"
#include "multi_ap.h"
#include "eloop.h"
#include "ethernet_layer.h"
#include "lldp.h"
#include "cmdu_tlv.h"
#ifdef MAP_R3
#include "security_engine.h"
#include "wpa_extern.h"
#endif

static unsigned char p1905_multicast_address[6]
	= { 0x01, 0x80, 0xc2, 0x00, 0x00, 0x13 };

struct _find_leaf {
	unsigned char al_mac[ETH_ALEN];
	unsigned char find_result;
};

char gw_agent_almac[ETH_ALEN];

int get_ifid_by_almac(struct p1905_managerd_ctx *ctx, unsigned char *almac)
{
	struct topology_response_db *rpdb = NULL;

	SLIST_FOREACH(rpdb, &ctx->topology_entry.tprdb_head, tprdb_entry) {
		if (!os_memcmp(rpdb->al_mac_addr, almac, ETH_ALEN))
			return rpdb->recv_ifid;
	}

	return -1;
}

struct leaf *create_leaf(unsigned char *al_mac)
{
	struct leaf *node = NULL;

	node = (struct leaf*)os_malloc(sizeof(struct leaf));
	if (!node) {
		err(DEBUG_CAT_MISC, "alloc leaf memory fail for ("MACSTR")\n",
			MAC2STR(al_mac));
		return NULL;
	}

	dl_list_init(&node->children);
	os_memcpy(node->al_mac, al_mac, ETH_ALEN);
	os_get_time(&node->create_time);
	node->renew_send_round = 0;
	return node;
}


void free_leaf(struct p1905_managerd_ctx *ctx, struct leaf *del_leaf)
{
	struct agent_list_db *agent_info = NULL;
#ifdef MAP_R3
	unsigned int wait_time = 30;
	struct r3_member *peer = NULL;

	if (ctx->MAP_Cer) {
		wait_time = 300;
		/* don't reset tx/rx counter in turnkey
		** tx rx counter may mismatch while plug in/out cable frequently
		*/
		ptk_peer_reset_encrypt_txrx_counter(del_leaf->al_mac);
	}

	peer = get_r3_member(del_leaf->al_mac);
	if (peer) {
		notice(DEBUG_CAT_DPP, "delete R3 security info for "MACSTR" after %d sec\n",
			MAC2STR(del_leaf->al_mac), wait_time);
		eloop_cancel_timeout(timeout_delete_r3_member, (void *)ctx, (void *)peer);
		eloop_register_timeout(wait_time, 0, timeout_delete_r3_member, (void *)ctx, (void *)peer);
	}
#endif

	find_agent_info(ctx, del_leaf->al_mac, &agent_info);
	if (agent_info) {
		/*reset the band configured status of agent which leaves from current network*/
		notice(DEBUG_CAT_AUTOCONF, "reset agent("MACSTR") config states\n",
			MAC2STR(agent_info->almac));
		clear_agent_all_radio_config_stat(agent_info);
	}
	dl_list_del(&del_leaf->entry);
	os_free(del_leaf);
}

struct topology_response_db *lookup_tprdb_by_almac(struct p1905_managerd_ctx *ctx, unsigned char *al_mac)
{
	struct topology_response_db *rpdb = NULL;

	SLIST_FOREACH(rpdb, &ctx->topology_entry.tprdb_head, tprdb_entry) {
		if (!os_memcmp(rpdb->al_mac_addr, al_mac, ETH_ALEN))
			break;
	}

	return rpdb;
}

unsigned char is_neighbor(struct topology_response_db *rpdb, unsigned char *al_mac)
{
	struct device_info_db *dev_info = NULL;
	struct p1905_neighbor_device_db *neighbor_db = NULL;

	SLIST_FOREACH(dev_info, &rpdb->devinfo_head, devinfo_entry) {
		SLIST_FOREACH(neighbor_db, &dev_info->p1905_nbrdb_head, p1905_nbrdb_entry) {
			if (!os_memcmp(neighbor_db->p1905_neighbor_al_mac, al_mac, ETH_ALEN))
				return 1;
		}
	}

	return 0;
}

struct leaf *lookup_childleaf_by_almac(struct leaf *current_leaf, unsigned char *almac)
{
	struct leaf *child_leaf = NULL;
	unsigned char found = 0;

	dl_list_for_each(child_leaf, &current_leaf->children, struct leaf, entry) {
		if (!os_memcmp(child_leaf->al_mac, almac, ETH_ALEN)) {
			found = 1;
			break;
		}
	}
	if (found == 0)
		child_leaf = NULL;

	return child_leaf;
}

void find_leaf_handler(void *context, void* parent_leaf, void *current_leaf, void *data)
{
	struct leaf *cur_leaf = (struct leaf *)current_leaf;
	struct _find_leaf *find_data = (struct _find_leaf *)data;

	if (find_data->find_result == 1)
		return;

	if (!os_memcmp(cur_leaf->al_mac, find_data->al_mac, ETH_ALEN))
		find_data->find_result = 1;
}

unsigned char is_leaf_exist(struct p1905_managerd_ctx * ctx, struct leaf *current_leaf, unsigned char *almac)
{
	struct _find_leaf find;

	os_memset(&find, 0, sizeof(struct _find_leaf));
	os_memcpy(find.al_mac, almac, ETH_ALEN);

	trace_topology_tree_cb(ctx, current_leaf, (topology_tree_cb_func)find_leaf_handler, (void*)&find);
	return find.find_result;
}

unsigned char build_tree_from_current_leaf(struct p1905_managerd_ctx *ctx, struct topology_response_db *current_rsp, struct leaf *current_leaf, struct leaf *parent_leaf)
{
	struct device_info_db *dev_info = NULL;
	struct p1905_neighbor_device_db *neighbor_db = NULL;
	struct topology_response_db *child_rpdb = NULL;
	struct leaf *child_leaf = NULL;

	SLIST_FOREACH(dev_info, &current_rsp->devinfo_head, devinfo_entry) {
		SLIST_FOREACH(neighbor_db, &dev_info->p1905_nbrdb_head, p1905_nbrdb_entry) {
			/*1. if neighbor exist in topology response db
			   2. if neighbor's 1905 neighbor tlv match the current devices's al mac and no leaf exist in current node
			       then create the child leaf
			   2.5 check whether this leaf exist, if yes, do not add this one until the exist one has deleted
			   3. and from this new/existed child leaf, buld all its child leaves*/
			child_rpdb = NULL;
			child_leaf = NULL;
			/*skip the parent leaf*/
			if (!os_memcmp(neighbor_db->p1905_neighbor_al_mac, parent_leaf->al_mac, ETH_ALEN))
				continue;
			/*1.*/
			child_rpdb = lookup_tprdb_by_almac(ctx, neighbor_db->p1905_neighbor_al_mac);
			if (!child_rpdb)
				continue;

			/*2.*/
			if (!is_neighbor(child_rpdb, current_leaf->al_mac))
				continue;

			child_leaf = lookup_childleaf_by_almac(current_leaf, child_rpdb->al_mac_addr);
			if (!child_leaf) {
				/*2.5*/
				if (is_leaf_exist(ctx, ctx->root_leaf, child_rpdb->al_mac_addr))
					continue;

				child_leaf = create_leaf(child_rpdb->al_mac_addr);

				if(!child_leaf)
					continue;
				notice(DEBUG_CAT_TOPO, "leaf add! current(%p)("MACSTR")----->child(%p)("MACSTR")\n",
					current_leaf, PRINT_MAC(current_leaf->al_mac),
					child_leaf, PRINT_MAC(child_leaf->al_mac));
				dl_list_add(&current_leaf->children, &child_leaf->entry);
			}

			/*3.*/
			build_tree_from_current_leaf(ctx, child_rpdb, child_leaf, current_leaf);
		}
	}

	return 0;
}

int delete_tree_from_current_leaf(struct p1905_managerd_ctx *ctx, struct leaf *current_leaf)
{
	struct leaf *child_leaf = NULL, *child_leaf_next = NULL;

	if (!current_leaf)
		return 0;

	dl_list_for_each_safe(child_leaf, child_leaf_next, &current_leaf->children, struct leaf, entry) {
		notice(DEBUG_CAT_TOPO, "leaf delete (%p)("MACSTR")\n",
				child_leaf, MAC2STR(child_leaf->al_mac));
		delete_tree_from_current_leaf(ctx, child_leaf);

		free_leaf(ctx, child_leaf);
	}

	return 0;
}

int detect_deleted_leaf_from_current_leaf(struct p1905_managerd_ctx *ctx, struct leaf *current_leaf)
{
	struct leaf *child_leaf = NULL, *child_leaf_next = NULL;
	struct topology_response_db *current_rsp = NULL, *child_rpdb = NULL;

	current_rsp = lookup_tprdb_by_almac(ctx, current_leaf->al_mac);

	if (!current_rsp) {
		err(DEBUG_CAT_TOPO, "current leaf ("MACSTR") not exist in my tpr db\n",
			MAC2STR(current_leaf->al_mac));
		return -1;
	}

	dl_list_for_each_safe(child_leaf, child_leaf_next, &current_leaf->children, struct leaf, entry) {
		child_rpdb = lookup_tprdb_by_almac(ctx, child_leaf->al_mac);
		/*maybe this condition should be add more, like check neighbor of child rsp db to see if it is current device*/
		if (child_rpdb && is_neighbor(current_rsp, child_leaf->al_mac)) {
			detect_deleted_leaf_from_current_leaf(ctx, child_leaf);
		} else {
			/*if child leaf is not my neighbor, should delete this child leaf and all its children leaves of this child leaf*/
			notice(DEBUG_CAT_TOPO, "leaf delete (%p)("MACSTR")\n",
				child_leaf, PRINT_MAC(child_leaf->al_mac));
			delete_tree_from_current_leaf(ctx, child_leaf);
			free_leaf(ctx, child_leaf);
		}
	}

	return 0;
}

/*init the root leaf of the tree, the root leaf always should represent current device*/
int create_topology_tree(struct p1905_managerd_ctx* ctx)
{
	struct leaf *root_leaf = NULL;

	if (ctx->root_leaf) {
		err(DEBUG_CAT_INIT, "root leaf already exist\n");
		goto fail;
	}

	root_leaf = create_leaf(ctx->p1905_al_mac_addr);
	if (!root_leaf)
		goto fail;

	ctx->root_leaf = root_leaf;
	return 0;
fail:
	return -1;
}

int update_topology_tree(struct p1905_managerd_ctx* ctx)
{
	struct p1905_neighbor_info *neighor_info = NULL;
	struct topology_response_db *child_rpdb = NULL;
	struct leaf *child_leaf = NULL, *child_leaf_next = NULL;
	int i = 0;
	unsigned char found = 0;

	if (!ctx->root_leaf) {
		info(DEBUG_CAT_TOPO, "root leaf not exist, wait init done\n");
		goto fail;
	}

	for (i = 0; i < ctx->itf_number; i++) {
		/*check the leaves that should be added to topology tree*/
		LIST_FOREACH(neighor_info, &ctx->p1905_neighbor_dev[i].p1905nbr_head, p1905nbr_entry) {
			child_rpdb = NULL;
			child_leaf = NULL;
			/*1. if neighbor exist in topology response db
			   2. if neighbor's 1905 neighbor tlv match the current devices's al mac and no leaf exist in current node
			       then create the child leaf
			   2.5 check whether this leaf exist, if yes, do not add this one until the exist one has deleted
			   3. and from this new/existed child leaf, rebuld its child leaves*/
			/*1.*/
			child_rpdb = lookup_tprdb_by_almac(ctx, neighor_info->al_mac_addr);
			if (!child_rpdb)
				continue;

			/*2.*/
			if (!is_neighbor(child_rpdb, ctx->root_leaf->al_mac))
				continue;

			child_leaf = lookup_childleaf_by_almac(ctx->root_leaf, neighor_info->al_mac_addr);
			if (!child_leaf) {
				/*2.5*/
				if (is_leaf_exist(ctx, ctx->root_leaf, neighor_info->al_mac_addr))
					continue;

				child_leaf = create_leaf(neighor_info->al_mac_addr);
				if (!child_leaf)
					continue;
				notice(DEBUG_CAT_TOPO, "leaf add! root(%p)("MACSTR")----->child(%p)("MACSTR")\n",
					ctx->root_leaf, PRINT_MAC(ctx->root_leaf->al_mac),
					child_leaf, PRINT_MAC(child_leaf->al_mac));
				dl_list_add(&ctx->root_leaf->children, &child_leaf->entry);
			}
			/*3.*/
			build_tree_from_current_leaf(ctx, child_rpdb, child_leaf, ctx->root_leaf);
		}
	}

	/*check the leaves that should be deleted from topology tree*/
	dl_list_for_each_safe(child_leaf, child_leaf_next, &ctx->root_leaf->children, struct leaf, entry) {
		found = 0;
		for (i = 0; i < ctx->itf_number; i++) {
			LIST_FOREACH(neighor_info, &ctx->p1905_neighbor_dev[i].p1905nbr_head, p1905nbr_entry) {
				if (!os_memcmp(child_leaf->al_mac, neighor_info->al_mac_addr, ETH_ALEN)) {
					found = 1;
					break;
				}
			}
			if (found)
				break;
		}

		child_rpdb = lookup_tprdb_by_almac(ctx, child_leaf->al_mac);

		if (!found || !child_rpdb) {
			notice(DEBUG_CAT_TOPO, "delete leaf (%p)("MACSTR")\n",
				child_leaf, MAC2STR(child_leaf->al_mac));
			delete_tree_from_current_leaf(ctx, child_leaf);
			free_leaf(ctx, child_leaf);
		} else {
			detect_deleted_leaf_from_current_leaf(ctx, child_leaf);
		}
	}

	return 0;
fail:
	return -1;
}

int clear_topology_tree(struct p1905_managerd_ctx* ctx)
{
	delete_tree_from_current_leaf(ctx, ctx->root_leaf);
	os_free(ctx->root_leaf);
	ctx->root_leaf = NULL;

	return 0;
}

int trace_topology_tree_cb(struct p1905_managerd_ctx* ctx, struct leaf *current_leaf, topology_tree_cb_func cb, void *data)
{
	struct leaf *child_leaf = NULL, *child_leaf_next = NULL;

	if (!current_leaf)
		return 0;

	dl_list_for_each_safe(child_leaf, child_leaf_next, &current_leaf->children, struct leaf, entry) {
		cb((void*)ctx, (void*)current_leaf, (void*)child_leaf, data);
		trace_topology_tree_cb(ctx, child_leaf, cb, data);
	}

	return 0;
}

int topology_tree_travel_preorder(struct p1905_managerd_ctx* ctx, struct leaf *current_leaf)
{
	struct leaf *child_leaf = NULL, *child_leaf_next = NULL;
	leaf_info leaf_in;
	struct agent_list_db *agent_info = NULL;

	if (!current_leaf)
		return 0;

	os_memset(&leaf_in, 0, sizeof(leaf_in));

	/*push to stack*/
	notice(DEBUG_CAT_TOPO, "push dev "MACSTR" to stack\n",
		MAC2STR(current_leaf->al_mac));
	os_memcpy(leaf_in.al_mac, current_leaf->al_mac, ETH_ALEN);
#ifdef MAP_R3
		struct r3_member *peer = NULL;
		dl_list_for_each(peer, &r3_member_head, struct r3_member, entry) {
			if (!os_memcmp(peer->al_mac, current_leaf->al_mac, ETH_ALEN)) {
				if (peer->security_1905)
					leaf_in.profile = MAP_PROFILE_R3;
			}
		}
#endif
	if (os_memcmp(current_leaf->al_mac, ctx->p1905_al_mac_addr, ETH_ALEN)) {
		find_agent_info(ctx, current_leaf->al_mac, &agent_info);
		if (agent_info)
			clear_agent_all_radio_config_stat(agent_info);
	}
	push(&ctx->topo_stack, leaf_in);

	dl_list_for_each_safe(child_leaf, child_leaf_next, &current_leaf->children, struct leaf, entry) {
		topology_tree_travel_preorder(ctx, child_leaf);
	}

	return 0;
}

/*this is for GPON feature*/
void detect_neighbor_existence(struct p1905_managerd_ctx *ctx,
	unsigned char *neth_almac, unsigned char *sta_mac)
{
	struct topology_discovery_db *tpg_db = NULL;
	struct neighbor_list_db *ndb = NULL;
	unsigned int i = 0;
	unsigned char remote_almac[ETH_ALEN] = {0};
	unsigned char zero_mac[ETH_ALEN] = {0};
	unsigned char meida = 0;

	if (neth_almac == NULL && sta_mac == NULL) {
		err(DEBUG_CAT_GPON, "invalid input params; need one of neth_almac and sta_mac is non NULL\n");
		return;
	}
	if (neth_almac != NULL && sta_mac != NULL) {
		err(DEBUG_CAT_GPON, "invalid input params; need one of neth_almac and sta_mac is NULL\n");
		return;
	}

	if (neth_almac) {
		os_memcpy(remote_almac, neth_almac, ETH_ALEN);
		meida = 0;
	}
	if (sta_mac) {
		find_neighbor_almac_by_intf_mac(ctx, sta_mac, remote_almac);
		meida = 1;
	}

	if (!os_memcmp(remote_almac, zero_mac, ETH_ALEN))
		return;

	tpg_db = find_discovery_by_almac(ctx, remote_almac);
	if (!tpg_db) {
		notice(DEBUG_CAT_GPON, "skip; no discovery for "MACSTR"\n",
			MAC2STR(remote_almac));
		return;
	}
	if (tpg_db->mtk_tpd == 0) {
		notice(DEBUG_CAT_GPON, "skip non MTK neighbor("MACSTR")\n",
			MAC2STR(remote_almac));
		return;
	}

	notice(DEBUG_CAT_GPON, "need detect if %s neighbor("MACSTR") exists\n",
		(meida ? "wifi" : "eth"), PRINT_MAC(remote_almac));

	LIST_FOREACH(tpg_db, &ctx->topology_entry.tpddb_head, tpddb_entry) {
		if (os_memcmp(tpg_db->al_mac, remote_almac, ETH_ALEN))
			continue;
		SLIST_FOREACH(ndb, &ctx->query_neighbor_head, neighbor_entry) {
			if (!os_memcmp(tpg_db->al_mac, ndb->nalmac, ETH_ALEN) &&
				!os_memcmp(tpg_db->itf_mac, ndb->nitf_mac, ETH_ALEN))
				break;
		}
		if (ndb)
			continue;
		ndb = (struct neighbor_list_db *)malloc(sizeof(struct neighbor_list_db));
		if (ndb == NULL) {
			err(DEBUG_CAT_MISC, "alloc struct neighbor_list_db fail\n");
			return;
		}
	    os_memcpy(ndb->nalmac, tpg_db->al_mac, ETH_ALEN);
		os_memcpy(ndb->nitf_mac, tpg_db->itf_mac, ETH_ALEN);
	    SLIST_INSERT_HEAD(&ctx->query_neighbor_head, ndb, neighbor_entry);
		for(i = 0; i < ctx->itf_number; i++) {
			if (os_memcmp(tpg_db->receive_itf_mac, ctx->itf[i].mac_addr, ETH_ALEN))
				continue;
			ctx->mid++;
			notice(DEBUG_CAT_TOPO, "send multicast discovery_with_vendor_ie with mid=%04x on %s\n",
			      ctx->mid, ctx->itf[i].if_name);
			insert_cmdu_txq(p1905_multicast_address, ctx->p1905_al_mac_addr,
					e_topology_discovery_with_vendor_ie, ctx->mid, ctx->itf[i].if_name, 0);
			eloop_register_timeout(DETECT_NEIGHBOR_TIME, 0, recv_neighbor_disc_timeout,
				(void *)ctx, (void *)ndb);
			break;
		}
	}
}

/**
 *  delete all non-1905.1 neighbor device.
 *
 * \param  non_p1905_dev  pointer of non_1905.1 database
 * \param  retun error code
 */
void delete_non_p1905_neighbor_dev_info(struct non_p1905_neighbor *non_p1905_dev)
{
    int i = 0;
    struct non_p1905_neighbor_info *dev_info, *dev_info_temp;

    for(i=0;i<ITF_NUM;i++)
    {
        if(!LIST_EMPTY(&(non_p1905_dev[i].non_p1905nbr_head)))
        {
            dev_info = LIST_FIRST(&(non_p1905_dev[i].non_p1905nbr_head));
            while(dev_info)
            {
                dev_info_temp = LIST_NEXT(dev_info, non_p1905nbr_entry);
                LIST_REMOVE(dev_info, non_p1905nbr_entry);
                free(dev_info);
                dev_info = dev_info_temp;
            }
        }
    }
}

void recv_neighbor_disc_timeout(void *eloop_data, void *user_ctx)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx*)eloop_data;
	struct neighbor_list_db *ndb = (struct neighbor_list_db *)user_ctx;
	struct topology_discovery_db *tpg_db = NULL, *tpg_db_tmp = NULL;
	struct topology_response_db *tpgr_db = NULL;
	unsigned char del_rsp_cnt = 0;
	int cotroller = 0, i = 0;

	tpg_db = LIST_FIRST(&ctx->topology_entry.tpddb_head);
	while (tpg_db) {
		tpg_db_tmp = LIST_NEXT(tpg_db, tpddb_entry);
		if (!os_memcmp(tpg_db->al_mac, ndb->nalmac, ETH_ALEN) &&
			!os_memcmp(tpg_db->itf_mac, ndb->nitf_mac, ETH_ALEN)) {
			LIST_REMOVE(tpg_db, tpddb_entry);
			notice(DEBUG_CAT_TOPO, "del topology discovery; almac="MACSTR";"
				" peer_itf_mac="MACSTR"\n",
				MAC2STR(tpg_db->al_mac), MAC2STR(tpg_db->itf_mac));
			delete_p1905_neighbor_dev_info(ctx, tpg_db->al_mac,
				(unsigned char *)tpg_db->receive_itf_mac);
			if (find_discovery_by_almac(ctx, tpg_db->al_mac) == NULL) {
				notice(DEBUG_CAT_TOPO, "del topology rsp; almac="MACSTR"\n",
					MAC2STR(tpg_db->al_mac));
				/*topo C--ETH--A1--ETH--A2
				*reboot A1; during A1 get start, A2 will get C topology discovery by ETH
				*PON with MAP logic will run and drop A1 discovery
				*Add this logic to solve the issue mentioned above
				*/
				tpgr_db = find_topology_rsp_by_almac(ctx, tpg_db->al_mac);
				if (tpgr_db) {
					for (i = 0; i < tpgr_db->support_service_cnt; i++) {
						if (tpgr_db->support_service[i] == 0) {
							cotroller = 1;
							break;
						}
					}
					if (cotroller) {
						if (ctx->conn_port.is_set) {
							ctx->conn_port.is_set = 0;
							notice(DEBUG_CAT_GPON, "clear conn_port=%d\n",
								ctx->conn_port.port_num);
						}
					}
					delete_exist_topology_response_database(ctx, tpg_db->al_mac);
					del_rsp_cnt++;
				}
			}
			os_free(tpg_db);
		}
		tpg_db = tpg_db_tmp;
	}

	report_own_topology_rsp(ctx, ctx->p1905_al_mac_addr, ctx->br_cap,
		ctx->p1905_neighbor_dev, ctx->non_p1905_neighbor_dev,
       	ctx->service, &ctx->ap_cap_entry.oper_bss_head,
        &ctx->ap_cap_entry.assoc_clients_head, ctx->cnt);

	if (del_rsp_cnt)
		mark_valid_topo_rsp_node(ctx);

	SLIST_REMOVE(&ctx->query_neighbor_head, ndb, neighbor_list_db, neighbor_entry);
	os_free(ndb);
}

void check_neighbor_discovery(struct p1905_managerd_ctx *ctx,
	unsigned char *al_mac, unsigned char *itf_mac)
{
	struct neighbor_list_db *ndb = NULL;
	int ret = 0;

	SLIST_FOREACH(ndb, &ctx->query_neighbor_head, neighbor_entry) {
		if (!os_memcmp(ndb->nalmac, al_mac, ETH_ALEN) &&
			!os_memcmp(ndb->nitf_mac, itf_mac, ETH_ALEN)) {
			break;
		}
	}
	if (!ndb)
		return;

	ret= eloop_is_timeout_registered(recv_neighbor_disc_timeout, ctx, ndb);
	if (ret) {
		notice(DEBUG_CAT_GPON, "receive neighbor discovery; almac="MACSTR"; "
			"peer_intf="MACSTR"\n", MAC2STR(al_mac), MAC2STR(itf_mac));
		eloop_cancel_timeout(recv_neighbor_disc_timeout, ctx, ndb);
		SLIST_REMOVE(&ctx->query_neighbor_head, ndb, neighbor_list_db, neighbor_entry);
		os_free(ndb);
	}
}

void topology_discovery_action(struct p1905_managerd_ctx *ctx, unsigned char *peer_al_mac,
			       unsigned char need_query, unsigned char need_notify)
{
	if (need_query) {
		insert_cmdu_txq(peer_al_mac, ctx->p1905_al_mac_addr, e_topology_query, ++ctx->mid,
				ctx->itf[ctx->recent_cmdu_rx_if_number].if_name, 0);
		notice(DEBUG_CAT_TOPO, "send topo query to "MACSTR" with mid=%04x on %s\n",
			    MAC2STR(peer_al_mac), ctx->mid, ctx->itf[ctx->recent_cmdu_rx_if_number].if_name);
	}
	if (need_notify == 1) {
		ctx->mid++;
		multicast_cmdu_tx(ctx, e_topology_notification, ctx->mid, 1);
	} else if (need_notify == 2) {
		ctx->mid++;
		fill_send_tlv(ctx, peer_al_mac, ETH_ALEN);
		multicast_cmdu_tx(ctx, e_topology_notification_with_vendor_ie, ctx->mid, 1);
	}
}

/**
 *  add/update 1905.1 neighbor device information.
 *
 * \param  ctx  1905.1 managerd context
 * \param  al_mac  neighbor al mac addr in topology discovery message.
 * \param  neighbor_itf_mac  neighbor device interface mac in topology discover.
 * \param  itf_mac_addr  the interface topology discovery received from.
 * \param  notify  if need to send topology notify, set this flag
 * \param  retun error code
 */
int update_p1905_neighbor_dev_info(struct p1905_managerd_ctx *ctx,
				   unsigned char *al_mac, unsigned char *neighbor_itf_mac,
				   unsigned char *itf_mac_addr, unsigned char *notify)
{
	int i = 0;
	struct p1905_neighbor_info *dev_info = NULL;

	for (i = 0; i < ctx->itf_number; i++) {
		if (!memcmp(ctx->p1905_neighbor_dev[i].local_mac_addr, itf_mac_addr, ETH_ALEN))
			break;
	}
	if (i >= ctx->itf_number) {
		err(DEBUG_CAT_TOPO, "no local interface with addr "MACSTR"\n", MAC2STR(itf_mac_addr));
		return -1;
	}

	if (!LIST_EMPTY(&ctx->p1905_neighbor_dev[i].p1905nbr_head)) {
		LIST_FOREACH(dev_info, &ctx->p1905_neighbor_dev[i].p1905nbr_head, p1905nbr_entry) {
			if (!memcmp(dev_info->al_mac_addr, al_mac, ETH_ALEN)) {
				if (dev_info->ieee802_1_bridge == 0) {
					/* can not find any matched mac address in LLDP storage
					 * it means that local device just receive the topology
					 * discovery but no 802.1 bridge detection message.
					 * so a 802.1 bridge exist
					 */
					if (find_lldp_by_port_id_mac(itf_mac_addr, neighbor_itf_mac) == 0) {
						dev_info->ieee802_1_bridge = 1;
						*notify = 1;
					}
				}
				return 0;
			}
		}
	}

	dev_info = (struct p1905_neighbor_info *)malloc(sizeof(struct p1905_neighbor_info));
	if (!dev_info) {
		err(DEBUG_CAT_MISC, "alloc dev_info fail\n");
		return -1;
	}
	memcpy(dev_info->al_mac_addr, al_mac, ETH_ALEN);
	dev_info->ieee802_1_bridge = 1;
	LIST_INSERT_HEAD(&ctx->p1905_neighbor_dev[i].p1905nbr_head, dev_info, p1905nbr_entry);
	notice(DEBUG_CAT_TOPO, "local intf(%s) add 1905 neighbor "MACSTR"\n",
	      ctx->itf[i].if_name, MAC2STR(al_mac));
	/*need to send topology notification message */
	*notify = 1;

	return 0;
}

/**
 *  delete 1905.1 topology response database.
 *
 * \param  ctx  1905.1 managerd context
 * \param  al_mac  input the target device al mac to delete.
 */
void delete_exist_topology_response_database(struct p1905_managerd_ctx *ctx, unsigned char *al_mac)
{
	struct topology_response_db *tpgr_db;
	struct device_info_db *dev_info, *dev_info_temp;
	struct p1905_neighbor_device_db *p1905_neighbor, *p1905_neighbor_temp;
	struct non_p1905_neighbor_device_list_db *non_p1905_neighbor, *non_p1905_neighbor_temp;
	struct device_bridge_capability_db *br_cap, *br_cap_temp;

	if (!SLIST_EMPTY(&(ctx->topology_entry.tprdb_head))) {
		SLIST_FOREACH(tpgr_db, &(ctx->topology_entry.tprdb_head), tprdb_entry) {
			if (!memcmp(tpgr_db->al_mac_addr, al_mac, ETH_ALEN)) {
				notice(DEBUG_CAT_TOPO, "del topo rsp; almac="MACSTR"\n",
					MAC2STR(tpgr_db->al_mac_addr));
				if (!SLIST_EMPTY(&(tpgr_db->devinfo_head))) {
					dev_info = SLIST_FIRST(&(tpgr_db->devinfo_head));
					while (dev_info) {
						dev_info_temp = SLIST_NEXT(dev_info, devinfo_entry);
						if (!SLIST_EMPTY(&(dev_info->p1905_nbrdb_head))) {
							/*delete all p1905.1 device in this interface */
							p1905_neighbor = SLIST_FIRST(&(dev_info->p1905_nbrdb_head));
							while (p1905_neighbor) {
								p1905_neighbor_temp =
								    SLIST_NEXT(p1905_neighbor, p1905_nbrdb_entry);

								SLIST_REMOVE(&(dev_info->p1905_nbrdb_head),
									     p1905_neighbor, p1905_neighbor_device_db,
									     p1905_nbrdb_entry);
								free(p1905_neighbor);
								p1905_neighbor = p1905_neighbor_temp;
							}
						}

						/*delete all non-p1905.1 device in this interface */
						if (!SLIST_EMPTY(&(dev_info->non_p1905_nbrdb_head))) {
							non_p1905_neighbor =
							    SLIST_FIRST(&(dev_info->non_p1905_nbrdb_head));
							while (non_p1905_neighbor) {
								non_p1905_neighbor_temp =
								    SLIST_NEXT(non_p1905_neighbor,
									       non_p1905_nbrdb_entry);

								SLIST_REMOVE(&(dev_info->non_p1905_nbrdb_head),
									     non_p1905_neighbor,
									     non_p1905_neighbor_device_list_db,
									     non_p1905_nbrdb_entry);
								free(non_p1905_neighbor);
								non_p1905_neighbor = non_p1905_neighbor_temp;
							}
						}
						/*remove this device info db from list */
						SLIST_REMOVE(&(tpgr_db->devinfo_head), dev_info,
							     device_info_db, devinfo_entry);
						/*delete this device info db */
						if (dev_info->vs_info_len)
							free(dev_info->vs_info);

						free(dev_info);
						dev_info = dev_info_temp;
					}
				}

				/*delete bridge capability info */
				if (!LIST_EMPTY(&(tpgr_db->brcap_head))) {
					br_cap = LIST_FIRST(&(tpgr_db->brcap_head));
					while (br_cap) {
						br_cap_temp = LIST_NEXT(br_cap, brcap_entry);
						LIST_REMOVE(br_cap, brcap_entry);

						if (br_cap->interface_amount)
							free(br_cap->interface_mac_tuple);

						free(br_cap);
						br_cap = br_cap_temp;
					}
				}
				/*finall, delete whole topology response with this AL MAC */
				SLIST_REMOVE(&(ctx->topology_entry.tprdb_head), tpgr_db,
					     topology_response_db, tprdb_entry);
				free(tpgr_db);
				return;
			}
		}
	}
}

void update_bridge_cap(struct list_head_brcap *dst_br_head, struct list_head_brcap *src_br_head)
{
	struct device_bridge_capability_db *br = NULL;
	struct device_bridge_capability_db *br_temp = NULL;

	if (!dst_br_head || !src_br_head)
		return;
	if (LIST_EMPTY(src_br_head))
		return;

	br = LIST_FIRST(src_br_head);
	while (br) {
		br_temp = LIST_NEXT(br, brcap_entry);
		LIST_REMOVE(br, brcap_entry);
		LIST_INSERT_HEAD(dst_br_head, br, brcap_entry);
		br = br_temp;
	}
}

void update_dev_info(struct list_head_devinfo *dst_devinfo_head, struct list_head_devinfo *src_devinfo_head)
{
	struct device_info_db *dev = NULL;
	struct device_info_db *dev_tmp = NULL;

	if (!dst_devinfo_head || !src_devinfo_head)
		return;
	if (SLIST_EMPTY(src_devinfo_head))
		return;

	dev = SLIST_FIRST(src_devinfo_head);
	while (dev) {
		dev_tmp = SLIST_NEXT(dev, devinfo_entry);
		SLIST_REMOVE(src_devinfo_head, dev, device_info_db, devinfo_entry);
		SLIST_INSERT_HEAD(dst_devinfo_head, dev, devinfo_entry);
		dev = dev_tmp;
	}
}

struct topology_response_db *delete_exist_topology_response_content(struct p1905_managerd_ctx *ctx,
	unsigned char *al_mac)
{
	struct topology_response_db *tpgr_db = NULL;
	struct device_info_db *dev_info, *dev_info_temp;
	struct p1905_neighbor_device_db *p1905_neighbor, *p1905_neighbor_temp;
	struct non_p1905_neighbor_device_list_db *non_p1905_neighbor, *non_p1905_neighbor_temp;
	struct device_bridge_capability_db *br_cap, *br_cap_temp;

	SLIST_FOREACH(tpgr_db, &(ctx->topology_entry.tprdb_head), tprdb_entry) {
		if (os_memcmp(tpgr_db->al_mac_addr, al_mac, ETH_ALEN))
			continue;

		dev_info = SLIST_FIRST(&tpgr_db->devinfo_head);
		while (dev_info) {
			dev_info_temp = SLIST_NEXT(dev_info, devinfo_entry);
			/*delete all p1905.1 device in this interface */
			p1905_neighbor = SLIST_FIRST(&dev_info->p1905_nbrdb_head);
			while (p1905_neighbor) {
				p1905_neighbor_temp = SLIST_NEXT(p1905_neighbor, p1905_nbrdb_entry);
				SLIST_REMOVE(&dev_info->p1905_nbrdb_head,
					     p1905_neighbor, p1905_neighbor_device_db, p1905_nbrdb_entry);
				free(p1905_neighbor);
				p1905_neighbor = p1905_neighbor_temp;
			}
			/*delete all non-p1905.1 device in this interface */
			non_p1905_neighbor = SLIST_FIRST(&dev_info->non_p1905_nbrdb_head);
			while (non_p1905_neighbor) {
				non_p1905_neighbor_temp = SLIST_NEXT(non_p1905_neighbor, non_p1905_nbrdb_entry);
				SLIST_REMOVE(&dev_info->non_p1905_nbrdb_head,
					     non_p1905_neighbor, non_p1905_neighbor_device_list_db,
					     non_p1905_nbrdb_entry);
				free(non_p1905_neighbor);
				non_p1905_neighbor = non_p1905_neighbor_temp;
			}
			/*remove this device info db from list */
			SLIST_REMOVE(&tpgr_db->devinfo_head, dev_info, device_info_db, devinfo_entry);
			/*delete this device info db */
			if (dev_info->vs_info_len)
				free(dev_info->vs_info);

			free(dev_info);
			dev_info = dev_info_temp;
		}

		/*delete bridge capability info */
		br_cap = LIST_FIRST(&tpgr_db->brcap_head);
		while (br_cap) {
			br_cap_temp = LIST_NEXT(br_cap, brcap_entry);
			LIST_REMOVE(br_cap, brcap_entry);

			if (br_cap->interface_amount)
				free(br_cap->interface_mac_tuple);

			free(br_cap);
			br_cap = br_cap_temp;
		}
		return tpgr_db;
	}

	return tpgr_db;
}

void delete_exist_topology_discovery_database(struct p1905_managerd_ctx *ctx,
					      unsigned char *al_mac, unsigned char *itf_mac)
{
	struct topology_discovery_db *tpg_db = NULL;

	if (!LIST_EMPTY(&ctx->topology_entry.tpddb_head)) {
		LIST_FOREACH(tpg_db, &ctx->topology_entry.tpddb_head, tpddb_entry) {
			if (!memcmp(tpg_db->al_mac, al_mac, 6) && !memcmp(tpg_db->itf_mac, itf_mac, 6)) {
				delete_p1905_neighbor_dev_info(ctx, tpg_db->al_mac,
							       (unsigned char *)tpg_db->receive_itf_mac);
				/*delete the topology discovery database */
				LIST_REMOVE(tpg_db, tpddb_entry);
				notice(DEBUG_CAT_TOPO, "del discovery; almac="MACSTR"; "
					"peer_intf="MACSTR"; local_recv_intf="MACSTR"\n",
					MAC2STR(tpg_db->al_mac), MAC2STR(tpg_db->itf_mac),
					MAC2STR(tpg_db->receive_itf_mac));
				free(tpg_db);
				return;
			}
		}
	}
}

/*
Fn to delete the topology rsp db by port by local interface mac address
	port == -1 delete by local interface mac address
	local_mac == NULL delete by port number index
*/
void delete_topo_response_db_by_port_interface(struct p1905_managerd_ctx *ctx, int port)
{
	struct topology_response_db *tpgr_db = NULL, *tpgr_db_tmp = NULL;
	unsigned char del_cnt = 0;

	if (port == -1) {
		err(DEBUG_CAT_TOPO, "error; port=-1\n");
		return;
	}

	tpgr_db = SLIST_FIRST(&ctx->topology_entry.tprdb_head);
	while (tpgr_db) {
		tpgr_db_tmp = SLIST_NEXT(tpgr_db, tprdb_entry);
		if (tpgr_db->eth_port == port) {
			delete_exist_topology_response_database(ctx, tpgr_db->al_mac_addr);
			del_cnt++;
		}
		tpgr_db = tpgr_db_tmp;
	}

	if (del_cnt)
		mark_valid_topo_rsp_node(ctx);
}

/*
Fn to delete the discovery db by port number or local interface mac address
	port == -1 delete by local interface mac address
	local_mac == NULL delete by port number index
*/
int delete_topo_disc_db_by_port(struct p1905_managerd_ctx *ctx, int port, unsigned char *exclude_almac)
{
	struct topology_discovery_db *db = NULL, *db_temp = NULL;
	int cnt = 0, del_rsp_cnt = 0;

	if (port == -1)
		return cnt;

	if (!LIST_EMPTY(&ctx->topology_entry.tpddb_head)) {
		db = LIST_FIRST(&ctx->topology_entry.tpddb_head);
		while (db) {
			db_temp = LIST_NEXT(db, tpddb_entry);
			if (db->eth_port == port) {
				if (exclude_almac && !os_memcmp(exclude_almac, db->al_mac, ETH_ALEN)) {
					db = db_temp;
					continue;
				}
				delete_p1905_neighbor_dev_info(ctx, db->al_mac, db->receive_itf_mac);
				LIST_REMOVE(db, tpddb_entry);
				cnt++;
				notice(DEBUG_CAT_TOPO, "del discovery; almac="MACSTR"; peer_intf="MACSTR";"
					" recv_intf="MACSTR"; port=%d\n",
					MAC2STR(db->al_mac), MAC2STR(db->itf_mac),
				    MAC2STR(db->receive_itf_mac), db->eth_port);
				if (find_discovery_by_almac(ctx, db->al_mac) == NULL) {
					notice(DEBUG_CAT_TOPO, "no discovery in db; del topology rsp\n");
					delete_exist_topology_response_database(ctx, db->al_mac);
					del_rsp_cnt++;
				}
				os_free(db);
			}
			db = db_temp;
		}
	}

	if (del_rsp_cnt)
		mark_valid_topo_rsp_node(ctx);

	return cnt;
}

/**
 *  delete one 1905.1 neighbor device.
 *
 * \param  ctx  1905.1 managerd context
 * \param  al_mac  input the neighbor device al mac to delete.
 * \param  retun error code
 */
int delete_p1905_neighbor_dev_info(struct p1905_managerd_ctx *ctx, unsigned char *al_mac, unsigned char *recvif_mac)
{
	int i = 0;
	struct p1905_neighbor_info *dev_info;
#ifdef MAP_R3
	struct r3_member *peer = NULL;
	unsigned int wait_time = 30;
#endif

	for (i = 0; i < ctx->itf_number; i++) {
		if (!memcmp(recvif_mac, ctx->itf[i].mac_addr, ETH_ALEN)) {
			LIST_FOREACH(dev_info, &ctx->p1905_neighbor_dev[i].p1905nbr_head, p1905nbr_entry) {
				if (!memcmp(dev_info->al_mac_addr, al_mac, ETH_ALEN)) {
					notice(DEBUG_CAT_TOPO, "delete neighbor("MACSTR") on %s\n",
					      MAC2STR(al_mac), ctx->itf[i].if_name);
#ifdef MAP_R3
					if (ctx->MAP_Cer) {
						wait_time = 300;
						ptk_peer_reset_encrypt_txrx_counter(al_mac);
					}
					peer = get_r3_member(al_mac);
					if (peer) {
						notice(DEBUG_CAT_DPP, "delete R3 security info for "MACSTR" after %d sec\n",
							MAC2STR(al_mac), wait_time);
						eloop_cancel_timeout(timeout_delete_r3_member,
							(void *)ctx, (void *)peer);
						eloop_register_timeout(wait_time, 0,
							timeout_delete_r3_member, (void *)ctx, (void *)peer);
					}
#endif
					LIST_REMOVE(dev_info, p1905nbr_entry);
					free(dev_info);
#ifdef EM_PLUS_SUPPORT
				for (int j = 0; j < ctx->itf_number; j++) {
					if (!memcmp(recvif_mac, ctx->itf[j].mac_addr, ETH_ALEN)
						&& (ctx->itf[j].update_vlan_tag == 1)
						&& (!ctx->itf[j].is_wifi_ap)) {
						notice(DEBUG_CAT_TOPO, "delete vlan interface %s", ctx->itf[j].if_name);
						update_vlan_tag_inf(ctx, ctx->itf[j].if_name, 0);
						ctx->itf[j].update_vlan_tag = 0;
					}
				}
#endif
					return 1;
				}
			}
		}
	}

	return 0;
}

struct topology_discovery_db *get_tpd_db_by_mac(struct p1905_managerd_ctx *ctx, unsigned char *mac)
{
	struct topology_discovery_db *tpg_db = NULL;

	LIST_FOREACH(tpg_db, &(ctx->topology_entry.tpddb_head), tpddb_entry) {
		if (!os_memcmp(tpg_db->itf_mac, mac, ETH_ALEN))
			break;
	}

	return tpg_db;
}

struct topology_response_db *get_trsp_db_by_mac(struct p1905_managerd_ctx *ctx, unsigned char *mac)
{
	struct topology_response_db *trsp_db = NULL;

	SLIST_FOREACH(trsp_db, &(ctx->topology_entry.tprdb_head), tprdb_entry) {
		if (!os_memcmp(trsp_db->al_mac_addr, mac, ETH_ALEN))
			break;
	}

	return trsp_db;
}

/**
 *  update the time to live for topology dicovery message.
 *  if value of time to live is less than 0, need to delete this record
 *
 *
 * \param  ctx  1905.1 managerd context
 * \param  sec  for 1905.1 managerd use.
 * \return error code
 */
int delete_not_exist_p1905_neighbor_device(struct p1905_managerd_ctx *ctx, int sec)
{
	struct topology_discovery_db *tpg_db, *tpg_db_temp;
	int result = 0;
	char del_rsp_cnt = 0;

	if (!LIST_EMPTY(&ctx->topology_entry.tpddb_head)) {
		tpg_db = LIST_FIRST(&ctx->topology_entry.tpddb_head);
		while (tpg_db) {
			tpg_db_temp = LIST_NEXT(tpg_db, tpddb_entry);
			tpg_db->time_to_live -= sec;
			if (tpg_db->time_to_live <= 0) {
				/*delete the local p1905.1 neighbor device info */
				err(DEBUG_CAT_TOPO, "timeout! del discovery; almac="MACSTR"; "
					" peer_intf="MACSTR"; recv_local_intf="MACSTR"\n",
					MAC2STR(tpg_db->al_mac), MAC2STR(tpg_db->itf_mac),
				    MAC2STR(tpg_db->receive_itf_mac));
				if (delete_p1905_neighbor_dev_info
				    (ctx, tpg_db->al_mac, (unsigned char *)tpg_db->receive_itf_mac))
					result = 1;
				/*delete the topology discovery database */
				LIST_REMOVE(tpg_db, tpddb_entry);
				if (find_discovery_by_almac(ctx, tpg_db->al_mac) == NULL) {
					err(DEBUG_CAT_TOPO, "no discovery in db; del rsp\n");
					delete_exist_topology_response_database(ctx, tpg_db->al_mac);
					del_rsp_cnt++;
				}
				unmask_control_conn_port(ctx, tpg_db->eth_port);
				free(tpg_db);
			}
			tpg_db = tpg_db_temp;
		}
	}
#ifdef EM_PLUS_EXT_SUPPORT
	if (ctx->gw_agent_dcv.time_to_live > 0)
		ctx->gw_agent_dcv.time_to_live -= sec;
#endif

	if (del_rsp_cnt)
		mark_valid_topo_rsp_node(ctx);

	return result;
}

void delete_not_exist_p1905_topology_device(struct p1905_managerd_ctx *ctx, int sec)
{
	struct topology_device_db *tpdev_db, *tpdev_db_temp;

	if (!SLIST_EMPTY(&ctx->topodev_entry.tpdevdb_head)) {
		tpdev_db = SLIST_FIRST(&ctx->topodev_entry.tpdevdb_head);
		while (tpdev_db) {
			tpdev_db_temp = SLIST_NEXT(tpdev_db, tpdev_entry);
			tpdev_db->time_to_live -= sec;
			if (tpdev_db->time_to_live <= 0) {
				SLIST_REMOVE(&ctx->topodev_entry.tpdevdb_head,
					     tpdev_db, topology_device_db, tpdev_entry);
				free(tpdev_db);
			}
			tpdev_db = tpdev_db_temp;
		}
	}
}

void query_neighbor_info(struct p1905_managerd_ctx *ctx, unsigned char *almac, unsigned int if_number)
{
	struct topology_response_db *tpgr = NULL, *tpgr_tmp = NULL;
	struct device_info_db *dev_info = NULL;
	struct p1905_neighbor_device_db *dev = NULL;
	unsigned char exist = 0;

	SLIST_FOREACH(tpgr, &ctx->topology_entry.tprdb_head, tprdb_entry) {
		if (!os_memcmp(tpgr->al_mac_addr, almac, 6))
			break;
	}

	if (!tpgr) {
		err(DEBUG_CAT_TOPO, "no dev "MACSTR" in topo rsp db\n", MAC2STR(almac));
		return;
	}

	SLIST_FOREACH(dev_info, &tpgr->devinfo_head, devinfo_entry) {
		SLIST_FOREACH(dev, &dev_info->p1905_nbrdb_head, p1905_nbrdb_entry) {
			if (!os_memcmp(dev->p1905_neighbor_al_mac, ctx->p1905_al_mac_addr, ETH_ALEN))
				continue;

			exist = 0;
			SLIST_FOREACH(tpgr_tmp, &ctx->topology_entry.tprdb_head, tprdb_entry) {
				if (os_memcmp(tpgr_tmp->al_mac_addr, almac, ETH_ALEN)) {
					if (!os_memcmp(tpgr_tmp->al_mac_addr, dev->p1905_neighbor_al_mac, ETH_ALEN) &&
					    (tpgr_tmp->valid == 1)) {
						exist = 1;
						break;
					}
				}
			}
			if (!exist) {
				insert_cmdu_txq(dev->p1905_neighbor_al_mac, ctx->p1905_al_mac_addr,
						e_topology_query, ++ctx->mid, ctx->itf[if_number].if_name, 0);
				notice(DEBUG_CAT_TOPO, "send topo query to "MACSTR"(not in topo rsp db) with mid=%04x on %s\n",
					MAC2STR(dev->p1905_neighbor_al_mac), ctx->mid, ctx->itf[if_number].if_name);
			}
		}
	}
}

int insert_topology_discovery_database(struct p1905_managerd_ctx *ctx,
		unsigned char *al_mac, unsigned char *itf_mac, unsigned char *recv_itf_mac)
{
	struct topology_discovery_db *tpg_db = NULL;

	LIST_FOREACH(tpg_db, &ctx->topology_entry.tpddb_head, tpddb_entry) {
		if (!os_memcmp(tpg_db->al_mac, al_mac, 6) && !os_memcmp(tpg_db->itf_mac, itf_mac, 6)) {
			return 0;
		}
	}

	if (!tpg_db) {
		tpg_db = (struct topology_discovery_db *)malloc(sizeof(struct topology_discovery_db));
		if (!tpg_db) {
			err(DEBUG_CAT_MISC, "alloc struct topology_discovery_db fail\n");
			return -1;
		}
		os_memset(tpg_db, 0, sizeof(*tpg_db));
		os_memcpy(tpg_db->al_mac, al_mac, ETH_ALEN);
		os_memcpy(tpg_db->itf_mac, itf_mac, ETH_ALEN);
		os_memcpy(tpg_db->receive_itf_mac, recv_itf_mac, ETH_ALEN);
		tpg_db->time_to_live = TOPOLOGY_DISCOVERY_TTL;
		LIST_INSERT_HEAD(&ctx->topology_entry.tpddb_head, tpg_db, tpddb_entry);
		err(DEBUG_CAT_TOPO, "insert discovery db; al_mac="MACSTR"; peer_intf="MACSTR";"
			" local_recv_intf="MACSTR"\n",
			MAC2STR(al_mac), MAC2STR(itf_mac), MAC2STR(recv_itf_mac));
	}

	return 1;
}

struct topology_discovery_db *find_discovery_by_almac(struct p1905_managerd_ctx *ctx, unsigned char *al_mac)
{
	struct topology_discovery_db *tpg_db = NULL;

	LIST_FOREACH(tpg_db, &ctx->topology_entry.tpddb_head, tpddb_entry) {
		if (!os_memcmp(tpg_db->al_mac, al_mac, ETH_ALEN)) {
			return tpg_db;
		}
	}

	return tpg_db;
}

void find_neighbor_almac_by_intf_mac(struct p1905_managerd_ctx *ctx, unsigned char *itf_mac, unsigned char *almac)
{
	struct topology_discovery_db *tpg_db = NULL;
	struct topology_response_db *tpgr_db = NULL;
	struct device_info_db *dev_db = NULL;

	SLIST_FOREACH(tpgr_db, &ctx->topology_entry.tprdb_head, tprdb_entry) {
		SLIST_FOREACH(dev_db, &tpgr_db->devinfo_head, devinfo_entry) {
			if (!os_memcmp(dev_db->mac_addr, itf_mac, ETH_ALEN))
				break;
		}
		if (dev_db)
			break;
	}

	if (!tpgr_db) {
		notice(DEBUG_CAT_TOPO, "cannot find tpgr_db by itf_mac "MACSTR"\n", MAC2STR(itf_mac));
		return;
	}

	LIST_FOREACH(tpg_db, &ctx->topology_entry.tpddb_head, tpddb_entry) {
		if (!os_memcmp(tpg_db->al_mac, tpgr_db->al_mac_addr, ETH_ALEN)) {
			os_memcpy(almac, tpg_db->al_mac, ETH_ALEN);
			notice(DEBUG_CAT_TOPO, "find neighbor "MACSTR" based on sta mac "MACSTR"\n",
			      MAC2STR(tpg_db->al_mac), MAC2STR(itf_mac));
			break;
		}
	}
}

struct topology_response_db *find_response_by_almac(struct p1905_managerd_ctx *ctx, unsigned char *al_mac)
{
	struct topology_response_db *tpgr_db = NULL;

	SLIST_FOREACH(tpgr_db, &ctx->topology_entry.tprdb_head, tprdb_entry) {
		if (!os_memcmp(tpgr_db->al_mac_addr, al_mac, ETH_ALEN)) {
			return tpgr_db;
		}
	}

	return tpgr_db;
}

int find_almac_by_connect_mac(struct p1905_managerd_ctx *ctx, unsigned char *mac, unsigned char *almac)
{
	struct topology_discovery_db *tpg_db = NULL;
	struct topology_response_db *tpgr_db = NULL;
	struct device_info_db *dev_info = NULL;

	LIST_FOREACH(tpg_db, &ctx->topology_entry.tpddb_head, tpddb_entry) {
		if (!os_memcmp(tpg_db->itf_mac, mac, ETH_ALEN)) {
			os_memcpy(almac, tpg_db->al_mac, ETH_ALEN);
			return 1;
		}
	}

	SLIST_FOREACH(tpgr_db, &ctx->topology_entry.tprdb_head, tprdb_entry) {
		SLIST_FOREACH(dev_info, &tpgr_db->devinfo_head, devinfo_entry) {
			if (!os_memcmp(dev_info->mac_addr, mac, ETH_ALEN)) {
				os_memcpy(almac, tpgr_db->al_mac_addr, ETH_ALEN);
				return 2;
			}
		}
	}

	return 0;
}

/*used for PON with MAP device feature
*need reform mesh topology to tree topology in agent side
*/
void mask_control_conn_port(struct p1905_managerd_ctx *ctx, struct topology_response_db *tpgr_db)
{
	struct topology_discovery_db *tpg_db = NULL;
	int rsp_port = 0, disc_port = 0;
	unsigned char role = AGENT;
	int i = 0;

	if (ctx->role == CONTROLLER || ctx->conn_port.is_set)
		return;

	for (i = 0; i < tpgr_db->support_service_cnt; i++) {
		if (tpgr_db->support_service[i] == 0) {
			role = CONTROLLER;
			break;
		}
	}
	rsp_port = tpgr_db->eth_port;

	if (role == CONTROLLER && rsp_port >= 0) {
		tpg_db = find_discovery_by_almac(ctx, tpgr_db->al_mac_addr);
		if (!tpg_db) {
			struct device_info_db *dev_info = NULL;
			struct p1905_neighbor_device_db *p1905_neighbor = NULL;
			struct topology_discovery_db *tpgd_child = NULL;

			/* Foreach controller neighor, find the neighbor which connect current dev with swtich,
			* mark it as controller_agent, make this eth port as controller port, clear related topo
			* info except the controller_agent. This marked eth port later just receive the discovery
			* from the controller_agent.
			*/
			SLIST_FOREACH(dev_info, &tpgr_db->devinfo_head, devinfo_entry) {
				SLIST_FOREACH(p1905_neighbor, &dev_info->p1905_nbrdb_head, p1905_nbrdb_entry) {
					tpgd_child = find_discovery_by_almac(ctx, p1905_neighbor->p1905_neighbor_al_mac);
					if (tpgd_child && (tpgd_child->eth_port == rsp_port)) {
						notice(DEBUG_CAT_GPON, "recv rsp & discovery of the agent connected to controlelr from the same"
							" eth_port; set conn_port=%d\n", rsp_port);
						ctx->conn_port.is_set = 1;
						ctx->conn_port.port_num = rsp_port;
						os_memcpy(ctx->conn_port.filter_almac, tpgd_child->al_mac, ETH_ALEN);
						delete_topo_disc_db_by_port(ctx, ctx->conn_port.port_num, ctx->conn_port.filter_almac);
						return;
					}
				}
			}
			return;
		}
		disc_port = tpg_db->eth_port;
		if (disc_port == rsp_port) {
			/*receive response & discovery from same eth port, need mark this port
			 *as controller-connect port. need drop all agents' MC message.
			 */
			/*check if need set controller-conncet port */
			notice(DEBUG_CAT_GPON, "recv controller rsp & discovery from the same eth_port;"
					" set conn_port=%d\n", rsp_port);
			ctx->conn_port.is_set = 1;
			ctx->conn_port.port_num = rsp_port;
			os_memcpy(ctx->conn_port.filter_almac, tpgr_db->al_mac_addr, ETH_ALEN);
			/*delete existing neighbor info except for controller */
			delete_topo_disc_db_by_port(ctx, ctx->conn_port.port_num, ctx->conn_port.filter_almac);
		} else {
			err(DEBUG_CAT_GPON, "port different!!! recv_topo_rsp_port=%d; recv_topo_discovery_port=%d\n",
			      rsp_port, disc_port);
		}
	}
}

void unmask_control_conn_port(struct p1905_managerd_ctx *ctx, int port)
{
	if (ctx->conn_port.is_set && (port == ctx->conn_port.port_num)) {
		ctx->conn_port.is_set = 0;
		notice(DEBUG_CAT_GPON, "clear conn_port(%d)\n", port);
	}
}

void report_own_topology_rsp(struct p1905_managerd_ctx *ctx,
	unsigned char *al_mac, struct bridge_capabiltiy *br_cap_list,
	struct p1905_neighbor *p1905_dev, struct non_p1905_neighbor *non_p1905_dev,
	unsigned char service, struct list_head_oper_bss *opbss_head,
    struct list_head_assoc_clients *asscli_head, unsigned int cnt)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	unsigned short length = 0;
	unsigned short total_tlvs_length = 0;
	int i = 0;
	unsigned char separate = 0;

    length = append_device_info_type_tlv(tlv_temp_buf, al_mac, ctx);
    total_tlvs_length += length;
    tlv_temp_buf += length;

    length = append_device_bridge_capability_type_tlv(tlv_temp_buf, br_cap_list);
    total_tlvs_length += length;
    tlv_temp_buf += length;

	for (i = 0; i < ctx->itf_number; i++) {
		do {
			length = append_p1905_neighbor_device_type_tlv(tlv_temp_buf, p1905_dev, i, &separate);
			total_tlvs_length += length;
			tlv_temp_buf += length;
		} while (separate);
	}

	separate = 0;
	/*append non-p1905.1 device tlv*/
	for (i = 0; i < ctx->itf_number; i++) {
		do {
			length = append_non_p1905_neighbor_device_type_tlv(tlv_temp_buf,
				non_p1905_dev, i, &separate);
			total_tlvs_length += length;
			tlv_temp_buf += length;
		} while (separate);
	}

	length = append_supported_service_tlv(tlv_temp_buf, service);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	length = append_operational_bss_tlv(ctx, tlv_temp_buf, opbss_head);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	length = append_associated_clients_tlv(tlv_temp_buf, asscli_head);
	total_tlvs_length += length;
	tlv_temp_buf += length;

#ifdef MAP_R4_SPT
	if (ctx->map_version >= DEV_TYPE_R3) {
#ifdef EM_PLUS_EXT_SUPPORT
		if (!ctx->security_enabled && ctx->map_version == MAP_PROFILE_R3)
			length = append_map_version_tlv(tlv_temp_buf, MAP_PROFILE_R2);
		else
#endif
			length = append_map_version_tlv(tlv_temp_buf, ctx->map_version);
		total_tlvs_length += length;
		tlv_temp_buf += length;
	}
#endif

#ifdef MAP_R3
	if ((ctx->map_version == (unsigned char)MAP_PROFILE_R3)) {
		length = append_bss_config_report_tlv(tlv_temp_buf, ctx);
		total_tlvs_length += length;
		tlv_temp_buf += length;
	}
#endif // MAP_R3
#ifdef MAP_R6
	{
		struct assoc_client *client = NULL;

		for (i = 0; i < HASH_TABLE_SIZE; i++) {
			if (dl_list_empty(&ctx->clients_table[i]))
				continue;
			dl_list_for_each(client, &ctx->clients_table[i], struct assoc_client, entry) {
				if (dl_list_empty(&client->sta_mld.mlo_sta_list))
					continue;
				length = append_assoc_sta_mld_cfg_rpt_tlv(&client->sta_mld, tlv_temp_buf);
				total_tlvs_length += length;
				tlv_temp_buf += length;
			}
		}
	}
#endif


	if (total_tlvs_length > 10240) {
		err(DEBUG_CAT_EVENT, "send length(%d) exceeds max revd_tlv len(10240)\n",
			total_tlvs_length);
		return;
	}
	reset_stored_tlv(ctx);
	store_revd_tlvs(ctx, ctx->tlv_buf.buf, total_tlvs_length);
	os_get_time(&ctx->own_topo_rsp_update_time);
	_1905_notify_topology_rsp_event(ctx, ctx->p1905_al_mac_addr, ctx->p1905_al_mac_addr);

}

void discovery_at_interface_link_up(void *eloop_data, void *user_ctx)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx*)eloop_data;
	unsigned char *if_name = (unsigned char *)user_ctx;
	static int i = 3, j = 10;

	ctx->mid++;
	notice(DEBUG_CAT_TOPO, "send topo discovery with vs tlv on %s; mid=0x%04x\n",
		if_name, ctx->mid);
	insert_cmdu_txq(p1905_multicast_address, ctx->p1905_al_mac_addr,
		e_topology_discovery_with_vendor_ie, ctx->mid, if_name, 0);

	/*in certification mode, cover TB Mar* issue
	* send more discovery to it and wait for it response
	*/
	if (ctx->MAP_Cer) {
		j--;
		if (j == 0) {
			j = 10;
			return;
		}
		eloop_register_timeout(3, 0, discovery_at_interface_link_up, (void *)ctx, (void *)if_name);
	} else {
		i--;
		if (i == 0) {
			i = 3;
			return;
		}
		eloop_register_timeout(3, 0, discovery_at_interface_link_up, (void *)ctx, (void *)if_name);
	}

	return;
}

void mark_valid_topo_rsp_node(struct p1905_managerd_ctx *ctx)
{
    struct p1905_neighbor_info *p1905_neigbor = NULL;
    struct topology_response_db *tpgr = NULL;
	int i = 0;

	SLIST_FOREACH(tpgr, &ctx->topology_entry.tprdb_head, tprdb_entry)
		tpgr->valid = 0;

	for(i = 0; i < ctx->itf_number; i++) {
		LIST_FOREACH(p1905_neigbor, &(ctx->p1905_neighbor_dev[i].p1905nbr_head), p1905nbr_entry) {
			tpgr = find_topology_rsp_by_almac(ctx, p1905_neigbor->al_mac_addr);
			if (tpgr && !tpgr->valid) {
				tpgr->valid = 1;
				update_topology_info(ctx, tpgr);
			}
		}
	}
}

void update_topology_info(
	struct p1905_managerd_ctx *ctx, struct topology_response_db *tpgr)
{
	struct device_info_db *dev_info = NULL;
	struct p1905_neighbor_device_db *p1905_neighbor = NULL;
    struct topology_response_db *tpgr_child = NULL;

	SLIST_FOREACH(dev_info, &tpgr->devinfo_head, devinfo_entry) {
		SLIST_FOREACH(p1905_neighbor, &dev_info->p1905_nbrdb_head, p1905_nbrdb_entry) {
			tpgr_child = find_topology_rsp_by_almac(ctx,
							p1905_neighbor->p1905_neighbor_al_mac);
			if (tpgr_child && !tpgr_child->valid) {
				tpgr_child->valid = 1;
				update_topology_info(ctx, tpgr_child);
			}
		}
	}
}

struct topology_response_db *find_topology_rsp_by_almac(
	struct p1905_managerd_ctx *ctx, unsigned char *almac)
{
    struct topology_response_db *tpgr_db = NULL;

	SLIST_FOREACH(tpgr_db, &ctx->topology_entry.tprdb_head, tprdb_entry) {
		if (!os_memcmp(tpgr_db->al_mac_addr, almac, ETH_ALEN))
			return tpgr_db;
	}

	return tpgr_db;
}

int check_C_and_A_concurrent_by_topology_rsp(struct p1905_managerd_ctx *ctx, struct topology_response_db *tpgr_db)
{
	struct topology_discovery_db *ctpg_db = NULL, *atpg_db = NULL, *tpg_db = NULL;
	int controller = 0;
	int i = 0;

	for (i = 0; i < tpgr_db->support_service_cnt; i++) {
		if (tpgr_db->support_service[i] == 0)
			controller = 1;
	}
	if (controller) {
		ctpg_db = find_discovery_by_almac(ctx, tpgr_db->al_mac_addr);
		if (ctpg_db) {
			LIST_FOREACH(tpg_db, &ctx->topology_entry.tpddb_head, tpddb_entry)
			{
				if (!os_memcmp(ctpg_db->itf_mac, tpg_db->itf_mac, ETH_ALEN) &&
					os_memcmp(ctpg_db->al_mac, tpg_db->al_mac, ETH_ALEN)) {
					notice(DEBUG_CAT_TOPO, "drop A("MACSTR") discovery to form tree topo; "
						"C("MACSTR") & A("MACSTR") sent discovery by the same itf mac("MACSTR")\n",
						MAC2STR(tpg_db->al_mac), MAC2STR(ctpg_db->al_mac), MAC2STR(tpg_db->al_mac),
						MAC2STR(tpg_db->itf_mac));
#ifdef EM_PLUS_EXT_SUPPORT
				if (os_memcmp(ctx->gw_agent_dcv.al_mac, tpg_db->al_mac, ETH_ALEN)) {
					os_memcpy(&ctx->gw_agent_dcv, tpg_db, sizeof(struct topology_discovery_db));
					notice(DEBUG_CAT_TOPO, "add GW-agent dsc ("MACSTR")", MAC2STR(ctx->gw_agent_dcv.al_mac));
				}
#endif
					delete_exist_topology_discovery_database(ctx, tpg_db->al_mac, tpg_db->itf_mac);
					delete_exist_topology_response_database(ctx, tpg_db->al_mac);
					/*report own topology rsp to update db in mapd*/
					report_own_topology_rsp(ctx, ctx->p1905_al_mac_addr, ctx->br_cap,
						ctx->p1905_neighbor_dev, ctx->non_p1905_neighbor_dev,
						ctx->service, &ctx->ap_cap_entry.oper_bss_head,
						&ctx->ap_cap_entry.assoc_clients_head, ctx->cnt);
				}
			}
		}
	} else {
		atpg_db = find_discovery_by_almac(ctx, tpgr_db->al_mac_addr);
		if (atpg_db) {
			LIST_FOREACH(tpg_db, &ctx->topology_entry.tpddb_head, tpddb_entry)
			{
				if (!os_memcmp(atpg_db->itf_mac, tpg_db->itf_mac, ETH_ALEN) &&
					os_memcmp(atpg_db->al_mac, tpg_db->al_mac, ETH_ALEN)) {
					notice(DEBUG_CAT_TOPO, "drop A("MACSTR") discovery to form tree topo; "
						"A1("MACSTR") & A("MACSTR") sent discovery by the same itf mac("MACSTR")\n",
						MAC2STR(atpg_db->al_mac), MAC2STR(tpg_db->al_mac), MAC2STR(atpg_db->al_mac),
						MAC2STR(atpg_db->itf_mac));
#ifdef EM_PLUS_EXT_SUPPORT
					if (os_memcmp(ctx->gw_agent_dcv.al_mac, tpg_db->al_mac, ETH_ALEN)) {
						os_memcpy(&ctx->gw_agent_dcv, tpg_db, sizeof(struct topology_discovery_db));
						notice(DEBUG_CAT_TOPO, "add GW-agent dsc ("MACSTR")", MAC2STR(ctx->gw_agent_dcv.al_mac));
					}
#endif

					delete_exist_topology_discovery_database(ctx, atpg_db->al_mac, atpg_db->itf_mac);
					delete_exist_topology_response_database(ctx, atpg_db->al_mac);
					/*report own topology rsp to update db in mapd*/
					report_own_topology_rsp(ctx, ctx->p1905_al_mac_addr, ctx->br_cap,
						ctx->p1905_neighbor_dev, ctx->non_p1905_neighbor_dev,
						ctx->service, &ctx->ap_cap_entry.oper_bss_head,
						&ctx->ap_cap_entry.assoc_clients_head, ctx->cnt);
					return -1;
				}
			}
		}
		if (!os_memcmp(tpgr_db->al_mac_addr, gw_agent_almac, ETH_ALEN)) {
			notice(DEBUG_CAT_TOPO, "drop topo rsp for gw_agent("MACSTR")\n", MAC2STR(tpgr_db->al_mac_addr));
			return -1;
		}
	}

	return 0;
}

int check_C_and_A_concurrent_by_discovery(struct p1905_managerd_ctx *ctx, unsigned char *al_mac_addr, unsigned char *mac_addr)
{
	struct topology_response_db *tpgr_db = NULL, *ctpgr_db = NULL;
	struct device_info_db *dev_info = NULL;
	int controller = 0;
	int i = 0;

	SLIST_FOREACH(tpgr_db, &ctx->topology_entry.tprdb_head, tprdb_entry) {
		for (i = 0; i < tpgr_db->support_service_cnt; i++) {
			if (tpgr_db->support_service[i] == 0) {
				controller = 1;
				break;
			}
		}
		if (controller == 1) {
			ctpgr_db = tpgr_db;
			break;
		}
	}
	if (ctpgr_db == NULL)
		return 0;

	SLIST_FOREACH(dev_info, &ctpgr_db->devinfo_head, devinfo_entry) {
		if (!os_memcmp(dev_info->mac_addr, mac_addr, ETH_ALEN) &&
			os_memcmp(ctpgr_db->al_mac_addr, al_mac_addr, ETH_ALEN)) {
				notice(DEBUG_CAT_TOPO, "C("MACSTR") & A("MACSTR") almac different but same intf_mac("MACSTR"); drop A\n",
					MAC2STR(ctpgr_db->al_mac_addr), MAC2STR(al_mac_addr),
					MAC2STR(mac_addr));
				/*Store Agent ALMAC of the Device*/
				os_memcpy(gw_agent_almac, al_mac_addr, ETH_ALEN);
				return -1;
		}
	}

	return 0;
}

unsigned char delete_non_p1905_neighbor_dev_info_byport(struct non_p1905_neighbor *non_p1905_dev, unsigned char port)
{
    int i = 0;
	unsigned char changed = 0;
    struct non_p1905_neighbor_info *dev_info, *dev_info_temp;

    for (i = 0; i < ITF_NUM; i++) {
        if (!LIST_EMPTY(&(non_p1905_dev->non_p1905nbr_head))) {
            dev_info = LIST_FIRST(&(non_p1905_dev->non_p1905nbr_head));
            while (dev_info) {
                dev_info_temp = LIST_NEXT(dev_info, non_p1905nbr_entry);
				if (dev_info->port_index == port) {
                	LIST_REMOVE(dev_info, non_p1905nbr_entry);
                	free(dev_info);
					changed = 1;
				}
                dev_info = dev_info_temp;
            }
        }
    }
	return changed;
}

unsigned char delete_non_p1905_neighbor_dev_info_bymac(struct non_p1905_neighbor *non_p1905_dev, unsigned char *mac)
{
    int i = 0;
	unsigned char changed = 0;
    struct non_p1905_neighbor_info *dev_info, *dev_info_temp;

    for (i = 0; i < ITF_NUM; i++) {
        if (!LIST_EMPTY(&(non_p1905_dev->non_p1905nbr_head))) {
            dev_info = LIST_FIRST(&(non_p1905_dev->non_p1905nbr_head));
            while (dev_info) {
                dev_info_temp = LIST_NEXT(dev_info, non_p1905nbr_entry);
				if (!os_memcmp(dev_info->itf_mac_addr, mac, ETH_ALEN)) {
                	LIST_REMOVE(dev_info, non_p1905nbr_entry);
                	free(dev_info);
					changed = 1;
				}
                dev_info = dev_info_temp;
            }
        }
    }
	return changed;
}

struct non_p1905_neighbor_info *get_non_p1905_neighbor_dev_info_bymac(struct non_p1905_neighbor *non_p1905_dev,
	unsigned char *mac, unsigned char port)
{
    struct non_p1905_neighbor_info *dev_info;

	LIST_FOREACH(dev_info, &(non_p1905_dev->non_p1905nbr_head), non_p1905nbr_entry) {
		if (!os_memcmp(dev_info->itf_mac_addr, mac, ETH_ALEN) && dev_info->port_index == port) {
			break;
		}
	}
    return dev_info;
}

unsigned int get_eth_itf_num(struct p1905_managerd_ctx *ctx)
{
	unsigned int i = 0, num_itf = 0;

	for (i = 0; i < ctx->itf_number; i++) {
		if (ctx->itf[i].media_type <= IEEE802_3_AB_GROUP)
			num_itf++;
	}

	return num_itf;
}


unsigned char non_1905_neighbor_update_per_itf(struct p1905_managerd_ctx *ctx, unsigned int itf_id, unsigned int port)
{
	struct topology_discovery_db *discovery_db = NULL;
	struct topology_response_db *rsp_db = NULL;
	struct ethernet_client_entry *client_entry = NULL;
	struct non_p1905_neighbor *non_1905_neighbor_list = NULL;
	struct non_p1905_neighbor_info *info = NULL;
	unsigned char topo_changed = 0;
	struct ethernet_port *peth_data = NULL;
	struct non_p1905_neighbor_info *dev_info = NULL, *dev_info_temp = NULL;

	info(DEBUG_CAT_TOPO, "itf_idx=%u(%s); port=%u\n", itf_id,
		ctx->itf[itf_id].if_name, port);

	non_1905_neighbor_list = &ctx->non_p1905_neighbor_dev[itf_id];
	discovery_db = NULL;
	peth_data = eth_layer_get_eth_data_by_port_num(port);
	if (peth_data == NULL) {
		err(DEBUG_CAT_TOPO, "can't get peth_data for port %u; ifname=%s\n",
			port, ctx->itf[itf_id].if_name);
		goto RETURN;
	}

	if (ctx->role == CONTROLLER && peth_data->wan_port) {
		info(DEBUG_CAT_TOPO, "this port is wan port and current role is controller"
			" don't update non 1905 neighbor\n");
		goto RETURN;
	}

	dl_list_for_each(client_entry, &peth_data->clients, struct ethernet_client_entry, entry) {
		discovery_db = get_tpd_db_by_mac(ctx, client_entry->mac);
		/*to check any 1905 device exist*/
		if (discovery_db != NULL) {
			/*delete all non-1905 neighbor device belongs to this port*/
			info(DEBUG_CAT_TOPO, "topo discovery found on this port; delete all non 1905.1 neighbors\n");
			topo_changed = delete_non_p1905_neighbor_dev_info_byport(non_1905_neighbor_list, peth_data->port_index);
			break;
		}
	}

	/*if no direct 1905 device found with current port*/
	if (discovery_db == NULL) {
		dl_list_for_each(client_entry, &peth_data->clients, struct ethernet_client_entry, entry) {
			rsp_db = get_trsp_db_by_mac(ctx, client_entry->mac);
			if (rsp_db != NULL)
				break;
		}

		if (rsp_db == NULL) {
			info(DEBUG_CAT_TOPO, "no topo rsp and discovery found on this port; check if need add"
				"new non 1905 neighbor\n");
			dl_list_for_each(client_entry, &peth_data->clients, struct ethernet_client_entry, entry) {
				info = get_non_p1905_neighbor_dev_info_bymac(non_1905_neighbor_list,
					client_entry->mac, peth_data->port_index);
				if (info == NULL) {
					info = (struct non_p1905_neighbor_info *)os_malloc(sizeof(struct non_p1905_neighbor_info));
					if (info == NULL) {
						err(DEBUG_CAT_MISC, "alloc struct non_p1905_neighbor_info fail\n");
						continue;
					}
					info->port_index = peth_data->port_index;
					os_memcpy(info->itf_mac_addr, client_entry->mac, ETH_ALEN);
					info(DEBUG_CAT_TOPO, "insert non 1905.1 dev "MACSTR" on intf "MACSTR"; port=%d\n",
						MAC2STR(info->itf_mac_addr), MAC2STR(non_1905_neighbor_list->local_mac_addr),
						peth_data->port_index);
					LIST_INSERT_HEAD(&non_1905_neighbor_list->non_p1905nbr_head, info, non_p1905nbr_entry);
					topo_changed = 1;
				}
			}
		} else {
			info(DEBUG_CAT_TOPO, "topo rsp found on this port; delete all non 1905.1 neighbors\n");
			topo_changed = delete_non_p1905_neighbor_dev_info_bymac(non_1905_neighbor_list, rsp_db->al_mac_addr);
		}

		/*delete the non 1905 neighbor from list by checking the switch port data list*/
		dev_info = LIST_FIRST(&(non_1905_neighbor_list->non_p1905nbr_head));
		while (dev_info) {
			dev_info_temp = LIST_NEXT(dev_info, non_p1905nbr_entry);
			if (dev_info->port_index == peth_data->port_index) {
				if (!eth_layer_get_client_by_mac(peth_data, dev_info->itf_mac_addr)) {
					LIST_REMOVE(dev_info, non_p1905nbr_entry);
					info(DEBUG_CAT_TOPO, "client disappear on switch; delete non 1905.1 dev "MACSTR
						" on inf "MACSTR"; port=%d\n",
						MAC2STR(dev_info->itf_mac_addr), MAC2STR(non_1905_neighbor_list->local_mac_addr),
						dev_info->port_index);
					os_free(dev_info);
					topo_changed = 1;
				}
			}
			dev_info = dev_info_temp;
		}
	}

RETURN:
	return topo_changed;
}

void non_1905_neighbor_update(void *eloop_data, void *user_ctx)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx *)eloop_data;
	unsigned int i = 0, j = 0;
	unsigned char topo_changed = 0;
	unsigned int num_eth_itf = 0;

	num_eth_itf = get_eth_itf_num(ctx);

	if (eth_layer_port_client_update() < 0)
		return;

	for (j = 0; j < ctx->itf_number; j++) {
		if (ctx->itf[j].media_type > IEEE802_3_AB_GROUP)
			continue;
		/* ext phy used as lan to be extended
		 * eagle:		eth1 <-> ext phy0
		 *				eth2 <-> ext phy8
		 * Panther:		eth1 <-> ext phy6
		 * Cheetah:		eth1 <-> inter phy0 or ext phy5
		 */
#ifdef EM_PLUS_SUPPORT
		if (strncmp((char *)ctx->itf[j].if_name, "eth2", 4U) == 0)
#else
		if (strncmp((char *)ctx->itf[j].if_name, "eth2", 4U) == 0 ||
			strncmp((char *)ctx->itf[j].if_name, "eth1", 4U) == 0)
#endif /* EM_PLUS_SUPPORT */
			continue;

		if (num_eth_itf > 2) {
			/* DSA: port id equal to lan itf id
			 * lan0 <-> port0
			 * lan1 <-> port1
			 * lan2 <-> port2
			 * lan3 <-> port3
			 */
			topo_changed |= non_1905_neighbor_update_per_itf(ctx, j, j);
		} else {
			/* GSW: lan = eth0 <-> port 0 1 2 3 */
			for (i = 0; i < MAX_LAN_PORT_NUM; i++)
				topo_changed |= non_1905_neighbor_update_per_itf(ctx, j, i);
		}
	}

	if (topo_changed) {
		report_own_topology_rsp(ctx, ctx->p1905_al_mac_addr, ctx->br_cap,
							ctx->p1905_neighbor_dev, ctx->non_p1905_neighbor_dev,
							ctx->service, &ctx->ap_cap_entry.oper_bss_head,
							&ctx->ap_cap_entry.assoc_clients_head, ctx->cnt);
		notice(DEBUG_CAT_TOPO, "topo change! send topo notification\n");
		ctx->mid++;
		multicast_cmdu_tx(ctx, e_topology_notification, ctx->mid, 1);
	}

	eloop_register_timeout(SWITCH_TABLE_DUMP_TIME, 0, non_1905_neighbor_update, (void *)ctx, NULL);
}

void discovery_at_boot_up(void *eloop_data, void *user_ctx)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx*)eloop_data;
	static int i = DISC_RETRY_TIME;

	notice(DEBUG_CAT_ONBOARD, "link up; send topo discovery_with_vendor_ie and notification\n");
	ctx->mid++;
	multicast_cmdu_tx_eth(ctx, e_topology_discovery_with_vendor_ie, ctx->mid, 0);
	ctx->mid++;
	multicast_cmdu_tx_eth(ctx, e_topology_notification, ctx->mid, 1);

	i--;
	if (i == 0) {
		i = DISC_RETRY_TIME;
		return;
	}

	eloop_register_timeout(3, 0, discovery_at_boot_up, (void *)ctx, NULL);

	return;
}

void check_topology_rsp_expired(struct p1905_managerd_ctx *ctx)
{
	struct os_time now;
	struct topology_response_db *rsp, *rsp_tmp = NULL;
	struct topology_discovery_db *disc = NULL, *disc_tmp = NULL;
	char query = 0, del = 0, del_rsp_cnt = 0;
	unsigned int i = 0;
	unsigned char *ifname = NULL;

	os_get_time(&now);

	/*fistly,  check whether it is necessary query all devices in topology response database*/
	disc = LIST_FIRST(&ctx->topology_entry.tpddb_head);
	while (disc) {
		query = 0;
		del = 0;
		disc_tmp = LIST_NEXT(disc, tpddb_entry);
		rsp = find_response_by_almac(ctx, disc->al_mac);
		if (rsp) {
			if ((now.sec - rsp->last_seen.sec) > NEIGHBOR_TOPOLOGY_EXPIRE_TIME) {
				del = 1;
			} else if ((now.sec - rsp->last_seen.sec) > NEIGHBOR_TOPOLOGY_QUERY_TIME) {
				query = 1;
			}
		} else {
			query = 1;
		}

		if (query) {
			/*get ifname by discovery*/
			for (i = 0; i < ctx->itf_number; i++) {
				if (!os_memcmp(ctx->itf[i].mac_addr, disc->receive_itf_mac, ETH_ALEN))
					break;
			}
			if (i < ctx->itf_number)
				ifname = ctx->itf[i].if_name;
			else
				ifname = ctx->br_name;
			insert_cmdu_txq(disc->al_mac, ctx->p1905_al_mac_addr,
					e_topology_query, ++ctx->mid, ifname, 0);
			info(DEBUG_CAT_TOPO, "send topo query on %s to neighbor; almac="MACSTR"; mid=%04x\n",
				ifname, MAC2STR(disc->al_mac), ctx->mid);
		}
		if (del) {
			notice(DEBUG_CAT_TOPO, "%ds timeout! del neighbor "MACSTR"\n",
				NEIGHBOR_TOPOLOGY_EXPIRE_TIME, MAC2STR(disc->al_mac));
			delete_p1905_neighbor_dev_info(ctx, disc->al_mac, disc->receive_itf_mac);
			report_own_topology_rsp(ctx, ctx->p1905_al_mac_addr, ctx->br_cap,
				ctx->p1905_neighbor_dev, ctx->non_p1905_neighbor_dev,
				ctx->service, &ctx->ap_cap_entry.oper_bss_head,
				&ctx->ap_cap_entry.assoc_clients_head, ctx->cnt);
			LIST_REMOVE(disc, tpddb_entry);
			if (find_discovery_by_almac(ctx, disc->al_mac) == NULL) {
				delete_exist_topology_response_database(ctx, disc->al_mac);
				del_rsp_cnt++;
				notice(DEBUG_CAT_TOPO, "no discovery in db; del topo rsp\n");
			}
			unmask_control_conn_port(ctx, disc->eth_port);
			free(disc);
		}
		disc = disc_tmp;
	}

	rsp = SLIST_FIRST(&ctx->topology_entry.tprdb_head);
	while (rsp) {
		query = 0;
		del = 0;
		rsp_tmp = SLIST_NEXT(rsp, tprdb_entry);
		if (find_discovery_by_almac(ctx, rsp->al_mac_addr) == NULL) {
			if ((now.sec - rsp->last_seen.sec > TOPOLOGY_EXPIRE_TIME) &&
				(now.sec - rsp->last_seen.sec < TOPOLOGY_EXPIRE_DEL_TIME) ) {
				query = 1;
			} else if (now.sec - rsp->last_seen.sec > TOPOLOGY_EXPIRE_DEL_TIME) {
				del = 1;
			}
		}

		if (query) {
			ifname = ctx->itf[rsp->recv_ifid].if_name;
			insert_cmdu_txq(rsp->al_mac_addr, ctx->p1905_al_mac_addr,
					e_topology_query, ++ctx->mid, ifname, 0);
			info(DEBUG_CAT_TOPO, "send topo query on %s to non neighbor; almac="MACSTR"; mid=%04x\n",
				ifname, MAC2STR(rsp->al_mac_addr), ctx->mid);
		}
		if (del) {
			delete_exist_topology_response_database(ctx, rsp->al_mac_addr);
			notice(DEBUG_CAT_TOPO, "%ds timeout! del topo rsp of non neighbor "MACSTR"\n",
				TOPOLOGY_EXPIRE_DEL_TIME, MAC2STR(rsp->al_mac_addr));
			del_rsp_cnt++;
		}
		rsp = rsp_tmp;
	}

	/*secondly, check whether it is necessary to update my own topology response*/
	if (now.sec - ctx->own_topo_rsp_update_time.sec > TOPOLOGY_EXPIRE_TIME) {
		notice(DEBUG_CAT_TOPO, "%ds timeout; update my own topology rsp event\n",
			TOPOLOGY_EXPIRE_TIME);
		report_own_topology_rsp(ctx, ctx->p1905_al_mac_addr, ctx->br_cap,
			ctx->p1905_neighbor_dev, ctx->non_p1905_neighbor_dev,
			ctx->service, &ctx->ap_cap_entry.oper_bss_head,
			&ctx->ap_cap_entry.assoc_clients_head, ctx->cnt);
	}

	if (del_rsp_cnt)
		mark_valid_topo_rsp_node(ctx);
}

void send_discovery_periodic(void *eloop_data, void *user_ctx)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx *)eloop_data;
	struct buf_info *buf = &ctx->trx_buf;

	ctx->mid++;
	multicast_cmdu_tx(ctx, e_topology_discovery, ctx->mid, 0);

     /*according to IEEE P1905.1 spec, we need to send 802.1 bridge
      *detection message after sending topology discovery message
      *so we implement this functionality here
      */
	lldp_tx(ctx, buf->buf);

	common_process(ctx, buf);
	eloop_register_timeout(ctx->discovery_cnt * PERIODIC_TIMER_SEC, 0,
		send_discovery_periodic, (void *)ctx, NULL);
}

void clear_topology_db(struct p1905_topology_db *topo_entry)
{
	struct topology_discovery_db *pddb = NULL, *pddb_tmp = NULL;
	struct topology_response_db *prdb = NULL, *prdb_tmp = NULL;
	struct device_info_db *pdev_info_db = NULL, *pdev_info_db_tmp = NULL;
	struct p1905_neighbor_device_db *neighbor_dev_db = NULL, *neighbor_dev_db_tmp = NULL;
	struct non_p1905_neighbor_device_list_db *non_neighbor_dev_db = NULL;
	struct non_p1905_neighbor_device_list_db *non_neighbor_dev_db_tmp = NULL;
	struct device_bridge_capability_db *pbrcap_db = NULL, *pbrcap_db_tmp = NULL;

	/*free list tpddb_head*/
	pddb = LIST_FIRST(&topo_entry->tpddb_head);
	while (pddb != NULL) {
		pddb_tmp = LIST_NEXT(pddb, tpddb_entry);
		free(pddb);
		pddb = pddb_tmp;
	}
	LIST_INIT(&topo_entry->tpddb_head);

	/*free list tprdb_head*/
	prdb = SLIST_FIRST(&topo_entry->tprdb_head);
	while (prdb != NULL) {
		prdb_tmp = SLIST_NEXT(prdb, tprdb_entry);
		/*free devinfo_head*/
		pdev_info_db = SLIST_FIRST(&prdb->devinfo_head);
		while (pdev_info_db != NULL) {
			pdev_info_db_tmp = SLIST_NEXT(pdev_info_db, devinfo_entry);
			/*free p1905_neighbor_device_db*/
			neighbor_dev_db = SLIST_FIRST(&pdev_info_db->p1905_nbrdb_head);
			while (neighbor_dev_db != NULL) {
				neighbor_dev_db_tmp = SLIST_NEXT(neighbor_dev_db, p1905_nbrdb_entry);
				free(neighbor_dev_db);
				neighbor_dev_db = neighbor_dev_db_tmp;
			}
			SLIST_INIT(&pdev_info_db->p1905_nbrdb_head);

			/*free non_p1905_neighbor_device_list_db*/
			non_neighbor_dev_db = SLIST_FIRST(&pdev_info_db->non_p1905_nbrdb_head);
			while (non_neighbor_dev_db != NULL) {
				non_neighbor_dev_db_tmp = SLIST_NEXT(non_neighbor_dev_db, non_p1905_nbrdb_entry);
				free(non_neighbor_dev_db);
				non_neighbor_dev_db = non_neighbor_dev_db_tmp;
			}
			SLIST_INIT(&(pdev_info_db->non_p1905_nbrdb_head));

			if(pdev_info_db->vs_info_len)
				free(pdev_info_db->vs_info);

			free(pdev_info_db);
			pdev_info_db = pdev_info_db_tmp;
		}
		SLIST_INIT(&prdb->devinfo_head);

		/*free device_bridge_capability_db*/
		pbrcap_db = LIST_FIRST(&prdb->brcap_head);
		while (pbrcap_db != NULL) {
			pbrcap_db_tmp = LIST_NEXT(pbrcap_db, brcap_entry);
			if(pbrcap_db->interface_amount != 0)
				free(pbrcap_db->interface_mac_tuple);
			free(pbrcap_db);
			pbrcap_db = pbrcap_db_tmp;
		}
		LIST_INIT(&(prdb->brcap_head));

		free(prdb);
		prdb = prdb_tmp;
	}
	SLIST_INIT(&topo_entry->tprdb_head);

}

void clear_topology_neighbor_db(struct p1905_neighbor *neighbor, unsigned char itf_number)
{
	struct p1905_neighbor_info *pinfo = NULL, *pinfo_tmp = NULL;
	int i = 0;

	for(i = 0; i < itf_number; i++) {
		pinfo = LIST_FIRST(&neighbor[i].p1905nbr_head);
		while (pinfo != NULL) {
			pinfo_tmp = LIST_NEXT(pinfo, p1905nbr_entry);
			free(pinfo);
			pinfo = pinfo_tmp;
		}
		LIST_INIT(&neighbor[i].p1905nbr_head);
	}
}

void clear_topology_device_db(struct p1905_topodevice_db *topodev_entry)
{
	struct topology_device_db *pdev = NULL, *pdev_tmp = NULL;

	pdev = SLIST_FIRST(&topodev_entry->tpdevdb_head);
	while (pdev != NULL) {
		pdev_tmp = SLIST_NEXT(pdev, tpdev_entry);
		free(pdev);
		pdev = pdev_tmp;
	}
	SLIST_INIT(&topodev_entry->tpdevdb_head);
}

int dump_topology_info(struct p1905_managerd_ctx *ctx, char *buf, int max_len)
{
	struct topology_discovery_db *tpg_db = NULL;
	struct p1905_neighbor_info *neighbor_info = NULL;
	struct non_p1905_neighbor_info *non_neighbor_info = NULL;
	struct topology_response_db  *tpr_db = NULL;
	struct device_info_db *dev_info = NULL;
	struct p1905_neighbor_device_db *p1905_dev = NULL;
	struct non_p1905_neighbor_device_list_db *non_p1905_dev = NULL;
	struct device_bridge_capability_db *br_cap = NULL;
	unsigned char *mac = NULL;
	struct topology_device_db *tpdev_db = NULL;
	unsigned int i = 0, j = 0, z = 0, a = 0, b = 0;
	int ret = 0, len = 0;
	char *pos = buf;
	struct os_time now;

	os_get_time(&now);

	ret = snprintf(pos, max_len, "\ntopology discovery section\n");
	if (os_snprintf_error(max_len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;
	i = 0;
	if (!LIST_EMPTY(&ctx->topology_entry.tpddb_head)) {
	    LIST_FOREACH(tpg_db, &ctx->topology_entry.tpddb_head, tpddb_entry) {
	        i++;
			ret = snprintf(pos + len, max_len - len,
				"\t%d: almac="MACSTR"; peer_intf="MACSTR"; recv_local_intf="MACSTR"; "
				"time_to_live=%d; eth_port=%d; mtk_tpd=%d\n",
				i, MAC2STR(tpg_db->al_mac), MAC2STR(tpg_db->itf_mac),
				MAC2STR(tpg_db->receive_itf_mac), tpg_db->time_to_live,
				tpg_db->eth_port, tpg_db->mtk_tpd);
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf fail\n");
				return -1;
			}
			len += ret;
	    }
	}

	ret = snprintf(pos + len, max_len - len, "\nown interface 1905 neighbor section\n");
	if (os_snprintf_error(max_len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;
	for (i = 0; i < ctx->itf_number; i++) {
		ret = snprintf(pos + len, max_len - len, "\tintf(%s) neighbor:\n", ctx->itf[i].if_name);
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;
		j = 0;
		LIST_FOREACH(neighbor_info, &ctx->p1905_neighbor_dev[i].p1905nbr_head, p1905nbr_entry) {
			j++;
			ret = snprintf(pos + len, max_len - len, "\t\t%d: almac="MACSTR"; ieee802_1_bridge=%d\n",
				j, MAC2STR(neighbor_info->al_mac_addr), neighbor_info->ieee802_1_bridge);
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf fail\n");
				return -1;
			}
			len += ret;
		}
	}

	ret = snprintf(pos + len, max_len - len, "\nown interface non-1905 neighbor section(only eth interface)\n");
	if (os_snprintf_error(max_len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;
	for (i = 0; i < ctx->itf_number; i++) {
		if (ctx->itf[i].media_type > IEEE802_3_AB_GROUP)
			continue;
		ret = snprintf(pos + len, max_len - len, "\tintf(%s) non neighbor:\n",
			ctx->itf[i].if_name);
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;
		j = 0;
		LIST_FOREACH(non_neighbor_info, &ctx->non_p1905_neighbor_dev[i].non_p1905nbr_head, non_p1905nbr_entry) {
			j++;
			ret = snprintf(pos + len, max_len - len, "\t\t%d: mac="MACSTR"; port=%d\n",
				j, MAC2STR(non_neighbor_info->itf_mac_addr), non_neighbor_info->port_index);
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf fail\n");
				return -1;
			}
			len += ret;
		}
	}

	ret = snprintf(pos + len, max_len - len, "\ntopology response section\n");
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	i = 0;
	SLIST_FOREACH(tpr_db, &ctx->topology_entry.tprdb_head, tprdb_entry) {
		char if_name[IFNAMSIZ + 1] = {0};

		if (tpr_db->recv_ifid != -1) {
			ret = snprintf(if_name, IFNAMSIZ + 1, "%s", ctx->itf[tpr_db->recv_ifid].if_name);
			if (os_snprintf_error(IFNAMSIZ + 1, ret)) {
				err(DEBUG_CAT_MISC, "snprintf fail\n");
				return -1;
			}
		}

		i++;
		ret = snprintf(pos + len, max_len - len,
			"\t%d: valid=%d; almac="MACSTR"; support_service_cnt=%d; "
			"support_service=%d %d %d %d; map_ver=%d; recv_ifid=%d(%s); "
			"eth_port=%d last_seen=%ld.%06ld(s.us) now=%ld.%06ld\n",
			i, tpr_db->valid, MAC2STR(tpr_db->al_mac_addr),
			tpr_db->support_service_cnt,
			tpr_db->support_service[0], tpr_db->support_service[1],
			tpr_db->support_service[2], tpr_db->support_service[3],
			tpr_db->profile, tpr_db->recv_ifid,
			if_name, tpr_db->eth_port, tpr_db->last_seen.sec,
			tpr_db->last_seen.usec, now.sec, now.usec);
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;

		ret = snprintf(pos + len, max_len - len, "\t    device list:\n");
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;
		j = 0;
		SLIST_FOREACH(dev_info, &tpr_db->devinfo_head, devinfo_entry) {
			j++;
			ret = snprintf(pos + len, max_len - len,
				"\t\t%d: mac="MACSTR"; media_type=%04x(%s)\n",
				j, MAC2STR(dev_info->mac_addr), dev_info->media_type,
				get_media_type_str(dev_info->media_type));
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf fail\n");
				return -1;
			}
			len += ret;

			ret = snprintf(pos + len, max_len - len, "\t\t    neighbor 1905 device:\n");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf fail\n");
				return -1;
			}
			len += ret;

			z = 0;
			SLIST_FOREACH(p1905_dev, &dev_info->p1905_nbrdb_head, p1905_nbrdb_entry)
			{
				z++;
				ret = snprintf(pos + len, max_len - len, "\t\t\t%d: almac="MACSTR"; ieee802_1_bridge=%d\n",
					z, MAC2STR(p1905_dev->p1905_neighbor_al_mac), p1905_dev->ieee_802_1_bridge_exist);
				if (os_snprintf_error(max_len - len, ret)) {
					err(DEBUG_CAT_MISC, "snprintf fail\n");
					return -1;
				}
				len += ret;
			}

			ret = snprintf(pos + len, max_len - len, "\t\t    neighbor non 1905 device:\n");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf fail\n");
				return -1;
			}
			len += ret;

			z = 0;
			SLIST_FOREACH(non_p1905_dev, &dev_info->non_p1905_nbrdb_head, non_p1905_nbrdb_entry) {
				z++;
				ret = snprintf(pos + len, max_len - len, "\t\t\t%d: almac="MACSTR"\n",
					z, MAC2STR(non_p1905_dev->non_p1905_device_interface_mac));
				if (os_snprintf_error(max_len - len, ret)) {
					err(DEBUG_CAT_MISC, "snprintf fail\n");
					return -1;
				}
				len += ret;
			}
		}

		ret = snprintf(pos + len, max_len - len, "\t    bridge bind device list:\n");
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;

		a = 0;
		LIST_FOREACH(br_cap, &tpr_db->brcap_head, brcap_entry) {
			a++;
			ret = snprintf(pos + len, max_len - len,
				"\t\tbridge%d; interface_amount=%d; interface_mac:\n",
				a, br_cap->interface_amount);
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf fail\n");
				return -1;
			}
			len += ret;
			b = 0;
			for (b = 0; b < br_cap->interface_amount; b++) {
				mac = br_cap->interface_mac_tuple + b * ETH_ALEN;
				ret = snprintf(pos + len, max_len - len, "\t\t\t%d: "MACSTR"\n", b + 1, MAC2STR(mac));
				if (os_snprintf_error(max_len - len, ret)) {
					err(DEBUG_CAT_MISC, "snprintf fail\n");
					return -1;
				}
				len += ret;
			}
		}
	}

	ret = snprintf(pos + len, max_len - len, "\ntopodev section(mid record)\n");
	if (os_snprintf_error(max_len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;
	i = 0;
	SLIST_FOREACH(tpdev_db, &ctx->topodev_entry.tpdevdb_head, tpdev_entry) {
		i++;
		ret = snprintf(pos + len, max_len - len,
			"\t%d: almac="MACSTR"; time_to_live=%d mid_list="
			"0x%04x 0x%04x 0x%04x 0x%04x 0x%04x "
			"0x%04x 0x%04x 0x%04x 0x%04x 0x%04x\n",
			i, MAC2STR(tpdev_db->aldev_mac), tpdev_db->mid_list[0],
			tpdev_db->time_to_live,
			tpdev_db->mid_list[1], tpdev_db->mid_list[2], tpdev_db->mid_list[3],
			tpdev_db->mid_list[4], tpdev_db->mid_list[5], tpdev_db->mid_list[6],
			tpdev_db->mid_list[7], tpdev_db->mid_list[8], tpdev_db->mid_list[9]);
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;
	}

	return len;
}


void print_tree_leaf_handler(void *context, void* parent_leaf, void *current_leaf, void *data)
{
	struct leaf *parent = (struct leaf*)parent_leaf;
	struct leaf *current = (struct leaf*)current_leaf;
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx *)context;

	if (ctx->role == CONTROLLER) {
		 printf("\t\033[1m\033[40;31m (%p)("MACSTR")------>[current](%p)("MACSTR")\033[0m\n",
		 	parent, PRINT_MAC(parent->al_mac), current, PRINT_MAC(current->al_mac));

	} else {
		printf("\t\033[1m\033[40;31m (%p)("MACSTR")------>(%p)("MACSTR")\033[0m\n",
			parent, PRINT_MAC(parent->al_mac), current, PRINT_MAC(current->al_mac));
	}
}

void dump_topology_tree(struct p1905_managerd_ctx *ctx)
{
	trace_topology_tree_cb(ctx,ctx->root_leaf, print_tree_leaf_handler, NULL);
}

void dump_radio_info(struct p1905_managerd_ctx *ctx)
{
	unsigned char radio_index = 0, bss_index = 0, if_index = 0, ch_index = 0;
	struct radio_info *r = NULL;
	struct p1905_interface *itf = NULL;
	struct operating_class *opc = NULL;

	printf("====================ALMAC====================\n");
	printf("My almac "MACSTR"\n", PRINT_MAC(ctx->p1905_al_mac_addr));
	printf("\n\n");

	printf("====================RADIO INFO====================\n");
	printf("total radio number: %d\n", ctx->radio_number);
	for (radio_index = 0; radio_index < ctx->radio_number; radio_index++) {
		r = &ctx->rinfo[radio_index];
		printf("radio%d:      "MACSTR"\n", radio_index, PRINT_MAC(r->identifier));
		printf("----------attribut:\n");
		printf("teared_down: %d   trrigerd_autoconf: %d\n", r->teared_down, r->trrigerd_autoconf);
		printf("band: %d   config_status: %d   bss_number: %d\n", r->band, r->config_status, r->bss_number);
		printf("----------bss list:\n");
		for (bss_index = 0; bss_index < r->bss_number; bss_index++) {
			printf("name: %s   mac: "MACSTR"   config_status(%d)   priority(%d)\n",
				r->bss[bss_index].ifname,
				PRINT_MAC(r->bss[bss_index].mac),
				r->bss[bss_index].config_status,
				r->bss[bss_index].priority
				);
#ifdef MAP_R2
			printf("ssid: %s   AuthMode: %d   EncrypType: %d\n",
				r->bss[bss_index].config.Ssid,
				r->bss[bss_index].config.AuthMode,
				r->bss[bss_index].config.EncrypType
			);
			printf("WPAKey: %s role: %02x   hidden_ssid: %d\n",
				r->bss[bss_index].config.WPAKey,
				r->bss[bss_index].config.map_vendor_extension,
				r->bss[bss_index].config.hidden_ssid
			);
#endif
		}
		printf("----------radio basic capability: max bss number:%d operating class number:%d\n",
			r->basic_cap.max_bss_num, r->basic_cap.op_class_num);
		dl_list_for_each(opc, &r->basic_cap.op_class_list, struct operating_class, entry) {
			printf("opclass:%d   max_tx_pwr=%d   non_operch_num=%d\n",
				opc->class_number, opc->max_tx_pwr, opc->non_operch_num);
			printf("\tnon_operch_list:\n");
			for (ch_index = 0; ch_index < opc->non_operch_num; ch_index++)
				printf("%d\n", opc->non_operch_list[ch_index]);
			printf("\n");
		}
	}
	printf("\n\n");
	printf("====================INTERFACE INFO====================\n");
	printf("total interface number: %d\n", ctx->itf_number);
	for (if_index = 0; if_index < ctx->itf_number; if_index++) {
		itf = &ctx->itf[if_index];
		printf("interface%d:   mac_addr: "MACSTR"   if_name: %s   media_type: %04x\n",
			if_index, PRINT_MAC(itf->mac_addr), itf->if_name, itf->media_type);
		if (itf->is_wifi_ap || itf->is_wifi_sta) {
			printf("channel_freq: %d   channel_bw: %d\n",
				itf->channel_freq, itf->channel_bw);
		}
		if (itf->is_wifi_sta)
			printf("BSSID: "MACSTR"\n", PRINT_MAC(itf->vs_info));
		if (itf->is_wan)
			printf("WAN interface\n");
		if (itf->is_veth)
			printf("VETH interface\n");
	}
	printf("\n\n");

	printf("====================DESCRIPTION====================\n");
	printf("----------total radio cap:\n");
	printf("#define RADIO_2G_CAP         0x01\n");
	printf("#define RADIO_5GL_CAP        0x02\n");
	printf("#define RADIO_5GH_CAP        0x04\n");
	printf("#define RADIO_5G_CAP         0x08\n");

	printf("----------AuthMode:\n");
	printf("#define AUTH_OPEN            0x0001\n");
	printf("#define AUTH_WPA_PERSONAL    0x0002\n");
	printf("#define AUTH_WPA2_PERSONAL   0x0020\n");
	printf("#define AUTH_SAE_PERSONAL    0x0040\n");

	printf("----------EncrypType:\n");
	printf("#define ENCRYP_NONE          0x0001\n");
	printf("#define ENCRYP_TKIP          0x0004\n");
	printf("#define ENCRYP_AES           0x0008\n");

	printf("----------role:\n");
	printf("#define BIT_BH_STA           BIT(7)\n");
	printf("#define BIT_BH_BSS           BIT(6)\n");
	printf("#define BIT_FH_BSS           BIT(5)\n");
	printf("#define BIT_TEAR_DOWN        BIT(4)\n");

	printf("----------media_type:\n");
	printf("#define IEEE802_3_GROUP      0x0000\n");
	printf("#define IEEE802_11_GROUP     0x0100\n");
}




int is_in_exclude_port_list(int port, int *exclude_port, int num)
{
	int i = 0;

	for (i =0; i < num; i++) {
		if (port == exclude_port[i])
			return 1;
	}

	return 0;
}

/*debug cmd.*/
void show_PON_dev(struct p1905_managerd_ctx *ctx)
{
	struct topology_discovery_db *tpg_db = NULL;
	struct topology_discovery_db *tpg_db_tmp = NULL, *ntpg_db_tmp = NULL;
	int i = 0, j = 0;
	int exclude_port[7] = {-1};

	if (ctx->role != CONTROLLER) {
		printf("current role is agent; need input this cmd on controller\n");
		return;
	}

    LIST_FOREACH(tpg_db, &ctx->topology_entry.tpddb_head, tpddb_entry)
    {
		i = 0;
		if (tpg_db->eth_port != -1 &&
			!is_in_exclude_port_list(tpg_db->eth_port, exclude_port, 7)) {
			tpg_db_tmp = LIST_NEXT(tpg_db, tpddb_entry);
			while(tpg_db_tmp) {
				ntpg_db_tmp = LIST_NEXT(tpg_db_tmp, tpddb_entry);
				if (tpg_db_tmp->eth_port == tpg_db->eth_port)
					i++;
				tpg_db_tmp = ntpg_db_tmp;
			}
			if (i >= 1) {
				exclude_port[j++] = tpg_db->eth_port;
				tpg_db_tmp = LIST_FIRST(&ctx->topology_entry.tpddb_head);
				while(tpg_db_tmp) {
					ntpg_db_tmp = LIST_NEXT(tpg_db_tmp, tpddb_entry);
					if (tpg_db_tmp->eth_port == tpg_db->eth_port) {
						 printf("dev "MACSTR" conncet to PON\n", MAC2STR(tpg_db_tmp->al_mac));
					}
					tpg_db_tmp = ntpg_db_tmp;
				}
				printf("dev "MACSTR" conncet to PON\n", MAC2STR(ctx->p1905_al_mac_addr));
				printf("controller conncet port(%d)\n", tpg_db->eth_port);
			}
		}
    }
}

int cal_controller_num_in_topo(struct p1905_managerd_ctx *ctx)
{
	struct topology_response_db *tpgr_db = NULL;
	int service_num = 0;
	int controller_num = 0;

	if (!SLIST_EMPTY(&ctx->topology_entry.tprdb_head)) {
		SLIST_FOREACH(tpgr_db, &ctx->topology_entry.tprdb_head, tprdb_entry)
		{
			for (service_num = 0; service_num < tpgr_db->support_service_cnt; service_num++) {
				if (tpgr_db->support_service[service_num] == SERVICE_CONTROLLER)
					controller_num++;
			}
		}
	}

	return controller_num;
}

int dump_controller_num_in_topo(struct p1905_managerd_ctx *ctx, char *buf, int max_len)
{
	struct topology_response_db *tpgr_db = NULL;
	int service_num = 0;
	int controller_num = 0;
	int ret = 0, len = 0;

	ret = snprintf(buf, max_len, "====================Controller Count Info====================\n\n");
	if (os_snprintf_error(max_len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf failed\n");
		return -1;
	}
	len += ret;

	if (!SLIST_EMPTY(&ctx->topology_entry.tprdb_head)) {
		SLIST_FOREACH(tpgr_db, &ctx->topology_entry.tprdb_head, tprdb_entry)
		{
			for (service_num = 0; service_num < tpgr_db->support_service_cnt; service_num++) {
				if (tpgr_db->support_service[service_num] == SERVICE_CONTROLLER) {
					controller_num++;
					ret = snprintf(buf, max_len - len, "====controller exist"MACSTR"\n", MAC2STR(tpgr_db->al_mac_addr));
					if (os_snprintf_error(max_len - len, ret)) {
						err(DEBUG_CAT_MISC, "snprintf failed\n");
						return -1;
					}
					len += ret;
				}
			}
		}
	}
	ret = snprintf(buf, max_len - len, "====the number of controller in the topology:%d\n", controller_num);
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf failed\n");
		return -1;
	}
	len += ret;
	ret = snprintf(buf, max_len - len, "============================================================\n");
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf failed\n");
		return -1;
	}
	len += ret;

	return len;
}
