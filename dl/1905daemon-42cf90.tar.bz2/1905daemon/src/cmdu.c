/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <errno.h>
#include <linux/if_packet.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <syslog.h>
#include <assert.h>
#include <linux/if_ether.h>
#include <asm/byteorder.h>
#include <fcntl.h>
#include <unistd.h>

#include "cmdu.h"
#include "cmdu_tlv.h"
#include "cmdu_tlv_parse.h"
#include "cmdu_fragment.h"
#include "debug.h"
#include "multi_ap.h"
#include "ethernet_layer.h"
#include "topology.h"
#include "wsc_attr_tlv.h"
#include "message_wait_queue.h"
#include "cmdu_retry_message.h"
#include "mapfilter_if.h"
#include "p1905_utils.h"
#ifdef MAP_R3
#include "security_engine.h"
#include "wpa_extern.h"
#endif
#ifdef MAP_R5
#include "qos.h"
#endif
#include "lldp.h"

static unsigned char p1905_multicast_address[6]
	= { 0x01, 0x80, 0xc2, 0x00, 0x00, 0x13 };
static unsigned char nearest_bridge_group_address[6]
	= { 0x01, 0x80, 0xc2, 0x00, 0x00, 0x0e  };

TAILQ_HEAD(list_head_txq, txq_list) cmdu_txq_head;
void delete_cmdu_txq_all(void);
int cmdu_send(struct p1905_managerd_ctx *ctx, unsigned char *dmac,
                     unsigned char *smac, msgtype mtype, unsigned short mid,
                     unsigned char *buffer, unsigned char *ifname);
int cmdu_bridge_relay(struct p1905_managerd_ctx *ctx,
                             unsigned char *buf, int len, unsigned int if_index);
int cmdu_bridge_relay_send(struct p1905_managerd_ctx *ctx,
            unsigned char *smac, unsigned char *buf, int len);




/**
 * check destination mac address of received CMDU. if this CMDU is not for us
 * , we need to ignore this CMDU
 *
 * \param  ctx  p1905_managerd_ctx context.
 * \param  da   pointer of destination MAC.
 * \return  1: for us 0: not for us.
 */
 unsigned char cmdu_dst_mac_check(struct p1905_managerd_ctx *ctx,
        unsigned char *da)
{
	if (!memcmp(da, ctx->p1905_al_mac_addr, ETH_ALEN))
		return 1;

	if (!memcmp(da, p1905_multicast_address, ETH_ALEN))
		return 1;

	return 0;
}


/**
 * check source mac address of received CMDU. if this received CMDU is send by us, drop it
 *
 * \param  ctx  p1905_managerd_ctx context.
 * \param  da   pointer of source MAC.
 * \return  1: from us 0: not from us.
 */
unsigned char cmdu_src_mac_check(struct p1905_managerd_ctx *ctx,
        unsigned char *sa)
{
	if (!memcmp(sa, ctx->p1905_al_mac_addr, ETH_ALEN))
		return 1;

    return 0;
}

/**
 *  bridge init
 *
 * \param  ctx  p1905_managerd_ctx context.
 * \return  error code.
 */
/*int bridge_init(struct p1905_managerd_ctx *ctx)
{
	int f, s;
	struct ifreq ifr;

	if ((f=socket(PF_PACKET, SOCK_RAW, host_to_be16(ETH_P_ALL)))<0)
		return -1;

	strcpy(ifr.ifr_name, (char *)ctx->br_name);
	if ((s = ioctl(f, SIOCGIFFLAGS, &ifr))<0){
		close(f);
		return-1;
	}

	ifr.ifr_flags |= IFF_PROMISC;
	if ((s = ioctl(f, SIOCSIFFLAGS, &ifr)) < 0){
		close(f);
		return -1;
	}
	notice(DEBUG_CAT_INIT, "Setting interface ::: %s ::: to promisc\n", ifr.ifr_name);
	close(f);

	return 0;
}*/

/**
 * init cmdu tx queue.
 *
 */
void cmdu_txq_init(void)
{
	TAILQ_INIT(&cmdu_txq_head);
}

/**
 * Initialize all parameters for CMDU.
 *
 * \param  ctx  p1905_managerd_ctx context.
 * \return  error code.
 */
int cmdu_init(struct p1905_managerd_ctx *ctx)
{
	struct sockaddr_ll sll;
	struct ifreq ifr;
	int nSndBufLen = 0,nRcvBufLen = 0;
	socklen_t optlen = sizeof(int);
	int ret;

	ctx->mid = 0;
	ctx->need_relay = 0;

	errno = 0;
	ctx->sock_br = socket(AF_PACKET, SOCK_RAW, ETH_P_1905);
	if (ctx->sock_br < 0) {
	    err(DEBUG_CAT_INIT, "fail to create socket %s; errno=%d(%s)", ctx->br_name,
			errno, strerror(errno));
	    return -1;
	}

	ret = snprintf(ifr.ifr_name, sizeof(ifr.ifr_name), "%s", ctx->br_name);
	if (os_snprintf_error(sizeof(ifr.ifr_name), ret)) {
		err(DEBUG_CAT_INIT, "snprintf fail!\n");
		close(ctx->sock_br);
		return -1;
	}

	errno = 0;
	ret = ioctl(ctx->sock_br, SIOCGIFINDEX, &ifr);
	if (ret == -1) {
	    err(DEBUG_CAT_INIT, "fail to get index for %s errno=%d(%s)\n",
			ctx->br_name, errno, strerror(errno));
	    close(ctx->sock_br);
	    return -1;
	}

	if (getsockopt(ctx->sock_br, SOL_SOCKET, SO_SNDBUF, (void *)&nSndBufLen, &optlen) < 0)
		nSndBufLen = 1024 * 1024;
	else
		nSndBufLen = nSndBufLen * 2;

	if (getsockopt(ctx->sock_br, SOL_SOCKET, SO_RCVBUF, (void *)&nRcvBufLen, &optlen) < 0)
		nRcvBufLen = 1024 * 1024;
	else
		nRcvBufLen = nRcvBufLen * 2;

	notice(DEBUG_CAT_INIT, "sock_br: SO_SNDBUF=%d SO_RCVBUF=%d\n", nSndBufLen, nRcvBufLen);
	errno = 0;
	if (setsockopt(ctx->sock_br, SOL_SOCKET, SO_SNDBUF, (const char *)&nSndBufLen, sizeof(int)) < 0)
		warn(DEBUG_CAT_INIT, "fail to reset SO_SNDBUF; errno=%d(%s)\n", errno, strerror(errno));
	errno = 0;
	if (setsockopt(ctx->sock_br, SOL_SOCKET, SO_RCVBUF, (const char *)&nRcvBufLen, sizeof(int)) < 0)
		warn(DEBUG_CAT_INIT, "fail to reset SO_RCVBUF; errno=%d(%s)\n", errno, strerror(errno));

	/*Create a receive connection of CMDU on bridge interface*/
	memset(&sll, 0, sizeof(sll));
	sll.sll_family = AF_PACKET;
	sll.sll_ifindex = ifr.ifr_ifindex;
	ctx->br_ifid = ifr.ifr_ifindex;
	sll.sll_protocol = host_to_be16(ETH_P_1905);
	errno = 0;
	ret = bind(ctx->sock_br, (struct sockaddr *)&sll, sizeof(struct sockaddr_ll));
	if (ret == -1) {
	    err(DEBUG_CAT_INIT, "fail to bind 1905 socket to %s; errno=%d(%s)\n",
			ctx->br_name, errno, strerror(errno));
	    close(ctx->sock_br);
	    return -1;
	}

    /*Get br mac address*/
	errno = 0;
	ret = ioctl(ctx->sock_br, SIOCGIFHWADDR, &ifr);
	if (ret == -1) {
		err(DEBUG_CAT_INIT, "fail to get mac for %s; errno=%d(%s)",
			ctx->br_name, errno, strerror(errno));
        close(ctx->sock_br);
        return -1;
    }
    memcpy(ctx->br_addr, ifr.ifr_hwaddr.sa_data, ETH_ALEN);

    /* Let bridge do not forward if dest address is local AL MAC address.
     * It is for 1905.1 unicast message usage.
     */
	if (ctx->rx_from_all) {
		if (forbid_almac_and_multicast_forward(ctx) < 0) {
			close(ctx->sock_br);
			return -1;
		}
	} else {
		if (set_opt_not_forward_dest(ctx->p1905_al_mac_addr) < 0) {
			close(ctx->sock_br);
			return -1;
		}
	}

    /*initialize the cmdu transmit queue */
    cmdu_txq_init();

    /* initialize the cmdu fragment queue. It will queue fragment cmdu until
     * all fragmenets received
     */
    init_fragment_queue();

	/*
	 * initialization retry queue. it will queue message which needs receive 1905_ack until
	 * 1905_ack received or timeout
	*/
	 init_retry_queue();

	/*
	 * initialization message wait queue. it will queue unsolicited event while waiting for
	 * some specific event.
	*/
	init_message_wait_queue();

    return 0;
}

/**
 * uninit cmdu, it will be called when exit this process.
 *
 * \param  ctx  p1905_managerd_ctx context.
 */
void cmdu_uninit(struct p1905_managerd_ctx *ctx)
{
	unsigned int i = 0;

	close(ctx->sock_br);
	for (i = 0; i < ctx->itf_number; i++)
		close(ctx->sock_inf_recv_1905[i]);

	if (ctx->rx_from_all)
		clear_forward_rule(ctx);

	/*delete all message queue in TX queue*/
	delete_cmdu_txq_all();

	/*delete all fragment message queue in fragment queue*/

	uninit_fragment_queue();
	/*delete all retry message in retry message queue*/
	uninit_retry_queue();

	uninit_message_wait_queue();
}

/**
 *  get the cmdu message in tx queue and send to bridge.
 *
 * \param  ctx  p1905_managerd_ctx context.
 * \param  buffer  tx buffer.
 * \return  error code.
 */
int process_cmdu_txq(struct p1905_managerd_ctx *ctx, unsigned char *buffer)
{
	struct txq_list *tlist;
	int result = 0;
	unsigned int i = 0;
	unsigned char *ifname = NULL;

	if (TAILQ_EMPTY(&cmdu_txq_head))
		return 0;

	TAILQ_FOREACH(tlist, &cmdu_txq_head, cmdu_txq_entry)
	{
		for (i = 0; i < ctx->itf_number; i++) {
			if (!memcmp(tlist->ifname, ctx->itf[i].if_name, strlen((char *)tlist->ifname))) {
				ifname = ctx->itf[i].if_name;
				break;
			}
		}
		if (i >= ctx->itf_number) {
			if (memcmp(tlist->ifname, ctx->br_name, IFNAMSIZ) != 0) {
				err(DEBUG_CAT_MSG, "tx unkonwn inf name(%s), replace to br(%s)\n",
					tlist->ifname, ctx->br_name);
				err(DEBUG_CAT_MSG, "txq send: da("MACSTR"); sa("MACSTR");"
					" send_mtype=0x%04x(%s);\n",
					MAC2STR(tlist->dmac), MAC2STR(tlist->smac),
					tlist->mtype, get_1905_send_mtype_str(tlist->mtype));
			}
			ifname = ctx->br_name;
		} else {
			/*drop this packet that does not allow to send multicast*/
			if (!(ctx->itf[i].trx_config & (TX_MUL | TX_UNI))) {
				err(DEBUG_CAT_MSG, "drop tx packet on %s; this intf has no tx cap\n",
					ctx->itf[i].if_name);
				err(DEBUG_CAT_MSG, "txq send: da("MACSTR"); sa("MACSTR");"
					" send_mtype=0x%04x(%s)\n",
					MAC2STR(tlist->dmac), MAC2STR(tlist->smac), tlist->mtype,
					get_1905_send_mtype_str(tlist->mtype));
				continue;
			}
		}

		result = cmdu_send(ctx, tlist->dmac, tlist->smac, tlist->mtype, tlist->mid, buffer, ifname);
		if (result == 0 && tlist->need_update_mid) {
			if (_1905_write_mid("/tmp/msg_id.txt", tlist->mid) < 0)
				err(DEBUG_CAT_MSG, "update mid=0x%04x to dev_send_1905_mid.txt fail\n", tlist->mid);
			else
				debug(DEBUG_CAT_MSG, "update mid=0x%04x to dev_send_1905_mid.txt success\n", tlist->mid);
		}
	}

	delete_cmdu_txq_all();
	if (ctx->sta_notifier)
		ctx->sta_notifier = 0;

	return 0;
}

/**
 *  insert cmdu message into tx queue.
 *
 * \param  dmac  destination mac address.
 * \param  smac  source mac addr, it awii affect the forwarding of bridge.
 * \param  mtype  cmdu message type, defined in 1905.1 spec.
 * \param  mid  message id, defined in 1905.1 spec
 */
void insert_cmdu_txq(unsigned char *dmac, unsigned char *smac, msgtype mtype,
                    unsigned short mid, unsigned char* ifname, unsigned char need_update_mid)
{
	int ret;
	struct txq_list *tlist;

	tlist = (struct txq_list *)malloc(sizeof(struct txq_list));
	if (!tlist) {
		err(DEBUG_CAT_MISC, "malloc struct txq_list fail!\n");
		return;
	}
	memset(tlist, 0, sizeof(struct txq_list));
	memcpy(tlist->dmac, dmac, 6);
	memcpy(tlist->smac, smac, 6);
	ret = snprintf((char *)tlist->ifname, sizeof(tlist->ifname), "%s", ifname);
	if (os_snprintf_error(sizeof(tlist->ifname), ret) < 0) {
		err(DEBUG_CAT_MISC, "snprintf fail!\n");
		return;
	}
	tlist->ifname[IFNAMSIZ-1] = '\0';
	tlist->mtype = mtype;
	tlist->mid = mid;
	tlist->need_update_mid = need_update_mid;
	TAILQ_INSERT_TAIL(&cmdu_txq_head, tlist, cmdu_txq_entry);
}

/**
 *  delete all cmdu message in tx queue.
 *
 */
void delete_cmdu_txq_all(void)
{
    struct txq_list *tlist, *tlist_temp;

    tlist = TAILQ_FIRST(&cmdu_txq_head);
    while(tlist)
    {
        tlist_temp = TAILQ_NEXT(tlist, cmdu_txq_entry);
        TAILQ_REMOVE(&cmdu_txq_head, tlist, cmdu_txq_entry);
        free(tlist);
        tlist = tlist_temp;
    }
}

/**
 *  Fragment tx. Use this funciton when CMDU message size exceed max size.
 *
 * \param  ctx  p1905_managerd_ctx context.
 * \param  tlv  pointer of tlv start position.
 * \param  msg_hdr  pointer of message header start position.
 * \param  buffer   pointer of start position of whole message.
 * \return error code
 */
int cmdu_tx_fragment(struct p1905_managerd_ctx *ctx,
	unsigned char *buffer, unsigned short buflen, unsigned char *ifname)
{
    unsigned short offset = 0;
    unsigned short tmp_length = 0;
	cmdu_message_header *msg_hdr = NULL;
    unsigned char *tlv_buf_raw = NULL, *tlv_buf = NULL;
    unsigned char *temp_buf = NULL;
	unsigned char *tlv = NULL;
    unsigned short tlv_len = 0, total_tlv_len = 0;
	int len = 0, send_len = 0;
	int sock = 0;
	unsigned int i = 0;

	for (i = 0; i < ctx->itf_number; i++) {
		if (!memcmp(ifname, ctx->itf[i].if_name, strlen((char *)ifname))) {
			sock = ctx->sock_inf_recv_1905[i];
			break;
		}
	}
	if (i >= ctx->itf_number)
		sock = ctx->sock_br;

	msg_hdr = (cmdu_message_header *)(buffer + ETH_HLEN);
	tlv = buffer + ETH_HLEN + CMDU_HLEN;
	total_tlv_len = buflen - ETH_HLEN - CMDU_HLEN;
	tlv_buf = (unsigned char *)malloc(total_tlv_len);
	if (!tlv_buf) {
		err(DEBUG_CAT_MISC, "alloc tlv_buf fail\n");
		goto error;
	}
	tlv_buf_raw = tlv_buf;

	memcpy(tlv_buf, tlv, total_tlv_len);
	temp_buf = tlv_buf;

	i = 0;
	for (;;) {
		if ((*temp_buf) == END_OF_TLV_TYPE) {
			/* if last fragment is larger than MAX_TLVS_LENGTH,
			* we need to seperate this fragment into two fragments
			* the total length of end of tlv is 3
			*/
			if ((offset + 3) > MAX_TLVS_LENGTH) {
#ifdef MAP_R3
				memcpy(tlv, tlv_buf, MAX_TLVS_LENGTH);
				msg_hdr->fragment_id = i;
				msg_hdr->last_fragment_indicator = 0;
				len = MAX_TLVS_LENGTH + CMDU_HLEN + ETH_HLEN;
#else
				memcpy(tlv, tlv_buf, offset);
				msg_hdr->fragment_id = i;
				msg_hdr->last_fragment_indicator = 0;
				len = offset + CMDU_HLEN + ETH_HLEN;
#endif
				errno = 0;
				send_len = send(sock, buffer, len, 0);
				if (0 > send_len) {
					err(DEBUG_CAT_MSG, "offset(%d) len(%d) fragment_id(%d)\n", offset, len, i);
					goto error;
				}
				/*add for fragment id*/
				i++;

				memset(tlv, 0, MIN_TLVS_LENGTH);
				msg_hdr->fragment_id = i;
				msg_hdr->last_fragment_indicator = 1;

				len = MIN_TLVS_LENGTH + CMDU_HLEN + ETH_HLEN;
				send_len = send(sock, buffer, len, 0);
				if (send_len < 0) {
					err(DEBUG_CAT_MSG, "len(%d) fragment_id(%d)\n", len, i);
				    goto error;
				}
			} else {
				/* It is the last fragment so we set last fragment ind to 1.
				* And send this buffer
				*/
				msg_hdr->fragment_id = i;
				msg_hdr->last_fragment_indicator = 1;

				memcpy(tlv, tlv_buf, (offset + 3));

				if ((offset + 3) < MIN_TLVS_LENGTH) {
					memset((tlv+(offset + 3)), 0, MIN_TLVS_LENGTH-(offset + 3));
					tmp_length = MIN_TLVS_LENGTH;
				} else {
					tmp_length = (offset + 3);
				}
				len = tmp_length + CMDU_HLEN + ETH_HLEN;

				send_len = send(sock, buffer, len, 0);
				if(0 > send_len) {
					err(DEBUG_CAT_MSG, "offset(%d) len(%d) fragment_id(%d)\n", offset, len, i);
					goto error;
				}
			}
			goto out;
		}

		/* below is non-last fragment case.
		* We should go here first when fragment tx happen.
		*/
		tlv_len = get_cmdu_tlv_length(temp_buf);
		if (tlv_len > total_tlv_len) {
			err(DEBUG_CAT_MSG, "tlv_len %d is bigger than total_tlv_len %d\n",
				tlv_len, total_tlv_len);
			goto error;
		}
		debug(DEBUG_CAT_MSG, "tlv_type=0x%02x, tlv_len=%d offset=%d tlv_len=%d\n",
			*temp_buf, tlv_len, offset, tlv_len);
		/*shift buffer to correct position*/
		temp_buf += tlv_len;
#ifdef MAP_R3
		/* one encrypted tlv may bigger than 0x3FFF for R3
		** no one tlv could exceed 0x3FFF for R1 and R2
		*/
		if (tlv_len > MAX_TLVS_LENGTH) {
			while ((offset + tlv_len) > MAX_TLVS_LENGTH) {
				memcpy(tlv, tlv_buf, MAX_TLVS_LENGTH);

				/*shift to start position of not sent cmdu payload */
				tlv_buf += MAX_TLVS_LENGTH;
				tlv_len -= (MAX_TLVS_LENGTH - offset);
				offset = 0;

				/* set fragment id & last fragment ind in cmdu message header.
				* In this case, last fragment ind must be 0 because no end_of_tlv.
				*/
				msg_hdr->fragment_id = i;
				msg_hdr->last_fragment_indicator = 0;

				len = MAX_TLVS_LENGTH + CMDU_HLEN + ETH_HLEN;
				send_len = send(sock, buffer, len, 0);
				if(0 > send_len)
					goto error;
				debug(DEBUG_CAT_MSG, "frag_cmdu%d, msgtype=0x%04x, interface=%s fid=%d mid=%d lf=%d, len:%d\n",
					i, be_to_host16(msg_hdr->message_type), ifname,
					msg_hdr->fragment_id, be_to_host16(msg_hdr->message_id),
					msg_hdr->last_fragment_indicator, len);

				i++;
				}

			offset += tlv_len;
		}else
#endif

        if ((offset + tlv_len) > MAX_TLVS_LENGTH) {
            memcpy(tlv, tlv_buf, offset);

            /* set fragment id & last fragment ind in cmdu message header.
             * In this case, last fragment ind must be 0 because no end_of_tlv.
             */
            msg_hdr->fragment_id = i;
            msg_hdr->last_fragment_indicator = 0;

            len = offset + CMDU_HLEN + ETH_HLEN;
            send_len = send(sock, buffer, len, 0);
			debug(DEBUG_CAT_MSG, "frag_tlv_len=%d send_len(%d)\n", offset, send_len);
			if (send_len < 0) {
				err(DEBUG_CAT_MSG, "offset(%d) len(%d) fragment_id(%d)\n", offset, len, i);
                goto error;
            }
            /*shift to start position of not sent cmdu payload */
            tlv_buf += offset;

            /* record the tlv_len, which was gotten by get_cmdu_tlv_length
             * Don't worry about buffer address, because we will shift buffer
             * to correct position in the end of this for loop.
             */
            offset = tlv_len;

            /*for fragment id use*/
            i++;
        } else {
            offset += tlv_len;
        }
    }

out:
	free(tlv_buf_raw);

	return 0;
error:
	err(DEBUG_CAT_MSG, "fragment cmdu send fail to %s; errno=%d(%s)"
		"sa="MACSTR"; da="MACSTR"; type=0x%04x(%s); mid=0x%04x; "
		"fragment_id=%d; last_fragment_indicator=%d\n",
		ifname, errno, strerror(errno),
		MAC2STR(buffer), MAC2STR(buffer + 6),
		be_to_host16(msg_hdr->message_type),
		get_1905_mtype_str(be_to_host16(msg_hdr->message_type)),
		be_to_host16(msg_hdr->message_id), msg_hdr->fragment_id,
		msg_hdr->last_fragment_indicator);
	free(tlv_buf_raw);

	return -1;
}

struct _config_sync {
	unsigned char al_mac[ETH_ALEN];
	unsigned char band;
};


/**
 *  create & send cmdu message to the corresponding interface.
 *
 * \param  ctx  p1905_managerd_ctx context.
 * \param  dmac  destination mac address.
 * \param  smac  source mac address.
 * \param  mtype   cmdu message type.
 * \param  mid   cmdu message id.
 * \param  buffer   cmdu buffer for sending.
 * \return error code
 */
int cmdu_send(struct p1905_managerd_ctx *ctx, unsigned char *dmac,
                     unsigned char *smac, msgtype mtype, unsigned short mid,
                     unsigned char *buffer, unsigned char *ifname)
{
    struct ethhdr *eth_hdr;
    cmdu_message_header *msg_hdr;
    unsigned char *msg;
    unsigned short msg_leng = 0;
    unsigned short len;
    unsigned char *tlv;
	struct agent_list_db *agent = NULL;
	unsigned char *pmac = NULL;
	int sock = 0;
	unsigned int i = 0;
	unsigned char zero_mac[ETH_ALEN] = {0};

	for (i = 0; i < ctx->itf_number; i++) {
		if (!memcmp(ifname, ctx->itf[i].if_name, strlen((char *)ifname))) {
			sock = ctx->sock_inf_recv_1905[i];
			pmac = ctx->itf[i].mac_addr;
			break;
		}
	}
	if (i >= ctx->itf_number) {
		sock = ctx->sock_br;
		pmac = (unsigned char*)ctx->br_addr;
	}

	/*Only the wan interface can send search message*/
	if (ctx->restrict_wan_onboarding &&
		(ctx->role != CONTROLLER)) {
		if (mtype == e_ap_autoconfiguration_search) {
			if ((i < ctx->itf_number) &&
				(ctx->itf[i].media_type <= IEEE802_3_AB_GROUP) &&
				!ctx->itf[i].is_wan) {
				notice(DEBUG_CAT_MSG, "restrict_wan_onboarding enable; forbid search msg"
					" on %s\n", ctx->itf[i].if_name);
				return 0;
			}
		}
	}

    eth_hdr = (struct ethhdr*)buffer;
    memcpy(eth_hdr->h_dest, dmac, ETH_ALEN);
    memcpy(eth_hdr->h_source, smac, ETH_ALEN);
    eth_hdr->h_proto = host_to_be16(ETH_P_1905);

    /*start position of message header*/
    msg = buffer + ETH_HLEN;
    msg_hdr = (cmdu_message_header*)(msg);

    /*start position of tlvs*/
    tlv = msg + CMDU_HLEN;

	switch (mtype) {
	case e_topology_discovery:
		msg_leng = create_topology_discovery_message(ctx, msg,
			ctx->p1905_al_mac_addr, pmac, 0, NULL);
		break;
	case e_topology_discovery_with_vendor_ie:
	{
		unsigned char vs_info[16] = {0};
		unsigned short vs_len = 0;

		vs_len = create_vs_info_for_specific_discovery(vs_info);
		msg_leng = create_topology_discovery_message(ctx, msg,
				ctx->p1905_al_mac_addr, pmac, vs_len, vs_info);
	}
		break;
	case e_vendor_specific_topology_discovery:
	{
		unsigned char vs_info[16] = {0};
		unsigned short vs_len = 0;

		vs_len = create_vs_info_for_specific_discovery(vs_info);
		msg_leng = create_vendor_specific_topology_discovery_message(ctx, msg,
			ctx->p1905_al_mac_addr, pmac, vs_len, vs_info);
	}
		break;
	case e_topology_notification:
		msg_leng = create_topology_notification_message(ctx, msg,
			ctx->p1905_al_mac_addr, &ctx->sinfo.sassoc_evt,
			ctx->sta_notifier, 0, NULL);
		break;
	case e_topology_notification_with_vendor_ie:
	{
		unsigned char vs_info[32] = {0};
		unsigned short vs_len = 0;

		vs_len = create_vs_info_for_specific_notification(ctx, vs_info);
		msg_leng = create_topology_notification_message(ctx, msg,
			ctx->p1905_al_mac_addr, &ctx->sinfo.sassoc_evt,
			ctx->sta_notifier, vs_len, vs_info);
	}
		break;
	case e_topology_query:
		msg_leng = create_topology_query_message(msg, ctx);
		break;
	case e_topology_response:
		msg_leng = create_topology_response_message(msg,
					ctx->p1905_al_mac_addr, ctx, ctx->br_cap,
					ctx->p1905_neighbor_dev, ctx->non_p1905_neighbor_dev,
					&(ctx->topology_entry.tprdb_head), ctx->service,
					&(ctx->ap_cap_entry.oper_bss_head),
					&(ctx->ap_cap_entry.assoc_clients_head), ctx->cnt);
		break;
	case e_vendor_specific:
		msg_leng = create_vendor_specific_message(msg, ctx);
		break;
	case e_vendor_specific_wts_content:
		msg_leng = create_vendor_specific_wts_content_message(msg, ctx);
		break;
	case e_vendor_specific_bss_prio:
		msg_leng = create_vendor_specific_bss_prio_message(msg, ctx);
		break;
	case e_vendor_specific_bss_prio_ack:
		msg_leng = create_vendor_specific_bss_prio_ack_message(msg, ctx);
		break;
	case e_link_metric_query:
		msg_leng = create_link_metrics_query_message(ctx, msg,
			ctx->link_metric_query_para.target,
			ctx->link_metric_query_para.type);
		break;
	case e_link_metric_response:
		msg_leng = create_link_metrics_response_message(msg, ctx);
		break;
	case e_ap_autoconfiguration_search:
		msg_leng = ap_autoconfiguration_search_message(msg, ctx);
		break;
	case e_ap_autoconfiguration_wsc_m1:
		msg_leng = ap_autoconfiguration_wsc_message(msg, ctx, dmac, MESSAGE_TYPE_M1);
		break;
	case e_ap_autoconfiguration_response:
		msg_leng = ap_autoconfiguration_response_message(msg, dmac, ctx);
		break;
	case e_ap_autoconfiguration_wsc_m2:
		msg_leng = ap_autoconfiguration_wsc_message(msg, ctx, dmac, MESSAGE_TYPE_M2);
		break;
	case e_ap_autoconfiguration_renew:
		msg_leng = ap_autoconfiguration_renew_message(msg, ctx);
		break;
	case e_ap_capability_query:
		msg_leng = ap_capability_query_message(msg, ctx);
		break;
	case e_channel_preference_query:
		msg_leng = channel_preference_query_message(msg, ctx);
		break;
	case e_channel_selection_request:
		if (ctx->role == CONTROLLER) {
			find_agent_info(ctx, dmac, &agent);
			if (!agent && !ctx->send_tlv_len) {
				err(DEBUG_CAT_MSG, "no agent info && send_tlv_len==0 for "MACSTR"\n",
					MAC2STR(dmac));
				break;
			}
			msg_leng = channel_selection_request_message(msg, agent, ctx);
	}
		break;
	case e_combined_infrastructure_metrics:
		if (ctx->role == CONTROLLER)
			msg_leng = combined_infrastructure_metrics_message(msg, ctx, dmac);
		else
			reset_send_tlv(ctx);
		break;
	case e_ap_capability_report:
		msg_leng = ap_capability_report_message(msg, ctx);
		break;
	case e_cli_capability_query:
		msg_leng = cli_capability_query_message(msg, ctx);
		break;
	case e_cli_capability_report:
		msg_leng = cli_capability_report_message(msg, ctx);
		break;
	case e_channel_selection_response:
		msg_leng = channel_selection_response_message(msg, ctx);
		break;
	case e_channel_preference_report:
		msg_leng = channel_preference_report_message(msg, ctx);
		break;
	case e_operating_channel_report:
		msg_leng = operating_channel_report_message(msg, ctx);
		break;
	case e_client_steering_btm_report:
		msg_leng = client_steering_btm_report_message(msg, ctx);
		break;
	case e_steering_completed:
		msg_leng = client_steering_completed_message(msg, ctx);
		break;
	case e_multi_ap_policy_config_request:
		msg_leng = map_policy_config_request_message(msg, ctx, dmac);
		break;
	case e_client_association_control_request:
		msg_leng = client_association_control_request_message(msg, ctx);
		break;
	case e_ap_metrics_query:
		msg_leng = ap_metrics_query_message(msg, ctx);
		break;
	case e_ap_metrics_response:
		msg_leng = ap_metrics_response_message(msg, ctx);
		break;
	case e_associated_sta_link_metrics_query:
		msg_leng = associated_sta_link_metrics_query_message(msg, ctx);
		break;
	case e_associated_sta_link_metrics_response:
		msg_leng = associated_sta_link_metrics_response_message(msg, ctx);
		break;
	case e_unassociated_sta_link_metrics_query:
		msg_leng = unassociated_sta_link_metrics_query_message(msg, ctx);
		break;
	case e_unassociated_sta_link_metrics_response:
		msg_leng = unassociated_sta_link_metrics_response_message(msg, ctx);
		break;
	case e_beacon_metrics_query:
		msg_leng = beacon_metrics_query_message(msg, ctx);
		break;
	case e_beacon_metrics_response:
		msg_leng = beacon_metrics_response_message(msg, ctx);
		break;
	case e_backhaul_steering_response:
		msg_leng = backhaul_steering_response_message(msg, ctx);
		break;
	case e_higher_layer_data:
		msg_leng = high_layer_data_message(msg, ctx);
		break;
	case e_1905_ack:
		msg_leng = _1905_ack_message(msg, ctx);
		break;
	case e_dev_send_1905_request:
		msg_leng = dev_send_1905_msg(msg, ctx);
		break;
	case e_client_steering_request:
		msg_leng = client_steering_request_message(msg, ctx);
		break;
	case e_backhaul_steering_request:
		msg_leng = backhaul_steering_request_message(msg, ctx);
		break;
#ifdef MAP_R2
	/*channel scan feature*/
	case e_channel_scan_request:
		if (ctx->role == CONTROLLER)
			msg_leng = channel_scan_request_message(msg, ctx);
		break;
	case e_channel_scan_report:
		msg_leng = channel_scan_report_message(msg, ctx);
		break;

	case e_tunneled_message:
		msg_leng = tunneled_message(msg, ctx);
		break;

	case e_association_status_notification:
		msg_leng = assoc_status_notification_message(msg, ctx);
		break;

	case e_cac_request:
		msg_leng = cac_request_message(msg, ctx);
		break;

	case e_cac_termination:
		msg_leng = cac_terminate_message(msg, ctx);
		break;

	case e_client_disassociation_stats:
		msg_leng = client_disassciation_stats_message(msg, ctx);
		break;
	case e_backhual_sta_cap_query_message:
			msg_leng = backhual_sta_cap_query_message(msg, ctx);
			break;
	case e_backhual_sta_cap_report_message:
			msg_leng = backhual_sta_cap_report_message(msg, ctx);
			break;
	case e_failed_connection_message:
		msg_leng = failed_connection_message(msg, ctx);
		break;
#endif // #ifdef MAP_R2

#ifdef MAP_R3
	case e_proxied_encap_dpp:
		msg_leng = proxied_encap_dpp_message(msg, ctx);
		break;

	case e_direct_encap_dpp:
		msg_leng = direct_encap_dpp_message(msg, ctx);
		break;

	case e_1905_encap_eapol:
		msg_leng = _1905_encap_eapol_message(msg, ctx);
		break;

	case e_dpp_bootstrapping_uri_notification:
		msg_leng = dpp_bootstrap_uri_notification_message(msg, ctx);
		break;

	case e_dpp_bootstrapping_uri_query:
		msg_leng = dpp_bootstrap_uri_query_message(msg, ctx);
		break;

	case e_dpp_cce_indication:
		msg_leng = dpp_cce_indication_message(msg, ctx);
		break;

	/* Agent may at any time send a BSS Configuration Request */
	case e_bss_configuration_request:
		msg_leng = bss_configuration_request_message(msg, ctx, dmac);
		break;

	case e_bss_configuration_response:
		msg_leng = bss_configuration_response_message(msg, ctx, dmac);
		if (msg_leng == 0) {
			/* trigger topology qeury at once as no bss connector match by almac */
			notice(DEBUG_CAT_DPP, "trigger topology query at once to "MACSTR"\n", MAC2STR(dmac));
			insert_cmdu_txq(dmac, ctx->p1905_al_mac_addr, e_topology_query, ++ctx->mid, ifname, 0);
			return 0;
		}
		/* reset position of message header*/
		buffer = ctx->trx_buf.buf;
		msg = buffer + ETH_HLEN;
		msg_hdr = (cmdu_message_header *)(msg);
		break;

	case e_bss_configuration_result:
		msg_leng = bss_configuration_result_message(msg, ctx, dmac);
		break;

	case e_ptk_rekey_request:
		msg_leng = _1905_rekey_request_message(msg, ctx);
		break;

	case e_decryption_failure:
		msg_leng = _1905_decryption_failure_message(ctx, msg, dmac);
		break;
	/*
	 * 1. this msg should be sent by ucc in raw data
	 * 2. this msg should be send after bss config changed while turnkey
	 */
	case e_bss_reconfiguration_trigger:
		msg_leng = bss_reconfiguration_trigger_message(msg, ctx);
		break;

	case e_agent_list:
		msg_leng = agent_list_message(msg, ctx, dmac);
		break;

	case e_chirp_notification:
		msg_leng = chirp_notification_message(msg, ctx);
		break;
#endif // MAP_R3
#ifdef MAP_R3_SP
	case e_service_prioritization_request:
		notice(DEBUG_CAT_SP, "e_service_prioritization_request");
		msg_leng = create_sp_request_message(get_tlv_buffer(ctx),
			msg, &ctx->sp_rule_static_list, &ctx->sp_rule_dynamic_list,
			&ctx->sp_rule_del_list, &ctx->sp_dp_table, ctx->sp_req_conf.action, dmac);
		break;
	case e_service_prioritization_request_4_learning_comp:
		notice(DEBUG_CAT_SP, "e_service_prioritization_request_4_learning_comp");
		msg_leng = create_sp_request_message(get_tlv_buffer(ctx),
			msg, NULL, &ctx->sp_rule_learn_complete_list,
			NULL, NULL, ADD_RULE, dmac);
		break;
	case e_service_prioritization_request_4_t2lm_conf:
		notice(DEBUG_CAT_SP, "e_service_prioritization_request_4_t2lm_conf");
		msg_leng = create_t2lm_sp_message(msg, ctx);
		break;
#endif
#ifdef MAP_R5
	case e_qos_management_notification:
		msg_leng = create_qos_management_notification_message(
			get_tlv_buffer(ctx), msg, ctx->p1905_al_mac_addr);
		break;
	case e_qos_dscp_policy_request:
		 notice(DEBUG_CAT_QOS,
			"to-do, send e_qos_dscp_policy_request in service prioritization request.\n");
		break;
#endif

#ifdef MAP_R6
	case e_early_ap_cap_report:
		msg_leng = early_ap_cap_report_message(msg, ctx);
		info(DEBUG_CAT_MLO, "send early ap cap report (%04X)\n",
			be_to_host16(msg_hdr->message_type));
		break;

	case e_ap_mld_configuration_request:
		msg_leng = ap_mld_configuration_request_message(msg, ctx, dmac);
		info(DEBUG_CAT_MLO, "send ap mld configuration request message (%04X)\n",
			be_to_host16(msg_hdr->message_type));
		break;

	case e_ap_mld_configuration_response:
		msg_leng = ap_mld_configuration_response_message(msg, ctx, dmac);
		info(DEBUG_CAT_MLO, "send ap mld configuration response message (%04X)\n",
			be_to_host16(msg_hdr->message_type));
		break;

	case e_bsta_mld_configuration_request:
		msg_leng = bsta_mld_configuration_request_message(msg, ctx, dmac);
		info(DEBUG_CAT_MLO, "send bsta mld configuration request message (%04X)\n",
			be_to_host16(msg_hdr->message_type));
		break;

	case e_bsta_mld_configuration_response:
		msg_leng = bsta_mld_configuration_response_message(msg, ctx, dmac);
		info(DEBUG_CAT_MLO, "send bsta mld configuration response message (%04X)\n",
			be_to_host16(msg_hdr->message_type));
		break;

	case e_afc_spectrum_inquiry_msg:
		msg_leng = afc_spectrum_inquiry_message(msg, ctx);
		info(DEBUG_CAT_MLO, "send afc spectrum inquiry message (%04X) %d\n",
			be_to_host16(msg_hdr->message_type), msg_leng);
		break;
#endif
	default:
		break;
	}

	if (msg_leng == 0) {
		err(DEBUG_CAT_MSG, "fail to construct the send msg to %s;"
			"sa="MACSTR"; da="MACSTR"; type=0x%04x(%s);",
			ifname, MAC2STR(smac), MAC2STR(dmac), mtype,
			get_1905_send_mtype_str(mtype));
		return -1;
	}

	/* reset header as buffer maybe realloced */
	eth_hdr = (struct ethhdr *)buffer;
	os_memcpy(eth_hdr->h_dest, dmac, ETH_ALEN);
	os_memcpy(eth_hdr->h_source, smac, ETH_ALEN);
	eth_hdr->h_proto = host_to_be16(ETH_P_1905);

	/*start position of tlvs */
	tlv = msg + CMDU_HLEN;

	/*move tlv_temp to buffer*/
	os_memcpy(tlv, get_tlv_buffer(ctx), msg_leng);
	len = msg_leng + CMDU_HLEN + ETH_HLEN;
#ifdef MAP_R3
	/* testbed need buffer message[include all tlvs] which ucc specified */
	if (ctx->MAP_Cer && (MAP_PROFILE_R3 == ctx->map_version))
		dev_buffer_frame(ctx, be_to_host16(msg_hdr->message_type), mid, tlv, msg_leng);
#endif

    msg_hdr->message_id = host_to_be16(mid);
    /* temporarily set the fragment id & last fragment ind
     	  * these two variables will be updated.
        */
    msg_hdr->fragment_id = 0;
    msg_hdr->last_fragment_indicator = 1;
	/*recheck relay indicator*/
	if (msg_hdr->relay_indicator == 0x1) {
		if (memcmp(dmac, p1905_multicast_address, ETH_ALEN))
			msg_hdr->relay_indicator = 0x0;
	}

	/*insert message into retry queue to monitor if 1905_ack is received from the peer*/
	if (memcmp(dmac, zero_mac, ETH_ALEN)) {
		if (exist_in_retry_message_list(be_to_host16(msg_hdr->message_type))) {
			insert_retry_message_queue(dmac, smac, be_to_host16(msg_hdr->message_id),
				be_to_host16(msg_hdr->message_type), RETRY_CNT,
				sock, ifname, buffer, len);
		}
	}

#ifdef MAP_R3
	/* not perform encryption procedure for the following messages
	**	1905 AP-Autoconfiguration Search
	**	1905 AP-AutoconfigurationResponse
	**	Direct Encap DPP or 1905 Encap EAPOL*/
	if (ctx->map_version == MAP_PROFILE_R3) {
		unsigned char code = 0;
		struct security_entry *entry = NULL;
		if ((be_to_host16(msg_hdr->message_type) != _1905_ENCAP_EAPOL) &&
			(be_to_host16(msg_hdr->message_type) != DIRECT_ENCAP_DPP_MESSAGE) &&
			(be_to_host16(msg_hdr->message_type) != AP_AUTOCONFIG_SEARCH) &&
			(be_to_host16(msg_hdr->message_type) != AP_AUTOCONFIG_RESPONSE)) {
			/* buffer: whole msg
			** len total len include eth hdr and cmdu hdr
			*/
			entry = sec_entry_lookup(dmac);
			if (entry) {
				code = sec_encrypt(dmac, smac, buffer, &len, 0);
				if (code != SUC) {
					notice(DEBUG_CAT_DPP, "encry msg (0x%04x) error: %s to "MACSTR"\n",
						be_to_host16(msg_hdr->message_type), code2string(code), PRINT_MAC(dmac));
					return 0;
				}
				msg_leng = len - CMDU_HLEN - ETH_HLEN;
			}
		}
	}
#endif // #ifdef MAP_R3

	/*exceed the max frame size, do need to fragment TX*/
	if (msg_leng > MAX_TLVS_LENGTH) {
		if (cmdu_tx_fragment(ctx, buffer, len, ifname) < 0) {
			err(DEBUG_CAT_MSG, "fragment cmdu send fail\n");
			return -1;
		}
	} else {
		/*send to local interface*/
		errno = 0;
		if (send(sock, buffer, len, 0) < 0) {
			err(DEBUG_CAT_MSG, "cmdu send failed on %s; errno=%d(%s); "
				"sa="MACSTR"; da="MACSTR"; type=0x%04x(%s); mid=0x%04x\n",
				ifname, errno, strerror(errno), MAC2STR(smac), MAC2STR(dmac),
				be_to_host16(msg_hdr->message_type),
				get_1905_mtype_str(be_to_host16(msg_hdr->message_type)),
				be_to_host16(msg_hdr->message_id));
			return -1;
		}
	}
	debug(DEBUG_CAT_MSG, "cmdu send success to %s; "
			"sa="MACSTR"; da="MACSTR"; type=0x%04x(%s); mid=0x%04x\n", ifname,
			MAC2STR(smac), MAC2STR(dmac), be_to_host16(msg_hdr->message_type),
			get_1905_mtype_str(be_to_host16(msg_hdr->message_type)),
			be_to_host16(msg_hdr->message_id));

	return 0;
}




/**
 *  for cmdu message relay.
 *
 * \param  ctx  p1905_managerd_ctx context.
 * \param  buf  pointer of buffer for tx.
 * \param  len  transmit length.
 * \return error code
 */
int cmdu_bridge_relay(struct p1905_managerd_ctx *ctx,
                             unsigned char *buf, int len, unsigned int if_index)
{
	int length = 0;

	errno = 0;
	length = send(ctx->sock_inf_recv_1905[if_index], buf, len, 0);
	if (length < 0) {
		err(DEBUG_CAT_MSG, "relay failed on %s; errno=%d(%s)\n",
			(char *)ctx->itf[if_index].if_name, errno, strerror(errno));
		err_hexdump(DEBUG_CAT_MSG, "failed relay cmdu: ", buf, (ETH_HLEN + CMDU_HLEN));
        return -1;
    }

    return 0;
}

/**
 *  for cmdu message relay.
 *
 * \param  ctx  p1905_managerd_ctx context.
 * \param  buf  pointer of buffer for tx.
 * \param  len  transmit length.
 * \return error code
 */
int cmdu_bridge_relay_send(struct p1905_managerd_ctx *ctx,
            unsigned char *smac, unsigned char *buf, int len)
{
	unsigned int i = 0;

	for (i = 0; i < ctx->itf_number; i++) {
		if (i != ctx->recent_cmdu_rx_if_number && (ctx->itf[i].trx_config & TX_MUL))
			cmdu_bridge_relay(ctx, buf, len, i);
	}

    return 0;
}

/**
 *  parse cmdu.
 *
 * \param  ctx  p1905_managerd_ctx context.
 * \param  buf  pointer of buffer for rx.
 * \param  len  receive length.
 * \return error code
 */
int cmdu_parse(struct p1905_managerd_ctx *ctx, unsigned char *buf, int len)
{
	struct ethhdr *eth_hdr;
	unsigned char *temp_buf;
	int ret = 0;

	eth_hdr = (struct ethhdr *)buf;

	/* examine the dst mac address to decide if we need to parse this packet */
	if (!cmdu_dst_mac_check(ctx, eth_hdr->h_dest)) {
		debug(DEBUG_CAT_MSG, "dst check fail\n");
		return 0;
	}

	/* examine the received cmdu is from us, then drop it */
	if (cmdu_src_mac_check(ctx, eth_hdr->h_source)) {
		err(DEBUG_CAT_MSG, "cmdu sa("MACSTR") is me", MAC2STR(eth_hdr->h_source));
		return -1;
	}

	/* shift to cmdu message start position */
	temp_buf = buf;
	temp_buf += ETH_HLEN;

#ifdef EM_PLUS_EXT_SUPPORT
	if (ctx->map_version == MAP_PROFILE_R2 && (ctx->security_enabled == 0))
		/* Set MAP version to R2 when MAP R3 is received*/
		ctx->map_version = MAP_PROFILE_R3;
#endif

	ret = parse_cmdu_message(ctx, temp_buf, eth_hdr->h_dest, eth_hdr->h_source, len);
	if (ret == -1) {
		err(DEBUG_CAT_MSG, "parse_cmdu_message fail\n");
		return -1;
	}

	if (ctx->need_relay) {
		ctx->need_relay = 0;
		/*change to our almac, because some device may drop multicast not sending by neighbor*/
		memcpy(eth_hdr->h_source, ctx->p1905_al_mac_addr, ETH_ALEN);
#ifdef MAP_R3
		if (ctx->map_version == MAP_PROFILE_R3) {
			unsigned char code = 0;
			unsigned short length = 0;
			struct security_entry *entry = NULL;

			length = len;

			entry = sec_entry_lookup(eth_hdr->h_dest);
			if (entry) {
				code = sec_encrypt(eth_hdr->h_dest, eth_hdr->h_source,
									buf, &length, 0);
				if (code != SUC) {
					notice(DEBUG_CAT_DPP, "encry error: %s to "MACSTR"\n",
					code2string(code), PRINT_MAC(eth_hdr->h_dest));
					return -1;
				}
				len = length;
			}
		}
#endif
		cmdu_bridge_relay_send(ctx, eth_hdr->h_source, buf, len);
	}

	return 0;
}

int common_process(struct p1905_managerd_ctx *ctx, struct buf_info *buf)
{
	/*if any cmdu need to be transmited , it will be sent here*/
	if (process_cmdu_txq(ctx, buf->buf) < 0)
		return -1;

	/*handle message wait queue*/
	handle_message_wait_queue(ctx, buf->buf);

	return 0;
}

void cmdu_process(int sock, void *eloop_ctx, void *sock_ctx)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx*)eloop_ctx;
	struct buf_info *buf = &ctx->trx_buf;
	struct ethhdr *eth_hdr = NULL;
	int len = MAX_PKT_LEN;
	unsigned int j = 0;
	unsigned char intf_mac[6];

	if (sock == ctx->sock_br) {
		errno = 0;
		len = recv(sock, buf->buf, MAX_PKT_LEN, 0);
		if (len < 0) {
			err(DEBUG_CAT_MSG, "receive failed on %s; errno=%d(%s)",
				ctx->br_name, errno, strerror(errno));
			return;
		}
		eth_hdr = (struct ethhdr *)buf->buf;
		if (get_receive_port_addr(ctx->br_name, eth_hdr->h_source, intf_mac) < 0) {
			err(DEBUG_CAT_MSG, "get_receive_port_addr fail, sa="MACSTR"\n",
				MAC2STR(eth_hdr->h_source));
			goto error;
		}
		for (j = 0; j < ctx->itf_number; j++) {
			if (!os_memcmp(ctx->itf[j].mac_addr, intf_mac, sizeof(intf_mac))) {
				/*add this to tell which inf recv the cmdu*/
				ctx->recent_cmdu_rx_if_number = j;
				break;
			}
		}
		if (j >= ctx->itf_number) {
			err(DEBUG_CAT_MSG, "no any local interface match the mac("MACSTR")\n",
				MAC2STR(intf_mac));
			goto error;
		}
		if (!(ctx->itf[j].trx_config & (RX_MUL | RX_UNI))) {
			notice(DEBUG_CAT_MSG, "drop rx packet on %s; no rx cap\n",
				ctx->itf[j].if_name);
			goto error;
		}
	} else {
		errno = 0;
		len = recv(sock, buf->buf, MAX_PKT_LEN, 0);
		if (len < 0) {
			err(DEBUG_CAT_MSG, "receive failed on %s; errno=%d(%s)",
				ctx->itf[j].if_name, errno, strerror(errno));
			return;
		}

		for (j = 0; j < ctx->itf_number; j++) {
			if (sock == ctx->sock_inf_recv_1905[j]) {
				ctx->recent_cmdu_rx_if_number = j;
				break;
			}
		}

		if (j >= ctx->itf_number) {
			err(DEBUG_CAT_MSG, "no any local interface match this sock\n");
			goto error;
		}

		if (!(ctx->itf[j].trx_config & (RX_MUL | RX_UNI))) {
			notice(DEBUG_CAT_MSG, "drop rx packet on %s; no rx cap\n",
				ctx->itf[j].if_name);
			goto error;
		}
	}

	if (cmdu_parse(ctx, buf->buf, len) < 0)
		goto error;

	common_process(ctx, buf);

	return;

error:
	err_hexdump(DEBUG_CAT_MSG, "drop recv cmdu: ", buf->buf, (ETH_HLEN + CMDU_HLEN));
}

void multicast_cmdu_tx(struct p1905_managerd_ctx *ctx, unsigned short type,
	unsigned short mid, int relayed)
{
	int i = 0;

	debug(DEBUG_CAT_MSG, "tx multicast to all bh intf; type=%04x(%s); mid=%04x\n",
		type, get_1905_send_mtype_str(type), mid);

	for (i = 0; i < ctx->itf_number; i++) {
		if (!(ctx->itf[i].trx_config & (TX_MUL | TX_UNI))) {
			debug(DEBUG_CAT_MSG, "drop tx packet with mtype=%d(%s) on %s;"
				" this intf is not a bh interface\n",
				type, get_1905_send_mtype_str(type), ctx->itf[i].if_name);
			continue;
		}
		insert_cmdu_txq((unsigned char *)p1905_multicast_address, ctx->p1905_al_mac_addr,
				type, mid, ctx->itf[i].if_name, 0);
		if (relayed == 0)
			continue;
#ifdef SUPPORT_CMDU_RELIABLE
		cmdu_reliable_send(ctx, type, mid, i);
#endif
	}
}

void multicast_cmdu_tx_eth(struct p1905_managerd_ctx *ctx, unsigned short type,
	unsigned short mid, int relayed)
{
	int i = 0;

	notice(DEBUG_CAT_MSG, "tx multicast to all eth intf; type=%04x(%s); mid=%04x\n",
		type, get_1905_send_mtype_str(type), mid);
	for (i = 0; i < ctx->itf_number; i++) {
		if (ctx->itf[i].media_type > IEEE802_3_AB_GROUP)
			continue;
		if (!(ctx->itf[i].trx_config & (TX_MUL | TX_UNI))) {
			debug(DEBUG_CAT_MSG, "drop tx packet with mtype=%d(%s) on %s;"
				" this intf is not a bh interface\n",
				type, get_1905_send_mtype_str(type), ctx->itf[i].if_name);
			continue;
		}
		insert_cmdu_txq((unsigned char *)p1905_multicast_address, ctx->p1905_al_mac_addr,
				type, mid, ctx->itf[i].if_name, 0);
		if (relayed == 0)
			continue;
#ifdef SUPPORT_CMDU_RELIABLE
		cmdu_reliable_send(ctx, type, mid, i);
#endif
	}
}

void lldp_tx(struct p1905_managerd_ctx *ctx, unsigned char *buf)
{
	unsigned int i = 0;
	int ret = 0;

	for (i = 0; i < ctx->itf_number; i++) {
		if (!(ctx->itf[i].trx_config & (TX_MUL | TX_UNI))) {
			debug(DEBUG_CAT_MSG, "drop lldp on %s;"
				" this intf is not a bh interface\n",
				ctx->itf[i].if_name);
			continue;
		}
		ret = send_802_1_bridge_discovery_msg(ctx,
			nearest_bridge_group_address, ctx->itf[i].mac_addr,
			buf, i);
		if (ret < 0)
			err(DEBUG_CAT_MSG, "send lldpdu fail on %s\n", ctx->itf[i].if_name);
		else
			info(DEBUG_CAT_MSG, "send lldpdu succ on %s\n", ctx->itf[i].if_name);
	}
}

int create_sock_for_new_intf(struct p1905_managerd_ctx *ctx, int index)
{
	struct sockaddr_ll sll;
	struct ifreq ifr;
	int ret = 0;

	if (!ctx || index < 0 || index >= ITF_NUM) {
		warn(DEBUG_CAT_INIT, DYN_INTF_PREX"input parameter invalid(%d)", index);
		return -1;
	}

	ctx->sock_inf_recv_1905[index] = socket(AF_PACKET, SOCK_RAW, ETH_P_1905);
	if (ctx->sock_inf_recv_1905[index] < 0) {
		warn(DEBUG_CAT_INIT, "cannot open socket on %s (%s)", ctx->itf[index].if_name, strerror(errno));
		return -1;
	}
	ret = snprintf(ifr.ifr_name, sizeof(ifr.ifr_name), "%s", ctx->itf[index].if_name);
	if (os_snprintf_error(sizeof(ifr.ifr_name), ret)) {
		warn(DEBUG_CAT_INIT, "[%d]snprintf fail\n", __LINE__);
		close(ctx->sock_inf_recv_1905[index]);
		return -1;
	}
	if (-1 == (ioctl(ctx->sock_inf_recv_1905[index], SIOCGIFINDEX, &ifr))) {
		warn(DEBUG_CAT_INIT, "cannot get interface %s index (%s) i=%d\n",
				ctx->itf[index].if_name, strerror(errno), index);
		close(ctx->sock_inf_recv_1905[index]);
		return -1;
	}

	sll.sll_family = AF_PACKET;
	sll.sll_ifindex = ifr.ifr_ifindex;
	ctx->itf[index].if_index = ifr.ifr_ifindex;
	sll.sll_protocol = host_to_be16(ETH_P_1905);

	if (-1 == bind(ctx->sock_inf_recv_1905[index], (struct sockaddr *)&sll, sizeof(struct sockaddr_ll))) {
		warn(DEBUG_CAT_INIT, "cannot bind raw socket to interface %s (%s)", ctx->itf[index].if_name, strerror(errno));
		close(ctx->sock_inf_recv_1905[index]);
		return -1;
	}

	notice(DEBUG_CAT_INIT, "create sock for %s sock(%d)\n", ctx->itf[index].if_name, ctx->sock_inf_recv_1905[index]);

	return 0;
}

