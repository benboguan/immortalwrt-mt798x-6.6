/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <errno.h>
#include <linux/if_packet.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <syslog.h>
#include <assert.h>
#include <linux/if_ether.h>
#include <asm/byteorder.h>
#include "cmdu_message_parse.h"
#include "cmdu_tlv_parse.h"
#include "cmdu_tlv.h"
#include "cmdu_message.h"
#include "cmdu_fragment.h"
#include "cmdu_retry_message.h"
#include "multi_ap.h"
#include "cmdu.h"
#include "_1905_lib_io.h"
#include "debug.h"
#include "common.h"
#include "topology.h"
#include "eloop.h"
#include "ethernet_layer.h"
#include "file_io.h"
#include "p1905_ap_autoconfig.h"
#include "service_prioritization.h"

#ifdef MAP_R3
#include "map_dpp.h"
#include "wpa_extern.h"
#include "security_engine.h"
#include "wpabuf.h"
#include "json.h"
#endif
#ifdef MAP_R5
#include "qos.h"
#endif
#ifdef EM_PLUS_SUPPORT
#include "emplus.h"
#include "mapfilter_if.h"
#include "vlan_util.h"
#endif

static unsigned char p1905_multicast_address[6]
	= { 0x01, 0x80, 0xc2, 0x00, 0x00, 0x13 };
#ifdef MAP_R3
/* temporary memory to store r3 onboarding info */
struct r3_onboarding_info r3_ctx_tmp;
#endif

#ifdef EM_PLUS_SUPPORT
int update_vlan_tag_inf(struct p1905_managerd_ctx *ctx, unsigned char *ifname, int add)
{
	int i, j, ret;
	int primary_vlan = INVALID_VLAN_ID, guest_vlan = INVALID_VLAN_ID, vid = 0;
	struct config_bss_info *bss;
	struct ssid_2_vid_mapping *mapping = NULL, *tmp_mapping;
	struct traffics_policy *pts_policy = &ctx->map_policy.tpolicy;
	struct traffic_separation_db *policy_db = NULL;
	char primary_vlan_intf[IFNAMSIZ] = {0};
	char guest_vlan_intf[IFNAMSIZ] = {0};

	notice(DEBUG_CAT_EMPLUS, "[VLAN]add traffic seperation inf %s", ifname);

	mapping = os_zalloc(pts_policy->SSID_num * sizeof(struct ssid_2_vid_mapping));
	if (!mapping)
		return -1;

	tmp_mapping = mapping;

	SLIST_FOREACH(policy_db, &(pts_policy->policy_head), policy_entry) {
		mapping->vlan_id = policy_db->vid;
		os_memcpy(mapping->ssid, policy_db->SSID, policy_db->SSID_len);
		mapping->ssid[sizeof(mapping->ssid) - 1] = '\0';
		notice(DEBUG_CAT_EMPLUS, "[VLAN]set_traffic_policy:%s --> %d\n", mapping->ssid, mapping->vlan_id);
		mapping++;
	}

	mapping = tmp_mapping;

	for (i = 0; i < ctx->radio_number; i++) {
		for (j = 0; j < ctx->rinfo[i].bss_number; j++) {
			bss = &ctx->rinfo[i].bss[j];

			notice(DEBUG_CAT_EMPLUS, "[VLAN] %s bss->config_status=%d\n", bss->ifname, bss->config_status);
			if (bss->config_status == 0)
				continue;

			vid = get_vid_from_ssid((char *)bss->config.Ssid, pts_policy->SSID_num, mapping);

			if (!os_memcmp(bss->config.ssid_label, GUEST_SSID_LABEL_PREFIX, strlen(GUEST_SSID_LABEL_PREFIX)))
				guest_vlan = vid;
			else if (!os_memcmp(bss->config.ssid_label, FH_SSID_LABEL_PREFIX, strlen(FH_SSID_LABEL_PREFIX)))
				primary_vlan = vid;

			if (primary_vlan != INVALID_VLAN_ID && guest_vlan != INVALID_VLAN_ID)
				break;
		}
		if (primary_vlan != INVALID_VLAN_ID && guest_vlan != INVALID_VLAN_ID)
			break;
	}

	notice(DEBUG_CAT_EMPLUS, "[VLAN] primary_vlan %d guest_vlan %d\n", primary_vlan, guest_vlan);
	ret = snprintf(primary_vlan_intf, sizeof(primary_vlan_intf), "%s.%d", ifname, primary_vlan);
	if (os_snprintf_error(sizeof(primary_vlan_intf), ret)) {
		notice(DEBUG_CAT_EMPLUS, "[VLAN] primary_vlan_intf snprintf fail!\n");
		os_free(mapping);
		return -1;
	}
	notice(DEBUG_CAT_EMPLUS, "[VLAN] primary_vlan %s\n", primary_vlan_intf);

	ret = snprintf(guest_vlan_intf, sizeof(guest_vlan_intf), "%s.%d", ifname, guest_vlan);
	if (os_snprintf_error(sizeof(guest_vlan_intf), ret)) {
		notice(DEBUG_CAT_EMPLUS, "[VLAN] guest_vlan_intf snprintf fail!\n");
		os_free(mapping);
		return -1;
	}
	notice(DEBUG_CAT_EMPLUS, "[VLAN] guest_vlan %s\n", guest_vlan_intf);

	if (add) {
		if (primary_vlan != INVALID_VLAN_ID && add == 1) {
			vlan_add((const char *)ifname, primary_vlan, primary_vlan_intf);
			ifconfig_up(primary_vlan_intf);
			switch_bridge_add_inf((const char *)ctx->br_name, primary_vlan_intf);
		}

		if (guest_vlan != INVALID_VLAN_ID) {
			vlan_add((const char *)ifname, guest_vlan, guest_vlan_intf);
			ifconfig_up(guest_vlan_intf);
			switch_bridge_add_inf((const char *)ctx->guest_br_name, guest_vlan_intf);
		}
	} else {
		if (primary_vlan != INVALID_VLAN_ID) {
			switch_bridge_del_inf((const char *)ctx->br_name, primary_vlan_intf);
			ifconfig_down(primary_vlan_intf);
			vlan_rem(primary_vlan_intf);
		}

		if (guest_vlan != INVALID_VLAN_ID) {
			switch_bridge_del_inf((const char *)ctx->guest_br_name, guest_vlan_intf);
			ifconfig_down(guest_vlan_intf);
			vlan_rem(guest_vlan_intf);
		}
	}
	os_free(mapping);
	return 0;
}
#endif

/**
 *  parse topology discovery message
 *
 *
 * \param  ctx  1905.1 managerd context
 * \param  buf  input, tlvs start position of receive cmdu packet
 * \param  left_tlv_len  input, 1905 message's tlv length
 * \param  query  flag for sending topology query
 * \param  notify  flag for sending topology notification
 * \param  al_mac  output al mac address from this message
 * \return error code
 */
int parse_topology_discovery_message(struct p1905_managerd_ctx *ctx,
				     unsigned char *buf, unsigned int left_tlv_len,
				     unsigned char *query, unsigned char *notify,
				     unsigned char *discovery, unsigned char *al_mac, unsigned char *mac_addr,
				     unsigned char *smac)
{
	unsigned char *type = NULL;
	unsigned short len = 0;
	unsigned char *value = NULL;
	unsigned int tlv_len = 0;
	int ret = 0;
	unsigned char al_mac_addr[ETH_ALEN];
	unsigned char itf_mac_addr[ETH_ALEN] = { 0 };
	unsigned char zero_mac[ETH_ALEN] = { 0 };
	unsigned char peer_itf_mac[ETH_ALEN] = { 0 };
	struct topology_discovery_db *tpg_db = NULL;
	unsigned char new_db = 1, if_sta = 0, if_eth = 0;
	unsigned int integrity = 0, ifid = 0;
	unsigned int right_integrity = 0x3;
	int eth_port = -1;
	struct vs_value vs_info;
	unsigned char mtk_oui[3] = {0x00, 0x0C, 0xE7};
	unsigned char mtk_tpd = 0;
#ifdef EM_PLUS_SUPPORT
	struct topology_response_db *topo_rsp = NULL;
	unsigned char controller = 0, i = 0;
#endif

	os_memset(&vs_info, 0, sizeof(struct vs_value));
	*discovery = 0;
	*query = 0;
	*notify = 0;
	type = buf;

	while (1) {
		if (left_tlv_len < 3)
			return -1;
		len = get_tlv_len(type);
		value = type + 3;
		tlv_len = len + 3;
		if (left_tlv_len < tlv_len)
			return -1;

		if (*type == AL_MAC_ADDR_TLV_TYPE) {
			integrity |= (1 << 0);
			ret = parse_al_mac_addr_type_tlv(al_mac_addr, len, value);
			if (ret < 0) {
				err(DEBUG_CAT_MSG, "err AL_MAC_ADDR tlv\n");
				return -1;
			}
		} else if (*type == MAC_ADDR_TLV_TYPE) {
			integrity |= (1 << 1);
			ret = parse_mac_addr_type_tlv(peer_itf_mac, len, value);
			if (ret < 0) {
				err(DEBUG_CAT_MSG, "err MAC_ADDR tlv\n");
				return -1;
			}
		} else if (*type == VENDOR_SPECIFIC_TLV_TYPE) {
			ret = parse_vs_tlv(&vs_info, len, value);
			if (ret < 0) {
				err(DEBUG_CAT_MSG, "err VENDOR_SPECIFIC tlv\n");
				return -1;
			}
			if (!os_memcmp(value, mtk_oui, 3) && vs_info.discovery)
				mtk_tpd = 1;
		} else if (*type == END_OF_TLV_TYPE) {
			break;
		}

		type += tlv_len;
		left_tlv_len -= tlv_len;
	}
	/*check integrity */
	if (integrity != right_integrity) {
		err(DEBUG_CAT_MSG, "lack of mandatory tlv; integrity=%d\n", integrity);
		return -1;
	}

	if ((integrity&BIT(1)) && os_memcmp(zero_mac, peer_itf_mac, ETH_ALEN))
		os_memcpy(mac_addr, peer_itf_mac, ETH_ALEN);

	/*sw solution for BCM */
	if (check_C_and_A_concurrent_by_discovery(ctx, al_mac_addr, mac_addr) < 0) {
#ifdef EM_PLUS_EXT_SUPPORT
		memcpy(ctx->gw_agent_dcv.al_mac, al_mac_addr, ETH_ALEN);
		memcpy(ctx->gw_agent_dcv.itf_mac, mac_addr, ETH_ALEN);
		memcpy(ctx->gw_agent_dcv.receive_itf_mac, vs_info.itf_mac, ETH_ALEN);
		if (!os_memcmp(zero_mac, ctx->gw_agent_dcv.receive_itf_mac, ETH_ALEN))
			os_memcpy(ctx->gw_agent_dcv.receive_itf_mac, ctx->itf[ctx->recent_cmdu_rx_if_number].mac_addr, ETH_ALEN);
		ctx->gw_agent_dcv.time_to_live = TOPOLOGY_DISCOVERY_TTL;

		debug(DEBUG_CAT_MSG, "GW-A-disc-almac("MACSTR") intf_mac("MACSTR") received-inf("MACSTR") TTL(%d)\n",
				MAC2STR(ctx->gw_agent_dcv.al_mac), MAC2STR(ctx->gw_agent_dcv.itf_mac),
				MAC2STR(ctx->gw_agent_dcv.receive_itf_mac),
				ctx->gw_agent_dcv.time_to_live = TOPOLOGY_DISCOVERY_TTL);
#endif
		return -1;
	}

	*discovery = vs_info.discovery;
	os_memcpy(al_mac, al_mac_addr, ETH_ALEN);
	os_memcpy(itf_mac_addr, vs_info.itf_mac, ETH_ALEN);
	if (!os_memcmp(zero_mac, itf_mac_addr, ETH_ALEN)) {
		os_memcpy(itf_mac_addr, ctx->itf[ctx->recent_cmdu_rx_if_number].mac_addr, ETH_ALEN);
		warn(DEBUG_CAT_TOPO, "don't get recv intf from mapfilter; set to "MACSTR"\n",
		      MAC2STR(itf_mac_addr));
	} else if (os_memcmp(vs_info.itf_mac, ctx->itf[ctx->recent_cmdu_rx_if_number].mac_addr, ETH_ALEN)) {
		for (ifid = 0; ifid < ctx->itf_number; ifid++) {
			if (!os_memcmp(ctx->itf[ifid].mac_addr, vs_info.itf_mac, ETH_ALEN)) {
				ctx->recent_cmdu_rx_if_number = ifid;
				warn(DEBUG_CAT_TOPO, "reset recent_cmdu_rx_if_number to %d(%s) due to mismatch\n",
					ifid, ctx->itf[ifid].if_name);
				break;
			}
		}
	}

	ifid = ctx->recent_cmdu_rx_if_number;
	if (ctx->itf[ifid].is_wifi_sta) {
		if_sta = 1;
	} else if (ctx->itf[ifid].media_type <= IEEE802_3_AB_GROUP) {
		if_eth = 1;
		if (ctx->itf[ifid].is_veth == 1)
			if_eth = 0;
	}

	if (!ctx->MAP_Cer) {
		/*for eth device, we should get which switch port this topology discoery comes from */
		if (if_eth) {
			eth_port = eth_layer_get_client_port_by_mac(al_mac_addr);
			if (eth_port == ETH_ERROR_FAIL) {
				err(DEBUG_CAT_TOPO, "fail to get eth_port for discovery with almac "MACSTR" on %s\n",
					MAC2STR(al_mac_addr), ctx->itf[ifid].if_name);
				return -1;
			}
		} else {
			eth_port = -1;
		}

		if (eth_port >= 0 && ctx->conn_port.is_set &&
		    ctx->conn_port.port_num == eth_port &&
		    os_memcmp(ctx->conn_port.filter_almac, al_mac_addr, ETH_ALEN)) {
#ifdef EM_PLUS_SUPPORT
			/* In GW A & C corner case controller topology response received before it's discovery */
			/* this will update agent almac if it's topology discovery already present */
			/* result into controller topology discovery never updated */
			topo_rsp = find_response_by_almac(ctx, al_mac_addr);
			controller = 0;
			for (i = 0; topo_rsp && i < topo_rsp->support_service_cnt; i++) {
				if (topo_rsp->support_service[i] == 0)
					controller = 1;
			}
			if (controller) {
				notice(DEBUG_CAT_GPON, "conn_port(%d) set due to recv topo rsp from C; set "MACSTR"to filter_almac\n",
					eth_port, MAC2STR(al_mac_addr));
				os_memcpy(ctx->conn_port.filter_almac, al_mac_addr, ETH_ALEN);
			} else {
				info(DEBUG_CAT_GPON, "conn_port(%d) set; drop discovery"MACSTR" from agent\n",
					eth_port, MAC2STR(al_mac_addr));
				return -1;
			}
#else
			info(DEBUG_CAT_TOPO,  "GPON case(recv discovery of C and A on the same eth_port(%d));"
				" drop A discovery with almac "MACSTR"\n",
			    eth_port, PRINT_MAC(al_mac_addr));
			return -1;
#endif
		}
	}

	if (if_sta && ctx->itf[ifid].vs_info_length >= ETH_ALEN
	    && (os_memcmp(mac_addr, ctx->itf[ifid].vs_info, ETH_ALEN) != 0
#ifdef MAP_R6
		&& (os_memcmp(mac_addr, ctx->itf[ifid].bakchaul_bss_mld_addr, ETH_ALEN) != 0
			&& os_memcmp(ctx->itf[ifid].bakchaul_bss_mld_addr, zero_mac, ETH_ALEN) != 0)
#endif
		)
	    && os_memcmp(ctx->itf[ifid].vs_info, zero_mac, ETH_ALEN) != 0) {
		err(DEBUG_CAT_TOPO, "drop discovery from non-directly connected dev;"
			" recv intf=%s; connected bssid="MACSTR"; peer tx intf mac="MACSTR"\n",
		    ctx->itf[ifid].if_name,
			MAC2STR(ctx->itf[ifid].vs_info),
			MAC2STR(mac_addr));
		*query = 0;
		*notify = 0;
		return 0;
	}

	/*search the AL MAC ADDRESS exist or not */
	LIST_FOREACH(tpg_db, &ctx->topology_entry.tpddb_head, tpddb_entry) {
		/*compare the AL MAC ADDR and INF MAC ADDR with database */
		if (!memcmp(tpg_db->al_mac, al_mac_addr, ETH_ALEN) && !memcmp(tpg_db->itf_mac, mac_addr, ETH_ALEN)) {
			new_db = 0;
			break;
		}
	}

	if (new_db) {
		*query = 1;
		*notify = 1;
		/*no this AL MAC ADDR , add a new topology_discovery_db component in database */
		tpg_db = (struct topology_discovery_db *)malloc(sizeof(struct topology_discovery_db));
		if (!tpg_db) {
			err(DEBUG_CAT_MISC, "alloc tpg_db fail\n");
			return -1;
		}
		memset(tpg_db, 0, sizeof(*tpg_db));
		memcpy(tpg_db->al_mac, al_mac_addr, ETH_ALEN);
		memcpy(tpg_db->itf_mac, mac_addr, ETH_ALEN);
		memcpy(tpg_db->receive_itf_mac, itf_mac_addr, ETH_ALEN);
		tpg_db->time_to_live = TOPOLOGY_DISCOVERY_TTL;
		tpg_db->eth_port = -1;
		LIST_INSERT_HEAD(&ctx->topology_entry.tpddb_head, tpg_db, tpddb_entry);
#ifdef EM_PLUS_SUPPORT
		notice(DEBUG_CAT_TOPO, "new db: setting updated %d policy updated %d\n",
			ctx->map_policy.setting.updated, ctx->map_policy.tpolicy.updated);
		notice(DEBUG_CAT_TOPO, "new db: primary_vid %d ifname %s\n",
			ctx->map_policy.setting.primary_vid, vs_info.ifname);
		if (ctx->map_policy.setting.primary_vid != INVALID_VLAN_ID) {
			update_vlan_tag_inf(ctx, (unsigned char *) vs_info.ifname, 1);
			ctx->itf[ifid].update_vlan_tag = 1;
			tpg_db->update_vlan_tag = 1;
		}
#endif
	} else {
		tpg_db->time_to_live = TOPOLOGY_DISCOVERY_TTL;
	}

#ifdef EM_PLUS_SUPPORT
	if (tpg_db->update_vlan_tag == 0) {
		notice(DEBUG_CAT_TOPO, "primary_vid %d ifname %s\n",
			ctx->map_policy.setting.primary_vid, vs_info.ifname);
		if (ctx->map_policy.setting.primary_vid != INVALID_VLAN_ID) {
			update_vlan_tag_inf(ctx, (unsigned char *) vs_info.ifname, 1);
			ctx->itf[i].update_vlan_tag = 1;
		}
	}
#endif

	if (mtk_tpd)
		tpg_db->mtk_tpd = 1;

	if (tpg_db->eth_port != eth_port) {
		notice(DEBUG_CAT_TOPO, "port change; prev_port(%d) new_port(%d)\n", tpg_db->eth_port, eth_port);
		*query = 1;
	}
	tpg_db->eth_port = eth_port;

	if (*notify || *query || *discovery) {
		notice(DEBUG_CAT_TOPO, "recv discovery notice; almac="MACSTR"; peer intf="MACSTR"; "
	      "recv_intf=%s; new db=%d; eth_port=%d; "
	      "need_query=%d; need_notify=%d; need_discovery=%d\n",
	      PRINT_MAC(tpg_db->al_mac),
	      PRINT_MAC(tpg_db->itf_mac), ctx->itf[ifid].if_name, new_db, eth_port, *query, *notify, *discovery);
	}
	if (0 > update_p1905_neighbor_dev_info(ctx, al_mac_addr, mac_addr, itf_mac_addr, notify)) {
		err(DEBUG_CAT_TOPO, "update_p1905_neighbor_dev_info fail\n");
		return -1;
	}
	if (if_eth && eth_port >= 0 && new_db)
		*notify = 2;

	if (*notify)
		report_own_topology_rsp(ctx, ctx->p1905_al_mac_addr, ctx->br_cap,
					ctx->p1905_neighbor_dev, ctx->non_p1905_neighbor_dev,
					ctx->service, &ctx->ap_cap_entry.oper_bss_head,
					&ctx->ap_cap_entry.assoc_clients_head, ctx->cnt);

	return 0;
}

/**
 *  parse topology notification message
 *
 *
 * \param  ctx  1905.1 managerd context
 * \param  buf  input, tlvs start position of receive cmdu packet
 * \param  left_tlv_len  input, 1905 message's tlv length
 * \param  al_mac  output al mac address from this message
 * \return error code
 */
int parse_topology_notification_message(struct p1905_managerd_ctx *ctx,
					unsigned char *buf, unsigned int left_tlv_len,
					unsigned char *al_mac, unsigned char *bssid,
					unsigned char *mac, unsigned char *event, unsigned char *neth_almac)
{
	unsigned char *type = NULL;
	unsigned short len = 0;
	unsigned char *value = NULL;
	unsigned int tlv_len = 0;
	int ret = 0;
	unsigned char al_mac_addr[ETH_ALEN];
	unsigned int integrity = 0;
	unsigned int right_integrity = 0x1;
	struct vs_value vs_info;
	struct dl_list clients_table = {0};
#ifdef MAP_R2
	struct assoc_client *client = NULL;
	struct assoc_client *client_tmp = NULL;
	struct assoc_client *assoc_client = NULL;
#endif
	os_memset(&vs_info, 0, sizeof(struct vs_value));
	os_memset(al_mac_addr, 0, sizeof(al_mac_addr));
	type = buf;
	reset_stored_tlv(ctx);
	dl_list_init(&clients_table);

	while (1) {
		if (left_tlv_len < 3)
			goto fail;
		len = get_tlv_len(type);
		value = type + 3;
		tlv_len = len + 3;
		if (left_tlv_len < tlv_len)
			goto fail;

		if (*type == AL_MAC_ADDR_TLV_TYPE) {
			integrity |= (1 << 0);
			ret = parse_al_mac_addr_type_tlv(al_mac_addr, len, value);
			if (ret < 0) {
				err(DEBUG_CAT_MSG, "err AL_MAC_ADDR tlv\n");
				goto fail;
			}
			if (!memcmp(ctx->p1905_al_mac_addr, al_mac_addr, ETH_ALEN)) {
				err(DEBUG_CAT_MSG, "recv topology_notification_message sent by myself\n");
				goto fail;
			}
			store_revd_tlvs(ctx, type, (unsigned short)tlv_len);
		} else if (*type == CLIENT_ASSOCIATION_EVENT_TYPE) {
			ret = parse_client_assoc_event_tlv(ctx, mac, bssid, event, al_mac_addr,
				len, value, &clients_table);
			if (ret < 0) {
				err(DEBUG_CAT_MSG, "err CLIENT_ASSOCIATION_EVENT tlv\n");
				goto fail;
			}
			store_revd_tlvs(ctx, type, (unsigned short)tlv_len);
		} else if (*type == VENDOR_SPECIFIC_TLV_TYPE) {
			ret = parse_vs_tlv(&vs_info, len, value);
			if (ret < 0) {
				err(DEBUG_CAT_MSG, "error vs tlv\n");
				goto fail;
			}
		} else if (*type == END_OF_TLV_TYPE) {
			break;
		} else {
			/*ignore extra tlv */
			store_revd_tlvs(ctx, type, (unsigned short)tlv_len);
		}

		type += tlv_len;
		left_tlv_len -= tlv_len;
	}

	/*check integrity */
	if (integrity != right_integrity) {
		err(DEBUG_CAT_MSG, "lack of mandatory tlv; integrity=%d\n", integrity);
		goto fail;
	}

#ifdef MAP_R2
	if (!dl_list_empty(&clients_table)) {
		unsigned char hash = 0;

		dl_list_for_each_safe(client, client_tmp, &clients_table, struct assoc_client, entry) {
			dl_list_del(&client->entry);
			assoc_client = get_assoc_cli_by_mac(ctx, client->mac);
			if (assoc_client) {
				/* keep sta in client db once sta steer from peer to me */
				if (os_memcmp(client->bssid, assoc_client->bssid, ETH_ALEN))
					client->disassoc = 0;
				assoc_client->disassoc = client->disassoc;
				free(client);
				client = NULL;
			} else {
				hash = MAC_ADDR_HASH_INDEX(client->mac);
				dl_list_add(&ctx->clients_table[hash], &client->entry);
			}
		}
	}
#endif

#ifdef MAP_R2
	maintain_all_assoc_clients(ctx);
#endif
	os_memcpy(al_mac, al_mac_addr, ETH_ALEN);
	os_memcpy(neth_almac, vs_info.neth_almac, ETH_ALEN);
	return 0;
fail:

#ifdef MAP_R2
	if (!dl_list_empty(&clients_table)) {
		dl_list_for_each_safe(client, client_tmp, &clients_table, struct assoc_client, entry) {
			dl_list_del(&client->entry);
			free(client);
		}
	}
#endif
	return -1;
}

#ifdef BR_IP_TLV_SUPPORT
int parse_vendor_tlv(unsigned char *buf)
{
	unsigned char *temp_buf;
	int left = 0, length = 0;
	u8 MTK_OUI[OUI_LEN] = {0x00, 0x0C, 0xE7};
	struct br_info *pbr_info = NULL;
	struct in_addr sin_addr;

	temp_buf = buf;

	if ((*temp_buf) == VENDOR_SPECIFIC_TLV_TYPE)
		temp_buf++;
	else
		return -1;

	length = (*temp_buf);
	length = (length << 8) & 0xFF00;
	length = length | (*(temp_buf + 1));
	temp_buf += 2;

	left = length;
	if (left < sizeof(MTK_OUI)) {
		err(DEBUG_CAT_MSG, "len pre check fail\n");
		goto error;
	}

	left -= sizeof(MTK_OUI);

	if (os_memcmp(temp_buf, MTK_OUI, sizeof(MTK_OUI)))
		return length;

	temp_buf += 3;

	if (*temp_buf == BR_IP_TYPE) {
		temp_buf += 1;
		left -= 1;
		if (left == sizeof(struct br_info)) {
			pbr_info = (struct br_info *)temp_buf;
			sin_addr.s_addr = pbr_info->br_ip;
		}
	}
	return length;
}
#endif /* BR_IP_TLV_SUPPORT */

/**
 *  parse topology notification message
 *
 *
 * \param  ctx  1905.1 managerd context
 * \param  buf  input, tlvs start position of receive cmdu packet
 * \return error code
 */
int parse_topology_response_message(struct p1905_managerd_ctx *ctx, unsigned char *buf, unsigned int left_tlv_len,
	unsigned char *almac, unsigned char *profile)
{
	unsigned char *type = NULL;
	unsigned short len = 0;
	unsigned char *value = NULL;
	unsigned int tlv_len = 0;
	int ret = 0;
	unsigned int left = 0;
	unsigned char al_mac_addr[ETH_ALEN];
	struct topology_response_db *tpgr_db;
	unsigned int integrity = 0;
	unsigned int right_integrity = 0x3;
	unsigned char map_profile = MAP_PROFILE_R1;
#ifdef MAP_R2
	struct dl_list bss_head = {0};
	struct dl_list clients_table = {0};
	struct assoc_client *client = NULL;
	struct assoc_client *client_tmp = NULL;
	struct assoc_client *assoc_client = NULL;
	struct operational_bss *bss = NULL;
	struct operational_bss *bss_tmp = NULL;
#endif
	struct list_head_devinfo devinfo_list = {0};
	struct device_info_db *dev = NULL;
	struct device_info_db *dev_tmp = NULL;
	struct list_head_brcap brcap_list = {0};
	struct device_bridge_capability_db *br = NULL;
	struct device_bridge_capability_db *br_tmp = NULL;

	type = buf;
	left = left_tlv_len;

	/*we must get the AL MAC addr to get correct database pointer
	 * , so need to search device info tlv  firstly
	 */
	while (1) {
		if (left < 3)
			return -1;
		len = get_tlv_len(type);
		tlv_len = len + 3;
		if (left < tlv_len)
			return -1;

		if ((*type) == DEVICE_INFO_TLV_TYPE) {
			/* type +3 shift to AL MAC addr field in device information tlv */
			memcpy(al_mac_addr, type + 3, ETH_ALEN);
			memcpy(almac, al_mac_addr, ETH_ALEN);
			integrity |= (1 << 0);
		} else if (*type == SUPPORTED_SERVICE_TLV_TYPE)
			integrity |= (1 << 1);
		else if (*type == END_OF_TLV_TYPE)
			break;

		type += tlv_len;
		left -= tlv_len;
	}

	/*check integrity */
	if (integrity != right_integrity) {
		err(DEBUG_CAT_MSG, "lack of mandatory tlv; integrity=%d\n", integrity);
		return -1;
	}

	/*delete the database if already exist */
	tpgr_db = delete_exist_topology_response_content(ctx, al_mac_addr);
	if (!tpgr_db) {
		/*add a new topology_response_db component in database */
		tpgr_db = (struct topology_response_db *)os_zalloc(sizeof(struct topology_response_db));
		if (tpgr_db == NULL) {
			err(DEBUG_CAT_MISC, "alloc memory for tpgr_db fail\n");
			return -1;
		}
		os_memcpy(tpgr_db->al_mac_addr, al_mac_addr, ETH_ALEN);
		SLIST_INSERT_HEAD(&(ctx->topology_entry.tprdb_head), tpgr_db, tprdb_entry);
	}
	os_get_time(&tpgr_db->last_seen);
	tpgr_db->recv_ifid = ctx->recent_cmdu_rx_if_number;
	tpgr_db->valid = 1;
	/*init its own device information list and bridge capacity list */
	SLIST_INIT(&tpgr_db->devinfo_head);
	LIST_INIT(&tpgr_db->brcap_head);
#ifdef MAP_R2
	dl_list_init(&bss_head);
	dl_list_init(&clients_table);
#endif
	SLIST_INIT(&devinfo_list);
	LIST_INIT(&brcap_list);

	/* until now, we get the correct pointer
	 * Move to the start of buf, then do tlvs parsing
	 */
	type = buf;
	left = left_tlv_len;
	reset_stored_tlv(ctx);
	while (1) {
		if (left < 3)
			goto fail;
		len = get_tlv_len(type);
		value = type + 3;
		tlv_len = len + 3;
		if (left < tlv_len)
			goto fail;

		if (*type == DEVICE_INFO_TLV_TYPE) {
			/*then shift back to start of device info tlv, parsing it first */
			ret = parse_device_info_type_tlv(ctx, &devinfo_list, len, value);
			if (ret < 0) {
				err(DEBUG_CAT_MSG, "err DEVICE_INFO tlv\n");
				goto fail;
			}
			integrity |= (1 << 0);
			store_revd_tlvs(ctx, type, (unsigned short)tlv_len);
		} else if (*type == BRIDGE_CAPABILITY_TLV_TYPE) {
			ret = parse_bridge_capability_type_tlv(&brcap_list, len, value);
			if (ret < 0) {
				err(DEBUG_CAT_MSG, "err BRIDGE_CAPABILITY tlv\n");
				goto fail;
			}
			integrity |= (1 << 1);
			store_revd_tlvs(ctx, type, (unsigned short)tlv_len);
		} else if (*type == P1905_NEIGHBOR_DEV_TLV_TYPE) {
			ret = parse_p1905_neighbor_device_type_tlv(&devinfo_list, len, value);
			if (ret < 0) {
				err(DEBUG_CAT_MSG, "err P1905_NEIGHBOR_DEV tlv\n");
				goto fail;
			}
			integrity |= (1 << 2);
			store_revd_tlvs(ctx, type, (unsigned short)tlv_len);
		} else if (*type == NON_P1905_NEIGHBOR_DEV_TLV_TYPE) {
			ret = parse_non_p1905_neighbor_device_type_tlv(&devinfo_list, len, value);
			if (ret < 0) {
				err(DEBUG_CAT_MSG, "err NON_P1905_NEIGHBOR_DEV tlv\n");
				goto fail;
			}
			integrity |= (1 << 3);
			store_revd_tlvs(ctx, type, (unsigned short)tlv_len);
		} else if (*type == SUPPORTED_SERVICE_TLV_TYPE) {
			ret = parse_supported_service_tlv(tpgr_db->support_service, len, value, &tpgr_db->support_service_cnt);
			if (ret < 0) {
				err(DEBUG_CAT_MSG, "err SUPPORTED_SERVICE tlv\n");
				goto fail;
			}
			integrity |= (1 << 4);
			store_revd_tlvs(ctx, type, (unsigned short)tlv_len);
		}
#ifdef MAP_R2
		else if (*type == AP_OPERATIONAL_BSS_TYPE) {
			ret = parse_ap_operational_bss_tlv(ctx, al_mac_addr, len, value, &bss_head);
			if (ret < 0) {
				err(DEBUG_CAT_MSG, "err AP_OPERATIONAL_BSS tlv\n");
				goto fail;
			}
			integrity |= (1 << 5);
			store_revd_tlvs(ctx, type, (unsigned short)tlv_len);
		} else if (*type == AP_ASSOCIATED_CLIENTS_TYPE) {
			ret = parse_assoc_clients_tlv(ctx, almac, len, value, &clients_table);
			if (ret < 0) {
				err(DEBUG_CAT_MSG, "err AP_ASSOCIATED_CLIENTS tlv\n");
				goto fail;
			}
			integrity |= (1 << 6);
			store_revd_tlvs(ctx, type, (unsigned short)tlv_len);
		}
#endif /* #ifdef MAP_R2 */
		else if (*type == MULTI_AP_VERSION_TYPE) {
#ifdef EM_PLUS_EXT_SUPPORT
			if (!ctx->security_enabled && ctx->map_version == MAP_PROFILE_R2)
				map_profile = MAP_PROFILE_R3;
			else
#endif
				parse_map_version_tlv(type, &map_profile);

			integrity |= (1 << 7);
			store_revd_tlvs(ctx, type, (unsigned short)tlv_len);
			tpgr_db->profile = map_profile;
			*profile = map_profile;
		}
#ifdef BR_IP_TLV_SUPPORT
		else if (*type == VENDOR_SPECIFIC_TLV_TYPE) {
			ret = parse_vendor_tlv(type);
			if (ret < 0) {
				err(DEBUG_CAT_MSG, "err VENDOR_SPECIFIC tlv\n");
				return -1;
			}
			integrity |= (1 << 8);
			store_revd_tlvs(ctx, type, (unsigned short)tlv_len);
		}
#endif /* BR_IP_TLV_SUPPORT */
		else if (*type == AGENT_AP_MLD_CONFIG_TLV_TYPE) {
			integrity |= (1 << 9);
			store_revd_tlvs(ctx, type, (unsigned short)tlv_len);
		}
#ifdef MAP_R6
		else if (*type == BSTA_MLD_CONFIG_TLV_TYPE) {
			integrity |= (1 << 10);
			store_revd_tlvs(ctx, type, (unsigned short)tlv_len);
		} else if (*type == ASSOCIATED_STA_MLD_CONFIG_REPORT_TLV_TYPE) {
			integrity |= (1 << 11);
			store_revd_tlvs(ctx, type, (unsigned short)tlv_len);
		}
#endif
		else if (*type == TID_2_LINK_MAPPING_POLICY_TLV_TYPE) {
			integrity |= (1 << 12);
			store_revd_tlvs(ctx, type, (unsigned short)tlv_len);
		}
		else if (*type == END_OF_TLV_TYPE)
			break;
		else {
			store_revd_tlvs(ctx, type, (unsigned short)tlv_len);
		}

		type += tlv_len;
		left -= tlv_len;
	}

	update_dev_info(&tpgr_db->devinfo_head, &devinfo_list);
	update_bridge_cap(&tpgr_db->brcap_head, &brcap_list);
#ifdef MAP_R2
	if (!dl_list_empty(&bss_head)) {
		dl_list_for_each_safe(bss, bss_tmp, &bss_head, struct operational_bss, entry) {
			dl_list_del(&bss->entry);
			dl_list_add(&ctx->bss_head, &bss->entry);
		}
	}

	if (!dl_list_empty(&clients_table)) {
		unsigned char hash = 0;

		dl_list_for_each_safe(client, client_tmp, &clients_table, struct assoc_client, entry) {
			dl_list_del(&client->entry);
			assoc_client = get_assoc_cli_by_mac(ctx, client->mac);
			if (assoc_client) {
				os_memcpy(assoc_client->bssid, client->bssid, ETH_ALEN);
				free(client);
				client = NULL;
			} else {
				hash = MAC_ADDR_HASH_INDEX(client->mac);
				dl_list_add(&ctx->clients_table[hash], &client->entry);
			}
		}
	}
#endif
	/*sw solution for BCM */
	if (check_C_and_A_concurrent_by_topology_rsp(ctx, tpgr_db) < 0)
		goto fail;

	if (ctx->itf[ctx->recent_cmdu_rx_if_number].media_type <= IEEE802_3_AB_GROUP) {
		tpgr_db->eth_port = eth_layer_get_client_port_by_mac(al_mac_addr);
		if (tpgr_db->eth_port == ETH_ERROR_FAIL)
			err(DEBUG_CAT_TOPO, "fail to find eth_port for eth neighbor"MACSTR"\n",
				MAC2STR(al_mac_addr));
	} else
		tpgr_db->eth_port = -1;

	/*shall not enable PON with MAP feature in Certification case */
	if (!ctx->MAP_Cer)
		mask_control_conn_port(ctx, tpgr_db);
#ifdef MAP_R2
	update_operation_bss_vlan(ctx, &ctx->bss_head, &ctx->map_policy.tpolicy, al_mac_addr);
	maintain_all_assoc_clients(ctx);
#endif

	return 0;

fail:

	(void *)delete_exist_topology_response_content(ctx, al_mac_addr);
	if (!SLIST_EMPTY(&devinfo_list)) {
		dev = SLIST_FIRST(&devinfo_list);
		while (dev) {
			dev_tmp = SLIST_NEXT(dev, devinfo_entry);
			SLIST_REMOVE(&devinfo_list, dev, device_info_db, devinfo_entry);
			free(dev);
			dev = dev_tmp;
		}
	}

	if (!LIST_EMPTY(&brcap_list)) {
		br = LIST_FIRST(&brcap_list);
		while (br) {
			br_tmp = LIST_NEXT(br, brcap_entry);
			LIST_REMOVE(br, brcap_entry);
			free(br);
			br = br_tmp;
		}
	}
#ifdef MAP_R2
	if (!dl_list_empty(&bss_head)) {
		dl_list_for_each_safe(bss, bss_tmp, &bss_head, struct operational_bss, entry) {
			dl_list_del(&bss->entry);
			free(bss);
		}
	}

	if (!dl_list_empty(&clients_table)) {
		dl_list_for_each_safe(client, client_tmp, &clients_table, struct assoc_client, entry) {
			dl_list_del(&client->entry);
			free(client);
		}
	}
#endif
	return -1;
}


unsigned char is_internal_used_vendor_specific(unsigned char *vs_info)
{
	unsigned char charator_value[4] = { 0xFF, 0x00, 0x0C, 0xE7 };
	/*0xff, 0x00, 0x0C, 0xE7 */

	if (!os_memcmp(vs_info, charator_value, sizeof(charator_value)))
		return 1;
	else
		return 0;
}

/**
 *  parse vendor specific message. It for PC tool use.
 *
 *
 * \param  ctx  1905.1 managerd context
 * \param  vs_info  input
 * \return error code
 */
int parse_vendor_specific_message(struct p1905_managerd_ctx *ctx, unsigned char *buf, unsigned int left_tlv_len,
				  struct p1905_vs_info *vs_info, unsigned char *internal_vendor_message)
{
	unsigned char *type = NULL;
	unsigned short len = 0;
	unsigned int tlv_len = 0;
	unsigned int integrity = 0;
	unsigned int right_integrity = 0x1;
#ifdef EM_PLUS_SUPPORT
	int ret = 0;
#endif /*EM_PLUS_SUPPORT*/

	type = buf;
	reset_stored_tlv(ctx);
	*internal_vendor_message = 0;
	while (1) {
		if (left_tlv_len < 3)
			return -1;
		len = get_tlv_len(type);
		tlv_len = len + 3;
		if (left_tlv_len < tlv_len)
			return -1;

		if (*type == VENDOR_SPECIFIC_TLV_TYPE) {
			integrity |= (1 << 0);
			if (tlv_len >= 8 && is_internal_used_vendor_specific(type + 6))
				*internal_vendor_message = 1;
#ifdef EM_PLUS_SUPPORT
			ret = parse_emplus_vs_tlv(ctx, len, type + 3);
			if (ret < 0)
				err(DEBUG_CAT_EMPLUS, "parse emplus tlv error\n");
#endif /*EM_PLUS_SUPPORT*/

		} else if (*type == END_OF_TLV_TYPE) {
			break;
		}

		store_revd_tlvs(ctx, type, (unsigned short)tlv_len);

		type += tlv_len;
		left_tlv_len -= tlv_len;
	}

	/*check integrity */
	if (integrity != right_integrity) {
		err(DEBUG_CAT_MSG, "lack of mandatory tlv; integrity=%d\n", integrity);
		return -1;
	}

	return 0;
}

char *get_internal_vendor_msg_subtype_str(unsigned char type)
{
	switch (type) {
	case internal_vendor_discovery_message_subtype:
		return "internal_vendor_discovery_message_subtype";
	case internal_vendor_notification_message_subtype:
		return "internal_vendor_notification_message_subtype";
	case transparent_vlan_message_subtype:
		return "transparent_vlan_message_subtype";
	case internal_vendor_wts_content_message_subtype:
		return "internal_vendor_wts_content_message_subtype";
	case service_prioritization_vendor_rule_message_subtype:
		return "service_prioritization_vendor_rule_message_subtype";
	case internal_vendor_bss_prio_message_subtype:
		return "internal_vendor_bss_prio_message_subtype";
	case internal_vendor_bss_prio_ack_message_subtype:
		return "internal_vendor_bss_prio_ack_message_subtype";
	default:
		return "unknown_internal_vendor_msg_subtype";
	}
}

/**
 *  parse 1905 internal using vendor specific message. It for PC tool use.
 *
 *
 * \param  ctx  1905.1 managerd context
 * \param  vs_info  input
 * \return error code
 */
int parse_1905_internal_vendor_specific_message(struct p1905_managerd_ctx *ctx, unsigned char *buf,
		unsigned int left_tlv_len, unsigned char *almac)
{
	unsigned char *temp_buf;
	unsigned char need_query = 0, need_notify = 0, discvoery = 0;
	unsigned char peer_al_mac[ETH_ALEN] = { 0x00 };
	unsigned char peer_itf_mac[ETH_ALEN] = { 0x00 };
	unsigned char *p = NULL;
	int len = 0, total_len = 0;
	unsigned int left = left_tlv_len;

	/*1905 internal using vendor specific tlv format
	   type                 1 byte                  0x11
	   length                       2 bytes                 0x, 0x
	   oui                  3 bytes                 0x00, 0x0C, 0xE7
	   function type        1 byte                  0xff
	   suboui                       3 bytes                 0x00, 0x0C, 0xE7
	   sub func type        1 byte                  0x
	 */
	temp_buf = buf + 10;
	if (left < 10) {
		err(DEBUG_CAT_MSG, "len pre check fail\n");
		goto error;
	}

	switch (*temp_buf) {
	case internal_vendor_discovery_message_subtype:
		if (parse_topology_discovery_message(ctx, buf, left_tlv_len,
								&need_query, &need_notify, &discvoery, peer_al_mac,
								peer_itf_mac, NULL) < 0) {
			err(DEBUG_CAT_MSG, "err internal_vendor_discovery_message\n");
			goto error;
		}

		ctx->mid++;
		notice(DEBUG_CAT_MSG, "recv vendor discovery; reply topo discovery on %s; "
			"mid=0x%04x\n", ctx->itf[ctx->recent_cmdu_rx_if_number].if_name, ctx->mid);
		insert_cmdu_txq((unsigned char *)p1905_multicast_address,
				ctx->p1905_al_mac_addr, e_topology_discovery, ctx->mid,
				ctx->itf[ctx->recent_cmdu_rx_if_number].if_name, 0);
		topology_discovery_action(ctx, peer_al_mac, need_query, need_notify);
		update_topology_tree(ctx);
		break;
	case internal_vendor_wts_content_message_subtype:
		p = buf;
		while (*p == VENDOR_SPECIFIC_TLV_TYPE) {
			if (left < 3)
				goto error;
			len = get_cmdu_tlv_length(p);
			if (left < len)
				goto error;
			left -= len;

			p += len;
			total_len += len;
		}

		p = buf;
		while (*p == VENDOR_SPECIFIC_TLV_TYPE) {
			if (left < 3) {
				err(DEBUG_CAT_MSG, "len pre check fail\n");
				goto error;
			}
			len = get_cmdu_tlv_length(p);
			if (left < len) {
				err(DEBUG_CAT_MSG, "len pre  check fail\n");
				goto error;
			}
			left -= len;
			if (total_len < 11 || len < 11) {
				err(DEBUG_CAT_MSG, "len pre check fail\n");
				goto error;
			}
			os_memmove(p, p + 11, total_len - 11);
			p += (len - 11);
			total_len -= len;
			if (!total_len)
				break;
		}
		*p = 0;

		if (_1905_write_wts_file_content((char *)buf, ctx->wts_bss_cfg_file))
			err(DEBUG_CAT_AUTOCONF, "write wts file fail\n");
		break;
#ifdef MAP_R3_SP
	case service_prioritization_vendor_rule_message_subtype:
		{
			unsigned int integrity = 0;
			struct dl_list static_list_tmp;
			struct dl_list dynamic_list_tmp;
			struct dl_list learn_complete_list_tmp;

			dl_list_init(&static_list_tmp);
			dl_list_init(&dynamic_list_tmp);
			dl_list_init(&learn_complete_list_tmp);

			if (ctx->role != CONTROLLER)
				break;

			if (left < 3) {
				warn(DEBUG_CAT_SP, "received buf len should greater than 3 bytes(1[type]+2[len])\n");
				return -1;
			}
			len = get_tlv_len(buf);
			if (parse_sp_vendor_tlv(buf+3, len,
				ctx->p1905_al_mac_addr, &integrity, &static_list_tmp,
				&dynamic_list_tmp, &learn_complete_list_tmp) < 0) {
				clear_rule_list(&static_list_tmp);
				clear_rule_list(&dynamic_list_tmp);
				clear_rule_list(&learn_complete_list_tmp);
				warn(DEBUG_CAT_SP, "error sp vendor rule tlv\n");
				return -1;
			}

			if (integrity & BIT(0)) {
				sync_rule_between_list(&ctx->sp_rule_static_list, &static_list_tmp);
				sync_rule_between_list(&ctx->sp_rule_dynamic_list, &dynamic_list_tmp);
			}
			if (integrity & BIT(2)) {
				clear_rule_list(&ctx->sp_rule_static_list);
				clear_rule_list(&ctx->sp_rule_dynamic_list);
			}
			if (integrity & BIT(3))
				sync_rule_between_list(&ctx->sp_rule_learn_complete_list, &learn_complete_list_tmp);
		}
		break;
#endif
	case internal_vendor_bss_prio_message_subtype:
	{
		int ret = 0;
		int ifid = 0;

		/*step1 update local bss priority*/
		if (ctx->role == CONTROLLER) {
			err(DEBUG_CAT_AUTOCONF,
				"ignore internal_vendor_bss_prio_message as current role is controller\n");
			break;
		}

		if (os_memcmp(almac, ctx->cinfo.almac, ETH_ALEN)) {
			err(DEBUG_CAT_AUTOCONF, "sender is not the Controller;"
				"almac="MACSTR"; c_almac="MACSTR"\n",
				MAC2STR(almac), MAC2STR(ctx->cinfo.almac));
			break;
		}
		left -= 10;
		len = left - 1 - 2;

		if (left < 3) {
			err(DEBUG_CAT_MSG, "len pre check fail\n");
			goto error;
		}
		/*len include 3 byte end tlv*/
		if (get_tlv_len(temp_buf) != (len - 3)) {
			err(DEBUG_CAT_MSG, "len pre check fail\n");
			goto error;
		}
		p = temp_buf + 1 + 2;
		ret = update_bss_prio_str(ctx, p, len - 3);
		if (ret) {
			err(DEBUG_CAT_AUTOCONF, "update_bss_prio_str fail\n");
			break;
		}
		ret = set_bss_config_priority_by_str(ctx);
		if (ret) {
			err(DEBUG_CAT_AUTOCONF, "set_bss_config_priority_by_str fail\n");
			break;
		}
		update_radio_bss_priority(ctx);
		write_bss_prio_to_1905_cfg_file(ctx->map_cfg_file, ctx->bss_priority_str);
		/*step2 send ack vendor msg for bss prioity to Controller*/
		ifid = get_ifid_by_almac(ctx, almac);
		if (ifid == -1) {
			warn(DEBUG_CAT_AUTOCONF, "agent "MACSTR" not exist in topo rsp db; ignore\n",
				MAC2STR(almac));
			break;
		}
		ctx->mid++;
		notice(DEBUG_CAT_AUTOCONF, "send e_vendor_specific_bss_prio_ack to "MACSTR"; "
				"mid=0x%04x, ifname=%s", MAC2STR(almac),
				ctx->mid, ctx->itf[ifid].if_name);
		insert_cmdu_txq(almac, ctx->p1905_al_mac_addr,
				e_vendor_specific_bss_prio_ack, ctx->mid,
				ctx->itf[ifid].if_name, 0);
	}
		break;
	case internal_vendor_bss_prio_ack_message_subtype:
		if (ctx->role != CONTROLLER) {
			err(DEBUG_CAT_AUTOCONF,
				"ignore internal_vendor_bss_prio_ack_message as current role is agent\n");
			break;
		}

		set_bss_prio_for_agent(ctx, almac);
		if (!check_all_agent_sync_bss_prio(ctx)) {
			eloop_cancel_timeout(sync_bss_prio_to_agent, (void *)ctx, NULL);
			eloop_cancel_timeout(sync_bss_prio_done, (void *)ctx, NULL);
			notice(DEBUG_CAT_AUTOCONF, "all agents sync bss priority done\n");
		}
		break;
	default:
		err(DEBUG_CAT_MSG, "recv un-supported internal vendor message; subtype=0x%02x\n", *temp_buf);
		goto error;
	}

	return 0;
error:
	err(DEBUG_CAT_MSG, "err 1905 internal vendor specific tlv; subtype=0x%02x(%s)\n",
		*temp_buf, get_internal_vendor_msg_subtype_str(*temp_buf));
	err_hexdump(DEBUG_CAT_MSG, "tlv dump", buf, left_tlv_len);
	return -1;
}

/**
 *  parse link metric query message.
 *
 *
 * \param  ctx  1905.1 managerd context
 * \param  buf  input, tlvs start position of receive cmdu packet
 * \return error code
 */
int parse_link_metric_query_message(struct p1905_managerd_ctx *ctx, unsigned char *buf, unsigned int left_tlv_len)
{
	unsigned char *type = NULL;
	unsigned short len = 0;
	unsigned int tlv_len = 0;
	unsigned int integrity = 0;
	unsigned int right_integrity = 0x1;

	type = buf;

	reset_stored_tlv(ctx);

	while (1) {
		if (left_tlv_len < 3)
			return -1;
		len = get_tlv_len(type);
		tlv_len = len + 3;
		if (left_tlv_len < tlv_len)
			return -1;

		if (*type == LINK_METRICS_QUERY_TLV_TYPE) {
			integrity |= (1 << 0);
			store_revd_tlvs(ctx, type, (unsigned short)tlv_len);
		} else if (*type == END_OF_TLV_TYPE) {
			break;
		}

		type += tlv_len;
		left_tlv_len -= tlv_len;
	}

	/*check integrity */
	if (integrity != right_integrity) {
		err(DEBUG_CAT_MSG, "lack of mandatory tlv; integrity=%d\n", integrity);
		return -1;
	}

	return 0;
}

/**
 *  parse auto configuration search message.
 *
 *
 * \param  ctx  1905.1 managerd context
 * \param  buf  input, tlvs start position of receive cmdu packet
 * \param  al_mac output, gotten from the al mac type tlv
 * \return error code
 */
int parse_ap_autoconfig_search_message(struct p1905_managerd_ctx *ctx,
				       unsigned char *buf, unsigned int left_tlv_len, unsigned char *al_mac,
				       unsigned char *profile)
{
	unsigned char *type = NULL;
	unsigned short len = 0;
	unsigned char *value = NULL;
	unsigned int tlv_len = 0;
	int ret = 0;
	unsigned char peer_search_band = 0;
	unsigned int integrity = 0;
	unsigned int right_integrity = 0x7;

#ifdef MAP_R3
	struct r3_member *peer = NULL;
	struct chirp_tlv_info chirp = {0};
#endif

	reset_stored_tlv(ctx);
	type = buf;

	while (1) {
		if (left_tlv_len < 3)
			return -1;
		len = get_tlv_len(type);
		value = type + 3;
		tlv_len = len + 3;
		if (left_tlv_len < tlv_len)
			return -1;

		if (*type == AL_MAC_ADDR_TLV_TYPE) {
			ret = parse_al_mac_addr_type_tlv(al_mac, len, value);
			if (ret < 0) {
				err(DEBUG_CAT_MSG, "err AL_MAC_ADDR tlv\n");
				return -1;
			}
			if (!memcmp(ctx->p1905_al_mac_addr, al_mac, ETH_ALEN)) {
				err(DEBUG_CAT_MSG, "receive ap_autoconfig_search_message sent by myself\n");
				return -1;
			}
			integrity |= (1 << 0);
		} else if (*type == SEARCH_ROLE_TLV_TYPE) {
			ret = parse_search_role_tlv(len, value);
			if (ret < 0) {
				err(DEBUG_CAT_MSG, "err SEARCH_ROLE tlv\n");
				return -1;
			}
			integrity |= (1 << 1);
		} else if (*type == AUTO_CONFIG_FREQ_BAND_TLV_TYPE) {
			ret = parse_auto_config_freq_band_tlv(&peer_search_band, len, value);
			if (ret < 0) {
				err(DEBUG_CAT_MSG, "err AUTO_CONFIG_FREQ_BAND tlv\n");
				return -1;
			}
			integrity |= (1 << 2);
		}
#ifdef MAP_R2
		else if (*type == MULTI_AP_VERSION_TYPE) {
#ifdef EM_PLUS_EXT_SUPPORT
			if (!ctx->security_enabled && ctx->map_version == MAP_PROFILE_R2)
				*profile = MAP_PROFILE_R3;
			else
#endif
				parse_map_version_tlv(type, profile);

			integrity |= (1 << 3);
		}
#endif
#ifdef MAP_R3
		else if (*type == DPP_CHIRP_VALUE_TYPE) {
			os_memset(&chirp, 0, sizeof(struct chirp_tlv_info));
			ret = parse_dpp_chirp_value_tlv(value, len, &chirp);
			if (ret < 0) {
				err(DEBUG_CAT_DPP, "error freq tlv\n");
				return -1;
			}
			integrity |= (1 << 4);
			store_revd_tlvs(ctx, type, (unsigned short)tlv_len);
		}
#endif
		else if (*type == END_OF_TLV_TYPE)
			break;

		type += tlv_len;
		left_tlv_len -= tlv_len;
	}

	/*check integrity */
	if (integrity < right_integrity) {
		err(DEBUG_CAT_MSG, "lack of mandatory tlv; integrity=%d\n", integrity);
		return -1;
	}

	if (integrity & BIT(2))
		ctx->peer_search_band = peer_search_band;

#ifdef MAP_R3
	peer = create_r3_member(al_mac);
	if (!peer) {
		warn(DEBUG_CAT_DPP, "create_r3_member: " MACSTR " fail!\n", MAC2STR(al_mac));
		return -1;
	}

	if (integrity & BIT(3)) {
		peer->profile = *profile;

		if (peer->security_1905 && (peer->profile < MAP_PROFILE_R3)) {
			notice(DEBUG_CAT_DPP, "disable security_1905 for " MACSTR "\n", MAC2STR(al_mac));
			peer->security_1905 = 0;
		}
	}

	if (integrity & BIT(4)) {
		if (ctx->role == CONTROLLER) {
			os_memcpy(&peer->chirp, &chirp, sizeof(struct chirp_tlv_info));
			notice(DEBUG_CAT_DPP, "store chirp for "MACSTR", will be used in dpp auth to check if chirp match\n",
				MAC2STR(al_mac));
			add_chirp_hash_list(ctx, &chirp, al_mac);
		}
	}
#endif

	return 0;
}

/**
 *  parse auto configuration response message.
 *
 *
 * \param  ctx  1905.1 managerd context
 * \param  buf  input, tlvs start position of receive cmdu packet
 * \return error code
 */

int parse_ap_autoconfig_response_message(struct p1905_managerd_ctx *ctx,
					unsigned char *buf, unsigned int left_tlv_len,
					unsigned char *band, unsigned char *service,
					unsigned char *service_cnt,
					unsigned char *role_register, unsigned char *al_mac, unsigned char *profile,
					struct controller_capability *contr_cap)
{
	unsigned char *type = NULL;
	unsigned short len = 0;
	unsigned char *value = NULL;
	unsigned int tlv_len = 0;
	int ret = 0;
	unsigned int integrity = 0;
	unsigned int right_integrity = 0x7;
	unsigned char freq_band = 0xff;

#ifdef MAP_R3
	struct chirp_tlv_info chirp = { 0 };
#endif
	type = buf;
	reset_stored_tlv(ctx);
	while (1) {
		if (left_tlv_len < 3)
			return -1;
		len = get_tlv_len(type);
		value = type + 3;
		tlv_len = len + 3;
		if (left_tlv_len < tlv_len)
			return -1;

		if (*type == SUPPORT_ROLE_TLV_TYPE) {
			integrity |= (1 << 0);
			ret = parse_supported_role_tlv(len, value);
			if (ret < 0) {
				err(DEBUG_CAT_MSG, "err SUPPORT_ROLE tlv\n");
				return -1;
			}
			store_revd_tlvs(ctx, type, tlv_len);
		} else if (*type == SUPPORT_FREQ_BAND_TLV_TYPE) {
			integrity |= (1 << 1);
			ret = parse_supported_freq_band_tlv(&freq_band, len, value);
			if (ret < 0) {
				err(DEBUG_CAT_MSG, "err SUPPORT_FREQ_BAND tlv\n");
				return -1;
			}
			store_revd_tlvs(ctx, type, tlv_len);
		} else if (*type == SUPPORTED_SERVICE_TLV_TYPE) {
			integrity |= (1 << 2);
			ret = parse_supported_service_tlv(service, len, value, service_cnt);
			if (ret < 0) {
				err(DEBUG_CAT_MSG, "err SUPPORTED_SERVICE tlv\n");
				return -1;
			}
			store_revd_tlvs(ctx, type, tlv_len);
		}

		else if (*type == MULTI_AP_VERSION_TYPE) {
			integrity |= (1 << 3);
#ifdef EM_PLUS_EXT_SUPPORT
			if (!ctx->security_enabled && ctx->map_version == MAP_PROFILE_R2)
				*profile = MAP_PROFILE_R3;
			else
#endif
				parse_map_version_tlv(type, profile);
		}
#ifdef MAP_R3
		else if (*type == _1905_LAYER_SECURITY_CAPABILITY_TYPE) {
			unsigned char onboardingProto = 0, msgIntAlg = 0, msgEncAlg = 0;
			integrity |= (1 << 4);
			ret = parse_1905_layer_security_capability_tlv(ctx, type, &onboardingProto,
								     &msgIntAlg, &msgEncAlg);
			if (ret < 0) {
				warn(DEBUG_CAT_DPP, "error 1905layer security cap tlv\n");
				return -1;
			}
		} else if (*type == DPP_CHIRP_VALUE_TYPE) {
			integrity |= (1 << 5);

			ret = parse_dpp_chirp_value_tlv(value, len, &chirp);
			if (ret < 0) {
				warn(DEBUG_CAT_DPP, "error freq tlv\n");
				return -1;
			}
		} else if (*type == CONTROLLER_CAPABILITY_TYPE) {
			integrity |= (1 << 6);

			ret = parse_controller_cap_tlv(type, contr_cap);
			if (ret < 0) {
				warn(DEBUG_CAT_DPP, "error support service tlv\n");
				return -1;
			}
			store_revd_tlvs(ctx, type, tlv_len);
		}
#endif /* MAP_R3 */
		else if (*type == END_OF_TLV_TYPE) {
			break;
		} else {
			store_revd_tlvs(ctx, type, (unsigned short)tlv_len);
		}

		type += tlv_len;
		left_tlv_len -= tlv_len;
	}

	/*check integrity */
	if (integrity < right_integrity) {
		err(DEBUG_CAT_MSG, "lack of mandatory tlv; integrity=%d\n", integrity);
		return -1;
	}

	if (integrity&BIT(0))
		*role_register = 1;
	if (integrity&BIT(1))
		*band = freq_band;
	return 0;
}

int parse_ap_autoconfig_renew_message(struct p1905_managerd_ctx *ctx,
				      unsigned char *buf, unsigned int left_tlv_len,
				      unsigned char *al_mac, unsigned char *band)
{
	unsigned char *type = NULL;
	unsigned short len = 0;
	unsigned char *value = NULL;
	unsigned int tlv_len = 0;
	int ret = 0;
	unsigned int integrity = 0;
	unsigned int right_integrity = 0x7;
	unsigned char freq_band = 0xff;
	unsigned char peer_al_mac[ETH_ALEN] = { 0 };
	unsigned char zero_mac[ETH_ALEN] = { 0 };

	type = buf;

	while (1) {
		if (left_tlv_len < 3)
			return -1;

		len = get_tlv_len(type);
		value = type + 3;
		tlv_len = len + 3;
		if (left_tlv_len < tlv_len)
			return -1;

		if (*type == AL_MAC_ADDR_TLV_TYPE) {
			integrity |= (1 << 0);

			ret = parse_al_mac_addr_type_tlv(peer_al_mac, len, value);

			if (ret < 0) {
				warn(DEBUG_CAT_MSG, "error al mac tlv\n");
				return -1;
			}
			if (!os_memcmp(ctx->p1905_al_mac_addr, peer_al_mac, ETH_ALEN))
				return -1;
		} else if (*type == SUPPORT_ROLE_TLV_TYPE) {
			integrity |= (1 << 1);

			ret = parse_supported_role_tlv(len, value);
			if (ret < 0) {
				warn(DEBUG_CAT_MSG, "error support role tlv\n");
				return -1;
			}
		} else if (*type == SUPPORT_FREQ_BAND_TLV_TYPE) {
			integrity |= (1 << 2);

			ret = parse_supported_freq_band_tlv(&freq_band, len, value);
			if (ret < 0) {
				warn(DEBUG_CAT_MSG, "error support freq tlv\n");
				return -1;
			}
		} else if (*type == END_OF_TLV_TYPE) {
			break;
		}

		type += tlv_len;
		left_tlv_len -= tlv_len;
	}

	/*check integrity */
	if (integrity != right_integrity) {
		warn(DEBUG_CAT_MSG, "incomplete ap auto config renew 0x%x 0x%x\n", integrity, right_integrity);
		return -1;
	}

	if ((integrity&BIT(0)) && (os_memcmp(peer_al_mac, zero_mac, ETH_ALEN)))
		os_memcpy(al_mac, peer_al_mac, ETH_ALEN);

	if (integrity&BIT(2))
		*band = freq_band;

	return 0;
}

/**
 *  parse wsc M1/M2 message.
 *
 *
 * \param  ctx  1905.1 managerd context
 * \param  buf  input, tlvs start position of receive cmdu packet
 * \return error code
 */

int parse_ap_autoconfig_wsc_message(struct p1905_managerd_ctx *ctx,
				    unsigned char *almac, unsigned char *buf, unsigned int left_tlv_len,
				    OUT struct agent_radio_info *r, OUT unsigned char *radio_cnt,
				    OUT unsigned char *radio_identifier)
{
	unsigned char *type = NULL;
	unsigned short len = 0;
	unsigned char *value = NULL;
	unsigned int tlv_len = 0;
	int ret = 0;
	unsigned int integrity = 0;
	unsigned int rc_integrity = 0x1F;
	unsigned int rm_integrity = 0x1F;
	unsigned int right_integrity = 0;
	int m2_num = 0;
	struct agent_list_db *agent_info = NULL;
	unsigned char radio_if[ETH_ALEN] = {0};
	unsigned char zero_if[ETH_ALEN] = {0};
	int i = 0;
	struct agent_radio_info rinfo_tmp[MAX_RADIO_NUM];
	unsigned char ra_idx = 0, ra_cnt = 0;
	struct mld_bss_config_db mld_bss = {0};
#ifdef MAP_R6
	struct mld_bsta_config_db mld_bsta = {0};
#endif
	struct eht_operations_db eht_op[MAX_RADIO_NUM] = {0};
	struct eht_operations_info_db *eht_db = NULL, *eht_db_tmp = NULL;

#ifdef MAP_R2
	struct vs_value vs_info;
	struct def_8021q_setting setting;
	struct traffics_policy tpolicy;
	struct traffic_separation_db *tpolicy_db = NULL;
	struct traffic_separation_db *tpolicy_db_nxt = NULL;
	struct ap_r2_capability r2_cap;

	os_memset(&setting, 0, sizeof(struct def_8021q_setting));
	setting.primary_vid = VLAN_N_VID;
	os_memset(&tpolicy, 0, sizeof(struct traffics_policy));
	os_memset(&vs_info, 0, sizeof(struct vs_value));
	os_memset(&r2_cap, 0, sizeof(struct ap_r2_capability));
	SLIST_INIT(&tpolicy.policy_head);
	vs_info.parse_ts = 1;
#endif
	type = buf;

	dl_list_init(&mld_bss.mlo_cfg_list);
#ifdef MAP_R6
	dl_list_init(&mld_bsta.affiliated_sta_list);
	ctx->wsc_msg_type = 0;
#endif

	for (i = 0; i < MAX_RADIO_NUM; i++)
		dl_list_init(&eht_op[i].eht_op_list);

	right_integrity = (ctx->role == CONTROLLER) ? rm_integrity : rc_integrity;

	if (ctx->role == CONTROLLER) {
		find_agent_info(ctx, almac, &agent_info);
		if (!agent_info) {
			notice(DEBUG_CAT_AUTOCONF, "no agent "MACSTR" info exist, insert it\n",
				MAC2STR(almac));
			agent_info = insert_agent_info(ctx, almac);
			if (!agent_info) {
				err(DEBUG_CAT_AUTOCONF, "fail to insert agent "MACSTR"\n", MAC2STR(almac));
				return -1;
			}
		}
	}

	*radio_cnt = 0;

	while (1) {
		if (left_tlv_len < 3)
			goto fail;
		len = get_tlv_len(type);
		if (left_tlv_len < (len + 3))
			goto fail;
		value = type + 3;
		tlv_len = len + 3;

		if (*type == WSC_TLV_TYPE) {
			integrity |= (1 << 0);
			if (ctx->role == AGENT)
				memset(&ctx->ap_config_data, 0, sizeof(WSC_CONFIG));
			ret = parse_wsc_tlv(ctx, len, value);
			if (ret < 0) {
				err(DEBUG_CAT_MSG, "err WSC tlv\n");
				goto fail;
			}
			/*copy all setting from each M2 */
			if (ctx->role == AGENT) {
#ifdef MAP_R3
				if ((ctx->map_version == MAP_PROFILE_R3) &&
				    (ctx->ap_config_data.AuthMode & AUTH_DPP_ONLY)) {
					notice(DEBUG_CAT_DPP, "WSC onboarding, need clear AKM DPP");
					notice_np(DEBUG_CAT_DPP, ",Orig AKM 0x%04x",
					      ctx->ap_config_data.AuthMode);
					ctx->ap_config_data.AuthMode &= (~AUTH_DPP_ONLY);
					notice_np(DEBUG_CAT_DPP, ",new AKM 0x%04x\n",
					      ctx->ap_config_data.AuthMode);
				}
#endif
				memcpy(&(ctx->current_autoconfig_info.config_data[m2_num]),
					&ctx->ap_config_data, sizeof(WSC_CONFIG));
				m2_num++;
#ifdef MAP_R6
				/* last WSC tlv maybe M8 */
				if (ctx->wsc_msg_type == 0x0c)
					m2_num -= 1;
#endif
				ctx->current_autoconfig_info.config_number = m2_num;
			}
		} else if (*type == AP_RADIO_IDENTIFIER_TYPE) {
			integrity |= (1 << 1);
			ret = parse_ap_radio_identifier_tlv(ctx, radio_if
#ifdef MAP_R2
							    , 0
#endif
							    , len, value);
			if (ret < 0) {
				err(DEBUG_CAT_MSG, "err AP_RADIO_IDENTIFIER tlv\n");
				goto fail;
			}
		} else if (*type == AP_RADIO_BASIC_CAPABILITY_TYPE) {
			integrity |= (1 << 2);
			ra_cnt += 1;
			if (ra_cnt > MAX_RADIO_NUM) {
				err(DEBUG_CAT_MSG, "radio_cnt(%d) > MAX_RADIO_NUM(%d)"
					" in ap radio basic cap tlv\n", ra_cnt, MAX_RADIO_NUM);
				goto fail;
			}
			os_memset(&rinfo_tmp[ra_cnt - 1], 0, sizeof(struct agent_radio_info));
			ret = parse_ap_radio_basic_cap_tlv(ctx, &rinfo_tmp[ra_cnt - 1], len, value);
			if (ret < 0) {
				err(DEBUG_CAT_MSG, "err AP_RADIO_BASIC_CAPABILITY tlv\n");
				goto fail;
			}

		}
#ifdef MAP_R2
		else if (*type == DEFAULT_8021Q_SETTING_TYPE) {
			ret = parse_default_802_1q_setting_tlv(&setting, len, value);
			if (ret < 0) {
				err(DEBUG_CAT_MSG, "error DEFAULT_8021Q_SETTING tlv\n");
				goto fail;
			}
			integrity |= BIT(3);
			setting.updated = 1;
		} else if (*type == TRAFFIC_SEPARATION_POLICY_TYPE) {
			ret = parse_traffic_separation_policy_tlv(&tpolicy, len, value);
			if (ret < 0) {
				err(DEBUG_CAT_MSG, "error TRAFFIC_SEPARATION_POLICY tlv\n");
				goto fail;
			}
			integrity |= BIT(4);
			tpolicy.updated = 1;
		} else if (*type == R2_AP_CAPABILITY_TYPE) {
			os_memset(&r2_cap, 0, sizeof(struct ap_r2_capability));
			ret = parse_r2_ap_capability_tlv(&r2_cap, almac, len, value);
			if (ret < 0) {
				err(DEBUG_CAT_MSG, "error R2_AP_CAPABILITY tlv\n");
				goto fail;
			}

			integrity |= (1 << 5);
		} else if (*type == VENDOR_SPECIFIC_TLV_TYPE) {
#ifdef EM_PLUS_SUPPORT
			ret = parse_emplus_vs_tlv(ctx, len, value);
			if (!ret)
				info(DEBUG_CAT_MSG, "it isn`t emplus tlv, then check MTK vendor tlv\n");
#endif /* EM_PLUS_SUPPORT */
			ret = parse_vs_tlv(&vs_info, len, value);
			if (ret < 0) {
				err(DEBUG_CAT_MSG, "error VENDOR_SPECIFIC tlv\n");
				goto fail;
			}
		} else if (*type == AP_RADIO_ADVANCED_CAPABILITIES_TYPE) {
			struct ts_cap_db *ts_cap = NULL;

			integrity |= (1 << 6);
			ret = parse_ap_radio_advanced_capability_tlv(ctx, almac, &ts_cap, len, value);
			if (ret < 0) {
				err(DEBUG_CAT_MSG, "error AP_RADIO_ADVANCED_CAPABILITIES tlv\n");
				goto fail;
			}
			map_r2_notify_ts_cap(ctx, almac, ts_cap);
		}
#endif /* #ifdef MAP_R2 */
		else if (*type == AGENT_AP_MLD_CONFIG_TLV_TYPE) {
			integrity |= (1 << 7);
			ret = parse_agent_ap_mld_config_tlv(&mld_bss, almac, value, len);
			if (ret < 0) {
				debug(DEBUG_ERROR, "error mlo agent bss config tlv\n");
				goto fail;
			}
		}
#ifdef MAP_R6
		else if (*type == BSTA_MLD_CONFIG_TLV_TYPE) {
			ret = parse_bsta_mld_config_tlv(&mld_bsta, value, len);
			if (ret < 0) {
				warn(DEBUG_CAT_MLO, "error mlo bh sta config tlv\n");
				goto fail;
			}
			if (mld_bsta.num_affiliated_sta > 0)
				integrity |= (1 << 8);
		} else if (*type == WSC_M8_TLV_TYPE) {
			integrity |= (1 << 10);
			store_revd_tlvs(ctx, type, tlv_len);
		}
#endif
		else if (*type == EHT_OPERATION_TLV_TYPE) {
			integrity |= (1 << 9);
			ret = parse_eht_operations_tlv(eht_op, value, len);
			if (ret < 0) {
				err(DEBUG_CAT_MSG, "error EHT_OPERATION tlv\n");
				goto fail;
			}
		}
		 else if (*type == END_OF_TLV_TYPE) {
			break;
		}

		type += tlv_len;
		left_tlv_len -= tlv_len;
	}

	/*check integrity */
	if (!(integrity & right_integrity)) {
		err(DEBUG_CAT_MSG, "lack of mandatory tlv; integrity=%d\n", integrity);
		goto fail;
	}

	if ((integrity&BIT(1)) && (os_memcmp(radio_if, zero_if, ETH_ALEN)))
		os_memcpy(radio_identifier, radio_if, ETH_ALEN);

	if (integrity & BIT(2)) {
		*radio_cnt = ra_cnt;
		for (ra_idx = 0; ra_idx < ra_cnt && ra_cnt < MAX_RADIO_NUM; ra_idx++) {
			/* update agent's radio infor on controller */
			update_agent_radio_info(agent_info, &rinfo_tmp[ra_idx]);

			/* copy out, agent will use it */
			os_memcpy(&r[ra_idx], &rinfo_tmp[ra_idx], sizeof(struct agent_radio_info));
		}
	}

#ifdef MAP_R2
	if (vs_info.trans_vlan.updated == 1 && vs_info.parse_ts) {
		ctx->map_policy.trans_vlan.num = vs_info.trans_vlan.num;
		notice(DEBUG_CAT_TS, "transparent vlan cnt(%d); vid=\n", ctx->map_policy.trans_vlan.num);
		for (i = 0; i < vs_info.trans_vlan.num; i++) {
			ctx->map_policy.trans_vlan.transparent_vids[i] = vs_info.trans_vlan.transparent_vids[i];
			notice_np(DEBUG_CAT_TS, "%d ", ctx->map_policy.trans_vlan.transparent_vids[i]);
		}
		notice_np(DEBUG_CAT_TS, "\n");
		ctx->map_policy.trans_vlan.updated = 1;
	}
#endif


	if (ctx->role == AGENT) {
#ifdef MAP_R2
		unsigned char updated = 0;

		/*if no default 802.1q setting */
		if (!(integrity & BIT(3)) && !ctx->MAP_Cer) {
			if (ctx->map_policy.setting.primary_vid != VLAN_N_VID) {
				updated = 1;
				notice(DEBUG_CAT_TS, "pvid setting changed with no 802.1q tlv\n");
			}
			ctx->map_policy.setting.primary_vid = VLAN_N_VID;
			ctx->map_policy.setting.updated = updated;
		} else {
			if ((ctx->map_policy.setting.primary_vid != setting.primary_vid) ||
				(ctx->map_policy.setting.dft.PCP != setting.dft.PCP)) {
				updated = 1;
				notice(DEBUG_CAT_TS, "pvid setting changed by 802.1q tlv, pvid(%d->%d), pcp(%d->%d)\n",
					ctx->map_policy.setting.primary_vid, setting.primary_vid,
					ctx->map_policy.setting.dft.PCP, setting.dft.PCP);
			}

			os_memcpy(&ctx->map_policy.setting, &setting, sizeof(struct def_8021q_setting));
			ctx->map_policy.setting.updated = updated;
		}

		/*if no traffic separation policy tlv */
		if (!(integrity & BIT(4)) && !ctx->MAP_Cer) {
			updated = check_traffic_policy_config_updated(ctx, &ctx->map_policy.tpolicy, NULL);
			delete_exist_traffic_policy(ctx, &ctx->map_policy.tpolicy);
			ctx->map_policy.tpolicy.updated = updated;
			info(DEBUG_CAT_TS, "tpolicy setting changed with no tpolicy tlv\n");
		} else {
			updated = check_traffic_policy_config_updated(ctx, &ctx->map_policy.tpolicy, &tpolicy);
			/*delete the previously reserved traffic policy */
			delete_exist_traffic_policy(ctx, &ctx->map_policy.tpolicy);
			ctx->map_policy.tpolicy.SSID_num = tpolicy.SSID_num;
			ctx->map_policy.tpolicy.updated = updated;
			notice(DEBUG_CAT_TS, "tpolicy setting changed with tpolicy tlv\n");

			tpolicy_db = SLIST_FIRST(&(tpolicy.policy_head));
			while (tpolicy_db) {
				tpolicy_db_nxt = SLIST_NEXT(tpolicy_db, policy_entry);
				SLIST_REMOVE(&(tpolicy.policy_head), tpolicy_db,
							traffic_separation_db, policy_entry);

				SLIST_INSERT_HEAD(&ctx->map_policy.tpolicy.policy_head, tpolicy_db, policy_entry);
				tpolicy_db = tpolicy_db_nxt;
			}
		}
#endif


#ifdef MAP_R6
		if (integrity & BIT(8)) {
			delete_bsta_mld_conf(&ctx->mld_bsta);
			update_bsta_mld_conf(&ctx->mld_bsta, &mld_bsta);
			ctx->bsta_mld_cfg = 1;
		}
#endif

		if ((integrity & BIT(7)) && (mld_bss.num_ap_mld > 0)) {
			struct mlo_config_db *mlo_cfg = NULL, *mlo_cfg_tmp = NULL;
			WSC_CONFIG *wsc_cfg = NULL;
			unsigned char len = 0;
#ifdef MAP_R6
			struct wps_cred_reconf_info *reconf_data = NULL;
#endif
			dl_list_for_each_safe(mlo_cfg, mlo_cfg_tmp,
				&mld_bss.mlo_cfg_list, struct mlo_config_db, list) {

				/* set mlo_bss_present flag for wapp using
				 * indicate mld grp setting is present or not for this bss
				 */
				for (i = 0; i < m2_num; i++) {
					wsc_cfg = &ctx->current_autoconfig_info.config_data[i];
					if (mlo_cfg->ssid_len >= strlen((char *)wsc_cfg->Ssid))
						len = mlo_cfg->ssid_len;
					else
						len = strlen((char *)wsc_cfg->Ssid);
					if ((os_strncmp(mlo_cfg->ssid, (char *)wsc_cfg->Ssid, len) == 0)) {
						wsc_cfg->mlo_bss_present = 1;
						info(DEBUG_CAT_MLO, "bss %s mlo_bss_present 1\n", mlo_cfg->ssid);
					}
				}
			}
			info(DEBUG_CAT_MLO, "agent ap mld config present\n");
			delete_ap_mld_conf(&ctx->mld_bss);
			update_ap_mld_conf(&ctx->mld_bss, &mld_bss);
			delete_ap_mld_conf(&ctx->opcls_mld_cfg);
			ctx->ap_mld_cfg = 1;

#ifdef MAP_R6
			if (ctx->wsc_msg_type == 0x0c) {
				reconf_data = &ctx->cred_reconfig.data[0].info;
				/* m8 cfg */
				wsc_cfg = &ctx->current_autoconfig_info.config_data[m2_num];
				reconf_data->bsta_mld_present = ctx->bsta_mld_cfg;
				os_memcpy(reconf_data->ssid, wsc_cfg->Ssid, sizeof(wsc_cfg->Ssid));
				reconf_data->ssid[sizeof(reconf_data->ssid)-1] = '\0';
				os_memcpy(reconf_data->key, wsc_cfg->WPAKey, sizeof(wsc_cfg->WPAKey));
				reconf_data->key[sizeof(reconf_data->key)-1] = '\0';
				reconf_data->ssid_len = strlen((char *)reconf_data->ssid);
				reconf_data->key_len = strlen((char *)reconf_data->key);
				reconf_data->auth_mode = wsc_cfg->AuthMode;
				reconf_data->encr_type = wsc_cfg->EncrypType;
				ctx->cred_reconfig.wps_cred_reconfig_num++;
				notice(DEBUG_CAT_MLO, "m8 ssid %s, auth mode %04x, enc type %04x",
					reconf_data->ssid, reconf_data->auth_mode, reconf_data->encr_type);

			}
#endif
		}
		if (integrity & BIT(9)) {
			ctx->eht_op_cfg = 1;
			delete_eht_operations(ctx->eht_op);

			for (ra_idx = 0; ra_idx < MAX_RADIO_NUM; ra_idx++) {
				dl_list_for_each_safe(eht_db, eht_db_tmp, &eht_op[ra_idx].eht_op_list,
					struct eht_operations_info_db, list) {
					dl_list_del(&eht_db->list);
					os_memcpy(ctx->eht_op[ra_idx].ruid,
						eht_op[ra_idx].ruid, ETH_ALEN);
					dl_list_add_tail(&ctx->eht_op[ra_idx].eht_op_list, &eht_db->list);
				}
			}
		}
	} else {
#ifdef MAP_R2
		if (integrity & BIT(5))
			os_memcpy(&agent_info->r2_cap, &r2_cap, sizeof(struct ap_r2_capability));

		if (vs_info.mlo_cap_valid) {
			for (ra_idx = 0; ra_idx < MAX_RADIO_NUM; ra_idx++) {
				if (os_memcmp(agent_info->ra_info[ra_idx].identifier, vs_info.mlo_data.mlo_cap.identifier, ETH_ALEN))
					continue;

				agent_info->ap_mlo_cap[ra_idx] = vs_info.mlo_data.mlo_cap.ap_mlo_cap;
				agent_info->sta_mlo_cap[ra_idx] = vs_info.mlo_data.mlo_cap.sta_mlo_cap;
				debug(DEBUG_CAT_MLO, "almac "MACSTR" (PRE R6), ruid "MACSTR", ap mlo %d(%s), sta mlo %d(%s)\n",
					MAC2STR(almac), MAC2STR(vs_info.mlo_data.mlo_cap.identifier),
					agent_info->ap_mlo_cap[ra_idx],
					(agent_info->ap_mlo_cap[ra_idx] == 1)?"enable":"disable",
					agent_info->sta_mlo_cap[ra_idx],
					(agent_info->sta_mlo_cap[ra_idx] == 1)?"enable":"disable");
			}
		}
#endif
		if (integrity & BIT(7))
			delete_ap_mld_conf(&mld_bss);

#ifdef MAP_R6
		if (integrity & BIT(8))
			delete_bsta_mld_conf(&mld_bsta);
#endif

		if (integrity & BIT(9))
			delete_eht_operations(eht_op);

	}

	return 0;

fail:
#ifdef MAP_R2
	tpolicy_db = SLIST_FIRST(&(tpolicy.policy_head));
	while (tpolicy_db) {
		tpolicy_db_nxt = SLIST_NEXT(tpolicy_db, policy_entry);
		SLIST_REMOVE(&(tpolicy.policy_head), tpolicy_db,
			traffic_separation_db, policy_entry);
		os_free(tpolicy_db);
		tpolicy_db = tpolicy_db_nxt;
	}
#endif

	delete_ap_mld_conf(&mld_bss);
	delete_eht_operations(eht_op);
#ifdef MAP_R6
	delete_bsta_mld_conf(&mld_bsta);
#endif

	return -1;
}

int parse_link_metrics_response_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len)
{
	unsigned char *type = NULL;
	unsigned int tlv_len = 0;
	unsigned short len = 0;

	type = buf;
	reset_stored_tlv(ctx);

	while(1) {
		if (left_tlv_len < 3)
			return -1;
		len = get_tlv_len(type);
		tlv_len = len + 3;
		if (tlv_len > left_tlv_len)
			return -1;

		if (*type == TRANSMITTER_LINK_METRIC_TYPE)
			store_revd_tlvs(ctx, type, tlv_len);
		else if (*type == RECEIVER_LINK_METRIC_TYPE)
			store_revd_tlvs(ctx, type, tlv_len);
		else if (*type == END_OF_TLV_TYPE)
			break;

		type += tlv_len;
		left_tlv_len -= tlv_len;
	}

	return 0;
}


/*MAP spec defined*/
int parse_1905_ack_message(struct p1905_managerd_ctx *ctx, unsigned char *buf, unsigned int left_tlv_len){
	unsigned char *type = NULL;
	unsigned short len = 0;
	unsigned int tlv_len = 0;
	type = buf;

	reset_stored_tlv(ctx);
	while (1) {
		if (left_tlv_len < 3)
			return -1;
		len = get_tlv_len(type);
		tlv_len = len + 3;
		if (tlv_len > left_tlv_len)
			return -1;
		if (*type == ERROR_CODE_TYPE)
			store_revd_tlvs(ctx, type, (unsigned short)tlv_len);
		else if (*type == END_OF_TLV_TYPE)
			break;
		type += tlv_len;
		left_tlv_len -= tlv_len;
	}

	return 0;
}


int parse_client_capability_query_message(struct p1905_managerd_ctx *ctx, unsigned char *buf, unsigned int left_tlv_len)
{
	unsigned char *type = NULL;
	unsigned short len = 0;
	unsigned char *value = NULL;
	unsigned int tlv_len = 0;
	int ret = 0;
	unsigned int integrity = 0;
	unsigned int right_integrity = 0x1;
	struct client_info client_info = {0};

	type = buf;

	while (1) {
		if (left_tlv_len < 3)
			return -1;
		len = get_tlv_len(type);
		value = type + 3;
		tlv_len = len + 3;
		if (left_tlv_len < tlv_len)
			return -1;

		if (*type == CLIENT_INFO_TYPE) {
			integrity |= (1 << 0);
			ret = parse_client_info_tlv(ctx, client_info.bssid, client_info.sta_mac, len, value);
			if (ret < 0) {
				err(DEBUG_CAT_MSG, "err CLIENT_INFO tlv\n");
				return -1;
			}
		} else if (*type == END_OF_TLV_TYPE) {
			break;
		}

		type += tlv_len;
		left_tlv_len -= tlv_len;
	}

	/*check integrity */
	if (integrity != right_integrity) {
		err(DEBUG_CAT_MSG, "lack of mandatory tlv; integrity=%d\n", integrity);
		return -1;
	}

	if (integrity & BIT(0)) {
		os_memcpy(ctx->sinfo.cinfo.bssid, client_info.bssid, ETH_ALEN);
		os_memcpy(ctx->sinfo.cinfo.sta_mac, client_info.sta_mac, ETH_ALEN);
	}
	return 0;
}


int parse_channel_selection_request_message(struct p1905_managerd_ctx *ctx,
							unsigned char *buf, unsigned int left_tlv_len)
{
	unsigned char *type = NULL;
	unsigned short len = 0;
	unsigned char *value = NULL;
	unsigned int tlv_len = 0;
	int ret = 0;
	struct list_head_ch_prefer ch_prefer_head = {0};
	struct ch_prefer_db *prefer = NULL;
	struct ch_prefer_db *prefer_tmp = NULL;

	type = buf;
	reset_stored_tlv(ctx);
	SLIST_INIT(&ch_prefer_head);

	while (1) {
		if (left_tlv_len < 3)
			goto fail;
		len = get_tlv_len(type);
		value = type + 3;
		tlv_len = len + 3;
		if (left_tlv_len < tlv_len)
			goto fail;

		if (*type == CH_PREFERENCE_TYPE) {
			ret = parse_channel_preference_tlv(ctx, &ch_prefer_head, len, value);
			if (ret < 0) {
				delete_all_ch_prefer_info(&ctx->ap_cap_entry.ch_prefer_head);
				err(DEBUG_CAT_MSG, "error CH_PREFERENCE tlv\n");
				goto fail;
			}
			store_revd_tlvs(ctx, type, tlv_len);
		} else if (*type == TRANSMIT_POWER_LIMIT_TYPE) {
			store_revd_tlvs(ctx, type, tlv_len);
		} else if (*type == SPATIAL_REUSE_REQ_TYPE)
			store_revd_tlvs(ctx, type, tlv_len);
		else if (*type == EHT_OPERATION_TLV_TYPE)
			store_revd_tlvs(ctx, type, tlv_len);
#ifdef MAP_VENDOR_SUPPORT
		else if (*type == VENDOR_SPECIFIC_TLV_TYPE) {
			store_revd_tlvs(ctx, type, tlv_len);
		}
#endif

		else if (*type == END_OF_TLV_TYPE)
			break;

		type += tlv_len;
		left_tlv_len -= tlv_len;
	}

	update_ch_prefer_info(ctx, &ch_prefer_head);

	return 0;

fail:
	if (!SLIST_EMPTY(&ch_prefer_head)) {
		prefer = SLIST_FIRST(&ch_prefer_head);
		while (prefer) {
			prefer_tmp = SLIST_NEXT(prefer, ch_prefer_entry);
			SLIST_REMOVE(&ch_prefer_head, prefer, ch_prefer_db, ch_prefer_entry);
			free(prefer);
			prefer = prefer_tmp;
		}
	}
	return -1;
}

int parse_map_policy_config_request_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len)
{
	unsigned char *type = NULL;
	unsigned char *val = NULL;
	unsigned int tlv_len = 0;
	int ret = 0;
	unsigned short len = 0;
	unsigned char integrity = 0;
	unsigned int all_integrity = 0xFF;
	struct metrics_policy mpolicy = {0};
#ifdef MAP_R5
	struct qos_management_policy qos_policy_tmp = {0};
#endif
#ifdef MAP_R2
	struct vs_value vs_info;
	struct def_8021q_setting setting;
	struct traffics_policy tpolicy;
	struct traffic_separation_db *tpolicy_db = NULL;
	struct traffic_separation_db *tpolicy_db_nxt = NULL;
	int i = 0;

	os_memset(&setting, 0, sizeof(struct def_8021q_setting));
	os_memset(&tpolicy, 0, sizeof(struct traffics_policy));
	os_memset(&vs_info, 0, sizeof(struct vs_value));
	SLIST_INIT(&tpolicy.policy_head);
	vs_info.parse_ts = 1;
#endif

	type = buf;
	reset_stored_tlv(ctx);
	SLIST_INIT(&(mpolicy.policy_head));

	while(1) {
		if (left_tlv_len < 3)
			goto fail;
		len = get_tlv_len(type);
		tlv_len = len + 3;
		if (tlv_len > left_tlv_len)
			goto fail;
		val = type + 3;

		/* Zero or one Steering Policy TLV */
		if (*type == STEERING_POLICY_TYPE) {
			integrity |= (1 << 0);
			store_revd_tlvs(ctx, type, tlv_len);
		}
		/* Zero or one Metric Reporting Policy TLV */
		else if (*type == METRIC_REPORTING_POLICY_TYPE) {
			integrity |= (1 << 1);
			ret = parse_metric_reporting_policy_tlv(ctx, len, val, &mpolicy);
			if (ret < 0) {
				err(DEBUG_CAT_MSG, "error METRIC_REPORTING_POLICY tlv\n");
				goto fail;
			}
			store_revd_tlvs(ctx, type, tlv_len);

		}
#ifdef MAP_R2
		/* Zero or one Channel Scan Reporting Policy TLV */
		else if (*type == CHANNEL_SCAN_REPORTING_POLICY_TYPE) {
			integrity |= (1 << 2);
			store_revd_tlvs(ctx, type, tlv_len);
		}
		/* Zero or one Default 802.1Q Settings TLV */
		else if (*type == DEFAULT_8021Q_SETTING_TYPE) {
			ret = parse_default_802_1q_setting_tlv(&setting, len, val);
			if (ret < 0) {
				err(DEBUG_CAT_MSG, "err DEFAULT_8021Q_SETTING tlv\n");
				goto fail;
			}
			integrity |= (1 << 3);
			setting.updated = 1;
		}
		/* Zero or one Traffic Separation Policy TLV */
		else if (*type == TRAFFIC_SEPARATION_POLICY_TYPE) {
			ret = parse_traffic_separation_policy_tlv(&tpolicy, len, val);
			if (ret < 0) {
				err(DEBUG_CAT_MSG, "err TRAFFIC_SEPARATION_POLICY tlv\n");
				goto fail;
			}
			integrity |= (1 << 4);
			tpolicy.updated = 1;
		}
		/* bh bss assoc ctrl TLV */
		else if (*type == BACKHAUL_BSS_CONFIG_TYPE) {
			store_revd_tlvs(ctx, type, tlv_len);
		} else if (*type == VENDOR_SPECIFIC_TLV_TYPE) {
			ret = parse_vs_tlv(&vs_info, len, val);
			if (ret < 0) {
				err(DEBUG_CAT_MSG, "err VENDOR_SPECIFIC tlv\n");
				goto fail;
			}
		}
		/* Zero or one Unsuccessful Association Policy TLV */
		else if (*type == UNSUCCESSFUL_ASSOCIATION_POLICY_TYPE) {
			integrity |= (1 << 5);
			store_revd_tlvs(ctx, type, tlv_len);
		}
#endif
#ifdef MAP_R5
		/* Zero or one QoS Management Policy TLV */
		else if (*type == QOS_MANAGEMENT_POLICY_TYPE) {
			ret = parse_qos_management_policy_tlv(val, len, &qos_policy_tmp);
			if (ret < 0) {
				err(DEBUG_CAT_QOS, "parse qos management policy tlv failed.\n");
				goto fail;
			}
			integrity |= (1 << 6);
		}
#endif
		else if (*type == END_OF_TLV_TYPE)
			break;

		type += tlv_len;
		left_tlv_len -= tlv_len;
	}

	if ((integrity & all_integrity) == 0) {
		err(DEBUG_CAT_MSG, "lack of mandatory tlv; integrity=%d\n", integrity);
		goto fail;
	}

	if (integrity & BIT(1))
		update_metrics_policy(ctx, &mpolicy);

#ifdef MAP_R2
	if (vs_info.trans_vlan.updated == 1 && vs_info.parse_ts) {
		ctx->map_policy.trans_vlan.num = vs_info.trans_vlan.num;
		notice(DEBUG_CAT_TS, "update transparent vlan number=%d\n", ctx->map_policy.trans_vlan.num);
		for (i = 0; i < vs_info.trans_vlan.num; i++) {
			ctx->map_policy.trans_vlan.transparent_vids[i] = vs_info.trans_vlan.transparent_vids[i];

			notice(DEBUG_CAT_TS, "set transparent vlan id(%d)\n",
				ctx->map_policy.trans_vlan.transparent_vids[i]);
		}
		ctx->map_policy.trans_vlan.updated = 1;
	}
#endif

#ifdef MAP_R2
	if (ctx->role == AGENT) {
		if (ctx->MAP_Cer) {
			/*if no default 802.1q setting*/
			if (!(integrity & BIT(3))) {
				ctx->map_policy.setting.primary_vid = VLAN_N_VID;
				ctx->map_policy.setting.updated = 1;
			} else
				os_memcpy(&ctx->map_policy.setting, &setting, sizeof(struct def_8021q_setting));

			/*if no traffic separation policy tlv*/
			if (!(integrity & BIT(4))) {
				delete_exist_traffic_policy(ctx, &ctx->map_policy.tpolicy);
				ctx->map_policy.tpolicy.updated = 1;
			} else {
				/*delete the previously reserved traffic policy*/
				delete_exist_traffic_policy(ctx, &ctx->map_policy.tpolicy);
				ctx->map_policy.tpolicy.SSID_num = tpolicy.SSID_num;
				ctx->map_policy.tpolicy.updated = tpolicy.updated;

				tpolicy_db = SLIST_FIRST(&(tpolicy.policy_head));
				while (tpolicy_db) {
					tpolicy_db_nxt = SLIST_NEXT(tpolicy_db, policy_entry);
					SLIST_REMOVE(&(tpolicy.policy_head), tpolicy_db,
								traffic_separation_db, policy_entry);

					SLIST_INSERT_HEAD(&ctx->map_policy.tpolicy.policy_head, tpolicy_db, policy_entry);
					tpolicy_db = tpolicy_db_nxt;
				}
			}

			eloop_register_timeout(0, 0, map_r2_notify_ts_config, (void *)ctx, NULL);
		} else {
			unsigned char updated = 0;

			if (integrity & BIT(3)) {
				if ((ctx->map_policy.setting.primary_vid != setting.primary_vid) ||
					(ctx->map_policy.setting.dft.PCP != setting.dft.PCP)) {
					updated = 1;
					notice(DEBUG_CAT_TS, "pvid setting changed by 802.1q tlv, pvid(%d->%d), pcp(%d->%d)\n",
						ctx->map_policy.setting.primary_vid, setting.primary_vid,
						ctx->map_policy.setting.dft.PCP, setting.dft.PCP);
				}
				os_memcpy(&ctx->map_policy.setting, &setting, sizeof(struct def_8021q_setting));
				ctx->map_policy.setting.updated = updated;
			}

			if (integrity & BIT(4)) {
				updated = check_traffic_policy_config_updated(ctx, &ctx->map_policy.tpolicy, &tpolicy);
				/*delete the previously reserved traffic policy*/
				delete_exist_traffic_policy(ctx, &ctx->map_policy.tpolicy);

				ctx->map_policy.tpolicy.SSID_num = tpolicy.SSID_num;
				ctx->map_policy.tpolicy.updated = updated;


				tpolicy_db = SLIST_FIRST(&(tpolicy.policy_head));
				while (tpolicy_db) {
					tpolicy_db_nxt = SLIST_NEXT(tpolicy_db, policy_entry);
					SLIST_REMOVE(&(tpolicy.policy_head), tpolicy_db,
								traffic_separation_db, policy_entry);

					SLIST_INSERT_HEAD(&ctx->map_policy.tpolicy.policy_head, tpolicy_db, policy_entry);
					tpolicy_db = tpolicy_db_nxt;
				}
			}

			if ((integrity & BIT(3)) || (integrity & BIT(4)))
				eloop_register_timeout(0, 0, map_r2_notify_ts_config, (void *)ctx, NULL);
		}
	}
#endif
#ifdef MAP_R5
	if (integrity & BIT(6))
		os_memcpy(&ctx->map_policy.qos_mgmt_policy, &qos_policy_tmp, sizeof(qos_policy_tmp));
#endif

	return 0;

fail:
#ifdef MAP_R2
	tpolicy_db = SLIST_FIRST(&(tpolicy.policy_head));
	while (tpolicy_db) {
		tpolicy_db_nxt = SLIST_NEXT(tpolicy_db, policy_entry);
		SLIST_REMOVE(&(tpolicy.policy_head), tpolicy_db,
			traffic_separation_db, policy_entry);
		os_free(tpolicy_db);
		tpolicy_db = tpolicy_db_nxt;
	}
#endif
	return -1;

}

int parse_client_steering_request_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len, struct err_sta_db *err_sta)
{
	unsigned char *type = NULL;
	unsigned char *val = NULL;
	unsigned int tlv_len = 0;
	int ret = 0;
	unsigned short len = 0;
	unsigned char integrity = 0;
	unsigned int right_integrity = 0x1;
	struct err_sta_db err_sta_list = {0};
	struct err_sta_mac_db *err_mac = NULL;
	struct err_sta_mac_db *err_mac_tmp = NULL;

	type = buf;
	reset_stored_tlv(ctx);
	SLIST_INIT(&err_sta_list.err_sta_head);

	while (1) {
		if (left_tlv_len < 3)
			goto fail;
		len = get_tlv_len(type);
		tlv_len = len + 3;
		if (tlv_len > left_tlv_len)
			goto fail;
		val = type + 3;

		if ((*type == STEERING_REQUEST_TYPE)
#ifdef MAP_R2
		 || (*type == R2_STEERING_REQUEST_TYPE)
#endif
		 ) {
			integrity |= (1 << 0);

			ret = parse_steering_request_tlv(ctx, len, val, &err_sta_list);
			if (ret < 0) {
				err(DEBUG_CAT_MSG, "err STEERING_REQUEST/R2_STEERING_REQUEST tlv\n");
				goto fail;
			}
			store_revd_tlvs(ctx, type, tlv_len);
		} else if (*type == END_OF_TLV_TYPE) {
			break;
		}
		type += tlv_len;
		left_tlv_len -= tlv_len;
	}

	if (integrity != right_integrity) {
		err(DEBUG_CAT_MSG, "lack of mandatory tlv; integrity=%d\n", integrity);
		goto fail;
	}

	if (integrity&BIT(0) && !SLIST_EMPTY(&err_sta_list.err_sta_head)) {
		err_sta->err_sta_cnt = err_sta_list.err_sta_cnt;
		err_mac = SLIST_FIRST(&err_sta_list.err_sta_head);
		while (err_mac) {
			err_mac_tmp = SLIST_NEXT(err_mac, err_sta_mac_entry);
			SLIST_REMOVE(&err_sta_list.err_sta_head, err_mac, err_sta_mac_db, err_sta_mac_entry);
			SLIST_INSERT_HEAD(&err_sta->err_sta_head, err_mac, err_sta_mac_entry);
			err_mac = err_mac_tmp;
		}
	}

	return 0;

fail:
	if (integrity&BIT(0) && !SLIST_EMPTY(&err_sta_list.err_sta_head)) {
		err_mac = SLIST_FIRST(&err_sta_list.err_sta_head);
		while (err_mac) {
			err_mac_tmp = SLIST_NEXT(err_mac, err_sta_mac_entry);
			SLIST_REMOVE(&err_sta_list.err_sta_head, err_mac, err_sta_mac_db, err_sta_mac_entry);
			free(err_mac);
			err_mac = err_mac_tmp;
		}
	}
	return -1;
}

int parse_cli_assoc_control_request_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len)
{
	unsigned char *type = NULL;
	unsigned char *val = NULL;
	unsigned int tlv_len = 0;
	int ret = 0;
	unsigned short len = 0;
	unsigned char integrity = 0;
	unsigned int right_integrity = 0x1;
	struct control_policy steer_cntrl = {0};
	struct control_policy_db *policy = NULL;
	struct control_policy_db *policy_tmp = NULL;

	type = buf;
	reset_stored_tlv(ctx);

	while(1) {
		if (left_tlv_len < 3)
			goto fail;
		len = get_tlv_len(type);
		tlv_len = len + 3;
		if (tlv_len > left_tlv_len)
			goto fail;

		val = type + 3;

		if (*type == CLI_ASSOC_CONTROL_REQUEST_TYPE) {
			integrity |= (1 << 0);
			ret = parse_cli_assoc_control_request_tlv(ctx, len, val, &steer_cntrl);
			if (ret < 0) {
				err(DEBUG_CAT_MSG, "err CLI_ASSOC_CONTROL_REQUEST tlv\n");
				goto fail;
			}
			store_revd_tlvs(ctx, type, tlv_len);
		} else if (*type == VENDOR_SPECIFIC_TLV_TYPE) {
			store_revd_tlvs(ctx, type, tlv_len);
		} else if (*type == END_OF_TLV_TYPE) {
			break;
		}
		type += tlv_len;
		left_tlv_len -= tlv_len;
	}

	if (integrity != right_integrity) {
		err(DEBUG_CAT_MSG, "lack of mandatory tlv; integrity=%d\n", integrity);
		goto fail;
	}

	if (integrity&BIT(0))
		update_control_policy_info(&(ctx->steer_cntrl), &steer_cntrl);

	return 0;
fail:
	if ((integrity&BIT(0)) && !SLIST_EMPTY(&(steer_cntrl.policy_head))) {
		policy = SLIST_FIRST(&(steer_cntrl.policy_head));
		while (policy) {
			policy_tmp = SLIST_NEXT(policy, policy_entry);
			SLIST_REMOVE(&(steer_cntrl.policy_head), policy, control_policy_db, policy_entry);
			free(policy);
			policy = policy_tmp;
		}
	}
	return -1;
}

int parse_ap_metrics_query_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len,
	unsigned char *radio_identifier)
{
	unsigned char *type = NULL;
	unsigned int tlv_len = 0;
#ifdef MAP_R2
	unsigned char *val = NULL;
	int ret = 0;
#endif
	unsigned short len = 0;
	unsigned char integrity = 0;
	unsigned int all_integrity = 0xff;
	unsigned char radio_if[ETH_ALEN] = {0};
	unsigned char zero_if[ETH_ALEN] = {0};

	type = buf;
	reset_stored_tlv(ctx);
#ifdef MAP_R2
	delete_exist_radio_identifier(ctx);
#endif
	while(1) {
		if (left_tlv_len < 3)
			return -1;
		len = get_tlv_len(type);
		tlv_len = len + 3;
		if (tlv_len > left_tlv_len)
			return -1;
#ifdef MAP_R2
		val = type + 3;
#endif
		/* One AP metric query TLV */
		if (*type == AP_METRICS_QUERY_TYPE) {
			integrity |= (1 << 0);
			store_revd_tlvs(ctx, type, tlv_len);
		}
#ifdef MAP_R2
		/* Zero or more AP Radio Identifier TLVs */
		else if (*type == AP_RADIO_IDENTIFIER_TYPE) {
			integrity |= (1 << 1);
			/* need save ap radio identifier for each radio */
			ret = parse_ap_radio_identifier_tlv(ctx, radio_if
#ifdef MAP_R2
			, 1
#endif
			, len, val);
			if (ret < 0) {
				err(DEBUG_CAT_MSG, "err AP_RADIO_IDENTIFIER tlv\n");
				return -1;
			}
			store_revd_tlvs(ctx, type, tlv_len);
		}
#endif
		else if (*type == END_OF_TLV_TYPE)
			break;

		type += tlv_len;
		left_tlv_len -= tlv_len;
	}

	if ((integrity & all_integrity) == 0) {
		err(DEBUG_CAT_MSG, "lack of mandatory tlv; integrity=%d\n", integrity);
		return -1;
	}

	if ((integrity&BIT(1)) && (os_memcmp(radio_if, zero_if, ETH_ALEN)))
		os_memcpy(radio_identifier, radio_if, ETH_ALEN);

	return 0;
}

int parse_associated_sta_link_metrics_query_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len)
{
	unsigned char *type = NULL;
	unsigned int tlv_len = 0;
	unsigned short len = 0;
	unsigned char integrity = 0;

	type = buf;
	reset_stored_tlv(ctx);

	while(1) {
		if (left_tlv_len < 3)
			return -1;
		len = get_tlv_len(type);
		tlv_len = len + 3;
		if (tlv_len > left_tlv_len)
			return -1;

		if (*type == STA_MAC_ADDRESS_TYPE) {
			integrity |= 0x1;
			store_revd_tlvs(ctx, type, tlv_len);
		} else if (*type == END_OF_TLV_TYPE) {
			break;
		}
		type += tlv_len;
		left_tlv_len -= tlv_len;
	}

	if(integrity != 0x1) {
		err(DEBUG_CAT_MSG, "lack of mandatory tlv; integrity=%d\n", integrity);
		return -1;
	}

	return 0;
}

int parse_associated_sta_link_metrics_rsp_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len)
{
	unsigned char *type = NULL;
	unsigned int tlv_len = 0;
	unsigned short len = 0;
	unsigned char integrity = 0, all_integrity = 0xff;

	type = buf;
	reset_stored_tlv(ctx);

	while(1) {
		if (left_tlv_len < 3)
			return -1;
		len = get_tlv_len(type);
		tlv_len = len + 3;
		if (tlv_len > left_tlv_len)
			return -1;

		if (*type == ASSOC_STA_LINK_METRICS_TYPE) {
			integrity |= (1 << 0);
			store_revd_tlvs(ctx, type, tlv_len);
		}
		/* Zero or one Error Code TLV */
		else if (*type == ERROR_CODE_TYPE) {
			integrity |= (1 << 1);
			store_revd_tlvs(ctx, type, tlv_len);
		}
#ifdef MAP_R2
		/* One or more Associated STA Extended Link Metrics TLVs */
		else if (*type == ASSOCIATED_STA_EXTENDED_LINK_METRIC_TYPE) {
			integrity |= (1 << 2);
			store_revd_tlvs(ctx, type, tlv_len);
		}
#endif

#ifdef MAP_R3
		else if (*type == 0xB0) {
			integrity |= (1 << 6);
			store_revd_tlvs(ctx, type, tlv_len);
		}
#endif
		else if (*type == END_OF_TLV_TYPE)
			break;

		type += tlv_len;
		left_tlv_len -= tlv_len;
	}

	if ((integrity & all_integrity) == 0) {
		err(DEBUG_CAT_MSG, "lack of mandatory tlv; integrity=%d\n", integrity);
		return -1;
	}

	return 0;
}

int parse_unassociated_sta_link_metrics_query_message(
	struct p1905_managerd_ctx *ctx, unsigned char *buf,
	unsigned int left_tlv_len)
{
	unsigned char *type = NULL;
	unsigned char *val = NULL;
	unsigned int tlv_len = 0;
	int ret = 0;
	unsigned short len = 0;
	unsigned char integrity = 0;

	type = buf;
	reset_stored_tlv(ctx);

	while(1) {
		if (left_tlv_len < 3)
			return -1;
		len = get_tlv_len(type);
		tlv_len = len + 3;
		if (tlv_len > left_tlv_len)
			return -1;
		val = type + 3;

		if (*type == UNASSOC_STA_LINK_METRICS_QUERY_TYPE) {
			integrity |= 0x1;
			ret = parse_unassociated_sta_link_metrics_query_tlv(ctx, len, val);
			if (ret < 0) {
				err(DEBUG_CAT_MSG, "err UNASSOC_STA_LINK_METRICS_QUERY tlv\n");
				return -1;
			}
			store_revd_tlvs(ctx, type, tlv_len);
		} else if (*type == END_OF_TLV_TYPE) {
			break;
		}
		type += tlv_len;
		left_tlv_len -= tlv_len;
	}

	if(integrity != 0x1) {
		err(DEBUG_CAT_MSG, "lack of mandatory tlv; integrity=%d\n", integrity);
		return -1;
	}

	return 0;
}



int parse_backhaul_steering_request_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len)
{
	unsigned char *type = NULL;
	unsigned int tlv_len = 0;
	unsigned short len = 0;
	unsigned char integrity = 0;

	type = buf;
	reset_stored_tlv(ctx);

	while(1) {
		if (left_tlv_len < 3)
			return -1;
		len = get_tlv_len(type);
		tlv_len = len + 3;
		if (tlv_len > left_tlv_len)
			return -1;

		if (*type == BACKHAUL_STEERING_REQUEST_TYPE) {
			integrity |= 0x1;
			store_revd_tlvs(ctx, type, tlv_len);
		} else if (*type == END_OF_TLV_TYPE) {
			break;
		}
		type += tlv_len;
		left_tlv_len -= tlv_len;
	}

	if (integrity != 0x1) {
		err(DEBUG_CAT_MSG, "lack of mandatory tlv; integrity=%d\n", integrity);
		return -1;
	}

	return 0;
}

int parse_backhaul_steering_rsp_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len)
{
	unsigned char *type = NULL;
	unsigned int tlv_len = 0;
	unsigned short len = 0;
	unsigned char integrity = 0;

	type = buf;
	reset_stored_tlv(ctx);

	while(1) {
		if (left_tlv_len < 3)
			return -1;

		len = get_tlv_len(type);
		tlv_len = len + 3;
		if (tlv_len > left_tlv_len)
			return -1;

		if (*type == BACKHAUL_STEERING_RESPONSE_TYPE) {
			integrity |= 0x1;
			store_revd_tlvs(ctx, type, tlv_len);
		} else if (*type == ERROR_CODE_TYPE) {
			store_revd_tlvs(ctx, type, tlv_len);
		} else if (*type == END_OF_TLV_TYPE) {
			break;
		}
		type += tlv_len;
		left_tlv_len -= tlv_len;
	}

	if (integrity != 0x1) {
		err(DEBUG_CAT_MSG, "lack of mandatory tlv; integrity=%d\n", integrity);
		return -1;
	}

	return 0;
}

int parse_ap_metrics_response_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len)
{
	unsigned char *type = NULL;
	unsigned int tlv_len = 0;
	unsigned short len = 0;
	unsigned int integrity = 0;
	unsigned int all_integrity = 0xff;

	type = buf;
	reset_stored_tlv(ctx);

	while(1) {
		if (left_tlv_len < 3)
			return -1;

		len = get_tlv_len(type);
		tlv_len = len + 3;
		if (tlv_len > left_tlv_len)
			return -1;

		/* One or more AP mMetrics TLVs */
		if (*type == AP_METRICS_TYPE) {
			integrity |= (1 << 0);
			store_revd_tlvs(ctx, type, tlv_len);
		}
		/* Zero or more Associated STA Traffic Stats TLVs */
		else if (*type == ASSOC_STA_TRAFFIC_STATS_TYPE) {
			integrity |= (1 << 1);
			parse_assoc_sta_traffic_stats_tlv(ctx, type);
			store_revd_tlvs(ctx, type, tlv_len);
		}
		/* Zero or more Associated STA Link Metrics TLVs */
		else if (*type == ASSOC_STA_LINK_METRICS_TYPE) {
			integrity |= (1 << 2);
			store_revd_tlvs(ctx, type, tlv_len);
		}
#ifdef MAP_R2
		/* Zero or more Radio Metrics TLVs */
		else if (*type == RADIO_METRIC_TYPE) {
			integrity |= (1 << 3);
			store_revd_tlvs(ctx, type, tlv_len);
		}
		/* One or more AP Extended Metrics TLVs */
		else if (*type == AP_EXTENDED_METRIC_TYPE) {
			integrity |= (1 << 4);
			store_revd_tlvs(ctx, type, tlv_len);
		}
		/* Zero or more Associated STA Extended Link Metrics TLVs */
		else if (*type == ASSOCIATED_STA_EXTENDED_LINK_METRIC_TYPE) {
			integrity |= (1 << 5);
			store_revd_tlvs(ctx, type, tlv_len);
		}
		/* Zero or more Associated STA Extended Link Metrics TLVs */
		else if (*type == VENDOR_SPECIFIC_TLV_TYPE) {
			integrity |= (1 << 6);
			store_revd_tlvs(ctx, type, tlv_len);
		}
#endif

#ifdef MAP_R6
		/* One or more AP MLD Extended Metrics TLVs */
		else if (*type == AP_MLD_EXTENDED_METRICS_TLV_TYPE) {
			integrity |= (1 << 7);
			store_revd_tlvs(ctx, type, tlv_len);
		}
		/* Zero or more Affiliated AP Metrics TLV */
		else if (*type == AFFILIATED_AP_METRICS_TLV_TYPE) {
			integrity |= (1 << 8);
			store_revd_tlvs(ctx, type, tlv_len);
		}
		/* Zero or more Affiliated STA Metrics TLV */
		else if (*type == AFFILIATED_STA_METRICS_TLV_TYPE) {
			integrity |= (1 << 9);
			(void)parse_affiliated_sta_metrics_tlv(ctx, type);
			store_revd_tlvs(ctx, type, tlv_len);
		}
#endif
		else if (*type == END_OF_TLV_TYPE) {
			break;
		}
		type += tlv_len;
		left_tlv_len -= tlv_len;
	}

	if ((integrity & all_integrity) == 0) {
		err(DEBUG_CAT_MSG, "lack of mandatory tlv; integrity=%d\n", integrity);
		return -1;
	}

	return 0;
}

int parse_combined_infra_metrics_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len)
{
	unsigned char *type = NULL;
	unsigned int tlv_len = 0;
	unsigned short len = 0;
	unsigned char integrity = 0;

	type = buf;
	reset_stored_tlv(ctx);

	while(1) {
		if (left_tlv_len < 3)
			return -1;

		len = get_tlv_len(type);
		tlv_len = len + 3;
		if (tlv_len > left_tlv_len)
			return -1;

		if (*type == AP_METRICS_TYPE) {
			integrity |= 0x1;
			store_revd_tlvs(ctx, type, tlv_len);
		} else if (*type == TRANSMITTER_LINK_METRIC_TYPE) {
			integrity |= 0x1;
			store_revd_tlvs(ctx, type, tlv_len);
		} else if (*type == RECEIVER_LINK_METRIC_TYPE) {
			integrity |= 0x1;
			store_revd_tlvs(ctx, type, tlv_len);
		} else if (*type == ERROR_CODE_TYPE) {
			store_revd_tlvs(ctx, type, tlv_len);
		} else if (*type == END_OF_TLV_TYPE) {
			break;
		}
		type += tlv_len;
		left_tlv_len -= tlv_len;
	}

	if (integrity != 0x1) {
		err(DEBUG_CAT_MSG, "lack of mandatory tlv; integrity=%d\n", integrity);
		return -1;
	}

	return 0;
}

int parse_ap_capability_report_message(struct p1905_managerd_ctx *ctx,
	unsigned char *almac, unsigned char *buf, unsigned int left_tlv_len)
{
	unsigned char *type = NULL;
	unsigned short len = 0;
	unsigned char *value = NULL;
	unsigned int tlv_len = 0;
	int ret = 0;
	unsigned int integrity = 0, all_integrity = 0xff;
	struct agent_list_db *agent_info = NULL;
	unsigned char ap_cap = {0};
	struct agent_radio_info rinfo_tmp[MAX_RADIO_NUM];
	unsigned char ra_idx = 0, ra_cnt = 0;
#ifdef MAP_R2
	struct ap_r2_capability r2_cap = {0};
#endif

#ifdef MAP_R6
	struct wifi7_mlo_cap_db *mlo_cap = NULL, *mlo_cap_tmp = NULL;
	struct dl_list wifi7_mlo_cap_list;

	dl_list_init(&wifi7_mlo_cap_list);
#endif

	type = buf;
	reset_stored_tlv(ctx);

	while (1) {
		if (left_tlv_len < 3)
			goto fail;

		len = get_tlv_len(type);
		value = type + 3;
		tlv_len = len + 3;
		if (tlv_len > left_tlv_len)
			goto fail;

		/* One AP Capability TLV */
		if (*type == AP_CAPABILITY_TYPE) {
			ret = parse_ap_capability_tlv(ctx, len, value, &ap_cap);
			if (ret < 0) {
				err(DEBUG_CAT_MSG, "error AP_CAPABILITY tlv\n");
				goto fail;
			}
			integrity |= (1 << 0);
			store_revd_tlvs(ctx, type, tlv_len);
		}
		/* One or more AP Radio Basic Capabilities TLV */
		else if (*type == AP_RADIO_BASIC_CAPABILITY_TYPE) {
			ra_cnt += 1;
			if (ra_cnt > MAX_RADIO_NUM) {
				err(DEBUG_CAT_MSG, "radio_cnt(%d) > MAX_RADIO_NUM(%d)"
					" in ap radio basic cap tlv\n", ra_cnt, MAX_RADIO_NUM);
				goto fail;
			}
			os_memset(&rinfo_tmp[ra_cnt - 1], 0, sizeof(struct agent_radio_info));
			ret = parse_ap_radio_basic_cap_tlv(ctx, &rinfo_tmp[ra_cnt - 1], len, value);
			if (ret < 0) {
				err(DEBUG_CAT_MSG, "err AP_RADIO_BASIC_CAPABILITY tlv\n");
				goto fail;
			}
			integrity |= (1 << 1);
			store_revd_tlvs(ctx, type, tlv_len);
		}
		/* Zero or more AP HT Capabilities TLV */
		else if (*type == AP_HT_CAPABILITY_TYPE) {
			ret = parse_ap_ht_capability_tlv(ctx, len, value);
			if (ret < 0) {
				err(DEBUG_CAT_MSG, "error AP_HT_CAPABILITY tlv\n");
				goto fail;
			}
			integrity |= (1 << 2);
			store_revd_tlvs(ctx, type, tlv_len);
		}
		/* Zero or more AP VHT Capabilities TLV */
		else if (*type == AP_VHT_CAPABILITY_TYPE) {
			ret = parse_ap_vht_capability_tlv(ctx, len, value);
			if (ret < 0) {
				err(DEBUG_CAT_MSG, "error AP_VHT_CAPABILITY tlv\n");
				goto fail;
			}

			integrity |= (1 << 3);
			store_revd_tlvs(ctx, type, tlv_len);
		}
		/* Zero or more AP HE Capabilities TLV */
		else if (*type == AP_HE_CAPABILITY_TYPE) {
			integrity |= (1 << 4);
			store_revd_tlvs(ctx, type, tlv_len);
		}
#ifdef MAP_R2
		/* One Channel Scan Capabilities TLV */
		else if (*type == CHANNEL_SCAN_CAPABILITY_TYPE) {
			integrity |= (1 << 5);
			store_revd_tlvs(ctx, type, tlv_len);
		}
		/* One CAC Capabilities TLV */
		else if (*type == CAC_CAPABILITIES_TYPE) {
			integrity |= (1 << 6);
			store_revd_tlvs(ctx, type, tlv_len);
		}
		/* One R2 AP Capability TLV */
		else if (*type == R2_AP_CAPABILITY_TYPE) {
			os_memset(&r2_cap, 0, sizeof(r2_cap));
			integrity |= (1 << 7);
			ret = parse_r2_ap_capability_tlv(&r2_cap, almac, len, value);
			if (ret < 0) {
				err(DEBUG_CAT_MSG, "error R2_AP_CAPABILITY tlv\n");
				goto fail;
			}
			store_revd_tlvs(ctx, type, tlv_len);
		}
		/* One Metric Collection Interval TLV */
		else if (*type == METRIC_COLLECTION_INTERVAL_TYPE) {
			integrity |= (1 << 8);
			store_revd_tlvs(ctx, type, tlv_len);
		}
		/* skip: One Device 1905 Layer Security Capability TLV
		else if (*temp_buf == METRIC_COLLECTION_INTERVAL_TYPE) {
			integrity |= (1 << 2);
			length = get_tlv_len_by_tlvtype(temp_buf);
			store_revd_tlvs(ctx, temp_buf, length);
			temp_buf += length;
		}*/
#endif
#ifdef MAP_R3
		/* One Device 1905 Layer Security Capability TLV */
		else if (*type == _1905_LAYER_SECURITY_CAPABILITY_TYPE) {
			unsigned char onboardingProto = 0, msgIntAlg = 0, msgEncAlg = 0;

			integrity |= (1 << 9);
			ret = parse_1905_layer_security_capability_tlv(ctx, type, &onboardingProto, &msgIntAlg, &msgEncAlg);
			if (ret < 0) {
				warn(DEBUG_CAT_DPP, "error 1905layer security cap tlv\n");
				goto fail;
			}
		}
#endif
#ifdef MAP_R3_WF6
		else if (*type == 0xAA) {
			integrity |= (1 << 10);
			ret = parse_ap_wf6_capability_tlv(ctx, type);
			if (ret < 0) {
				warn(DEBUG_CAT_DPP, "error ap wf6 capability tlv\n");
				goto fail;
			}
			store_revd_tlvs(ctx, type, tlv_len);
		}
#endif /*MAP_R3_WF6*/
#ifdef MAP_R3_DE
		else if (*type == R3_DE_INVENTORY_TLV_TYPE) {
			integrity |= (1 << 11);
			store_revd_tlvs(ctx, type, tlv_len);
		}
#endif //MAP_R3_DE
		else if (*type == VENDOR_SPECIFIC_TLV_TYPE) {
			integrity |= (1 << 12);
			store_revd_tlvs(ctx, type, tlv_len);
		}
#ifdef MAP_R6
		/* wifi7 capability */
		else if (*type == WIFI7_AGENT_CAPABILITY_TLV_TYPE) {
			ret = parse_wifi7_cap_tlv(ctx, almac, &wifi7_mlo_cap_list, value, len);
			if (ret < 0) {
				os_free(mlo_cap);
				warn(DEBUG_CAT_MLO, "error parse wifi7 capability tlv\n");
				goto fail;
			}
			integrity |= (1 << 13);
			store_revd_tlvs(ctx, type, tlv_len);
		} else if (*type == EHT_OPERATION_TLV_TYPE) {
			integrity |= (1 << 14);
			store_revd_tlvs(ctx, type, tlv_len);
		}
#endif
		else if (*type == END_OF_TLV_TYPE) {
			break;
		}

		type += tlv_len;
		left_tlv_len -= tlv_len;
	}
	/*check integrity*/
	if ((integrity & all_integrity) == 0) {
		err(DEBUG_CAT_MSG, "lack of mandatory tlv; integrity=%d\n", integrity);
		goto fail;
	}

	if (ctx->role == CONTROLLER) {
		find_agent_info(ctx, almac, &agent_info);
		if (!agent_info) {
			notice(DEBUG_CAT_AUTOCONF, "no agent"MACSTR" info; insert\n", MAC2STR(almac));
			agent_info = insert_agent_info(ctx, almac);
			if (!agent_info) {
				err(DEBUG_CAT_AUTOCONF, "fail to insert agent "MACSTR"\n", MAC2STR(almac));
				goto fail;
			}
		}
#ifdef MAP_R6
		if ((integrity & BIT(0)) && (ap_cap & BIT(4)))
			agent_info->bsta_wsc_reconfig = 1;
#endif

		if (integrity & BIT(1)) {
			for (ra_idx = 0; ra_idx < ra_cnt && ra_cnt < MAX_RADIO_NUM; ra_idx++) {
				debug(DEBUG_CAT_MLO, "update radio idx %d ruid "MACSTR"\n", ra_idx, MAC2STR(rinfo_tmp[ra_idx].identifier));
				update_agent_radio_info(agent_info, &rinfo_tmp[ra_idx]);
			}
		}

#ifdef MAP_R2
		if (integrity & BIT(7)) {
			os_memcpy(&agent_info->r2_cap, &r2_cap, sizeof(struct ap_r2_capability));
			info(DEBUG_CAT_MLO, "dpp flag %d(%s) for "MACSTR"\n", r2_cap.dpp_flag,
				(r2_cap.dpp_flag == 1)?"enable":"disable", MAC2STR(almac));
		}
#endif

#ifdef MAP_R6
		if (integrity & BIT(13)) {
			debug(DEBUG_CAT_MLO, "ra_cnt %d\n", ra_cnt);
			update_agent_wifi7_mlo_cap(agent_info, &wifi7_mlo_cap_list);
		}
		dl_list_for_each_safe(mlo_cap, mlo_cap_tmp, &wifi7_mlo_cap_list,
				struct wifi7_mlo_cap_db, list) {
			dl_list_del(&mlo_cap->list);
			os_free(mlo_cap);
		}
		dl_list_init(&wifi7_mlo_cap_list);
#endif
	} else {
#ifdef MAP_R6
		dl_list_for_each_safe(mlo_cap, mlo_cap_tmp, &wifi7_mlo_cap_list,
			struct wifi7_mlo_cap_db, list) {
			dl_list_del(&mlo_cap->list);
			os_free(mlo_cap);
		}
#endif
	}

	return 0;
fail:
#ifdef MAP_R6
	dl_list_for_each_safe(mlo_cap, mlo_cap_tmp, &wifi7_mlo_cap_list,
		struct wifi7_mlo_cap_db, list) {
		dl_list_del(&mlo_cap->list);
		os_free(mlo_cap);
	}
#endif
	return -1;
}

int parse_channel_selection_rsp_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len)
{
	unsigned char *type = NULL;
	unsigned int tlv_len = 0;
	unsigned short len = 0;
	unsigned char integrity = 0;

	type = buf;
	reset_stored_tlv(ctx);

	while (1) {
		if (left_tlv_len < 3)
			return -1;

		len = get_tlv_len(type);
		tlv_len = len + 3;
		if (tlv_len > left_tlv_len)
			return -1;

		if (*type == CH_SELECTION_RESPONSE_TYPE) {
			integrity |= (1 << 0);
			store_revd_tlvs(ctx, type, tlv_len);
		}
#ifdef MAP_R4_SPT
		else if (*type == SPATIAL_REUSE_CONFIG_RESP_TYPE) {
			integrity |= (1 << 1);
			store_revd_tlvs(ctx, type, tlv_len);
		}
#endif
		else if (*type == EHT_OPERATION_TLV_TYPE) {
			integrity |= (1 << 2);
			store_revd_tlvs(ctx, type, tlv_len);
		} else if (*type == END_OF_TLV_TYPE)
			break;

		type += tlv_len;
		left_tlv_len -= tlv_len;
	}

	if (integrity < 1) {
		err(DEBUG_CAT_MSG, "lack of mandatory tlv; integrity=%d\n", integrity);
		goto fail;
	}

	return 0;

fail:
	return -1;
}

int parse_operating_channel_report_message(struct p1905_managerd_ctx *ctx,
		unsigned char *buf, unsigned int left_tlv_len)
{
	unsigned char *type = NULL;
	unsigned short len = 0;
	unsigned int tlv_len = 0;
	unsigned int integrity = 0;

	type = buf;
	reset_stored_tlv(ctx);

#ifdef SINGLE_BAND_SUPPORT
	if (*type != OPERATING_CHANNEL_REPORT_TYPE)
		return 0;
#endif

	while (1) {
		if (left_tlv_len < 3)
			return -1;

		len = get_tlv_len(type);
		tlv_len = len + 3;
		if (tlv_len > left_tlv_len)
			return -1;

		if (*type == OPERATING_CHANNEL_REPORT_TYPE) {
			integrity |= (1 << 0);
			store_revd_tlvs(ctx, type, tlv_len);
		}
#ifdef MAP_R4_SPT
		else if (*type == SPATIAL_REUSE_REPORT_TYPE) {
			integrity |= (1 << 1);
			store_revd_tlvs(ctx, type, tlv_len);
		}
#endif
		else if (*type == EHT_OPERATION_TLV_TYPE) {
			integrity |= (1 << 2);
			store_revd_tlvs(ctx, type, tlv_len);
		} else if (*type == END_OF_TLV_TYPE)
			break;


		type += tlv_len;
		left_tlv_len -= tlv_len;
	}
	/* check integrity */
	if (integrity < 1) {
		err(DEBUG_CAT_MSG, "lack of mandatory tlv; integrity=%d\n", integrity);
		return -1;
	}

	return 0;
}

int parse_client_capability_report_message(struct p1905_managerd_ctx *ctx,
						unsigned char *buf, unsigned int left_tlv_len)
{
	unsigned char *type = NULL;
	unsigned short len = 0;
	unsigned int tlv_len = 0;
	unsigned int integrity = 0;

	type = buf;
	reset_stored_tlv(ctx);

	while (1) {
		if (left_tlv_len < 3)
			return -1;
		len = get_tlv_len(type);
		tlv_len = len + 3;
		if (left_tlv_len < tlv_len)
			return -1;

		if (*type == CLIENT_INFO_TYPE) {
			integrity |= (1 << 0);
			store_revd_tlvs(ctx, type, tlv_len);
		} else if (*type == CLIENT_CAPABILITY_REPORT_TYPE) {
			integrity |= (1 << 1);
			store_revd_tlvs(ctx, type, tlv_len);
			break;
		} else if (*type == ERROR_CODE_TYPE) {
			store_revd_tlvs(ctx, type, tlv_len);
			break;
		} else if (*type == END_OF_TLV_TYPE) {
			break;
		}

		type += tlv_len;
		left_tlv_len -= tlv_len;
	}
	/* check integrity */
	if (integrity != 3) {
		err(DEBUG_CAT_MSG, "lack of mandatory tlv; integrity=%d\n", integrity);
		return -1;
	}

	return 0;
}

int parse_unassoc_sta_link_metrics_response_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len)
{
	unsigned char *type = NULL;
	unsigned int tlv_len = 0;
	unsigned short len = 0;
	unsigned char integrity = 0;

	type = buf;
	reset_stored_tlv(ctx);

	while (1) {
		if (left_tlv_len < 3)
			return -1;
		len = get_tlv_len(type);
		tlv_len = len + 3;
		if (tlv_len > left_tlv_len)
			return -1;

		if (*type == UNASSOC_STA_LINK_METRICS_RSP_TYPE) {
			integrity |= (1 << 0);
			store_revd_tlvs(ctx, type, tlv_len);
		} else if (*type == END_OF_TLV_TYPE) {
			break;
		}
		type += tlv_len;
		left_tlv_len -= tlv_len;
	}

	if (integrity != 1) {
		err(DEBUG_CAT_MSG, "lack of mandatory tlv; integrity=%d\n", integrity);
		return -1;
	}
	return 0;
}

int parse_beacon_metrics_response_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len)
{
	unsigned char *type = NULL;
	unsigned int tlv_len = 0;
	unsigned short len = 0;
	unsigned char integrity = 0;

	type = buf;
	reset_stored_tlv(ctx);

	while (1) {
		if (left_tlv_len < 3)
			return -1;

		len = get_tlv_len(type);
		tlv_len = len + 3;
		if (tlv_len > left_tlv_len)
			return -1;

		if (*type == BEACON_METRICS_RESPONSE_TYPE) {
			integrity |= (1 << 0);
			store_revd_tlvs(ctx, type, tlv_len);
		} else if (*type == END_OF_TLV_TYPE) {
			break;
		}
		type += tlv_len;
		left_tlv_len -= tlv_len;
	}

	if (integrity != 1) {
		err(DEBUG_CAT_MSG, "lack of mandatory tlv; integrity=%d\n", integrity);
		return -1;
	}

	return 0;
}

int parse_client_steering_btm_report_message(struct p1905_managerd_ctx *ctx,
		unsigned char *buf, unsigned int left_tlv_len)
{
	unsigned char *type = NULL;
	unsigned int tlv_len = 0;
	unsigned short len = 0;
	unsigned char integrity = 0;

	type = buf;
	reset_stored_tlv(ctx);

	while (1) {
		if (left_tlv_len < 3)
			return -1;

		len = get_tlv_len(type);
		tlv_len = len + 3;
		if (tlv_len > left_tlv_len)
			return -1;

		if (*type == STEERING_BTM_REPORT_TYPE) {
			integrity |= (1 << 0);
			store_revd_tlvs(ctx, type, tlv_len);
		} else if (*type == END_OF_TLV_TYPE) {
			break;
		}
		type += tlv_len;
		left_tlv_len -= tlv_len;
	}

	if (integrity != 1) {
		err(DEBUG_CAT_MSG, "lack of mandatory tlv; integrity=%d\n", integrity);
		return -1;
	}
	return 0;
}

int parse_higher_layer_data_message(struct p1905_managerd_ctx *ctx,
					unsigned char *buf, unsigned int left_tlv_len)
{
	unsigned char *type = NULL;
	unsigned short len = 0;
	unsigned int tlv_len = 0;
	unsigned int integrity = 0;

	type = buf;
	reset_stored_tlv(ctx);

	while (1) {
		if (left_tlv_len < 3)
			return -1;

		len = get_tlv_len(type);
		tlv_len = len + 3;
		if (left_tlv_len < tlv_len)
			return -1;

		if (*type == HIGH_LAYER_DATA_TYPE) {
			integrity |= (1 << 0);
			store_revd_tlvs(ctx, type, tlv_len);
		} else if (*type == END_OF_TLV_TYPE) {
			break;
		}

		type += tlv_len;
		left_tlv_len -= tlv_len;
	}

	if (integrity != 1) {
		err(DEBUG_CAT_MSG, "lack of mandatory tlv; integrity=%d\n", integrity);
		return -1;
	}

	return 0;
}

int parse_channel_scan_request_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len)
{
	unsigned char *type = NULL;
	unsigned short len = 0;
	unsigned int tlv_len = 0;
	unsigned char integrity = 0;

	type = buf;
	reset_stored_tlv(ctx);

	while(1) {
		if (left_tlv_len < 3)
			return -1;

		len = get_tlv_len(type);
		tlv_len = len + 3;
		if (tlv_len > left_tlv_len)
			return -1;

		if (*type == CHANNEL_SCAN_REQUEST_TYPE) {
			integrity |= 0x1;
			store_revd_tlvs(ctx, type, tlv_len);
		} else if (*type == END_OF_TLV_TYPE) {
			break;
		}

		type += tlv_len;
		left_tlv_len -= tlv_len;
	}

	if (integrity != 0x1) {
		err(DEBUG_CAT_MSG, "lack of mandatory tlv; integrity=%d\n", integrity);
		return -1;
	}

	return 0;
}

int parse_channel_scan_report_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len)
{
	unsigned char *type = NULL;
	unsigned int tlv_len = 0;
	unsigned short len = 0;
	unsigned char integrity = 0;

	type = buf;
	reset_stored_tlv(ctx);

	while(1) {
		if (left_tlv_len < 3)
			return -1;
		len = get_tlv_len(type);
		tlv_len = len + 3;
		if (tlv_len > left_tlv_len)
			return -1;

		if (*type == TIMESTAMP_TYPE) {
			integrity |= 0x1;
			store_revd_tlvs(ctx, type, tlv_len);
		} else if (*type == CHANNEL_SCAN_RESULT_TYPE) {
			integrity |= 0x2;
			store_revd_tlvs(ctx, type, tlv_len);
		} else if (*type == VENDOR_SPECIFIC_TLV_TYPE) {
			integrity |= 0x2;
			store_revd_tlvs(ctx, type, tlv_len);
		} else if (*type == END_OF_TLV_TYPE) {
			break;
		}
		type += tlv_len;
		left_tlv_len -= tlv_len;
	}

	if (integrity != 0x3) {
		err(DEBUG_CAT_MSG, "lack of mandatory tlv; integrity=%d\n", integrity);
		return -1;
	}

	return 0;
}

int parse_tunneled_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len, unsigned char *msg_type)
{
	unsigned char *type = NULL;
	unsigned int tlv_len = 0;
	unsigned short len = 0;
	unsigned char integrity = 0;

	type = buf;
	reset_stored_tlv(ctx);

	while (1) {
		if (left_tlv_len < 3)
			return -1;

		len = get_tlv_len(type);
		tlv_len = len + 3;
		if (tlv_len > left_tlv_len)
			return -1;

		if (*type == SOURCE_INFO_TYPE) {
			integrity |= (1 << 0);
			store_revd_tlvs(ctx, type, tlv_len);
#ifdef MAP_R5
			memcpy(ctx->dscp_policy_act_frm.sta_mac, (type+3), MAC_ADDR_LEN);
#endif
		} else if (*type == TUNNELED_MESSAGE_TYPE) {
			integrity |= (1 << 0);
			store_revd_tlvs(ctx, type, tlv_len);
			*msg_type = *(type+3);
#ifdef MAP_R5
			if (*(type+3) == TUNNELLED_DSCP_QUERY || *(type+3) == TUNNELLED_DSCP_RESPONSE)
				ctx->dscp_policy_act_frm.protocol_type = *(type+3);
			else
				ctx->dscp_policy_act_frm.protocol_type = 0;
#endif
		}  else if (*type == TUNNELED_TYPE) {
			integrity |= (1 << 0);
			store_revd_tlvs(ctx, type, tlv_len);
#ifdef MAP_R5
			if (ctx->dscp_policy_act_frm.protocol_type == TUNNELLED_DSCP_QUERY ||
				ctx->dscp_policy_act_frm.protocol_type == TUNNELLED_DSCP_RESPONSE)
				os_memcpy(ctx->dscp_policy_act_frm.frmbody, (type+3),
					MIN(tlv_len, MAX_FRAME_BODY_LEN));
#endif
		} else if (*type == END_OF_TLV_TYPE) {
			break;
		}
		type += tlv_len;
		left_tlv_len -= tlv_len;
	}

	if (integrity != 1) {
		err(DEBUG_CAT_MSG, "lack of mandatory tlv; integrity=%d\n", integrity);
		return -1;
	}
	return 0;
}

int parse_assoc_status_notification_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len)
{
	unsigned char *type = NULL;
	unsigned int tlv_len = 0;
	unsigned short len = 0;
	unsigned char integrity = 0;

	type = buf;
	reset_stored_tlv(ctx);

	while (1) {
		if (left_tlv_len < 3)
			return -1;

		len = get_tlv_len(type);
		tlv_len = len + 3;
		if (tlv_len > left_tlv_len)
			return -1;

		if (*type == ASSOCIATION_STATUS_NOTIFICATION_TYPE) {
			integrity |= (1 << 0);
			store_revd_tlvs(ctx, type, tlv_len);
		} else if (*type == END_OF_TLV_TYPE) {
			break;
		}
		type += tlv_len;
		left_tlv_len -= tlv_len;
	}

	if (integrity != 1) {
		err(DEBUG_CAT_MSG, "lack of mandatory tlv; integrity=%d\n", integrity);
		return -1;
	}

	return 0;
}

int parse_cac_request_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len)
{
	unsigned char *type = NULL;
	unsigned int tlv_len = 0;
	unsigned short len = 0;
	unsigned char integrity = 0;

	type = buf;
	reset_stored_tlv(ctx);

	while (1) {
		if (left_tlv_len < 3)
			return -1;

		len = get_tlv_len(type);
		tlv_len = len + 3;
		if (tlv_len > left_tlv_len)
			return -1;

		if (*type == CAC_REQUEST_TYPE) {
			integrity |= (1 << 0);
			store_revd_tlvs(ctx, type, tlv_len);
		} else if (*type == END_OF_TLV_TYPE) {
			break;
		}
		type += tlv_len;
		left_tlv_len -= tlv_len;
	}

	if (integrity != 1) {
		err(DEBUG_CAT_MSG, "lack of CAC_REQUEST tlv\n");
		return -1;
	}

	return 0;
}

int parse_cac_terminate_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len)
{
	unsigned char *type = NULL;
	unsigned int tlv_len = 0;
	unsigned short len = 0;
	unsigned char integrity = 0;

	type = buf;
	reset_stored_tlv(ctx);

	while (1) {
		if (left_tlv_len < 3)
			return -1;

		len = get_tlv_len(type);
		tlv_len = len + 3;
		if (tlv_len > left_tlv_len)
			return -1;

		if (*type == CAC_TERMINATION_TYPE) {
			integrity |= (1 << 0);
			store_revd_tlvs(ctx, type, tlv_len);
		} else if (*type == END_OF_TLV_TYPE) {
			break;
		}
		type += tlv_len;
		left_tlv_len -= tlv_len;
	}

	if (integrity != 1) {
		err(DEBUG_CAT_MSG, "lack of mandatory tlv; integrity=%d\n", integrity);
		return -1;
	}

	return 0;
}


int parse_client_disassciation_stats_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len)
{
	unsigned char *type = NULL;
	unsigned int tlv_len = 0;
	unsigned short len = 0;
	unsigned char integrity = 0;

	type = buf;
	reset_stored_tlv(ctx);

	while (1) {
		if (left_tlv_len < 3)
			return -1;
		len = get_tlv_len(type);
		tlv_len = len + 3;
		if (tlv_len > left_tlv_len)
			return -1;

		if (*type == STA_MAC_ADDRESS_TYPE) {
			integrity |= (1 << 0);
			store_revd_tlvs(ctx, type, tlv_len);
		} else if (*type == REASON_CODE_TYPE) {
			integrity |= (1 << 1);
			store_revd_tlvs(ctx, type, tlv_len);
		} else if (*type == ASSOC_STA_TRAFFIC_STATS_TYPE) {
			integrity |= (1 << 2);
			store_revd_tlvs(ctx, type, tlv_len);
		}
#ifdef MAP_R6
		else if (*type == AFFILIATED_STA_METRICS_TLV_TYPE) {
			integrity |= (1 << 3);
			store_revd_tlvs(ctx, type, tlv_len);
		}
#endif
		else if (*type == END_OF_TLV_TYPE)
			break;

		type += tlv_len;
		left_tlv_len -= tlv_len;
	}

	if (integrity < 0x7) {
		err(DEBUG_CAT_MSG, "lack of mandatory tlv; integrity=%d\n", integrity);
		return -1;
	}

	return 0;
}

int parse_backhaul_sta_cap_report_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len)
{
	unsigned char *type = NULL;
	unsigned int tlv_len = 0;
	unsigned short len = 0;
	unsigned char integrity = 0;

	type = buf;
	reset_stored_tlv(ctx);

	while (1) {
		if (left_tlv_len < 3)
			return -1;
		len = get_tlv_len(type);
		tlv_len = len + 3;
		if (tlv_len > left_tlv_len)
			return -1;

		if (*type == BACKHAUL_STA_RADIA_CAPABILITY_TYPE) {
			integrity |= (1 << 0);
			store_revd_tlvs(ctx, type, tlv_len);
		} else if (*type == END_OF_TLV_TYPE) {
			break;
		}
		type += tlv_len;
		left_tlv_len -= tlv_len;
	}

	if (integrity == 0x0) {
		err(DEBUG_CAT_MSG, "lack of mandatory tlv; integrity=%d\n", integrity);
		return -1;
	}
	return 0;
}

int parse_failed_connection_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len)
{
	unsigned char *type = NULL;
	unsigned int tlv_len = 0;
	unsigned short len = 0;
	unsigned char integrity = 0;

	type = buf;
	reset_stored_tlv(ctx);

	while (1) {
		if (left_tlv_len < 3)
			return -1;
		len = get_tlv_len(type);
		tlv_len = len + 3;
		if (tlv_len > left_tlv_len)
			return -1;

		if (*type == STA_MAC_ADDRESS_TYPE) {
			integrity |= (1 << 0);
			store_revd_tlvs(ctx, type, tlv_len);
		} else if (*type == ASSOCIATED_STATUS_CODE_TYPE) {
			integrity |= (1 << 1);
			store_revd_tlvs(ctx, type, tlv_len);
		} else if (*type == REASON_CODE_TYPE) {
			integrity |= (1 << 2);
			store_revd_tlvs(ctx, type, tlv_len);
		} else if (*type == END_OF_TLV_TYPE) {
			break;
		}
		type += tlv_len;
		left_tlv_len -= tlv_len;
	}

	if (integrity < 0x3) {
		err(DEBUG_CAT_MSG, "lack of mandatory tlv; integrity=%d\n", integrity);
		return -1;
	}

	return 0;
}

int parse_beacon_metrics_query_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len)
{
	unsigned char *type = NULL;
	unsigned char *val = NULL;
	unsigned int tlv_len = 0;
	int ret = 0;
	unsigned short len = 0;
	unsigned char integrity = 0;

	type = buf;
	reset_stored_tlv(ctx);

	while(1) {
		if (left_tlv_len < 3)
			return -1;
		len = get_tlv_len(type);
		tlv_len = len + 3;
		if (tlv_len > left_tlv_len)
			return -1;
		val = type + 3;

		if (*type == BEACON_METRICS_QUERY_TYPE) {
			integrity |= 0x1;
			ret = parse_beacon_metrics_query_tlv(ctx, len, val);
			if (ret < 0) {
				err(DEBUG_CAT_MSG, "err BEACON_METRICS_QUERY tlv\n");
				return -1;
			}
			store_revd_tlvs(ctx, type, tlv_len);
		} else if (*type == END_OF_TLV_TYPE) {
			break;
		}
		type += tlv_len;
		left_tlv_len -= tlv_len;
	}

	if (integrity != 0x1) {
		err(DEBUG_CAT_MSG, "lack of mandatory tlv; integrity=%d\n", integrity);
		return -1;
	}

	return 0;
}

int parse_channel_preference_report_message(struct p1905_managerd_ctx *ctx,
	struct agent_list_db *agent, unsigned char *buf, unsigned int left_tlv_len)
{
	unsigned char *type = NULL;
	unsigned char *val = NULL;
	unsigned int tlv_len = 0;
	int ret = 0;
	unsigned short len = 0;
	struct list_head_ch_prefer ch_prefer_head = {0};
	struct ch_prefer_db *chcap = NULL;
	struct ch_prefer_db *chcap_tmp = NULL;
	unsigned int integrity = 0;

	type = buf;
	reset_stored_tlv(ctx);
	SLIST_INIT(&ch_prefer_head);

	while (1) {
		if (left_tlv_len < 3)
			goto fail;
		len = get_tlv_len(type);
		tlv_len = len + 3;
		if (tlv_len > left_tlv_len)
			goto fail;
		val = type + 3;

		if (*type == CH_PREFERENCE_TYPE) {
			integrity |= (1 << 0);
			if (ctx->MAP_Cer) {
				ret = insert_new_ch_prefer_info(&ch_prefer_head, len, val);
				if (ret < 0) {
					delete_all_ch_prefer_info((struct list_head_ch_prefer *)&(agent->ch_prefer_head));
					err(DEBUG_CAT_MSG, "err CH_PREFERENCE tlv\n");
					goto fail;
				}
			}
			store_revd_tlvs(ctx, type, tlv_len);
		} else if (*type == RADIO_OPERATION_RESTRICTION_TYPE) {
			integrity |= (1 << 1);
			store_revd_tlvs(ctx, type, tlv_len);
		} else if (*type == CAC_COMPLETION_REPORT_TYPE) {
			integrity |= (1 << 2);
			store_revd_tlvs(ctx, type, tlv_len);
		}
#ifdef MAP_R2
		else if (*type == CAC_STATUS_REPORT_TYPE) {
			integrity |= (1 << 3);
			store_revd_tlvs(ctx, type, tlv_len);
		}
#endif
		else if (*type == EHT_OPERATION_TLV_TYPE) {
			integrity |= (1 << 4);
			store_revd_tlvs(ctx, type, tlv_len);
		}
		else if (*type == END_OF_TLV_TYPE) {
			break;
		}
		type += tlv_len;
		left_tlv_len -= tlv_len;
	}

	update_ch_prefer_list_info((struct list_head_ch_prefer *)&(agent->ch_prefer_head), &ch_prefer_head);
	return 0;

fail:
	if (!SLIST_EMPTY(&ch_prefer_head)) {
		chcap = SLIST_FIRST(&ch_prefer_head);
		while (chcap != NULL) {
			chcap_tmp = SLIST_NEXT(chcap, ch_prefer_entry);
			free(chcap);
			chcap = chcap_tmp;
		}
	}
	return -1;
}




#ifdef MAP_R3
int cmdu_r3_handle(struct p1905_managerd_ctx *ctx,
	unsigned char *dmac, unsigned char *smac,
	unsigned char *cmdu_hdr, unsigned short *cmdu_len, unsigned short mtype,
	unsigned char *vsinfo, unsigned short *vsinfo_len,
	unsigned char *tlv_buf, int tlv_total_len,
	unsigned char *restore_flag, unsigned char *mid_check)
{
	unsigned char code = SUC;
	struct security_entry *entry = NULL;
	unsigned char *tlv_first = NULL, *pos_mic = NULL, *pos_vs = NULL;
	unsigned char mtk_oui[3] = { 0x00, 0x0C, 0xE7 };
	unsigned char *tlv_pos = NULL;
	unsigned short tlv_len = 0;
	struct r3_member *peer = NULL;

	peer = create_r3_member(smac);
	if (!peer)
		return -1;

	/*
	 * unicast: encrypt this frame only if both R3 device
	 * multicast: i'm R3, should encrypt the frame
	 */
	if (ctx->map_version == MAP_PROFILE_R3) {
		/* all unicast should be encrypted except reliable unicast */
		tlv_pos = tlv_first = tlv_buf;

		if (mtype == TOPOLOGY_DISCOVERY) {
			pos_mic = get_tlv_pos(tlv_first, MIC_TLV_TYPE, tlv_total_len);
			if (pos_mic) {
				while (1) {
					tlv_len = be_to_host16(*(unsigned short *)(tlv_pos + 1)) + 3;
					/* there maybe more than 1 vs info */
					if (*tlv_pos == VENDOR_SPECIFIC_TLV_TYPE) {
						pos_vs = tlv_pos;
						*vsinfo_len = tlv_len;
						if (*vsinfo_len > 16)
							*vsinfo_len = 16;

						if (!os_memcmp(&pos_vs[3], mtk_oui, 3) && (pos_vs[6] == 0x00)) {
							tlv_total_len -= *vsinfo_len;
							os_memcpy(vsinfo, pos_vs, *vsinfo_len);
							/* strip vs info added in mapfilter */
							os_memset(pos_vs, 0, 3);

							*restore_flag = 1;
						}
					} else if (*tlv_pos == END_OF_TLV_TYPE) {
						break;
					}
					tlv_pos += tlv_len;
				}
			}
		}

		/*
		 * not perform encryption procedure for the following messages
		 * 1905 AP-Autoconfiguration Search
		 * 1905 AP-AutoconfigurationResponse
		 * Direct Encap DPP or 1905 Encap EAPOL
		 */
		if ((mtype == _1905_ENCAP_EAPOL) ||
			(mtype == DIRECT_ENCAP_DPP_MESSAGE) ||
			(mtype == AP_AUTOCONFIG_SEARCH) ||
			(mtype == AP_AUTOCONFIG_RESPONSE))
			return 0;

		if (!os_memcmp(p1905_multicast_address, dmac, ETH_ALEN)) {
			unsigned char relay_ind = 0;
			unsigned char *pos_almac = NULL, *real_almac = NULL;
			unsigned short mid = 0;

			entry = sec_entry_lookup(dmac);

			/* check mid first for 1905 mc pkt */
			relay_ind = get_relay_ind_from_msg_hdr((unsigned char *)cmdu_hdr);
			mid = get_mid_from_msg_hdr((unsigned char *)cmdu_hdr);

			if (relay_ind) {
				pos_almac = get_tlv_pos(tlv_first, AL_MAC_ADDR_TLV_TYPE, tlv_total_len);
				if (!pos_almac) {
					warn(DEBUG_CAT_DPP, "pos_almac null, drop\n");
					return -1;
				}

				if (*((unsigned short *)(pos_almac+1)) < MAC_ADDR_LEN) {
					warn(DEBUG_CAT_DPP, "almac tlv len illegal, drop\n");
					return -1;
				}

				real_almac = pos_almac+3;
			} else
				real_almac = smac;

			/* R1 mcast, no sec infor for peer, no MIC TLV in pkt, go on */
			if (entry == NULL &&
				(!get_tlv_pos(tlv_buf, MIC_TLV_TYPE, tlv_total_len)))
				return 0;

			*mid_check = 1;
			if (check_recv_mid(ctx, real_almac, mid, mtype) < 0) {
				debug(DEBUG_CAT_DPP, "duplicate msg, msgtype=0x%04x(%s), mid(%04x)\n",
					mtype, get_1905_mtype_str(mtype), mid);
				ctx->need_relay = 0;
				return -1;
			}
		} else {
			entry = sec_entry_lookup(smac);
			/* R1 ucast, no sec infor for peer, no ENCRYPTED TLV in pkt, go on */
			if (entry == NULL &&
				(!get_tlv_pos(tlv_buf, ENCRYPTED_TLV_TYPE, tlv_total_len)))
				return 0;
		}

		code = sec_decrypt(dmac, smac, cmdu_hdr, cmdu_len);
		if (code != SUC) {
			/* mcast pkt with MIC TLV, go on
			 * it's encrypted from dpp onboarded device to non-dpp onboarded device
			 */
			if (dmac[0]&0x01)
				return 0;
			if (code == INVALID_RX_COUNTER && entry && entry->key_type == KEY_MULTICAST)
				return 0;

			if (code == NOT_ENCRYPTED && entry && entry->key_type == KEY_UNICAST) {
				notice(DEBUG_CAT_DPP,
					"frame 0x%04x(%s) from "MACSTR", not encrypted but sec entry valid\n",
					mtype, get_1905_mtype_str(mtype), MAC2STR(smac));
			}

			if (code == NO_KEY_FOUND &&
				get_tlv_pos(tlv_buf, ENCRYPTED_TLV_TYPE, tlv_total_len)) {
				notice(DEBUG_CAT_DPP,
					"frame 0x%04x(%s) from "MACSTR", encrypted but sec entry invalid\n",
					mtype, get_1905_mtype_str(mtype), MAC2STR(smac));
			}

			if (code == INVALID_RX_COUNTER && entry && entry->key_type == KEY_UNICAST) {
				notice(DEBUG_CAT_DPP,
					"frame 0x%04x(%s) from "MACSTR", invalid rx counter\n",
					mtype, get_1905_mtype_str(mtype), MAC2STR(smac));
			}

			peer->dec_fail_cnt++;

			if (peer->dec_fail_cnt >= ctx->decrypt_fail_threshold) {
				notice(DEBUG_CAT_DPP, "exceed decryption failure threshold %d with "MACSTR"\n",
					ctx->decrypt_fail_threshold, MAC2STR(smac));
				peer->dec_fail_cnt = 0;
				/* trigger dpp discovery again. */
				if (ctx->role != CONTROLLER) {
					/* send Decrypting failure msg to controller */
					insert_cmdu_txq(ctx->cinfo.almac, ctx->p1905_al_mac_addr,
						e_decryption_failure, ++ctx->mid, ctx->itf[ctx->cinfo.recv_ifid].if_name, 0);

					notice(DEBUG_CAT_DPP,
						"send decryption failure to controller "MACSTR" with almac "MACSTR"\n",
						MAC2STR(ctx->cinfo.almac), MAC2STR(ctx->p1905_al_mac_addr));
					/* go on sending decryption failure msg */
					process_cmdu_txq(ctx, ctx->trx_buf.buf);
				}
				notice(DEBUG_CAT_DPP, "trigger dpp peer discovery at once to "MACSTR"\n", MAC2STR(peer->al_mac));
				map_dpp_trigger_member_dpp_intro(ctx, peer);
			}
			return -1;
		}
	}
	return 0;
}

/*MAP dpp protocol defined message parsing*/
int parse_proxied_encap_dpp_message(
	struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len,
	unsigned char *al_mac,
	unsigned char *frame_type,
	unsigned short *frame_offset,
	unsigned short *frame_len)
{
	unsigned char *type = NULL;
	unsigned char *value = NULL;
	unsigned short len = 0;
	unsigned int tlv_len = 0;
	int ret = 0;
	unsigned int integrity = 0;
	struct chirp_tlv_info chirp;

	os_memset(&chirp, 0, sizeof(struct chirp_tlv_info));

	type = buf;
	reset_stored_tlv(ctx);

	while (1) {
		if (left_tlv_len < 3) {
			warn(DEBUG_CAT_DPP, "buf should greater than 3 bytes(1[type]+2[len])\n");
			return -1;
		}
		len = get_tlv_len(type);
		value = type + 3;
		tlv_len = len + 3;
		if (left_tlv_len < tlv_len) {
			warn(DEBUG_CAT_DPP, "Error TLV len, type = 0x%02x, left_tlv_length %d less than tlv_len %d\n",
			    *type, left_tlv_len, tlv_len);
			return -1;
		}
		if (*type == PROXIED_ENCAP_DPP_MESSAGE_TYPE) {
			/* only need to parse peer discovery,
			** other pkt pass to mapd directly
			*/
			ret = parse_proxied_encap_dpp_type_tlv(value, len,
				frame_type, frame_offset, frame_len);
			if (ret < 0) {
				warn(DEBUG_CAT_DPP, "error dpp message tlv\n");
				return -1;
			}
			integrity |= (1 << 0);
			store_revd_tlvs(ctx, type, (unsigned short)tlv_len);
		} else if (*type == DPP_CHIRP_VALUE_TYPE) {
			ret = parse_dpp_chirp_value_tlv(value, len, &chirp);
			if (ret < 0) {
				warn(DEBUG_CAT_DPP, "error dpp message tlv\n");
				return -1;
			}
			integrity |= (1 << 1);
			if (*frame_type != DPP_DISCOVERY_REQUEST &&
				*frame_type != DPP_DISCOVERY_RESPONSE)
				store_revd_tlvs(ctx, type, (unsigned short)tlv_len);
		} else if (*type == END_OF_TLV_TYPE)
			break;

		type += tlv_len;
		left_tlv_len -= tlv_len;
	}
	/*check integrity*/
	if (integrity < 0x1) {
		warn(DEBUG_CAT_DPP, "error when check dpp message tlvs\n");
		return -1;
	}

	return 0;
}


int parse_1905_encap_eapol_message(
	struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len,
	unsigned short *eapol_offset, unsigned short *eapol_len)
{
	unsigned char *type = NULL;
	unsigned char *value = NULL;
	unsigned short len = 0;
	unsigned int tlv_len = 0;
	unsigned int integrity = 0;

	type = buf;
	reset_stored_tlv(ctx);

	while (1) {
		if (left_tlv_len < 3) {
			warn(DEBUG_CAT_DPP, "buf should greater than 3 bytes(1[type]+2[len])\n");
			return -1;
		}
		len = get_tlv_len(type);
		value = type + 3;
		tlv_len = len + 3;
		if (left_tlv_len < tlv_len) {
			warn(DEBUG_CAT_DPP, "Error TLV len, type = 0x%02x, left_tlv_length %d less than tlv_len %d\n",
			    *type, left_tlv_len, tlv_len);
			return -1;
		}
		if (*type == _1905_ENCAP_EAPOL_MESSAGE_TYPE) {
			*eapol_offset = (unsigned short)(value - type);
			*eapol_len = len;
			integrity |= (1 << 0);
			store_revd_tlvs(ctx, type, (unsigned short)tlv_len);
		} else if (*type == END_OF_TLV_TYPE)
			break;

		type += tlv_len;
		left_tlv_len -= tlv_len;
	}
	/*check integrity*/
	if (integrity != 1) {
		warn(DEBUG_CAT_DPP, "error when check eapol message tlvs\n");
		return -1;
	}
	return 0;
}


int parse_dpp_bootstraping_uri_notification_message(
	struct p1905_managerd_ctx *ctx,
	unsigned char *buf,
	unsigned int left_tlv_len)
{
	unsigned char *type = NULL;
	unsigned short len = 0;
	unsigned int tlv_len = 0;
	unsigned int integrity = 0;

	type = buf;
	reset_stored_tlv(ctx);

	while (1) {
		if (left_tlv_len < 3) {
			warn(DEBUG_CAT_DPP, "buf should greater than 3 bytes(1[type]+2[len])\n");
			return -1;
		}
		len = get_tlv_len(type);
		tlv_len = len + 3;
		if (left_tlv_len < tlv_len) {
			warn(DEBUG_CAT_DPP, "Error TLV len, type = 0x%02x, left_tlv_length %d less than tlv_len %d\n",
			    *type, left_tlv_len, tlv_len);
			return -1;
		}
		if (*type == DPP_BOOTSTRAP_URI_NOTIFY_TYPE) {
			integrity |= (1 << 0);

			store_revd_tlvs(ctx, type, (unsigned short)tlv_len);
		} else if (*type == END_OF_TLV_TYPE)
			break;

		type += tlv_len;
		left_tlv_len -= tlv_len;
	}
	/*check integrity*/
	if (integrity != 1) {
		warn(DEBUG_CAT_DPP, "error when check dpp bootstraping uri notification tlvs\n");
		return -1;
	}
	return 0;
}


int parse_dpp_cce_indication_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len)
{
	unsigned char *type = NULL;
	unsigned short len = 0;
	unsigned int tlv_len = 0;
	unsigned int integrity = 0;

	type = buf;
	reset_stored_tlv(ctx);

	while (1) {
		if (left_tlv_len < 3) {
			warn(DEBUG_CAT_DPP, "buf should greater than 3 bytes(1[type]+2[len])\n");
			return -1;
		}
		len = get_tlv_len(type);
		tlv_len = len + 3;
		if (left_tlv_len < tlv_len) {
			warn(DEBUG_CAT_DPP, "Error TLV len, type = 0x%02x, left_tlv_length %d less than tlv_len %d\n",
			    *type, left_tlv_len, tlv_len);
			return -1;
		}
		if (*type == DPP_CCE_INDICATION_TYPE) {
			integrity |= (1 << 0);

			store_revd_tlvs(ctx, type, (unsigned short)tlv_len);
		} else if (*type == END_OF_TLV_TYPE)
			break;

		type += tlv_len;
		left_tlv_len -= tlv_len;
	}
		/*check integrity*/
	if (integrity != 1) {
		warn(DEBUG_CAT_DPP, "error when check dpp message tlvs\n");
		return -1;
	}
	return 0;
}

int parse_direct_encap_dpp_message_tlv(
	struct p1905_managerd_ctx *ctx, unsigned char *buf, unsigned short len,
	unsigned char *frame_type, unsigned short *frame_offset, unsigned short *frame_len,
	unsigned char *al_mac)
{
	unsigned short left = len;
	unsigned char *temp_buf;
	unsigned char action = 0;

	temp_buf = buf;

	if (left < 1) {
		warn(DEBUG_CAT_DPP, "Error left_tlv_length %d less than %d\n",
			left, 1);
		return -1;
	}
	action = *temp_buf;
	left -= 1;

	if (action == 0x09) {
		/* publica action frame: include dpp auth, peer discover */
		/* action frame start from Action field not Category
		** Action field:    1 octet,    value 0x09
		** OUI:             3 octets,   value 50 6F 9A
		** OUI type:        1 octet,    value 0x1A
		** Crypto Suite:    1 octet,    value *
		** DPP frame type:  1 octet,    value *
		*/
		if (left < 6) {
			warn(DEBUG_CAT_DPP, "Error left_tlv_length %d less than %d\n",
				left, 6);
			return -1;
		}
		left -= 6;
		/* 7:action hdr + 3: tlv hdr */
		*frame_offset = 7 + 3;
		*frame_type = *(temp_buf + 6);
		*frame_len = len - 7;

		if (left < *frame_len) {
			warn(DEBUG_CAT_DPP, "Error left_tlv_length %d less than %d\n",
				left, *frame_len);
			return -1;
		}

		notice(DEBUG_CAT_DPP, "public action frame %d(%s)\n",
			*frame_type, actionFrame_typeNum2str(*frame_type));
	} else {
		/* GAS frame: DPP configuration */
        /* 1905 don't handle this */
		*frame_type = 0xFF;

		/* pass whole raw data to mapd */
		notice(DEBUG_CAT_DPP, "GAS frame: %d(%s)\n",
			*frame_type, GasFrame_actionNum2str(*temp_buf));
	}
	return 0;
}



int parse_direct_encap_dpp_message(
	struct p1905_managerd_ctx *ctx, unsigned char *buf, unsigned int left_tlv_len,
	unsigned char *frame_type, unsigned short *frame_offset, unsigned short *frame_len,
	unsigned char *al_mac)
{
	unsigned char *type = NULL;
	unsigned char *value = NULL;
	unsigned short len = 0;
	unsigned int tlv_len = 0;
	int ret = 0;
	unsigned int integrity = 0;

	type = buf;
	reset_stored_tlv(ctx);

	while (1) {
		if (left_tlv_len < 3) {
			warn(DEBUG_CAT_DPP, "buf should greater than 3 bytes(1[type]+2[len])\n");
			return -1;
		}
		len = get_tlv_len(type);
		value = type + 3;
		tlv_len = len + 3;
		if (left_tlv_len < tlv_len) {
			warn(DEBUG_CAT_DPP, "Error TLV len, type = 0x%02x, left_tlv_length %d less than tlv_len %d\n",
			    *type, left_tlv_len, tlv_len);
			return -1;
		}
		if (*type == DIRECT_ENCAP_DPP_MESSAGE_TYPE) {
			ret = parse_direct_encap_dpp_message_tlv(ctx, value, len, frame_type,
				frame_offset, frame_len, al_mac);
			if (ret < 0) {
				warn(DEBUG_CAT_DPP, "error direct encap dpp message tlv\n");
				return -1;
			}
			integrity |= (1 << 0);

			store_revd_tlvs(ctx, type, (unsigned short)tlv_len);
		} else if (*type == END_OF_TLV_TYPE)
			break;

		type += tlv_len;
		left_tlv_len -= tlv_len;
	}
	/*check integrity*/
	if (integrity != 1) {
		warn(DEBUG_CAT_DPP, "error when check dpp message tlvs\n");
		return -1;
	}

	if (*frame_type == DPP_PA_AUTHENTICATION_REQ) {
		if (ctx->r3_oboard_ctx.bh_type == MAP_BH_ETH) {
			notice(DEBUG_CAT_DPP, "ETH BH,cancel timer of dpp auth req\n");
			eloop_cancel_timeout(r3_wait_for_dpp_auth_req, (void *)ctx, NULL);
		}
	} else if (*frame_type == DPP_PA_PEER_DISCOVERY_REQ ||
			*frame_type == DPP_PA_PEER_DISCOVERY_RESP) {
		map_dpp_handle_public_action_frame(ctx, *frame_type,
			(unsigned char *)(buf + *frame_offset), (size_t)*frame_len, al_mac);
	}
	return 0;
}

int parse_1905_rekey_request_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len)
{
	unsigned char *type = NULL;
	unsigned short len = 0;
	unsigned int tlv_len = 0;
	unsigned int integrity = 0;

	type = buf;
	reset_stored_tlv(ctx);

	while (1) {
		if (left_tlv_len < 3) {
			warn(DEBUG_CAT_DPP, "buf should greater than 3 bytes(1[type]+2[len])\n");
			return -1;
		}
		len = get_tlv_len(type);
		tlv_len = len + 3;
		if (left_tlv_len < tlv_len) {
			warn(DEBUG_CAT_DPP, "Error TLV len, type = 0x%02x, left_tlv_length %d less than tlv_len %d\n",
			    *type, left_tlv_len, tlv_len);
			return -1;
		}
		if (*type != END_OF_TLV_TYPE)
			store_revd_tlvs(ctx, type, (unsigned short)tlv_len);
		else
			break;

		type += tlv_len;
		left_tlv_len -= tlv_len;
	}
	/*check integrity*/
	if (integrity != 0) {
		warn(DEBUG_CAT_DPP, "error when check 1905 rekey request message tlvs\n");
		return -1;
	}
	return 0;
}

int parse_1905_decryption_failure_message(struct p1905_managerd_ctx *ctx,
			unsigned char *buf, unsigned int left_tlv_len, unsigned char *al_mac)
{
	unsigned char *type = NULL;
	unsigned short len = 0;
	unsigned char *value = NULL;
	unsigned int tlv_len = 0;
	int ret = 0;
	unsigned int integrity = 0;
	unsigned char peer_al_mac[ETH_ALEN] = { 0 };
	unsigned char zero_mac[ETH_ALEN] = { 0 };

	type = buf;
	reset_stored_tlv(ctx);

	while (1) {
		if (left_tlv_len < 3) {
			warn(DEBUG_CAT_DPP, "buf should greater than 3 bytes(1[type]+2[len])\n");
			return -1;
		}
		len = get_tlv_len(type);
		value = type + 3;
		tlv_len = len + 3;
		if (tlv_len > left_tlv_len) {
			warn(DEBUG_CAT_DPP, "type = %d, tlv len %d > left_tlv_len %d\n",
				*type, tlv_len, left_tlv_len);
			return -1;
		}

		if (*type == AL_MAC_ADDR_TLV_TYPE) {
			/* only need to parse peer discovery,
			** other pkt pass to mapd directly
			*/
			ret = parse_al_mac_addr_type_tlv(al_mac, len, value);
			if (ret < 0) {
				warn(DEBUG_CAT_DPP, "error al mac tlv\n");
				return -1;
			}
			integrity |= (1 << 0);
			store_revd_tlvs(ctx, type, tlv_len);
		} else if (*type == END_OF_TLV_TYPE)
			break;

		type += tlv_len;
		left_tlv_len -= tlv_len;
	}
	/*check integrity*/
	if (integrity < 1) {
		warn(DEBUG_CAT_DPP, "error when check dpp message tlvs\n");
		return -1;
	}

	if ((integrity&BIT(0)) && (os_memcmp(peer_al_mac, zero_mac, ETH_ALEN)))
		os_memcpy(al_mac, peer_al_mac, ETH_ALEN);

	return 0;
}

int parse_chirp_notification_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len, unsigned char *al_mac)
{
	unsigned char *type = NULL;
	unsigned char *value = NULL;
	unsigned short len = 0;
	unsigned int tlv_len = 0;
	int ret = 0;
	unsigned int integrity = 0;
	struct chirp_tlv_info chirp;

	os_memset(&chirp, 0, sizeof(struct chirp_tlv_info));

	type = buf;
	reset_stored_tlv(ctx);

	notice(DEBUG_CAT_DPP, "chirp notification from "MACSTR"\n", MAC2STR(al_mac));

	while (1) {
		if (left_tlv_len < 3) {
			warn(DEBUG_CAT_DPP, "buf should greater than 3 bytes(1[type]+2[len])\n");
			return -1;
		}
		len = get_tlv_len(type);
		value = type + 3;
		tlv_len = len + 3;
		if (left_tlv_len < tlv_len) {
			warn(DEBUG_CAT_DPP, "Error TLV len, type = 0x%02x, left_tlv_length %d less than tlv_len %d\n",
			    *type, left_tlv_len, tlv_len);
			return -1;
		}
		if (*type == DPP_CHIRP_VALUE_TYPE) {

			ret = parse_dpp_chirp_value_tlv(value, len, &chirp);
			if (ret < 0) {
				warn(DEBUG_CAT_DPP, "error al mac tlv\n");
				return -1;
			}
			integrity |= (1 << 0);
			store_revd_tlvs(ctx, type, (unsigned short)tlv_len);
		} else if (*type == END_OF_TLV_TYPE)
			break;

		type += tlv_len;
		left_tlv_len -= tlv_len;
	}
	/*check integrity*/
	if (integrity != 1) {
		warn(DEBUG_CAT_DPP, "error when check chirp notification tlvs\n");
		return -1;
	}
	return 0;
}

int parse_dpp_bootstrapping_uri_query_message(struct p1905_managerd_ctx *ctx, unsigned char *buf, unsigned char *al_mac)
{
	int length =0;
	unsigned char *temp_buf;
	unsigned int integrity = 0;
	temp_buf = buf;
	reset_stored_tlv(ctx);

	while(1)
	{
		if(*temp_buf == END_OF_TLV_TYPE) {
			break;
		} else {
			length = get_cmdu_tlv_length(temp_buf);
			temp_buf += length;
		}
	}
		/*check integrity*/
	if(integrity != 0) {
		warn(DEBUG_CAT_DPP, "error when check dpp uri query message\n");
		return -1;
	}
	return 0;
}

int parse_1905_bss_configuration_request_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len, unsigned char *al_mac)
{
	unsigned char *type = NULL;
	unsigned short len = 0;
	unsigned char *value = NULL;
	unsigned int tlv_len = 0;
	int ret = 0;
	unsigned char service[4] = {0};
	unsigned char service_cnt = 0;
	unsigned int integrity = 0;
	unsigned char map_version = 0, i = 0;
	struct r3_member *peer = NULL;
	struct agent_list_db *agent_info = NULL;
	struct agent_radio_info rinfo_tmp[MAX_RADIO_NUM];
	unsigned char ra_idx = 0, ra_cnt = 0;
	struct ap_r2_capability r2_cap;
	struct vs_value vs_info[MAX_RADIO_NUM] = {0};
	unsigned char vs_idx = 0, vs_num = 0;
	struct akm_suite_cap bh_akm = {0};
	struct akm_suite_cap fh_akm = {0};
#ifdef MAP_R6
	struct dl_list wifi7_mlo_cap_list;
	struct wifi7_mlo_cap_db *mlo_cap = NULL, *mlo_cap_tmp = NULL;

	dl_list_init(&wifi7_mlo_cap_list);
#endif

	if (ctx->role != CONTROLLER) {
		notice(DEBUG_CAT_DPP, "role not match!!! agent can't handle this frame!!!\n");
		return -1;
	}
	find_agent_info(ctx, al_mac, &agent_info);
	if (!agent_info) {
		info(DEBUG_CAT_DPP, "no agent info exist, insert new one\n");
		agent_info = insert_agent_info(ctx, al_mac);
		if (!agent_info)
			return -1;
	}

	os_memset(&vs_info, 0, sizeof(struct vs_value));
	os_memset(&r2_cap, 0, sizeof(struct ap_r2_capability));
	type = buf;
	reset_stored_tlv(ctx);
	peer = get_r3_member(al_mac);
	if (!peer) {
		notice(DEBUG_CAT_DPP, "agent not found by almac "MACSTR"\n", MAC2STR(al_mac));
		return -1;
	}

	notice(DEBUG_CAT_DPP, "receive BSS Configuration Request message from "MACSTR"\n",
		MAC2STR(al_mac));

	while (1) {
		if (left_tlv_len < 3) {
			warn(DEBUG_CAT_DPP, "buf should greater than 3 bytes(1[type]+2[len])\n");
			goto fail;
		}
		len = get_tlv_len(type);
		value = type + 3;
		tlv_len = len + 3;
		if (left_tlv_len < tlv_len) {
			warn(DEBUG_CAT_DPP, "Error TLV len, type = 0x%02x, left_tlv_length %d less than tlv_len %d\n",
				*type, left_tlv_len, tlv_len);
			goto fail;
		}

		if (*type == MULTI_AP_VERSION_TYPE) {
#ifdef EM_PLUS_EXT_SUPPORT
			if (!ctx->security_enabled && ctx->map_version == MAP_PROFILE_R2)
				map_version = MAP_PROFILE_R3;
			else
#endif
				parse_map_version_tlv(type, &map_version);

			integrity |= (1 << 0);
		} else if (*type == SUPPORTED_SERVICE_TLV_TYPE) {
			ret = parse_supported_service_tlv(service, len, value, &service_cnt);
			if (ret < 0) {
				warn(DEBUG_CAT_DPP, "error supported service tlv\n");
				goto fail;
			}
			integrity |= (1 << 1);
		} else if (*type == AKM_SUITE_CAPABILITY_TYPE) {
			ret = parse_akm_suit_capability_tlv(value, len, &bh_akm, &fh_akm);
			if (ret < 0) {
				warn(DEBUG_CAT_DPP, "error akm suite cap tlv\n");
				goto fail;
			}
			integrity |= (1 << 2);
		} else if (*type == AP_RADIO_BASIC_CAPABILITY_TYPE) {
			ra_cnt += 1;
			if (ra_cnt > MAX_RADIO_NUM) {
				err(DEBUG_CAT_MSG, "radio_cnt(%d) > MAX_RADIO_NUM(%d)"
					" in ap radio basic cap tlv\n", ra_cnt, MAX_RADIO_NUM);
				goto fail;
			}
			os_memset(&rinfo_tmp[ra_cnt - 1], 0, sizeof(struct agent_radio_info));
			ret = parse_ap_radio_basic_cap_tlv(ctx, &rinfo_tmp[ra_cnt - 1], len, value);
			if (ret < 0) {
				warn(DEBUG_CAT_DPP, "error ap radio basic cap tlv\n");
				goto fail;
			}
			integrity |= (1 << 3);
		}
		/* One Profile-2 AP Capability TLV */
		else if (*type == R2_AP_CAPABILITY_TYPE) {
			os_memset(&r2_cap, 0, sizeof(struct ap_r2_capability));
			ret = parse_r2_ap_capability_tlv(&r2_cap, al_mac, len, value);
			if (ret < 0) {
				warn(DEBUG_CAT_DPP, "error, r2 ap capability tlv\n");
				goto fail;
			}

			integrity |= (1 << 4);
			store_revd_tlvs(ctx, type, tlv_len);
		}
		/* One or more AP Radio Advanced Capabilities TLV  */
		else if (*type == AP_RADIO_ADVANCED_CAPABILITIES_TYPE) {
			integrity |= (1 << 5);
			store_revd_tlvs(ctx, type, tlv_len);
		}
		/* One or more BSS Configuration Request TLV */
		else if (*type == BSS_CONFIG_REQUEST_TYPE) {
			ret = parse_bss_configuration_request_tlv(ctx, value, len);
			if (ret < 0) {
				warn(DEBUG_CAT_DPP, "error bss configuration request tlv\n");
				goto fail;
			}
			integrity |= (1 << 6);
		}
		/* Zero or more Backhaul STA Radio Capabilities TLV */
		else if (*type == BACKHAUL_STA_RADIA_CAPABILITY_TYPE) {
			ret = parse_bh_sta_radio_cap_tlv(value, len);
			if (ret < 0) {
				warn(DEBUG_CAT_DPP, "error bh sta radio cap tlv\n");
				goto fail;
			}
			integrity |= (1 << 7);
		} else if (*type == VENDOR_SPECIFIC_TLV_TYPE) {
			os_memset(&vs_info[vs_num], 0, sizeof(struct vs_value));
			parse_vs_tlv(&vs_info[vs_num], len, value);

			vs_num += 1;
		}
#ifdef MAP_R6
		else if (*type == WIFI7_AGENT_CAPABILITY_TLV_TYPE) {
			integrity |= (1 << 8);
			ret = parse_wifi7_cap_tlv(ctx, al_mac, &wifi7_mlo_cap_list, value, len);
			if (ret < 0) {
				warn(DEBUG_CAT_MLO, "error parse wifi7 capability tlv\n");
				goto fail;
			}
			store_revd_tlvs(ctx, type, tlv_len);
		}
#endif
		else if (*type == END_OF_TLV_TYPE)
			break;

		type += tlv_len;
		left_tlv_len -= tlv_len;
	}
	/*check integrity*/
	if(integrity < 0x3F) {
		warn(DEBUG_CAT_DPP, "error when check bss configuration request msg\n");
		goto fail;
	}

	if (integrity & BIT(0)) {
		peer->profile = map_version;
		if (peer->security_1905 && (peer->profile < MAP_PROFILE_R3)) {
			notice(DEBUG_CAT_DPP, "disable security_1905 for " MACSTR "\n", MAC2STR(al_mac));
			peer->security_1905 = 0;
		}
	}

	if (integrity & BIT(2)) {
		map_notify_akm_suit_cap(ctx, al_mac, type, tlv_len);
		peer->bh_akm.akm_suite_cnt = bh_akm.akm_suite_cnt;
		if (peer->bh_akm.akm_suite_info)
			os_free(peer->bh_akm.akm_suite_info);
		peer->bh_akm.akm_suite_info = bh_akm.akm_suite_info;
		peer->fh_akm.akm_suite_cnt = fh_akm.akm_suite_cnt;
		if (peer->fh_akm.akm_suite_info)
			os_free(peer->fh_akm.akm_suite_info);
		peer->fh_akm.akm_suite_info = fh_akm.akm_suite_info;
	}

	if (integrity & BIT(3)) {
		for (ra_idx = 0; ra_idx < ra_cnt && ra_idx < MAX_RADIO_NUM; ra_idx++) {
			debug(DEBUG_CAT_MLO, "update radio idx %d ruid "MACSTR"\n", ra_idx, MAC2STR(rinfo_tmp[ra_idx].identifier));
			update_agent_radio_info(agent_info, &rinfo_tmp[ra_idx]);
		}
	}

	if (integrity & BIT(4))
		os_memcpy(&agent_info->r2_cap, &r2_cap, sizeof(struct ap_r2_capability));

	for (vs_idx = 0; vs_idx < vs_num; vs_idx++) {
		if (!vs_info[vs_idx].mlo_cap_valid)
			continue;
		for (i = 0; i < ra_cnt && i < MAX_RADIO_NUM; i++) {
			if (os_memcmp(agent_info->ra_info[i].identifier,
				vs_info[vs_idx].mlo_data.mlo_cap.identifier, ETH_ALEN))
				continue;
			agent_info->ap_mlo_cap[i] = vs_info[vs_idx].mlo_data.mlo_cap.ap_mlo_cap;
			agent_info->sta_mlo_cap[i] = vs_info[vs_idx].mlo_data.mlo_cap.sta_mlo_cap;

			notice(DEBUG_CAT_MLO, "almac "MACSTR" (PRE R6), ruid "MACSTR", ap mlo %d(%s), sta mlo %d(%s)\n",
					MAC2STR(al_mac), MAC2STR(agent_info->ra_info[i].identifier),
					agent_info->ap_mlo_cap[i], (agent_info->ap_mlo_cap[i] == 1) ? "enable" : "disable",
					agent_info->sta_mlo_cap[i], (agent_info->sta_mlo_cap[i] == 1) ? "enable" : "disable");
			break;
		}
	}

#ifdef MAP_R6
	if (integrity & BIT(8)) {
		info(DEBUG_CAT_MLO, "\n");
		update_agent_wifi7_mlo_cap(agent_info, &wifi7_mlo_cap_list);

		dl_list_for_each_safe(mlo_cap, mlo_cap_tmp, &wifi7_mlo_cap_list,
			struct wifi7_mlo_cap_db, list) {
			dl_list_del(&mlo_cap->list);
			os_free(mlo_cap);
		}
	}
#endif
	return 0;

fail:
	if (bh_akm.akm_suite_info)
		os_free(bh_akm.akm_suite_info);
	if (fh_akm.akm_suite_info)
		os_free(fh_akm.akm_suite_info);
#ifdef MAP_R6
	dl_list_for_each_safe(mlo_cap, mlo_cap_tmp, &wifi7_mlo_cap_list,
		struct wifi7_mlo_cap_db, list) {
		dl_list_del(&mlo_cap->list);
		os_free(mlo_cap);
	}
#endif
	return -1;
}

int parse_bss_configuration_response_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len, unsigned char *al_mac)
{
	unsigned char *type = NULL;
	unsigned short len = 0;
	unsigned char *value = NULL, i = 0;
	unsigned int tlv_len = 0;
	int ret = 0;
	unsigned int integrity = 0;
	struct def_8021q_setting setting;
	struct traffics_policy tpolicy;
	struct traffic_separation_db *tpolicy_db = NULL;
	struct traffic_separation_db *tpolicy_db_nxt = NULL;
	struct vs_value vs_info;

	struct mld_bss_config_db mld_bss = {0};
#ifdef MAP_R6
	struct mld_bsta_config_db mld_bsta = {0};

	dl_list_init(&mld_bsta.affiliated_sta_list);
#endif
	dl_list_init(&mld_bss.mlo_cfg_list);
	os_memset(&setting, 0, sizeof(struct def_8021q_setting));
	os_memset(&tpolicy, 0, sizeof(struct traffics_policy));
	os_memset(&r3_ctx_tmp, 0, sizeof(struct r3_onboarding_info));
	os_memset(&vs_info, 0, sizeof(struct vs_value));

	SLIST_INIT(&tpolicy.policy_head);

	type = buf;
	reset_stored_tlv(ctx);
	ctx->r3_oboard_ctx.total_config_num = 0;
	while(1) {
		if (left_tlv_len < 3) {
			warn(DEBUG_CAT_DPP, "buf should greater than 3 bytes(1[type]+2[len])\n");
			goto fail;
		}
		len = get_tlv_len(type);
		if ((len + 3) > left_tlv_len) {
			warn(DEBUG_CAT_DPP, "tlv len > left_tlv_len\n");
			goto fail;
		}
		value = type + 3;
		tlv_len = len + 3;
		if (*type == BSS_CONFIG_RESPONSE_TYPE) {
			/* only need to parse peer discovery,
			** other pkt pass to mapd directly
			*/
			notice(DEBUG_CAT_DPP, "\n");
			ret = parse_bss_configuration_response_tlv(value, len, &r3_ctx_tmp);
			if (ret < 0) {
				warn(DEBUG_CAT_DPP, "error bss configuration response tlv\n");
				goto fail;
			}
			integrity |= (1 << 0);
		} else if (*type == DEFAULT_8021Q_SETTING_TYPE) {
			ret = parse_default_802_1q_setting_tlv(&setting, len, value);
			if (ret < 0) {
				warn(DEBUG_CAT_DPP, "error default 802_1q setting tlv\n");
				goto fail;
			}
			integrity |= (1 << 1);
			setting.updated = 1;
		} else if (*type == TRAFFIC_SEPARATION_POLICY_TYPE) {
			ret = parse_traffic_separation_policy_tlv(&tpolicy, len, value);
			if (ret < 0) {
				warn(DEBUG_CAT_DPP, "%s error trffic separation policy tlv\n", __func__);
				goto fail;
			}
			integrity |= (1 << 2);
			tpolicy.updated = 1;
		} else if (*type == VENDOR_SPECIFIC_TLV_TYPE) {
			parse_vs_tlv(&vs_info, len, value);
		} else if (*type == AGENT_AP_MLD_CONFIG_TLV_TYPE) {
			integrity |= (1 << 3);
			ret = parse_agent_ap_mld_config_tlv(&mld_bss, al_mac, value, len);
			if (ret < 0) {
				warn(DEBUG_CAT_DPP, "error agent ap mld bss config tlv\n");
				goto fail;
			}
		}
#ifdef MAP_R6
		else if (*type == BSTA_MLD_CONFIG_TLV_TYPE) {
			ret = parse_bsta_mld_config_tlv(&mld_bsta, value, len);
			if (ret < 0) {
				err(DEBUG_CAT_MLO, "error bsta mld config tlv\n");
				goto fail;
			}
			if (mld_bsta.num_affiliated_sta > 0)
				integrity |= (1 << 4);
		}
#endif
		else if (*type == END_OF_TLV_TYPE)
			break;

		type += tlv_len;
		left_tlv_len -= tlv_len;
	}
		/*check integrity*/
	if(integrity < 0x01) {
		warn(DEBUG_CAT_DPP, "error when check dpp message tlvs\n");
		goto fail;
	}

	if (integrity & BIT(0)) {
		os_memset(ctx->r3_oboard_ctx.bss_config_data, 0,
			MAX_SET_BSS_INFO_NUM*sizeof(struct r3_config_data));
		ctx->r3_oboard_ctx.total_config_num = r3_ctx_tmp.total_config_num;
		os_memcpy(&ctx->r3_oboard_ctx.bss_config_data, &r3_ctx_tmp.bss_config_data,
			r3_ctx_tmp.total_config_num * sizeof(struct r3_config_data));
	}

	if (integrity & BIT(1)) {
		unsigned char updated = 0;

		if ((ctx->map_policy.setting.primary_vid != setting.primary_vid) ||
			(ctx->map_policy.setting.dft.PCP != setting.dft.PCP)) {
			updated = 1;
			notice(DEBUG_CAT_TS, "pvid setting changed by 802.1q tlv, pvid(%d->%d), pcp(%d->%d)\n",
				ctx->map_policy.setting.primary_vid, setting.primary_vid,
				ctx->map_policy.setting.dft.PCP, setting.dft.PCP);
		}
		os_memcpy(&ctx->map_policy.setting, &setting, sizeof(struct def_8021q_setting));
		ctx->map_policy.setting.updated = updated;
	}

	if (integrity & BIT(2)) {
		unsigned char updated = 0;

		updated = check_traffic_policy_config_updated(ctx, &ctx->map_policy.tpolicy, &tpolicy);
		/*delete the previously reserved traffic policy*/
		delete_exist_traffic_policy(ctx, &ctx->map_policy.tpolicy);

		ctx->map_policy.tpolicy.SSID_num = tpolicy.SSID_num;
		ctx->map_policy.tpolicy.updated = updated;

		tpolicy_db = SLIST_FIRST(&(tpolicy.policy_head));
		while (tpolicy_db) {
			tpolicy_db_nxt = SLIST_NEXT(tpolicy_db, policy_entry);
			SLIST_REMOVE(&(tpolicy.policy_head), tpolicy_db,
						traffic_separation_db, policy_entry);

			SLIST_INSERT_HEAD(&ctx->map_policy.tpolicy.policy_head, tpolicy_db, policy_entry);
			tpolicy_db = tpolicy_db_nxt;
		}
	}

	if (integrity & BIT(3)) {
		notice(DEBUG_CAT_MLO, "agent ap mld config present\n");

		for (i = 0; i < r3_ctx_tmp.total_config_num; i++)
			ctx->r3_oboard_ctx.bss_config_data[i].config_data.mlo_bss_present = 1;

		delete_ap_mld_conf(&ctx->mld_bss);
		update_ap_mld_conf(&ctx->mld_bss, &mld_bss);
		delete_ap_mld_conf(&ctx->opcls_mld_cfg);
		ctx->ap_mld_cfg = 1;
	}
#ifdef MAP_R6

	if (integrity & BIT(4)) {
		notice(DEBUG_CAT_MLO, "bsta mld config present\n");
		delete_bsta_mld_conf(&ctx->mld_bsta);
		update_bsta_mld_conf(&ctx->mld_bsta, &mld_bsta);
		ctx->bsta_mld_cfg = 1;
	}

#endif


	return 0;

fail:
	tpolicy_db = SLIST_FIRST(&(tpolicy.policy_head));
	while (tpolicy_db) {
		tpolicy_db_nxt = SLIST_NEXT(tpolicy_db, policy_entry);
		SLIST_REMOVE(&(tpolicy.policy_head), tpolicy_db,
					traffic_separation_db, policy_entry);
		os_free(tpolicy_db);
		tpolicy_db = tpolicy_db_nxt;
	}

	delete_ap_mld_conf(&mld_bss);
#ifdef MAP_R6
	delete_bsta_mld_conf(&mld_bsta);
#endif
	return -1;
}

int parse_agent_list_message(unsigned char *buf, unsigned int left_tlv_len)
{
	unsigned char *type = NULL;
	unsigned short len = 0;
	unsigned char *value = NULL;
	unsigned int tlv_len = 0;
	int ret = 0;
	unsigned int integrity = 0;
	unsigned char i = 0, agent_cnt = 0;
	struct r3_member peers[10];
	struct r3_member *peer = NULL;

	os_memset(peers, 0, sizeof(peers));

	type = buf;
	while (1) {
		if (left_tlv_len < 3) {
			warn(DEBUG_CAT_DPP, "buf should greater than 3 bytes(1[type]+2[len])\n");
			return -1;
		}
		len = get_tlv_len(type);
		value = type + 3;
		tlv_len = len + 3;
		if (left_tlv_len < tlv_len) {
			warn(DEBUG_CAT_DPP, "Error TLV len, type = 0x%02x, left_tlv_length %d less than tlv_len %d\n",
				*type, left_tlv_len, tlv_len);
			return -1;
		}
		if (*type == AGENT_LIST_TLV_TYPE) {
			ret = parse_agent_list_tlv(value, len, &agent_cnt, peers);
			if (ret < 0) {
				warn(DEBUG_CAT_DPP, "error al mac tlv\n");
				return -1;
			}
			integrity |= (1 << 0);
		} else if (*type == END_OF_TLV_TYPE)
			break;

		type += tlv_len;
		left_tlv_len -= tlv_len;
	}
		/*check integrity*/
	if (integrity < 0x01) {
		warn(DEBUG_CAT_DPP, "error when check agent list message tlvs\n");
		return -1;
	}

	for (i = 0; i < agent_cnt; i++) {
		peer = create_r3_member(peers[i].al_mac);
		if (!peer)
			continue;

		peer->profile = peers[i].profile;
		info(DEBUG_CAT_DPP, "peer "MACSTR" profile %d, 1905 security %d(%s)\n",
			MAC2STR(peer->al_mac), peer->profile, peer->security_1905,
			(peer->security_1905 == 1)?"enable":"disable");
	}
	return 0;
}
#endif

#ifdef MAP_R6
int parse_early_apcap_report_message(struct p1905_managerd_ctx *ctx,
			unsigned char *buf, unsigned int left_tlv_len, unsigned char *al_mac)
{
	unsigned char *type = NULL;
	unsigned short len = 0;
	unsigned char *value = NULL;
	unsigned int tlv_len = 0;
	int ret = 0;
	unsigned int integrity = 0;
	struct ts_cap_db *ts_cap = NULL;
	struct wifi7_mlo_cap_db *mlo_cap = NULL, *mlo_cap_tmp = NULL;
	struct dl_list wifi7_mlo_cap_list;
	struct agent_list_db *agent_info = NULL;
	struct agent_radio_info rinfo_tmp[MAX_RADIO_NUM] = {0};
	unsigned char ra_cnt = 0, ra_idx = 0;
	struct akm_suite_cap bh_akm = {0};
	struct akm_suite_cap fh_akm = {0};
	struct r3_member *peer = NULL;
	struct ap_r2_capability r2_cap = {0};
	unsigned char ap_cap = {0};

	notice(DEBUG_CAT_MLO, "early ap capability report msg from "MACSTR"\n",
		MAC2STR(al_mac));

	type = buf;
	reset_stored_tlv(ctx);
	dl_list_init(&wifi7_mlo_cap_list);

	while (1) {
		if (left_tlv_len < 3) {
			err(DEBUG_CAT_MLO, "buf should greater than 3 bytes(1[type]+2[len])\n");
			goto fail;
		}
		len = get_tlv_len(type);
		value = type + 3;
		tlv_len = len + 3;
		if (tlv_len > left_tlv_len) {
			notice(DEBUG_CAT_MLO, "type = %d, tlv len %d > left_tlv_len %d\n",
				*type, tlv_len, left_tlv_len);
			goto fail;
		}

		if (*type == AP_CAPABILITY_TYPE) {
			/* only need to parse peer discovery,
			** other pkt pass to mapd directly
			*/
			ret = parse_ap_capability_tlv(ctx, len, value, &ap_cap);
			if (ret < 0) {
				err(DEBUG_CAT_MLO, "error ap cap tlv\n");
				goto fail;
			}
			integrity |= (1 << 0);
			store_revd_tlvs(ctx, type, tlv_len);
		} else if (*type == AP_RADIO_BASIC_CAPABILITY_TYPE) {
			ra_cnt += 1;
			if (ra_cnt > MAX_RADIO_NUM) {
				err(DEBUG_CAT_MSG, "radio_cnt(%d) > MAX_RADIO_NUM(%d)"
					" in ap radio basic cap tlv\n", ra_cnt, MAX_RADIO_NUM);
				goto fail;
			}
			integrity |= (1 << 1);
			os_memset(&rinfo_tmp[ra_cnt - 1], 0, sizeof(struct agent_radio_info));

			ret = parse_ap_radio_basic_cap_tlv(ctx, &rinfo_tmp[ra_cnt - 1], len, value);
			if (ret < 0) {
				err(DEBUG_CAT_MLO, "error ap radio basic cap tlv\n");
				goto fail;
			}
		}
		/* Zero or more AP HT Capabilities TLV */
		else if (*type == AP_HT_CAPABILITY_TYPE) {
			ret = parse_ap_ht_capability_tlv(ctx, len, value);
			if (ret < 0) {
				err(DEBUG_CAT_MLO, "error ap ht capability tlv\n");
				goto fail;
			}
			integrity |= (1 << 2);
			store_revd_tlvs(ctx, type, tlv_len);
		}
		/* Zero or more AP VHT Capabilities TLV */
		else if (*type == AP_VHT_CAPABILITY_TYPE) {
			ret = parse_ap_vht_capability_tlv(ctx, len, value);
			if (ret < 0) {
				err(DEBUG_CAT_MLO, "error ap vht capability tlv\n");
				goto fail;
			}

			integrity |= (1 << 3);
			store_revd_tlvs(ctx, type, tlv_len);
		}
		/* Zero or more AP HE Capabilities TLV */
		else if (*type == AP_HE_CAPABILITY_TYPE) {
			integrity |= (1 << 4);
			store_revd_tlvs(ctx, type, tlv_len);
		}
		/* wifi6 capability */
		else if (*type == 0xAA) {
			integrity |= (1 << 5);
			ret = parse_ap_wf6_capability_tlv(ctx, type);
			if (ret < 0) {
				err(DEBUG_CAT_MLO, "error ap wf6 capability tlv\n");
				goto fail;
			}
			store_revd_tlvs(ctx, type, tlv_len);
		}
		/* ap radio advanced capability */
		else if (*type == AP_RADIO_ADVANCED_CAPABILITIES_TYPE) {

			integrity |= (1 << 6);
			ret = parse_ap_radio_advanced_capability_tlv(ctx, al_mac, &ts_cap, len, value);
			if (ret < 0) {
				err(DEBUG_CAT_MLO, "error ap radio advanced capability tlv\n");
				goto fail;
			}
		}
		/* wifi7 capability */
		else if (*type == WIFI7_AGENT_CAPABILITY_TLV_TYPE) {
			ret = parse_wifi7_cap_tlv(ctx, al_mac, &wifi7_mlo_cap_list, value, len);
			if (ret < 0) {
				err(DEBUG_CAT_MLO, "error parse wifi7 capability tlv\n");
				goto fail;
			}
			integrity |= (1 << 7);
			store_revd_tlvs(ctx, type, tlv_len);
		}
		/* akm capability */
		else if (*type == AKM_SUITE_CAPABILITY_TYPE) {
			ret = parse_akm_suit_capability_tlv(value, len, &bh_akm, &fh_akm);
			if (ret < 0) {
				err(DEBUG_CAT_MLO, "error parse wifi7 capability tlv\n");
				goto fail;
			}
			integrity |= (1 << 8);
			store_revd_tlvs(ctx, type, tlv_len);
		}
		/* eht operation tlv */
		else if (*type == EHT_OPERATION_TLV_TYPE) {
			integrity |= (1 << 9);
			store_revd_tlvs(ctx, type, tlv_len);
		}
		/* 1905 Layer Security Capability */
		else if (*type == _1905_LAYER_SECURITY_CAPABILITY_TYPE) {
			integrity |= (1 << 10);
			store_revd_tlvs(ctx, type, tlv_len);
		}
		/* CAC Capabilities */
		else if (*type == CAC_CAPABILITIES_TYPE) {
			integrity |= (1 << 11);
			store_revd_tlvs(ctx, type, tlv_len);
		}
		/* Profile-2 AP Capability */
		else if (*type == R2_AP_CAPABILITY_TYPE) {
			integrity |= (1 << 12);
			parse_r2_ap_capability_tlv(&r2_cap, al_mac, len, value);
			store_revd_tlvs(ctx, type, tlv_len);
		}
		/* Metric Collection Interval */
		else if (*type == METRIC_COLLECTION_INTERVAL_TYPE) {
			integrity |= (1 << 13);
			store_revd_tlvs(ctx, type, tlv_len);
		}
		/* Device Inventory */
		else if (*type == R3_DE_INVENTORY_TLV_TYPE) {
			integrity |= (1 << 14);
			store_revd_tlvs(ctx, type, tlv_len);
		}
		/* end of tlv */
		else if (*type == END_OF_TLV_TYPE)
			break;

		type += tlv_len;
		left_tlv_len -= tlv_len;
	}
	/*check integrity*/
	if (integrity < 1) {
		err(DEBUG_CAT_MLO, "error when check early ap cap report message tlvs\n");
		goto fail;
	}

	find_agent_info(ctx, al_mac, &agent_info);
	if (!agent_info)
		goto fail;

	if ((integrity & BIT(0)) && (ap_cap & BIT(4)))
		agent_info->bsta_wsc_reconfig = 1;

	if (integrity & BIT(1)) {
		for (ra_idx = 0; ra_idx < ra_cnt && ra_cnt < MAX_RADIO_NUM; ra_idx++) {
			info(DEBUG_CAT_MLO, "update ap basic radio for ruid "MACSTR"\n",
				MAC2STR(rinfo_tmp[ra_idx].identifier));
			update_agent_radio_info(agent_info, &rinfo_tmp[ra_idx]);
		}
	}

	if ((integrity & BIT(6)) && ts_cap)
		map_r2_notify_ts_cap(ctx, al_mac, ts_cap);

	if (integrity & BIT(7)) {
		info(DEBUG_CAT_MLO, "update agent wifi7 mlo cap for "MACSTR"\n", MAC2STR(al_mac));
		update_agent_wifi7_mlo_cap(agent_info, &wifi7_mlo_cap_list);

		dl_list_for_each_safe(mlo_cap, mlo_cap_tmp, &wifi7_mlo_cap_list,
				struct wifi7_mlo_cap_db, list) {
			dl_list_del(&mlo_cap->list);
			os_free(mlo_cap);
		}
		dl_list_init(&wifi7_mlo_cap_list);
	}

	if (integrity & BIT(8)) {
		peer = get_r3_member(al_mac);
		if (!peer)
			goto fail;

		if (peer->bh_akm.akm_suite_info) {
			os_free(peer->bh_akm.akm_suite_info);
		}
		peer->bh_akm.akm_suite_cnt = bh_akm.akm_suite_cnt;
		peer->bh_akm.akm_suite_info = bh_akm.akm_suite_info;

		if (peer->fh_akm.akm_suite_info) {
			os_free(peer->fh_akm.akm_suite_info);
		}
		peer->fh_akm.akm_suite_cnt = fh_akm.akm_suite_cnt;
		peer->fh_akm.akm_suite_info = fh_akm.akm_suite_info;
	} else {
		if (bh_akm.akm_suite_info)
			os_free(bh_akm.akm_suite_info);

		if (fh_akm.akm_suite_info)
			os_free(fh_akm.akm_suite_info);
	}

	if (integrity & BIT(12))
		os_memcpy(&agent_info->r2_cap, &r2_cap, sizeof(struct ap_r2_capability));

	return 0;

fail:
	dl_list_for_each_safe(mlo_cap, mlo_cap_tmp, &wifi7_mlo_cap_list,
		struct wifi7_mlo_cap_db, list) {
		dl_list_del(&mlo_cap->list);
		os_free(mlo_cap);
	}
	if (bh_akm.akm_suite_info)
		os_free(bh_akm.akm_suite_info);

	if (fh_akm.akm_suite_info)
		os_free(fh_akm.akm_suite_info);

	return -1;
}

int parse_ap_mld_request_message(struct p1905_managerd_ctx *ctx,
			unsigned char *buf, unsigned int left_tlv_len, unsigned char *al_mac)
{
	unsigned char *type = NULL;
	unsigned short len = 0;
	unsigned char *value = NULL;
	unsigned int tlv_len = 0;
	int ret = 0;
	unsigned int integrity = 0;
	unsigned char i = 0;
	struct mld_bss_config_db mld_bss = {0};
	struct eht_operations_db eht_op[MAX_RADIO_NUM] = {0};
	struct eht_operations_info_db *eht_db = NULL, *eht_db_tmp = NULL;

	dl_list_init(&mld_bss.mlo_cfg_list);
	for (i = 0; i < MAX_RADIO_NUM; i++)
		dl_list_init(&eht_op[i].eht_op_list);

	type = buf;
	reset_stored_tlv(ctx);

	while (1) {
		if (left_tlv_len < 3) {
			err(DEBUG_CAT_MLO, "buf should greater than 3 bytes(1[type]+2[len])\n");
			goto fail;
		}
		len = get_tlv_len(type);
		value = type + 3;
		tlv_len = len + 3;
		if (tlv_len > left_tlv_len) {
			err(DEBUG_CAT_MLO, "type = %d, tlv len %d > left_tlv_len %d\n",
				*type, tlv_len, left_tlv_len);
			goto fail;
		}

		if (*type == AGENT_AP_MLD_CONFIG_TLV_TYPE) {
			ret = parse_agent_ap_mld_config_tlv(&mld_bss, al_mac, value, len);
			if (ret < 0) {
				err(DEBUG_CAT_MLO, "error agent ap mld config tlv\n");
				goto fail;
			}
			integrity |= (1 << 0);
		} else if (*type == EHT_OPERATION_TLV_TYPE) {
			integrity |= (1 << 1);

			ret = parse_eht_operations_tlv(eht_op, value, len);
			if (ret < 0) {
				err(DEBUG_CAT_MLO, "error eht operation tlv\n");
				goto fail;
			}
		}
		/* end of tlv */
		else if (*type == END_OF_TLV_TYPE)
			break;

		type += tlv_len;
		left_tlv_len -= tlv_len;
	}
	/*check integrity*/
	if (integrity < 1) {
		err(DEBUG_CAT_MLO, "error when check ap mld request message\n");
		goto fail;
	}


	if (integrity & BIT(0)) {
		notice(DEBUG_CAT_MLO, "ap mld config present\n");
		delete_ap_mld_conf(&ctx->mld_bss);
		update_ap_mld_conf(&ctx->mld_bss, &mld_bss);
		delete_ap_mld_conf(&ctx->opcls_mld_cfg);

		_1905_notify_ap_mld_config(ctx, &ctx->mld_bss, 1);
		ctx->ap_mld_cfg = 0;
	}

	if (integrity & BIT(1)) {
		notice(DEBUG_CAT_MLO, "eth operations present\n");
		ctx->eht_op_cfg = 1;
		delete_eht_operations(ctx->eht_op);

		for (i = 0; i < MAX_RADIO_NUM; i++) {
			dl_list_for_each_safe(eht_db, eht_db_tmp, &eht_op[i].eht_op_list,
				struct eht_operations_info_db, list) {
				dl_list_del(&eht_db->list);
				os_memcpy(ctx->eht_op[i].ruid,
					eht_op[i].ruid, ETH_ALEN);
				dl_list_add_tail(&ctx->eht_op[i].eht_op_list, &eht_db->list);
			}
		}
	}

	return 0;

fail:
	delete_ap_mld_conf(&mld_bss);
	delete_eht_operations(eht_op);

	return -1;
}

int parse_ap_mld_response_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned int left_tlv_len, unsigned char *al_mac)
{
	unsigned char *type = NULL;
	unsigned short len = 0;
	unsigned char *value = NULL;
	unsigned int tlv_len = 0;
	int ret = 0;
	unsigned int integrity = 0;
	struct mld_bss_config_db mld_bss = {0};
	struct agent_list_db *agent = NULL;
	struct eht_operations_db eht_op[MAX_RADIO_NUM] = {0};
	int i = 0;

	find_agent_info(ctx, al_mac, &agent);
	if (!agent)
		return -1;

	dl_list_init(&mld_bss.mlo_cfg_list);
	for (i = 0; i < MAX_RADIO_NUM; i++)
		dl_list_init(&eht_op[i].eht_op_list);

	type = buf;
	reset_stored_tlv(ctx);

	while (1) {
		if (left_tlv_len < 3) {
			err(DEBUG_CAT_MLO, "buf should greater than 3 bytes(1[type]+2[len])\n");
			goto fail;
		}
		len = get_tlv_len(type);
		value = type + 3;
		tlv_len = len + 3;
		if (tlv_len > left_tlv_len) {
			err(DEBUG_CAT_MLO, "type = %d, tlv len %d > left_tlv_len %d\n",
				*type, tlv_len, left_tlv_len);
			goto fail;
		}

		if (*type == AGENT_AP_MLD_CONFIG_TLV_TYPE) {
			ret = parse_agent_ap_mld_config_tlv(&mld_bss, al_mac, value, len);
			if (ret < 0) {
				err(DEBUG_CAT_MLO, "error agent ap mld config tlv\n");
				goto fail;
			}
			integrity |= (1 << 0);
		} else if (*type == EHT_OPERATION_TLV_TYPE) {
			integrity |= (1 << 1);

			ret = parse_eht_operations_tlv(eht_op, value, len);
			if (ret < 0) {
				err(DEBUG_CAT_MLO, "error eht operation tlv\n");
				goto fail;
			}
		}
		/* end of tlv */
		else if (*type == END_OF_TLV_TYPE)
			break;

		type += tlv_len;
		left_tlv_len -= tlv_len;
	}
	/*check integrity*/
	if (integrity < 1) {
		err(DEBUG_CAT_MLO, "error when check ap mld response message\n");
		goto fail;
	}


	if (integrity & BIT(0)) {
		update_ap_mld_conf(&agent->mld_cfg, &mld_bss);
		notice(DEBUG_CAT_MLO, "dump ap mld for almac "MACSTR"\n", MAC2STR(al_mac));
		notice_dump_agent_ap_mld(&agent->mld_cfg);
	}

	if (integrity & BIT(1))
		delete_eht_operations(eht_op);

	return 0;

fail:
	delete_ap_mld_conf(&mld_bss);
	delete_eht_operations(eht_op);
	return -1;
}

int parse_bsta_mld_request_message(struct p1905_managerd_ctx *ctx,
			unsigned char *buf, unsigned int left_tlv_len, unsigned char *al_mac)
{
	unsigned char *type = NULL;
	unsigned short len = 0;
	unsigned char *value = NULL;
	unsigned int tlv_len = 0;
	int ret = 0;
	unsigned int integrity = 0;
	struct mld_bsta_config_db mld_bsta = {0};

	dl_list_init(&mld_bsta.affiliated_sta_list);

	type = buf;
	reset_stored_tlv(ctx);

	while (1) {
		if (left_tlv_len < 3) {
			err(DEBUG_CAT_MLO, "buf should greater than 3 bytes(1[type]+2[len])\n");
			goto fail;
		}
		len = get_tlv_len(type);
		value = type + 3;
		tlv_len = len + 3;
		if (tlv_len > left_tlv_len) {
			err(DEBUG_CAT_MLO, "type = %d, tlv len %d > left_tlv_len %d\n",
				*type, tlv_len, left_tlv_len);
			goto fail;
		}

		if (*type == BSTA_MLD_CONFIG_TLV_TYPE) {
			ret = parse_bsta_mld_config_tlv(&mld_bsta, value, len);
			if (ret < 0) {
				err(DEBUG_CAT_MLO, "error bsta mld config tlv\n");
				goto fail;
			}
			if (mld_bsta.num_affiliated_sta > 0)
				integrity |= (1 << 0);
		} else if (*type == END_OF_TLV_TYPE)
			break;

		type += tlv_len;
		left_tlv_len -= tlv_len;
	}
	/*check integrity*/
	if (integrity < 1) {
		err(DEBUG_CAT_MLO, "error when check bsta mld request message\n");
		goto fail;
	}


	if (integrity & BIT(0)) {
		delete_bsta_mld_conf(&ctx->mld_bsta);
		update_bsta_mld_conf(&ctx->mld_bsta, &mld_bsta);

		notice(DEBUG_CAT_MLO, "notify bsta mld\n");
		_1905_notify_bsta_mld_config(ctx, &ctx->mld_bsta);
		ctx->bsta_mld_cfg = 0;
	}

	return 0;

fail:
	delete_bsta_mld_conf(&mld_bsta);
	return -1;
}

int parse_bsta_mld_response_message(struct p1905_managerd_ctx *ctx,
			unsigned char *buf, unsigned int left_tlv_len, unsigned char *al_mac)
{
	unsigned char *type = NULL;
	unsigned short len = 0;
	unsigned char *value = NULL;
	unsigned int tlv_len = 0;
	int ret = 0;
	unsigned int integrity = 0;
	struct mld_bsta_config_db mld_bsta = {0};

	dl_list_init(&mld_bsta.affiliated_sta_list);

	type = buf;
	reset_stored_tlv(ctx);

	while (1) {
		if (left_tlv_len < 3) {
			err(DEBUG_CAT_MLO, "buf should greater than 3 bytes(1[type]+2[len])\n");
			goto fail;
		}
		len = get_tlv_len(type);
		value = type + 3;
		tlv_len = len + 3;
		if (tlv_len > left_tlv_len) {
			err(DEBUG_CAT_MLO, "type = %d, tlv len %d > left_tlv_len %d\n",
				*type, tlv_len, left_tlv_len);
			goto fail;
		}

		if (*type == BSTA_MLD_CONFIG_TLV_TYPE) {
			ret = parse_bsta_mld_config_tlv(&mld_bsta, value, len);
			if (ret < 0) {
				err(DEBUG_CAT_MLO, "error bsta mld config tlv\n");
				goto fail;
			}
			if (mld_bsta.num_affiliated_sta > 0)
				integrity |= (1 << 0);
		} else if (*type == END_OF_TLV_TYPE)
			break;

		type += tlv_len;
		left_tlv_len -= tlv_len;
	}
	/*check integrity*/
	if (integrity < 1) {
		err(DEBUG_CAT_MLO, "error when check bsta mld response message\n");
		goto fail;
	}

	/* don't need notify here as another bsta mld cfg tlv in wsc m2 is coming soon
	 * if (integrity & BIT(1)) {
	 *	_1905_notify_bsta_mld_config(ctx, &mld_bsta);
	 * }
	 */

fail:
	delete_bsta_mld_conf(&mld_bsta);
	return ret;
}

int parse_afc_spectrum_inquiry_message(struct p1905_managerd_ctx *ctx,
			unsigned char *buf, unsigned int left_tlv_len)
{
	unsigned char *type = NULL;
	unsigned short len = 0;
	unsigned int tlv_len = 0;
	int ret = 0;
	unsigned int integrity = 0;

	type = buf;
	reset_stored_tlv(ctx);

	while (1) {
		len = get_tlv_len(type);
		tlv_len = len + 3;
		if (tlv_len > left_tlv_len)
			return -1;

		if (*type == CH_PREFERENCE_TYPE) {
			integrity |= (1 << 0);
			store_revd_tlvs(ctx, type, tlv_len);
		} else if (*type == AFC_SPECTRUM_INQUIRY_REQUEST_TLV_TYPE) {
			integrity |= (1 << 1);
			store_revd_tlvs(ctx, type, tlv_len);
		} else if (*type == AFC_SPECTRUM_INQUIRY_RESPONSE_TLV_TYPE) {
			integrity |= (1 << 2);
			store_revd_tlvs(ctx, type, tlv_len);
		} else if (*type == END_OF_TLV_TYPE)
			break;

		type += tlv_len;
		left_tlv_len -= tlv_len;
	}

	if (integrity < 6) {
		warn(DEBUG_CAT_MISC, "error parse spectrum inquiry message\n");
		return -1;
	}
	return ret;
}
#endif

int check_frag_frame_len(unsigned char *tlv, int tlv_len)
{
	unsigned char *pos = tlv;
	unsigned int tlv_total_len = 0;

	while (1) {
		/* end tlv */
		if (*(pos + tlv_total_len) == END_OF_TLV_TYPE)
			return tlv_total_len;
		tlv_total_len += get_cmdu_tlv_length(pos + tlv_total_len);
		/* not found end tlv */
		if (tlv_total_len >= tlv_len)
			return tlv_len;
	}
}

/**
 *  parse cmdu message.
 *
 *
 * \param  ctx  1905.1 managerd context
 * \param  buf  input, cmdu message start address(header + payload)
 * \param  dmac  input, dmac of receive packet
 * \param  smac  input, smac of receive packet
 * \param  len   input, length of received packet
 * \return error code
 */
int parse_cmdu_message(struct p1905_managerd_ctx *ctx, unsigned char *buf,
		       unsigned char *dmac, unsigned char *smac, int len)
{
	unsigned char *temp_buf;
	unsigned char mversion;
	unsigned short mtype;
	unsigned short mid = 0;
	unsigned char fid;
	unsigned char last_fragment_ind;
	unsigned char relay_ind = 0;
	unsigned char al_mac[ETH_ALEN] = { 0 };
	unsigned char itf_mac[ETH_ALEN] = { 0 };
	unsigned char need_query = 0, need_notify = 0, need_discovery = 0, internal_vendor_message = 0;
	int tlv_total_len = 0, temp_tlv_len = 0;
	unsigned short queue_len = 0;
	unsigned char *tlv_start;
	struct p1905_vs_info vs_info;
	unsigned char band = 0, role = 0;
	unsigned char service[4] = {0};
	unsigned char service_cnt = 0;
	struct controller_capability contr_cap = {0};
	unsigned char *cmdu_hdr = NULL;
	unsigned short cmdu_len = 0;
#ifdef MAP_R3
	struct r3_member *peer = NULL;
	struct hash_value_item *hv_item = NULL, *hv_item_nxt = NULL;
	unsigned char vsinfo[16] = { 0 };
	unsigned short vsinfo_len;
	unsigned char restore_flag = 0;
	unsigned char *pos_vs = NULL;
#endif
	unsigned char multicast_address[ETH_ALEN] = { 0 };
	unsigned char profile = MAP_PROFILE_R1;
	unsigned char *if_name = NULL;
	int sanity_check_flag = 0;
	unsigned char radio_identifier[ETH_ALEN];
	unsigned char mid_check = 0;
	struct agent_radio_info rinfo_tmp[MAX_RADIO_NUM];
	unsigned char radio_cnt = 0;

	ctx->need_relay = 0;
	if_name = ctx->itf[ctx->recent_cmdu_rx_if_number].if_name;

	memcpy(multicast_address, p1905_multicast_address, ETH_ALEN);
	/* get message info from message header */
	temp_buf = buf;
	cmdu_hdr = buf;
	tlv_start = buf + 8;
	mversion = get_mversion_from_msg_hdr(temp_buf);
	mtype = get_mtype_from_msg_hdr(temp_buf);
	mid = get_mid_from_msg_hdr(temp_buf);
	fid = get_fid_from_msg_hdr(temp_buf);
	last_fragment_ind = get_last_fragment_ind_from_msg_hdr(temp_buf);
	relay_ind = get_relay_ind_from_msg_hdr(temp_buf);

	/* deal with message version, it must be 0x00 */
	if (mversion != MESSAGE_VERSION) {
		err(DEBUG_CAT_MSG, "msg version(%d) in correct; should be %d\n",
			mversion, MESSAGE_VERSION);
		return -1;
	}

	/* check msg type: avoid cache invalid data to fragment buffer */
	if (!((mtype <= ICHANNEL_SELECTION_REQUEST) ||
		(mtype >= Ack_1905 && mtype <= AFC_SPECTRUM_INQUIRY_MESSAGE))) {
		err(DEBUG_CAT_MSG, "do not support mtype(0x%04x)\n", mtype);
		return -1;
	}

	os_memcpy(al_mac, smac, ETH_ALEN);

	/* if relay indicator =1 but this is not relay multicast message, ignore */
	if (check_relay_message(relay_ind, mtype) < 0) {
		err(DEBUG_CAT_MSG, "mtype=0x%04x(%s) is not a relay msg\n",
			mtype, get_1905_mtype_str(mtype));
		return -1;
	}
	if (relay_ind)
		ctx->need_relay = relay_ind;
	/*
	 * check the fragment relevant field
	 * if fragment, insert to fragment queue and try to reassembly
	 */
	temp_tlv_len = len - ETH_HLEN - sizeof(cmdu_message_header);
	tlv_total_len = temp_tlv_len;
	cmdu_len = (unsigned short)(tlv_total_len + CMDU_HLEN);

	debug(DEBUG_CAT_MSG, "recv cmdu: sa("MACSTR") da("MACSTR") recv_ifname=%s "
		"mtype=0x%04x(%s); mid=0x%04x; fid-lf_ind=%d-%d; relay_ind=%d\n",
		MAC2STR(smac), MAC2STR(dmac), if_name,
		mtype, get_1905_mtype_str(mtype),
		mid, fid, last_fragment_ind, relay_ind);

	if (last_fragment_ind == 0 || fid != 0) {
		/*
		 * because of receiving fragment cmdu, we need to record the total
		 * tlvs length of message.
		 * we use the received length reported by socket and to minus the
		 * ether header length & cmdu message header length
		 */

		/* store cmdu hdr */
		if (fid == 0) {
			os_memcpy(ctx->reassemble_buf.buf, buf, CMDU_HLEN);
			/* fragment id set to 0 */
			*(ctx->reassemble_buf.buf + 6) &= 0x00;
			/* last frag set to 1 */
			*(ctx->reassemble_buf.buf + 7) |= 0x80;
		}
		if (last_fragment_ind == 0)
			temp_tlv_len = check_frag_frame_len(tlv_start, temp_tlv_len);
		insert_fragment_queue(mtype, mid, fid, last_fragment_ind, temp_tlv_len, tlv_start);
		queue_len = reassembly_fragment_queue(ctx, mtype, mid);
		/* do not parse this message unless each fragment was received */
		if (queue_len == 0) {
			/* relay the whole packets instesd of fragments to avoid dual backhaul looping */
			if (relay_ind)
				ctx->need_relay = 0;
			return 0;
		}
		/* do relay in msg handle */
		ctx->need_relay = 0;

		tlv_total_len = queue_len;
		cmdu_len = (unsigned short)(tlv_total_len + CMDU_HLEN);
		cmdu_hdr = ctx->reassemble_buf.buf;
	}

	/*
	 * because relay multicast frame will change SA to TA ensure send by neighbor
	 * so its mid need check later
	 * in order to keep reliable for relay multicast message, these message will be
	 * transfered to unicast and sent again. its relay bit will be set to zero.
	 * for dual backhaul link, discovery message cannot drop so no need check mid
	 */
	/*condition check relay_ind == 0 is enough. consider refine later*/
	if (relay_ind == 0 &&
		mtype != TOPOLOGY_DISCOVERY &&
	    mtype != TOPOLOGY_NOTIFICATION &&
		mtype != AP_AUTOCONFIG_SEARCH &&
		mtype != AP_AUTOCONFIG_RENEW) {
		if (check_recv_mid(ctx, al_mac, mid, mtype) < 0) {
			if (mtype == TOPOLOGY_DISCOVERY)
				debug(DEBUG_CAT_MSG, "mid check fail\n");
			else
				err(DEBUG_CAT_MSG, "mid check fail\n");
			return -1;
		}
	}

	/*
	 * shift to payload, if queue_len > 0 ==> get message tlv from fragment
	 * queue. otherwise, get payload from original allocated buffer
	 */
	if (queue_len > 0)
		temp_buf = ctx->reassemble_buf.buf + CMDU_HLEN;
	else
		temp_buf = tlv_start;

#ifdef MAP_R3
	if (is_security_on(smac) && cmdu_r3_handle(ctx, dmac, smac, cmdu_hdr, &cmdu_len, mtype,
		vsinfo, &vsinfo_len, temp_buf, tlv_total_len, &restore_flag, &mid_check))
		return -2;
#endif /* MAP_R3 */

	temp_buf = cmdu_hdr + CMDU_HLEN;
	tlv_total_len = cmdu_len - CMDU_HLEN;

	/* check if receive 1905_ack for those message which need receive */
	if (mtype == Ack_1905)
		delete_retry_message_queue(al_mac, mid, if_name);

	reset_send_tlv(ctx);
#ifdef MAP_R3
	if (ctx->MAP_Cer && (MAP_PROFILE_R3 == ctx->map_version))
		dev_buffer_frame(ctx, mtype, mid, temp_buf, tlv_total_len);
#endif

	sanity_check_flag = cmdu_sanity_check(temp_buf, tlv_total_len);
	if (-1 > sanity_check_flag) {
		err(DEBUG_CAT_MSG, "cmdu msg length check fail!\n");
		return -1;
	}

#ifdef MAP_R3
	/* restore vs info added in mapfilter */
	if (restore_flag) {
		pos_vs = get_tlv_pos(temp_buf, END_OF_TLV_TYPE, cmdu_len - CMDU_HLEN);
		if (pos_vs) {
			/* vs info */
			os_memcpy(pos_vs, vsinfo, vsinfo_len);
			/* end of tlv */
			os_memset(pos_vs + vsinfo_len, 0, 3);

			tlv_total_len += vsinfo_len;
		}
	}
#endif /* MAP_R3 */

	switch (mtype) {
	case TOPOLOGY_DISCOVERY:
		/*
		 * need to do ==> check al mac addr tlv
		 * & MID to know whether this message is duplicated
		 */
		if (parse_topology_discovery_message(ctx, temp_buf, tlv_total_len,
						     &need_query, &need_notify, &need_discovery,
						     al_mac, itf_mac, smac) < 0) {
			err(DEBUG_CAT_MSG, "err TOPOLOGY_DISCOVERY msg\n");
			return -1;
		}

		if (need_discovery) {
			insert_cmdu_txq((unsigned char *)p1905_multicast_address,
					ctx->p1905_al_mac_addr, e_topology_discovery, ++ctx->mid, if_name, 0);
			notice(DEBUG_CAT_TOPO, "send discovery to "MACSTR" with mid=%04x on %s\n",
			      MAC2STR(ctx->p1905_al_mac_addr), ctx->mid, if_name);
		}
		topology_discovery_action(ctx, al_mac, need_query, need_notify);
		update_topology_tree(ctx);
		check_neighbor_discovery(ctx, al_mac, itf_mac);
		break;
	case TOPOLOGY_NOTIFICATION:
	{
		unsigned char sta_mac[ETH_ALEN] = { 0 };
		unsigned char neth_almac[ETH_ALEN] = { 0 };
		unsigned char bssid[ETH_ALEN] = { 0 };
		unsigned char event = 0;
		unsigned char zero_mac[ETH_ALEN] = { 0 };

		if (parse_topology_notification_message(ctx, temp_buf, tlv_total_len, al_mac,
							bssid, sta_mac, &event, neth_almac) < 0) {
			ctx->need_relay = 0;
			err(DEBUG_CAT_MSG, "err TOPOLOGY_NOTIFICATION msg\n");
			return -1;
		}
		/* need check mid for SA */

		if (mid_check == 0 && check_recv_mid(ctx, al_mac, mid, mtype) < 0) {
			ctx->need_relay = 0;
			debug(DEBUG_CAT_MSG, "mid check fail\n");
			break;
		}
		_1905_notify_topology_notification_event(ctx, al_mac);
		/* send a topology query after receiving the topology notification message */
		insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr, e_topology_query, ++ctx->mid, if_name, 0);
		notice(DEBUG_CAT_TOPO, "recv topo notify; send query to "MACSTR" with mid=%04x on %s\n",
			      MAC2STR(al_mac), ctx->mid, if_name);
		if (!ctx->MAP_Cer) {
			if (os_memcmp(neth_almac, zero_mac, ETH_ALEN))
				detect_neighbor_existence(ctx, neth_almac, NULL);
			else if (os_memcmp(sta_mac, zero_mac, ETH_ALEN) &&
					os_memcmp(bssid, zero_mac, ETH_ALEN) && event)
				detect_neighbor_existence(ctx, NULL, sta_mac);
		}
#ifdef MAP_R5
		recheck_and_apply_qos_config((void *)ctx);
#endif
	}
		break;
	case TOPOLOGY_QUERY:
		insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr, e_topology_response, mid, if_name, 0);
		break;
	case TOPOLOGY_RESPONSE:
		if (parse_topology_response_message(ctx, temp_buf, tlv_total_len, al_mac, &profile) < 0) {
			err(DEBUG_CAT_MSG, "err TOPOLOGY_RESPONSE msg\n");
			return -1;
		}
#ifdef MAP_R3
		if (NULL == (peer = get_r3_member(al_mac))) {
			create_r3_member(al_mac);
		}
		if (peer) {
			peer->profile = profile;
			if (peer->security_1905 && (peer->profile < MAP_PROFILE_R3)) {
				notice(DEBUG_CAT_DPP, "disable security_1905 for " MACSTR "\n", MAC2STR(al_mac));
				peer->security_1905 = 0;
			}
		}
#endif
		_1905_notify_topology_rsp_event(ctx, al_mac, ctx->itf[ctx->recent_cmdu_rx_if_number].mac_addr);
		query_neighbor_info(ctx, al_mac, ctx->recent_cmdu_rx_if_number);
		update_topology_tree(ctx);
		break;
	case VENDOR_SPECIFIC:
		if (parse_vendor_specific_message(ctx, temp_buf, tlv_total_len, &vs_info,
		&internal_vendor_message) < 0) {
			err(DEBUG_CAT_MSG, "err VENDOR_SPECIFIC msg\n");
			return -1;
		}
		/* some vendor message is internal used by 1905daemon, so do not notify it to upper layer */
		if (!internal_vendor_message) {
			_1905_notify_vendor_specific_message(ctx, al_mac);
		} else {
			if (parse_1905_internal_vendor_specific_message(ctx, temp_buf, tlv_total_len,
				al_mac) < 0) {
				err(DEBUG_CAT_MSG, "err 1905_internal_vendor_specific msg\n");
				return -1;
			}
		}

		if (relay_ind && queue_len) {
			relay_fragment_send(ctx, ctx->reassemble_buf.buf,
				queue_len, (buf - ETH_HLEN), ctx->p1905_al_mac_addr);
		}

		break;
	case LINK_METRICS_QUERY:
		if (parse_link_metric_query_message(ctx, temp_buf, tlv_total_len) < 0) {
			err(DEBUG_CAT_MSG, "err LINK_METRICS_QUERY msg");
			return -1;
		}
		if (!store_dm_buffer(ctx, al_mac, WAPP_LINK_METRICS_RSP_INFO, mid, (char *)if_name))
			_1905_notify_link_metrics_query(ctx, al_mac, mid);

		break;
	case AP_AUTOCONFIG_SEARCH:
		if (parse_ap_autoconfig_search_message(ctx, temp_buf, tlv_total_len, al_mac, &profile) < 0) {
			ctx->need_relay = 0;
			err(DEBUG_CAT_MSG, "err AP_AUTOCONFIG_SEARCH msg");
			return -1;
		}

		if (0 > check_recv_mid(ctx, al_mac, mid, mtype)) {
			ctx->need_relay = 0;
			debug(DEBUG_CAT_MSG, "mid check fail");
			break;
		}
		cont_handle_autoconfig_search(ctx, al_mac, if_name, profile, mid);
		break;
	case AP_AUTOCONFIG_RESPONSE:
	{
#ifdef EM_PLUS_SUPPORT
		int i = 0;
		int emplus_controller = 0;
#endif
		if (ctx->autoconfig_search_mid != mid) {
			notice(DEBUG_CAT_AUTOCONF,
				"mid mismatch; autoconfig_search_mid=0x%04x, autoconfig_rsp_mid=0x%04x\n",
				ctx->autoconfig_search_mid, mid);
			return -1;
		}
		info(DEBUG_CAT_AUTOCONF, "Received AP_AUTOCONFIG_RESPONSE from :"MACSTR"\n", MAC2STR(al_mac));
		if (parse_ap_autoconfig_response_message(ctx, temp_buf, tlv_total_len,
			&band, service, &service_cnt, &role, al_mac, &profile,
			&contr_cap) < 0) {
			err(DEBUG_CAT_MSG, "err AP_AUTOCONFIG_RESPONSE msg");
			return -1;
		}

#ifdef EM_PLUS_SUPPORT
		for (i = 0; i < service_cnt; i++) {
			if (service[i] == SERVICE_EMPLUS_CONTROLLER) {
				emplus_controller = 1;
				break;
			}
		}
		if (ctx->role == SERVICE_EMPLUS_AGENT && !emplus_controller) {
			warn(DEBUG_CAT_AUTOCONF, "Emplus agent only onboard with emplus controller\n");
			break;
		}
#endif
		cont_handle_autoconfig_response(ctx, al_mac, if_name, band, role, profile, contr_cap);
	}
#ifdef EM_PLUS_EXT_SUPPORT
		/* If there is no topology Discovery from peer device the device record is not updated
		 * in the topology database.
		 */
		topology_discovery_action(ctx, al_mac, 1, 0);
		update_topology_tree(ctx);
#endif
		break;
	case AP_AUTOCONFIG_RENEW:
#ifdef MAP_R3
		peer = get_r3_member(al_mac);
		if (peer && peer->security_1905) {
			notice(DEBUG_CAT_DPP, "R3 onboarding, skip autoconfig renew\n");
			break;
		}
#endif
		if (parse_ap_autoconfig_renew_message(ctx, temp_buf, tlv_total_len, al_mac, &band) < 0) {
			notice(DEBUG_CAT_DPP, "no need to response this autoconfig renew message\n");
			ctx->need_relay = 0;
			return -1;
		}

		if (mid_check == 0 && check_recv_mid(ctx, al_mac, mid, mtype) < 0) {
			ctx->need_relay = 0;
			break;
		}

		if (cont_handle_autoconfig_renew(ctx, al_mac, if_name, band) < 0) {
			warn(DEBUG_CAT_RENEW,
			    "fail to continue to handle auto config renew (" MACSTR ")\n",
			    PRINT_MAC(al_mac));
			break;
		}
#ifdef EM_PLUS_EXT_SUPPORT
		/* If there is no topology Discovery from peer device the device record is not updated
		 * in the topology database.
		 */
		topology_discovery_action(ctx, al_mac, 1, 0);
		update_topology_tree(ctx);
#endif
		break;
	case AP_AUTOCONFIG_WSC:
		if (ctx->role == AGENT) {
			if (ctx->enrolle_state != wait_4_recv_m2) {
				warn(DEBUG_CAT_AUTOCONF,
					"drop wsc msg; wrong state; enrolle_state=%d(%s)\n",
					ctx->enrolle_state, get_enrollee_state_str(ctx->enrolle_state));
				return -1;
			}
		}

		if (parse_ap_autoconfig_wsc_message(ctx, al_mac, temp_buf, tlv_total_len, rinfo_tmp, &radio_cnt, radio_identifier) < 0) {
			err(DEBUG_CAT_MSG, "err AP_AUTOCONFIG_WSC msg");
			return -1;
		}

		cont_handle_autoconfig_wsc(ctx, al_mac, if_name, mid, rinfo_tmp, radio_cnt, radio_identifier);
		break;
	case Ack_1905:
		if (parse_1905_ack_message(ctx, temp_buf, tlv_total_len) < 0) {
			err(DEBUG_CAT_MSG, "err Ack_1905 msg\n");
			return -1;
		}
		if (ctx->revd_tlv.buf_len > 0)
			_1905_notify_error_code_event(ctx, al_mac);
		break;
	case AP_CAPABILITY_QUERY:
		insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr, e_ap_capability_report, mid,
			if_name, 0);
		break;
	case AP_CAPABILITY_REPORT:
		if (parse_ap_capability_report_message(ctx, al_mac, temp_buf, tlv_total_len) < 0) {
			err(DEBUG_CAT_MSG, "err AP_CAPABILITY_REPORT msg\n");
			return -1;
		}
		_1905_notify_ap_capability_report_event(ctx, al_mac);
		break;
	case CLIENT_CAPABILITY_QUERY:
		if (parse_client_capability_query_message(ctx, temp_buf, tlv_total_len) < 0) {
			err(DEBUG_CAT_MSG, "err CLIENT_CAPABILITY_QUERY msg\n");
			return -1;
		}
		insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr, e_cli_capability_report, mid, if_name, 0);
		break;
	case CLIENT_CAPABILITY_REPORT:
		if (parse_client_capability_report_message(ctx, temp_buf, tlv_total_len) < 0) {
			err(DEBUG_CAT_MSG, "err CLIENT_CAPABILITY_REPORT msg\n");
			return -1;
		}
		_1905_notify_client_capability_report_event(ctx, al_mac);
		break;
	case CHANNEL_PREFERENCE_QUERY:
		reset_stored_tlv(ctx);
		_1905_notify_channel_preference_query(ctx, al_mac, mid);
		break;
	case CHANNEL_SELECTION_REQUEST:
		if (parse_channel_selection_request_message(ctx, temp_buf, tlv_total_len) < 0) {
			err(DEBUG_CAT_MSG, "err CHANNEL_SELECTION_REQUEST msg\n");
			return -1;
		}
		_1905_notify_channel_selection_req(ctx, al_mac, mid);
		break;
	case OPERATING_CHANNEL_REPORT:
		insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr, e_1905_ack, mid, if_name, 0);
		if (parse_operating_channel_report_message(ctx, temp_buf, tlv_total_len) < 0) {
			err(DEBUG_CAT_MSG, "err OPERATING_CHANNEL_REPORT msg\n");
			return -1;
		}
		_1905_notify_operating_channel_report_event(ctx, al_mac);
		break;
	case e_higher_layer_data:
		insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr, e_1905_ack, mid, if_name, 0);
		if (parse_higher_layer_data_message(ctx, temp_buf, tlv_total_len) < 0) {
			err(DEBUG_CAT_MSG, "err e_higher_layer_data msg\n");
			return -1;
		}
		_1905_notify_higher_layer_data_event(ctx, al_mac);
		break;
	case CLIENT_STEERING_REQUEST:
	{
		struct err_sta_db err_sta;
		struct err_sta_mac_db *err_mac = NULL, *err_mac_next = NULL;
		unsigned char *buf_err = NULL, *pos = NULL;
		int len = 0;

		os_memset(&err_sta, 0, sizeof(err_sta));
		insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr, e_1905_ack, mid, if_name, 0);
		/* parse the selection request message */
		if (parse_client_steering_request_message(ctx, temp_buf, tlv_total_len, &err_sta) < 0) {
			err(DEBUG_CAT_MSG, "err CLIENT_STEERING_REQUEST msg\n");
			return -1;
		}
		_1905_set_steering_setting(ctx, al_mac);

		/* prepare for error mac tlv */
		if (err_sta.err_sta_cnt) {
			len = err_sta.err_sta_cnt * 10;
			buf_err = (unsigned char *)os_malloc(len);
			if (!buf_err) {
				err(DEBUG_CAT_MISC, "alloc buf_err fail\n");
				break;
			}
			pos = buf_err;
			SLIST_FOREACH(err_mac, &err_sta.err_sta_head, err_sta_mac_entry) {
				*pos++ = ERROR_CODE_TYPE;
				*pos++ = 0x00;
				*pos++ = 0x07;
				*pos++ = 0x02;
				os_memcpy(pos, err_mac->mac_addr, ETH_ALEN);
				pos += ETH_ALEN;
			}
			err_mac = SLIST_FIRST(&err_sta.err_sta_head);
			while (err_mac) {
				err_mac_next = SLIST_NEXT(err_mac, err_sta_mac_entry);
				SLIST_REMOVE(&err_sta.err_sta_head, err_mac, err_sta_mac_db, err_sta_mac_entry);
				os_free(err_mac);
				err_mac = err_mac_next;
			}
			reset_send_tlv(ctx);
			if (fill_send_tlv(ctx, buf_err, len) < 0)
				err(DEBUG_CAT_MSG, "fill_send_tlv fail for ack to CLIENT_STEERING_REQUEST msg\n");
			os_free(buf_err);
		}
	}
		break;
	case MAP_POLICY_CONFIG_REQUEST:
		if (ctx->role == AGENT) {
			unsigned char old_report_interval = ctx->map_policy.mpolicy.report_interval;

			insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr, e_1905_ack, mid, if_name, 0);
			if (parse_map_policy_config_request_message(ctx, temp_buf, tlv_total_len) < 0) {
				err(DEBUG_CAT_MSG, "err MAP_POLICY_CONFIG_REQUEST msg\n");
				return -1;
			}
			_1905_set_map_policy_config(ctx, al_mac);

			if (ctx->map_policy.mpolicy.report_interval == 0) {
				eloop_cancel_timeout(metrics_report_timeout, (void *)ctx, NULL);
			} else if (old_report_interval != ctx->map_policy.mpolicy.report_interval) {
				eloop_cancel_timeout(metrics_report_timeout, (void *)ctx, NULL);
				eloop_register_timeout(0, 0,
								metrics_report_timeout, (void *)ctx, NULL);
			}
#ifdef MAP_R2
			/* Only update traffic separation policy in Certification mode */
			if (ctx->MAP_Cer) {
				eloop_register_timeout(4, 0, map_r2_notify_ts_config, (void *)ctx, NULL);
				eloop_register_timeout(0, 0, map_notify_transparent_vlan_setting, (void *)ctx,
								NULL);
			}
#endif
#ifdef MAP_R5
		eloop_register_timeout(2, 0, qos_management_policy_check, (void *)ctx, NULL);
#endif
		}
		break;
	case CLIENT_ASSOC_CONTROL_REQUEST:
	{
		unsigned char ack_buf[560] = { 0 };

		delete_exist_steer_cntrl_db(ctx);
		if (parse_cli_assoc_control_request_message(ctx, temp_buf, tlv_total_len) < 0) {
			err(DEBUG_CAT_MSG, "err CLIENT_ASSOC_CONTROL_REQUEST msg\n");
			return -1;
		}
		/* check if need add error code tlv in 1905 ack message */
		check_add_error_code_tlv(ctx, ack_buf, 50, CLIENT_ASSOC_CONTROL_REQUEST);
		insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr, e_1905_ack, mid, if_name, 0);
		_1905_set_client_assoc_ctrl(ctx, al_mac);
	}
		break;
	case AP_LINK_METRICS_QUERY:
		/* parse AP_LINK_METRICS_QUERY msg */
		if (parse_ap_metrics_query_message(ctx, temp_buf, tlv_total_len, radio_identifier) < 0) {
			err(DEBUG_CAT_MSG, "err AP_LINK_METRICS_QUERY msg\n");
			return -1;
		}
		_1905_notify_ap_metrics_query(ctx, al_mac, mid
#ifdef MAP_R2
			, 0
#endif
		);
		break;
	case AP_LINK_METRICS_RESPONSE:
		if (ctx->role == CONTROLLER) {
			if (parse_ap_metrics_response_message(ctx, temp_buf, tlv_total_len) < 0) {
				err(DEBUG_CAT_MSG, "err AP_LINK_METRICS_RESPONSE msg\n");
				return -1;
			}
			_1905_notify_ap_metrics_response(ctx, al_mac);
		}
		break;
	case LINK_METRICS_RESPONSE:
		if (ctx->role == CONTROLLER) {
			if (parse_link_metrics_response_message(ctx, temp_buf, tlv_total_len) < 0) {
				err(DEBUG_CAT_MSG, "err LINK_METRICS_RESPONSE msg\n");
				return -1;
			}
			_1905_notify_link_metrics_response(ctx, al_mac);
		}
		break;
	case ASSOC_STA_LINK_METRICS_QUERY:
		/* parse AP_LINK_METRICS_QUERY msg */
		if (parse_associated_sta_link_metrics_query_message(ctx, temp_buf, tlv_total_len) < 0) {
			err(DEBUG_CAT_MSG, "err LINK_METRICS_RESPONSE msg\n");
			return -1;
		}
		_1905_notify_assoc_sta_link_metrics_query(ctx, al_mac, mid);
		break;
	case ASSOC_STA_LINK_METRICS_RESPONSE:
		if (parse_associated_sta_link_metrics_rsp_message(ctx, temp_buf, tlv_total_len) < 0) {
			err(DEBUG_CAT_MSG, "err ASSOC_STA_LINK_METRICS_RESPONSE msg\n");
			return -1;
		}
		_1905_notify_assoc_sta_link_metric_rsp(ctx, al_mac);
		break;
	case UNASSOC_STA_LINK_METRICS_QUERY:
	{
		unsigned char ack_buf[1514] = { 0 };

		free(ctx->metric_entry.unlink_query);
		ctx->metric_entry.unlink_query = NULL;
		if (parse_unassociated_sta_link_metrics_query_message(ctx, temp_buf, tlv_total_len) < 0) {
			err(DEBUG_CAT_MSG, "err UNASSOC_STA_LINK_METRICS_QUERY msg\n");
			return -1;
		}
		/* check if need add error code tlv in 1905 ack message */
		check_add_error_code_tlv(ctx, ack_buf, 50, UNASSOC_STA_LINK_METRICS_QUERY);
		insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr, e_1905_ack, mid, if_name, 0);
		process_cmdu_txq(ctx, ack_buf);

		if (!store_dm_buffer(ctx, al_mac, LIB_UNASSOC_STA_LINK_METRICS,
			mid, (char *)ctx->itf[ctx->recent_cmdu_rx_if_number].if_name))
			_1905_notify_unassoc_sta_metrics_query(ctx, al_mac);
	}
	break;
	case UNASSOC_STA_LINK_METRICS_RESPONSE:
		insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr, e_1905_ack, mid, if_name, 0);
		if (parse_unassoc_sta_link_metrics_response_message(ctx, temp_buf, tlv_total_len) < 0) {
			err(DEBUG_CAT_MSG, "err UNASSOC_STA_LINK_METRICS_RESPONSE msg\n");
			return -1;
		}
		_1905_notify_unassoc_sta_link_metric_rsp(ctx, al_mac);
		break;
	case BEACON_METRICS_QUERY:
	{
		unsigned char ack_buf[128] = { 0 };

		free(ctx->metric_entry.bcn_query);
		ctx->metric_entry.bcn_query = NULL;

		if (parse_beacon_metrics_query_message(ctx, temp_buf, tlv_total_len) < 0) {
			err(DEBUG_CAT_MSG, "err BEACON_METRICS_QUERY msg\n");
			return -1;
		}
		check_add_error_code_tlv(ctx, ack_buf, 1, BEACON_METRICS_QUERY);
		insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr, e_1905_ack, mid, if_name, 0);
		_1905_notify_beacon_metrics_query(ctx, al_mac);
	}
		break;
	case BEACON_METRICS_RESPONSE:
		insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr, e_1905_ack, mid, if_name, 0);
		if (parse_beacon_metrics_response_message(ctx, temp_buf, tlv_total_len) < 0) {
			err(DEBUG_CAT_MSG, "err BEACON_METRICS_RESPONSE msg\n");
			return -1;
		}
		_1905_notify_bcn_metric_rsp(ctx, al_mac);
		break;
	case CHANNEL_PREFERENCE_REPORT:
	{
		struct agent_list_db *agent_info = NULL;

		if (ctx->role == CONTROLLER) {
			insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr, e_1905_ack, mid, if_name, 0);

			if (ctx->MAP_Cer) {
				find_agent_info(ctx, smac, &agent_info);
				if (!agent_info) {
					err(DEBUG_CAT_AUTOCONF, "no agent("MACSTR") exist\n", MAC2STR(smac));
					break;
				}
				/* delete all the stored channel preference information for the agent */
				delete_agent_ch_prefer_info(ctx, agent_info);
			}

			/* parse the channel preference report message for the agent */
			if (parse_channel_preference_report_message(ctx, agent_info, temp_buf,
			tlv_total_len) < 0) {
				err(DEBUG_CAT_MSG, "err CHANNEL_PREFERENCE_REPORT message\n");
				return -1;
			}
			_1905_notify_channel_preference_report(ctx, al_mac);
		}
	}
	break;
	case CHANNEL_SELECTION_RESPONSE:
		if (ctx->role == CONTROLLER) {
			insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr, e_1905_ack, mid, if_name, 0);
			if (parse_channel_selection_rsp_message(ctx, temp_buf, tlv_total_len) < 0) {
				err(DEBUG_CAT_MSG, "err CHANNEL_SELECTION_RESPONSE message\n");
				return -1;
			}
			_1905_notify_ch_selection_rsp_event(ctx, al_mac);
		}
		break;
	case CLIENT_STEERING_BTM_REPORT:
		if (ctx->role == CONTROLLER) {
			insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr, e_1905_ack, mid, if_name, 0);
			if (parse_client_steering_btm_report_message(ctx, temp_buf, tlv_total_len) < 0) {
				err(DEBUG_CAT_MSG, "err CLIENT_STEERING_BTM_REPORT message\n");
				return -1;
			}
			_1905_notify_client_steering_btm_report(ctx, al_mac);
		}
		break;
	case CLIENT_STEERING_COMPLETED:
		if (ctx->role == CONTROLLER) {
			insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr, e_1905_ack, mid, if_name, 0);
			reset_stored_tlv(ctx);
			_1905_notify_steering_complete(ctx, al_mac);
		}
		break;
	case BACKHAUL_STEERING_RESPONSE:
		if (ctx->role == CONTROLLER) {
			insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr, e_1905_ack, mid, if_name, 0);
			if (parse_backhaul_steering_rsp_message(ctx, temp_buf, tlv_total_len) < 0) {
				err(DEBUG_CAT_MSG, "err BACKHAUL_STEERING_RESPONSE message\n");
				return -1;
			}
			_1905_notify_bh_steering_rsp(ctx, al_mac);
		}
		break;
		/* Backhaul optimization */
	case BACKHAUL_STEERING_REQUEST:
		insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr, e_1905_ack, mid, if_name, 0);
		/* parse BACKHAUL_STEERING_REQUEST msg */
		if (parse_backhaul_steering_request_message(ctx, temp_buf, tlv_total_len) < 0) {
			err(DEBUG_CAT_MSG, "err BACKHAUL_STEERING_RESPONSE message\n");
			return -1;
		}
		_1905_notify_bh_steering_req(ctx, al_mac);
		break;
	case COMBINED_INFRASTRUCTURE_METRICS:
		insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr, e_1905_ack, mid, if_name, 0);
		if (parse_combined_infra_metrics_message(ctx, temp_buf, tlv_total_len) < 0) {
			err(DEBUG_CAT_MSG, "err COMBINED_INFRASTRUCTURE_METRICS message\n");
			return -1;
		}
		_1905_notify_combined_infra_metrics(ctx, al_mac);
		break;
#ifdef MAP_R2
		/* channel scan feature */
	case CHANNEL_SCAN_REQUEST:
		insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr, e_1905_ack, mid, if_name, 0);
		if (parse_channel_scan_request_message(ctx, temp_buf, tlv_total_len) < 0) {
			err(DEBUG_CAT_MSG, "err CHANNEL_SCAN_REQUEST message\n");
			return -1;
		}
		_1905_notify_ch_scan_req(ctx, al_mac);
		break;
	case CHANNEL_SCAN_REPORT:
		insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr, e_1905_ack, mid, if_name, 0);
		if (parse_channel_scan_report_message(ctx, temp_buf, tlv_total_len) < 0) {
			err(DEBUG_CAT_MSG, "err CHANNEL_SCAN_REPORT message\n");
			return -1;
		}
		_1905_notify_ch_scan_rep(ctx, al_mac);
		break;

	case TUNNELED_MESSAGE:
	{
		unsigned char msg_type = 0;

		insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr, e_1905_ack, mid, if_name, 0);
		/* parse tunneled msg */
		if (parse_tunneled_message(ctx, temp_buf, tlv_total_len, &msg_type) < 0) {
			err(DEBUG_CAT_MSG, "err TUNNELED message\n");
#ifdef MAP_R5
			memset(&ctx->dscp_policy_act_frm, 0, sizeof(ctx->dscp_policy_act_frm));
#endif
			return -1;
		}
#ifdef MAP_R5
		if (ctx->dscp_policy_act_frm.protocol_type == TUNNELLED_DSCP_QUERY) {
			insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr,
				e_qos_dscp_policy_request, mid, if_name, 0);
			break;
		}
#endif
#ifdef MAP_R6
		if (msg_type == TUNNELED_ASSOC_REQ || msg_type == TUNNELED_REASSOC_REQ) {
			/* send a topology query after receiving the assoc or re-assoc frame */
			insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr, e_topology_query, ++ctx->mid, if_name, 0);
			notice(DEBUG_CAT_TOPO, "recv tunnel assoc/reassoc; send query to "MACSTR" with mid=%04x on %s\n",
			      MAC2STR(al_mac), ctx->mid, if_name);
		}
#endif
		_1905_notify_tunneled_msg(ctx, al_mac);
	}
		break;
	case ASSOCIATION_STATUS_NOTIFICATION:
		insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr, e_1905_ack, mid, if_name, 0);
		if (parse_assoc_status_notification_message(ctx, temp_buf, tlv_total_len) < 0) {
			err(DEBUG_CAT_MSG, "err ASSOCIATION_STATUS_NOTIFICATION message\n");
			return -1;
		}
		_1905_notify_assoc_status_notification_event(ctx, al_mac);
		break;
	case CAC_REQUEST:
		insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr, e_1905_ack, mid, if_name, 0);
		if (parse_cac_request_message(ctx, temp_buf, tlv_total_len) < 0) {
			err(DEBUG_CAT_MSG, "err CAC_REQUEST message\n");
			return -1;
		}
		_1905_notify_cac_request_event(ctx, al_mac);
		break;

	case CAC_TERMINATION:
		insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr, e_1905_ack, mid, if_name, 0);
		if (parse_cac_terminate_message(ctx, temp_buf, tlv_total_len) < 0) {
			err(DEBUG_CAT_MSG, "err CAC_TERMINATION message\n");
			return -1;
		}
		_1905_notify_cac_terminate_event(ctx, al_mac);
		break;

	case CLIENT_DISASSOCIATION_STATS:
		if (parse_client_disassciation_stats_message(ctx, temp_buf, tlv_total_len) < 0) {
			err(DEBUG_CAT_MSG, "err CLIENT_DISASSOCIATION_STATS message\n");
			return -1;
		}
		_1905_notify_client_disassociation_stats_event(ctx, al_mac);
		break;

	case BACKHAUL_STA_CAP_QUERY_MESSAGE:
		insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr,
				e_backhual_sta_cap_report_message, mid, if_name, 0);
		break;
	case BACKHAUL_STA_CAP_REPORT_MESSAGE:
		if (parse_backhaul_sta_cap_report_message(ctx, temp_buf, tlv_total_len) < 0) {
			err(DEBUG_CAT_MSG, "err BACKHAUL_STA_CAP_REPORT message\n");
			return -1;
		}
		_1905_notify_backhaul_sta_cap_report_event(ctx, al_mac);
		break;

	case FAILED_CONNECTION_MESSAGE:
		insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr,
				e_1905_ack, mid, ctx->itf[ctx->recent_cmdu_rx_if_number].if_name, 0);
		if (parse_failed_connection_message(ctx, temp_buf, tlv_total_len) < 0) {
			err(DEBUG_CAT_MSG, "err FAILED_CONNECTION message\n");
			return -1;
		}
		_1905_notify_failed_connection_event(ctx, al_mac);
		break;
#endif /* #ifdef MAP_R2 */

#ifdef MAP_R3
	case DIRECT_ENCAP_DPP_MESSAGE:
		{
			unsigned char dpp_frame_type = 0;
			unsigned short dpp_frame_offset = 0;
			unsigned short dpp_frame_len = 0;

			if (ctx->map_version < MAP_PROFILE_R3)
				break;

			if (ctx->r3_dpp.onboarding_type != MAP_ONBOARDING_TYPE_DPP) {
				debug(DEBUG_CAT_DPP, "no dpp onboarding, skip DIRECT_ENCAP_DPP_MESSAGE\n");
				break;
			}

			if (parse_direct_encap_dpp_message(ctx, temp_buf, tlv_total_len,
				&dpp_frame_type, &dpp_frame_offset,
				&dpp_frame_len, al_mac) < 0) {
				warn(DEBUG_CAT_DPP, "[dpp in 1905]error! fail to parse direct encap dpp msg\n");
				break;
			}

			/* DPP onboarding after R1|R2 onboarding */
			if ((ctx->r3_oboard_ctx.bh_type == MAP_BH_ETH) && (dpp_frame_type == DPP_AUTH_REQUEST)) {
				notice(DEBUG_CAT_DPP,
				      "activate dpp onboarding after receiving DPP Auth Req\n");
				ctx->r3_oboard_ctx.active = 1;
			}

			if (dpp_frame_type != DPP_DISCOVERY_REQUEST && dpp_frame_type != DPP_DISCOVERY_RESPONSE)
				_1905_notify_direct_encap_dpp_event(ctx, al_mac);
		}
		break;

	case PROXIED_ENCAP_DPP_MESSAGE:
		{
			unsigned char dpp_frame_type = 0;
			unsigned short dpp_frame_offset = 0;
			unsigned short dpp_frame_len = 0;

			/*
			 * If a Multi-AP Controller receives a Proxied Encap DPP Message,
			 * then it shall respond within one second with a 1905 Ack
			 */
			if (ctx->role == CONTROLLER) {
				insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr,
						e_1905_ack, mid, ctx->itf[ctx->recent_cmdu_rx_if_number].if_name, 0);
			}

			/* parse proxied encap dpp msg */
			if (parse_proxied_encap_dpp_message(ctx, temp_buf, tlv_total_len,
				al_mac, &dpp_frame_type, &dpp_frame_offset, &dpp_frame_len) < 0) {
				notice(DEBUG_CAT_DPP, "error! no need to proxid encap dpp msg to mapd\n");
				break;
			}

			if (dpp_frame_type != DPP_DISCOVERY_REQUEST && dpp_frame_type != DPP_DISCOVERY_RESPONSE)
				_1905_notify_proxied_encap_dpp_event(ctx, al_mac);

			if (ctx->r3_oboard_ctx.bh_type == MAP_BH_ETH && dpp_frame_type == DPP_AUTH_REQUEST) {
				notice(DEBUG_CAT_DPP, "ETH BH,cancel timer of dpp auth req\n");
				eloop_cancel_timeout(r3_wait_for_dpp_auth_req, (void *)ctx, NULL);
			}
		}
		break;

	case _1905_ENCAP_EAPOL:
		{
			unsigned char *eapol_frame = NULL;
			unsigned short eapol_offset = 0;
			unsigned short eapol_len = 0;
			int eapol_msg_type = EAPOL_MSG_INVALID;
			struct wpa_entry_info *entry = NULL;

			if (ctx->map_version < MAP_PROFILE_R3)
				break;

			/* parse eapol frame and length */
			if (parse_1905_encap_eapol_message(ctx, temp_buf, tlv_total_len,
				&eapol_offset, &eapol_len) < 0) {
				warn(DEBUG_CAT_DPP, "parse encap eapol frame error\n");
				break;
			}

			eapol_frame = temp_buf + eapol_offset;
			eapol_msg_type = wpa_receive_from_1905(al_mac, eapol_frame, eapol_len);

			if (ctx->role == AGENT &&
			    ((eapol_msg_type == EAPOL_PAIR_MSG_1) || (eapol_msg_type == EAPOL_PAIR_MSG_2))) {

				if (!os_memcmp(al_mac, ctx->cinfo.almac, ETH_ALEN)) {
					ctx->r3_oboard_ctx.onboarding_stage = R3_ONBOARDING_STAGE_4_WAY_HS;
					notice(DEBUG_CAT_DPP, "change stage to 4 way hand shake\n");
				}
			}

			entry = wpa_get_entry(al_mac);
			if (entry && entry->wpa_sm->ptk_sm == wpa_pair_suc) {
				peer = get_r3_member(al_mac);
				if (peer) {
					peer->security_1905 = 1;
					peer->dec_fail_cnt = 0;

					if (os_memcmp(al_mac, ctx->cinfo.almac, ETH_ALEN) == 0) {
						_1905_notify_1905_security(ctx, al_mac, 1);
					}
				}
			}

			/* make sure not trigger dpp peer discovery while GTK Rekey */
			if ((eapol_msg_type >= EAPOL_PAIR_MSG_3) && (eapol_msg_type <= EAPOL_PAIR_MSG_4)) {
				/* agent start bss configuration procedure */
				if (!os_memcmp(ctx->cinfo.almac, al_mac, ETH_ALEN)) {
					entry = wpa_get_entry(al_mac);
					/* check if PTK negotiation finished or not */
					if (entry && entry->wpa_sm->ptk_sm == wpa_pair_suc) {
						notice(DEBUG_CAT_DPP,
						      "4 way finished, start bss config procedure\n");
						if (ctx->r3_oboard_ctx.r3_config_state == no_r3_autoconfig
						    || ctx->r3_oboard_ctx.r3_config_state == r3_autoconfig_done) {
							r3_set_config_state(ctx, wait_4_send_bss_autoconfig_req);
							/* wait for 5 secs to start bss configuration */
							eloop_cancel_timeout(r3_config_sm_step, (void *)ctx, NULL);
							eloop_register_timeout(0, 0, r3_config_sm_step, (void *)ctx,
									       NULL);

							ctx->r3_oboard_ctx.onboarding_stage =
							    R3_ONBOARDING_STAGE_BSS_CONFIG;

						}
					} else
						info(DEBUG_CAT_DPP,
						      "4 way not finished, can't start bss config procedure\n");
				}
			} else
				info(DEBUG_CAT_DPP, "only start bss config after msg3|msg4\n");
		}
		break;

	case DPP_BOOTSTRAPING_URI_QUERY:
		{
			/* if need ack??? */
			insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr,
					e_1905_ack, mid, ctx->itf[ctx->recent_cmdu_rx_if_number].if_name, 0);

			/* no tlvs in uri query msg, so do not need to parse it */
			_1905_notify_dpp_bootstraping_uri_query_event(ctx, al_mac);
		}
		break;

	case DPP_BOOTSTRAPING_URI_NOTIFICATION:
		{
			insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr,
					e_1905_ack, mid, ctx->itf[ctx->recent_cmdu_rx_if_number].if_name, 0);

			/* parse dpp bootstraping uri notification msg */
			if (parse_dpp_bootstraping_uri_notification_message(ctx, temp_buf, tlv_total_len) < 0) {
				warn(DEBUG_CAT_DPP, "error! no need to bootstraping uri notify msg to mapd\n");
				break;
			}

			_1905_notify_dpp_bootstraping_uri_notification_event(ctx, al_mac);
		}
		break;

	case DPP_CCE_INDICATION_MESSAGE:
		{
			insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr,
					e_1905_ack, mid, ctx->itf[ctx->recent_cmdu_rx_if_number].if_name, 0);

			/* parse assoc status notification msg */
			if (parse_dpp_cce_indication_message(ctx, temp_buf, tlv_total_len) < 0) {
				warn(DEBUG_CAT_DPP, "error! no need to send cce indication msg to mapd\n");
				break;
			}

			_1905_notify_dpp_cce_indication_event(ctx, al_mac);
		}
		break;

	case CHIRP_NOTIFICATION_MESSAGE:
		{
			insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr,
					e_1905_ack, mid, ctx->itf[ctx->recent_cmdu_rx_if_number].if_name, 0);

			/* parse chirp notification msg */
			if (parse_chirp_notification_message(ctx, temp_buf, tlv_total_len, al_mac) < 0) {
				warn(DEBUG_CAT_DPP, "error! no need to send chirp notification msg to mapd\n");
				break;
			}

			_1905_notify_chirp_notification_event(ctx, al_mac);

		}
		break;

	case _1905_REKEY_REQUEST:
		{
			struct topology_response_db *tpgr_db = NULL;
			unsigned char peer_cnt = 0;

			notice(DEBUG_CAT_DPP, "receive _1905_REKEY_REQUEST from " MACSTR "\n", MAC2STR(al_mac));

			/*
			 * receives a 1905 Rekey Request Message,
			 * respond within one second with a 1905 Ack message
			 */
			insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr,
					e_1905_ack, mid, ctx->itf[ctx->recent_cmdu_rx_if_number].if_name, 0);

			/* parse 1905 rekey request message */
			if (parse_1905_rekey_request_message(ctx, temp_buf, tlv_total_len) < 0) {
				warn(DEBUG_CAT_DPP, "error! no need handle 1905 rekey request\n");
				break;
			}

			/* start 4-way handshake with each peer */
			SLIST_FOREACH(tpgr_db, &(ctx->topology_entry.tprdb_head), tprdb_entry) {
				notice(DEBUG_CAT_DPP, "start timer %d(s) to init 4way with " MACSTR "\n",
				      peer_cnt * 10, MAC2STR(tpgr_db->al_mac_addr));
				eloop_cancel_timeout(wpa_start_4way_handshake, (void *)tpgr_db->al_mac_addr, NULL);
				eloop_register_timeout(peer_cnt * 2, 0, wpa_start_4way_handshake,
						       (void *)tpgr_db->al_mac_addr, NULL);
				peer_cnt++;
			}
		}
		break;

	case _1905_DECRYPTION_FAILURE:
		{
			unsigned char peer_al_mac[ETH_ALEN];

			insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr,
					e_1905_ack, mid, ctx->itf[ctx->recent_cmdu_rx_if_number].if_name, 0);

			/* parse 1905 rekey request message */
			if (parse_1905_decryption_failure_message(ctx, temp_buf, tlv_total_len, peer_al_mac) < 0)
				break;

			peer = get_r3_member(peer_al_mac);
			if (peer) {
				notice(DEBUG_CAT_DPP, "trigger dpp intro with " MACSTR "again\n", PRINT_MAC(peer_al_mac));
				map_dpp_trigger_member_dpp_intro(ctx, peer);
			}
		}
		break;

	case BSS_CONFIGURATION_REQUEST_MESSAGE:
		{
			if (ctx->role != CONTROLLER)
				break;

			/* parse bss configuration request message */
			if (parse_1905_bss_configuration_request_message(ctx, temp_buf, tlv_total_len, al_mac) < 0) {
				warn(DEBUG_CAT_DPP, "failed to parse bss config request message\n");
				break;
			}

			if (cont_handle_bss_configuration_request(ctx, al_mac) < 0)
				break;
		}
		break;

	case BSS_CONFIGURATION_RESPONSE_MESSAGE:
		{
			unsigned int conf_timer = 0;

			if (ctx->role != AGENT)
				break;
			/* need wait 5 secs before apply renew bss setting to wifi */
			if (ctx->r3_oboard_ctx.bss_renew)
				conf_timer = 5;
			ctx->r3_oboard_ctx.bss_renew = 0;

			if (ctx->r3_oboard_ctx.r3_config_state != wait_4_recv_bss_autoconfig_resp) {
				warn(DEBUG_CAT_DPP, "r3 config state mismatch\n");
				break;
			}
			if (parse_bss_configuration_response_message(ctx, temp_buf, tlv_total_len, al_mac) < 0) {
				warn(DEBUG_CAT_DPP, "failed to parse bss config rsp message\n");
				break;
			}
			eloop_cancel_timeout(r3_config_sm_step, (void *)ctx, NULL);
			r3_set_config_state(ctx, wait_4_set_r3_config);
			notice(DEBUG_CAT_DPP, "wait for apply R3 config\n");
			eloop_register_timeout(conf_timer, 0, r3_config_sm_step, (void *)ctx, NULL);
		}
		break;

	case BSS_CONFIGURATION_RESULT_MESSAGE:
		{
			struct agent_list_db *agent = NULL;

			if (ctx->role != CONTROLLER)
				break;
			find_agent_info(ctx, al_mac, &agent);

			insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr, e_agent_list, mid,
					ctx->itf[ctx->recent_cmdu_rx_if_number].if_name, 0);

			/* all band configured */
			if (agent)
				config_agent_all_radio_config_stat(agent);

			peer = get_r3_member(al_mac);
			if (peer) {
				info_hexdump(DEBUG_CAT_DPP, "peer hash", (unsigned char *)peer->chirp.hash_payload,
					 sizeof(hv_item->hashValue));
				/* one chirp value for each agent on controller */
				dl_list_for_each_safe(hv_item, hv_item_nxt,
						      &ctx->r3_dpp.hash_value_list, struct hash_value_item, member) {
					info_hexdump(DEBUG_CAT_DPP, "item hash", hv_item->hashValue, sizeof(hv_item->hashValue));
					info(DEBUG_CAT_DPP, "item almac " MACSTR "\n", PRINT_MAC(hv_item->almac));
					if ((!(os_memcmp(hv_item->almac, al_mac, ETH_ALEN)))
					    && hv_item->hashLen) {
						_1905_notify_onboarding_result(ctx, al_mac, 1, hv_item->hashValue,
									       hv_item->hashLen);
						info(DEBUG_CAT_DPP, "notify onboarding result to mapd\n");
						break;
					}
				}

				if (peer->security_1905 && (!ctx->MAP_Cer)) {
					info(DEBUG_CAT_DPP, "trigger GTK REKEY for " MACSTR "\n", PRINT_MAC(al_mac));
					check_trigger_gtk_rekey();
				}
			}
		}
		break;

	case BSS_RECONFIGURATION_TRIGGER_MESSAGE:
		{
			if (ctx->role != AGENT)
				break;
			reset_stored_tlv(ctx);

			insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr,
					e_1905_ack, mid, ctx->itf[ctx->recent_cmdu_rx_if_number].if_name, 0);

			if (ctx->r3_oboard_ctx.bss_renew) {
				notice(DEBUG_CAT_DPP, "R3 BSS Config renew is ongoing, skip this one\n");
				break;
			}
			notice(DEBUG_CAT_DPP, "received bss reconfig trigger msg from "MACSTR"\n",
				MAC2STR(al_mac));

			r3_set_config_state(ctx, wait_4_send_bss_autoconfig_req);
			notice(DEBUG_CAT_DPP, "change stage to [send bss config request]]\n");
			ctx->r3_oboard_ctx.bss_renew = 1;
			/* start bss config sm */
			eloop_cancel_timeout(r3_config_sm_step, (void *)ctx, NULL);
			eloop_register_timeout(0, 0, r3_config_sm_step, (void *)ctx, NULL);
		}
		break;

	case AGENT_LIST_MESSAGE:
		{
#ifdef EM_PLUS_EXT_SUPPORT
			if (ctx->security_enabled == 0) {
				debug(DEBUG_CAT_DPP, "1905 security is disabled. Agent list message not expected\n");
				break;
			}
#endif
			if (parse_agent_list_message(temp_buf, tlv_total_len) < 0) {
				warn(DEBUG_CAT_DPP, "parse agent list message error\n");
				break;
			}
			map_dpp_trigger_all_member_dpp_intro(ctx);
		}
		break;
#endif /* #ifdef MAP_R3 */
#ifdef MAP_R3_SP
	case SERVICE_PRIORITIZATION_REQUEST:
		{
			notice(DEBUG_CAT_SP, "receive SERVICE_PRIORITIZATION_REQUEST\n");

			if (ctx->role == CONTROLLER) {
				warn(DEBUG_CAT_SP, "BUG!! controller received SERVICE_PRIORITIZATION_REQUEST\n");
				break;
			}

			if (parse_sp_request_message(&ctx->sp_rule_static_list, &ctx->sp_rule_dynamic_list,
							&ctx->sp_rule_del_list, &ctx->sp_rule_learn_complete_list,
							&ctx->sp_dp_table, ctx->p1905_al_mac_addr,
#ifdef MAP_R5
							&ctx->qos_mgmt_desc_list,
#endif
							temp_buf, tlv_total_len, &ctx->revd_tlv) < 0) {
				warn(DEBUG_CAT_SP,  "failed to parse service prioritization request message\n");
				break;
			}
			insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr, e_1905_ack, mid, if_name, 0);

			if (ctx->revd_tlv.buf_len != 0) {
				_1905_notify_t2lm_request_notification_event(ctx, al_mac);
				break;
			}

#ifdef MAP_R5
		eloop_register_timeout(2, 0, qos_management_descriptor_tlv_check, (void *)ctx, NULL);
		eloop_register_timeout(2, 0, qos_management_dscp_mapping_tbl_check, (void *)ctx, NULL);
#endif
			/*
			 * if all rule lists are empty, means controller has removed all sp rules,
			 * so clear sp rule in local mapfilter
			 */
			if (dl_list_len(&ctx->sp_rule_static_list) == 0 && dl_list_len(&ctx->sp_rule_dynamic_list) == 0) {
				if (clear_sp_rules_of_local(&ctx->sp_rule_static_list, &ctx->sp_rule_dynamic_list) < 0) {
					warn(DEBUG_CAT_SP, "failed to clear sp rules of local\n");
					break;
				}
			} else {
				/*
				 * if non-mtk controller want to remove some rules which are inlcude in standard rule tlv,
				 * just clear it; for mtk controller, all sp rules will be cleared in clear_sp_rules_of_local
				 * at above.
				 */
				if (remove_sp_rules_of_local(&ctx->sp_rule_del_list) < 0)
					warn(DEBUG_CAT_SP, "failed to remove sp rules of local\n");

				if (apply_sp_rules_to_local(&ctx->sp_rule_static_list, &ctx->sp_rule_dynamic_list,
							    ctx->sp_dp_table.dptbl) < 0) {
					warn(DEBUG_CAT_SP, "failed to apply sp rules to local\n");
					break;
				}

				if (sp_rule_write_back_2_profile(&ctx->sp_rule_static_list, &ctx->sp_dp_table,
								 SP_RULE_FILE_PATH) < 0) {
					warn(DEBUG_CAT_SP, "failed to save sp rules\n");
					break;
				}
			}
		}
		break;
#endif
#ifdef MAP_R5
	case QOS_MANAGEMENT_NOTIFICATION:
	{
		if (ctx->role == AGENT) {
			warn(DEBUG_CAT_QOS, "Agent received QOS_MANAGEMENT_NOTIFICATION unexpectedly.\n");
			break;
		}
		process_qos_management_notification_message((void *)ctx, temp_buf, tlv_total_len);
		break;
	}
#endif

#ifdef MAP_R6
	case EARLY_AP_CAP_REPORT_MESSAGE:
		parse_early_apcap_report_message(ctx, temp_buf, tlv_total_len, al_mac);
		_1905_notify_early_apcap_report(ctx, al_mac);
		break;

	case AP_MLD_CONFIGURATION_REQUEST_MESSAGE:
		insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr, e_1905_ack, mid, if_name, 0);
		parse_ap_mld_request_message(ctx, temp_buf, tlv_total_len, al_mac);

		break;

	case AP_MLD_CONFIGURATION_RESPONSE_MESSAGE:
		parse_ap_mld_response_message(ctx, temp_buf, tlv_total_len, al_mac);
		break;

	case BSTA_MLD_CONFIGURATION_REQUEST_MESSAGE:
		insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr, e_1905_ack, mid, if_name, 0);
		parse_bsta_mld_request_message(ctx, temp_buf, tlv_total_len, al_mac);

		break;

	case BSTA_MLD_CONFIGURATION_RESPONSE_MESSAGE:
		parse_bsta_mld_response_message(ctx, temp_buf, tlv_total_len, al_mac);
		break;

	case AFC_SPECTRUM_INQUIRY_MESSAGE:
		insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr, e_1905_ack, mid, if_name, 0);
		parse_afc_spectrum_inquiry_message(ctx, temp_buf, tlv_total_len);
		_1905_notify_afc_spectrum_inquiry_event(ctx, al_mac);
		break;
#endif
	default:
		break;
	}
	return 0;
}



