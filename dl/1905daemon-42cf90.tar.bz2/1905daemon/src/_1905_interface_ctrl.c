/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <errno.h>
#include <assert.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/ipc.h>
#include <sys/types.h>
#include <sys/sem.h>
#include <stddef.h>
#include "interface.h"
#include "data_def.h"
#include "_1905_interface_ctrl.h"
#include "../inc/_1905_lib_internal.h"
#include "../inc/common.h"
#include "debug.h"

#ifdef CONFIG_MASK_MACADDR
#define PRINT_MAC(a) a[0],a[3],a[4],a[5]
#else
#define PRINT_MAC(a) a[0],a[1],a[2],a[3],a[4],a[5]
#endif


#define CMD_SUC_SYNC_EVENT 0
#define CMD_SUC_ASYNC_EVENT 1
#define CMD_PROCESS_FAIL 2

#ifndef BIT
#define BIT(x) (1U << (x))
#endif


#define TOPOLOGY_DISCOVERY      0x0000
#define TOPOLOGY_NOTIFICATION   0x0001
#define TOPOLOGY_QUERY          0x0002
#define TOPOLOGY_RESPONSE       0x0003
#define VENDOR_SPECIFIC         0x0004
#define LINK_METRICS_QUERY      0x0005
#define LINK_METRICS_RESPONSE   0x0006
#define AP_AUTOCONFIG_SEARCH    0x0007
#define AP_AUTOCONFIG_RESPONSE  0x0008
#define AP_AUTOCONFIG_WSC       0x0009
#define AP_AUTOCONFIG_RENEW     0x000A
#define P1905_PB_EVENT_NOTIFY   0x000B
#define P1905_PB_JOIN_NOTIFY    0x000C
#define SCLIENT_CAPABILITY_QUERY 0x000D
#define ICHANNEL_SELECTION_REQUEST 0x000E
#define Ack_1905 0x8000
#define AP_CAPABILITY_QUERY 0x8001
#define AP_CAPABILITY_REPORT 0x8002
#define MAP_POLICY_CONFIG_REQUEST 0x8003
#define CHANNEL_PREFERENCE_QUERY 0x8004
#define CHANNEL_PREFERENCE_REPORT 0x8005
#define CHANNEL_SELECTION_REQUEST 0x8006
#define CHANNEL_SELECTION_RESPONSE 0x8007
#define OPERATING_CHANNEL_REPORT 0x8008
#define CLIENT_CAPABILITY_QUERY 0x8009
#define CLIENT_CAPABILITY_REPORT 0x800A
#define AP_LINK_METRICS_QUERY 0x800B
#define AP_LINK_METRICS_RESPONSE 0x800C
#define ASSOC_STA_LINK_METRICS_QUERY 0x800D
#define ASSOC_STA_LINK_METRICS_RESPONSE 0x800E
#define UNASSOC_STA_LINK_METRICS_QUERY 0x800F
#define UNASSOC_STA_LINK_METRICS_RESPONSE 0x8010
#define BEACON_METRICS_QUERY 0x8011
#define BEACON_METRICS_RESPONSE 0x8012
#define COMBINED_INFRASTRUCTURE_METRICS 0x8013
#define CLIENT_STEERING_REQUEST 0x8014
#define CLIENT_STEERING_BTM_REPORT 0x8015
#define CLIENT_ASSOC_CONTROL_REQUEST 0x8016
#define CLIENT_STEERING_COMPLETED 0x8017
#define HIGHER_LAYER_DATA_MESSAGE 0x8018
#define BACKHAUL_STEERING_REQUEST 0x8019
#define BACKHAUL_STEERING_RESPONSE 0x801A
/*channel scan feature*/
#define CHANNEL_SCAN_REQUEST 0x801B
#define CHANNEL_SCAN_REPORT 0x801C
/*  DPP CCE Indication */
#define DPP_CCE_INDICATION_MESSAGE 0x801D

/* DFS CAC */
#define CAC_REQUEST 0x8020
#define CAC_TERMINATION 0x8021
#define CLIENT_DISASSOCIATION_STATS 0x8022
#define SERVICE_PRIORITIZATION_REQUEST 0x8023
#define ASSOCIATION_STATUS_NOTIFICATION 0x8025
#define TUNNELED_MESSAGE 0x8026
#define BACKHAUL_STA_CAP_QUERY_MESSAGE 0x8027
#define BACKHAUL_STA_CAP_REPORT_MESSAGE 0x8028
#define PROXIED_ENCAP_DPP_MESSAGE 0x8029
#define DIRECT_ENCAP_DPP_MESSAGE 0x802A
#define BSS_RECONFIGURATION_TRIGGER_MESSAGE 0x802B
#define BSS_CONFIGURATION_REQUEST_MESSAGE 0x802C
#define BSS_CONFIGURATION_RESPONSE_MESSAGE 0x802D
#define BSS_CONFIGURATION_RESULT_MESSAGE 0x802E
#define CHIRP_NOTIFICATION_MESSAGE 0x802F
#define _1905_ENCAP_EAPOL 0x8030
#define DPP_BOOTSTRAPING_URI_NOTIFICATION 0x8031
#define DPP_BOOTSTRAPING_URI_QUERY 0x8032
#define FAILED_CONNECTION_MESSAGE 0x8033
#define DPP_URI_NOTIFICATION_MESSAGE 0x8034
#define QOS_MANAGEMENT_NOTIFICATION 0x8037
#define DEV_SEND_1905_REQUEST 0x9000

#define STA_LEAVE 0
#define STA_JOIN (1 << 7)

unsigned char _1905_multicast_address[6]
                    = { 0x01, 0x80, 0xc2, 0x00, 0x00, 0x13 };

#define MAX_LIBBUF_LEN 40960
unsigned char cmdu_buf[MAX_LIBBUF_LEN] = {0};

int _1905_interface_ctrl_send(struct _1905_context *ctrl, const char *cmd, size_t cmd_len)
{
	struct os_time started_at;
	const char *_cmd;
	size_t _cmd_len;
	int _error = 0;

	_cmd = cmd;
	_cmd_len = cmd_len;
	started_at.sec = 0;
	started_at.usec = 0;
retry_send:
	if (send(ctrl->s, _cmd, _cmd_len, 0) < 0) {
		_error = errno;
		if (errno == EAGAIN || errno == EBUSY || errno == EWOULDBLOCK) {
			/*
			 * Must be a non-blocking socket... Try for a bit
			 * longer before giving up.
			 */
			if (started_at.sec == 0) {
				os_get_time(&started_at);
			} else {
				struct os_time n;
				os_get_time(&n);
				/* Try for a few seconds. */
				if (os_reltime_expired(&n, &started_at, 5)) {
					notice(DEBUG_CAT_EVENT, "os_reltime_expired; errno=%d(%s); retry\n",
						_error, strerror(_error));
					return -2;
				}
			}
			os_sleep(0, 10000);
			goto retry_send;
		}
		err(DEBUG_CAT_EVENT, "send fail; error=%d(%s)\n", _error, strerror(_error));
		return -1;
	}
	return 0;
}


int _1905_interface_ctrl_request(struct _1905_context *ctrl, const char *cmd, size_t cmd_len) {
	int ret = 0;
	unsigned short buf_len = 0;
	struct timeval tv;
	unsigned char recv_buf[50] = {0};
	size_t rev_buf_len = sizeof(recv_buf);
	struct msg *recv_event = NULL, *send_event = NULL;
	unsigned char rsp = 0;
	unsigned short change_buf_len = 0;
	struct os_time now;
	struct os_time started;

	os_memset(&now, 0, sizeof(struct os_time));
	os_memset(&started, 0, sizeof(struct os_time));

	if (!cmd || !cmd_len) {
		err(DEBUG_CAT_EVENT, "invalid input parameters; cmd=%p; cmd_len=%zu\n",
			cmd, cmd_len);
		return -1;
	}

	if (strncmp(cmd, "ATTACH:", strlen("ATTACH:")) == 0 || strncmp(cmd, "DETACH", strlen("DETACH")) == 0) {
		ret = _1905_interface_ctrl_send(ctrl, cmd, cmd_len);
		return ret;
	}
	buf_len = ctrl->peer_recv_buf_len;
	send_event = (struct msg *)cmd;

	if (cmd_len > buf_len)
		change_buf_len = cmd_len;
	else if (ctrl->default_peer_recv_len < buf_len && cmd_len <= ctrl->default_peer_recv_len)
		change_buf_len = ctrl->default_peer_recv_len;

	if(change_buf_len == 0) {
		ret = _1905_interface_ctrl_send(ctrl, cmd, cmd_len);
	} else {
		notice(DEBUG_CAT_EVENT, "send LIB_SYNC_RECV_BUF_SIZE to 1905 to adjust size;"
			" change_buf_len=%d; cmd_len=%zu; peer_recv_buf_len=%d; default_peer_recv_len=%d\n",
			change_buf_len, cmd_len, ctrl->peer_recv_buf_len, ctrl->default_peer_recv_len);
		ret  = _1905_Sync_Recv_Buf_Size(ctrl, change_buf_len, ctrl->own_recv_buf_len);
		if (ret < 0) {
			err(DEBUG_CAT_EVENT, "send LIB_SYNC_RECV_BUF_SIZE fail\n");
			return ret;
		}
		tv.tv_sec = 3;
		tv.tv_usec = 0;
		os_get_time(&started);
		while (1) {
			if (_1905_interface_ctrl_pending(ctrl, &tv)) {
				errno = 0;
				if (_1905_Receive(ctrl, (char *)recv_buf, &rev_buf_len) < 0) {
					err(DEBUG_CAT_EVENT, "_1905_Receive fail; errno=%d(%s)\n", errno, strerror(errno));
					return -1;
				}
				recv_event = (struct msg *)recv_buf;
				if (recv_event->type == _1905_SYNC_RECV_BUF_SIZE_RSP_EVENT) {
					change_buf_len = 0;
					memcpy(&change_buf_len, recv_event->buffer, sizeof(change_buf_len));
					rsp = recv_event->buffer[sizeof(change_buf_len)];
					notice(DEBUG_CAT_EVENT, "receive _1905_SYNC_RECV_BUF_SIZE_RSP_EVENT from 1905;"
						"change_buf_len=%d; rsp=%d(%s)\n", change_buf_len, rsp,
						(rsp == 1) ? "success" : "fail");
					if (rsp == 1) {
						if (!ctrl->peer_recv_buf_len && !ctrl->default_peer_recv_len)
							ctrl->default_peer_recv_len = change_buf_len;
						ctrl->peer_recv_buf_len = change_buf_len;
						ret = _1905_interface_ctrl_send(ctrl, cmd, cmd_len);
						return ret;
					} else {
						err(DEBUG_CAT_EVENT, "receive _1905_SYNC_RECV_BUF_SIZE_RSP_EVENT fail;"
							" drop send_event; type=0x%04x\n",
							send_event->type);
						return -1;
					}
				} else {
					notice(DEBUG_CAT_EVENT, "not _1905_SYNC_RECV_BUF_SIZE_RSP_EVENT; "
						"drop recv_event; type=0x%04x\n", recv_event->type);
				}
			} else {
				err(DEBUG_CAT_EVENT, "%lds timeout! no _1905_SYNC_RECV_BUF_SIZE_RSP_EVENT from 1905; "
					"drop send_event; type=0x%04x\n", tv.tv_sec, send_event->type);
				return -2;
			}

			os_get_time(&now);
			if (os_reltime_expired(&now, &started, (os_time_t)tv.tv_sec)) {
				err(DEBUG_CAT_EVENT, "wait for _1905_SYNC_RECV_BUF_SIZE_RSP_EVENT timeout; drop send_event;"
					" type=0x%04x\n", send_event->type);
				return -2;
			}
		}
	}

	return ret;
}

int _1905_interface_ctrl_attach_helper(struct _1905_context *ctrl, int attach, char* daemon)
{
	char buf[10];
	int ret;
	size_t len = 10;
	struct timeval tv;
	char request_buf[64];

	memset(request_buf, 0, sizeof(request_buf));
	memset(buf, 0, sizeof(buf));
	ret = snprintf(request_buf, sizeof(request_buf), attach ? "ATTACH:%s" : "DETACH:%s", daemon);
	if (os_snprintf_error(sizeof(request_buf), ret)) {
		err(DEBUG_CAT_EVENT, "snprintf fail!\n");
		return -1;
	}
	tv.tv_sec = 3;
	tv.tv_usec = 0;
	ret = _1905_interface_ctrl_request(ctrl, request_buf, strlen(request_buf));
	if (ret < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return ret;
	}
	if (_1905_interface_ctrl_pending(ctrl, &tv)) {
		if(_1905_Receive(ctrl, buf, &len) < 0) {
			err(DEBUG_CAT_EVENT, "_1905_Receive fail; errno=%d(%s)\n", errno, strerror(errno));
			return -1;
		}
	} else {
		err(DEBUG_CAT_EVENT, "3s timeout; no rsp from 1905daemon\n");
	}
	if (len == 3 && memcmp(buf, "OK\n", 3) == 0)
		return 0;

	return -1;
}


int _1905_interface_ctrl_attach(struct _1905_context *ctrl, char* daemon)
{
#define INIT_RETRY_TIME 10
	int i = 0;

	for (i = 0; i < INIT_RETRY_TIME; i++) {
		if (_1905_interface_ctrl_attach_helper(ctrl, 1, daemon) == 0)
			break;
		os_sleep(1, 0);
	}

	if (i >= INIT_RETRY_TIME)
		return -1;

	return 0;
}

#ifdef EM_PLUS_SUPPORT
void get_tid_q_size(unsigned char *tid_q_size)
{
	FILE *file;
	char *ptr;
	char line[256];
	int tid_q_size_tmp = 0;
	int q_size_unit = 256;/*the The queue size's unit is 256 bytes specified by the protocol.*/
	static const char search_str[] = "The max/min quota pages of HIF group=";

	file = fopen("/sys/kernel/debug/ieee80211/phy0/mt76/ple_info", "r");
	if (!file) {
		err(DEBUG_CAT_EMPLUS, "Error open file %s\n", strerror(errno));
		return;
	}

	while (fgets(line, sizeof(line), file)) {
		ptr = strstr(line, search_str);
		if (ptr != NULL) {
			if (sscanf(ptr, "The max/min quota pages of HIF group=%x", &tid_q_size_tmp) == EOF) {
				err(DEBUG_CAT_EMPLUS, "sscanf fail\n");
				goto error;
			}
			break;
		}
	}

	tid_q_size_tmp = tid_q_size_tmp * 64 / TID_CNT / q_size_unit;
	tid_q_size_tmp = tid_q_size_tmp > 254 ? 254 : tid_q_size_tmp;
	*tid_q_size = (unsigned char)tid_q_size_tmp;
	info(DEBUG_CAT_EMPLUS, "tid_q_size = %d\n", *tid_q_size);
error:
	if (fclose(file))
		err(DEBUG_CAT_EMPLUS, "fclose fail: %s", strerror(errno));
}
#endif /* EM_PLUS_SUPPORT */

int _1905_interface_ctrl_detach(struct _1905_context *ctrl)
{
	return _1905_interface_ctrl_attach_helper(ctrl, 0, "");
}

struct _1905_context * _1905_Init(const char *local_path)
{
	struct _1905_context *ctrl;
	static int counter = 0;
	int nameLen = 0;
	int tries = 0;
	int flags;
	int path_len = 0;
	int local_path_len = 0, sock_path_len = 0;
	int nSndBufLen = 0,nRcvBufLen = 0;
	socklen_t optlen = sizeof(int);
	char *daemon = NULL;
	int ret;

	local_path_len = strlen(local_path);
	sock_path_len = sizeof(ctrl->local.sun_path);
	if (path_len >= sock_path_len) {
		err(DEBUG_CAT_EVENT, "len too long; local_path_len(%d) >= sock_path_len(%d)"
		" local_path=%s\n", local_path_len, sock_path_len, local_path);
		return NULL;
	}
	notice(DEBUG_CAT_EVENT, "local_path=%s\n", local_path);

	daemon = malloc(strlen(local_path) + 1);
	if (!daemon) {
		err(DEBUG_CAT_MISC, "alloc %d size buffer fail\n", local_path_len + 1);
		return NULL;
	}
	ret = snprintf(daemon, strlen(local_path) + 1, "%s", local_path);
	if (os_snprintf_error(strlen(local_path) + 1, ret)) {
		err(DEBUG_CAT_EVENT, "snprintf fail!\n");
		free(daemon);
		return NULL;
	}

	ctrl = (struct _1905_context *)malloc(sizeof(*ctrl));
	if (ctrl == NULL) {
		err(DEBUG_CAT_MISC, "alloc struct _1905_context fail\n");
		free(daemon);
		return NULL;
	}
	memset(ctrl, 0, sizeof(*ctrl));

	errno = 0;
	ctrl->s = socket(PF_UNIX, SOCK_DGRAM, 0);
	if (ctrl->s < 0) {
		err(DEBUG_CAT_EVENT, "create socket fail; errno=%d(%s)\n",
			errno, strerror(errno));
		free(ctrl);
		free(daemon);
		return NULL;
	}

	/* set send buf as 1M */
	if (getsockopt(ctrl->s, SOL_SOCKET, SO_SNDBUF, (void *)&nSndBufLen, &optlen) < 0)
		nSndBufLen = 1024*1024;
	else
		nSndBufLen = nSndBufLen * 2;

	/* set recv buf as 1M */
	if (getsockopt(ctrl->s, SOL_SOCKET, SO_RCVBUF, (void *)&nRcvBufLen, &optlen) < 0)
		nRcvBufLen = 1024*1024;
	else
		nRcvBufLen = nRcvBufLen * 2;

#ifdef EM_PLUS_SUPPORT
	/*get tid queue size*/
	get_tid_q_size(&ctrl->tid_q_size);
#endif /* EM_PLUS_SUPPORT */

	notice(DEBUG_CAT_EVENT, "setsockopt: nSndBufLen=%d; nRcvBufLen=%d\n", nSndBufLen, nRcvBufLen);

	errno = 0;
	if (setsockopt(ctrl->s, SOL_SOCKET, SO_SNDBUF, (const char *)&nSndBufLen, sizeof(int)) < 0)
		warn(DEBUG_CAT_EVENT, "set nSndBufLen failed; errno=%d(%s)\n", errno, strerror(errno));

	errno = 0;
	if (setsockopt(ctrl->s, SOL_SOCKET, SO_RCVBUF, (const char *)&nRcvBufLen, sizeof(int)) < 0)
		warn(DEBUG_CAT_EVENT, "set nRcvBufLen failed; errno=%d(%s)\n", errno, strerror(errno));

	ctrl->local.sun_family = AF_UNIX;
	counter++;
try_again:
    ctrl->local.sun_path[0] = '\0';  /* abstract namespace */
	ret = snprintf(ctrl->local.sun_path + 1, sizeof(ctrl->local.sun_path) - 1, "%s", local_path);
	if (os_snprintf_error(sizeof(ctrl->local.sun_path) - 1, ret)) {
		err(DEBUG_CAT_EVENT, "snprintf fail!\n");
		close(ctrl->s);
		free(ctrl);
		free(daemon);
		return NULL;
	}
    path_len = 1 + nameLen + offsetof(struct sockaddr_un, sun_path);
	tries++;
	errno = 0;
	if (bind(ctrl->s, (struct sockaddr *) &ctrl->local,
		    path_len) < 0) {
		if (errno == EADDRINUSE && tries < 2) {
			/*
			 * getpid() returns unique identifier for this instance
			 * of wpa_ctrl, so the existing socket file must have
			 * been left by unclean termination of an earlier run.
			 * Remove the file and try again.
			 */
			/*for abstract socket path, no need to unlink it*/
//			unlink(ctrl->local.sun_path);
			goto try_again;
		}
		err(DEBUG_CAT_EVENT, "bind fail; errno=%d(%s)\n", errno, strerror(errno));
		close(ctrl->s);
		free(ctrl);
		free(daemon);
		return NULL;
	}

	ctrl->dest.sun_family = AF_UNIX;
	nameLen = strlen("1905_daemon");
    ctrl->dest.sun_path[0] = '\0';  /* abstract namespace */
	ret = snprintf(ctrl->dest.sun_path + 1, sizeof(ctrl->dest.sun_path) - 1, "%s", "1905_daemon");
	if (os_snprintf_error(sizeof(ctrl->dest.sun_path) - 1, ret)) {
		err(DEBUG_CAT_EVENT, "snprintf fail!\n");
		close(ctrl->s);
		free(ctrl);
		free(daemon);
		return NULL;
	}
    path_len = 1 + nameLen + offsetof(struct sockaddr_un, sun_path);

	errno = 0;
	if (connect(ctrl->s, (struct sockaddr *) &ctrl->dest,
		    path_len) < 0) {
		err(DEBUG_CAT_EVENT, "connect fail; errno=%d(%s)\n", errno, strerror(errno));
		close(ctrl->s);
		/*for abstract socket path, no need to unlink it*/
//		unlink(ctrl->local.sun_path);
		free(ctrl);
		free(daemon);
		return NULL;
	}

	/*
	 * Make socket non-blocking so that we don't hang forever if
	 * target dies unexpectedly.
	 */
	flags = fcntl(ctrl->s, F_GETFL);
	if (flags >= 0) {
		flags |= O_NONBLOCK;
		errno = 0;
		if (fcntl(ctrl->s, F_SETFL, flags) < 0)
			warn(DEBUG_CAT_EVENT, "fcntl O_NONBLOCK fail; errno=%d(%s)\n",
				errno, strerror(errno));
			/* Not fatal, continue on.*/
	}

	ctrl->own_recv_buf_len = 0;
	ctrl->default_own_recv_len = 0;
	ctrl->peer_recv_buf_len = 0;
	ctrl->default_peer_recv_len = 0;
	ctrl->s_buf = NULL;

	if (_1905_interface_ctrl_attach(ctrl, daemon)) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_attach fail\n");
		close(ctrl->s);
		free(ctrl);
		free(daemon);
		return NULL;
	}
	free(daemon);

	return ctrl;
}

void _1905_Deinit(struct _1905_context *ctrl)
{
	if (_1905_interface_ctrl_detach(ctrl))
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_detach fail\n");
//	unlink(ctrl->local.sun_path);
	if (ctrl->s >= 0)
		close(ctrl->s);
	free(ctrl);
}

int _1905_Receive(struct _1905_context *ctrl, char *reply, size_t *reply_len)
{
	int res;

	res = recv(ctrl->s, reply, *reply_len, 0);
	if (res < 0)
		return res;
	*reply_len = res;
	return 0;
}


int _1905_interface_ctrl_pending(struct _1905_context *ctrl, struct timeval *tv)
{
	fd_set rfds;
	FD_ZERO(&rfds);
	FD_SET(ctrl->s, &rfds);
	select(ctrl->s + 1, &rfds, NULL, NULL, tv);
	return FD_ISSET(ctrl->s, &rfds);
}


int _1905_interface_ctrl_get_fd(struct _1905_context *ctrl)
{
	return ctrl->s;
}

int _1905_Set_Role(IN struct _1905_context *ctx, enum MAP_ROLE role)
{
	struct msg *cmd = (struct msg* )cmdu_buf;
	struct manage_cmd *_manage_cmd = (struct manage_cmd*)cmd->buffer;
	struct timeval tv;
	size_t len = sizeof(cmdu_buf);

	memset(cmdu_buf, 0, sizeof(cmdu_buf));
	tv.tv_sec = 3;
	tv.tv_usec = 0;
	cmd->type = MANAGEMENT_1905_COMMAND;
	cmd->length = sizeof(struct manage_cmd) + 1;
	_manage_cmd->cmd_id = MANAGE_SET_ROLE;
	_manage_cmd->len = 1;
	_manage_cmd->content[0] = (unsigned char)role;

	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		if (_1905_interface_ctrl_pending(ctx, &tv)) {
			if (_1905_Receive(ctx, (char*)cmdu_buf, &len) < 0) {
				warn(DEBUG_CAT_EVENT, "3s timeout; no rsp\n");
				return -1;
			}
		}
		if (len == 3 && memcmp(cmdu_buf, "OK\n", 3) == 0)
			return 0;
		err(DEBUG_CAT_EVENT, "set role(%d) fail\n", role);
		return -1;
	}
}

#define ENOUGH_CHECK(org, cur, step, total_len){	\
	if((unsigned short)((cur - org) + (step)) > (total_len)) { \
		err(DEBUG_CAT_EVENT, "not enough buffer; (cur-org)=%d; step=%d; total_len=%d\n", (int)(cur - org), step, total_len);	\
		return -1;\
	}	\
}

int _1905_Get_Local_Devinfo(IN struct _1905_context *ctx, OUT struct device_info *dev_info,
	OUT struct bridge_cap *br_cap, OUT struct supported_srv *srv)
{
	struct msg *cmd = (struct msg* )cmdu_buf;
	struct manage_cmd *_manage_cmd = (struct manage_cmd*)cmd->buffer;
	struct timeval tv;
	size_t len = sizeof(cmdu_buf);
	unsigned char *p = NULL;
	unsigned short len_body = 0;
	unsigned char i = 0;
	int charlen = sizeof(unsigned char);
	int shortlen = sizeof(unsigned short);

	if (dev_info == NULL) {
		err(DEBUG_CAT_EVENT, "dev_info NULL pointer");
		goto fail;
	}

	if (br_cap == NULL || srv == NULL) {
		err(DEBUG_CAT_EVENT, "NULL pointer; br_cap=%p; srv=%p\n", br_cap, srv);
		goto fail;
	}

	memset(cmdu_buf, 0, sizeof(cmdu_buf));
	tv.tv_sec = 3;
	tv.tv_usec = 0;
	cmd->type = MANAGEMENT_1905_COMMAND;
	cmd->length = sizeof(struct manage_cmd);
	_manage_cmd->cmd_id = MANAGE_GET_LOCAL_DEVINFO;
	_manage_cmd->len = 0;

	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		goto fail;
	} else {
		if (_1905_interface_ctrl_pending(ctx, &tv)) {
			if (_1905_Receive(ctx, (char*)cmdu_buf, &len) < 0) {
				err(DEBUG_CAT_EVENT, "3s timeout; no rsp\n");
				goto fail;
			}
		}

		p = cmdu_buf;

		ENOUGH_CHECK(cmdu_buf, p, shortlen, (int)len);
		if (*(unsigned short*)p != MANAGE_GET_LOCAL_DEVINFO) {
			err(DEBUG_CAT_EVENT, "raw data from 1905 is wrong\n");
			goto fail;
		}
		p += sizeof(unsigned short);

		/*mid*/
		ENOUGH_CHECK(cmdu_buf, p, shortlen, (int)len);
		p += sizeof(unsigned short);

		ENOUGH_CHECK(cmdu_buf, p, shortlen, (int)len);
		len_body = *(unsigned short*)p;
		if (len_body != len - 6) {
			err(DEBUG_CAT_EVENT, "len pre check fail\n");
			goto fail;
		}
		p += sizeof(unsigned short);

		/*dev info*/
		ENOUGH_CHECK(cmdu_buf, p, ETH_ALEN, (int)len);
		memcpy(dev_info->al_mac, p, ETH_ALEN);
		p += ETH_ALEN;

		ENOUGH_CHECK(cmdu_buf, p, charlen, (int)len);
		dev_info->inf_num = *p++;

		ENOUGH_CHECK(cmdu_buf, p, (ETH_ALEN + (unsigned int)shortlen) * dev_info->inf_num, (int)len);
		for (i = 0; i < dev_info->inf_num; i++) {
			memcpy(dev_info->inf_info[i].mac, p, ETH_ALEN);
			p += ETH_ALEN;
			dev_info->inf_info[i].media_type = *(unsigned short*)p;
			p += sizeof(unsigned short);
		}

		/*bridge info*/
		ENOUGH_CHECK(cmdu_buf, p, charlen, (int)len);
		br_cap->br_num = *p++;

		for (i = 0; i < br_cap->br_num; i++) {
			ENOUGH_CHECK(cmdu_buf, p, charlen, (int)len);
			unsigned char br_name_len = *p++;

			ENOUGH_CHECK(cmdu_buf, p, br_name_len, (int)len);
			if (br_name_len >= IFNAMSIZ - 1)
				br_name_len = IFNAMSIZ - 1;
			os_strncpy(br_cap->bridge_info[i].br_name, (char*)p, br_name_len);
			br_cap->bridge_info[i].br_name[IFNAMSIZ - 1] = '\0';
			p += br_name_len;

			ENOUGH_CHECK(cmdu_buf, p, charlen, (int)len);
			br_cap->bridge_info[i].inf_num = *p++;

			ENOUGH_CHECK(cmdu_buf, p, br_cap->bridge_info[i].inf_num * ETH_ALEN, (int)len);
			os_memcpy(br_cap->bridge_info[i].inf_mac, p, br_cap->bridge_info[i].inf_num * ETH_ALEN);
			p += br_cap->bridge_info[i].inf_num * ETH_ALEN;
		}

		/*supported service*/
		ENOUGH_CHECK(cmdu_buf, p, charlen, (int)len);
		srv->srv_num = *p++;

		ENOUGH_CHECK(cmdu_buf, p, srv->srv_num, (int)len);
		os_memcpy(srv->srv, p, srv->srv_num);
	}
	return 0;
fail:
	return -1;
}


int _1905_Set_Radio_Basic_Cap (IN struct _1905_context* ctx,
	IN struct ap_radio_basic_cap * cap)
{
	struct msg *cmd = (struct msg* )cmdu_buf;
	int len = 0;

	if (cap == NULL) {
		err(DEBUG_CAT_EVENT, "cap NULL pointer\n");
		return -1;
	}
	cmd->type = LIB_RADIO_BASIC_CAP;
	len = sizeof(struct ap_radio_basic_cap) + cap->op_class_num * sizeof(struct radio_basic_cap);
	cmd->length = len;
	memcpy(cmd->buffer, (unsigned char*)cap, len);
	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + len) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	}else {
		return 0;
	}
}

int _1905_Set_Channel_Preference_Report_Info (IN struct _1905_context* ctx,
	IN int ch_prefer_cnt, IN struct ch_prefer_lib * ch_prefers,
	IN int restriction_cnt, IN struct restriction_lib *restrictions,
	IN struct cac_completion_report_lib  *cac_rep
#ifdef MAP_R2
	, IN struct cac_status_report_lib  *cac_status_rep
#endif
	, IN unsigned short mid
	)
{
	unsigned short len = 0;
	struct msg *cmd = (struct msg* )cmdu_buf;
	unsigned char* p = NULL;
	unsigned char* p_old = NULL;
	int i = 0, j = 0, k = 0;

	if ((ch_prefer_cnt > 0 && ch_prefers == NULL) || (restriction_cnt > 0 && restrictions == NULL)) {
		err(DEBUG_CAT_EVENT, "%s null pointer\n", (ch_prefers == NULL) ? "ch_prefers" : "restrictions");
		return -1;
	}
	p = cmd->buffer;
	cmd->type = WAPP_CHANNEL_PREFERENCE_REPORT_INFO;
	cmd->mid = mid;

	for (i = 0; i < ch_prefer_cnt; i++) {
		*p++ = 0x8B;

		p_old = p;
		p += 2;
		memcpy(p, ch_prefers->identifier, ETH_ALEN);
		p += ETH_ALEN;

		*p++ = ch_prefers->op_class_num;
		for (j = 0; j < ch_prefers->op_class_num; j++) {
			*p++ = ch_prefers->opinfo[j].op_class;
			*p++ = ch_prefers->opinfo[j].ch_num;
			memcpy(p, ch_prefers->opinfo[j].ch_list, ch_prefers->opinfo[j].ch_num);
			p += ch_prefers->opinfo[j].ch_num;
			*p++ = (((ch_prefers->opinfo[j].perference & 0x0F) << 4) | (ch_prefers->opinfo[j].reason & 0x0F));
		}
		len = (unsigned short)(p - p_old) - 2;
		*((unsigned short*)p_old) = host_to_be16(len);
		ch_prefers++;
	}

	for (i = 0; i < restriction_cnt; i++) {
		*p++ = 0x8C;

		p_old = p;
		p += 2;
		memcpy(p, restrictions->identifier, ETH_ALEN);
		p += ETH_ALEN;

		*p++ = restrictions->op_class_num;
		for (j = 0; j < restrictions->op_class_num; j++) {
			*p++ = restrictions->opinfo[j].op_class;
			*p++ = restrictions->opinfo[j].ch_num;
			for (k = 0; k < restrictions->opinfo[j].ch_num; k++) {
				*p++ = restrictions->opinfo[j].ch_list[k];
				*p++ = restrictions->opinfo[j].fre_separation[k];
			}
		}
		len = (unsigned short)(p - p_old) - 2;
		*((unsigned short*)p_old) = host_to_be16(len);
		restrictions = (struct restriction_lib *) ((char *)restrictions +
				(sizeof(struct restriction_lib) + (restrictions->op_class_num * sizeof(struct restrict_info))));
	}

	if (cac_rep) {
		struct cac_completion_status_lib  *p_cac_status = NULL;
		struct cac_completion_report_opcap *p_opcap = NULL;

		*p++ = 0xAF;

		p_old = p;
		p += 2;
		*p++ = cac_rep->radio_num;

		p_cac_status = cac_rep->cac_completion_status;
		for (i = 0; i < cac_rep->radio_num; i++) {
			memcpy(p, p_cac_status->identifier, ETH_ALEN);
			p += ETH_ALEN;

			*p++ = p_cac_status->op_class;

			*p++ = p_cac_status->channel;

			*p++ = p_cac_status->cac_status;

			*p++ = p_cac_status->op_class_num;

			p_opcap = p_cac_status->opcap;
			for (j = 0; j <p_cac_status->op_class_num; j++) {
				*p++ = p_opcap->op_class;
				*p++ = p_opcap->ch_num;

				p_opcap++;
			}

			p_cac_status = (struct cac_completion_status_lib *)((char *)p_cac_status + sizeof(struct cac_completion_status_lib) +
				p_cac_status->op_class_num * sizeof(struct cac_completion_report_opcap));
		}
		len = (unsigned short)(p - p_old) - 2;
		*((unsigned short*)p_old) = host_to_be16(len);
	}
#ifdef MAP_R2
	if (cac_status_rep) {
		struct cac_allowed_channel *p_allowed_channel = NULL;
		struct cac_non_allowed_channel *p_non_allowed_channel = NULL;
		struct cac_ongoing_channel *p_ongoing_channel = NULL;
		/* CAC Status Report TLV. */
		*p++ = 0xB1;

		/* length */
		p_old = p;
		p += 2;

		/* Number of channels the Multi-AP Agent indicates is Available Channels */
		*p++ = cac_status_rep->allowed_channel_num;

		p_allowed_channel = cac_status_rep->allowed_channel;
		for (i = 0; i < cac_status_rep->allowed_channel_num; i++) {
			*p++ = p_allowed_channel->op_class;

			*p++ = p_allowed_channel->ch_num;

			*((unsigned short *)p) = host_to_be16(p_allowed_channel->cac_interval);
			p += 2;

			p_allowed_channel ++;
		}

		/* Number of class/channel pairs the Multi-AP Agent indicates
		** are on the non-occupancy list due to detection of radar
		*/
		*p++ = cac_status_rep->non_allowed_channel_num;

		p_non_allowed_channel = cac_status_rep->non_allowed_channel;
		for (i = 0; i < cac_status_rep->non_allowed_channel_num; i++) {
			*p++ = p_non_allowed_channel->op_class;

			*p++ = p_non_allowed_channel->ch_num;

			*((unsigned short *)p) = host_to_be16(p_non_allowed_channel->remain_interval);
			p += 2;

			p_non_allowed_channel++;
		}

		/* Number of class/channel pairs that have an active CAC ongoing */
		*p++ = cac_status_rep->ongoing_cac_channel_num;

		p_ongoing_channel = cac_status_rep->cac_ongoing_channel;
		for (i = 0; i < cac_status_rep->ongoing_cac_channel_num; i++) {
			*p++ = p_ongoing_channel->op_class;

			*p++ = p_ongoing_channel->ch_num;

			*p++ = p_ongoing_channel->remain_interval;
			*p++ = p_ongoing_channel->remain_interval >> 8;
			*p++ = p_ongoing_channel->remain_interval >> 16;

			p_ongoing_channel++;
		}

		len = (unsigned short)(p - p_old) - 2;
		*((unsigned short*)p_old) = host_to_be16(len);
	}
#endif //#ifdef MAP_R2


	cmd->length = (unsigned short)(p - cmd->buffer);

	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}

int _1905_Set_Channel_Selection_Rsp_Info (IN struct _1905_context* ctx,
	IN struct ch_sel_rsp_info *rsp_info, IN unsigned char rsp_cnt
#ifdef MAP_R4_SPT
	, IN struct ch_sel_rsp_info *spt_reuse_rsp_info, IN unsigned char spt_reuse_rsp_cnt
#endif
	, IN unsigned short mid
	)
{
	struct msg *cmd = (struct msg* )cmdu_buf;
	unsigned char *p = cmd->buffer;
	int i = 0;
	cmd->type = WAPP_CHANNEL_SELECTION_RSP_INFO;
	cmd->mid = mid;

	if ((rsp_cnt == 0 || rsp_info == NULL)
#ifdef MAP_R4_SPT
		&&(spt_reuse_rsp_cnt == 0 || spt_reuse_rsp_info == NULL)
#endif
	) {
		err(DEBUG_CAT_EVENT, "%s\n", (rsp_cnt == 0) ? "rsp_cnt invalid value" : "rsp_info NULL pointer");
		return -1;
	}
	for (i = 0; i < rsp_cnt && rsp_info; i++) {
		/*Channel Sleection Response TLV*/
		*p++ = 0x8E;

		*p++ = 0;
		*p++ = 7;
		memcpy(p, rsp_info->radio_indentifier, ETH_ALEN);
		p += ETH_ALEN;
		*p++ = rsp_info->rsp_code;
		rsp_info++;
	}
#ifdef MAP_R4_SPT
	for (i = 0; i < spt_reuse_rsp_cnt && spt_reuse_rsp_info; i++) {
		/*spatial reuse config Response TLV*/
		/* DM: need to improve tlv no*/
		*p++ = 0xDA;

		*p++ = 0;
		*p++ = 7;
		memcpy(p, spt_reuse_rsp_info->radio_indentifier, ETH_ALEN);
		p += ETH_ALEN;
		*p++ = spt_reuse_rsp_info->rsp_code;
		spt_reuse_rsp_info++;
	}
#endif
	cmd->length = (unsigned short)(p - cmd->buffer);

	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}



int _1905_Set_Ap_Cap (IN struct _1905_context* ctx,
	IN struct ap_capability *cap)
{
	struct msg *cmd = (struct msg* )cmdu_buf;

	if (cap == NULL) {
		err(DEBUG_CAT_EVENT, "cap NULL pointer\n");
		return -1;
	}
	cmd->type = LIB_AP_CAPABILITY;
	cmd->length = sizeof(struct ap_capability);
	memcpy(cmd->buffer, (unsigned char*)cap, cmd->length);
	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}

int _1905_Set_Ap_Ht_Cap (IN struct _1905_context* ctx,
	IN struct ap_ht_capability *cap)
{
	struct msg *cmd = (struct msg* )cmdu_buf;

	if (cap == NULL) {
		err(DEBUG_CAT_EVENT, "cap NULL pointer\n");
		return -1;
	}
	cmd->type = LIB_AP_HT_CAPABILITY;
	cmd->length = sizeof(struct ap_ht_capability);
	memcpy(cmd->buffer, (unsigned char*)cap, cmd->length);
	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}

int _1905_Set_Ap_Vht_Cap (IN struct _1905_context* ctx,
	IN struct ap_vht_capability *cap)
{
	struct msg *cmd = (struct msg* )cmdu_buf;

	if (cap == NULL) {
		err(DEBUG_CAT_EVENT, "cap NULL pointer\n");
		return -1;
	}
	cmd->type = LIB_AP_VHT_CAPABILITY;
	cmd->length = sizeof(struct ap_vht_capability);
	memcpy(cmd->buffer, (unsigned char*)cap, cmd->length);
	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}

int _1905_Set_Ap_He_Cap (IN struct _1905_context* ctx,
	IN struct ap_he_capability *cap)
{
	struct msg *cmd = (struct msg* )cmdu_buf;

	if (cap == NULL) {
		err(DEBUG_CAT_EVENT, "cap NULL pointer\n");
		return -1;
	}
	cmd->type = LIB_AP_HE_CAPABILITY;
	cmd->length = sizeof(struct ap_he_capability);
	memcpy(cmd->buffer, (unsigned char*)cap, cmd->length);
	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}
int _1905_Set_Ap_Eht_Cap(IN struct _1905_context *ctx,
	IN struct ap_eht_capability *cap)
{
	struct msg *cmd = (struct msg *)cmdu_buf;

	if (cap == NULL) {
		err(DEBUG_CAT_EVENT, "cap NULL pointer\n");
		return -1;
	}
	cmd->type = LIB_AP_EHT_CAPABILITY;
	cmd->length = sizeof(struct ap_eht_capability);
	memcpy(cmd->buffer, (unsigned char *)cap, cmd->length);
	if (_1905_interface_ctrl_request(ctx, (char *)cmd, sizeof(struct msg) + cmd->length) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}

int _1905_Set_Operbss_Cap(IN struct _1905_context* ctx,
	IN struct oper_bss_cap *cap)
{
	struct msg *cmd = (struct msg* )cmdu_buf;

	if (cap == NULL) {
		err(DEBUG_CAT_EVENT, "cap NULL pointer\n");
		return -1;
	}
	cmd->type = LIB_OPERBSS_REPORT;
	cmd->length = sizeof(struct oper_bss_cap) + cap->oper_bss_num * sizeof(struct op_bss_cap);
	memcpy(cmd->buffer, (unsigned char*)cap, cmd->length);
	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}

int _1905_Set_Cli_Steer_BTM_Report_Info (IN struct _1905_context* ctx,
	IN struct  cli_steer_btm_event *info)
{
	struct msg *cmd = (struct msg* )cmdu_buf;

	if (info == NULL) {
		err(DEBUG_CAT_EVENT, "info NULL pointer\n");
		return -1;
	}
	cmd->type = LIB_CLI_STEER_BTM_REPORT;
	cmd->length = sizeof(struct cli_steer_btm_event);
	memcpy(cmd->buffer, (unsigned char*)info, cmd->length);
	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}

int _1905_Set_Steering_Complete_Info (IN struct _1905_context* ctx)
{
	struct msg *cmd = (struct msg* )cmdu_buf;

	cmd->type = LIB_STEERING_COMPLETED;
	cmd->length = 0;
	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg)) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}

int _1905_Set_Read_Bss_Conf_Request (IN struct _1905_context* ctx)
{
	struct msg *cmd = (struct msg* )cmdu_buf;

	cmd->type = LIB_1905_READ_BSS_CONF_REQUEST;
	cmd->length = 0;
	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}

int _1905_Set_Read_Bss_Conf_and_Renew_legacy (IN struct _1905_context* ctx,
	IN unsigned char local_only, IN unsigned char version)
{
	struct msg *cmd = (struct msg* )cmdu_buf;

	cmd->type = LIB_1905_READ_BSS_CONF_AND_RENEW;
	cmd->length = 2;
	*(cmd->buffer) = local_only;
	*(cmd->buffer + 1) = version;
	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}

int _1905_Set_Read_Bss_Conf_and_Renew (IN struct _1905_context *ctx, IN unsigned char local_only) {
	return _1905_Set_Read_Bss_Conf_and_Renew_legacy(ctx, local_only, 1);
}


int _1905_Set_Read_Bss_Conf_and_Renew_v2 (IN struct _1905_context *ctx, IN unsigned char local_only) {
	return _1905_Set_Read_Bss_Conf_and_Renew_legacy(ctx, local_only, 2);
}


int _1905_Set_Bss_Config(IN struct _1905_context* ctx, IN struct bss_config_info* info,
	IN enum BSS_CONFIG_OPERATION oper)
{
	struct msg *cmd = (struct msg*)cmdu_buf;
	struct manage_cmd *_manage_cmd = (struct manage_cmd*)cmd->buffer;
	unsigned char *p = NULL;

	if(info == NULL) {
		err(DEBUG_CAT_EVENT, "info NULL pointer\n");
		goto fail;
	}

	cmd->type = MANAGEMENT_1905_COMMAND;

	_manage_cmd->cmd_id = MANAGE_SET_BSS_CONF;
	_manage_cmd->len = 1 + sizeof(struct bss_config_info) + info->cnt * sizeof(struct config_info);
	p = _manage_cmd->content;

	*p++ = oper;

	memcpy(p, info, sizeof(struct bss_config_info) + info->cnt * sizeof(struct config_info));

	cmd->length = sizeof(struct manage_cmd) + _manage_cmd->len;

	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		goto fail;
	}
	return 0;
fail:
	return -1;
}

int _1905_Set_Ap_Metric_Rsp_Info (IN struct _1905_context* ctx,
	IN struct ap_metrics_info_lib *info, IN int ap_metrics_info_cnt,
	IN struct stat_info *sta_states, IN int sta_states_cnt,
	IN struct link_metrics *sta_metrics, IN int sta_metrics_cnt
#ifdef MAP_R2
	, IN struct ap_extended_metrics_lib *ap_extended_metrics, IN int ap_extended_metrics_cnt,
	IN struct radio_metrics_lib *radio_metrics, IN int radio_metrics_cnt,
	IN struct sta_extended_metrics_lib *sta_extended_metrics, IN int sta_extended_metrics_cnt,
	IN unsigned char *vs_tlv, IN unsigned int vs_len
#endif // #ifdef MAP_R2
#ifdef MAP_R3_WF6
	, IN struct assoc_wifi6_sta_status_tlv_lib *wifi6_sta
	, IN int wifi6_sta_cnt
#endif
#ifdef MAP_R6
	, IN struct mlo_ap_extended_metrics_lib *mlo_ext_ap_metrics, IN int mlo_ext_ap_met_cnt
	, IN struct stat_info *mld_sta_stats, IN int mld_sta_stats_cnt
#endif
	, IN unsigned short mid
	)
{
	unsigned short len = 0;
	struct msg *cmd = (struct msg* )cmdu_buf;
	unsigned char* p = NULL;
	unsigned char* p_old = NULL;
	unsigned char* p_old_2 = NULL;
	unsigned char ac[4] = {0x01, 0x00, 0x03, 0x02};
	int i = 0, j = 0, k=0;
	p = cmd->buffer;

	if (ap_metrics_info_cnt > 0  && info == NULL) {
		err(DEBUG_CAT_EVENT, "info NULL pointer\n");
		return -1;
	}
	if ((sta_states_cnt > 0 && sta_states == NULL) || (sta_metrics_cnt > 0 && sta_metrics == NULL)) {
		err(DEBUG_CAT_EVENT, "%s NULL pointer\n", sta_states == NULL ? "stat_states" : "sta_metrics");
		return -1;
	}
	if (ap_metrics_info_cnt == 0 && sta_states_cnt == 0 && sta_metrics_cnt == 0) {
		err(DEBUG_CAT_EVENT, "invalid value; ap_metrics_info_cnt=0, sta_states_cnt=0, sta_metrics_cnt=0\n");
		return -1;
	}
	cmd->type = WAPP_AP_METRICS_RSP_INFO;
	cmd->mid = mid;
	if (ap_metrics_info_cnt < 1) {
		err(DEBUG_CAT_EVENT, "invalid value; ap_metrics_cnt < 1\n");
		return -1;
	}
	/* one  or more ap metrics TLVs */
	for (k = 0; k < ap_metrics_info_cnt; k++) {
		/*AP metrics TLV*/
		*p++ = 0x94;
		p_old = p;

		p += 2;

		memcpy(p, info->bssid, ETH_ALEN);
		p += ETH_ALEN;
		*p++ = info->ch_util;

		*((unsigned short*)p) = host_to_be16(info->assoc_sta_cnt);
		p += sizeof(unsigned short);

		p_old_2 = p;
		*p_old_2 = 0x00;
		p++;
		for (i = 0; i < 4; i++) {
			for (j = 0; j < info->valid_esp_count; j++) {
				if (ac[i] == info->esp[j].ac) {
					*p_old_2 |= (0x01 << (7 - i));
					if (info->esp[j].ba_win_size > 7) {
						err(DEBUG_CAT_EVENT, "len pre check fail\n");
						return -1;
					}

					if (info->esp[j].format > 3) {
						err(DEBUG_CAT_EVENT, "len pre check fail\n");
						return -1;
					}
					*p++ = info->esp[j].ppdu_dur_target;
					*p++ = info->esp[j].e_air_time_fraction;
					*p++ = (info->esp[j].ba_win_size << 5) |
						(info->esp[j].format << 3) | info->esp[j].ac;

				}
			}
		}
		/*AC_BE is fixed*/
		if (((*p_old_2) & 0x80) == 0) {
			err(DEBUG_CAT_EVENT, "content error; does not contain AC_BE %02x\n", *p_old_2);
			return -1;
		}
		len = (unsigned short)(p - p_old - 2);
		*((unsigned short*)p_old) = host_to_be16(len);
		info++;
	}



	/* zero or more associated sta traffic stats TLVs */
	if (sta_states != NULL) {
		for (i = 0; i < sta_states_cnt; i++) {
			/*Associated STA Traffic Stats TLV*/
			*p++ = 0xA2;
			p_old = p;

			p += 2;

			memcpy(p, sta_states[i].mac, ETH_ALEN);
			p += ETH_ALEN;

			*((unsigned int*)p) = host_to_be32(sta_states[i].bytes_sent);
			p += sizeof(unsigned int);

			*((unsigned int*)p) = host_to_be32(sta_states[i].bytes_received);
			p += sizeof(unsigned int);

			*((unsigned int*)p) = host_to_be32(sta_states[i].packets_sent);
			p += sizeof(unsigned int);

			*((unsigned int*)p) = host_to_be32(sta_states[i].packets_received);
			p += sizeof(unsigned int);

			*((unsigned int*)p) = host_to_be32(sta_states[i].tx_packets_errors);
			p += sizeof(unsigned int);

			*((unsigned int*)p) = host_to_be32(sta_states[i].rx_packets_errors);
			p += sizeof(unsigned int);

			*((unsigned int*)p) = host_to_be32(sta_states[i].retransmission_count);
			p += sizeof(unsigned int);

			len = (unsigned short)(p - p_old - 2);
			*((unsigned short*)p_old) = host_to_be16(len);
		}
	}

	/* zero or more associated sta link metrics TLVs */
	if (sta_metrics != NULL) {
		for (i = 0; i < sta_metrics_cnt; i++) {
			/*Associated STA link metrics TLV*/
			*p++ = 0x96;
			p_old = p;

			p += 2;

			memcpy(p, sta_metrics[i].mac, ETH_ALEN);
			p += ETH_ALEN;

			*p++ = 1;

			memcpy(p, sta_metrics[i].bssid, ETH_ALEN);
			p += ETH_ALEN;

			*((unsigned int*)p) = host_to_be32(sta_metrics[i].time_delta);
			p += sizeof(unsigned int);

			*((unsigned int*)p) = host_to_be32(sta_metrics[i].erate_downlink);
			p += sizeof(unsigned int);

			*((unsigned int*)p) = host_to_be32(sta_metrics[i].erate_uplink);
			p += sizeof(unsigned int);

			*p++ = sta_metrics[i].rssi_uplink;

			len = (unsigned short)(p - p_old - 2);
			*((unsigned short*)p_old) = host_to_be16(len);
		}
	}

#ifdef MAP_R2

	/* One or more AP Extended Metrics TLVs */
	if (ap_extended_metrics != NULL) {
		for (i = 0; i < ap_extended_metrics_cnt; i++) {
			/* AP Extended Metrics TLVs */
			*p++ = 0xC7;
			p_old = p;

			p += 2;

			memcpy(p, ap_extended_metrics[i].bssid, ETH_ALEN);
			p += ETH_ALEN;

			/* mapd guarantee this unit */
			*((unsigned int*)p) = host_to_be32(ap_extended_metrics[i].uc_tx);
			p += sizeof(unsigned int);

			*((unsigned int*)p) = host_to_be32(ap_extended_metrics[i].uc_rx);
			p += sizeof(unsigned int);

			*((unsigned int*)p) = host_to_be32(ap_extended_metrics[i].mc_tx);
			p += sizeof(unsigned int);

			*((unsigned int*)p) = host_to_be32(ap_extended_metrics[i].mc_rx);
			p += sizeof(unsigned int);

			*((unsigned int*)p) = host_to_be32(ap_extended_metrics[i].bc_tx);
			p += sizeof(unsigned int);

			*((unsigned int*)p) = host_to_be32(ap_extended_metrics[i].bc_rx);
			p += sizeof(unsigned int);

			len = (unsigned short)(p - p_old - 2);
			*((unsigned short*)p_old) = host_to_be16(len);

			//ap_extended_metrics ++;
		}
	}

	/* Zero or more Radio Metrics TLVs */
	if (radio_metrics != NULL) {
		for (i = 0; i < radio_metrics_cnt; i++) {
			/* Radio Metrics TLVs */
			*p++ = 0xC6;
			p_old = p;

			p += 2;

			memcpy(p, radio_metrics[i].identifier, ETH_ALEN);
			p += ETH_ALEN;


			*p++ = radio_metrics[i].noise;

			*p++ = radio_metrics[i].transmit;

			*p++ = radio_metrics[i].receive_self;

			*p++ = radio_metrics[i].receive_other;

			len = (unsigned short)(p - p_old - 2);
			*((unsigned short*)p_old) = host_to_be16(len);

			//radio_metrics ++;
		}
	}

	/* Zero or more Associated STA Extended Link Metrics TLVs */
	if (sta_extended_metrics) {
		struct extended_metrics_info *metric_info = NULL;
		for (i = 0; i < sta_extended_metrics_cnt; i++) {
			/* Associated STA Extended Link Metrics TLVs */
			*p++ = 0xC8;
			p_old = p;

			p += 2;

			memcpy(p, sta_extended_metrics->sta_mac, ETH_ALEN);
			p += ETH_ALEN;

			*p++ = sta_extended_metrics->extended_metric_cnt;

			metric_info = sta_extended_metrics->metric_info;
			for (j = 0; j < sta_extended_metrics->extended_metric_cnt; j ++) {
				memcpy(p, metric_info->bssid, ETH_ALEN);
				p += ETH_ALEN;

				*((unsigned int *)p) = host_to_be32(metric_info[j].last_data_dl_rate);
				p += sizeof(unsigned int);

				*((unsigned int *)p) = host_to_be32(metric_info[j].last_data_ul_rate);
				p += sizeof(unsigned int);

				*((unsigned int*)p) = host_to_be32(metric_info[j].utilization_rx);
				p += sizeof(unsigned int);

				*((unsigned int*)p) = host_to_be32(metric_info[j].utilization_tx);
				p += sizeof(unsigned int);

				//metric_info += 1;
			}

			sta_extended_metrics = (struct sta_extended_metrics_lib *)((char *)sta_extended_metrics +
				sizeof(struct sta_extended_metrics_lib) +
				sta_extended_metrics->extended_metric_cnt * sizeof(struct extended_metrics_info));

			len = (unsigned short)(p - p_old - 2);
			*((unsigned short*)p_old) = host_to_be16(len);

		}
	}

	if (vs_tlv && vs_len) {
		memcpy(p, vs_tlv, vs_len);
		p += vs_len;
	}
#endif // #ifdef MAP_R2

#ifdef MAP_R3_WF6
	/* zero or more associated wf6 sta status TLVs */
	if (wifi6_sta != NULL) {
		for (i = 0; i < wifi6_sta_cnt; i++) {
			/*Associated STA Traffic Stats TLV*/
			*p++ = 0xB0;
			p_old = p;

			p += 2;

			memcpy(p, wifi6_sta[i].mac, ETH_ALEN);
			p += ETH_ALEN;

#ifdef EM_PLUS_SUPPORT
			*p++ = TID_CNT;
			for (j = 0; j < TID_CNT; j++) {
				*p++ = j;
				*p++ = ctx->tid_q_size;
#else
			*p++ = wifi6_sta[i].tid_cnt;
			for(j = 0; j < 4; j++) {
				*p++ = wifi6_sta[i].status_tlv[j].tid;
				*p++ = wifi6_sta[i].status_tlv[j].tid_q_size;
#endif /* EM_PLUS_SUPPORT */

			}

			len = (unsigned short)(p - p_old - 2);
			*((unsigned short*)p_old) = host_to_be16(len);
		}
	}
#endif

#ifdef MAP_R6
	if (!mlo_ext_ap_metrics && mlo_ext_ap_met_cnt) {
		err(DEBUG_CAT_EVENT, "mlo ext ap metrics NULL pointer\n");
		return -1;
	}

	for (i = 0; i < mlo_ext_ap_met_cnt; i++) {
		*p++ = 0xE5;
		p_old = p;
		p += 2;

		os_memcpy(p, mlo_ext_ap_metrics[i].bssid, ETH_ALEN);
		p += ETH_ALEN;

		*(unsigned int *)p = host_to_be32(mlo_ext_ap_metrics[i].mlo_pkts_tx);
		p += sizeof(unsigned int);

		*(unsigned int *)p = host_to_be32(mlo_ext_ap_metrics[i].mlo_pkts_rx);
		p += sizeof(unsigned int);

		*(unsigned int *)p = host_to_be32(mlo_ext_ap_metrics[i].mlo_tx_pkts_error_count);
		p += sizeof(unsigned int);

		*(unsigned int *)p = host_to_be32(mlo_ext_ap_metrics[i].mlo_uc_tx);
		p += sizeof(unsigned int);

		*(unsigned int *)p = host_to_be32(mlo_ext_ap_metrics[i].mlo_uc_rx);
		p += sizeof(unsigned int);

		*(unsigned int *)p = host_to_be32(mlo_ext_ap_metrics[i].mlo_mc_tx);
		p += sizeof(unsigned int);

		*(unsigned int *)p = host_to_be32(mlo_ext_ap_metrics[i].mlo_mc_rx);
		p += sizeof(unsigned int);

		*(unsigned int *)p = host_to_be32(mlo_ext_ap_metrics[i].mlo_bc_tx);
		p += sizeof(unsigned int);

		*(unsigned int *)p = host_to_be32(mlo_ext_ap_metrics[i].mlo_bc_rx);
		p += sizeof(unsigned int);

		len = (unsigned short)(p - p_old - 2);
		*((unsigned short *)p_old) = host_to_be16(len);

	}

	if (!mld_sta_stats && mld_sta_stats_cnt) {
		err(DEBUG_CAT_EVENT, "mlo sta stats NULL pointer\n");
		return -1;
	}

	for (i = 0; i < mld_sta_stats_cnt; i++) {
		*p++ = 0xE4;
		p_old = p;
		p += sizeof(unsigned short);

		os_memcpy(p, mld_sta_stats[i].mac, ETH_ALEN);
		p += ETH_ALEN;

		*(unsigned int *)p = host_to_be32(mld_sta_stats[i].bytes_sent);
		p += sizeof(unsigned int);

		*(unsigned int *)p = host_to_be32(mld_sta_stats[i].bytes_received);
		p += sizeof(unsigned int);

		*(unsigned int *)p = host_to_be32(mld_sta_stats[i].packets_sent);
		p += sizeof(unsigned int);

		*(unsigned int *)p = host_to_be32(mld_sta_stats[i].packets_received);
		p += sizeof(unsigned int);

		*(unsigned int *)p = host_to_be32(mld_sta_stats[i].tx_packets_errors);
		p += sizeof(unsigned int);

		len = (unsigned short)(p - p_old - 2);
		*((unsigned short *)p_old) = host_to_be16(len);
	}
#endif

	cmd->length = (unsigned short)(p - cmd->buffer);

	if (_1905_interface_ctrl_request(ctx, (char*)cmd, cmd->length + sizeof(struct msg)) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	}
	return 0;
}

int _1905_Set_Bh_Steer_Rsp_Info (IN struct _1905_context* ctx,
	IN struct backhaul_steer_rsp *info)
{
	struct msg *cmd = (struct msg* )cmdu_buf;
	unsigned char* p = NULL;
	unsigned short len = 13;
	unsigned short err_tlv_len = 7;

	if (info == NULL) {
		err(DEBUG_CAT_EVENT, "info NULL pointer\n");
		return -1;
	}
	cmd->type = LIB_BACKHAUL_STEER_RSP;
	p = cmd->buffer;

	*p++ = 0x9F;

	*((unsigned short*)p) = host_to_be16(len);
	p += 2;

	memcpy(p, info->backhaul_mac, ETH_ALEN);
	p += ETH_ALEN;

	memcpy(p, info->target_bssid, ETH_ALEN);
	p += ETH_ALEN;

	*p++ = info->status;

	if (info->error) {/*add error code tlv*/
		*p++ = 0xA3;
		*((unsigned short*)p) = host_to_be16(err_tlv_len);
		p += 2;
		*p++ = info->error;
		memcpy(p, info->backhaul_mac, ETH_ALEN);
		p += ETH_ALEN;
	}

	cmd->length = p - cmd->buffer;
	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}

int _1905_Set_Assoc_Sta_Link_Metric_Rsp_Info (IN struct _1905_context* ctx,
	IN unsigned char info_cnt, IN struct link_metrics *info,
	IN unsigned char *sta_mac, IN unsigned char reason
#ifdef MAP_R2
	, IN unsigned char sta_extended_metrics_cnt,
	IN struct sta_extended_metrics_lib *sta_extended_metrics
#endif
	, IN unsigned short mid
)
{
	unsigned char* p = NULL;
	unsigned char* old_p = NULL;
	unsigned short len = 0;
	int i = 0;
	struct msg *cmd = (struct msg* )cmdu_buf;

	if (info_cnt == 0 || info == NULL) {
		err(DEBUG_CAT_EVENT, "%s\n", info_cnt <= 0 ? "info_cnt must be no less than 1" : "info NULL pointer");
		return -1;
	}
	cmd->type = LIB_ONE_ASSOC_STA_LINK_METRICS;
	cmd->mid = mid;
	p = cmd->buffer;

	/* One or more Associated STA Link Metrics TLVs */
	for (i = 0; i < info_cnt; i++) {
		/*associated sta link metrics tlv*/
		*p++ = 0x96;
		old_p = p;

		p += 2;

		memcpy(p, info[i].mac, ETH_ALEN);
		p += ETH_ALEN;

		if (reason == 0x02)
			*p++ = 0;
		else
			*p++ = 1;
		if (reason != 0x02) {
			memcpy(p, info[i].bssid, ETH_ALEN);
			p += ETH_ALEN;

			*((unsigned int*)p) = host_to_be32(info[i].time_delta);
			p += sizeof(unsigned int);

			*((unsigned int*)p) = host_to_be32(info[i].erate_downlink);
			p += sizeof(unsigned int);

			*((unsigned int*)p) = host_to_be32(info[i].erate_uplink);
			p += sizeof(unsigned int);

			*p++ = info[i].rssi_uplink;

			len = (unsigned short)(p - old_p - 2);

			*((unsigned short*)old_p) = host_to_be16(len);
		}
	}

#ifdef MAP_R2
	/* One or more Associated STA Extended Link Metrics TLVs */
	if (sta_extended_metrics) {
		int j = 0;
		struct extended_metrics_info *metric_info = NULL;
		for (i = 0; i < sta_extended_metrics_cnt; i++) {
			/* Associated STA Extended Link Metrics TLVs */
			*p++ = 0xC8;
			old_p = p;

			p += 2;

			memcpy(p, sta_extended_metrics->sta_mac, ETH_ALEN);
			p += ETH_ALEN;

			*p++ = sta_extended_metrics->extended_metric_cnt;

			metric_info = sta_extended_metrics->metric_info;
			for (j = 0; j < sta_extended_metrics->extended_metric_cnt; j ++) {
				memcpy(p, metric_info->bssid, ETH_ALEN);
				p += ETH_ALEN;

				*((unsigned int *)p) = host_to_be32(metric_info->last_data_dl_rate);
				p += sizeof(unsigned int);

				*((unsigned int *)p) = host_to_be32(metric_info->last_data_ul_rate);
				p += sizeof(unsigned int);

				*((unsigned int*)p) = host_to_be32(metric_info->utilization_rx);
				p += sizeof(unsigned int);

				*((unsigned int*)p) = host_to_be32(metric_info->utilization_tx);
				p += sizeof(unsigned int);

				metric_info += 1;
			}


			len = (unsigned short)(p - old_p - 2);
			*((unsigned short*)old_p) = host_to_be16(len);

			sta_extended_metrics = (struct sta_extended_metrics_lib *)metric_info;
		}
	}

	/* zero or one Error Code TLV (see section 17.2.36) */
	if (reason) {
		/* Error Code TLV */
		*p++ = 0xA3;

		*((unsigned short*)p) = host_to_be16(7);
		p += 2;

		*p++ =reason;

		if ((reason == 0x01 || reason == 0x02) && sta_mac) {
			memcpy(p, sta_mac, ETH_ALEN);
			p += ETH_ALEN;
		}
	}
#endif // #ifdef MAP_R2

	cmd->length = (unsigned short)(p - cmd->buffer);

	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}

int _1905_Set_Link_Metrics_Rsp_Info (IN struct _1905_context* ctx,
	IN int tx_metrics_cnt, IN struct tx_link_metrics *tx_metrics,
	IN int rx_metrics_cnt, IN struct rx_link_metrics *rx_metrics,
	IN unsigned short mid)
{
	unsigned char* p = NULL;
	unsigned char* old_p = NULL;
	unsigned short len = 0;
	int i = 0, j = 0;
#ifdef EM_PLUS_EXT_SUPPORT
	int max_cnt = 0;
#endif
	struct msg *cmd = (struct msg* )cmdu_buf;

	cmd->type = WAPP_LINK_METRICS_RSP_INFO;
	cmd->mid = mid;
	p = cmd->buffer;

	if ((tx_metrics_cnt > 0 && tx_metrics == NULL) || (rx_metrics_cnt > 0 && rx_metrics == NULL)) {
		err(DEBUG_CAT_EVENT, "%s NULL pointer\n", tx_metrics == NULL ? "tx_metrics" : "rx_metrics");
		return -1;
	}
#ifdef EM_PLUS_EXT_SUPPORT
	max_cnt = (tx_metrics_cnt > rx_metrics_cnt) ? tx_metrics_cnt : rx_metrics_cnt;

	for (i = 0; i < max_cnt; i++) {
		if (i < tx_metrics_cnt) {
#else
	for (i = 0; i < tx_metrics_cnt; i++) {
#endif
		/*transmitter link metrics TLV*/
		*p++ = 0x09;

		old_p = p;

		/*skip tlvLength field*/
		p += 2;

		memcpy(p, tx_metrics->almac, ETH_ALEN);
		p += ETH_ALEN;

		memcpy(p, tx_metrics->neighbor_almac, ETH_ALEN);
		p += ETH_ALEN;

		for (j = 0; j < tx_metrics->link_pair_cnt; j++) {
			memcpy(p, tx_metrics->metrics[j].mac_address, ETH_ALEN);
			p += ETH_ALEN;
			memcpy(p, tx_metrics->metrics[j].mac_address_neighbor, ETH_ALEN);
			p += ETH_ALEN;

			*((unsigned short*)p) = host_to_be16(tx_metrics->metrics[j].intftype);
			p += sizeof(unsigned short);

			*p++ = tx_metrics->metrics[j].ieee80211_bridgeflg;

			*((unsigned int*)p) = host_to_be32(tx_metrics->metrics[j].packetErrors);
			p += sizeof(unsigned int);

			*((unsigned int*)p) = host_to_be32(tx_metrics->metrics[j].transmittedPackets);
			p += sizeof(unsigned int);

			*((unsigned short*)p) = host_to_be16(tx_metrics->metrics[j].macThroughputCapacity);
			p += sizeof(unsigned short);

			*((unsigned short*)p) = host_to_be16(tx_metrics->metrics[j].linkAvailability);
			p += sizeof(unsigned short);

			*((unsigned short*)p) = host_to_be16(tx_metrics->metrics[j].phyRate);
			p += sizeof(unsigned short);
		}
		len = (unsigned short)(p - old_p - 2);
		*((unsigned short*)old_p) = host_to_be16(len);
		tx_metrics++;
	}
#ifdef EM_PLUS_EXT_SUPPORT
	if (i < rx_metrics_cnt) {
#else
	for (i = 0; i < rx_metrics_cnt; i++) {
#endif
		/*receiver link metrics TLV*/
		*p++ = 10;
		old_p = p;

		/*skip tlvLength field*/
		p += 2;

		memcpy(p, rx_metrics->almac, ETH_ALEN);
		p += ETH_ALEN;

		memcpy(p, rx_metrics->neighbor_almac, ETH_ALEN);
		p += ETH_ALEN;

		for (j = 0; j < rx_metrics->link_pair_cnt; j++) {
			memcpy(p, rx_metrics->metrics[j].mac_address, ETH_ALEN);
			p += ETH_ALEN;
			memcpy(p, rx_metrics->metrics[j].mac_address_neighbor, ETH_ALEN);
			p += ETH_ALEN;

			*((unsigned short*)p) = host_to_be16(rx_metrics->metrics[j].intftype);
			p += sizeof(unsigned short);

			*((unsigned int*)p) = host_to_be32(rx_metrics->metrics[j].packetErrors);
			p += sizeof(unsigned int);

			*((unsigned int*)p) = host_to_be32(rx_metrics->metrics[j].packetsReceived);
			p += sizeof(unsigned int);

			*p++ = rx_metrics->metrics[j].rssi;
		}
		len = (unsigned short)(p - old_p - 2);
		*((unsigned short*)old_p) = host_to_be16(len);
		rx_metrics++;
#ifdef EM_PLUS_EXT_SUPPORT
	}
#endif
	}

	cmd->length = (unsigned short)(p - cmd->buffer);
	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}

int _1905_Set_Unassoc_Sta_Link_Metric_Rsp_Info (IN struct _1905_context* ctx,
	IN struct unlink_metrics_rsp *info)
{
	unsigned char* p = NULL;
	unsigned char* old_p = NULL;
	unsigned short len = 0;
	int i = 0;
	struct msg *cmd = (struct msg* )cmdu_buf;

	if (info == NULL) {
		err(DEBUG_CAT_EVENT, "info NULL pointer\n");
		goto error_exit;
	}
	cmd->type = LIB_UNASSOC_STA_LINK_METRICS;
	p = cmd->buffer;

	/*unassociated sta link metrics response TLV*/
	*p++ = 0x98;
	old_p = p;

	p += 2;
	*p++ = info->oper_class;
	*p++ = info->sta_num;

	for (i = 0; i < info->sta_num; i++) {
		memcpy(p, info->info[i].mac, ETH_ALEN);
		p += ETH_ALEN;

		*p++ = info->info[i].ch;

		*((unsigned int*)p) = host_to_be32(info->info[i].time_delta);
		p += sizeof(unsigned int);

		*p++ = info->info[i].uplink_rssi;
	}
	len = (unsigned short)(p - old_p) - 2;
	*((unsigned short*)old_p) = host_to_be16(len);
	cmd->length =(unsigned short)(p - cmd->buffer);
	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}

error_exit:
	cmd->type = LIB_UNASSOC_STA_LINK_METRICS;
	cmd->length = 0;
	if (_1905_interface_ctrl_request(ctx, (char *)cmd, sizeof(struct msg) + cmd->length) < 0)
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");

	return -1;
}

int _1905_Set_Operating_Channel_Report_Info (IN struct _1905_context* ctx,
	IN struct channel_report *info
#ifdef MAP_R4_SPT
	, IN struct spt_reuse_report *spt_report
#endif
	)
{
	struct msg *cmd = (struct msg* )cmdu_buf;

	if (info == NULL) {
		err(DEBUG_CAT_EVENT, "info NULL pointer\n");
		return -1;
	}
#ifdef MAP_R4_SPT
	unsigned short len = 0;
#endif
	cmd->type = LIB_OPERATING_CHANNEL_REPORT;
	cmd->length = sizeof(struct channel_report) + info->ch_rep_num * sizeof(struct ch_rep_info);
	memcpy(cmd->buffer, (unsigned char*)info, cmd->length);

#ifdef MAP_R4_SPT
	if(spt_report != NULL) {
		len = sizeof(struct spt_reuse_report)+ spt_report->spt_rep_num* sizeof(struct ap_spt_reuse_resp);
		memcpy(cmd->buffer + cmd->length, (unsigned char*)spt_report, len);
		cmd->length += len;
	}
#endif
	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}

int _1905_Set_Beacon_Metrics_Report_Info (IN struct _1905_context* ctx,
	IN struct beacon_metrics_rsp_lib *info)
{
	struct msg *cmd = (struct msg* )cmdu_buf;
	unsigned char* p = NULL;
	unsigned char* p_old = NULL;
	unsigned short len = 0;
	cmd->type = LIB_BEACON_METRICS_REPORT;
	p = cmd->buffer;

	if (info == NULL) {
		err(DEBUG_CAT_EVENT, "info NULL pointer\n");
		return -1;
	}
	/*beacon metrics response tlv*/
	*p++ = 0x9A;
	p_old = p;

	p += 2;

	memcpy(p, info->sta_mac, ETH_ALEN);
	p += ETH_ALEN;

	*p++ = (info->status << 6);

	*p++ = info->bcn_rpt_num;

	memcpy(p, info->rpt, info->rpt_len);
	p += info->rpt_len;

	len = (unsigned short)(p - cmd->buffer) - 3;

	*((unsigned short*)p_old) = host_to_be16(len);

	cmd->length = len + 3;
	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + len) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}

int _1905_Set_Sta_Notification_Info (IN struct _1905_context* ctx,
	IN struct client_association_event *info)
{
	struct msg *cmd = (struct msg* )cmdu_buf;

	if (info == NULL) {
		err(DEBUG_CAT_EVENT, "info NULL pointer\n");
		return -1;
	}
	cmd->type = LIB_CLIENT_NOTIFICATION;
	cmd->length = sizeof(struct client_association_event) + (info->map_assoc_evt.assoc_evt == STA_LEAVE ? 0 : info->map_assoc_evt.assoc_req_len);
	memcpy(cmd->buffer, (unsigned char*)info, cmd->length);
	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}

int _1905_Set_Bh_Ready (IN struct _1905_context* ctx, struct bh_link_info *info)
{
	struct msg *cmd = (struct msg* )cmdu_buf;

	if (info == NULL) {
		err(DEBUG_CAT_EVENT, "info NULL pointer\n");
		return -1;
	}
	cmd->type = LIB_MAP_BH_READY;
	cmd->length = sizeof(struct bh_link_info);
	os_memcpy(cmd->buffer, (unsigned char*)info, sizeof(struct bh_link_info));

	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}

#ifdef MAP_R2
int _1905_Set_Radio_Metric(IN struct _1905_context* ctx, struct radio_metrics_lib *info)
{
	struct msg *cmd = (struct msg* )cmdu_buf;

	if (info == NULL) {
		err(DEBUG_CAT_EVENT, "radio_metrics_lib NULL pointer\n");
		return -1;
	}
	cmd->type = LIB_RADIO_METRICS_INFO;
	cmd->length = sizeof(struct radio_metrics_lib);
	os_memcpy(cmd->buffer, (unsigned char*)info, sizeof(struct radio_metrics_lib));

	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}
#endif

int _1905_Set_Wi_Bh_Link_Down (IN struct _1905_context* ctx, struct bh_link_info *info)
{
	struct msg *cmd = (struct msg* )cmdu_buf;

	if (info == NULL) {
		err(DEBUG_CAT_EVENT, "info NULL pointer\n");
		return -1;
	}
	cmd->type = WAPP_NOTIFY_WIRELESS_BH_LINK_DOWN;
	cmd->length = sizeof(struct bh_link_info);
	os_memcpy(cmd->buffer, (unsigned char*)info, sizeof(struct bh_link_info));

	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}

int _1905_Set_ch_bw_info (IN struct _1905_context* ctx, struct channel_bw_info *info)
{
	struct msg *cmd = (struct msg* )cmdu_buf;

	if (info == NULL) {
		err(DEBUG_CAT_EVENT, "info NULL pointer\n");
		return -1;
	}
	cmd->type = WAPP_NOTIFY_CH_BW_INFO;
	cmd->length = sizeof(struct channel_bw_info);
	os_memcpy(cmd->buffer, (unsigned char*)info, sizeof(struct channel_bw_info));

	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}

int _1905_Get_Own_Topo_Rsp (IN struct _1905_context* ctx)
{
	struct msg *cmd = (struct msg* )cmdu_buf;

	cmd->type = WAPP_GET_OWN_TOPOLOGY_RSP;
	cmd->length = 0;

	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}

int _1905_Get_Own_Switch_Status (IN struct _1905_context* ctx)
{
	struct msg *cmd = (struct msg* )cmdu_buf;

	cmd->type = GET_SWITCH_STATUS;
	cmd->length = 0;

	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}


int _1905_Get_Wsc_Config (IN struct _1905_context* ctx, struct wps_get_config *config)
{
	struct msg *cmd = (struct msg* )cmdu_buf;

	if (config == NULL) {
		err(DEBUG_CAT_EVENT, "config NULL pointer\n");
		return -1;
	}
	cmd->type = LIB_GET_WSC_CONF;
	cmd->length = sizeof(struct wps_get_config) + sizeof(inf_info) * config->num_of_inf;
	memcpy(cmd->buffer, (char* )config,  cmd->length);
	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}

int _1905_Set_Read_1905_Tlv_Req (IN struct _1905_context* ctx, char* file_path, int len)
{
	struct msg *cmd = (struct msg* )cmdu_buf;

	if (file_path == NULL || len == 0) {
		err(DEBUG_CAT_EVENT, "%s\n", len == 0 ? "len must be no less than 1" : "file_path NULL pointer");
		return -1;
	}

	memset(cmdu_buf, 0, sizeof(cmdu_buf));
	cmd->type = LIB_1905_READ_1905_TLV_REQUEST;
	memcpy(cmd->buffer, file_path,  len);
	cmd->length = len;
	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + len) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}


int _1905_Send_Topology_Query_Message (IN struct _1905_context* ctx, char* almac)
{
	struct msg *cmd = (struct msg* )cmdu_buf;
	struct _1905_cmdu_request* request = (struct _1905_cmdu_request*)cmd->buffer;

	if (almac == NULL) {
		err(DEBUG_CAT_EVENT, "almac NULL pointer\n");
		return -1;
	}
	cmd->type = LIB_1905_CMDU_REQUEST;
	memcpy(request->dest_al_mac, almac, ETH_ALEN);
	request->type = TOPOLOGY_QUERY;
	request->len = 0;
	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + sizeof(struct _1905_cmdu_request)) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}

int _1905_Send_Link_Metric_Query_Message (IN struct _1905_context* ctx,
	char* almac, unsigned char  neighbor,  char* neighbor_almac,  unsigned char metrics)
{
	struct msg *cmd = (struct msg* )cmdu_buf;
	struct _1905_cmdu_request* request = (struct _1905_cmdu_request*)cmd->buffer;
	unsigned char zero_mac[ETH_ALEN] = {0};

	if (neighbor > 1) {
		err(DEBUG_CAT_EVENT, "neighbor should be less than 2\n");
		return -1;
	}
	if (metrics > 2) {
		err(DEBUG_CAT_EVENT, "metrics should be less than 3\n");
		return -1;
	}
	if (almac == NULL || (neighbor > 0 && neighbor_almac == NULL)) {
		err(DEBUG_CAT_EVENT, "%s NULL pointer\n", almac == NULL ? "almac" : "neighbor_almac");
		return -1;
	}
	cmd->type = LIB_1905_CMDU_REQUEST;
	memcpy(request->dest_al_mac, almac, ETH_ALEN);
	request->type = LINK_METRICS_QUERY;
	request->len = ETH_ALEN + sizeof(unsigned char);
	if (neighbor == 0x00) {
		memcpy(request->body, zero_mac, ETH_ALEN);
	} else {
		memcpy(request->body, neighbor_almac, ETH_ALEN);
	}
	memcpy(request->body + 6, &metrics, sizeof(unsigned char));
	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + sizeof(struct _1905_cmdu_request) + 7) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}

}

int _1905_Send_AP_Autoconfig_Search_Message(IN struct _1905_context* ctx,
	unsigned char band)
{
	struct msg *cmd = (struct msg* )cmdu_buf;
	struct _1905_cmdu_request* request = (struct _1905_cmdu_request*)cmd->buffer;

	cmd->type = LIB_1905_CMDU_REQUEST;
	memcpy(request->dest_al_mac, _1905_multicast_address, ETH_ALEN);
	request->type = AP_AUTOCONFIG_SEARCH;
	request->len = sizeof(unsigned char);
	memcpy(request->body, &band, sizeof(unsigned char));
	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + sizeof(struct _1905_cmdu_request) + sizeof(unsigned char)) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}

int _1905_Send_AP_autoconfig_Renew_Message (IN struct _1905_context* ctx,
	unsigned char band)
{
	struct msg *cmd = (struct msg* )cmdu_buf;
	struct _1905_cmdu_request* request = (struct _1905_cmdu_request*)cmd->buffer;

	cmd->type = LIB_1905_CMDU_REQUEST;
	request->type = AP_AUTOCONFIG_RENEW;
	request->len = sizeof(unsigned char);
	memcpy(request->body, &band, sizeof(unsigned char));
	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + sizeof(struct _1905_cmdu_request) + sizeof(unsigned char)) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}
int _1905_Send_Vendor_Specific_Message(IN struct _1905_context* ctx,
	char* almac,  char* vend_spec_tlv, unsigned short len)
{
	struct msg *cmd = (struct msg* )cmdu_buf;
	struct _1905_cmdu_request* request = (struct _1905_cmdu_request*)cmd->buffer;

	if (almac == NULL) {
		err(DEBUG_CAT_EVENT, "almac NULL pointer\n");
		return -1;
	}
	if (len == 0 || vend_spec_tlv == NULL) {
		err(DEBUG_CAT_EVENT, "%s\n", len == 0 ? "len must be no less than 1" : "vend_spec_tlv NULL pointer");
		return -1;
	}
	cmd->type = LIB_1905_CMDU_REQUEST;
	memcpy(request->dest_al_mac, almac, ETH_ALEN);
	request->type = VENDOR_SPECIFIC;
	request->len = len;
	memcpy(request->body, vend_spec_tlv, len);
	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + sizeof(struct _1905_cmdu_request) + len) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}


int _1905_Send_AP_Capability_Query_Message (IN struct _1905_context* ctx, char* almac)
{
	struct msg *cmd = (struct msg* )cmdu_buf;
	struct _1905_cmdu_request* request = (struct _1905_cmdu_request*)cmd->buffer;

	if (almac == NULL) {
		err(DEBUG_CAT_EVENT, "almac NULL pointer\n");
		return -1;
	}
	cmd->type = LIB_1905_CMDU_REQUEST;
	memcpy(request->dest_al_mac, almac, ETH_ALEN);
	request->type = AP_CAPABILITY_QUERY;
	request->len = 0;
	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + sizeof(struct _1905_cmdu_request)) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}

int _1905_Send_MAP_Policy_Request_Message (IN struct _1905_context* ctx,
	char* almac, unsigned char steer_disallow_sta_cnt,  char *steer_disallow_sta_list,
	unsigned char btm_disallow_sta_cnt, char *btm_disallow_sta_list,  unsigned char radio_cnt_steer,
	struct lib_steer_radio_policy *steering_policy, unsigned char ap_rep_interval,
	unsigned char radio_cnt_metrics, struct lib_metrics_radio_policy *metrics_policy
#ifdef MAP_R2
	, unsigned char scan_rep_include, unsigned char scan_rep_policy,
	unsigned char unsuccess_assoc_policy_include, struct lib_unsuccess_assoc_policy *unsuccess_assoc_policy
	, unsigned int bh_assoc_ctrl_num, struct bh_bss_assoc_ctrl_setting *bh_assoc_ctrl_info
#endif
	)
{
	unsigned short len = 0;
	struct msg *cmd = (struct msg* )cmdu_buf;
	struct _1905_cmdu_request* request = (struct _1905_cmdu_request*)cmd->buffer;
	unsigned char *p = request->body;
	unsigned char *old_p = NULL;
	int j = 0;

	if (almac == NULL) {
		err(DEBUG_CAT_EVENT, "almac NULL pointer\n");
		return -1;
	}
	if (steer_disallow_sta_cnt > 0 && steer_disallow_sta_list == NULL) {
		err(DEBUG_CAT_EVENT, "steer_disallow_sta_list NULL pointer\n");
		return -1;
	}
	if (btm_disallow_sta_cnt > 0 && btm_disallow_sta_list == NULL) {
		err(DEBUG_CAT_EVENT, "btm_disallow_sta_list NULL pointer\n");
		return -1;
	}
	if (radio_cnt_steer > 0 && steering_policy == NULL) {
		err(DEBUG_CAT_EVENT, "steering_policy NULL pointer\n");
		return -1;
	}
	if (radio_cnt_metrics > 0 && metrics_policy == NULL) {
		err(DEBUG_CAT_EVENT, "metrics_policy NULL pointer");
		return -1;
	}
	if (steer_disallow_sta_cnt == 0 && btm_disallow_sta_cnt == 0 && radio_cnt_steer == 0
		&& radio_cnt_metrics == 0) {
		err(DEBUG_CAT_EVENT, "invalid value; all cnt equal to 0\n");
		return -1;
	}
	cmd->type = LIB_1905_CMDU_REQUEST;
	memcpy(request->dest_al_mac, almac, ETH_ALEN);
	request->type = MAP_POLICY_CONFIG_REQUEST;

	if (steer_disallow_sta_cnt != 0 || btm_disallow_sta_cnt != 0 || radio_cnt_steer != 0) {
		/*steering policy tlv*/
		*p++ = 0x89;
		old_p = p;

		/*skip tlvLength field*/
		p += 2;

		*p++ = steer_disallow_sta_cnt;
		memcpy(p, steer_disallow_sta_list, steer_disallow_sta_cnt * ETH_ALEN);
		p += steer_disallow_sta_cnt * ETH_ALEN;

		*p++ = btm_disallow_sta_cnt;
		memcpy(p, btm_disallow_sta_list, btm_disallow_sta_cnt * ETH_ALEN);
		p += btm_disallow_sta_cnt * ETH_ALEN;

		*p++ = radio_cnt_steer;
		for (j = 0; j < radio_cnt_steer; j++) {
			memcpy(p, steering_policy->identifier, ETH_ALEN);
			p += ETH_ALEN;
			*p++ = steering_policy->steer_policy;
			*p++ = steering_policy->ch_util_thres;
			*p++ = steering_policy->rssi_thres;
			steering_policy++;
		}

		len = (unsigned short)(p - old_p - 2);
		*((unsigned short*)old_p) = host_to_be16(len);
	}

	if (ap_rep_interval != 0 || radio_cnt_metrics!= 0) {
		/*metric reporting policy TLV*/
		*p++ = 0x8A;

		old_p = p;

		/*skip tlvLength field*/
		p += 2;

		*p++ = ap_rep_interval;
		*p++ = radio_cnt_metrics;
		for (j = 0; j < radio_cnt_metrics; j++) {
			memcpy(p, metrics_policy->identifier, ETH_ALEN);
			p += ETH_ALEN;
			*p++ = metrics_policy->rssi_thres;
			*p++ = metrics_policy->rssi_margin;
			*p++ = metrics_policy->ch_util_thres;
			*p = ((metrics_policy->traffic_inclusion & 0x01) << 7);
			*p |= ((metrics_policy->metrics_inclusion& 0x01) << 6);
#ifdef MAP_R3_WF6
			*p |= ((metrics_policy->assoc_wf6_inclusion& 0x01) << 5);
#endif
			p++;
			metrics_policy++;
		}

		len = (unsigned short)(p - old_p - 2);
		*((unsigned short*)old_p) = host_to_be16(len);
	}

#ifdef MAP_R2
	if (scan_rep_include) {
		/*channel scan reporting policy TLV*/
		*p++ = 0xA4;
		old_p = p;

		/*skip tlvLength field*/
		p += 2;
		*p++ = scan_rep_policy;
		len = (unsigned short)(p - old_p - 2);
		*((unsigned short*)old_p) = host_to_be16(len);
	}
	if (unsuccess_assoc_policy_include) {
		/* Unsuccessful Association Policy TLV */
		*p++ = 0xC4;
		old_p = p;

		/*skip tlvLength field*/
		p += 2;

		/*   Report Unsuccessful Associations (bit 7)
		**	0: Do not report unsuccessful association attempts
		**	1: Report unsuccessful association attempts
		*/
		if (unsuccess_assoc_policy->report_switch)
			*p++ |= 0x80;

		/* report rate */
		*((unsigned int *)p) = host_to_be32(unsuccess_assoc_policy->report_rate);
		p += sizeof(unsigned int);

		len = (unsigned short)(p - old_p - 2);
		*((unsigned short*)old_p) = host_to_be16(len);
	}

	if (bh_assoc_ctrl_num && bh_assoc_ctrl_info) {
		/*bh bss configuration TLV*/
		int i = 0, total_len = ETH_ALEN + 1;

		for (i = 0; i < bh_assoc_ctrl_num; i++) {
			*p++ = 0xD0;

			/*tlvLength field*/
			*((unsigned short *)p) = host_to_be16(total_len);
			p += 2;

			/* BSSID */
			os_memcpy(p, bh_assoc_ctrl_info->BSSID, ETH_ALEN);
			p += ETH_ALEN;

			*p = 0;
			/* bit7: R1 disallowed status */
			if (bh_assoc_ctrl_info->P1_disallow)
				*p |= 0x80;

			/* bit6: R2 disallowed status */
			if (bh_assoc_ctrl_info->P2_disallow)
				*p |= 0x40;
			p++;
			bh_assoc_ctrl_info++;
		}
	}
#endif // #ifdef MAP_R2

	// TODO: add BSSID to Unique BSS Index mapping TLV (0x83)

	request->len = p - request->body;

	if(_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + sizeof(struct _1905_cmdu_request) + request->len) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}

int _1905_Send_Channel_Preference_Query_Message (IN struct _1905_context* ctx, char* almac)
{
	struct msg *cmd = (struct msg* )cmdu_buf;
	struct _1905_cmdu_request* request = (struct _1905_cmdu_request*)cmd->buffer;

	if (almac == NULL) {
		err(DEBUG_CAT_EVENT, "almac NULL pointer\n");
		return -1;
	}
	cmd->type = LIB_1905_CMDU_REQUEST;
	memcpy(request->dest_al_mac, almac, ETH_ALEN);
	request->type = CHANNEL_PREFERENCE_QUERY;
	request->len = 0;
	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + sizeof(struct _1905_cmdu_request)) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}

int _1905_Send_Channel_Selection_Request_Message (IN struct _1905_context* ctx,
	char* almac, unsigned char ch_prefer_cnt, struct ch_prefer_lib* prefer,
	unsigned char transmit_power_cnt, struct transmit_power_limit* power_limit
#ifdef MAP_R4_SPT
	,unsigned char spt_reuse_count, struct ap_spt_reuse_req *spt_reuse_cap
#endif
#ifdef MAP_VENDOR_SUPPORT
	, unsigned char vendor_prefer_cnt, struct ch_prefer_lib *vendor_prefer
#endif /* MAP_VENDOR_SUPPORT */
#ifdef MAP_R6
	, unsigned char eht_ops_cnt, struct eht_operations_lib *eht_ops
#endif
	)
{
#ifdef MAP_VENDOR_SUPPORT
	u8 MTK_OUI[3] = {0x00, 0x0C, 0xE7};
#endif

	unsigned short len = 0;
	struct msg *cmd = (struct msg* )cmdu_buf;
	struct _1905_cmdu_request* request = (struct _1905_cmdu_request*)cmd->buffer;
	unsigned char *p = request->body;
	unsigned char *old_p = NULL;
	int i = 0, j = 0;

	if (almac == NULL) {
		err(DEBUG_CAT_EVENT, "almac NULL pointer\n");
		return -1;
	}
	if (ch_prefer_cnt > 0 && prefer == NULL) {
		err(DEBUG_CAT_EVENT, "invalid value; ch_prefer_cnt=%d; prefer=NULL\n", ch_prefer_cnt);
		return -1;
	}
	if (transmit_power_cnt > 0 && power_limit == NULL) {
		err(DEBUG_CAT_EVENT, "invalid value; transmit_power_cnt=%d; power_limit=NULL", transmit_power_cnt);
		return -1;
	}
	if (ch_prefer_cnt == 0 && transmit_power_cnt == 0
#ifdef MAP_R4_SPT
		&& spt_reuse_count == 0
#endif
#ifdef MAP_R6
		&& eht_ops_cnt == 0
#endif
	) {
		err(DEBUG_CAT_EVENT, " all cnt equal to 0\n");
		return -1;
	}

#ifdef MAP_R4_SPT
	if (spt_reuse_count > 0 && spt_reuse_cap == NULL) {
		err(DEBUG_CAT_EVENT, "invalid value; spt_reuse_count=%d; spt_reuse_cap=NULL", transmit_power_cnt);
		return -1;
	}
	err(DEBUG_CAT_EVENT, "invalid value; spt_reuse_count=%d; prefer=NULL\n", spt_reuse_count);
#endif

#ifdef MAP_VENDOR_SUPPORT
	if (vendor_prefer_cnt > 0 && vendor_prefer == NULL) {
		err(DEBUG_CAT_EVENT, "invalid value; vvendor_prefer_cnt=%d, vendor_prefer=NULL\n", vendor_prefer_cnt);
		return -1;
	}
#endif /* MAP_VENDOR_SUPPORT */

#ifdef MAP_R6
	if (eht_ops_cnt > 0 && eht_ops == NULL) {
		err(DEBUG_CAT_EVENT, "invalid valud; eht_ops_cnt=%d, eht_ops=NULL\n", eht_ops_cnt);
		return -1;
	}
#endif /* MAP_R6 */

	cmd->type = LIB_1905_CMDU_REQUEST;
	memcpy(request->dest_al_mac, almac, ETH_ALEN);
	request->type = CHANNEL_SELECTION_REQUEST;

	for (i = 0; i < ch_prefer_cnt; i++) {
		/*channel preference TLV*/
		*p++ = 0x8B;
		old_p = p;

		/*skip tlvLength field*/
		p += 2;
		memcpy(p, prefer->identifier, ETH_ALEN);
		p += ETH_ALEN;
		*p++ = prefer->op_class_num;
		for (j = 0; j < prefer->op_class_num; j++) {
			*p++ = prefer->opinfo[j].op_class;
			*p++ = prefer->opinfo[j].ch_num;
			memcpy(p, prefer->opinfo[j].ch_list, prefer->opinfo[j].ch_num);
			p += prefer->opinfo[j].ch_num;
			*p = 0;
			*p |= (unsigned char)((prefer->opinfo[j].perference & 0x0F) << 4);
			*p |= (unsigned char)(prefer->opinfo[j].reason & 0x0F);
			p++;
		}
		len = (unsigned short)(p - old_p - 2);
		*((unsigned short*)old_p) = host_to_be16(len);
		prefer++;

	}

	for (i = 0; i < transmit_power_cnt; i++) {
		/*transmit power limit TLV*/
		*p++ = 0x8D;

		*p++ = 0;
		*p++ = 0x07;

		memcpy(p, power_limit->identifier, ETH_ALEN);
		p += ETH_ALEN;

		*p++ = power_limit->transmit_power_limit;

		power_limit++;
	}
#ifdef MAP_R4_SPT
	for(i = 0; i < spt_reuse_count; i++)
	{/* Spatial Reuse Request TLV*/
		/* DM: need to improve tlv no*/
		*p++ = 0xD8;
		old_p = p;
		/*skip tlvLength field*/
		p += 2;

		memcpy(p, spt_reuse_cap->identifier, ETH_ALEN);
		p += ETH_ALEN;
		*p++ = spt_reuse_cap->bss_color & 0x3F;
		*p++ = (spt_reuse_cap->hesiga_spa_reuse_val_allowed? 0x10 : 0x00) |
				(spt_reuse_cap->srg_info_valid? 0x08 : 0x00) |
				(spt_reuse_cap->nonsrg_offset_valid ? 0x04 : 0x00) |
				(spt_reuse_cap->psr_disallowed ? 0x01 : 0x00);

		if(spt_reuse_cap->nonsrg_offset_valid)
			*p++ = spt_reuse_cap->nonsrg_obsspd_max_offset;
		else
			p++;

		if(spt_reuse_cap->srg_info_valid){
			*p++ = spt_reuse_cap->srg_obsspd_min_offset;
			*p++ = spt_reuse_cap->srg_obsspd_max_offset;
			memcpy(p, spt_reuse_cap->srg_bss_color_bitmap, 8);
			p += 8;
			memcpy(p, spt_reuse_cap->srg_partial_bssid_bitmap, 8);
			p += 8;
		}
		else
			p += 18;
		*p++ = 0;
		*p++ = 0;
		len = (unsigned short)(p - old_p - 2);
		*((unsigned short*)old_p) = host_to_be16(len);
		spt_reuse_cap++;
	}
#endif
#ifdef MAP_VENDOR_SUPPORT
	for (i = 0; i < vendor_prefer_cnt; i++) {
		/*channel preference TLV*/
		*p++ = 11; /* vendor specific TLV */
		old_p = p;
		/*skip tlvLength field*/
		p += 2;
		/* Add OUI Specific field */
		memcpy(p, MTK_OUI, 3);
		p += 3;

		memcpy(p, vendor_prefer->identifier, ETH_ALEN);
		p += ETH_ALEN;
		*p++ = vendor_prefer->op_class_num;
		for (j = 0; j < vendor_prefer->op_class_num; j++) {
			*p++ = vendor_prefer->opinfo[j].op_class;
			*p++ = vendor_prefer->opinfo[j].ch_num;
			memcpy(p, vendor_prefer->opinfo[j].ch_list, vendor_prefer->opinfo[j].ch_num);
			p += vendor_prefer->opinfo[j].ch_num;
			*p = 0;
			*p |= (unsigned char)((vendor_prefer->opinfo[j].perference & 0x0F) << 4);
			*p |= (unsigned char)(vendor_prefer->opinfo[j].reason & 0x0F);
			p++;
		}

		len = (unsigned short)(p - old_p - 2);
		*((unsigned short *)old_p) = host_to_be16(len);
		vendor_prefer++;
	}
#endif /* MAP_VENDOR_SUPPORT */

#ifdef MAP_R6
	for (i = 0; i < eht_ops_cnt; i++) {
		/* ETH Operation TLV */
		*p++ = 0xE7;
		old_p = p;
		/* skip tlvLength field */
		p += 2;

		/* 32 bytes reserved bytes */
		os_memset(p, 0, 32);
		p += 32;

		/* num_radio equals to 1 */
		*p++ = 1;

		os_memcpy(p, eht_ops->ruid, ETH_ALEN);
		p += ETH_ALEN;

		/* num_bss equals to 1 */
		*p++ = 1;

		os_memcpy(p, eht_ops->bssid, ETH_ALEN);
		p += ETH_ALEN;

		*p++ = eht_ops->eht_operation_information_valid;

		os_memcpy(p, &eht_ops->eht_mcs_nss_set, sizeof(struct eht_mcs_nss));
		p += sizeof(struct eht_mcs_nss);

		*p++ = eht_ops->control;
		*p++ = eht_ops->ccfs0;
		*p++ = eht_ops->ccfs1;

		*(unsigned short *)p = eht_ops->dscb_bitmap;
		p += 2;

		/* 16 bytes reserved bytes */
		os_memset(p, 0, 16);
		p += 16;

		len = (unsigned short)(p - old_p - 2);
		*((unsigned short *)old_p) = host_to_be16(len);
		eht_ops++;
	}
#endif /* MAP_R6 */

	request->len = p - request->body;

	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + sizeof(struct _1905_cmdu_request) + request->len) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}

int _1905_Send_Client_Capability_Query_Message (IN struct _1905_context* ctx,
	char* almac, unsigned char *bssid, unsigned char *sta_mac)
{
	struct msg *cmd = (struct msg* )cmdu_buf;
	struct _1905_cmdu_request* request = (struct _1905_cmdu_request*)cmd->buffer;

	if (almac == NULL) {
		err(DEBUG_CAT_EVENT, "almac NULL pointer\n");
		return -1;
	}
	if (bssid == NULL || sta_mac == NULL) {
		err(DEBUG_CAT_EVENT, "%s NULL pointer\n", bssid == NULL ? "bssid" : "sta_mac");
		return -1;
	}
	cmd->type = LIB_1905_CMDU_REQUEST;
	memcpy(request->dest_al_mac, almac, ETH_ALEN);
	request->type = CLIENT_CAPABILITY_QUERY;
	request->len = 2 * ETH_ALEN;
	memcpy(request->body, bssid, ETH_ALEN);
	memcpy(request->body + ETH_ALEN, sta_mac, ETH_ALEN);
	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + sizeof(struct _1905_cmdu_request) + 2 * ETH_ALEN) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}

int _1905_Send_AP_Metrics_Query_Message (IN struct _1905_context* ctx,
	char* almac, unsigned char bssid_cnt, unsigned char *bssid_list
#ifdef MAP_R2
	, unsigned char radio_cnt, unsigned char *identifier_list
#endif
	)
{
	struct msg *cmd = (struct msg* )cmdu_buf;
	unsigned char* p = NULL, *p_old = NULL;
	struct _1905_cmdu_request* request = (struct _1905_cmdu_request*)cmd->buffer;

	if (almac == NULL) {
		err(DEBUG_CAT_EVENT, "almac NULL pointer\n");
		return -1;
	}
	if (bssid_cnt == 0 || bssid_list == NULL) {
		err(DEBUG_CAT_EVENT, "%s\n", bssid_cnt == 0 ? "bssid_cnt must be no less than 1" : "bssid_list NULL pointer");
		return -1;
	}

	cmd->type = LIB_1905_CMDU_REQUEST;
	memcpy(request->dest_al_mac, almac, ETH_ALEN);
	request->type = AP_LINK_METRICS_QUERY;

	p = request->body;

	/* One AP metric query TLV */
	*p++ = 0x93;

	p_old = p;
	p += 2;

	*p++ = bssid_cnt;

	memcpy(p, bssid_list, bssid_cnt * ETH_ALEN);
	p += bssid_cnt * ETH_ALEN;

	*((unsigned short*)p_old) = host_to_be16(p - p_old - 2);

#ifdef MAP_R2
	if (identifier_list){
		int i = 0;
		unsigned char *p_identifier_list = NULL;

		p_identifier_list = identifier_list;
		/* Zero or more AP Radio Identifier TLVs */
		for (i = 0; i < radio_cnt; i ++) {
			*p++ = 0x82;

			p_old = p;

			*(unsigned short *)p = ETH_ALEN;
			p += 2;

			memcpy(p, p_identifier_list, ETH_ALEN);
			p += ETH_ALEN;
			p_identifier_list += ETH_ALEN;

			*((unsigned short*)p_old) = host_to_be16(p - p_old - 2);
		}
	}
#endif


	request->len = (unsigned short)(p - request->body);


	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + sizeof(struct _1905_cmdu_request) + request->len) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}

int _1905_Send_Associated_STA_Link_Metrics_Query_Message (IN struct _1905_context* ctx,
	char* almac, unsigned char *sta_mac)
{
	struct msg *cmd = (struct msg*)cmdu_buf;
	unsigned char* p = NULL;
	struct _1905_cmdu_request* request = (struct _1905_cmdu_request*)cmd->buffer;

	if (almac == NULL) {
		err(DEBUG_CAT_EVENT, "almac NULL pointer\n");
		return -1;
	}
	if (sta_mac == NULL) {
		err(DEBUG_CAT_EVENT, "sta_mac NULL pointer\n");
		return -1;
	}
	cmd->type = LIB_1905_CMDU_REQUEST;
	memcpy(request->dest_al_mac, almac, ETH_ALEN);
	request->type = ASSOC_STA_LINK_METRICS_QUERY;
	p = request->body;

	/*sta mac address tlv*/
	*p++ = 0x95;

	*p++ = 0x00;
	*p++ = 0x06;

	memcpy(p, sta_mac, ETH_ALEN);
	request->len = 9;

	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + sizeof(struct _1905_cmdu_request) + request->len) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}

int _1905_Send_Unassociated_STA_Link_Metrics_Query_Message (IN struct _1905_context* ctx,
	char* almac, struct unassoc_sta_link_metrics_query *query)
{
	struct msg *cmd = (struct msg*)cmdu_buf;
	unsigned char* p = NULL, *p_old = NULL;
	unsigned char i = 0;
	struct _1905_cmdu_request* request = (struct _1905_cmdu_request*)cmd->buffer;

	if (almac == NULL) {
		err(DEBUG_CAT_EVENT, "almac NULL pointer\n");
		return -1;
	}
	if (query == NULL) {
		err(DEBUG_CAT_EVENT, "query NULL pointer\n");
		return -1;
	}

	cmd->type = LIB_1905_CMDU_REQUEST;

	memcpy(request->dest_al_mac, almac, ETH_ALEN);
	request->type = UNASSOC_STA_LINK_METRICS_QUERY;

	p = request->body;

	/*unassociated sta link metrics query tlv*/
	*p++ = 0x97;

	p_old = p;
	p += 2;

	*p++ = query->op_class;
	*p++ = query->ch_num;

	for (i = 0; i < query->ch_num; i++) {
		*p++ = query->unassoc_link_query_sub[i].channel;
		*p++ = query->unassoc_link_query_sub[i].sta_num;
		memcpy(p, query->unassoc_link_query_sub[i].sta_mac, query->unassoc_link_query_sub[i].sta_num * ETH_ALEN);
		p += query->unassoc_link_query_sub[i].sta_num * ETH_ALEN;
	}

	request->len = (unsigned short)(p - request->body);

	*((unsigned short*)p_old) = host_to_be16((request->len - 3));

	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + sizeof(struct _1905_cmdu_request) + request->len) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}

}

int _1905_Send_Beacon_Metrics_Query_Message (IN struct _1905_context* ctx, char* almac,
	struct beacon_metrics_query *query)
{
	struct msg *cmd = (struct msg*)cmdu_buf;
	unsigned char* p = NULL, *p_old = NULL;
	unsigned char i = 0;

	if (almac == NULL) {
		err(DEBUG_CAT_EVENT, "almac NULL pointer\n");
		return -1;
	}
	if (query == NULL) {
		err(DEBUG_CAT_EVENT, "query NULL pointer\n");
		return -1;
	}
	cmd->type = LIB_1905_CMDU_REQUEST;
	struct _1905_cmdu_request* request = (struct _1905_cmdu_request*)cmd->buffer;

	memcpy(request->dest_al_mac, almac, ETH_ALEN);
	request->type = BEACON_METRICS_QUERY;

	p = request->body;

	/*beacon metrics query tlv*/
	*p++ = 0x99;

	p_old = p;
	p += 2;

	memcpy(p, query->sta_mac, ETH_ALEN);
	p += ETH_ALEN;

	*p++ = query->oper_class;
	*p++ = query->ch;

	memcpy(p, query->bssid, ETH_ALEN);
	p += ETH_ALEN;

	*p++ = query->rpt_detail_val;
	*p++ = query->ssid_len;

	memcpy(p, query->ssid, query->ssid_len);
	p += query->ssid_len;

	if (query->ch != 255) {
		query->ap_ch_rpt_num = 0;
	}
	*p++ = query->ap_ch_rpt_num;
	for (i = 0; i < query->ap_ch_rpt_num; i++) {
		*p++ = query->rpt[i].ch_rpt_len;
		*p++ = query->rpt[i].oper_class;
		memcpy(p, query->rpt[i].ch_list, query->rpt[i].ch_rpt_len - 1);
		p += (query->rpt[i].ch_rpt_len - 1);
	}

	if (query->rpt_detail_val != 1) {
		query->elemnt_num = 0;
	}
	*p++ = query->elemnt_num;
	memcpy(p, query->elemnt_list, query->elemnt_num);
	p += query->elemnt_num;

	request->len = (unsigned short)(p - request->body);

	*((unsigned short*)p_old) = host_to_be16((request->len - 3));
	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + sizeof(struct _1905_cmdu_request) + request->len) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}

int _1905_Send_Combined_Infrastructure_Metrics_Message (IN struct _1905_context* ctx,
	char* almac, unsigned char ap_metrics_cnt, struct GNU_PACKED ap_metrics_info_lib *metrics_info,
	unsigned char bh_link_cnt, struct tx_link_metrics* tx_metrics_bh_ap,
	struct tx_link_metrics *tx_metrics_bh_sta, struct rx_link_metrics* rx_metrics_bh_ap,
	struct rx_link_metrics *rx_metrics_bh_sta)
{
	unsigned short len = 0;
	struct msg* cmd = (struct msg*)cmdu_buf;
	struct _1905_cmdu_request* request = (struct _1905_cmdu_request*)cmd->buffer;
	unsigned char *p = request->body;
	unsigned char *old_p = NULL;
	unsigned char *old_p_2 = NULL;
	unsigned char ac[4] = {0x01, 0x00, 0x03, 0x02};
	int i = 0, j = 0, k = 0;

	if (almac == NULL) {
		err(DEBUG_CAT_EVENT, "almac NULL pointer\n");
		return -1;
	}
	if (ap_metrics_cnt > 0 && metrics_info == NULL) {
		err(DEBUG_CAT_EVENT, "metrics_info NULL pointer\n");
		return -1;
	}
	if (bh_link_cnt > 0 && (tx_metrics_bh_ap == NULL || tx_metrics_bh_sta == NULL
		|| rx_metrics_bh_ap == NULL || rx_metrics_bh_sta == NULL)) {
		err(DEBUG_CAT_EVENT, "invalid value; NULL pointer\n");
		return -1;
	}
	if (ap_metrics_cnt == 0 && bh_link_cnt == 0) {
		err(DEBUG_CAT_EVENT, "invalid value; ap_metrics_cnt and bh_link_cnt could not be 0 at same time\n");
		return -1;
	}
	cmd->type = LIB_1905_CMDU_REQUEST;
	memcpy(request->dest_al_mac, almac, ETH_ALEN);
	request->type = COMBINED_INFRASTRUCTURE_METRICS;

	for (i = 0; i < ap_metrics_cnt; i++) {
		/*ap metrics TLV*/
		*p++ = 0x94;
		old_p = p;

		/*skip tlvLength field*/
		p += 2;
		memcpy(p, metrics_info->bssid, ETH_ALEN);
		p += ETH_ALEN;
		*p++ = metrics_info->ch_util;

		*((unsigned short*)p) = host_to_be16(metrics_info->assoc_sta_cnt);
		p += sizeof(unsigned short);

		old_p_2 = p;
		*old_p_2 = 0x00;
		p++;
		for (k = 0; k < 4; k++) {
			for (j = 0; j < metrics_info->valid_esp_count; j++) {
				if (ac[k] == metrics_info->esp[j].ac) {
					*old_p_2 |= (0x01 << (7 - k));
					if (metrics_info->esp[j].ba_win_size > 7) {
						err(DEBUG_CAT_EVENT, "len pre check fail\n");
						return -1;
					}

					if (metrics_info->esp[j].format > 3) {
						err(DEBUG_CAT_EVENT, "len pre check fail\n");
						return -1;
					}
					*p++ = metrics_info->esp[j].ppdu_dur_target;
					*p++ = metrics_info->esp[j].e_air_time_fraction;
					*p++ = (metrics_info->esp[j].ba_win_size << 5) |
						(metrics_info->esp[j].format << 3) | metrics_info->esp[j].ac;
				}
			}
		}
		/*AC_BE is fixed*/
		if (((*old_p_2) & 0x80) == 0) {
			err(DEBUG_CAT_EVENT, "error content; does not contain AC_BE %02x\n", *old_p_2);
			return -1;
		}
		len = (unsigned short)(p - old_p - 2);
		*((unsigned short*)old_p) = host_to_be16(len);
		metrics_info++;
	}

	for (i = 0; i < bh_link_cnt; i++) {
		/*transmitter link metrics TLV*/
		*p++ = 0x09;

		old_p = p;

		/*skip tlvLength field*/
		p += 2;

		memcpy(p, tx_metrics_bh_ap->almac, ETH_ALEN);
		p += ETH_ALEN;

		memcpy(p, tx_metrics_bh_ap->neighbor_almac, ETH_ALEN);
		p += ETH_ALEN;

		for (j = 0; (j < tx_metrics_bh_ap->link_pair_cnt) && (j < MAX_LINK_NUM); j++) {
			memcpy(p, tx_metrics_bh_ap->metrics[j].mac_address, ETH_ALEN);
			p += ETH_ALEN;
			memcpy(p, tx_metrics_bh_ap->metrics[j].mac_address_neighbor, ETH_ALEN);
			p += ETH_ALEN;

			*((unsigned short*)p) = host_to_be16(tx_metrics_bh_ap->metrics[j].intftype);
			p += sizeof(unsigned short);

			*p++ = tx_metrics_bh_ap->metrics[j].ieee80211_bridgeflg;

			*((unsigned int*)p) = host_to_be32(tx_metrics_bh_ap->metrics[j].packetErrors);
			p += sizeof(unsigned int);

			*((unsigned int*)p) = host_to_be32(tx_metrics_bh_ap->metrics[j].transmittedPackets);
			p += sizeof(unsigned int);

			*((unsigned short*)p) = host_to_be16(tx_metrics_bh_ap->metrics[j].macThroughputCapacity);
			p += sizeof(unsigned short);

			if (tx_metrics_bh_ap->metrics[j].linkAvailability > 100) {
				warn(DEBUG_CAT_EVENT, "tx_metrics_bh_ap linkAvailability(%d) > 100\n",
					tx_metrics_bh_ap->metrics[j].linkAvailability);
				/*
				return -1;
				*/
			}
			*((unsigned short*)p) = host_to_be16(tx_metrics_bh_ap->metrics[j].linkAvailability);
			p += sizeof(unsigned short);

			*((unsigned short*)p) = host_to_be16(tx_metrics_bh_ap->metrics[j].phyRate);
			p += sizeof(unsigned short);
		}
		len = (unsigned short)(p - old_p - 2);
		*((unsigned short*)old_p) = host_to_be16(len);
		tx_metrics_bh_ap++;

		/*transmitter link metrics TLV*/
		*p++ = 0x09;

		old_p = p;

		/*skip tlvLength field*/
		p += 2;

		memcpy(p, tx_metrics_bh_sta->almac, ETH_ALEN);
		p += ETH_ALEN;

		memcpy(p, tx_metrics_bh_sta->neighbor_almac, ETH_ALEN);
		p += ETH_ALEN;

		for (j = 0; j < tx_metrics_bh_sta->link_pair_cnt; j++) {
			memcpy(p, tx_metrics_bh_sta->metrics[j].mac_address, ETH_ALEN);
			p += ETH_ALEN;
			memcpy(p, tx_metrics_bh_sta->metrics[j].mac_address_neighbor, ETH_ALEN);
			p += ETH_ALEN;

			*((unsigned short*)p) = host_to_be16(tx_metrics_bh_sta->metrics[j].intftype);
			p += sizeof(unsigned short);

			*p++ = tx_metrics_bh_sta->metrics[j].ieee80211_bridgeflg;

			*((unsigned int*)p) = host_to_be32(tx_metrics_bh_sta->metrics[j].packetErrors);
			p += sizeof(unsigned int);

			*((unsigned int*)p) = host_to_be32(tx_metrics_bh_sta->metrics[j].transmittedPackets);
			p += sizeof(unsigned int);

			*((unsigned short*)p) = host_to_be16(tx_metrics_bh_sta->metrics[j].macThroughputCapacity);
			p += sizeof(unsigned short);

			if (tx_metrics_bh_sta->metrics[j].linkAvailability > 100) {
				warn(DEBUG_CAT_EVENT, "tx_metrics_bh_sta linkAvailability(%d) > 100\n",
					tx_metrics_bh_sta->metrics[j].linkAvailability);
				/*
				return -1;
				*/
			}
			*((unsigned short*)p) = host_to_be16(tx_metrics_bh_sta->metrics[j].linkAvailability);
			p += sizeof(unsigned short);

			*((unsigned short*)p) = host_to_be16(tx_metrics_bh_sta->metrics[j].phyRate);
			p += sizeof(unsigned short);
		}
		len = (unsigned short)(p - old_p - 2);
		*((unsigned short*)old_p) = host_to_be16(len);
		tx_metrics_bh_sta++;

		/*receiver link metrics TLV*/
		*p++ = 10;

		old_p = p;

		/*skip tlvLength field*/
		p += 2;

		memcpy(p, rx_metrics_bh_ap->almac, ETH_ALEN);
		p += ETH_ALEN;

		memcpy(p, rx_metrics_bh_ap->neighbor_almac, ETH_ALEN);
		p += ETH_ALEN;

		for (j = 0; j < rx_metrics_bh_ap->link_pair_cnt; j++) {
			memcpy(p, rx_metrics_bh_ap->metrics[j].mac_address, ETH_ALEN);
			p += ETH_ALEN;
			memcpy(p, rx_metrics_bh_ap->metrics[j].mac_address_neighbor, ETH_ALEN);
			p += ETH_ALEN;

			*((unsigned short*)p) = host_to_be16(rx_metrics_bh_ap->metrics[j].intftype);
			p += sizeof(unsigned short);

			*((unsigned int*)p) = host_to_be32(rx_metrics_bh_ap->metrics[j].packetErrors);
			p += sizeof(unsigned int);

			*((unsigned int*)p) = host_to_be32(rx_metrics_bh_ap->metrics[j].packetsReceived);
			p += sizeof(unsigned int);

			*p++ = rx_metrics_bh_ap->metrics[j].rssi;
		}
		len = (unsigned short)(p - old_p - 2);
		*((unsigned short*)old_p) = host_to_be16(len);
		rx_metrics_bh_ap++;

		/*receiver link metrics TLV*/
		*p++ = 10;

		old_p = p;

		/*skip tlvLength field*/
		p += 2;

		memcpy(p, rx_metrics_bh_sta->almac, ETH_ALEN);
		p += ETH_ALEN;

		memcpy(p, rx_metrics_bh_sta->neighbor_almac, ETH_ALEN);
		p += ETH_ALEN;

		for (j = 0; j < rx_metrics_bh_sta->link_pair_cnt; j++) {
			memcpy(p, rx_metrics_bh_sta->metrics[j].mac_address, ETH_ALEN);
			p += ETH_ALEN;
			memcpy(p, rx_metrics_bh_sta->metrics[j].mac_address_neighbor, ETH_ALEN);
			p += ETH_ALEN;

			*((unsigned short*)p) = host_to_be16(rx_metrics_bh_sta->metrics[j].intftype);
			p += sizeof(unsigned short);

			*((unsigned int*)p) = host_to_be32(rx_metrics_bh_sta->metrics[j].packetErrors);
			p += sizeof(unsigned int);

			*((unsigned int*)p) = host_to_be32(rx_metrics_bh_sta->metrics[j].packetsReceived);
			p += sizeof(unsigned int);

			*p++ = rx_metrics_bh_sta->metrics[j].rssi;
		}
		len = (unsigned short)(p - old_p - 2);
		*((unsigned short*)old_p) = host_to_be16(len);
		rx_metrics_bh_sta++;
	}
	request->len = p - request->body;

	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + sizeof(struct _1905_cmdu_request) + request->len) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}

int _1905_Send_Client_Steering_Request_Message (IN struct _1905_context* ctx,
	char* almac, struct lib_steer_request *request,  unsigned char tbss_cnt,
	struct lib_target_bssid_info *info
#ifdef MAP_R2
	, struct lib_steer_request_R2 *request_R2,
	unsigned char tbss_cnt_R2, struct lib_target_bssid_info_R2 *info_R2
#endif
	)

{
	unsigned char *p = NULL, *p_old = NULL;
	int i = 0;
	struct msg *cmd = (struct msg*)cmdu_buf;
	struct _1905_cmdu_request* cmdu_request = (struct _1905_cmdu_request*)cmd->buffer;

	if (almac == NULL) {
		err(DEBUG_CAT_EVENT, "almac NULL pointer\n");
		goto fail;
	}

	cmd->type = LIB_1905_CMDU_REQUEST;
	memcpy(cmdu_request->dest_al_mac, almac, ETH_ALEN);
	cmdu_request->type = CLIENT_STEERING_REQUEST;
	p = cmdu_request->body;

	/* One Steering Request TLV in R1 Agent */
	if (request) {
		if ((request->mode & 0xFE) || (request->disassoc_imminent & 0xFE) || (request->abridged & 0xFE)) {
			err(DEBUG_CAT_EVENT, "mode(%d) disassoc_imminent(%d) abridged(%d) all should not be larger than 1\n",
				request->mode, request->disassoc_imminent, request->abridged);
			goto fail;
		}

		/*steering request tlv*/
		*p++ = 0x9B;
		p_old = p;
		p += 2;

		memcpy(p, request->bssid, ETH_ALEN);
		p += ETH_ALEN;

		*p = 0;
		*p |= (request->mode << 7);
		*p |= (request->disassoc_imminent << 6);
		*p |= (request->abridged << 5);
		p++;
		/*
		if (request->mode == 0) {
			*(unsigned short*)p = host_to_be16(request->window);
			p += sizeof(unsigned short);
		}
		*/
		*(unsigned short*)p = host_to_be16(request->window);
		p += sizeof(unsigned short);

		*(unsigned short*)p = host_to_be16(request->timer);
		p += sizeof(unsigned short);

		*p++ = request->sta_cnt;

		memcpy(p, request->sta_list, request->sta_cnt * ETH_ALEN);
		p += request->sta_cnt * ETH_ALEN;

		if (request->mode == 0) {
			if (tbss_cnt != 0) {
				tbss_cnt = 0;
				err(DEBUG_CAT_EVENT, "tbss_cnt must be 0 when mode equal to 0\n");
			}
		} else if (request->mode == 1) {
			if (tbss_cnt == 0) {
				err(DEBUG_CAT_EVENT, "tbss_cnt(%d) must not to set 0 when mode equal to 1\n", tbss_cnt);
				goto fail;
			} else {
				if (tbss_cnt != 1 && (request->sta_cnt != tbss_cnt)) {
					err(DEBUG_CAT_EVENT, "tbss_cnt(%d) must be 1 or equal to sta_cnt(%d)\n",
						tbss_cnt, request->sta_cnt);
					goto fail;
				}

				if (info == NULL) {
					err(DEBUG_CAT_EVENT, "info NULL pointer\n");
					goto fail;
				}
			}
		}

		*p++ = tbss_cnt;
		if (tbss_cnt > 0) {
			for (i = 0; i < tbss_cnt; i++) {
				memcpy(p, info->bssid, ETH_ALEN);
				p += ETH_ALEN;
				*p++ = info->op_class;
				*p++ = info->channel;
				info++;
			}
		}

		/* update R1 len of steering request tlv */
		*((unsigned short*)p_old) = host_to_be16(p - p_old - 2);
	}

#ifdef MAP_R2

	/* Zero or one R2 Steering Request TLV */
	if (request_R2) {
		if ((request_R2->mode & 0xFE) || (request_R2->disassoc_imminent & 0xFE) || (request_R2->abridged & 0xFE)) {
			err(DEBUG_CAT_EVENT, "mode(%d) disassoc_imminent(%d) abridged(%d) all should not be larger than 1\n",
				request_R2->mode, request_R2->disassoc_imminent, request_R2->abridged);
			goto fail;
		}

		/*R2 Steering Request TLV*/
		*p++ = 0xC3;
		p_old = p;
		p += 2;

		memcpy(p, request_R2->bssid, ETH_ALEN);
		p += ETH_ALEN;

		*p = 0;
		*p |= (request_R2->mode << 7);
		*p |= (request_R2->disassoc_imminent << 6);
		*p |= (request_R2->abridged << 5);
		p++;
		/*
		if (request->mode == 0) {
			*(unsigned short*)p = host_to_be16(request->window);
			p += sizeof(unsigned short);
		}
		*/
		*(unsigned short*)p = host_to_be16(request_R2->window);
		p += sizeof(unsigned short);

		*(unsigned short*)p = host_to_be16(request_R2->timer);
		p += sizeof(unsigned short);

		*p++ = request_R2->sta_cnt;

		memcpy(p, request_R2->sta_list, request_R2->sta_cnt * ETH_ALEN);
		p += request_R2->sta_cnt * ETH_ALEN;

		if (request_R2->mode == 0) {
			if (tbss_cnt_R2 != 0) {
				tbss_cnt_R2 = 0;
				err(DEBUG_CAT_EVENT, "tbss_cnt_R2 must be 0 when mode equal to 0\n");
			}
		} else if (request_R2->mode == 1) {
			if (tbss_cnt_R2 == 0) {
				err(DEBUG_CAT_EVENT, "tbss_cnt_R2(%d) must not to set 0 when mode equal to 1\n",
					tbss_cnt_R2);
				goto fail;
			} else {
				if (tbss_cnt_R2 != 1 && (request_R2->sta_cnt != tbss_cnt_R2)) {
					err(DEBUG_CAT_EVENT, "tbss_cnt_R2(%d) must be 1 or equal to sta_cnt(%d)\n",
						tbss_cnt_R2, request_R2->sta_cnt);
					goto fail;
				}

				if (info_R2 == NULL) {
					err(DEBUG_CAT_EVENT, "info_R2 NULL pointer\n");
					goto fail;
				}
			}
		}

		*p++ = tbss_cnt_R2;
		if (tbss_cnt_R2 > 0) {
			for (i = 0; i < tbss_cnt_R2; i++) {
				memcpy(p, info_R2->bssid, ETH_ALEN);
				p += ETH_ALEN;
				*p++ = info_R2->op_class;
				*p++ = info_R2->channel;
				*p++ = info_R2->reason_code;
				info_R2++;
			}
		}

		/* update R2 len of steering request tlv */
		*((unsigned short*)p_old) = host_to_be16(p - p_old - 2);

	}
#endif // #ifdef MAP_R2

	cmdu_request->len = (unsigned short)(p - cmdu_request->body);

	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + sizeof(struct _1905_cmdu_request) + cmdu_request->len) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		goto fail;
	}
	return 0;
fail:
	return -1;
}

int _1905_Send_Client_Association_Control_Request_Message (IN struct _1905_context* ctx,
	char* almac, unsigned char *bssid,  unsigned char control,
	unsigned short valid_time, unsigned char sta_cnt, unsigned char *sta_list
	, unsigned char *vs_tlv, unsigned int vs_len)
{
	struct msg *cmd = (struct msg*)cmdu_buf;
	unsigned char* p = NULL, *p_old = NULL;
	struct _1905_cmdu_request* request = (struct _1905_cmdu_request*)cmd->buffer;

	if (almac == NULL) {
		err(DEBUG_CAT_EVENT, "almac NULL pointer\n");
		return -1;
	}
	if (bssid == NULL) {
		err(DEBUG_CAT_EVENT, "bssid NULL pointer\n");
		return -1;
	}
	if(sta_cnt < 1 || (sta_cnt >= 1 && sta_list == NULL)) {
		err(DEBUG_CAT_EVENT, "%s\n", sta_cnt < 1 ? "sta_cnt must be no less than 1" : "sta_list NULL pointer");
		return -1;
	}
	cmd->type = LIB_1905_CMDU_REQUEST;
	memcpy(request->dest_al_mac, almac, ETH_ALEN);
	request->type = CLIENT_ASSOC_CONTROL_REQUEST;
	p = request->body;

	/*client assoc control request tlv*/
	*p++ = 0x9D;

	p_old = p;
	p += 2;

	memcpy(p, bssid, ETH_ALEN);
	p += ETH_ALEN;

	*p++ = control;
	valid_time = host_to_be16(valid_time);
	memcpy(p, &valid_time, sizeof(unsigned short));
	p += 2;
	*p++ = sta_cnt;
	memcpy(p, sta_list, sta_cnt * ETH_ALEN);

	p += sta_cnt * ETH_ALEN;

	*((unsigned short *)p_old) = host_to_be16((p - request->body - 3));

	if (vs_tlv && (vs_len != 0)) {
		memcpy(p, vs_tlv, vs_len);
		p += vs_len;
	}

	request->len = (unsigned short)(p - request->body);

	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + sizeof(struct _1905_cmdu_request) + request->len) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}

int _1905_Send_Higher_Layer_Data_Message (IN struct _1905_context* ctx, char* almac,
	unsigned char protocol, unsigned short len, unsigned char *payload)
{
	struct msg *cmd = (struct msg*)cmdu_buf;
	unsigned char* p = NULL, *p_old = NULL;
	struct _1905_cmdu_request* request = (struct _1905_cmdu_request*)cmd->buffer;

	if (almac == NULL) {
		err(DEBUG_CAT_EVENT, "almac NULL pointer\n");
		return -1;
	}
	if (len > 0 && payload == NULL) {
		err(DEBUG_CAT_EVENT, "payload NULL pointer\n");
		return -1;
	}
	if (len >= (MAX_LIBBUF_LEN - sizeof(struct msg) - sizeof(struct _1905_cmdu_request)) - 4) {
		err(DEBUG_CAT_EVENT, "payload len too long\n");
		return -1;
	}
	cmd->type = LIB_1905_CMDU_REQUEST;
	memcpy(request->dest_al_mac, almac, ETH_ALEN);
	request->type = HIGHER_LAYER_DATA_MESSAGE;
	p = request->body;

	/*higher layer data tlv*/
	*p++ = 0xA0;

	p_old = p;
	p += 2;

	*p++ = protocol;
	memcpy(p, payload, len);
	p += len;

	request->len = (unsigned short)(p - request->body);

	*((unsigned short*)p_old) = host_to_be16((request->len - 3));

	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + sizeof(struct _1905_cmdu_request) + request->len) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}

int _1905_Send_Backhaul_Steering_Request_Message (IN struct _1905_context* ctx, char* almac,
	unsigned char *sta_mac, unsigned char *bssid, unsigned char opclass, unsigned char channel)
{
	struct msg *cmd = (struct msg*)cmdu_buf;
	unsigned char* p = NULL, *p_old = NULL;
	struct _1905_cmdu_request* request = (struct _1905_cmdu_request*)cmd->buffer;

	if (almac == NULL) {
		err(DEBUG_CAT_EVENT, "almac NULL pointer\n");
		return -1;
	}
	if (sta_mac == NULL || bssid == NULL) {
		err(DEBUG_CAT_EVENT, "%s NULL pointer\n", sta_mac == NULL ? "sta_mac" : "bssid");
		return -1;
	}

	cmd->type = LIB_1905_CMDU_REQUEST;
	memcpy(request->dest_al_mac, almac, ETH_ALEN);
	request->type = BACKHAUL_STEERING_REQUEST;
	p = request->body;

	/*backhaul steering request tlv*/
	*p++ = 0x9E;
	p_old = p;
	p += 2;

	memcpy(p, sta_mac, ETH_ALEN);
	p += ETH_ALEN;

	memcpy(p, bssid, ETH_ALEN);
	p += ETH_ALEN;

	*p++ = opclass;
	*p++ = channel;

	request->len = (unsigned short)(p - request->body);

	*((unsigned short*)p_old) = host_to_be16((request->len - 3));
	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + sizeof(struct _1905_cmdu_request) + request->len) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}


#ifdef MAP_R2

int _1905_Set_CAC_Cap (IN struct _1905_context* ctx,
	IN struct cac_capability_lib * cac_caps, IN int len)
{
	struct msg *cmd = (struct msg* )cmdu_buf;

	if (cac_caps == NULL) {
		err(DEBUG_CAT_EVENT, "cac_caps NULL pointer\n");
		return -1;
	}

	memset(cmdu_buf, 0, sizeof(cmdu_buf));
	cmd->type = LIB_CAC_CAPAB;
	cmd->length = len;

	memcpy(cmd->buffer, cac_caps,  len);
	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + len) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}



int _1905_Set_R2_AP_Cap(IN struct _1905_context* ctx, struct ap_r2_capability *info)
{
	struct msg *cmd = (struct msg* )cmdu_buf;

	if (info == NULL) {
		err(DEBUG_CAT_EVENT, "info NULL pointer\n");
		return -1;
	}
	cmd->type = LIB_R2_AP_CAP;
	cmd->length = sizeof(struct ap_r2_capability);
	os_memcpy(cmd->buffer, (unsigned char*)info, cmd->length);


	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}


int _1905_Set_Metric_collection_interval(IN struct _1905_context* ctx, unsigned int interval)
{
	struct msg *cmd = (struct msg* )cmdu_buf;

	cmd->type = LIB_METRIC_REP_INTERVAL_CAP;
	cmd->length = sizeof(interval);
	os_memcpy(cmd->buffer, (unsigned char *)&interval, sizeof(interval));

	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length) < 0) {
		err(DEBUG_CAT_EVENT,  "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}


int _1905_Set_AP_Extened_Metric(IN struct _1905_context* ctx, struct ap_extended_metrics_lib *info)
{
	struct msg *cmd = (struct msg* )cmdu_buf;

	if (info == NULL) {
		err(DEBUG_CAT_EVENT, "ap_extended_metrics NULL pointer\n");
		return -1;
	}
	cmd->type = LIB_AP_EXTENDED_METRICS_INFO;
	cmd->length = sizeof(struct ap_extended_metrics_lib);
	os_memcpy(cmd->buffer, (unsigned char*)info, sizeof(struct ap_extended_metrics_lib));

	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length) < 0) {
		err(DEBUG_CAT_EVENT,  "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}

int _1905_Set_Assoc_Sta_Extended_Link_Metrics(IN struct _1905_context* ctx, struct sta_extended_metrics_lib *info)
{
	struct msg *cmd = (struct msg* )cmdu_buf;

	if (info == NULL) {
		err(DEBUG_CAT_EVENT, "info NULL pointer\n");
		return -1;
	}
	cmd->type = LIB_ASSOC_STA_EXTENDED_LINK_METRICS;
	cmd->length = sizeof(struct sta_extended_metrics_lib) + info->extended_metric_cnt * sizeof(struct sta_extended_metrics_lib);
	os_memcpy(cmd->buffer, (unsigned char*)info, cmd->length);

	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length) < 0) {
		err(DEBUG_CAT_EVENT,  "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}

/*channel scan feature*/
int _1905_Set_Channel_Scan_Cap (IN struct _1905_context* ctx,
	IN struct scan_capability_lib *scan_caps)
{
	struct msg *cmd = (struct msg* )cmdu_buf;

	if (scan_caps == NULL) {
		err(DEBUG_CAT_EVENT,  "scan_caps=NULL\n");
		return -1;
	}

	//cmd->type = WAPP_CHANNEL_SCAN_CAP;
	cmd->type = LIB_CHANNEL_SCAN_CAPAB;
	cmd->length = sizeof(struct scan_capability_lib) + scan_caps->op_class_num * sizeof(struct scan_opcap);
	memcpy(cmd->buffer, (unsigned char*)scan_caps, cmd->length);
	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}

int _1905_Send_Channel_Scan_Request_Message (
	IN struct _1905_context* ctx, char* almac,
	IN unsigned char fresh_scan, IN int radio_cnt,
	IN struct scan_request_lib *scan_req)
{
	unsigned short len = 0;
	struct msg *cmd = (struct msg* )cmdu_buf;
	struct _1905_cmdu_request* request = (struct _1905_cmdu_request*)cmd->buffer;
	unsigned char *p = request->body;
	unsigned char *old_p = NULL;
	int i = 0, j = 0;

	if (almac == NULL) {
		err(DEBUG_CAT_EVENT, "almac NULL pointer\n");
		return -1;
	}
	if (radio_cnt > 0 && scan_req == NULL) {
		err(DEBUG_CAT_EVENT, "invalid value; radio_cnt=%d; scan_req=NULL\n", radio_cnt);
		return -1;
	}
	if (radio_cnt == 0) {
		err(DEBUG_CAT_EVENT, "radio_cnt is 0\n");
		return -1;
	}
	cmd->type = LIB_1905_CMDU_REQUEST;
	memcpy(request->dest_al_mac, almac, ETH_ALEN);
	request->type = CHANNEL_SCAN_REQUEST;

	/*channel scan request tlv type*/
	*p++ = 0xA6;
	old_p = p;
	/*skip tlvLength field*/
	p += 2;
	/*fresh scan*/
	*p++ = fresh_scan;
	/*number of radio*/
	*p++ = radio_cnt;

	for (i = 0; i < radio_cnt; i++) {
		/*radio identifier*/
		memcpy(p, scan_req->identifier, ETH_ALEN);
		p += ETH_ALEN;
		/*number of operating classes*/
		*p++ = scan_req->op_class_num;
		for (j = 0; j < scan_req->op_class_num; j++) {
			/*operating class*/
			*p++ = scan_req->opcap[j].op_class;
			/*number of channels*/
			*p++ = scan_req->opcap[j].ch_num;
			/*channel list*/
			if (scan_req->opcap[j].ch_num)
				memcpy(p, scan_req->opcap[j].ch_list, scan_req->opcap[j].ch_num);
			p += scan_req->opcap[j].ch_num;
		}
		scan_req++;
	}

	len = (unsigned short)(p - old_p - 2);
	*((unsigned short*)old_p) = host_to_be16(len);
	request->len = p - request->body;

	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + sizeof(struct _1905_cmdu_request) + request->len) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}

}

int _1905_Send_Channel_Scan_Report_Message (
	IN struct _1905_context* ctx, char* almac,
	IN unsigned char ts_len, IN unsigned char *ts_str,
	IN int scan_res_cnt, IN unsigned char *scan_res,
	IN unsigned char *vs_tlv, IN unsigned int vs_len
#ifdef MAP_R6
	, IN unsigned char ap_mld_num, IN unsigned char *ap_mld
#endif
	)
{
	int buf_len = MAX_LIBBUF_LEN;
	unsigned char *buf = (unsigned char *)cmdu_buf;
	unsigned short len = 0;
	struct msg *cmd = NULL;
	struct _1905_cmdu_request *request = NULL;
	unsigned char *p = NULL;
	unsigned char *old_p = NULL, *p_neighbor_cnt = NULL, *p_neighbor = NULL;

#ifdef EM_PLUS_SUPPORT
	int i = 0, j = 0, neighbor_num = 0;
#else
	int i = 0, j = 0;
#endif /* EM_PLUS_SUPPORT */

	unsigned char *psr = scan_res;
	unsigned char *psr_tmp = NULL;
	struct scan_result_lib *pscan_res_tmp = NULL, *pscan_tmp = NULL;
	unsigned short neighbor_cnt = 0;
	u32 total_len = 0, tmp = 0;

#ifdef MAP_R6
	struct mld_struct *mld = (struct mld_struct *)ap_mld;
	struct mld_struct_info *mld_info = NULL;
#endif

	memset(buf, 0, buf_len);
	cmd = (struct msg *)buf;
	request = (struct _1905_cmdu_request *)cmd->buffer;
	p = request->body;

	if (almac == NULL) {
		err(DEBUG_CAT_EVENT, "almac NULL pointer\n");
		return -1;
	}
	if (ts_len > 0 && ts_str == NULL) {
		err(DEBUG_CAT_EVENT, "invalid value; ts_len=%d; ts_str=NULL\n", ts_len);
		return -1;
	}
	if (scan_res_cnt > 0 && scan_res == NULL) {
		err(DEBUG_CAT_EVENT, "invalid value; scan_res_cnt=%d; scan_res=NULL\n", scan_res_cnt);
		return -1;
	}
	if (scan_res_cnt == 0 || ts_len == 0) {
		err(DEBUG_CAT_EVENT, "scan_res_cnt(%d) or ts_len(%d) equal to 0\n",
			scan_res_cnt, ts_len);
		return -1;
	}

	cmd->type = LIB_1905_CMDU_REQUEST;
	memcpy(request->dest_al_mac, almac, ETH_ALEN);
	request->type = CHANNEL_SCAN_REPORT;

	/*timestamp tlv type*/
	*p++ = 0xA8;
	old_p = p;
	/*skip tlvLength field*/
	p += 2;
	/*timestamp length*/
	*p++ = ts_len;
	/*timestamp*/
	memcpy(p, ts_str, ts_len);
	p += ts_len;
	len = (unsigned short)(p - old_p - 2);
	*((unsigned short*)old_p) = host_to_be16(len);

	psr_tmp = psr;
	for (i = 0; i < scan_res_cnt; i++) {
		pscan_tmp = (struct scan_result_lib *)psr_tmp;
		tmp = sizeof(struct scan_result_lib) + pscan_tmp->neighbor_cnt * sizeof(struct scan_neighbor);
		total_len += tmp;
		psr_tmp += tmp;
	}
	if (total_len > (buf_len - sizeof(struct msg) - 4 - ts_len)) {
		err(DEBUG_CAT_EVENT, "len pre check fail\n");
		return -1;
	}
	psr_tmp = scan_res;

	pscan_res_tmp = (struct scan_result_lib *)psr;
	for (i = 0; i < scan_res_cnt; i++) {

#ifdef EM_PLUS_SUPPORT
		neighbor_num = 0;
#else
		j = 0;
#endif /* EM_PLUS_SUPPORT */

		neighbor_cnt = 0;
next_roud:
		/*channel scan result tlv type*/
		*p++ = 0xA7;
		old_p = p;

		/*skip tlvLength field*/
		p += 2;
		/*radio identifier*/
		memcpy(p, pscan_res_tmp->identifier, ETH_ALEN);
		p += ETH_ALEN;
		/*operating class*/
		*p++ = pscan_res_tmp->op_class;
		/*channel*/
		*p++ = pscan_res_tmp->channel;
		/*scan status*/
		*p++ = pscan_res_tmp->scan_status;
		if (pscan_res_tmp->scan_status == 0) {
			/*timestamp length*/
			if (pscan_res_tmp->ts_len > TS_MAX) {
				err(DEBUG_CAT_EVENT, "len pre check fail\n");
				return -1;
			}
			*p++ = pscan_res_tmp->ts_len;
			/*timestamp*/
			memcpy(p, pscan_res_tmp->ts_str, pscan_res_tmp->ts_len);
			p += pscan_res_tmp->ts_len;
			/*utlization*/
			*p++ = pscan_res_tmp->utilization;
			/*Noise*/
			*p++ = pscan_res_tmp->noise;
			/*number of neighbors, fill it later*/
			p_neighbor_cnt = p;
			p += 2;
			if (pscan_res_tmp->neighbor_cnt > 256) {
				err(DEBUG_CAT_EVENT, "len pre check fail\n");
				return -1;
			}

#ifdef EM_PLUS_SUPPORT
			for (j = neighbor_num; j < pscan_res_tmp->neighbor_cnt; j++) {
#else
			for (; j < pscan_res_tmp->neighbor_cnt; j++) {
#endif /* EM_PLUS_SUPPORT */

				p_neighbor = p;
				/*bssid*/
				memcpy(p, pscan_res_tmp->neighbor[j].bssid, ETH_ALEN);
				p += ETH_ALEN;
				/*ssid length*/
				if (pscan_res_tmp->neighbor[j].ssid_len > 32) {
					err(DEBUG_CAT_EVENT, "len pre check fail\n");
					return -1;
				}
				*p++ = pscan_res_tmp->neighbor[j].ssid_len;
				/*ssid*/
				memcpy(p, pscan_res_tmp->neighbor[j].ssid, pscan_res_tmp->neighbor[j].ssid_len);
				p += pscan_res_tmp->neighbor[j].ssid_len;
				/*rssi*/
				*p++ = pscan_res_tmp->neighbor[j].rssi;
				/*channel bw length*/
				if (pscan_res_tmp->neighbor[j].bw_len > BW_MAX) {
					err(DEBUG_CAT_EVENT, "len pre check fail\n");
					return -1;
				}
				*p++ = pscan_res_tmp->neighbor[j].bw_len;
				/*channel bw*/
				memcpy(p, pscan_res_tmp->neighbor[j].bw, pscan_res_tmp->neighbor[j].bw_len);
				p += pscan_res_tmp->neighbor[j].bw_len;
				/*present*/
				*p++ = pscan_res_tmp->neighbor[j].present;
				/*neighbor channel utilization*/
				if (pscan_res_tmp->neighbor[j].present & 0x80)
					*p++ = pscan_res_tmp->neighbor[j].utilization;
				/*neighbor channel utilization*/
				if (pscan_res_tmp->neighbor[j].present & 0x40) {
					*((unsigned short *)p) = host_to_be16(pscan_res_tmp->neighbor[j].sta_cnt);
					p += 2;
				}

				/*if one tlv exceeds the tlv length limiation*/
				if ((p - old_p - 7) > 1467) {
					p = p_neighbor;
					*((unsigned int *)p) = host_to_be32(pscan_res_tmp->agg_scan_dur);
					p += 4;
					/*scan type*/
					*p++ = pscan_res_tmp->scan_type;
					*((unsigned short *)p_neighbor_cnt) = host_to_be16(neighbor_cnt);
					len = (unsigned short)(p - old_p - 2);
					*((unsigned short*)old_p) = host_to_be16(len);
					neighbor_cnt = 0;

#ifdef EM_PLUS_SUPPORT
					neighbor_num = j;
#endif /* EM_PLUS_SUPPORT */

					goto next_roud;
				}
				neighbor_cnt++;
			}
			*((unsigned short *)p_neighbor_cnt) = host_to_be16(neighbor_cnt);
			/*aggregate scan duration*/
			*((unsigned int *)p) = host_to_be32(pscan_res_tmp->agg_scan_dur);
			p += 4;
			/*scan type*/
			*p++ = pscan_res_tmp->scan_type;
		}

		len = (unsigned short)(p - old_p - 2);
		*((unsigned short*)old_p) = host_to_be16(len);
		psr_tmp += sizeof(struct scan_result_lib)+ pscan_res_tmp->neighbor_cnt*sizeof(struct scan_neighbor);

		pscan_res_tmp = (struct scan_result_lib *)psr_tmp;//(struct scan_result_lib *)(psr + len + 3);
	}

#ifdef MAP_R6
	for (i = 0; i < ap_mld_num; i++) {

		*p++ = 0xE3;
		old_p = p;

		/*skip tlvLength field*/
		p += 2;

		/* mld mac */
		os_memcpy(p, mld->ap_mld_mac, ETH_ALEN);
		p += ETH_ALEN;

		/* reserved bytes */
		os_memset(p, 0, 25);
		p += 25;

		/* num affiliated ap */
		*p = mld->num_affiliated_ap;
		p += 1;

		for (j = 0; j < mld->num_affiliated_ap; j++) {
			mld_info = &mld->affiliated_ap[j];

			/* affiliated mac */
			os_memcpy(p, mld_info->bssid, ETH_ALEN);
			p += ETH_ALEN;

			/* reserved bytes */
			os_memset(p, 0, 26);
			p += 26;
		}

		len = (unsigned short)(p - old_p - 2);
		*((unsigned short *)old_p) = host_to_be16(len);

		mld = mld + 1;
	}
#endif

	if (vs_tlv && vs_len) {
		memcpy(p, vs_tlv, vs_len);
		p += vs_len;
	}
	request->len = p - request->body;

	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + sizeof(struct _1905_cmdu_request) + request->len) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}

}


int _1905_Send_Tunneled_Message (IN struct _1905_context* ctx, char* almac,
	IN struct tunneled_message_lib * tunneled_msg)
{
	unsigned short len = 0;
	struct msg *cmd = (struct msg*)cmdu_buf;
	struct _1905_cmdu_request* request = (struct _1905_cmdu_request*)cmd->buffer;
	unsigned char *p = request->body;
	int i = 0;
	struct tunneled_msg_tlv *p_payload = NULL;

	if (almac == NULL) {
		err(DEBUG_CAT_EVENT, "almac NULL pointer\n");
		return -1;
	}
	if (tunneled_msg == NULL) {
		err(DEBUG_CAT_EVENT, "tunneled_msg NULL pointer\n");
		return -1;
	}

	cmd->type = LIB_1905_CMDU_REQUEST;
	memcpy(request->dest_al_mac, almac, ETH_ALEN);
	request->type = TUNNELED_MESSAGE;

	/* one Source Info TLV*/
	/* tlv type 0xC0 */
	*p++ = 0xC0;

	/* tlv lenth 2 octets, value 2 */
	len = ETH_ALEN;
	*((unsigned short*)p) = host_to_be16(len);
	p += 2;

	/* The MAC address of the device that generated the message */
	memcpy(p, tunneled_msg->sta_mac, ETH_ALEN);
	p += ETH_ALEN;

	/* One Tunneled Message Type TLV */
	/* tlv type 0xC1 */
	*p++ = 0xC1;

	/* tlv lenth 2 octets, value 1 */
	len = 1;
	*((unsigned short*)p) = host_to_be16(len);
	p += 2;

	/* Tunneled protocol type 1 octet */
	*p++ = tunneled_msg->proto_type;

	/* One or more Tunneled TLVs */
	p_payload = tunneled_msg->tunneled_msg_tlv;
	for (i = 0; i < tunneled_msg->num_tunneled_tlv; i ++) {
		/* tlv type 0xC2 */
		*p++ = 0xC2;

		/* tlv lenth 2 octets */
		len = (unsigned short)(p_payload->payload_len);
		*((unsigned short*)p) = host_to_be16(len);
		p += 2;

		memcpy(p ,p_payload->payload, p_payload->payload_len);
		p += p_payload->payload_len;
		p_payload = (struct tunneled_msg_tlv *)(p_payload->payload + p_payload->payload_len);
	}

	request->len = (unsigned short)(p - request->body);

	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + sizeof(struct _1905_cmdu_request) + request->len) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}

int _1905_Send_Assoc_Status_Notification_Message (IN struct _1905_context* ctx,
	char* almac, IN struct assoc_notification_lib *assoc_notification)
{
	unsigned char all_agent_mac[ETH_ALEN] = { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff };
	unsigned short len = 0;
	struct msg *cmd = (struct msg*)cmdu_buf;
	struct _1905_cmdu_request* request = (struct _1905_cmdu_request*)cmd->buffer;
	unsigned char *p = request->body;
	unsigned char *old_p = NULL;
	int i = 0, j = 0;
	struct assoc_notification_tlv *notify_tlv = NULL;
	struct assoc_status *p_assoc_status = NULL;

	if (assoc_notification == NULL) {
		err(DEBUG_CAT_EVENT, "assoc_notification NULL pointer\n");
		return -1;
	}

	cmd->type = LIB_1905_CMDU_REQUEST;
	if (almac == NULL) {
		memcpy(request->dest_al_mac, all_agent_mac, ETH_ALEN);
	}
	else {
		memcpy(request->dest_al_mac, almac, ETH_ALEN);
	}
	request->type = ASSOCIATION_STATUS_NOTIFICATION;

	notify_tlv = assoc_notification->notification_tlv;

	/* one or more Association Status Notification TLVs */
	for (i = 0; i < assoc_notification->assoc_notification_tlv_num; i ++) {

		/* tlv type 0xBF */
		*p++ = 0xBF;
		old_p = p;
		p += 2;

		/* Number of BSSIDs and their statuses included in this TLV */
		*p++ = notify_tlv->bssid_num;
		p_assoc_status = notify_tlv->status;

		for (j = 0; j < notify_tlv->bssid_num; j ++) {

			memcpy(p, p_assoc_status->bssid, ETH_ALEN);
			p += ETH_ALEN;

			*p++ = p_assoc_status->status;

			p_assoc_status += 1;
		}

	    	len = (unsigned short)(p - old_p - 2);
	    	*((unsigned short*)old_p) = host_to_be16(len);

		notify_tlv = (struct assoc_notification_tlv *)((unsigned char *)notify_tlv->status + notify_tlv->bssid_num * sizeof(struct assoc_status));
	}

	request->len = (unsigned short)(p - request->body);



	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + sizeof(struct _1905_cmdu_request) + request->len) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}

int _1905_Send_CAC_Request_Message (IN struct _1905_context* ctx, char* almac,
	IN struct cac_request_lib * cac_req)
{
	unsigned short len = 0;
	struct msg *cmd = (struct msg*)cmdu_buf;
	struct _1905_cmdu_request* request = (struct _1905_cmdu_request*)cmd->buffer;
	unsigned char *p = request->body;
	unsigned char *old_p = NULL;
	int i = 0;
	struct cac_req *p_cac_req = NULL;

	if (cac_req == NULL) {
		err(DEBUG_CAT_EVENT, "cac_req NULL pointer\n");
		return -1;
	}

	cmd->type = LIB_1905_CMDU_REQUEST;
	memcpy(request->dest_al_mac, almac, ETH_ALEN);
	request->type = CAC_REQUEST;

	/* tlv type 0xAD */
	*p++ = 0xAD;
	old_p = p;
	p += 2;

	*p++ = cac_req->num_radio;

	/* one or more Association Status Notification TLVs */
	p_cac_req = cac_req->req;
	for (i = 0; i < cac_req->num_radio; i ++) {


		/* Number of BSSIDs and their statuses included in this TLV */
		memcpy(p, p_cac_req->identifier, ETH_ALEN);
		p += ETH_ALEN;

		*p++ = p_cac_req->op_class_num;

		*p++ = p_cac_req->ch_num;
		*p = 0;//initialize to 0
		*p |= (p_cac_req->cac_method << 5) & 0xE0;
		*p |= (p_cac_req->cac_action << 3) & 0x18;
		p++;


		p_cac_req += 1;
	}
	len = (unsigned short)(p - old_p - 2);
	*((unsigned short*)old_p) = host_to_be16(len);

	request->len = (unsigned short)(p - request->body);

	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + sizeof(struct _1905_cmdu_request) + request->len) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}

int _1905_Send_CAC_Terminate_Message (IN struct _1905_context* ctx, char* almac,
	IN struct cac_terminate_lib * cac_term)
{
	unsigned short len = 0;
	struct msg *cmd = (struct msg*)cmdu_buf;
	struct _1905_cmdu_request* request = (struct _1905_cmdu_request*)cmd->buffer;
	unsigned char *p = request->body;
	unsigned char *old_p = NULL;
	int i = 0;
	struct cac_term *p_cac_term = NULL;

	if (cac_term == NULL) {
		err(DEBUG_CAT_EVENT, "cac_term NULL pointer\n");
		return -1;
	}

	cmd->type = LIB_1905_CMDU_REQUEST;
	memcpy(request->dest_al_mac, almac, ETH_ALEN);
	request->type = CAC_TERMINATION;

	/* tlv type 0xAE */
	*p++ = 0xAE;
	old_p = p;
	p += 2;
	*p++ = cac_term->num_radio;

	/* one or more Association Status Notification TLVs */
	p_cac_term = cac_term->term_tlv;
	for (i = 0; i < cac_term->num_radio; i ++) {


		/* Number of BSSIDs and their statuses included in this TLV */
		memcpy(p, p_cac_term->identifier, ETH_ALEN);
		p += ETH_ALEN;

		*p++ = p_cac_term->op_class_num;

		*p++ = p_cac_term->ch_num;

		p_cac_term ++;
	}
	len = (unsigned short)(p - old_p - 2);
	*((unsigned short*)old_p) = host_to_be16(len);

	request->len = (unsigned short)(p - request->body);

	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + sizeof(struct _1905_cmdu_request) + request->len) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}


int _1905_Send_Client_Disassociation_Stats_Message(IN struct _1905_context* ctx,
	char *almac, unsigned short reason_code, struct stat_info *stat
#ifdef MAP_R6
	, IN struct sta_mld_traffic_stats *mlo_all_stats
#endif
	)
{
	struct msg *cmd = (struct msg*)cmdu_buf;
	struct _1905_cmdu_request* request = (struct _1905_cmdu_request*)cmd->buffer;
	unsigned char *p = request->body;
	unsigned char *p_old = NULL;

	if (stat == NULL) {
		err(DEBUG_CAT_EVENT, "stat NULL pointer\n");
		return -1;
	}
	cmd->type = LIB_1905_CMDU_REQUEST;
	memcpy(request->dest_al_mac, almac, ETH_ALEN);
	request->type = CLIENT_DISASSOCIATION_STATS;

	/* One STA MAC Address TLV */
	*p++ = 0x95;
	*(unsigned short *)p = host_to_be16(ETH_ALEN);
	p += sizeof(unsigned short);

	memcpy(p, stat->mac, ETH_ALEN);
	p += ETH_ALEN;

	/* One Disassociation Reason Code TLV */
	*p++ = 0xCA;
	*(unsigned short *)p = host_to_be16(sizeof(unsigned short));
	p += sizeof(unsigned short);

	*(unsigned short *)p = host_to_be16(reason_code);
	p += sizeof(unsigned short);

	/* One Associated STA Traffic Stats TLV */
	*p++ = 0xA2;
	p_old = p;
	p += sizeof(unsigned short);

	memcpy(p, stat->mac, ETH_ALEN);
	p += ETH_ALEN;

	*(unsigned int *)p = host_to_be32(stat->bytes_sent);
	p += sizeof(unsigned int);

	*(unsigned int *)p = host_to_be32(stat->bytes_received);
	p += sizeof(unsigned int);

	*(unsigned int *)p = host_to_be32(stat->packets_sent);
	p += sizeof(unsigned int);

	*(unsigned int *)p = host_to_be32(stat->packets_received);
	p += sizeof(unsigned int);

	*(unsigned int *)p = host_to_be32(stat->tx_packets_errors);
	p += sizeof(unsigned int);

	*(unsigned int *)p = host_to_be32(stat->rx_packets_errors);
	p += sizeof(unsigned int);

	*(unsigned int *)p = host_to_be32(stat->retransmission_count);
	p += sizeof(unsigned int);
	*((unsigned short *)p_old) = host_to_be16(p - p_old - 2);

#ifdef MAP_R6
	/* Zero or more Affiliated STA Metrics TLV */
	if (mlo_all_stats && mlo_all_stats->sta_cnt > 0) {
		unsigned char idx = 0;

		while (idx < mlo_all_stats->sta_cnt) {
			*p++ = 0xE4;
			p_old = p;
			p += sizeof(unsigned short);

			os_memcpy(p, mlo_all_stats->stats[idx].mac, ETH_ALEN);
			p += ETH_ALEN;

			*(unsigned int *)p = host_to_be32(mlo_all_stats->stats[idx].bytes_sent);
			p += sizeof(unsigned int);

			*(unsigned int *)p = host_to_be32(mlo_all_stats->stats[idx].bytes_received);
			p += sizeof(unsigned int);

			*(unsigned int *)p = host_to_be32(mlo_all_stats->stats[idx].packets_sent);
			p += sizeof(unsigned int);

			*(unsigned int *)p = host_to_be32(mlo_all_stats->stats[idx].packets_received);
			p += sizeof(unsigned int);

			*(unsigned int *)p = host_to_be32(mlo_all_stats->stats[idx].tx_packets_errors);
			p += sizeof(unsigned int);
			idx++;

			*((unsigned short *)p_old) = host_to_be16(p - p_old - 2);
		}
	}
#endif
	request->len = p - request->body;

	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + sizeof(struct _1905_cmdu_request) + request->len) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}


int _1905_Send_Failed_Connection_message(IN struct _1905_context *ctx,
	char* almac, char* sta_mac, unsigned short status, unsigned short reason
#ifdef MAP_R3
	, unsigned char *bssid
#endif
	)
{
	struct msg *cmd = (struct msg*)cmdu_buf;
	struct _1905_cmdu_request* request = (struct _1905_cmdu_request*)cmd->buffer;
	unsigned char *p = request->body;

	if (almac == NULL || sta_mac == NULL) {
		err(DEBUG_CAT_EVENT, "NULL pointer; almac=%p; sta_mac=%p\n",
			almac, sta_mac);
		return -1;
	}
	cmd->type = LIB_1905_CMDU_REQUEST;
	memcpy(request->dest_al_mac, almac, ETH_ALEN);
	request->type = FAILED_CONNECTION_MESSAGE;

#ifdef MAP_R3
	/* One BSSID TLV */
	if (bssid) {
		*p++ = 0xB8;
		*(unsigned short *)p = host_to_be16(ETH_ALEN);
		p += sizeof(unsigned short);

		memcpy(p, bssid, ETH_ALEN);
		p += ETH_ALEN;
	}
#endif
	/* One STA MAC Address TLV */
	*p++ = 0x95;
	*(unsigned short *)p = host_to_be16(ETH_ALEN);
	p += sizeof(unsigned short);

	memcpy(p, sta_mac, ETH_ALEN);
	p += ETH_ALEN;

	/* One Association Status Code TLV */
	*p++ = 0xC9;
	*(unsigned short *)p = host_to_be16(sizeof(unsigned short));
	p += sizeof(unsigned short);

	*(unsigned short *)p = host_to_be16(status);
	p += sizeof(unsigned short);

	if (!status) {
		/* zero or One Reason Code TLV */
		*p++ = 0xCA;
		*(unsigned short *)p = host_to_be16(sizeof(unsigned short));
		p += sizeof(unsigned short);

		*(unsigned short *)p = host_to_be16(reason);
		p += sizeof(unsigned short);
	}


	request->len = p - request->body;


	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + sizeof(struct _1905_cmdu_request) + request->len) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}

int _1905_Send_BH_Sta_Cap_Query (IN struct _1905_context *ctx, char *almac)
{
	struct msg *cmd = (struct msg* )cmdu_buf;
	struct _1905_cmdu_request* request = (struct _1905_cmdu_request*)cmd->buffer;

	if (almac == NULL) {
		err(DEBUG_CAT_EVENT, "almac NULL pointer\n");
		return -1;
	}

	cmd->type = LIB_1905_CMDU_REQUEST;
	memcpy(request->dest_al_mac, almac, ETH_ALEN);
	request->type = BACKHAUL_STA_CAP_QUERY_MESSAGE;
	request->len = 0;
	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + sizeof(struct _1905_cmdu_request)) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}

#endif // MAP_R2

#ifdef MAP_R3
int _1905_set_connector(IN struct _1905_context* ctx, struct dpp_sec_cred *dpp_sec)
{
	struct msg *cmd = (struct msg*)cmdu_buf;
	unsigned char *p = cmd->buffer;

	if (ctx == NULL) {
		warn(DEBUG_CAT_DPP, "ctx NULL pointer");
		return -1;
	}

	cmd->type = LIB_SET_1905_CONNECTOR;

	/* decrypt_threshold */
	if (dpp_sec == NULL)
		*(unsigned short *)p = 0;
	else
		*(unsigned short *)p = dpp_sec->decrypt_threshold;
	p += 2;

	/* connector len and connector */
	if (dpp_sec == NULL)
		*(unsigned short *)p = 0;
	else
		*(unsigned short *)p = dpp_sec->connector_len;
	p += 2;

	if (dpp_sec != NULL) {
		os_memcpy(p, dpp_sec->payload, dpp_sec->connector_len);
		p += dpp_sec->connector_len;

		/* CSignKeyLen and CSignKey */
		*(unsigned short *)p = dpp_sec->csign_len;
		p += 2;

		os_memcpy(p, dpp_sec->payload+dpp_sec->connector_len, dpp_sec->csign_len);
		p += dpp_sec->csign_len;

		/* netAccessKeyLen and netAccesskey */
		*(unsigned short *)p = dpp_sec->netaccesskey_len;
		p += 2;

		os_memcpy(p, dpp_sec->payload+dpp_sec->connector_len+dpp_sec->csign_len,
			dpp_sec->netaccesskey_len);
		p += dpp_sec->netaccesskey_len;

		/* netAccesskey expiry */
		*(unsigned int *)p = dpp_sec->netaccesskey_expiry;
		p += sizeof(unsigned int);
	}

	cmd->length = (unsigned short)(p - cmd->buffer);

	//hex_dump("set 1905 connector", cmd->buffer, cmd->length);

	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length) < 0) {
		warn(DEBUG_CAT_DPP, "_1905_interface_ctrl_request error");
		return -1;
	} else {
		return 0;
	}
}


int _1905_set_bss_connector(IN struct _1905_context* ctx, struct dpp_bss_cred *dpp_sec)
{
	struct msg *cmd = (struct msg*)cmdu_buf;
	unsigned char *p = cmd->buffer;

	if (ctx == NULL) {
		warn(DEBUG_CAT_DPP, "ctx NULL pointer");
		return -1;
	}
	if (dpp_sec == NULL) {
		warn(DEBUG_CAT_DPP, "%s NULL pointer", __func__);
		return -1;
	}

	if (dpp_sec->payload_len != dpp_sec->bh_connect_len + dpp_sec->fh_connect_len) {
		warn(DEBUG_CAT_DPP, "%s len mismatch, total %d bh %d fh %d", __func__,
			dpp_sec->payload_len, dpp_sec->bh_connect_len, dpp_sec->fh_connect_len);
		return -1;
	}

	cmd->type = LIB_SET_BSS_CONNECTOR;

	/* enrollee apcli mac address */
	os_memcpy(p, dpp_sec->mac_apcli, ETH_ALEN);
	p += ETH_ALEN;

	/* enrollee almac address */
	os_memcpy(p, dpp_sec->almac, ETH_ALEN);
	p += ETH_ALEN;

	/* bh connector len */
	*(unsigned short *)p = dpp_sec->bh_connect_len;
	p += 2;

	/* fh connector len */
	*(unsigned short *)p = dpp_sec->fh_connect_len;
	p += 2;

	os_memcpy(p, dpp_sec->payload, dpp_sec->payload_len);
	p += dpp_sec->payload_len;

	cmd->length = (unsigned short)(p - cmd->buffer);

	//hex_dump("set bss connector", cmd->buffer, cmd->length);

	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length) < 0) {
		warn(DEBUG_CAT_DPP, "_1905_interface_ctrl_request error");
		return -1;
	} else {
		return 0;
	}
}


int _1905_set_chirp_value(IN struct _1905_context* ctx,
	struct chirp_info *chirp)
{
	struct msg *cmd = (struct msg*)cmdu_buf;
	unsigned char *p = cmd->buffer;

	if (ctx == NULL) {
		warn(DEBUG_CAT_DPP, "ctx NULL pointer");
		return -1;
	}

	if (chirp && (chirp->chirp_cnt != 1)) {
		warn(DEBUG_CAT_DPP, "chirp count %d is not eqaul to 1", chirp->chirp_cnt);
		return -1;
	}

	cmd->type = LIB_SET_CHIRP_VALUE;

	if (chirp == NULL)
		os_memset(p, 0, ETH_ALEN);
	else
		os_memcpy(p, chirp->almac, ETH_ALEN);
	p += ETH_ALEN;

	if (chirp == NULL)
		os_memset(p, 0, sizeof(struct chirp_tlv_info));
	else
		os_memcpy(p, chirp->item, sizeof(struct chirp_tlv_info));
	p+=sizeof(struct chirp_tlv_info);
	cmd->length = (unsigned short)(p - cmd->buffer);

	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length) < 0) {
		warn(DEBUG_CAT_DPP, "_1905_interface_ctrl_request error");
		return -1;
	} else {
		return 0;
	}
}

int _1905_Send_Proxied_Encap_DPP_Message (IN struct _1905_context* ctx, char* almac, struct dpp_msg *msg)
{
	struct msg *cmd = (struct msg*)cmdu_buf;
	struct _1905_cmdu_request* request = (struct _1905_cmdu_request*)cmd->buffer;
	unsigned char *p = request->body;
	unsigned char *p_bitmap = NULL, *p_len = NULL;
	int i = 0;
	char frame_str[36] = {0};

	if (ctx == NULL) {
		warn(DEBUG_CAT_DPP, "ctx NULL pointer");
		return -1;
	}
	if (almac == NULL) {
		warn(DEBUG_CAT_DPP, "almac NULL pointer");
		return -1;
	}

	if (!msg->payload_len) {
		warn(DEBUG_CAT_DPP, "dpp_frame payload length zero");
		return -1;
	}

	cmd->type = LIB_1905_CMDU_REQUEST;
	memcpy(request->dest_al_mac, almac, ETH_ALEN);
	request->type = PROXIED_ENCAP_DPP_MESSAGE;

	/* One 1905 Encap DPP TLV */
	/* tlv type 0xCD */
	*p++ = 0xCD;

	p_len = p;
	p += 2;

	p_bitmap = p++;

	*p_bitmap = 0;

    /* Enrollee MAC Address Present */
	if (msg->dpp_info.enrollee_mac_flag) {
		*p_bitmap |= 0x80;

        /* Destination STA MAC Address  */
		memcpy(p, msg->dpp_info.enrollee_mac, ETH_ALEN);
		p += ETH_ALEN;
	}

    /* Channel List Present */
	if (msg->dpp_info.chn_list_flag) {
		*p_bitmap |= 0x40;

        /* Number of Operating Classes */
		*p++ = msg->dpp_info.opclass_num;

		for (i = 0; i < msg->dpp_info.opclass_num; i ++) {
            /* Operating Class */
			*p++ = msg->dpp_info.opclass[i].opclass;

            /* Number of Channels  */
			*p++ = msg->dpp_info.opclass[i].channel_num;

            /* Channel */
			memcpy(p, msg->dpp_info.opclass[i].channel, msg->dpp_info.opclass[i].channel_num);
			p += msg->dpp_info.opclass[i].channel_num;
		}
	}

	/* frame type:
	** if 1, indicate it's a GAS frame
	** if 0, Public action frame
	*/
    /* GAS frame, should set Frame Type as 0xFF */
	if (msg->dpp_frame_indicator == 1) {
		*p_bitmap |= 0x20;
        *p++ = 0xFF;
		switch (msg->payload[0]) {
		case 0x0A:
		case 0x0C:
			(void)os_snprintf(frame_str, sizeof(frame_str), "%s", "DPP Configuration Request");
			break;
		case 0x0B:
		case 0x0D:
			(void)os_snprintf(frame_str, sizeof(frame_str), "%s", "DPP Configuration Response");
			break;
		default:
			(void)os_snprintf(frame_str, sizeof(frame_str), "%s", "unsupported type");
			break;
		}
		notice(DEBUG_CAT_DPP, "send 0x802A(DIRECT_ENCAP_DPP_MESSAGE) with %s to "MACSTR"\n",
			frame_str, MAC2STR(almac));
	} else {
		*p++ = msg->frame_type;
		switch (msg->payload[6]) {
		case 0:/*DPP_PA_AUTHENTICATION_REQ*/
			(void)os_snprintf(frame_str, sizeof(frame_str), "%s", "Authentication Request");
			break;
		case 1:/*DPP_PA_AUTHENTICATION_RESP*/
			(void)os_snprintf(frame_str, sizeof(frame_str), "%s", "Authentication Response");
			break;
		case 2:/*DPP_PA_AUTHENTICATION_CONFIRM*/
			(void)os_snprintf(frame_str, sizeof(frame_str), "%s", "Authentication Confirm");
			break;
		case 5:/*DPP_PA_PEER_DISCOVERY_REQ*/
			(void)os_snprintf(frame_str, sizeof(frame_str), "%s", "Peer Discovery Request");
			break;
		case 6:/*DPP_PA_PEER_DISCOVERY_RESP*/
			(void)os_snprintf(frame_str, sizeof(frame_str), "%s", "Peer Discovery Response");
			break;
		case 7:/*DPP_PA_PKEX_EXCHANGE_REQ*/
			(void)os_snprintf(frame_str, sizeof(frame_str), "%s", "PKEX Exchange Request");
			break;
		case 8:/*DPP_PA_PKEX_EXCHANGE_RESP*/
			(void)os_snprintf(frame_str, sizeof(frame_str), "%s", "PKEX Exchange Response");
			break;
		case 9:/*DPP_PA_PKEX_COMMIT_REVEAL_REQ*/
			(void)os_snprintf(frame_str, sizeof(frame_str), "%s", "PKEX Commit-Reveal Request");
			break;
		case 10:/*DPP_PA_PKEX_COMMIT_REVEAL_RESP*/
			(void)os_snprintf(frame_str, sizeof(frame_str), "%s", "PKEX Commit-Reveal Response");
			break;
		case 11:/*DPP_PA_CONFIGURATION_RESULT*/
			(void)os_snprintf(frame_str, sizeof(frame_str), "%s", "Configuration Result");
			break;
		case 12:/*DPP_PA_CONNECTION_STATUS_RESULT*/
			(void)os_snprintf(frame_str, sizeof(frame_str), "%s", "Connection Status Result");
			break;
		case 13:/*DPP_PA_PRESENCE_ANNOUNCEMENT*/
			(void)os_snprintf(frame_str, sizeof(frame_str), "%s", "DPP Presence Announcement");
			break;
		case 14:/*DPP_PA_RECONFIG_ANNOUNCEMENT*/
			(void)os_snprintf(frame_str, sizeof(frame_str), "%s", "DPP Reconfig Announcement");
			break;
		case 15:/*DPP_PA_RECONFIG_AUTH_REQ*/
			(void)os_snprintf(frame_str, sizeof(frame_str), "%s", "DPP Reconfig Auth Req");
			break;
		case 16:/*DPP_PA_RECONFIG_AUTH_RESP*/
			(void)os_snprintf(frame_str, sizeof(frame_str), "%s", "DPP Reconfig Auth Resp");
			break;
		case 17:/*DPP_PA_RECONFIG_AUTH_COMFIRM*/
			(void)os_snprintf(frame_str, sizeof(frame_str), "%s", "DPP Reconfig Auth Confirm");
			break;
		default:
			(void)os_snprintf(frame_str, sizeof(frame_str), "%s", "unsupported type");
			break;
		}
		notice(DEBUG_CAT_DPP, "send 0x802A(DIRECT_ENCAP_DPP_MESSAGE) with %s to "MACSTR"\n",
			frame_str, MAC2STR(almac));

    }

    /* length of frame */
    *(unsigned short*)p = host_to_be16(msg->payload_len);
    p += 2;

    /* frame */
	memcpy(p, msg->payload, msg->payload_len);
    p += msg->payload_len;

    /* update encap dpp tlv len */
	*((unsigned short*)p_len) = host_to_be16(p - p_len -2);

    /* DPP Reconfig Authentication Request, shall not include a DPP Chirp Value TLV */
	/* zero or One Chirp Hash TLV */
    if (msg->chirp_tlv_present && msg->frame_type != 15) {
        /* tlv type 0xD3 */
        *p++ = 0xD3;

        /* len pointer */
        p_len = p;
        p += 2;

        *p = 0;

        /* Enrollee MAC Address Present field: reconfiguration purposes */
        if (msg->chirp_info.enrollee_mac_address_present)
            *p |= 0x80;

        /* hash type and hash validity bitmapt */
        if (msg->chirp_info.hash_validity == 1)
            *p |= 0x40;

        p++;

        if (msg->chirp_info.enrollee_mac_address_present) {
            os_memcpy(p, msg->chirp_info.enrollee_mac, ETH_ALEN);
            p += ETH_ALEN;
        }

        /* hash len: 1 byte */
        *(p++) = msg->chirp_info.hash_len;

        /* hash */
        os_memcpy(p, msg->chirp_info.hash_payload, msg->chirp_info.hash_len);

        p += msg->chirp_info.hash_len;

        *((unsigned short*)p_len) = host_to_be16(p - p_len - 2);
    }

	request->len = (unsigned short)(p - request->body);

	//hex_dump("proxied encap dpp", request->body, request->len);

	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + sizeof(struct _1905_cmdu_request) + request->len) < 0) {
		warn(DEBUG_CAT_DPP, "_1905_interface_ctrl_request error");
		return -1;
	} else {
		return 0;
	}
}



int _1905_Send_Direct_Encap_DPP_Message (IN struct _1905_context* ctx, char* almac,
	unsigned short frame_len, unsigned char *frame)
{
	struct msg *cmd = (struct msg*)cmdu_buf;
	struct _1905_cmdu_request* request = (struct _1905_cmdu_request*)cmd->buffer;
	unsigned char *p = request->body;
	char frame_str[36] = {0};

	if (ctx == NULL) {
		warn(DEBUG_CAT_DPP, "ctx NULL pointer");
		return -1;
	}
	if (almac == NULL) {
		warn(DEBUG_CAT_DPP, "almac NULL pointer");
		return -1;
	}

	if (frame_len && frame == NULL) {
		warn(DEBUG_CAT_DPP, "dpp_frame NULL pointer");
		return -1;
	}

	cmd->type = LIB_1905_CMDU_REQUEST;
	memcpy(request->dest_al_mac, almac, ETH_ALEN);
	request->type = DIRECT_ENCAP_DPP_MESSAGE;

	/* One DPP Message */
	/* tlv type ???  */
	*p++ = 0xD1;

	/* len pointer */
	*(unsigned short *)p = host_to_be16(frame_len);
	p += 2;

	/* dpp frame */
	memcpy(p, frame, frame_len);
	if (frame[0] == 0x09) {
		/* public action frame */
		switch (frame[6]) {
		case 0:/*DPP_PA_AUTHENTICATION_REQ*/
			(void)os_snprintf(frame_str, sizeof(frame_str), "%s", "Authentication Request");
			break;
		case 1:/*DPP_PA_AUTHENTICATION_RESP*/
			(void)os_snprintf(frame_str, sizeof(frame_str), "%s", "Authentication Response");
			break;
		case 2:/*DPP_PA_AUTHENTICATION_CONFIRM*/
			(void)os_snprintf(frame_str, sizeof(frame_str), "%s", "Authentication Confirm");
			break;
		case 5:/*DPP_PA_PEER_DISCOVERY_REQ*/
			(void)os_snprintf(frame_str, sizeof(frame_str), "%s", "Peer Discovery Request");
			break;
		case 6:/*DPP_PA_PEER_DISCOVERY_RESP*/
			(void)os_snprintf(frame_str, sizeof(frame_str), "%s", "Peer Discovery Response");
			break;
		case 7:/*DPP_PA_PKEX_EXCHANGE_REQ*/
			(void)os_snprintf(frame_str, sizeof(frame_str), "%s", "PKEX Exchange Request");
			break;
		case 8:/*DPP_PA_PKEX_EXCHANGE_RESP*/
			(void)os_snprintf(frame_str, sizeof(frame_str), "%s", "PKEX Exchange Response");
			break;
		case 9:/*DPP_PA_PKEX_COMMIT_REVEAL_REQ*/
			(void)os_snprintf(frame_str, sizeof(frame_str), "%s", "PKEX Commit-Reveal Request");
			break;
		case 10:/*DPP_PA_PKEX_COMMIT_REVEAL_RESP*/
			(void)os_snprintf(frame_str, sizeof(frame_str), "%s", "PKEX Commit-Reveal Response");
			break;
		case 11:/*DPP_PA_CONFIGURATION_RESULT*/
			(void)os_snprintf(frame_str, sizeof(frame_str), "%s", "Configuration Result");
			break;
		case 12:/*DPP_PA_CONNECTION_STATUS_RESULT*/
			(void)os_snprintf(frame_str, sizeof(frame_str), "%s", "Connection Status Result");
			break;
		case 13:/*DPP_PA_PRESENCE_ANNOUNCEMENT*/
			(void)os_snprintf(frame_str, sizeof(frame_str), "%s", "DPP Presence Announcement");
			break;
		case 14:/*DPP_PA_RECONFIG_ANNOUNCEMENT*/
			(void)os_snprintf(frame_str, sizeof(frame_str), "%s", "DPP Reconfig Announcement");
			break;
		case 15:/*DPP_PA_RECONFIG_AUTH_REQ*/
			(void)os_snprintf(frame_str, sizeof(frame_str), "%s", "DPP Reconfig Auth Req");
			break;
		case 16:/*DPP_PA_RECONFIG_AUTH_RESP*/
			(void)os_snprintf(frame_str, sizeof(frame_str), "%s", "DPP Reconfig Auth Resp");
			break;
		case 17:/*DPP_PA_RECONFIG_AUTH_COMFIRM*/
			(void)os_snprintf(frame_str, sizeof(frame_str), "%s", "DPP Reconfig Auth Confirm");
			break;
		default:
			(void)os_snprintf(frame_str, sizeof(frame_str), "%s", "unsupported type");
			break;
	}
		notice(DEBUG_CAT_DPP, "send 0x802A(DIRECT_ENCAP_DPP_MESSAGE) with %s to "MACSTR"\n",
			frame_str, MAC2STR(almac));
	} else {
		/* GAS frame */
		switch (frame[0]) {
		case 0x0A:
		case 0x0C:
			(void)os_snprintf(frame_str, sizeof(frame_str), "%s", "DPP Configuration Request");
			break;
		case 0x0B:
		case 0x0D:
			(void)os_snprintf(frame_str, sizeof(frame_str), "%s", "DPP Configuration Response");
			break;
		default:
			(void)os_snprintf(frame_str, sizeof(frame_str), "%s", "unsupported type");
			break;
		}
		notice(DEBUG_CAT_DPP, "send 0x802A(DIRECT_ENCAP_DPP_MESSAGE) with %s to "MACSTR"\n",
			frame_str, MAC2STR(almac));
	}

	p += frame_len;

	request->len = (unsigned short)(p - request->body);

	//hex_dump("direct encap dpp", request->body, request->len);

	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + sizeof(struct _1905_cmdu_request) + request->len) < 0) {
		warn(DEBUG_CAT_DPP, "_1905_interface_ctrl_request error");
		return -1;
	} else {
		return 0;
	}
}



int _1905_Send_DPP_Bootstrap_URI_Notification_Message (
	IN struct _1905_context* ctx, char* almac,IN unsigned char *identifier,
	IN unsigned char *local_if_mac, IN unsigned char *peer_if_mac,
	IN unsigned char *uri, IN unsigned short uri_len)
{
	struct msg *cmd = (struct msg*)cmdu_buf;
	struct _1905_cmdu_request* request = (struct _1905_cmdu_request*)cmd->buffer;
	unsigned char *p = request->body;
	unsigned char *p_tlvlen = 0;

	if (ctx == NULL) {
		warn(DEBUG_CAT_DPP, "ctx NULL pointer");
		return -1;
	}
	if (almac == NULL) {
		warn(DEBUG_CAT_DPP, "almac NULL pointer");
		return -1;
	}

	cmd->type = LIB_1905_CMDU_REQUEST;
	memcpy(request->dest_al_mac, almac, ETH_ALEN);
	request->type = DPP_BOOTSTRAPING_URI_NOTIFICATION;

	/* One DPP Bootstrapping URI Notification TLV */
	*p++ = 0xCF;

	p_tlvlen = p;
	p += 2;

	/* Radio Unique Identifier of a radio */
	memcpy(p, identifier, ETH_ALEN);
	p += ETH_ALEN;

	/* MAC Address of Local Interface (equal to BSSID) */
	memcpy(p, local_if_mac, ETH_ALEN);
	p += ETH_ALEN;

	/* MAC Address of bSTA from which the URI was received */
	memcpy(p, peer_if_mac, ETH_ALEN);
	p += ETH_ALEN;

	/* DPP Bootstrapping URI received during PBC onboarding */
	memcpy(p, uri, uri_len);
	p += uri_len;

	*((unsigned short*)p_tlvlen) = host_to_be16(p - p_tlvlen - 2);

	request->len = (unsigned short)(p - request->body);

	//hex_dump("dpp bootstrap", request->body, request->len);

	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + sizeof(struct _1905_cmdu_request) + request->len) < 0) {
		warn(DEBUG_CAT_DPP, "_1905_interface_ctrl_request error");
		return -1;
	} else {
		return 0;
	}
}

int _1905_Send_DPP_Bootstrap_URI_Query_Message (IN struct _1905_context* ctx, char* almac)
{
	struct msg *cmd = (struct msg*)cmdu_buf;
	struct _1905_cmdu_request* request = (struct _1905_cmdu_request*)cmd->buffer;

	if (ctx == NULL) {
		warn(DEBUG_CAT_DPP, "ctx NULL pointer");
		return -1;
	}
	if (almac == NULL) {
		warn(DEBUG_CAT_DPP, "almac NULL pointer");
		return -1;
	}

	cmd->type = LIB_1905_CMDU_REQUEST;
	memcpy(request->dest_al_mac, almac, ETH_ALEN);
	request->type = DPP_BOOTSTRAPING_URI_QUERY;

	request->len = 0;

	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + sizeof(struct _1905_cmdu_request) + request->len) < 0) {
		warn(DEBUG_CAT_DPP, "_1905_interface_ctrl_request error");
		return -1;
	} else {
		return 0;
	}
}



int _1905_Send_DPP_CCE_Indication_Message (IN struct _1905_context* ctx, char* almac,
	IN unsigned char indication)
{
	struct msg *cmd = (struct msg*)cmdu_buf;
	struct _1905_cmdu_request* request = (struct _1905_cmdu_request*)cmd->buffer;
	unsigned char *p = request->body;

	if (ctx == NULL) {
		warn(DEBUG_CAT_DPP, "ctx NULL pointer");
		return -1;
	}
	if (almac == NULL) {
		warn(DEBUG_CAT_DPP, "almac NULL pointer");
		return -1;
	}

	cmd->type = LIB_1905_CMDU_REQUEST;
	memcpy(request->dest_al_mac, almac, ETH_ALEN);
	request->type = DPP_CCE_INDICATION_MESSAGE;

	/* One CCE Indication tlv */
	/* tlv type 0xD2 */
	*p++ = 0xD2;

	*((unsigned short*)p) = host_to_be16(1);
	p += 2;

	*p++ = indication;
	request->len = (unsigned short)(p - request->body);

	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + sizeof(struct _1905_cmdu_request) + request->len) < 0) {
		warn(DEBUG_CAT_DPP, "_1905_interface_ctrl_request error");
		return -1;
	} else {
		return 0;
	}
}

int _1905_Send_Chirp_Notification_Message (IN struct _1905_context* ctx, char* almac,
	IN struct chirp_info *chirp)
{
	struct msg *cmd = (struct msg*)cmdu_buf;
	struct _1905_cmdu_request* request = (struct _1905_cmdu_request*)cmd->buffer;
	unsigned char *p = request->body;
	unsigned char i = 0;
	unsigned char *p_len = NULL;
	struct chirp_tlv_info *p_chirp_item = NULL;
    unsigned char all_agent_mac[ETH_ALEN] = { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff };

	if (ctx == NULL) {
		warn(DEBUG_CAT_DPP, "ctx NULL pointer");
		return -1;
	}
	if (almac == NULL)
		os_memcpy(request->dest_al_mac, all_agent_mac, ETH_ALEN);
	else
		os_memcpy(request->dest_al_mac, almac, ETH_ALEN);

	if (chirp == NULL) {
		warn(DEBUG_CAT_DPP, "chirp NULL pointer");
		return -1;
	}

	cmd->type = LIB_1905_CMDU_REQUEST;
	request->type = CHIRP_NOTIFICATION_MESSAGE;

	/* One or more DPP Chirp Value TLV */
	/* tlv type 0xD3 */
	p_chirp_item = chirp->item;
	for (i = 0; i < chirp->chirp_cnt; i ++) {

		(*p++) = 0xD3;
		p_len = p;
		p += 2;

		/*
		1. one byte
		   bit 7, Enrollee MAC Address Present field,
		    This field is only set to 1 for reconfiguration purposes
		   Bit 6: Hash Validity
			1: establish DPP authentication state pertaining to the hash value in this TLV
			0: purge any DPP authentication state pertaining to the hash value in this TLV

		2. Destination STA MAC Address
		3. hash length 1 octet
		4. hash value k octets
		*/

        *p = 0;
		if (p_chirp_item->enrollee_mac_address_present) {
			*p |= (1 << 7);
		}

		if (p_chirp_item->hash_validity) {
			*p |= (1 << 6);
		}
        p++;

        if (p_chirp_item->enrollee_mac_address_present) {
            os_memcpy(p, chirp->item[i].enrollee_mac, ETH_ALEN);
            p += ETH_ALEN;
        }

		*p++ = p_chirp_item->hash_len;

		/*
		4. hash value k octets
		*/
		memcpy(p, p_chirp_item->hash_payload, p_chirp_item->hash_len);
		p += chirp->item[i].hash_len;

		*((unsigned short *)p_len) = host_to_be16(p - p_len - 2);

		p_chirp_item ++;
	}

	request->len = (unsigned short)(p - request->body);

	//hex_dump("chirp notify", request->body, request->len);

	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + sizeof(struct _1905_cmdu_request) + request->len) < 0) {
		warn(DEBUG_CAT_DPP, "_1905_interface_ctrl_request error");
		return -1;
	} else {
		return 0;
	}
}

int _1905_Set_GTK_Rekey_Interval (IN struct _1905_context* ctx, IN unsigned int interval)
{
	struct msg *cmd = (struct msg* )cmdu_buf;
	unsigned char *p = cmd->buffer;

	if (ctx == NULL) {
		warn(DEBUG_CAT_DPP, "ctx NULL pointer");
		return -1;
	}

	cmd->type = LIB_SET_GTK_REKEY_INTERVAL;
	cmd->length = sizeof(unsigned int);
	*((unsigned int *)p) = interval;
	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length) < 0) {
		warn(DEBUG_CAT_DPP, "_1905_interface_ctrl_request error");
		return -1;
	} else {
		return 0;
	}
}

int _1905_Set_R3_Onboarding_Type (IN struct _1905_context* ctx, unsigned char type)
{
	struct msg *cmd = (struct msg* )cmdu_buf;
	unsigned char *p = cmd->buffer;

	if (ctx == NULL) {
		warn(DEBUG_CAT_DPP, "ctx NULL pointer");
		return -1;
	}

	cmd->type = LIB_SET_R3_ONBOARDING_TYPE;
	cmd->length = sizeof(unsigned char);
	*p = type;
	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length) < 0) {
		warn(DEBUG_CAT_DPP, "_1905_interface_ctrl_request error");
		return -1;
	} else {
		return 0;
	}
}

#endif  // MAP_R3
#ifdef MAP_R3_DE
int _1905_Set_Dev_Inven_Tlv (IN struct _1905_context* ctx,
	IN struct dev_inven *de)
{
	struct msg *cmd = (struct msg* )cmdu_buf;

	if (ctx == NULL) {
		warn(DEBUG_CAT_DPP, "ctx NULL pointer");
		return -1;
	}
	if (de == NULL) {
		warn(DEBUG_CAT_DPP, "de NULL pointer");
		return -1;
	}
	cmd->type = LIB_DEV_INVEN_TLV;
	cmd->length = sizeof(struct dev_inven);
	memcpy(cmd->buffer, (unsigned char*)de, cmd->length);
	if (_1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length) < 0) {
		warn(DEBUG_CAT_DPP, "_1905_interface_ctrl_request error");
		return -1;
	} else {
		return 0;
	}
}
#endif //MAP_R3_DE
#ifdef MAP_R3_WF6
int _1905_Set_Ap_Wf6_Cap(IN struct _1905_context *ctx,
	IN struct ap_wf6_cap_roles *cap)
{
	struct msg *cmd = (struct msg *)cmdu_buf;

	if (ctx == NULL) {
		warn(DEBUG_CAT_MISC, "ctx NULL pointer");
		return -1;
	}
	if (cap == NULL) {
		warn(DEBUG_CAT_MISC, "cap NULL pointer");
		return -1;
	}
	cmd->type = LIB_AP_WF6_CAPABILITY;
	cmd->length = sizeof(struct ap_wf6_cap_roles);
	memcpy(cmd->buffer, (unsigned char *)cap, cmd->length);
	if (_1905_interface_ctrl_request(ctx, (char *)cmd, sizeof(struct msg) + cmd->length) < 0) {
		warn(DEBUG_CAT_MISC, "_1905_interface_ctrl_request error");
		return -1;
	} else {
		return 0;
	}
}
#endif

#ifdef MAP_R5
int _1905_send_qos_mgmt_tlv(IN struct _1905_context *ctx, u8 *tlv, unsigned short len)
{
	struct msg *cmd = (struct msg *)cmdu_buf;

	notice(DEBUG_CAT_QOS, "-->send qos mgmt tlv.\n");

	if (ctx == NULL) {
		err(DEBUG_CAT_QOS, "ctx NULL pointer");
		return -1;
	}
	if (tlv == NULL) {
		err(DEBUG_CAT_QOS, "tlv NULL pointer");
		return -1;
	}
	cmd->type = LIB_QOS_MGMT_TLV_MSG;
	cmd->length = len;
	memcpy(cmd->buffer, (unsigned char *)tlv, cmd->length);
	if (_1905_interface_ctrl_request(ctx, (char *)cmd, sizeof(struct msg) + cmd->length) < 0) {
		err(DEBUG_CAT_QOS, "_1905_interface_ctrl_request error");
		return -1;
	} else {
		return 0;
	}
}

int _1905_set_qos_config(IN struct _1905_context *ctx, char *cmdstr, unsigned short cmdlen)
{
	struct msg *cmd = (struct msg *)cmdu_buf;

	if (ctx == NULL) {
		err(DEBUG_CAT_QOS, "ctx NULL pointer");
		return -1;
	}
	if (cmdstr == NULL) {
		err(DEBUG_CAT_QOS, "cmdstr NULL pointer");
		return -1;
	}
	cmd->type = LIB_QOS_SET_CONFIG;
	cmd->length = cmdlen;
	memcpy(cmd->buffer, (unsigned char *)cmdstr, cmd->length);
	if (_1905_interface_ctrl_request(ctx, (char *)cmd, sizeof(struct msg) + cmd->length) < 0) {
		err(DEBUG_CAT_QOS, "_1905_interface_ctrl_request error");
		return -1;
	}
	return 0;
}

int _1905_get_qos_config(IN struct _1905_context *ctx, char *cmdstr, char *replybuf, int *buflen)
{
	struct msg *cmd = (struct msg *)cmdu_buf;
	int ret = 0;
	size_t reply_len = sizeof(cmdu_buf);
	struct timeval tv;

	memset(cmdu_buf, 0, sizeof(cmdu_buf));
	cmd->type = LIB_QOS_GET_CONFIG;
	cmd->length = strlen(cmdstr) + 1;
	memcpy(cmd->buffer, cmdstr, cmd->length);

	ret = _1905_interface_ctrl_send(ctx, (char *)cmd, sizeof(struct msg) + cmd->length);
	if (ret < 0) {
		err(DEBUG_CAT_QOS, "_1905_interface_ctrl_request error");
		goto err1;
	}

	reply_len = sizeof(cmdu_buf);

	tv.tv_sec = 2;
	tv.tv_usec = 0;
	if (_1905_interface_ctrl_pending(ctx, &tv)) {
		ret = _1905_Receive(ctx, (char *)cmdu_buf, &reply_len);
		if (ret < 0) {
			err(DEBUG_CAT_QOS, "fail to recv rsp or rev wrong rsp\n");
			goto err1;
		}

		debug(DEBUG_CAT_QOS, "reply_len:%zu\n", reply_len);

		if (reply_len == 0) {
			warn(DEBUG_CAT_QOS, "nothing replied.\n");
			goto err1;
		} else if (reply_len > *buflen) {
			warn(DEBUG_CAT_QOS, "reply_len(%zu) exceed reply bufflen(%d).\n", reply_len, *buflen);
			goto err1;
		} else {
			memcpy(replybuf, cmdu_buf, reply_len);
			*buflen = reply_len;
		}
	} else {
		err(DEBUG_CAT_QOS, "waiting rsp timeout\n");
		ret = -1;
	}

err1:
	if (ret < 0)
		err(DEBUG_CAT_QOS, "recv error from 1905daemon");

	return ret;
}

int _1905_save_qos_config(IN struct _1905_context *ctx)
{
	struct msg *cmd = (struct msg *)cmdu_buf;
	int ret = 0;

	memset(cmdu_buf, 0, sizeof(cmdu_buf));
	cmd->type = LIB_QOS_SAVE_CONFIG;
	cmd->length = 0;

	ret = _1905_interface_ctrl_request(ctx, (char *)cmd, sizeof(struct msg));
	if (ret < 0)
		err(DEBUG_CAT_QOS, "_1905_interface_ctrl_request error");

	return ret;
}

int _1905_get_qos_errorcode(IN struct _1905_context *ctx, char *replybuf, int *buflen)
{
	struct msg *cmd = (struct msg *)cmdu_buf;
	int ret = 0;
	size_t reply_len = sizeof(cmdu_buf);
	struct timeval tv;

	memset(cmdu_buf, 0, sizeof(cmdu_buf));
	cmd->type = LIB_QOS_GET_ERROR_CODE;
	cmd->length = 0;

	ret = _1905_interface_ctrl_send(ctx, (char *)cmd, sizeof(struct msg) + cmd->length);
	if (ret < 0) {
		err(DEBUG_CAT_QOS, "_1905_interface_ctrl_request error");
		goto err1;
	}

	reply_len = sizeof(cmdu_buf);

	tv.tv_sec = 2;
	tv.tv_usec = 0;
	if (_1905_interface_ctrl_pending(ctx, &tv)) {
		ret = _1905_Receive(ctx, (char *)cmdu_buf, &reply_len);
		if (ret < 0) {
			err(DEBUG_CAT_QOS, "fail to recv rsp or rev wrong rsp\n");
			goto err1;
		}

		if (reply_len == 0) {
			warn(DEBUG_CAT_QOS, "nothing replied.\n");
			goto err1;
		} else if (reply_len > *buflen) {
			warn(DEBUG_CAT_QOS, "reply_len(%zu) exceed reply bufflen(%d).\n", reply_len, *buflen);
			goto err1;
		} else {
			memcpy(replybuf, cmdu_buf, reply_len);
			*buflen = reply_len;
		}
	} else {
		err(DEBUG_CAT_QOS, "waiting rsp timeout\n");
		ret = -1;
	}

err1:
	if (ret < 0)
		err(DEBUG_CAT_QOS, "recv error from 1905daemon");

	return ret;
}

#endif /* MAP_R5 */

int _1905_Set_Wireless_Interface_Info (IN struct _1905_context* ctx,
	IN struct interface_info_list_hdr *info)
{
	struct msg *cmd = (struct msg* )cmdu_buf;
	int ret = 0;

	if (info == NULL) {
		err(DEBUG_CAT_EVENT, "info NULL pointer");
		return -1;
	}
	cmd->type = LIB_WIRELESS_INTERFACE_INFO;
	cmd->length = sizeof(struct interface_info_list_hdr) +
		info->interface_count * sizeof(struct interface_info);
	memcpy(cmd->buffer, (unsigned char *)info, cmd->length);
	ret = _1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length);
	if (ret < 0)
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error");

	return ret;
}

int _1905_clear_switch_table (IN struct _1905_context* ctx)
{
	struct msg *cmd = (struct msg* )cmdu_buf;
	int ret = 0;

	cmd->type = LIB_CLEAR_SWITCH_TABLE;
	cmd->length = 0;
	ret = _1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length);
	if (ret < 0)
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");

	return ret;
}

int _1905_Sync_Recv_Buf_Size (IN struct _1905_context* ctx, unsigned short length, unsigned short own_length)
{
	unsigned char recv_buf[50] = {0};
	struct msg *cmd = (struct msg* )recv_buf;

	cmd->type = LIB_SYNC_RECV_BUF_SIZE;
	cmd->length = sizeof(length) + sizeof(own_length);
	os_memcpy(cmd->buffer, &length, sizeof(length));
	os_memcpy(cmd->buffer+ sizeof(length), &own_length, sizeof(own_length));

	if (_1905_interface_ctrl_send(ctx, (char*)cmd, sizeof(struct msg) + cmd->length) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_send error\n");
		return -1;
	} else {
		notice(DEBUG_CAT_EVENT, "LIB_SYNC_RECV_BUF_SIZE send to 1905 success;"
			" change_buf_len=%d; own_recv_buf_len=%d\n", length, own_length);
		return 0;
	}
}

int _1905_Sync_Recv_Buf_Size_Rsp (IN struct _1905_context* ctx, unsigned short length, unsigned char rsp)
{
	unsigned char tmp_buf[50] = {0};
	struct msg *cmd = (struct msg *) tmp_buf;
	int ret = 0;

	if (length == 0) {
		err(DEBUG_CAT_EVENT, "no need to nofity due to length is 0\n");
		return -1;
	}
	cmd->type = LIB_SYNC_RECV_BUF_SIZE_RSP;
	cmd->length = sizeof(length) + sizeof(rsp);
	os_memcpy(cmd->buffer, &length, sizeof(length));
	os_memcpy(cmd->buffer + sizeof(length), &rsp, sizeof(rsp));

	ret = _1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length);
	if (ret < 0)
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");

	return ret;
}
#ifdef MAP_R3_SP
int _1905_sp_add_static_rule(IN struct _1905_context *ctx, char *rule_str, int str_len)
{
	struct msg *cmd = (struct msg* )cmdu_buf;
	struct sp_cmd *sp = (struct sp_cmd*)cmd->buffer;
	int ret = 0;
	size_t reply_len = sizeof(cmdu_buf);
	struct timeval tv;


	if (str_len > (sizeof(cmdu_buf) - sizeof(struct sp_cmd) - sizeof(struct msg))) {
		warn(DEBUG_CAT_SP, "rule string too long to handle\n");
		ret = -1;
		goto err1;
	}

	memset(cmdu_buf, 0, sizeof(cmdu_buf));
	cmd->type = SERVICE_PRIORITIZATION_COMMAND;
	cmd->length = sizeof(struct sp_cmd) + str_len;

	sp->cmd_id = SP_CMD_ADD_RULE;
	sp->len = str_len;
	memcpy(sp->value, rule_str, str_len);

	ret = _1905_interface_ctrl_send(ctx, (char*)cmd, sizeof(struct msg) + cmd->length);
	if (ret < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_send fail");
		goto err1;
	}

	tv.tv_sec = 2;
	tv.tv_usec = 0;
	if (_1905_interface_ctrl_pending(ctx, &tv)) {
		ret = _1905_Receive(ctx, (char *)cmdu_buf, &reply_len);
		if (ret < 0) {
			err(DEBUG_CAT_EVENT, "_1905_Receive fail\n");
			goto err1;
		}

		if (reply_len > 0) {
			if (cmdu_buf[0] == 0x01)
				ret = 0;	/*success*/
			else
				ret = -1;	/*fail*/
		} else {
			err(DEBUG_CAT_SP, "reply_len(%zu) <= 0\n", reply_len);
			goto err1;
		}
	}
	else {
		err(DEBUG_CAT_EVENT, "waiting rsp timeout\n");
		ret = -1;
	}

err1:
	return ret;
}

int _1905_sp_set_static_rule (IN struct _1905_context* ctx,
	char *rule_str, int str_len)
{
	struct msg *cmd = (struct msg* )cmdu_buf;
	struct sp_cmd *sp = (struct sp_cmd*)cmd->buffer;
	int ret = 0;

	if (str_len > (sizeof(cmdu_buf) - sizeof(struct sp_cmd) - 1 - sizeof(struct msg))) {
		warn(DEBUG_CAT_SP, "rule string too long to handle\n");
		return -1;
	}

	memset(cmdu_buf, 0, sizeof(cmdu_buf));
	cmd->type = SERVICE_PRIORITIZATION_COMMAND;
	cmd->length = sizeof(struct sp_cmd) + str_len + 1;

	sp->cmd_id = SP_CMD_SET_RULE;
	sp->len = str_len;
	memcpy(sp->value , rule_str, str_len);

	ret = _1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length);
	if (ret < 0)
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error");

	return ret;
}

int _1905_sp_rm_static_rule (IN struct _1905_context* ctx,
	unsigned char rule_index)
{
	struct msg *cmd = (struct msg* )cmdu_buf;
	struct sp_cmd *sp = (struct sp_cmd*)cmd->buffer;
	int ret = 0;

	memset(cmdu_buf, 0, sizeof(cmdu_buf));
	cmd->type = SERVICE_PRIORITIZATION_COMMAND;
	cmd->length = sizeof(struct sp_cmd) + 1;

	sp->cmd_id = SP_CMD_RM_RULE;
	sp->len = 1;
	sp->value[0] = rule_index;

	ret = _1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length);
	if (ret < 0)
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error");

	return ret;
}

int _1905_sp_reorder_static_rule (IN struct _1905_context* ctx,
	unsigned char org_idx, unsigned char new_idx)
{
	struct msg *cmd = (struct msg* )cmdu_buf;
	struct sp_cmd *sp = (struct sp_cmd*)cmd->buffer;
	int ret = 0;

	memset(cmdu_buf, 0, sizeof(cmdu_buf));
	cmd->type = SERVICE_PRIORITIZATION_COMMAND;
	cmd->length = sizeof(struct sp_cmd) + 2;

	sp->cmd_id = SP_CMD_REORDER_RULE;
	sp->len = 2;
	sp->value[0] = org_idx;
	sp->value[1] = new_idx;

	ret = _1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length);
	if (ret < 0)
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error");

	return ret;
}

int _1905_sp_move_static_rule (IN struct _1905_context* ctx,
	unsigned char org_idx, unsigned char action)
{
	struct msg *cmd = (struct msg* )cmdu_buf;
	struct sp_cmd *sp = (struct sp_cmd*)cmd->buffer;
	int ret = 0;

	memset(cmdu_buf, 0, sizeof(cmdu_buf));
	cmd->type = SERVICE_PRIORITIZATION_COMMAND;
	cmd->length = sizeof(struct sp_cmd) + 2;

	sp->cmd_id = SP_CMD_MOVE_RULE;
	sp->len = 2;
	sp->value[0] = org_idx;
	sp->value[1] = action;

	ret = _1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length);
	if (ret < 0)
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error");

	return ret;
}

int _1905_sp_get_static_rule(IN struct _1905_context *ctx, unsigned char idx, char *rule_string, int *str_len)
{
	struct msg *cmd = (struct msg* )cmdu_buf;
	struct sp_cmd *sp = (struct sp_cmd*)cmd->buffer;
	int ret = 0;
	size_t reply_len = sizeof(cmdu_buf);
	struct timeval tv;

	memset(cmdu_buf, 0, sizeof(cmdu_buf));
	cmd->type = SERVICE_PRIORITIZATION_COMMAND;
	cmd->length = sizeof(struct sp_cmd) + 1;

	sp->cmd_id = SP_CMD_GET_RULE;
	sp->len = 1;
	sp->value[0] = idx;

	ret = _1905_interface_ctrl_send(ctx, (char*)cmd, sizeof(struct msg) + cmd->length);
	if (ret < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_send error");
		goto err1;
	}

	reply_len = sizeof(cmdu_buf);

	tv.tv_sec = 2;
	tv.tv_usec = 0;
	if (_1905_interface_ctrl_pending(ctx, &tv)) {
		ret = _1905_Receive(ctx, (char *)cmdu_buf, &reply_len);
		if (ret < 0) {
			err(DEBUG_CAT_EVENT, "_1905_Receive fail\n");
			goto err1;
		}
		if (reply_len > 0) {
			memcpy(rule_string, cmdu_buf, reply_len);
			*str_len = reply_len;
		} else {
			err(DEBUG_CAT_SP, "reply_len(%d)<=0\n", (int)reply_len);
			goto err1;
		}
	}
	else {
		err(DEBUG_CAT_EVENT, "waiting rsp timeout\n");
		ret = -1;
	}

err1:
	return ret;
}

int _1905_sp_enable_dynamic_rule (IN struct _1905_context* ctx,
	unsigned char enable, unsigned char prior)
{
	struct msg *cmd = (struct msg* )cmdu_buf;
	struct sp_cmd *sp = (struct sp_cmd*)cmd->buffer;
	int ret = 0;

	memset(cmdu_buf, 0, sizeof(cmdu_buf));
	cmd->type = SERVICE_PRIORITIZATION_COMMAND;
	cmd->length = sizeof(struct sp_cmd) + 2;

	sp->cmd_id = SP_CMD_SET_DYNAMIC;
	sp->len = 2;
	sp->value[0] = enable;
	sp->value[1] = prior;

	ret = _1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length);
	if (ret < 0)
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error");

	return ret;
}

int _1905_sp_set_dscp_tbl (IN struct _1905_context* ctx,
	char *dscp_tbl)
{
	struct msg *cmd = (struct msg* )cmdu_buf;
	struct sp_cmd *sp = (struct sp_cmd*)cmd->buffer;
	int ret = 0, len = 0;

	len = strlen(dscp_tbl);
	if (len != 144) {
		err(DEBUG_CAT_SP, "error!! dscp_tble string len(%d) != 144", len);
		return -1;
	}

	memset(cmdu_buf, 0, sizeof(cmdu_buf));
	cmd->type = SERVICE_PRIORITIZATION_COMMAND;
	cmd->length = sizeof(struct sp_cmd) + len;

	sp->cmd_id = SP_CMD_SET_DSCP_TBL;
	sp->len = len;
	memcpy(sp->value, dscp_tbl, len);

	ret = _1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length);
	if (ret < 0)
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error");

	return ret;
}

int _1905_sp_config_done (IN struct _1905_context* ctx)
{
	struct msg *cmd = (struct msg* )cmdu_buf;
	struct sp_cmd *sp = (struct sp_cmd*)cmd->buffer;
	int ret = 0;

	memset(cmdu_buf, 0, sizeof(cmdu_buf));
	cmd->type = SERVICE_PRIORITIZATION_COMMAND;
	cmd->length = sizeof(struct sp_cmd);

	sp->cmd_id = SP_CMD_CONFIG_DONE;
	sp->len = 0;

	ret = _1905_interface_ctrl_request(ctx, (char*)cmd, sizeof(struct msg) + cmd->length);
	if (ret < 0)
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error");

	return ret;
}

#endif


int _1905_Set_Bss_Prio(IN struct _1905_context *ctx,
	IN unsigned char *bss_prio_str)
{
	struct msg *cmd = (struct msg *)cmdu_buf;

	if (bss_prio_str == NULL) {
		err(DEBUG_CAT_EVENT, "bss_prio_str NULL pointer\n");
		return -1;
	}
	cmd->type = LIB_SYNC_BSS_PRIO;
	cmd->length = os_strlen((char *)bss_prio_str);
	memcpy(cmd->buffer, bss_prio_str, cmd->length);
	if (_1905_interface_ctrl_request(ctx, (char *)cmd, sizeof(struct msg) + cmd->length) < 0) {
		err(DEBUG_CAT_EVENT, "_1905_interface_ctrl_request error\n");
		return -1;
	} else {
		return 0;
	}
}

int _1905_Set_Ap_Mlo_Cap(IN struct _1905_context *ctx, IN unsigned char *mlo_cap)
{
	struct msg *cmd = (struct msg *)cmdu_buf;
#if defined(MAP_R6) || defined(EM_PLUS_SUPPORT)
	int i = 0;
	struct wifi7_ap_mlo_cap_lib *ap_mlo = (struct wifi7_ap_mlo_cap_lib *)mlo_cap;
#endif

	if (ctx == NULL) {
		warn(DEBUG_CAT_MLO, "ctx NULL pointer");
		return -1;
	}
	if (mlo_cap == NULL) {
		warn(DEBUG_CAT_MLO, "mlo_cap NULL pointer");
		return -1;
	}
	cmd->type = LIB_AP_MLO_CAPABILITY;
#if defined(MAP_R6) || defined(EM_PLUS_SUPPORT)
	cmd->length = sizeof(struct wifi7_ap_mlo_cap_lib);

	for (i = 0; i < ap_mlo->mlo_cap.total_ap_sta_records; i++)
		cmd->length += sizeof(struct mlo_record);
#else
	cmd->length = sizeof(struct ap_mlo_cap_lib);
#endif
	memcpy(cmd->buffer, mlo_cap, cmd->length);
	if (_1905_interface_ctrl_request(ctx, (char *)cmd, sizeof(struct msg) + cmd->length) < 0) {
		warn(DEBUG_CAT_MLO, "_1905_interface_ctrl_request error");
		return -1;
	} else {
		return 0;
	}
}



int _1905_Set_Eht_Operations(IN struct _1905_context *ctx, unsigned char *data, unsigned short len)
{
	struct msg *cmd = (struct msg *)cmdu_buf;

	if (ctx == NULL) {
		warn(DEBUG_CAT_MLO, "ctx NULL pointer");
		return -1;
	}
	if (data == NULL) {
		warn(DEBUG_CAT_MLO, "eht operation NULL pointer");
		return -1;
	}
	cmd->type = LIB_EHT_OPERATION;
	cmd->length = len;
	memcpy(cmd->buffer, data, cmd->length);
	if (_1905_interface_ctrl_request(ctx, (char *)cmd, sizeof(struct msg) + cmd->length) < 0) {
		warn(DEBUG_CAT_MLO, "_1905_interface_ctrl_request error");
		return -1;
	}

	return 0;
}

#ifdef MAP_R6
int _1905_Set_Ap_Akm_Cap(IN struct _1905_context *ctx, unsigned char *cap, unsigned short len)
{
	struct msg *cmd = (struct msg *)cmdu_buf;

	if (ctx == NULL) {
		warn(DEBUG_CAT_MLO, "ctx NULL pointer");
		return -1;
	}
	if (cap == NULL) {
		warn(DEBUG_CAT_MLO, "akm suite capability NULL pointer");
		return -1;
	}
	cmd->type = LIB_AKM_SUITE_CAPABILITY;
	cmd->length = len;
	memcpy(cmd->buffer, cap, cmd->length);
	if (_1905_interface_ctrl_request(ctx, (char *)cmd, sizeof(struct msg) + cmd->length) < 0) {
		warn(DEBUG_CAT_MLO, "_1905_interface_ctrl_request error");
		return -1;
	}

	return 0;
}


int _1905_Set_Sta_Mld_Config_Report(IN struct _1905_context *ctx, IN struct mlo_sta_config *info)
{
	struct msg *cmd = (struct msg *)cmdu_buf;

	if (ctx == NULL) {
		warn(DEBUG_CAT_MLO, "ctx NULL pointer");
		return -1;
	}
	if (info == NULL) {
		warn(DEBUG_CAT_MLO, "mlo sta config report NULL pointer");
		return -1;
	}
	cmd->type = LIB_STA_MLD_CONFIG_REPORT;
	cmd->length = sizeof(struct mlo_sta_config);
	memcpy(cmd->buffer, info, cmd->length);
	if (_1905_interface_ctrl_request(ctx, (char *)cmd, sizeof(struct msg) + cmd->length) < 0) {
		warn(DEBUG_CAT_MLO, "_1905_interface_ctrl_request error");
		return -1;
	}

	return 0;
}


int _1905_send_afc_report(IN struct _1905_context *ctx, char *almac,
	unsigned short spectrum_inquiry_len, unsigned char *spectrum_inquiry_req,
	unsigned short inquiry_resp_len, unsigned char *spectrum_inquiry_resp,
	unsigned short ch_prefer_cnt, struct ch_prefer_lib *ch_prefers)
{
	struct msg *cmd = (struct msg *)cmdu_buf;
	unsigned char *p = NULL;
	unsigned char *p_old = NULL;
	int i = 0, j = 0, len = 0;

	if (ctx == NULL) {
		warn(DEBUG_CAT_MISC, "ctx NULL pointer");
		return -1;
	}

	if (spectrum_inquiry_len != 0 && spectrum_inquiry_req == NULL) {
		warn(DEBUG_CAT_MISC, "spectrum_inquiry_req NULL pointer");
		return -1;
	}

	if (inquiry_resp_len != 0 && spectrum_inquiry_resp == NULL) {
		warn(DEBUG_CAT_MISC, "spectrum_inquiry_resp NULL pointer");
		return -1;
	}

	if (ch_prefer_cnt != 0 && ch_prefers == NULL) {
		warn(DEBUG_CAT_MISC, "ch_prefers NULL pointer");
		return -1;
	}

	cmd->type = LIB_AFC_SPECTRUM_RESPONSE;
	p = cmd->buffer;

	/* Channel Preference TLV*/
	for (i = 0; i < ch_prefer_cnt; i++) {
		*p++ = 0x8B;

		p_old = p;
		p += 2;
		memcpy(p, ch_prefers->identifier, ETH_ALEN);
		p += ETH_ALEN;

		*p++ = ch_prefers->op_class_num;
		for (j = 0; j < ch_prefers->op_class_num; j++) {
			*p++ = ch_prefers->opinfo[j].op_class;
			*p++ = ch_prefers->opinfo[j].ch_num;
			memcpy(p, ch_prefers->opinfo[j].ch_list, ch_prefers->opinfo[j].ch_num);
			p += ch_prefers->opinfo[j].ch_num;
			*p++ = (((ch_prefers->opinfo[j].perference & 0x0F) << 4) | (ch_prefers->opinfo[j].reason & 0x0F));
		}
		len = (unsigned short)(p - p_old) - 2;
		*((unsigned short *)p_old) = host_to_be16(len);
		ch_prefers++;
	}

	/* Available Spectrum Inquiry Request TLV*/
	*p++ = 0xE8;
	*((unsigned short *)p) = host_to_be16(spectrum_inquiry_len);
	p += 2;
	memcpy(p, spectrum_inquiry_req, spectrum_inquiry_len);
	p += spectrum_inquiry_len;

	/* Avaialble Spectrum Inquiry Response TLV*/
	*p++ = 0xE9;
	*((unsigned short *)p) = host_to_be16(inquiry_resp_len);
	p += 2;
	memcpy(p, spectrum_inquiry_resp, inquiry_resp_len);
	p += inquiry_resp_len;

	cmd->length = (unsigned short)(p - cmd->buffer);

	if (_1905_interface_ctrl_request(ctx, (char *)cmd, sizeof(struct msg) + cmd->length) < 0) {
		warn(DEBUG_CAT_MISC, "_1905_interface_ctrl_request error");
		return -1;
	}

	return 0;
}
#endif

#ifdef EM_PLUS_SUPPORT
int _1905_Set_Radio_Temperature_Rsp_Info(IN struct _1905_context *ctx, struct radio_temperature *radio_temp, u8 radio_cnt)
{
	struct msg *cmd = (struct msg *)cmdu_buf;
	unsigned char *p = cmd->buffer;

	cmd->type = LIB_RADIO_TEMPERATURE;
	cmd->length = sizeof(struct radio_temperature) * radio_cnt + sizeof(char);
	*p = radio_cnt;
	p = p + sizeof(char);
	os_memcpy(p, (unsigned char *)radio_temp, sizeof(struct radio_temperature) * radio_cnt);
	if (_1905_interface_ctrl_request(ctx, (char *)cmd, sizeof(struct msg) + cmd->length) < 0) {
		warn(DEBUG_CAT_MISC, "_1905_interface_ctrl_request error");
		return -1;
	}
	return 0;
}
#endif

int _1905_set_topology_t2lm_conf(IN struct _1905_context *ctx, struct sp_t2lm_request_lib *config)
{
	struct msg *cmd = (struct msg *)cmdu_buf;
	unsigned char *p = cmd->buffer;
	unsigned short num_mapping = config->num_mapping;

	cmd->type = LIB_T2LM_CONFIGURATION;
	cmd->length = sizeof(struct sp_t2lm_request_lib) + (num_mapping * sizeof(struct ap_t2lm_mapping_lib));

	os_memcpy(p, (unsigned char *)config, cmd->length);
	if (_1905_interface_ctrl_request(ctx, (char *)cmd, sizeof(struct msg) + cmd->length) < 0) {
		warn(DEBUG_CAT_MLO, "_1905_interface_ctrl_request error");
		return -1;
	}
	return 0;
}

int _1905_send_t2lm_configuration(IN struct _1905_context *ctx, char *almac,
	unsigned char *payload, unsigned short len)
{
	struct msg *cmd = (struct msg *)cmdu_buf;
	struct _1905_cmdu_request *request = (struct _1905_cmdu_request *)cmd->buffer;
	unsigned char *p = request->body, *old_p;
	struct sp_t2lm_request_lib *bla_bh_t2lm_req = (struct sp_t2lm_request_lib *) payload;
	int i, j;

	if (ctx == NULL) {
		warn(DEBUG_CAT_MLO, "ctx NULL pointer");
		return -1;
	}
	if (almac == NULL) {
		warn(DEBUG_CAT_MLO, "almac NULL pointer");
		return -1;
	}

	cmd->type = LIB_1905_CMDU_REQUEST;
	os_memcpy(request->dest_al_mac, almac, ETH_ALEN);
	request->type = SERVICE_PRIORITIZATION_REQUEST;

	/* Encap T2LM TLV.*/
	*p++ = 0xE6;

	old_p = p;
	p += 2;

	*p++ = bla_bh_t2lm_req->is_bsta_config ? 0x80 : 0x00;

	os_memcpy(p, bla_bh_t2lm_req->mld_mac, ETH_ALEN);
	p += ETH_ALEN;

	*p++ = bla_bh_t2lm_req->t2lm_negotiation ? 0x80 : 0x00;
	p += 22;

	*((unsigned short *)p) = host_to_be16(bla_bh_t2lm_req->num_mapping);
	p += 2;

	for (i = 0; i < bla_bh_t2lm_req->num_mapping; i++) {
		*p++ = bla_bh_t2lm_req->ap_t2lm_mapping[i].add_remove ? 0x80 : 0x00;

		os_memcpy(p, bla_bh_t2lm_req->ap_t2lm_mapping[i].sta_ml_mac, ETH_ALEN);
		p += ETH_ALEN;

		*p++ = bla_bh_t2lm_req->ap_t2lm_mapping[i].t2l_control;
		*p++ = bla_bh_t2lm_req->ap_t2lm_mapping[i].lm_Presence_Indicator;
		*p++ = bla_bh_t2lm_req->ap_t2lm_mapping[i].expected_duration[0];
		*p++ = bla_bh_t2lm_req->ap_t2lm_mapping[i].expected_duration[1];
		*p++ = bla_bh_t2lm_req->ap_t2lm_mapping[i].expected_duration[2];

		for (j = 0; j < MAX_TID_PER_LINK; j++) {
			if (bla_bh_t2lm_req->ap_t2lm_mapping[i].lm_Presence_Indicator & BIT(i)) {
				*((unsigned short *)p) = host_to_be16(bla_bh_t2lm_req->ap_t2lm_mapping[i].t2lm[j]);
				p += 2;
			}
		}
		p += 7;
	}
	request->len = (unsigned short)(p - request->body);

	*((unsigned short *)old_p) = host_to_be16((request->len - 3));
	if (_1905_interface_ctrl_request(ctx, (char *)cmd, sizeof(struct msg) + sizeof(struct _1905_cmdu_request) + request->len) < 0) {
		warn(DEBUG_CAT_MLO, "_1905_interface_ctrl_request error");
		return -1;
	} else {
		return 0;
	}
}

int _1905_Set_New_Interface_Info(IN struct _1905_context *ctx, IN unsigned char *buf)
{
	struct msg *cmd = (struct msg *)cmdu_buf;
	int ret = 0;

	if (!ctx) {
		warn(DEBUG_CAT_INIT, "input ctx is null");
		return -1;
	}
	if (!buf) {
		warn(DEBUG_CAT_INIT, "input buf is null");
		return -1;
	}
	cmd->type = LIB_NEW_INTERFACE_EVENT;
	cmd->length = sizeof(struct interface_info);
	os_memcpy(cmd->buffer, buf, cmd->length);
	ret = _1905_interface_ctrl_request(ctx, (char *)cmd, sizeof(struct msg) + cmd->length);
	if (ret < 0)
		warn(DEBUG_CAT_INIT, "_1905_interface_ctrl_request error");

	return ret;
}

int _1905_Set_Del_Interface_Info(IN struct _1905_context *ctx, IN unsigned char *buf)
{
	struct msg *cmd = (struct msg *)cmdu_buf;
	int ret = 0;

	if (!ctx) {
		warn(DEBUG_CAT_INIT, "input ctx is null");
		return -1;
	}
	if (!buf) {
		warn(DEBUG_CAT_INIT, "input buf is null");
		return -1;
	}
	cmd->type = LIB_DEL_INTERFACE_EVENT;
	cmd->length = os_strlen((char *)buf);
	os_memcpy(cmd->buffer, buf, cmd->length);
	ret = _1905_interface_ctrl_request(ctx, (char *)cmd, sizeof(struct msg) + cmd->length);
	if (ret < 0)
		warn(DEBUG_CAT_INIT, "_1905_interface_ctrl_request error");

	return ret;
}
