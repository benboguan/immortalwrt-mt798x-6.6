/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#include <stdio.h>
#include <unistd.h>
#include <stdarg.h>
#include <ctype.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <limits.h>
#include "debug.h"

#define ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))

int debug_level = DEBUG_NOTICE;
int debug_syslog;
int debug_timestamp;
int debug_funcline = 1;
int debug_category = 0xffffffffu;
int debug_show_keys;
char daemon_name[32];
char lcat[32][32];
char lcat_num;

//newly added
static char *dbg_lvl_str[DEBUG_LVL_MAX + 1] = {
	"OFF",
	"ERROR",
	"WARN",
	"NOTICE",
	"INFO",
	"DEBUG",
};

int log_init(char *name, char cat[][32], size_t cat_num)
{
	unsigned char i = 0, num = 0;
	int ret = 0;

	ret = snprintf(daemon_name, sizeof(daemon_name), "%s", name);
	if (ret < 0 || (unsigned int)ret >= sizeof(daemon_name)) {
		printf("%s: snprintf daemon_name error\n", __func__);
		return -1;
	}

	memset(lcat, 0, sizeof(lcat));
	num = cat_num > ARRAY_SIZE(lcat) ? ARRAY_SIZE(lcat) : cat_num;
	lcat_num = num;
	for (i = 0; i < num; i++) {
		ret = snprintf(lcat[i], 32, "%s", cat[i]);
		if (ret < 0 || (unsigned int)ret >= 32) {
			printf("%s: snprintf category error\n", __func__);
			return -1;
		}
	}

	openlog(daemon_name, LOG_PID | LOG_NDELAY, LOG_DAEMON);

	return 0;
}

void log_deinit(void)
{
	closelog();
}

static int syslog_priority(int level)
{
	switch (level) {
	case DEBUG_DEBUG:
		return LOG_DEBUG;
	case DEBUG_INFO:
		return LOG_INFO;
	case DEBUG_NOTICE:
		return LOG_NOTICE;
	case DEBUG_WARN:
		return LOG_WARNING;
	case DEBUG_ERROR:
		return LOG_ERR;
	}
	return LOG_INFO;
}

void debug_print_timestamp(void)
{
	struct timespec tv;

	if (!debug_timestamp)
		return;

	clock_gettime(CLOCK_MONOTONIC, &tv);
	if (!debug_syslog)
		printf("[%ld.%06u]_", (long)tv.tv_sec, (unsigned int)(tv.tv_nsec / 1000));
}

void _log_printf(int level, int category, int prefix, const char *func_name,
	int func_line, const char *fmt, ...)
{
	va_list args;
	int ret = 0;
	int prefix_len = 0;
	int avbl_buflen = 256;
	char buf[256] = {0};

	if (level < DEBUG_OFF || level > DEBUG_LVL_MAX) {
		printf("%s: invalid level(%d)\n", __func__, level);
		return;
	}

	if (level > debug_level)
		return;

	if (((0x1 << category) & debug_category) == 0)
		return;

	if (prefix) {
		if (debug_funcline)
			ret = snprintf(buf, avbl_buflen, "[%s][%s.%d]: ",
				lcat[category], func_name, func_line);
		else
			ret = snprintf(buf, avbl_buflen, "[%s]: ", lcat[category]);
		if (ret < 0 || (unsigned int)ret >= avbl_buflen) {
			printf("%s: vsnprintf prefix error\n", __func__);
			return;
		}
		prefix_len = ret;
	}

	va_start(args, fmt);
	if (debug_syslog) {
		if (prefix) {
			ret = vsnprintf(buf + prefix_len, avbl_buflen - prefix_len, fmt, args);
			if (ret < 0 || (unsigned int)ret >= (avbl_buflen - prefix_len))
				printf("%s: vsnprintf log content error\n", __func__);
			else
				syslog(syslog_priority(level), "%s", buf);
		} else {
			vsyslog(syslog_priority(level), fmt, args);
		}
		va_end(args);
		return;
	}
	debug_print_timestamp();
	if (prefix)
		printf("[%s][%s]%s", daemon_name, dbg_lvl_str[level], buf);
	else
		printf("%s", buf);
	vprintf(fmt, args);
	va_end(args);
}

void _log_hexdump(int level, int category, const char *title, const unsigned char *buf,
			 size_t len, int show, int only_syslog)
{
	size_t i = 0, llen = 0;
	int ret = 0;
	const size_t line_len = 16;
	const unsigned char *pos = NULL;

	if (level > debug_level)
		return;

	if (((0x1 << category) & debug_category) == 0)
		return;

	if (debug_syslog) {
		const char *display;
		char *strbuf = NULL;

		if (buf == NULL) {
			display = " [NULL]";
		} else if (len == 0) {
			display = "";
		} else if (show && len) {
			strbuf = malloc(1 + 3 * len);
			if (strbuf == NULL) {
				printf("%s: Failed to allocate message buffer", __func__);
				return;
			}
			for (i = 0; i < len; i++) {
				ret = snprintf(&strbuf[i * 3], 4, " %02x", buf[i]);
				if (ret < 0 || ret >= 4) {
					printf("%s: snprintf fail\n", __func__);
					free(strbuf);
					return;
				}
			}
			display = strbuf;
		} else {
			display = " [REMOVED]";
		}

		syslog(syslog_priority(level), "%s - hexdump(len=%lu):%s",
		       title, (unsigned long) len, display);
		if (strbuf) {
			memset(strbuf, 0, (1 + 3 * len));
			free(strbuf);
		}
		if (only_syslog)
			return;
	}
	debug_print_timestamp();
	if (!debug_syslog) {
		printf("%s - hexdump(len=%lu):\n", title, (unsigned long) len);
		if (buf == NULL) {
			printf(" [NULL]");
		} else if (show) {
			pos = buf;
			while (len) {
				llen = len > line_len ? line_len : len;
				for (i = 0; i < llen; i++)
					printf(" %02x", pos[i]);
				printf("\n");
				pos += llen;
				len -= llen;
			}
		} else {
			printf(" [REMOVED]");
		}
		printf("\n");
	}
}

void _log_hexdump_ascii(int level, int category, const char *title, const void *buf,
			       size_t len, int show)
{
	size_t i, llen;
	const unsigned char *pos = buf;
	const size_t line_len = 16;

	if (level > debug_level)
		return;

	if (((0x1 << category) & debug_category) == 0)
		return;

	if (debug_syslog)
		_log_hexdump(level, category, title, buf, len, show, 1);
	debug_print_timestamp();
	if (!debug_syslog) {
		if (!show) {
			printf("%s - hexdump_ascii(len=%lu): [REMOVED]\n",
			       title, (unsigned long) len);
			return;
		}
		if (buf == NULL) {
			printf("%s - hexdump_ascii(len=%lu): [NULL]\n",
			       title, (unsigned long) len);
			return;
		}
		printf("%s - hexdump_ascii(len=%lu):\n", title,
		       (unsigned long) len);
		while (len) {
			llen = len > line_len ? line_len : len;
			printf("    ");
			for (i = 0; i < llen; i++)
				printf(" %02x", pos[i]);
			for (i = llen; i < line_len; i++)
				printf("   ");
			printf("   ");
			for (i = 0; i < llen; i++) {
				if (isprint(pos[i]))
					printf("%c", pos[i]);
				else
					printf("_");
			}
			for (i = llen; i < line_len; i++)
				printf(" ");
			printf("\n");
			pos += llen;
			len -= llen;
		}
	}
}

int set_debug_level(int level)
{
	if (level < DEBUG_OFF || level > DEBUG_LVL_MAX)
		return -1;
	debug_level = level;

	return 0;
}

void set_log_option_str(char *arg)
{
	int lvl = 0;
	int slog = 0;
	int tstamp = 0;
	int prtfuncline = 0;
	int cat = 0;
	int ret = 0;
	long value = 0;
	char *str = NULL;
	char *endptr = NULL;

	if (arg == NULL || strlen(arg) == 0)
		goto usage;

	str = strsep(&arg, ":");
	errno = 0;
	value = strtol(str, &endptr, 10);
	if ((errno == ERANGE && (value == LONG_MAX || value == LONG_MIN))
		|| (errno != 0 && value == 0) || (endptr == str)) {
		printf("strtol log level fail!\n");
		goto usage;
	}
	lvl = value;
	ret = set_debug_level(lvl);
	if (ret)
		goto usage;

	if (arg != NULL) {
		str = strsep(&arg, ":");
		errno = 0;
		value = strtol(str, 0, 10);
		if ((errno == ERANGE && (value == LONG_MAX || value == LONG_MIN))
			|| (errno != 0 && value == 0) || (endptr == str)) {
			printf("strtol syslog fail!\n");
			goto usage;
		}
		slog = value;
		set_debug_syslog(slog);
	} else {
		goto usage;
	}

	if (arg != NULL) {
		str = strsep(&arg, ":");
		errno = 0;
		value = strtol(str, 0, 10);
		if ((errno == ERANGE && (value == LONG_MAX || value == LONG_MIN))
			|| (errno != 0 && value == 0) || (endptr == str)) {
			printf("strtol timestamp fail!\n");
			goto usage;
		}
		tstamp = value;
		set_debug_timestamp(tstamp);
	} else {
		goto usage;
	}

	if (arg != NULL) {
		str = strsep(&arg, ":");
		errno = 0;
		value = strtol(str, 0, 10);
		if ((errno == ERANGE && (value == LONG_MAX || value == LONG_MIN))
			|| (errno != 0 && value == 0) || (endptr == str)) {
			printf("strtol funcline fail!\n");
			goto usage;
		}
		prtfuncline = value;
		set_debug_funcline(prtfuncline);
	} else {
		goto usage;
	}

	if (arg != NULL) {
		str = strsep(&arg, ":");
		errno = 0;
		value = strtol(str, 0, 16);
		if ((errno == ERANGE && (value == LONG_MAX || value == LONG_MIN))
			|| (errno != 0 && value == 0) || (endptr == str)) {
			printf("strtol log category fail!\n");
			goto usage;
		}
		cat = value;
		set_debug_category(cat);
	} else {
		goto usage;
	}

	printf("debug_option=%d:%d:%d:%d:0x%08x\n", lvl, slog, tstamp, prtfuncline, cat);

	return;

usage:
	printf("Format error! correct format:\n");
	printf(" set_log_option <dbg_lvl>:<syslog>:<prt_timestamp>:<prt_funcline><category>\n");
	printf("  dbg_lvl: print the debug level; valid value is 0-5\n");
	printf("  syslog:  print log to syslog; valid 0-1; 1: to syslog; 0: to console\n");
	printf("  prt_timestamp: add timestamp with format s.us when print log on console; valid 0-1\n");
	printf("  prt_funcline: print function name and line number; valid 0-1\n");
	printf("  dbg_category: print the debug category; valid value is bit0-bit31\n");
}

void set_log_category_str(char *arg)
{
	int i = 0;
	char *token = NULL;

	if (arg == NULL || strlen(arg) == 0)
		goto usage;

	token = strsep(&arg, " ");
	if (token) {
		if (strcasecmp(token, "clear") == 0) {
			debug_category = 0;
		} else if (strcasecmp(token, "all") == 0) {
			debug_category = 0xFFFFFFFF;
		} else if (token[0] == '+') {
			token = strsep(&arg, " ");
			if (token == NULL)
				goto usage;
			while (token != NULL) {
				for (i = 0; i < lcat_num; i++) {
					if (strcasecmp(token, lcat[i]) == 0) {
						debug_category |= (1 << i);
						break;
					}
				}
				token = strsep(&arg, " ");
			}
		} else if (token[0] == '-') {
			token = strsep(&arg, " ");
			if (token == NULL)
				goto usage;
			while (token != NULL) {
				for (i = 0; i < lcat_num; i++) {
					if (strcasecmp(token, lcat[i]) == 0) {
						debug_category &= ~(1 << i);
						break;
					}
				}
				token = strsep(&arg, " ");
			}
		} else {
			goto usage;
		}
	} else {
		goto usage;
	}

	printf("Current debug_category: 0x%08X\n", debug_category);
	for (int i = 0; i < lcat_num; ++i) {
		if (debug_category & (1 << i))
			printf("1\t%s\t\tbit%d\n", lcat[i], i);
		else
			printf("0\t%s\t\tbit%d\n", lcat[i], i);
	}
	return;

usage:
	printf("Format error! correct format:\n");
	printf(" clear: Clear all categories\n");
	printf(" full: Set all categories to FF\n");
	printf(" +<CATEGORY>: Set the corresponding bit for CATEGORY\n");
	printf(" -<CATEGORY>: Clear the corresponding bit for CATEGORY\n");
}

int get_log_info(char *buf, size_t max_len)
{
	char *pos = buf;
	int ret = 0;
	unsigned int i = 0, len = 0;

	if (debug_level < DEBUG_OFF || debug_level > DEBUG_LVL_MAX) {
		printf("invalid debug_level(%d)\n", debug_level);
		return -1;
	}

	ret = snprintf(pos, max_len, "\nlog info:\n");
	if (ret < 0 || (unsigned int)ret >= max_len) {
		printf("snprintf log info fail\n");
		return -1;
	}
	len += ret;

	ret = snprintf(pos + len, max_len - len, "\tdebug_level=%d(%s)\n",
			debug_level, dbg_lvl_str[debug_level]);
	if (ret < 0 || (unsigned int)ret >= (max_len - len)) {
		printf("snprintf debug_level fail\n");
		return -1;
	}
	len += ret;

	ret = snprintf(pos + len, max_len - len, "\tdebug_syslog=%d(%s)\n", debug_syslog, debug_syslog ? "enable" : "disable");
	if (ret < 0 || (unsigned int)ret >= (max_len - len)) {
		printf("snprintf debug_syslog fail\n");
		return -1;
	}
	len += ret;

	ret = snprintf(pos + len, max_len - len, "\tdebug_timestamp=%d(%s)\n", debug_timestamp, debug_timestamp ? "enable" : "disable");
	if (ret < 0 || (unsigned int)ret >= (max_len - len)) {
		printf("snprintf debug_timestamp fail\n");
		return -1;
	}
	len += ret;

	ret = snprintf(pos + len, max_len - len, "\tdebug_funcline=%d(%s)\n", debug_funcline, debug_funcline ? "enable" : "disable");
	if (ret < 0 || (unsigned int)ret >= (max_len - len)) {
		printf("snprintf debug_funcline fail\n");
		return -1;
	}
	len += ret;

	ret = snprintf(pos + len, max_len - len, "\tdebug_category=0x%x\n", debug_category);
	if (ret < 0 || (unsigned int)ret >= (max_len - len)) {
		printf("snprintf debug_category fail\n");
		return -1;
	}
	len += ret;
	for (i = 0; i < lcat_num; i++) {
		if (debug_category & (1 << i)) {
			ret = snprintf(pos + len, max_len - len, "\t1\t%s\t\tbit%d\n", lcat[i], i);
			if (ret < 0 || (unsigned int)ret >= (max_len - len)) {
				printf("snprintf debug_category %s set fail\n", lcat[i]);
				return -1;
			}
			len += ret;
		} else {
			ret = snprintf(pos + len, max_len - len, "\t0\t%s\t\tbit%d\n", lcat[i], i);
			if (ret < 0 || (unsigned int)ret >= (max_len - len)) {
				printf("snprintf debug_category %s unset fail\n", lcat[i]);
				return -1;
			}
			len += ret;
		}
	}

	return len;
}

