/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#include <stdio.h>
#include <string.h>
#include <syslog.h>
#include <assert.h>
#include <linux/if_ether.h>
#include <asm/byteorder.h>
#include "cmdu_tlv.h"
#include "multi_ap.h"
#include "debug.h"
#include "wsc_attr_tlv.h"
#ifdef MAP_R3
#include "wpabuf.h"
#include "json.h"
#endif
#ifdef EM_PLUS_SUPPORT
#include "emplus.h"
#endif

#ifdef MAP_R3
static unsigned char OUI_WPA2_AKM_PSK[4] = {0x00, 0x0F, 0xAC, 0x02};
static unsigned char OUI_WPA2_AKM_PSK_SHA256[4] = {0x00, 0x0F, 0xAC, 0x06};
static unsigned char OUI_WPA2_AKM_SAE_SHA256[4] = {0x00, 0x0F, 0xAC, 0x08};
static unsigned char OUI_AKM_DPP[4] = {0x50, 0x6F, 0x9A, 0x02};
#endif
#ifdef MAP_R6
static unsigned char OUI_AKM_SAE24[4] = {0x00, 0x0F, 0xAC, 0x24};
#endif

#define MAX_NEIGHBORS_IN_ONE_TLV 100
extern WSC_ATTR_STATUS create_wsc_msg_M1(
	struct p1905_managerd_ctx *ctx, unsigned char *pkt, unsigned short *length);
extern WSC_ATTR_STATUS create_wsc_msg_M2(
	struct p1905_managerd_ctx *ctx, unsigned char *pkt, unsigned short *length,
	WSC_CONFIG *config_data, unsigned char wfa_vendor_extension);
#ifdef MAP_R6
WSC_ATTR_STATUS create_wsc_msg_M8(
	struct p1905_managerd_ctx *ctx, unsigned char *pkt, unsigned short *length,
	WSC_CONFIG *config_data, unsigned char wfa_vendor_extension);
#endif

unsigned short append_1905_al_mac_addr_type_tlv(unsigned char *pkt,
    unsigned char *al_mac)
{
    unsigned short total_length = 0;

    *pkt++ = AL_MAC_ADDR_TLV_TYPE;
    total_length += 1;

	*(unsigned short *)(pkt) = host_to_be16(AL_MAC_ADDR_TLV_LENGTH);
	pkt += 2;
    total_length += 2;

    memcpy(pkt,al_mac,ETH_ALEN);

    total_length += AL_MAC_ADDR_TLV_LENGTH;
    return total_length;
}

unsigned short append_mac_addr_type_tlv(unsigned char *pkt,
    unsigned char *itf_mac)
{
    unsigned short total_length = 0;

    *pkt++ = MAC_ADDR_TLV_TYPE;
    total_length += 1;

	*(unsigned short *)(pkt) = host_to_be16(MAC_ADDR_TLV_LENGTH);
	pkt += 2;
    total_length += 2;

    memcpy(pkt,itf_mac,ETH_ALEN);

    total_length += MAC_ADDR_TLV_LENGTH;
    return total_length;
}

unsigned short append_device_info_type_tlv(unsigned char *pkt,
    unsigned char *al_mac,struct p1905_managerd_ctx *ctx)
{
	unsigned short total_length = 0;
	unsigned char *temp_buf = NULL;
#ifdef EM_PLUS_SUPPORT
	u8 zero_mac[] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
	unsigned char itf_amount = ctx->itf_number;
#endif /*EM_PLUS_SUPORT*/

	struct p1905_interface* itf_list = ctx->itf;
    int i =0;

    temp_buf = pkt;

    *temp_buf = DEVICE_INFO_TLV_TYPE;
    temp_buf +=1;
    total_length += 1;

    /* shift to tlv value ,we will calculate the tlv value length in the end
     *  of this function
     */
    temp_buf +=2;
    total_length += 2;

    /*al mac address*/
    memcpy(temp_buf,al_mac,ETH_ALEN);
    temp_buf +=6;
    total_length += 6;

#ifdef EM_PLUS_SUPPORT
	/*amount of local p1905.1 interface, will be overwrite at the end */
#else
    /*amount of local p1905.1 interface */
#endif /*EM_PLUS_SUPPORT*/

    *temp_buf = ctx->itf_number;
    temp_buf +=1;
    total_length += 1;

#ifdef EM_PLUS_SUPPORT
	/*add bridge mac*/
	if (os_memcmp(ctx->br_addr, zero_mac, ETH_ALEN)) {
		itf_amount = ctx->itf_number + 1;
		memcpy(temp_buf, ctx->br_addr, ETH_ALEN);
		temp_buf += ETH_ALEN;
		total_length += ETH_ALEN;

		*(unsigned short *)(temp_buf) = host_to_be16(IEEE802_3_AB_GROUP);
		temp_buf += 2;
		total_length += 2;

		*temp_buf = 0;
		temp_buf += 1;
		total_length += 1;
	}
#endif /*EM_PLUS_SUPPORT*/

    /*info of every interface*/
#ifdef EM_PLUS_SUPPORT
	for (i = 0; i < ctx->itf_number; i++) {
		/*exclude lo interface in the topology response*/
		if (itf_list[i].is_veth) {
			itf_amount--;
			info(DEBUG_CAT_EMPLUS, "skip %s interface, cnt = %d\n",
				itf_list[i].if_name, itf_amount);
			continue;
		}
#else
    for (i = 0; i < ctx->itf_number; i++)
    {
#endif /*EM_PLUS_SUPPORT*/

        memcpy(temp_buf,itf_list[i].mac_addr,ETH_ALEN);
        temp_buf += ETH_ALEN;
        total_length += ETH_ALEN;

        *(unsigned short *)(temp_buf) = host_to_be16(itf_list[i].media_type);
        temp_buf += 2;
        total_length += 2;

        *temp_buf = itf_list[i].vs_info_length;
        temp_buf += 1;
	total_length += 1;

		if ((itf_list[i].vs_info_length == 10) && itf_list[i].vs_info) {
#ifdef SUPPORT_WIFI
            if(itf_list[i].media_type >= IEEE802_11_GROUP &&
               itf_list[i].media_type < IEEE1901_GROUP)
            {
                /* we use 802.11n device, dot11CurrentChannelCenterFrequencyIndex1 = 0*/
				*((itf_list[i].vs_info) + 7) = itf_list[i].channel_bw;
				*((itf_list[i].vs_info) + 8) = itf_list[i].channel_freq;
                 *((itf_list[i].vs_info) + 9) = 0;
            }
#endif
            memcpy(temp_buf,itf_list[i].vs_info,itf_list[i].vs_info_length);
            temp_buf += itf_list[i].vs_info_length;
            total_length += itf_list[i].vs_info_length;
        }
    }
    /*finally, fill the total tlv value length into tlv length field*/
	*(unsigned short *)(pkt + 1) = host_to_be16(total_length - 3);

#ifdef EM_PLUS_SUPPORT
	/*update local interface count*/
	*(unsigned char *)(pkt + 9) = itf_amount;
#endif /*EM_PLUS_SUPPORT*/

    return total_length;
}

unsigned short append_device_bridge_capability_type_tlv(unsigned char *pkt,
    struct bridge_capabiltiy *br_cap_list)
{
    unsigned short total_length = 0;
    unsigned char *temp_buf;
    int i =0;

    temp_buf = pkt;

    *temp_buf = BRIDGE_CAPABILITY_TLV_TYPE;
    temp_buf +=1;
    total_length += 1;

    /* shift to tlv value ,we will calculate the tlv value length in the end
     * ofthis function
     */
    temp_buf +=2;
    total_length += 2;

    /*amount of internal bridge*/
    *temp_buf = BRIDGE_NUM;
    temp_buf +=1;
    total_length += 1;

    for(i=0;i<BRIDGE_NUM;i++)
    {
        *temp_buf = br_cap_list[i].interface_num;
        temp_buf +=1;
        total_length += 1;

        memcpy(temp_buf, br_cap_list[i].itf_mac_list,
               (ETH_ALEN*br_cap_list[i].interface_num));

        temp_buf += ETH_ALEN * br_cap_list[i].interface_num;
        total_length += ETH_ALEN * br_cap_list[i].interface_num;
    }

    /*finally, fill the total tlv value length into tlv length field*/
	*(unsigned short *)(pkt + 1) = host_to_be16(total_length - 3);

    return total_length;
}

#ifdef EM_PLUS_EXT_SUPPORT
unsigned short append_gw_agent_p1905_neighbor_device_type_tlv(unsigned char *pkt,
	struct topology_discovery_db *atpg_db, int num, unsigned char *separate)
{

	unsigned short total_length = 0;

	unsigned char *temp_buf;
    //int i = 0;

	debug(DEBUG_CAT_EMPLUS, "Add GW-Agent entry\n");

	temp_buf = pkt;
    //i = num;

  /*firstly shift to tlv value*/
	temp_buf += 3;
	total_length += 3;

	memcpy(temp_buf, atpg_db->receive_itf_mac, ETH_ALEN);
	temp_buf += ETH_ALEN;
	total_length += ETH_ALEN;

	memcpy(temp_buf, atpg_db->al_mac, ETH_ALEN);
	temp_buf += ETH_ALEN;
	total_length += ETH_ALEN;

	(*temp_buf) = 0x0;
	temp_buf += 1;
	total_length += 1;


   /*if really has the p1905.1 neighbor device, append type & length */
	(*pkt) = P1905_NEIGHBOR_DEV_TLV_TYPE;
	*(unsigned short *)(pkt + 1) = host_to_be16(total_length - 3);

	return total_length;
}
#endif

unsigned short append_p1905_neighbor_device_type_tlv(unsigned char *pkt,
    struct p1905_neighbor *devlist, int num, unsigned char *seperate)
{
    unsigned short total_length = 0;
    unsigned char *temp_buf;
    int i = 0;
    struct p1905_neighbor_info *info;
    unsigned char exist = 0;
    unsigned char neighbor_num = 0;
    static unsigned char record_mac[ETH_ALEN] = {0};

    temp_buf = pkt;
    i = num;

  /*firstly shift to tlv value*/
    temp_buf += 3;
    total_length += 3;

    if(!LIST_EMPTY(&(devlist[i].p1905nbr_head)))
    {
        //exist = 1;
        memcpy(temp_buf, devlist[i].local_mac_addr, ETH_ALEN);
        temp_buf += ETH_ALEN;
        total_length += ETH_ALEN;

        LIST_FOREACH(info, &(devlist[i].p1905nbr_head), p1905nbr_entry)
        {
            if(*seperate)
            {
                if(memcmp(record_mac, info->al_mac_addr, ETH_ALEN))
                {
                    continue;
                }

                /*shift to next p1905.1 neighbor device database*/
                *seperate = 0;
                continue;
            }

            exist = 1;
            memcpy(temp_buf, info->al_mac_addr, ETH_ALEN);
            temp_buf += ETH_ALEN;
            total_length += ETH_ALEN;

            if(info->ieee802_1_bridge)
                (*temp_buf) = 0x80;
            else
                (*temp_buf) = 0x0;
            temp_buf += 1;
            total_length += 1;

            /* use neighbor_num to record how many neighbors in one tlv
             * we don't want the tlv length larger than max message length
             * so we restrict the neighbor number to MAX_NEIGHBORS_IN_ONE_TLV
             * Notice:  although we can fragmet the cmdu, but cmdu is protocol
             * tlv boundary. So one tlv cannot exceed max message length.
             */
            neighbor_num += 1;
            if(neighbor_num == MAX_NEIGHBORS_IN_ONE_TLV)
            {
                *seperate = 1;
                memcpy(record_mac, info->al_mac_addr, ETH_ALEN);
                break;
            }
         }
     }

    /*if really has the p1905.1 neighbor device, append type & length */
    if(exist)
    {
        (*pkt) = P1905_NEIGHBOR_DEV_TLV_TYPE;
		*(unsigned short *)(pkt + 1) = host_to_be16(total_length - 3);
        return total_length;
    }
    else
        return 0;
}

unsigned short append_non_p1905_neighbor_device_type_tlv(unsigned char *pkt,
    struct non_p1905_neighbor *devlist, int num, unsigned char *seperate)
{
    unsigned short total_length = 0;
    unsigned char *temp_buf;
    unsigned char exist = 0;
    struct non_p1905_neighbor_info *info;
    unsigned char neighbor_num = 0;
    static unsigned char record_mac[ETH_ALEN] = {0};

    temp_buf = pkt;

    /*shift to value field*/
    temp_buf += 3;
    total_length += 3;

    /*local interface mac field*/
    memcpy(temp_buf, devlist[num].local_mac_addr, ETH_ALEN);
    temp_buf += ETH_ALEN;
    total_length += ETH_ALEN;

    /*mac address of non-1905.1 neighbor device*/
    if(!LIST_EMPTY(&(devlist[num].non_p1905nbr_head)))
    {
        LIST_FOREACH(info, &(devlist[num].non_p1905nbr_head), non_p1905nbr_entry)
        {
            if(*seperate)
            {
                if(memcmp(record_mac, info->itf_mac_addr, ETH_ALEN))
                {
                    continue;
                }

                /*shift to next non-p1905.1 neighbor device database*/
                *seperate = 0;
                memset(record_mac, 0, ETH_ALEN);
                continue;
            }

            exist =1;
            memcpy(temp_buf, info->itf_mac_addr, ETH_ALEN);
            temp_buf += ETH_ALEN;
            total_length += ETH_ALEN;

            /* use neighbor_num to record how many neighbors in one tlv
             * we don't want the tlv length larger than max message length
             * so we restrict the neighbor number to MAX_NEIGHBORS_IN_ONE_TLV
             * Notice:  although we can fragmet the cmdu, but cmdu is protocol
             * tlv boundary. So one tlv cannot exceed max message length.
             */
            neighbor_num += 1;
            if(neighbor_num == MAX_NEIGHBORS_IN_ONE_TLV)
            {
                *seperate = 1;
                memcpy(record_mac, info->itf_mac_addr, ETH_ALEN);
                break;
            }
        }
    }

    /*if really has the non-1905.1 neighbor device, append type & length */
    if(exist)
    {
        (*pkt) = NON_P1905_NEIGHBOR_DEV_TLV_TYPE;
		*(unsigned short *)(pkt + 1) = host_to_be16(total_length - 3);
        return total_length;
    }
    else
        return 0;
}

unsigned short append_end_of_tlv(unsigned char *pkt)
{
    unsigned short total_length = 0;

    *pkt++ = END_OF_TLV_TYPE;
    total_length += 1;

	*(unsigned short *)(pkt) = host_to_be16(END_OF_TLV_LENGTH);
    total_length += 2;

    return total_length;
}

unsigned short append_vendor_specific_type_tlv(unsigned char *pkt,
                                               struct p1905_vs_info *vs_info)
{
    unsigned short total_length = 0;
    unsigned char *temp_buf;

    temp_buf = pkt;
    *pkt = VENDOR_SPECIFIC_TLV_TYPE;
    total_length += 1;
    temp_buf += 1;

    /*shift to OUI field*/
    temp_buf += 2;
    total_length += 2;

	memcpy(temp_buf, OUI_MEDIATEK, OUI_LEN);
    temp_buf += OUI_LEN;
    total_length += OUI_LEN;


    /*append AL MAC*/
	/*
    memcpy(temp_buf, vs_info->al_mac, ETH_ALEN);
    temp_buf += ETH_ALEN;
    total_length += ETH_ALEN;
	*/
    /*add more vendor specific information below*/

    /*.........................................*/
    /*add more vendor specific information above*/
    *(pkt + 1) =  (unsigned char)(((total_length - 3) >> 8) & 0xff);
    *(pkt + 2) =  (unsigned char)((total_length - 3) & 0xff);

    return total_length;
}

unsigned short append_link_metrics_query_type_tlv(unsigned char *pkt,
                                                  unsigned char *target_al_mac,
                                                  unsigned char type)
{
    unsigned short total_length = 0;
    unsigned char *temp_buf;
    unsigned char query_all_neighbor[ETH_ALEN] = {0,0,0,0,0,0};


    temp_buf = pkt;

    *temp_buf = LINK_METRICS_QUERY_TLV_TYPE;
    temp_buf +=1;
    total_length += 1;

    /* The length of link metrics query is a variable.
     * It depends on target & type, so shift to payload first
     */
    temp_buf +=2;
    total_length += 2;

    /*query link metrics of ALL neighbor or specific neighbor */
    if(!memcmp(target_al_mac, query_all_neighbor, ETH_ALEN))
    {
        *temp_buf = QUERY_ALL_NEIGHBOR;
        temp_buf += 1;
        total_length += 1;
    }
    else
    {
        *temp_buf = QUERY_SPECIFIC_NEIGHBOR;
        /*specific neighbor, append the AL MAC of neighbor in following field*/
        temp_buf += 1;
        total_length += 1;

        memcpy(temp_buf, target_al_mac, ETH_ALEN);
        temp_buf += ETH_ALEN;
        total_length += ETH_ALEN;
    }

    if(type == TX_METRICS_ONLY)
        *temp_buf = TX_METRICS_ONLY;
    else if(type == RX_METRICS_ONLY)
        *temp_buf = RX_METRICS_ONLY;
    else if(type == BOTH_TX_AND_RX_METRICS)
        *temp_buf = BOTH_TX_AND_RX_METRICS;

    temp_buf += 1;
    total_length += 1;

    /*calculate totoal length & fill into the length field*/
	*(unsigned short *)(pkt+1) = host_to_be16(total_length - 3);

    return total_length;
}

unsigned short append_link_metrics_result_code_tlv(unsigned char *pkt)
{
    unsigned short total_length = 0;
    unsigned char *temp_buf;

    temp_buf = pkt;

    *temp_buf = RESULT_CODE_TLV_TYPE;
    temp_buf +=1;
    total_length += 1;

    /*calculate totoal length & fill into the length field*/
	*(unsigned short *)(temp_buf) = host_to_be16(LINK_METRIC_RESULT_CODE_LENGTH);

    temp_buf +=2;
    total_length += 2;

    /*0x00: Invalid neighbor, other value: reserved*/
    *temp_buf = 0x0;
    temp_buf +=1;
    total_length += 1;
    return total_length;
}

unsigned short append_push_button_event_notification_tlv(unsigned char *pkt,
                    struct p1905_interface *itf_list)
{
    unsigned short total_length = 0;
    unsigned char *temp_buf;
    int i = 0, launch_itf_amount = 0;

    temp_buf = pkt;

    *temp_buf = PUSH_BUTTON_EVENT_NOTIFICATION_TYPE;
    temp_buf +=1;
    total_length += 1;

    /*shift the tlvLength field firstly*/
    temp_buf +=2;
    total_length += 2;

    for(i=0;i<ITF_NUM;i++)
    {
        if(((itf_list[i].media_type >= IEEE1901_GROUP) &&
            (itf_list[i].media_type < MOCA_GROUP)))
            launch_itf_amount++;
#ifdef SUPPORT_WIFI
        else if(((itf_list[i].media_type >= IEEE802_11_GROUP) &&
            (itf_list[i].media_type < IEEE1901_GROUP)))
        {
            /*if wifi interface is AP, need to launch PBC configuration*/
            if((*((itf_list[i].vs_info) + 6)) == 0)
                launch_itf_amount++;
            #ifdef SUPPORT_WIFI_STATION
            /* if wifi interface is station and no link, need to launch
             * PBC configuration, implement in future
             */
            #endif
        }
#endif
    }
    /*fill into number of media type*/
    *temp_buf = launch_itf_amount;
    temp_buf +=1;
    total_length += 1;


    for(i=0;i<ITF_NUM;i++)
    {
#ifdef SUPPORT_WIFI
        if(((itf_list[i].media_type >= IEEE802_11_GROUP) &&
                    (itf_list[i].media_type < IEEE1901_GROUP)))
        {
            /*media type field, 2 octets*/
            *temp_buf = (itf_list[i].media_type >> 8) & 0xFF;
            *(temp_buf + 1) = itf_list[i].media_type & 0xFF;
            temp_buf += 2;
            total_length += 2;

            /*media specific info length*/
            *temp_buf = 10;
            temp_buf += 1;
            total_length += 1;

            /* we use 802.11n device, dot11CurrentChannelCenterFrequencyIndex1 = 0*/
            *((itf_list[i].vs_info) + 9) = 0;

            memcpy(temp_buf,itf_list[i].vs_info,itf_list[i].vs_info_length);
            temp_buf += itf_list[i].vs_info_length;
            total_length += itf_list[i].vs_info_length;
        }
#endif
    }

    /*calculate totoal length & fill into the length field*/
    *(pkt + 1) =  (unsigned char)(((total_length - 3) >> 8) & 0xff);
    *(pkt + 2) =  (unsigned char)((total_length - 3) & 0xff);

    return total_length;
}

unsigned short append_push_button_join_notification_tlv(unsigned char *pkt,
                unsigned char *al_id, unsigned short mid,
                unsigned char *local_mac, unsigned char *new_device_mac)
{
    unsigned short total_length = 0;
    unsigned char *temp_buf;

    temp_buf = pkt;

    *temp_buf = PUSH_BUTTON_JOIN_NOTIFICATION_TYPE;
    temp_buf +=1;

    *(temp_buf) = (unsigned char)((PUSH_BUTTON_JOIN_NOTIFICATION_LENGTH & 0xFF00) >> 8);
    *(temp_buf + 1) = (unsigned char)(PUSH_BUTTON_JOIN_NOTIFICATION_LENGTH & 0x00FF);
    temp_buf += 2;
    total_length = PUSH_BUTTON_JOIN_NOTIFICATION_LENGTH + 3;

    /*fill into al id field*/
    memcpy(temp_buf, al_id, ETH_ALEN);
    temp_buf += ETH_ALEN;

    /*fill into mid field*/
    *(temp_buf) = (unsigned char)((mid & 0xFF00) >> 8);
    *(temp_buf + 1) = (unsigned char)(mid & 0x00FF);
    temp_buf += 2;

    /*fill into local plc mac*/
    memcpy(temp_buf, local_mac, ETH_ALEN);
    temp_buf += ETH_ALEN;

    /*fill into new joined plc mac*/
    memcpy(temp_buf, new_device_mac, ETH_ALEN);
    temp_buf += ETH_ALEN;

    return total_length;
}

unsigned short append_searched_role_tlv(
        unsigned char *pkt)
{
    unsigned short total_length = 0;
    unsigned char *temp_buf;

    temp_buf = pkt;

    *temp_buf = SEARCH_ROLE_TLV_TYPE;
    temp_buf +=1;

	*(unsigned short *)(temp_buf) = host_to_be16(SEARCH_ROLE_LENGTH);
    temp_buf += 2;
    total_length = SEARCH_ROLE_LENGTH + 3;

    *temp_buf = ROLE_REGISTRAR;
    return total_length;
}

unsigned short append_autoconfig_freq_band_tlv(
        unsigned char *pkt, unsigned char band)
{
    unsigned short total_length = 0;
    unsigned char *temp_buf;

    temp_buf = pkt;

    *temp_buf = AUTO_CONFIG_FREQ_BAND_TLV_TYPE;
    temp_buf +=1;

	*(unsigned short *)(temp_buf) = host_to_be16(AUTOCONFIG_FREQ_BAND_LENGTH);
    temp_buf += 2;
    total_length = AUTOCONFIG_FREQ_BAND_LENGTH + 3;

    /*0x00: 2.4G, 0x01:5G, 0x02:60G, no 60G case now*/
    *temp_buf = band;

    return total_length;
}

unsigned short append_supported_role_tlv(
        unsigned char *pkt)
{
    unsigned short total_length = 0;
    unsigned char *temp_buf;

    temp_buf = pkt;

    *temp_buf = SUPPORT_ROLE_TLV_TYPE;
    temp_buf +=1;

	*(unsigned short *)(temp_buf) = host_to_be16(SUPPORTED_ROLE_LENGTH);
    temp_buf += 2;
    total_length = SUPPORTED_ROLE_LENGTH + 3;

    *temp_buf = ROLE_REGISTRAR;
    return total_length;
}

unsigned short append_supported_freq_band_tlv(
        unsigned char *pkt, unsigned char band)
{
    unsigned short total_length = 0;
    unsigned char *temp_buf;

    temp_buf = pkt;

    *temp_buf = SUPPORT_FREQ_BAND_TLV_TYPE;
    temp_buf +=1;

	*(unsigned short *)(temp_buf) = host_to_be16(SUPPORTED_FREQ_BAND_LENGTH);
    temp_buf += 2;
    total_length = SUPPORTED_FREQ_BAND_LENGTH + 3;

    /*0x00: 2.4G, 0x01:5G, 0x02:60G, no 60G case now*/
    *temp_buf = band;

    return total_length;
}

unsigned short append_WSC_tlv(
	unsigned char *pkt, struct p1905_managerd_ctx *ctx, unsigned char wsc_type,
	WSC_CONFIG *config_data, unsigned char wfa_vendor_extension)
{
    unsigned short total_length = 0;
    unsigned char *temp_buf;
    WSC_ATTR_STATUS status = wsc_attr_success;
    unsigned short wsc_length = 0;

    temp_buf = pkt;

    *temp_buf = WSC_TLV_TYPE;
    temp_buf +=1;
    total_length += 1;

    /*shift the tlvLength field firstly*/
    temp_buf +=2;
    total_length += 2;

	if (ctx->role == AGENT) {
    	if (wsc_type == MESSAGE_TYPE_M1)
        	status = create_wsc_msg_M1(ctx, temp_buf, &wsc_length);
	} else {
		if (wsc_type == MESSAGE_TYPE_M2)
			status = create_wsc_msg_M2(ctx, temp_buf, &wsc_length, config_data, wfa_vendor_extension);
#ifdef MAP_R6
		else if (wsc_type == MESSAGE_TYPE_M8)
			status = create_wsc_msg_M8(ctx, temp_buf, &wsc_length, config_data, wfa_vendor_extension);
#endif
	}

	if (status != wsc_attr_success) {
		err(DEBUG_CAT_AUTOCONF, "create WSC TLV type 0x%02x(%s) fail\n",
			wsc_type, get_wsc_msg_type_str(wsc_type));
		total_length = 0;
		goto end;
	}

    total_length += wsc_length;

    /*calculate totoal length & fill into the length field*/
	*(unsigned short *)(pkt+1) = host_to_be16(total_length - 3);

end:
    return total_length;
}

unsigned short append_send_tlv(unsigned char *pkt, struct p1905_managerd_ctx *ctx)
{
	unsigned short total_length = 0;
	unsigned char *temp_buf;

	temp_buf = pkt;
	total_length = ctx->send_tlv_len;
	memcpy(temp_buf, ctx->send_tlv, ctx->send_tlv_len);

	ctx->send_tlv_len = 0;

	return total_length;
}

unsigned short append_send_tlv_relayed(unsigned char *pkt, struct p1905_managerd_ctx *ctx)
{
	unsigned short total_length = 0;
	unsigned char *temp_buf;

	temp_buf = pkt;
	total_length = ctx->send_tlv_len;
	memcpy(temp_buf, ctx->send_tlv, ctx->send_tlv_len);

	return total_length;
}

/*MAP defined tlv*/
/**
  * @service: 1 for controller only; 2 for agent only; 3 for both controller and agent
  */
unsigned short append_supported_service_tlv(
        unsigned char *pkt, unsigned char service)
{
    unsigned short total_length = 0;
    unsigned char *temp_buf;

    temp_buf = pkt;

    *temp_buf = SUPPORTED_SERVICE_TLV_TYPE;
    temp_buf +=1;
	/**
	  * need communicate with WAPP to get supported service
	  * or just write hard code to Multi-AP Agent
	  */
	if (service == 0) {
		*(unsigned short *)(temp_buf) = host_to_be16(SUPPORTED_SERVICE_LENGTH);
		temp_buf += 2;
		*temp_buf++ = SUPPORTED_SERVICE_LENGTH - 1;
		*temp_buf = SERVICE_CONTROLLER;
#ifdef EM_PLUS_SUPPORT
		temp_buf++;
		*temp_buf = SERVICE_EMPLUS_CONTROLLER;
#endif /*EM_PLUS_SUPPORT*/
		total_length = SUPPORTED_SERVICE_LENGTH + 3;
	} else if (service == 1) {
		*(unsigned short *)(temp_buf) = host_to_be16(SUPPORTED_SERVICE_LENGTH);
		temp_buf += 2;
		*temp_buf++ = SUPPORTED_SERVICE_LENGTH - 1;
		*temp_buf = SERVICE_AGENT;
#ifdef EM_PLUS_SUPPORT
		temp_buf++;
		*temp_buf = SERVICE_EMPLUS_AGENT;
#endif /*EM_PLUS_SUPPORT*/
		total_length = SUPPORTED_SERVICE_LENGTH + 3;

	} else if (service == 2) {
		*(unsigned short *)(temp_buf) = host_to_be16(SUPPORTED_SERVICE2_LENGTH);
    	temp_buf += 2;
		*temp_buf++ = 2;
    	*temp_buf++ = SERVICE_CONTROLLER;
		*temp_buf = SERVICE_AGENT;
    	total_length = SUPPORTED_SERVICE2_LENGTH + 3;
	}

    return total_length;
}

unsigned short append_controller_cap_tlv(
		unsigned char *pkt, struct controller_capability contr_cap)
{
	unsigned short total_length = 0;
	unsigned char *temp_buf;

	temp_buf = pkt;

	*temp_buf = CONTROLLER_CAPABILITY_TYPE;
	temp_buf += 1;

	temp_buf += 2;

	*temp_buf = 0;
	if (contr_cap.kibmib)
		*temp_buf |= 0x80;
#ifdef MAP_R6
	/* Accept Early AP Capability Report */
	*temp_buf |= 0x40;
#endif
	temp_buf += 1;

	/* Reserved for future expansion */
	*temp_buf = 0;
	temp_buf += 1;

	total_length = temp_buf - pkt;
	*(unsigned short *)(pkt + 1) = host_to_be16(total_length - 3);
	return total_length;
}

unsigned short append_searched_service_tlv(
        unsigned char *pkt)
{
    unsigned short total_length = 0;
    unsigned char *temp_buf;

    temp_buf = pkt;

    *temp_buf = SEARCHED_SERVICE_TLV_TYPE;
    temp_buf +=1;

	*(unsigned short *)(temp_buf) = host_to_be16(SEARCHED_SERVICE_LENGTH);
    temp_buf += 2;
	*temp_buf++ = 1;
    *temp_buf = SERVICE_CONTROLLER;

    total_length = SEARCHED_SERVICE_LENGTH + 3;

    return total_length;
}
/**
  * @identifier: 6 byte of Radio Unique Identifier of a radio of the Agent
  */
unsigned short append_ap_radio_identifier_tlv(
        unsigned char *pkt, unsigned char *identifier)
{
    unsigned short total_length = 0;
    unsigned char *temp_buf;

    temp_buf = pkt;

    *temp_buf = AP_RADIO_IDENTIFIER_TYPE;
    temp_buf +=1;

	*(unsigned short *)(temp_buf) = host_to_be16(AP_RADIO_IDENTIFIER_LENGTH);
    temp_buf += 2;
	memcpy(temp_buf,identifier,ETH_ALEN);

    total_length = AP_RADIO_IDENTIFIER_LENGTH + 3;

    return total_length;
}

unsigned short append_ap_radio_basic_capability_tlv(struct p1905_managerd_ctx* ctx, unsigned char *pkt,
	struct radio_info *r)
{
	unsigned short total_length = 0, tmp_len = 0;
    unsigned char *temp_buf;
	struct operating_class *opc = NULL;

	temp_buf = pkt;
	*temp_buf = AP_RADIO_BASIC_CAPABILITY_TYPE;
    temp_buf += 1;
	total_length += 1;

	temp_buf += 2;
	total_length += 2;

	memcpy(temp_buf, r->identifier, ETH_ALEN);
	temp_buf += ETH_ALEN;
	total_length += ETH_ALEN;

	temp_buf[0] = r->basic_cap.max_bss_num;
	temp_buf += 1;
	total_length += 1;

	temp_buf[0] = r->basic_cap.op_class_num;
	temp_buf += 1;
	total_length += 1;

	dl_list_for_each(opc, &r->basic_cap.op_class_list, struct operating_class, entry) {
		tmp_len = 3 + opc->non_operch_num;
		memcpy(temp_buf, opc, tmp_len);
		temp_buf += tmp_len;
		total_length += tmp_len;
	}

	/*calculate totoal length & fill into the length field*/
	*(unsigned short *)(pkt+1) = host_to_be16(total_length - 3);

	return total_length;
}


/**
  * @cap1(0 or 1): cap of unassociated sta link metrics reporting on the channels its BSSs are
  * currently operating on
  * @cap2(0 or 1): cap of unassociated sta link metrics reporting on the channels its BSSs are
  * not currently operating on
  * @cap3(0 or 1): cap of Agent-initiated RSSI-based Steering
  */
unsigned short append_ap_capability_tlv(
        unsigned char *pkt, struct ap_capability *ap_cap)
{
    unsigned short total_length = 0;
    unsigned char *temp_buf;

    temp_buf = pkt;

    *temp_buf = AP_CAPABILITY_TYPE;
    temp_buf +=1;

	*(unsigned short *)(temp_buf) = host_to_be16(AP_CAPABILITY_LENGTH);
    temp_buf += 2;

	/*if big endian is correct*/
	*temp_buf = (ap_cap->sta_report_on_cop << 7) | (ap_cap->sta_report_not_cop << 6) |
		(ap_cap->rssi_steer << 5)
#ifdef MAP_R6
		| (ap_cap->bsta_wsc_reconfig << 4)
#endif
	;

    total_length = AP_CAPABILITY_LENGTH + 3;

    return total_length;
}

unsigned short append_ap_ht_capability_tlv(
        unsigned char *pkt, struct ap_ht_cap_db* ht_cap)
{
    unsigned short total_length = 0;
    unsigned char *temp_buf;

    temp_buf = pkt;

    *temp_buf++ = AP_HT_CAPABILITY_TYPE;

	*(unsigned short *)(temp_buf) = host_to_be16(AP_HT_CAPABILITY_LENGTH);
    temp_buf += 2;
	memcpy(temp_buf, ht_cap->identifier, ETH_ALEN);
	temp_buf += ETH_ALEN;

	*temp_buf = (ht_cap->tx_stream << 6) | (ht_cap->rx_stream << 4) |
		(ht_cap->sgi_20 << 3) | (ht_cap->sgi_40 << 2) | (ht_cap->ht_40 << 1);

    total_length = AP_HT_CAPABILITY_LENGTH + 3;

    return total_length;
}

unsigned short append_ap_vht_capability_tlv(
        unsigned char *pkt, struct ap_vht_cap_db *vht_cap)
{
    unsigned short total_length = 0;
    unsigned char *temp_buf = NULL;

    temp_buf = pkt;

    *temp_buf = AP_VHT_CAPABILITY_TYPE;
    temp_buf += 1;

	*(unsigned short *)(temp_buf) = host_to_be16(AP_VHT_CAPABILITY_LENGTH);
    temp_buf += 2;
	memcpy(temp_buf, vht_cap->identifier, ETH_ALEN);
	temp_buf += ETH_ALEN;
	*(unsigned short *)(temp_buf) = host_to_be16(vht_cap->vht_tx_mcs);
	temp_buf += 2;
	*(unsigned short *)(temp_buf) = host_to_be16(vht_cap->vht_rx_mcs);
	temp_buf += 2;
	*temp_buf = (vht_cap->tx_stream << 5) | (vht_cap->rx_stream << 2) |
		(vht_cap->sgi_80 << 1) | (vht_cap->sgi_160);
	temp_buf++;
	*temp_buf = (vht_cap->vht_8080 << 7) | (vht_cap->vht_160 << 6) |
		(vht_cap->su_beamformer << 5) | (vht_cap->mu_beamformer << 4);

    total_length = AP_VHT_CAPABILITY_LENGTH + 3;

    return total_length;
}
unsigned short append_ap_eht_capability_tlv(
	struct p1905_managerd_ctx *ctx, unsigned char *temp_buf)
{
	unsigned short total_length = 0, len = 0, radio = 0;
	unsigned char *pkt, *radio_num;
	unsigned char mtk_oui[3] = {0x00, 0x0C, 0xE7};
	struct ap_eht_cap_db *eht_cap = NULL;

	*temp_buf = VENDOR_SPECIFIC_TLV_TYPE;
	temp_buf += 1;
	pkt = temp_buf;
	/*tlv length*/
	temp_buf += 2;
	os_memcpy(temp_buf, mtk_oui, sizeof(mtk_oui));
	temp_buf += 3;
	/*function type for mapd parsing*/
	*temp_buf++ = FUNC_VENDOR_EHT_CAP;

	/*fill num of radio*/
	radio_num = temp_buf;
	temp_buf += 1;
	SLIST_FOREACH(eht_cap, &(ctx->ap_cap_entry.ap_eht_cap_head), ap_eht_cap_entry) {
		memcpy(temp_buf, eht_cap->identifier, 6);
		temp_buf += ETH_ALEN;

		*temp_buf++ = eht_cap->tx_stream;
		*temp_buf++ = eht_cap->rx_stream;
		*temp_buf++ = eht_cap->eht_ch_width;
		*temp_buf++ = eht_cap->ccfs0;
		*temp_buf++ = eht_cap->ccfs1;
		radio++;
	}
	len = (unsigned short)(temp_buf - pkt) - 2;
	*((unsigned short *)pkt) = host_to_be16(len);
	*((unsigned short *)radio_num) = radio;
	total_length = len + 3;

	return total_length;
}

unsigned short append_ap_he_capability_tlv(
        unsigned char *pkt, struct ap_he_cap_db *he_cap)
{
    unsigned short total_length = 0;
    unsigned char *temp_buf = NULL;

    temp_buf = pkt;

    *temp_buf++ = AP_HE_CAPABILITY_TYPE;

	*(unsigned short *)(temp_buf) = host_to_be16(9 + he_cap->he_mcs_len);
    temp_buf += 2;
	memcpy(temp_buf, he_cap->identifier, ETH_ALEN);
	temp_buf += ETH_ALEN;

	*temp_buf++ = he_cap->he_mcs_len;
	os_memcpy(temp_buf, he_cap->he_mcs, he_cap->he_mcs_len);
	temp_buf += he_cap->he_mcs_len;
	*temp_buf++ = (he_cap->tx_stream << 5) | (he_cap->rx_stream << 2) |
		(he_cap->he_8080 << 1) | (he_cap->he_160);
	*temp_buf++ = (he_cap->su_bf_cap << 7) | (he_cap->mu_bf_cap << 6) |
		(he_cap->ul_mu_mimo_cap << 5) | (he_cap->ul_mu_mimo_ofdma_cap << 4) |
		(he_cap->dl_mu_mimo_ofdma_cap << 3) | (he_cap->ul_ofdma_cap << 2) |
		(he_cap->dl_ofdma_cap << 1);

    total_length = 12 + he_cap->he_mcs_len;

    return total_length;
}

unsigned short append_client_steering_request_tlv(unsigned char *pkt)
{
    unsigned short total_length = 0;
    unsigned char *temp_buf;
	unsigned char BSSID[6] = {0x00,0x0C,0x43,0x26,0x60,0x98};
	unsigned char TBSSID[6] = {0x00,0x0C,0x43,0x26,0x60,0x60};
	unsigned char STA[6] = {0x38,0xBC,0x1A,0xC1,0xD3,0x40};

    temp_buf = pkt;

    *temp_buf++ = STEERING_REQUEST_TYPE;
	total_length += 1;

	temp_buf += 2;
	total_length += 2;

	memcpy(temp_buf, BSSID, 6);
	temp_buf += 6;
	total_length += 6;

	*temp_buf++ = 0xe0;
	total_length += 1;

	*temp_buf++ = 0x00;
	*temp_buf++ = 0x05;
	total_length += 2;

	/*sta num & sta mac*/
	*temp_buf++ = 1;
	total_length += 1;
	memcpy(temp_buf, STA, 6);
	temp_buf += 6;
	total_length += 6;

	/*bssid num & bssid mac, opclass, channel*/
	*temp_buf++ = 1;
	total_length += 1;
	memcpy(temp_buf, TBSSID, 6);
	temp_buf += 6;
	total_length += 6;
	*temp_buf++ = 115;
	*temp_buf++ = 36;
	total_length += 2;

	/*calculate totoal length & fill into the length field*/
    *(pkt + 1) =  (unsigned char)(((total_length - 3) >> 8) & 0xff);
    *(pkt + 2) =  (unsigned char)((total_length - 3) & 0xff);

    return total_length;
}

unsigned short append_client_steering_btm_report_tlv(unsigned char *pkt,
	struct cli_steer_btm_event *btm_evt)
{
    unsigned short total_length = 0;
    unsigned char *temp_buf;
	unsigned char zero_bssid[ETH_ALEN] = {0};

    temp_buf = pkt;

    *temp_buf++ = STEERING_BTM_REPORT_TYPE;
	total_length += 1;

	temp_buf += 2;
	total_length += 2;

	memcpy(temp_buf, btm_evt->bssid, ETH_ALEN);
	temp_buf += ETH_ALEN;
	total_length += ETH_ALEN;

	memcpy(temp_buf, btm_evt->sta_mac, ETH_ALEN);
	temp_buf += ETH_ALEN;
	total_length += ETH_ALEN;

	*temp_buf++ = btm_evt->status;
	total_length += 1;

	if (memcmp(zero_bssid, btm_evt->tbssid, ETH_ALEN)) {
		memcpy(temp_buf, btm_evt->tbssid, ETH_ALEN);
		temp_buf += ETH_ALEN;
		total_length += ETH_ALEN;
	}

	/*calculate totoal length & fill into the length field*/
	*(unsigned short *)(pkt+1) = host_to_be16(total_length - 3);

    return total_length;
}

unsigned short append_map_policy_config_request_tlv(unsigned char *pkt)
{
	unsigned short total_length = 0;
	unsigned char *temp_buf;
	unsigned char BSSID[ETH_ALEN] = {0x00,0x0C,0x43,0x26,0x60,0x98};

	temp_buf = pkt;

	*temp_buf++ = STEERING_POLICY_TYPE;
	total_length += 1;

	temp_buf += 2;
	total_length += 2;

	*temp_buf++ = 0;
	total_length += 1;

	*temp_buf++ = 0;
	total_length += 1;

	*temp_buf++ = 1;
	total_length += 1;
	memcpy(temp_buf, BSSID, ETH_ALEN);
	temp_buf += ETH_ALEN;
	total_length += ETH_ALEN;
	*temp_buf++ = 0x01;
	*temp_buf++ = 0xff;
	*temp_buf++ = 20;
	total_length += 3;

	/*calculate totoal length & fill into the length field*/
	*(unsigned short *)(pkt+1) = host_to_be16(total_length - 3);

	return total_length;
}

unsigned short append_cli_assoc_cntrl_request_tlv(unsigned char *pkt)
{
	unsigned short total_length = 0;
	unsigned char *temp_buf;
	unsigned char BSSID[ETH_ALEN] = {0x00,0x0C,0x43,0x26,0x60,0x98};
	unsigned char STA[ETH_ALEN] = {0x38,0xBC,0x1A,0xC1,0xD3,0x40};

	temp_buf = pkt;

	*temp_buf++ = CLI_ASSOC_CONTROL_REQUEST_TYPE;
	total_length += 1;

	temp_buf += 2;
	total_length += 2;

	memcpy(temp_buf, BSSID, ETH_ALEN);
	temp_buf += ETH_ALEN;
	total_length += ETH_ALEN;

	*temp_buf++ = 0;
	total_length += 1;

	*temp_buf++ = 0;
	*temp_buf++ = 30;
	total_length += 2;

	*temp_buf++ = 1;
	total_length += 1;

	memcpy(temp_buf, STA, ETH_ALEN);
	temp_buf += ETH_ALEN;
	total_length += ETH_ALEN;


	/*calculate totoal length & fill into the length field*/
	*(unsigned short *)(pkt+1) = host_to_be16(total_length - 3);

	return total_length;
}

unsigned short append_channel_preference_tlv(unsigned char *pkt,
	struct ch_prefer_db *prefer_db)
{
	unsigned short total_length = 0;
	unsigned char *temp_buf;
	struct prefer_info_db *prefer_info = NULL;

	temp_buf = pkt;

  /*firstly shift to tlv value*/
	temp_buf += 3;
	total_length += 3;

	memcpy(temp_buf, prefer_db->identifier, ETH_ALEN);
	temp_buf += ETH_ALEN;
	total_length += ETH_ALEN;

	*temp_buf++ = prefer_db->op_class_num;
	total_length += 1;
	if (!SLIST_EMPTY(&prefer_db->prefer_info_head)) {
		SLIST_FOREACH(prefer_info, &prefer_db->prefer_info_head, prefer_info_entry)
		{
			/*operating class*/
			*temp_buf++ = prefer_info->op_class;
			total_length += 1;
			/*channel num*/
			*temp_buf++ = prefer_info->ch_num;
			total_length += 1;
			/*channel list*/
			if (prefer_info->ch_num) {
				memcpy(temp_buf, prefer_info->ch_list, prefer_info->ch_num);
				temp_buf += prefer_info->ch_num;
				total_length += prefer_info->ch_num;
			}
			/*preference & reason*/
			*temp_buf++ = (prefer_info->perference << 4) | prefer_info->reason;
			total_length += 1;
		}
	} else {
		err(DEBUG_CAT_MSG, "prefer_info_head is empty for radio "MACSTR"\n",
			MAC2STR(prefer_db->identifier));
		return 0;
	}

	/*if really has the p1905.1 neighbor device, append type & length */
	*pkt = CH_PREFERENCE_TYPE;
	*(unsigned short *)(pkt+1) = host_to_be16(total_length - 3);

	return total_length;
}

unsigned short append_transmit_power_limit_tlv(unsigned char *pkt,
	unsigned char *identifier, signed char tx_power_limit)
{
	unsigned short total_length = 0;
	unsigned char *temp_buf;

	temp_buf = pkt;

	*temp_buf++ = TRANSMIT_POWER_LIMIT_TYPE;
	total_length += 1;

	*(unsigned short *)(temp_buf) = host_to_be16(TRANSMIT_POWER_LIMIT_LENGTH);
	temp_buf += 2;
	total_length += 2;

	memcpy(temp_buf, identifier, ETH_ALEN);
	temp_buf += ETH_ALEN;
	total_length += ETH_ALEN;

	*temp_buf++ = tx_power_limit;
	total_length += 1;

	return total_length;
}

unsigned short append_channel_selection_response_tlv(unsigned char *pkt,
	struct ch_stat_info *stat)
{
	unsigned short total_length = 0;
    unsigned char *temp_buf;

	temp_buf = pkt;

	*temp_buf = CH_SELECTION_RESPONSE_TYPE;
    temp_buf += 1;
	total_length += 1;

	temp_buf += 2;
	total_length += 2;

	memcpy(temp_buf, stat->identifier, ETH_ALEN);
	temp_buf += ETH_ALEN;
	total_length += ETH_ALEN;

	*temp_buf = stat->code;
	temp_buf += 1;
	total_length += 1;

	/*calculate totoal length & fill into the length field*/
	*(unsigned short *)(pkt+1) = host_to_be16(total_length - 3);

	return total_length;
}

unsigned short append_operating_channel_report_tlv(unsigned char *pkt,
	struct ch_rep_info *rep_info)
{
	unsigned short total_length = 0;
	unsigned char *temp_buf;

	temp_buf = pkt;

	*temp_buf = OPERATING_CHANNEL_REPORT_TYPE;
	temp_buf += 1;
	total_length += 1;

	temp_buf += 2;
	total_length += 2;

	memcpy(temp_buf, rep_info->identifier, ETH_ALEN);
	temp_buf += ETH_ALEN;
	total_length += ETH_ALEN;

	*temp_buf = 1;
	temp_buf += 1;
	total_length += 1;

	*temp_buf = rep_info->op_class;
	temp_buf += 1;
	total_length += 1;

	*temp_buf = rep_info->channel;
	temp_buf += 1;
	total_length += 1;

	*temp_buf = rep_info->tx_power;
	temp_buf += 1;
	total_length += 1;

	/*calculate totoal length & fill into the length field*/
	*(unsigned short *)(pkt+1) = host_to_be16(total_length - 3);

	return total_length;
}

unsigned short append_operating_channel_report_tlv_bw80(unsigned char *pkt,
	struct ch_rep_info *rep_info)
{
	unsigned short total_length = 0;
	unsigned char *temp_buf;

	temp_buf = pkt;

	*temp_buf = OPERATING_CHANNEL_REPORT_TYPE;
	temp_buf += 1;
	total_length += 1;

	temp_buf += 2;
	total_length += 2;

	memcpy(temp_buf, rep_info->identifier, ETH_ALEN);
	temp_buf += ETH_ALEN;
	total_length += ETH_ALEN;

	*temp_buf = 2;
	temp_buf += 1;
	total_length += 1;

	*temp_buf = rep_info->op_class;
	temp_buf += 1;
	total_length += 1;

	*temp_buf = rep_info->channel;
	temp_buf += 1;
	total_length += 1;

	/*primary channel*/
	rep_info++;
	*temp_buf = rep_info->op_class;
	temp_buf += 1;
	total_length += 1;

	*temp_buf = rep_info->channel;
	temp_buf += 1;
	total_length += 1;

	if (rep_info->op_class == 128 || rep_info->op_class == 129
#ifdef MAP_6E_SUPPORT
			|| rep_info->op_class == 132
			|| rep_info->op_class == 133
			|| rep_info->op_class == 134
			|| rep_info->op_class == 137
#endif
		) {
		rep_info--;
		*temp_buf = rep_info->tx_power;
	} else {
		*temp_buf = rep_info->tx_power;
	}
	temp_buf += 1;
	total_length += 1;

	/*calculate totoal length & fill into the length field*/
	*(unsigned short *)(pkt+1) = host_to_be16(total_length - 3);

	return total_length;
}

int append_operational_bss_tlv(struct p1905_managerd_ctx *ctx,
	unsigned char *pkt,
	struct list_head_oper_bss *opbss_head)
{
	unsigned short total_length = 0;
	unsigned char *temp_buf;
	int radio_num = 0;
	unsigned char exist = 0;
	struct op_bss_db *bss_info = NULL;
	struct operational_bss_db *operbss_info = NULL;

	temp_buf = pkt;

  /*firstly shift to tlv value*/
	temp_buf += 3;
	total_length += 3;

	temp_buf += 1;
	total_length += 1;

	if(!SLIST_EMPTY(opbss_head)) {
		SLIST_FOREACH(operbss_info, opbss_head, oper_bss_entry)
		{
			exist = 1;
			radio_num++;
			memcpy(temp_buf, operbss_info->identifier, ETH_ALEN);
			temp_buf += ETH_ALEN;
			total_length += ETH_ALEN;

			*temp_buf = operbss_info->oper_bss_num;
			temp_buf += 1;
			total_length += 1;
			if (!SLIST_EMPTY(&operbss_info->op_bss_head)) {
				SLIST_FOREACH(bss_info, &operbss_info->op_bss_head, op_bss_entry)
				{
					memcpy(temp_buf, bss_info->bssid, ETH_ALEN);
					temp_buf += ETH_ALEN;
					total_length += ETH_ALEN;
					*temp_buf = bss_info->ssid_len;
					temp_buf += 1;
					total_length += 1;
					memcpy(temp_buf, bss_info->ssid, bss_info->ssid_len);
					temp_buf += bss_info->ssid_len;
					total_length += bss_info->ssid_len;
				}
			} else {
				if (ctx->disable_tear_down || !operbss_info->oper_bss_num) {
					radio_num--;
					temp_buf -= (ETH_ALEN+1);
					total_length -= (ETH_ALEN+1);
				}
			}
		 }
	 }

	/*if really has the p1905.1 neighbor device, append type & length */
	if(exist) {
		(*pkt) = AP_OPERATIONAL_BSS_TYPE;
		*(unsigned short *)(pkt+1) = host_to_be16(total_length - 3);
		*(pkt + 3) = radio_num;
		return total_length;
	} else {
		return 0;
	}

}

int append_associated_clients_tlv(unsigned char *pkt,
	struct list_head_assoc_clients *asscli_head)
{
	unsigned short total_length = 0;
	unsigned char *temp_buf = NULL;
	int bss_num = 0, cli_num = 0;
	unsigned char bss_exist = 0;
	struct clients_db *clis_info = NULL;
	struct associated_clients_db *assc_clis_info = NULL;
	unsigned short time = 0;
	struct os_reltime current_time;

	temp_buf = pkt;

  /*firstly shift to tlv value*/
	temp_buf += 3;
	total_length += 3;

	temp_buf += 1;
	total_length += 1;

	if(!SLIST_EMPTY(asscli_head)) {
		SLIST_FOREACH(assc_clis_info, asscli_head, assoc_clients_entry)
		{
			bss_exist = 1;
			bss_num++;
			memcpy(temp_buf, assc_clis_info->bssid, ETH_ALEN);
			temp_buf += ETH_ALEN;
			total_length += ETH_ALEN;
			*(unsigned short *)(temp_buf) = host_to_be16(assc_clis_info->assco_clients_num);
			temp_buf += 2;
			total_length += 2;

			if (!SLIST_EMPTY(&assc_clis_info->clients_head)) {
				cli_num = 0;
				SLIST_FOREACH(clis_info, &assc_clis_info->clients_head, clients_entry)
				{
					cli_num++;
					memcpy(temp_buf, clis_info->mac, ETH_ALEN);
					temp_buf += ETH_ALEN;
					total_length += ETH_ALEN;

					os_get_reltime(&current_time);
					if ((current_time.sec - clis_info->time) > 65534)
						time = 65535;
					else
						time = (unsigned short)(current_time.sec - clis_info->time);
					*(unsigned short *)(temp_buf) = host_to_be16(time);
					temp_buf += 2;
					total_length += 2;
				}
				if (cli_num != assc_clis_info->assco_clients_num) {
					err(DEBUG_CAT_MSG, "drop tlv; assco_clients_num mismatch; cli_num=%d, assco_clients_num=%d\n",
						cli_num, assc_clis_info->assco_clients_num);
					return 0;
				}
			} else {
				continue;
			}
		 }
	 }

	/*if really has the p1905.1 neighbor device, append type & length */
	if(bss_exist) {
		(*pkt) = AP_ASSOCIATED_CLIENTS_TYPE;
		*(unsigned short *)(pkt+1) = host_to_be16(total_length - 3);
		*(pkt + 3) = bss_num;
		return total_length;
	} else {
		return 0;
	}
}



int append_client_assoc_event_tlv(unsigned char *pkt,
		struct map_client_association_event *assoc_evt)
{
	unsigned short total_length = 0;
	unsigned char *temp_buf = NULL;

	*pkt++ = CLIENT_ASSOCIATION_EVENT_TYPE;
	total_length += 1;

	*(unsigned short *)(pkt) = host_to_be16(CLIENT_ASSOCIATION_EVENT_LENGTH);
	pkt += 2;
	total_length += 2;

	temp_buf = pkt;
	memcpy(temp_buf, assoc_evt->sta_mac, ETH_ALEN);
	temp_buf += ETH_ALEN;
	memcpy(temp_buf, assoc_evt->bssid, ETH_ALEN);
	temp_buf += ETH_ALEN;
	*temp_buf = assoc_evt->assoc_evt;

	total_length += CLIENT_ASSOCIATION_EVENT_LENGTH;
	return total_length;
}

int append_cli_info_tlv(unsigned char *pkt,
		struct client_info *info)
{
	unsigned short total_length = 0;
	unsigned char *temp_buf = NULL;

	*pkt = CLIENT_INFO_TYPE;
	total_length += 1;

	*(unsigned short *)(pkt+1) = host_to_be16(CLIENT_INFO_LENGTH);
	total_length += 2;

	temp_buf = pkt + 3;

	memcpy(temp_buf, info->bssid, ETH_ALEN);
	temp_buf += ETH_ALEN;
	memcpy(temp_buf, info->sta_mac, ETH_ALEN);
	temp_buf += ETH_ALEN;

	total_length += CLIENT_INFO_LENGTH;
	return total_length;
}

int append_cli_capability_report_tlv(struct p1905_managerd_ctx* ctx, unsigned char *pkt,
		int *error_code)
{
	unsigned short total_length = 0;
	unsigned short length = 1;
	unsigned char *temp_buf = NULL;
	struct associated_clients_db* pbss_db = NULL;
	struct clients_db* sta_db = NULL;

	*pkt = CLIENT_CAPABILITY_REPORT_TYPE;
	total_length += 1;

	SLIST_FOREACH(pbss_db, &(ctx->ap_cap_entry.assoc_clients_head), assoc_clients_entry)
	{
		SLIST_FOREACH(sta_db, &(pbss_db->clients_head), clients_entry)
		{
			if(!memcmp(sta_db->mac, ctx->sinfo.cinfo.sta_mac, ETH_ALEN))
			{
				break;
			}
		}
		if(sta_db != NULL)
		{
			break;
		}
	}
	temp_buf = pkt + 3;
	if(!sta_db)
	{
		*temp_buf = 0x01;
		*error_code = 0x02; /*STA not associated with any BSS operated by the Multi-AP Agent*/
		total_length += 1;
	}
	else
	{
		*temp_buf = 0x00;
		total_length += 1;
		temp_buf += 1;

		memcpy(temp_buf, sta_db->frame, sta_db->frame_len);
		total_length += sta_db->frame_len;
		length += sta_db->frame_len;
	}

	*(unsigned short *)(pkt+1) = host_to_be16(length);
	total_length += 2;

	return total_length;
}


#ifdef MAP_R4_SPT
unsigned short append_spatial_report_tlv(unsigned char *pkt,
	struct ap_spt_reuse_resp *rep_info)
{
	unsigned short total_length = 0;
	unsigned char *temp_buf;

	temp_buf = pkt;

	*temp_buf = SPATIAL_REUSE_REPORT_TYPE;
	temp_buf += 1;
	total_length += 1;

	temp_buf += 2;
	total_length += 2;

	memcpy(temp_buf, rep_info->identifier, ETH_ALEN);
	temp_buf += ETH_ALEN;
	total_length += ETH_ALEN;

	*temp_buf = (rep_info->partial_bss_color ? 0x40:0) | (rep_info->bss_color & 0x3F);
	temp_buf += 1;
	total_length += 1;

	*temp_buf = (rep_info->hesiga_spa_reuse_val_allowed? 0x10:0)|
				(rep_info->srg_info_valid? 0x08:0)|
				(rep_info->nonsrg_offset_valid? 0x04:0)|
				(rep_info->psr_disallowed? 0x01:0);
	temp_buf += 1;
	total_length += 1;

	if(rep_info->nonsrg_offset_valid)
	{
		*temp_buf = rep_info->nonsrg_obsspd_max_offset;
	}
	temp_buf += 1;
	total_length += 1;

	if(rep_info->srg_info_valid)
	{
		*temp_buf = rep_info->srg_obsspd_min_offset;
		temp_buf += 1;
		total_length += 1;

		*temp_buf = rep_info->srg_obsspd_max_offset;
		temp_buf += 1;
		total_length += 1;

		memcpy(temp_buf, rep_info->srg_bss_color_bitmap, 8);
		temp_buf += 8;
		total_length += 8;

		memcpy(temp_buf, rep_info->srg_partial_bssid_bitmap, 8);
		temp_buf += 8;
		total_length += 8;
	}
	else
	{
		temp_buf += 18;
		total_length += 18;
	}

	memcpy(temp_buf, rep_info->ngh_bss_color_in_bitmap, 8);
	temp_buf += 8;
	total_length += 8;

	*temp_buf = 0;
	temp_buf += 1;
	*temp_buf = 0;
	temp_buf += 1;

	total_length += 2;

	/*calculate totoal length & fill into the length field*/
	*(unsigned short *)(pkt+1) = host_to_be16(total_length - 3);

	return total_length;
}
#endif

int append_error_code_tlv(struct p1905_managerd_ctx* ctx, unsigned char *pkt,
		int error_code, unsigned char *mac)
{
	*pkt++ = ERROR_CODE_TYPE;

	*(unsigned short *)pkt = host_to_be16(ERROR_CODE_TLV_LENGTH);
	pkt += 2;

	*pkt++ = error_code;

	memcpy(pkt, mac, ETH_ALEN);

	return ERROR_CODE_TLV_LENGTH + 3;
}

int append_reason_code_tlv(unsigned char *pkt,unsigned short reason)
{
	unsigned short total_length = 0;
	unsigned char *temp_buf = NULL;

	temp_buf= pkt;
	*temp_buf++ = REASON_CODE_TYPE;

	*(unsigned short *)(temp_buf) = host_to_be16(2);
	temp_buf += 2;

	memcpy(temp_buf, &reason, 2);
	temp_buf += 2;

	total_length = (temp_buf - pkt);
	return total_length;
}

unsigned short append_sta_unlink_metrics_response_tlv(
        unsigned char *pkt, struct unlink_metrics_info *metrics)
{
    unsigned short total_length = 0;
    unsigned char *temp_buf;
	struct unlink_metrics_db *unlink_metrics = NULL;

    temp_buf = pkt;

    *temp_buf++ = UNASSOC_STA_LINK_METRICS_RSP_TYPE;
	total_length += 1;

    temp_buf += 2;
	total_length += 2;

	/*Operating Class*/
	*temp_buf++ = metrics->oper_class;
	total_length += 1;

	/*STA number*/
	*temp_buf++ = metrics->sta_num;
	total_length += 1;

	SLIST_FOREACH(unlink_metrics, &metrics->unlink_metrics_head, unlink_metrics_entry)
    {
    	/*sta mac*/
    	memcpy(temp_buf, unlink_metrics->mac, ETH_ALEN);
		temp_buf += ETH_ALEN;
		total_length += ETH_ALEN;

		/*channel*/
		*temp_buf++ = unlink_metrics->ch;
		total_length += 1;

		/*TimeDelta*/
		*(unsigned int *)(pkt+1) = host_to_be32(unlink_metrics->time_delta);
		temp_buf += 4;
		total_length += 4;

		/*Measured Uplink RSSI*/
		*temp_buf++ = unlink_metrics->uplink_rssi & 0xff;
		total_length += 1;
	}

	/*calculate totoal length & fill into the length field*/
	*(unsigned short *)(pkt+1) = host_to_be16(total_length - 3);

    return total_length;
}

unsigned short append_beacon_metrics_response_tlv(
        unsigned char *pkt, struct beacon_metrics_rsp *beacon_rsp)
{
    unsigned short total_length = 0;
    unsigned char *temp_buf;

    temp_buf = pkt;

    *temp_buf++ = BEACON_METRICS_RESPONSE_TYPE;
	total_length += 1;

    temp_buf += 2;
	total_length += 2;

	/*MAC address of the associated STA for which the Beacon report information is requested*/
	memcpy(temp_buf, beacon_rsp->sta_mac, ETH_ALEN);
	temp_buf += ETH_ALEN;
	total_length += ETH_ALEN;

	/*reserved field*/
	*temp_buf++ = beacon_rsp->reserved;
	total_length += 1;

	/*Number of measurement report elements*/
	*temp_buf++ = beacon_rsp->bcn_rpt_num;
	total_length += 1;
	memcpy(temp_buf, beacon_rsp->rpt, beacon_rsp->rpt_len);
	total_length += beacon_rsp->rpt_len;


	/*calculate totoal length & fill into the length field*/
	*(unsigned short *)(pkt+1) = host_to_be16(total_length - 3);

    return total_length;
}

unsigned short append_backhaul_steer_response_tlv(
		unsigned char *pkt, struct backhaul_steer_rsp *steer_rsp)
{
	unsigned short total_length = 0;
	unsigned char *temp_buf;

	temp_buf = pkt;

	*temp_buf++ = BACKHAUL_STEERING_RESPONSE_TYPE;
	total_length += 1;

	*(unsigned short *)(temp_buf) = host_to_be16(BACKHAUL_STEERING_RESPONSE_LENGTH);
	temp_buf += 2;
	total_length += 2;

	memcpy(temp_buf, steer_rsp->backhaul_mac, ETH_ALEN);
	temp_buf += ETH_ALEN;
	total_length += ETH_ALEN;

	memcpy(temp_buf, steer_rsp->target_bssid, ETH_ALEN);
	temp_buf += ETH_ALEN;
	total_length += ETH_ALEN;

	*temp_buf++ = steer_rsp->status;
	total_length += 1;

	return total_length;
}

unsigned short append_tx_link_metric_tlv(
        unsigned char *pkt, struct tx_link_metric_db *tx_link_metric)
{
    unsigned short total_length = 0;
    unsigned char *temp_buf;
	struct tx_metric_db *tx_metric = NULL;

    temp_buf = pkt;

    *temp_buf = TRANSMITTER_LINK_METRIC_TYPE;
    temp_buf +=1;
    total_length += 1;

    /* The length of tx link metric tlv is a variable.
     * It depends on connetced interface number, shift to payload first
     */
    temp_buf +=2;
    total_length += 2;

    /*fill into local abstration layer mac addr*/
    memcpy(temp_buf, tx_link_metric->almac, ETH_ALEN);
    temp_buf += ETH_ALEN;
    total_length += ETH_ALEN;

    /*fill into neighbor abstration layer mac addr*/
    memcpy(temp_buf, tx_link_metric->nalmac, ETH_ALEN);
    temp_buf += ETH_ALEN;
    total_length += ETH_ALEN;

    SLIST_FOREACH(tx_metric, &tx_link_metric->tx_metric_head, tx_metric_entry)
    {
		/*fill into local interface mac addr*/
		memcpy(temp_buf, tx_metric->mac, ETH_ALEN);
		temp_buf += ETH_ALEN;
		total_length += ETH_ALEN;
		/*fill into neighbor interface mac addr*/
		memcpy(temp_buf, tx_metric->nmac, ETH_ALEN);
		temp_buf += ETH_ALEN;
		total_length += ETH_ALEN;
		/*fill into interface media type*/
		*(unsigned short *)(temp_buf) = host_to_be16(tx_metric->intf_type);
		temp_buf += 2;
		total_length += 2;
		/*fill into bridge flag*/
		*temp_buf = tx_metric->bridge_flag;
		temp_buf += 1;
		total_length += 1;
		/*fill into tx packets error*/
		*(unsigned int *)(temp_buf) = host_to_be32(tx_metric->error_packet);
		temp_buf += 4;
		total_length += 4;
		/*fill into total transmitted packets*/
		*(unsigned int *)(temp_buf) = host_to_be32(tx_metric->tx_packets);
		temp_buf += 4;
		total_length += 4;
		/*fill into max throughput capability*/
		*(unsigned short *)(temp_buf) = host_to_be16(tx_metric->mac_tpcap);
		temp_buf += 2;
		total_length += 2;
		/*fill into link availability field */
		*(unsigned short *)(temp_buf) = host_to_be16(tx_metric->linkavl);
		temp_buf += 2;
		total_length += 2;
		/* fill into phy rate*/
		*(unsigned short *)(temp_buf) = host_to_be16(tx_metric->phyrate);
		temp_buf += 2;
		total_length += 2;
    }

    /*calculate totoal length & fill into the length field*/
	*(unsigned short *)(pkt+1) = host_to_be16(total_length - 3);

    return total_length;
}

unsigned short append_rx_link_metric_tlv(
        unsigned char *pkt, struct rx_link_metric_db *rx_link_metric)
{
    unsigned short total_length = 0;
    unsigned char *temp_buf;
	struct rx_metric_db *rx_metric = NULL;

    temp_buf = pkt;

    *temp_buf = RECEIVER_LINK_METRIC_TYPE;
    temp_buf +=1;
    total_length += 1;

    /* The length of rx link metric tlv is a variable.
     * It depends on connetced interface number, shift to payload first
     */
    temp_buf +=2;
    total_length += 2;

    /*fill into local abstration layer mac addr*/
    memcpy(temp_buf, rx_link_metric->almac, ETH_ALEN);
    temp_buf += ETH_ALEN;
    total_length += ETH_ALEN;

    /*fill into neighbor abstration layer mac addr*/
    memcpy(temp_buf, rx_link_metric->nalmac, ETH_ALEN);
    temp_buf += ETH_ALEN;
    total_length += ETH_ALEN;

    SLIST_FOREACH(rx_metric, &rx_link_metric->rx_metric_head, rx_metric_entry)
    {
		/*fill into local interface mac addr*/
		memcpy(temp_buf, rx_metric->mac, ETH_ALEN);
		temp_buf += ETH_ALEN;
		total_length += ETH_ALEN;
		/*fill into neighbor interface mac addr*/
		memcpy(temp_buf, rx_metric->nmac, ETH_ALEN);
		temp_buf += ETH_ALEN;
		total_length += ETH_ALEN;
		/*fill into interface media type*/
		*(unsigned short *)(temp_buf) = host_to_be16(rx_metric->intf_type);
		temp_buf += 2;
		total_length += 2;
		/*fill into rx packets error*/
		*(unsigned int *)(temp_buf) = host_to_be32(rx_metric->error_packet);
		temp_buf += 4;
		total_length += 4;
		/*fill into total received packets*/
		*(unsigned int *)(temp_buf) = host_to_be32(rx_metric->rx_packets);
		temp_buf += 4;
		total_length += 4;
		/* fill rssi*/
		*temp_buf = rx_metric->rssi;
		temp_buf += 1;
		total_length += 1;
    }

    /*calculate totoal length & fill into the length field*/
	*(unsigned short *)(pkt+1) = host_to_be16(total_length - 3);

    return total_length;
}

void build_ap_metric_query_tlv(struct p1905_managerd_ctx *ctx)
{
	unsigned char buf[512] = {0}, bssid[512] = {0};
	unsigned char i = 0, j = 0, bssid_num = 0;
	unsigned short length = 0;
	unsigned char *pos = buf, *bss_pos = bssid;

#ifdef MAP_R2
	struct radio_identifier_db *p_tmp = NULL;

	unsigned char identifier[512] = {0};
	unsigned char id_total_len = 0;
	unsigned char *identifier_pos = identifier;
#endif
	reset_stored_tlv(ctx);

	for (i = 0; i < MAX_RADIO_NUM; i++) {
		for (j = 0; j < ctx->rinfo[i].bss_number; j++) {
			if (ctx->rinfo[i].bss[j].config_status) {
				memcpy(bss_pos, ctx->rinfo[i].bss[j].mac, ETH_ALEN);
				bss_pos += ETH_ALEN;
				bssid_num++;
			}
		}
	}

	/*tlvType*/
	*pos++ = AP_METRICS_QUERY_TYPE;
	/*tlvLength*/
	length = 1 + ETH_ALEN * bssid_num;
	*(unsigned short *)(pos) = host_to_be16(length);
	pos += 2;
	/*Number of BSSIDs included in this TLV*/
	*pos++ = bssid_num;
	/*BSSID of a BSS*/
	memcpy(pos, bssid, length-1);

	store_revd_tlvs(ctx, buf, length + 3);
#ifdef MAP_R2
	/* Zero or more AP Radio Identifier TLVs */
	if(!SLIST_EMPTY(&ctx->metric_entry.radio_identifier_head))
	{
		p_tmp = SLIST_FIRST(&ctx->metric_entry.radio_identifier_head);
		while (p_tmp)
		{
			/*tlvType*/
			*identifier_pos++ = AP_RADIO_IDENTIFIER_TYPE;
			/*tlvLength*/
			length = ETH_ALEN;
			*(unsigned short *)(identifier_pos) = host_to_be16(length);
			identifier_pos += 2;
			/*radio identifier*/
			memcpy(identifier_pos, p_tmp->identifier, ETH_ALEN);

			id_total_len += (length + 3);
			identifier_pos += ETH_ALEN;
			p_tmp = SLIST_NEXT(p_tmp, radio_identifier_entry);
		}
	}
	store_revd_tlvs(ctx, identifier, id_total_len);
#endif // MAP_R2
}

unsigned short create_vs_info_for_specific_discovery(unsigned char *vs_info)
{
	/*1905 internal using vendor specific tlv format
	   type			1 byte			0x0b
	   length			2 bytes			0x, 0x
	   oui			3 bytes			0x00, 0x0C, 0xE7
	   function type	1 byte			0xff
	   suboui			3 bytes			0x00, 0x0C, 0xE7
	   sub func type	1 byte			0x
	*/
	unsigned char *p = vs_info;
	unsigned short len = 0;
	unsigned char mtk_oui[3] = {0x00, 0x0C, 0xE7};

	/*vendor specific tlv type*/
	*p++ = 11;

	/*vendor specific tlv length*/
	*((unsigned short*)p) = host_to_be16(8);
	p += 2;

	/*oui*/
	os_memcpy(p, mtk_oui, sizeof(mtk_oui));
	p += 3;

	/*function type*/
	*p++ = 0xff;

	/*additional OUI*/
	os_memcpy(p, mtk_oui, sizeof(mtk_oui));
	p += 3;

	/*1905 internal used vendor specific subtype*/
	*p++ = internal_vendor_discovery_message_subtype;

	len = (unsigned short)(p - vs_info);

	return len;
}

unsigned short create_vs_info_for_specific_notification(
		struct p1905_managerd_ctx *ctx, unsigned char *vs_info)
{
	/*1905 internal using vendor specific tlv format
	   type 		1 byte			0x11
	   length			2 bytes 		0x, 0x
	   oui			3 bytes 		0x00, 0x0C, 0xE7
	   function type	1 byte			0xff
	   suboui			3 bytes 		0x00, 0x0C, 0xE7
	   sub func type	1 byte			0x01
	   sub len			2 byte
	   sub value		n byte
	*/
	unsigned char *p = vs_info;
	unsigned short len = 0;
	unsigned char mtk_oui[3] = {0x00, 0x0C, 0xE7};

	/*vendor specific tlv type*/
	*p++ = 11;

	/*vendor specific tlv length*/
	*((unsigned short*)p) = host_to_be16(16);
	p += 2;

	/*oui*/
	os_memcpy(p, mtk_oui, sizeof(mtk_oui));
	p += 3;

	/*function type*/
	*p++ = 0xff;

	/*additional OUI*/
	os_memcpy(p, mtk_oui, sizeof(mtk_oui));
	p += 3;

	/*1905 internal used vendor specific subtype*/
	*p++ = internal_vendor_notification_message_subtype;
	*((unsigned short*)p) = host_to_be16(ETH_ALEN);
	p += 2;
	os_memcpy(p, ctx->send_tlv, ETH_ALEN);
	p += ETH_ALEN;

	len = (unsigned short)(p - vs_info);

	return len;
}

int append_map_version_tlv(unsigned char *pkt, unsigned char version)
{
	unsigned char *temp_buf = NULL;
	unsigned short total_length = 0;

	temp_buf = pkt;
	total_length = 4;
	(*temp_buf) = MULTI_AP_VERSION_TYPE;
	*(unsigned short *)(temp_buf+1) = host_to_be16(total_length-3);
	*(temp_buf+3) = version;

	return total_length;
}

unsigned short append_wts_content_vendor_tlv(unsigned char *pkt,
	FILE *f, int offset, int size)
{
	/*1905 internal using vendor specific tlv format
	   type			1 byte			0x11
	   length			2 bytes			0x, 0x
	   oui			3 bytes			0x00, 0x0C, 0xE7
	   function type	1 byte			0xff
	   suboui			3 bytes			0x00, 0x0C, 0xE7
	   sub func type	1 byte			0x
	*/
	unsigned char *p = pkt;
	unsigned short count = 0;
	unsigned char mtk_oui[3] = {0x00, 0x0C, 0xE7};
	int ret = 0;

	/*vendor specific tlv type*/
	*p++ = VENDOR_SPECIFIC_TLV_TYPE;

	/*vendor specific tlv length*/
	*((unsigned short*)(p)) = host_to_be16(8 + size);
	p += 2;

	/*oui*/
	os_memcpy(p, mtk_oui, sizeof(mtk_oui));
	p += 3;

	/*function type*/
	*p++ = 0xff;

	/*additional OUI*/
	os_memcpy(p, mtk_oui, sizeof(mtk_oui));
	p += 3;

	/*1905 internal used vendor specific subtype*/
	*p++ = internal_vendor_wts_content_message_subtype;

	/*add content*/
	errno = 0;
	ret = fseek(f, offset, SEEK_SET);
	if (ret) {
		err(DEBUG_CAT_MSG, "fseek fail!; offset=%d; errno=%d(%s)\n",
			offset, errno, strerror(errno));
		return 0;
	}

	errno = 0;
    count = fread(p, 1, size, f);
	if (count != size) {
		err(DEBUG_CAT_MSG, "fread error; count=%d!=size=%d; errno=%d(%s)\n",
			count, size, errno, strerror(errno));
		return 0;
	}

	return 11 + count;
}

unsigned short append_bss_prio_vendor_tlv(unsigned char *pkt,
	unsigned char *str, unsigned short str_len)
{
	/*1905 internal using vendor specific tlv format
	 * type			1 byte			0x11
	 * length			2 bytes			0x, 0x
	 *oui			3 bytes			0x00, 0x0C, 0xE7
	 *function type	1 byte			0xff
	 *suboui			3 bytes			0x00, 0x0C, 0xE7
	 *sub func type	1 byte			0x
	*/
	unsigned char *p = pkt;
	unsigned char mtk_oui[3] = {0x00, 0x0C, 0xE7};

	/*vendor specific tlv type*/
	*p++ = VENDOR_SPECIFIC_TLV_TYPE;

	/*vendor specific tlv length*/
	*((unsigned short *)(p)) = host_to_be16(8 + str_len + 2);
	p += 2;

	/*oui*/
	os_memcpy(p, mtk_oui, sizeof(mtk_oui));
	p += 3;

	/*function type*/
	*p++ = 0xff;

	/*additional OUI*/
	os_memcpy(p, mtk_oui, sizeof(mtk_oui));
	p += 3;

	/*1905 internal used vendor specific subtype*/
	*p++ = internal_vendor_bss_prio_message_subtype;

	*((unsigned short *)(p)) = host_to_be16(str_len);
	p += 2;

	os_memcpy(p, str, str_len);

	return 11 + str_len + 2;
}

unsigned short append_bss_prio_ack_vendor_tlv(unsigned char *pkt)
{
	/*1905 internal using vendor specific tlv format
	 * type			1 byte			0x11
	 * length			2 bytes			0x, 0x
	 *oui			3 bytes			0x00, 0x0C, 0xE7
	 *function type	1 byte			0xff
	 *suboui			3 bytes			0x00, 0x0C, 0xE7
	 *sub func type	1 byte			0x
	*/

	unsigned char *p = pkt;
	unsigned char mtk_oui[3] = {0x00, 0x0C, 0xE7};

	/*vendor specific tlv type*/
	*p++ = VENDOR_SPECIFIC_TLV_TYPE;

	/*vendor specific tlv length*/
	*((unsigned short *)(p)) = host_to_be16(8);
	p += 2;

	/*oui*/
	os_memcpy(p, mtk_oui, sizeof(mtk_oui));
	p += 3;

	/*function type*/
	*p++ = 0xff;

	/*additional OUI*/
	os_memcpy(p, mtk_oui, sizeof(mtk_oui));
	p += 3;

	/*1905 internal used vendor specific subtype*/
	*p++ = internal_vendor_bss_prio_ack_message_subtype;

	return 11;
}

#ifdef MAP_R2
int append_r2_cap_tlv(unsigned char *pkt, struct ap_r2_capability *r2_cap)
{
	unsigned char *temp_buf = NULL;
	unsigned short total_length = 0;

	temp_buf = pkt;
	(*temp_buf) = R2_AP_CAPABILITY_TYPE;
	temp_buf += 3;

	/*
	1. Set the Max Number Service Prioritization Rules in the R2 AP Capability TLV to 6 or greater.
	2. If the Multi-AP R2 Agent Advanced Service Prioritization Capability fields are included,
		the Multi-AP R2 Agent shall set the Max Number Advance Service Prioritization Rules
		in the R2 AP Capability TLV to 0 or greater.
	3. Set the Max Number of Permitted Destination MAC Addresses field to 1 or greater and
		shall support Packet Filtering using up to that number of Permitted Destination MAC Addresses.
	4. Set the Byte Counter Units field to 0x01 (KiB (kibibytes)).
	5. Set the Max Total Number of VIDs field to 2 or greater.
	6. Set the Number of Ethernet Interfaces that can be configured as Edge field to 0 or
		greater and add an Interface ID field for each logical Ethernet interface that
		can be configured as Edge
	*/

	*temp_buf = r2_cap->max_total_num_sp_rules;
	temp_buf += 2;	/*sizeof(max_total_num_sp_rules) + sizeof(reserved1)*/

	/* Byte Counter Units: bits 7-6
	**	0: bytes
	**	1: kibibytes (KiB)
	**	2: mebibytes (MiB)
	**	3: reserved
	*/
	*temp_buf = 0;

	if (r2_cap->byte_counter_units == 1)
		*temp_buf |= 0x40;
	else if (r2_cap->byte_counter_units == 2)
		*temp_buf |= 0x80;

	if (r2_cap->sp_flag == 1)
		*temp_buf |= 0x20;
	if (r2_cap->dpp_flag == 1)
		*temp_buf |= 0x10;
	if (r2_cap->ts_flag == 1)
		*temp_buf |= 0x08;

	temp_buf += 1;

	*temp_buf++ = r2_cap->max_total_num_vid;

	total_length = (unsigned short)(temp_buf - pkt);

	*(unsigned short *)(pkt + 1) = host_to_be16(total_length - 3);

	return total_length;
}

int append_metric_collection_interval_tlv(unsigned char *pkt, unsigned int interval)
{
	unsigned char *temp_buf = NULL;
	unsigned short total_length = 0;

	temp_buf = pkt;
	total_length = sizeof(unsigned int) + 3;
	(*temp_buf) = METRIC_COLLECTION_INTERVAL_TYPE;
	*(unsigned short *)(temp_buf+1) = host_to_be16(sizeof(unsigned int));
	temp_buf += 3;
	*(unsigned int *)(temp_buf) = host_to_be32(interval);

	return total_length;
}

int append_default_8021Q_tlv(struct p1905_managerd_ctx *ctx,
	unsigned char *pkt, unsigned char *al_mac,
	unsigned char bss_num, struct set_config_bss_info *bss_info)
{
	unsigned char *temp_buf = NULL;
	unsigned short total_length = 0;
	unsigned char i = 0;
	unsigned short pvid = 0;
	unsigned char pcp = 0;

	if (ctx->MAP_Cer) {
		for (i = 0; i < MAX_SET_BSS_INFO_NUM; i ++) {
			if (memcmp(al_mac, bss_info[i].mac, ETH_ALEN))
				continue;

			if (bss_info[i].pvid)
				break;
		}

		if (i >= bss_num)
			return 0;

		pvid = bss_info[i].pvid;
		pcp = bss_info[i].pcp;
	} else {
		pvid = ctx->map_policy.setting.primary_vid;
		pcp = ctx->map_policy.setting.dft.PCP;
	}

	if (pvid == INVALID_VLAN_ID)
		return 0;

	temp_buf = pkt;
	*temp_buf++ = DEFAULT_8021Q_SETTING_TYPE;
	*(unsigned short *)temp_buf = host_to_be16(3);
	temp_buf += 2;

	*(unsigned short *)temp_buf = host_to_be16(pvid);
	temp_buf +=2;

	*temp_buf++ = (pcp << 5) & 0xE0;

	total_length = temp_buf - pkt;
	*(unsigned short *)(pkt+1) = host_to_be16(total_length - 3);

	return total_length;
}


int append_traffic_separation_tlv(struct p1905_managerd_ctx *ctx,
	unsigned char *pkt, unsigned char *al_mac,
	unsigned char bss_num, struct set_config_bss_info *bss_info)
{
	unsigned char *temp_buf = pkt;
	unsigned short total_length = 0;
	unsigned char i = 0, ssid_num = 0;

	temp_buf += 3;

	/* skip ssid num 1 byte */
	temp_buf ++;

	for (i = 0; i < ctx->bss_config_num; i++) {
		if (ctx->MAP_Cer) {
			if (memcmp(al_mac, bss_info[i].mac, ETH_ALEN))
				continue;
		}
		if (bss_info[i].vid == INVALID_VLAN_ID)
			continue;

		ssid_num++;

		/* ssid len 1 byte */
		*temp_buf++ = bss_info[i].ssid_len;

		/* ssid */
		memcpy(temp_buf, bss_info[i].ssid, bss_info[i].ssid_len);
		temp_buf += bss_info[i].ssid_len;

		/* vlan id */
		*(unsigned short *)temp_buf = host_to_be16(bss_info[i].vid);
		temp_buf += 2;
	}

	if (ssid_num) {
		total_length = temp_buf - pkt;

		*pkt = TRAFFIC_SEPARATION_POLICY_TYPE;

		/* ts tlv len */
		*(unsigned short *)(pkt+1) = host_to_be16(total_length - 3);

		/* ssid num */
		*(pkt+3) = ssid_num;


	}
	/* fix cross-vendor test issue with Broadcom. Broadcom will re-onboarding after policy config
	** Broadcom will remove there policy after receiving M2 with ssid num == 0
	** only use policy config req to remove policy
	** so if ssid num ==0, we don't need to add this tlv in M2
	*/
	else
		notice(DEBUG_CAT_TS, "no ssid configured, don't add TS tlv in M2\n");

	return total_length;
}

int append_transparent_vlan_tlv(struct p1905_managerd_ctx *ctx, unsigned char *pkt)
{
	/*1905 internal using vendor specific tlv format
	   type			1 byte			0x11
	   length			2 bytes			0x, 0x
	   oui			3 bytes			0x00, 0x0C, 0xE7
	   function type	1 byte			0xff
	   suboui			3 bytes			0x00, 0x0C, 0xE7
	   sub func type	1 byte			0x
	*/
	unsigned char *p = pkt, *p_old = NULL;
	unsigned short len = 0;
	unsigned char mtk_oui[3] = {0x00, 0x0C, 0xE7};
	unsigned char i = 0;

	/*vendor specific tlv type*/
	*p++ = 11;

	/*vendor specific tlv length*/
	*((unsigned short*)p) = host_to_be16(8);
	p += 2;

	/*oui*/
	os_memcpy(p, mtk_oui, sizeof(mtk_oui));
	p += 3;

	/*function type*/
	*p++ = 0xff;

	/*additional OUI*/
	os_memcpy(p, mtk_oui, sizeof(mtk_oui));
	p += 3;

	/*1905 internal used vendor specific subtype*/
	*p++ = transparent_vlan_message_subtype;

	/*skip transparency vlan number*/
	p_old = p;
	p++;

	for (i = 0; i < ctx->map_policy.trans_vlan.num; i++) {
		if (ctx->map_policy.trans_vlan.transparent_vids[i]== INVALID_VLAN_ID)
			break;

		*((unsigned short*)p) = host_to_be16(ctx->map_policy.trans_vlan.transparent_vids[i]);
		p += 2;
	}

	/*set transparent vlan number*/
	*p_old = i;

	len = (unsigned short)(p - pkt);

	*((unsigned short*)(pkt + 1)) = host_to_be16(len - 3);

	return len;
}

int append_ap_radio_advan_tlv(unsigned char *pkt, struct ap_radio_advan_cap *radio_adv_capab)
{
	unsigned char *temp_buf = NULL;
	unsigned short total_length = 0;
	struct ap_radio_advan_cap *radio_advan_capability;

	temp_buf = pkt;
	total_length = 10;
	(*temp_buf) = AP_RADIO_ADVANCED_CAPABILITIES_TYPE;
	*(unsigned short *)(temp_buf+1) = host_to_be16(total_length-3);
	radio_advan_capability = (struct ap_radio_advan_cap *)(temp_buf + 3);
	os_memcpy(radio_advan_capability->radioid,radio_adv_capab->radioid,6);
	radio_advan_capability->flag=radio_adv_capab->flag;

	return total_length;
}

unsigned short append_backhaul_sta_radio_cap_tlv(unsigned char *pkt,
    unsigned char *rid, unsigned char *itf_mac)
{
    unsigned short total_length = 0;

    *pkt++ = BACKHAUL_STA_RADIA_CAPABILITY_TYPE;

	if (itf_mac) {
		*(unsigned short *)(pkt) = host_to_be16(13);
		total_length = 16;
	} else {
		*(unsigned short *)(pkt) = host_to_be16(7);
		total_length = 10;
	}
	pkt += 2;

	 /* Radio Unique Identifier */
	 memcpy(pkt,rid,ETH_ALEN);
	 pkt += ETH_ALEN;

	/* MAC address inlucde bit (bit 7)
	** 0: the MAC address is not included below
	** 1: the MAC address is included below
	*/
	if (itf_mac) {
		*pkt++ = 0x80;

		/* MAC address of the backhaul STA on this radio */
	    memcpy(pkt,itf_mac,ETH_ALEN);
	} else {
		*pkt++ = 0x0;
	}

    return total_length;
}

#endif

#ifdef MAP_R3
int append_agent_list_tlv(unsigned char *pkt, struct p1905_managerd_ctx *ctx)
{
	unsigned char *temp_buf = NULL;
    unsigned char agent_cnt = 0;
	unsigned char *p_cnt = NULL;
	unsigned short total_length = 0;
	struct r3_member *peer = NULL;

	temp_buf = pkt;
	(*temp_buf) = AGENT_LIST_TLV_TYPE;
	temp_buf += 3;

	/* Number of Agents */
	p_cnt = temp_buf;
	temp_buf++;
	dl_list_for_each(peer, &r3_member_head, struct r3_member, entry) {
		agent_cnt++;

	/* AL MAC address of the Agent */
	os_memcpy(temp_buf, peer->al_mac, ETH_ALEN);
	temp_buf += ETH_ALEN;

	/* Latest profile supported by the Agent */
	*temp_buf++ = peer->profile;

	/* 0x01: 1905 Security enabled default */
	*temp_buf++ = peer->security_1905;

	notice(DEBUG_CAT_DPP, "append peer "MACSTR" profile %d, 1905 security %d\n",
		MAC2STR(peer->al_mac), peer->profile, peer->security_1905);
	}

	*p_cnt = agent_cnt;

	total_length = (unsigned short)(temp_buf - pkt);

	*(unsigned short *)(pkt + 1) = host_to_be16(total_length - 3);

	return total_length;
}


int append_dpp_cce_indication_tlv(unsigned char *pkt, struct p1905_managerd_ctx* ctx)
{
	unsigned char *temp_buf = NULL;
	unsigned short total_length = 0;

	temp_buf = pkt;
	(*temp_buf) = DPP_CCE_INDICATION_TYPE;
	temp_buf += 1;

	*(unsigned short *)temp_buf = host_to_be16(2);
	temp_buf += 2;

	/* 1: enable
	** 2: disable CCE indication
	*/
	*temp_buf++ = 1;

	total_length = (unsigned short)(temp_buf - pkt);
	return total_length;
}

int append_akm_suite_cap_tlv(unsigned char *pkt, struct p1905_managerd_ctx* ctx)
{
	unsigned char *temp_buf = NULL;
	unsigned short total_length = 0;
	struct akm_suite_cap *p_akm = NULL;
	struct akm_suit *p_akm_suit = NULL;
	int i = 0;

	temp_buf = pkt;
	(*temp_buf) = AKM_SUITE_CAPABILITY_TYPE;
	temp_buf += 3;

	/* Num BH BSS AKM Suite Selectors	*/
	p_akm = &ctx->bh_akm;
	*temp_buf++ = p_akm->akm_suite_cnt;
	info(DEBUG_CAT_DPP, "\nNum BH AKM Suite %d\n", p_akm->akm_suite_cnt);
	/* where does the akm suits come frome */
	for (i = 0; i < p_akm->akm_suite_cnt; i ++) {
		p_akm_suit = &p_akm->akm_suite_info[i];
		memcpy(temp_buf, p_akm_suit->oui, 3);
		temp_buf += 3;

		*temp_buf++ = p_akm_suit->akm_suit_type;

		info_np(DEBUG_CAT_DPP, "\tsuite type %d, oui %02x%02x%02x\n",
			p_akm_suit->akm_suit_type, p_akm_suit->oui[0], p_akm_suit->oui[1],
			p_akm_suit->oui[2]);
	}

	/* Num FH BSS AKM Suite Selectors	*/
	p_akm = &ctx->fh_akm;
	*temp_buf++ = p_akm->akm_suite_cnt;
	info_np(DEBUG_CAT_DPP, "Num FH AKM Suite %d\n", p_akm->akm_suite_cnt);
	/* where does the akm suits come frome */
	for (i = 0; i < p_akm->akm_suite_cnt; i ++) {
		p_akm_suit = &p_akm->akm_suite_info[i];
		memcpy(temp_buf, p_akm_suit->oui, 3);
		temp_buf += 3;

		*temp_buf++ = p_akm_suit->akm_suit_type;

		info_np(DEBUG_CAT_DPP, "\tsuite type %d, oui %02x%02x%02x\n",
			p_akm_suit->akm_suit_type, p_akm_suit->oui[0], p_akm_suit->oui[1],
			p_akm_suit->oui[2]);
	}

	total_length = (unsigned short)(temp_buf - pkt);
	*(unsigned short *)(pkt + 1) = host_to_be16(total_length - 3);
	return total_length;
}


unsigned char *build_config_obj_attr(unsigned char *pkt, struct p1905_managerd_ctx* ctx,
	struct r3_member *peer, unsigned char *radio_identifier, unsigned char bss_index,
	unsigned char bss_found, unsigned char bss_type)
{
#define JSON_LEN 2048
	unsigned char *temp_buf = pkt;
	unsigned short per_obj_len = 0;
	unsigned short authmode = 0;
	char pass[63 * 6 + 1];
	char ssid[32 * 4 + 1];
	char identifier_str[20] = {0};
	struct wpabuf *buf = NULL;
	char json[JSON_LEN] = {0};
	char authStr[64 + 1] = {0};
	char dbg_authStr[64 + 1] = {0};
	unsigned char akm_idx = 0;
	struct bss_connector_item *bc_item =NULL, *bc_item_nxt = NULL;
	int found = 0;
	int res = 0;
	struct agent_list_db *agent = NULL;

	per_obj_len = 0;
	find_agent_info(ctx, peer->al_mac, &agent);
	if (!agent) {
		warn(DEBUG_CAT_DPP, "error!agent not found"MACSTR"\n",
			PRINT_MAC(peer->al_mac));
		return pkt;
	}

	/* update */
	dl_list_for_each_safe(bc_item, bc_item_nxt,
		&ctx->r3_dpp.bss_connector_list, struct bss_connector_item, member) {
		if (os_memcmp(bc_item->almac, peer->al_mac, ETH_ALEN) == 0) {
			found = 1;
			break;
		}
	}

	if (!found) {
		notice(DEBUG_CAT_DPP, "not found bss connector by almac "MACSTR"\n", MAC2STR(peer->al_mac));
		return pkt;
	}

	os_memset(json, 0, sizeof(json));
	buf = wpabuf_alloc(512+bc_item->bh_connector_len);
	if (!buf) {
		warn(DEBUG_CAT_DPP, "wpabuf_alloc failed\n");
		return pkt;
	}

	if (bss_found && bss_type & BIT_BH_BSS)
		/* wi-fi tech: map */
		res = snprintf(json+per_obj_len, sizeof(json), "{\"wi-fi_tech\":\"map\",\"discovery\":");
	else
		/* wi-fi tech: inframap */
		res = snprintf(json+per_obj_len, sizeof(json), "{\"wi-fi_tech\":\"inframap\",\"discovery\":");

	if (os_snprintf_error(JSON_LEN - per_obj_len, res))
		goto fail;
	per_obj_len += res;

	/* Radio identifier */
	wpa_snprintf_hex(identifier_str, sizeof(identifier_str), radio_identifier, ETH_ALEN);
	res = snprintf(json+per_obj_len, sizeof(json) - per_obj_len, "{\"RUID\":\"%s\"", identifier_str);
	if (os_snprintf_error(JSON_LEN - per_obj_len, res))
		goto fail;
	per_obj_len += res;

	if (bss_found) {
		os_memset(ssid, 0, sizeof(ssid));
		json_escape_string(ssid, sizeof(ssid),
			(const char *)ctx->bss_config[bss_index].ssid,
			os_strlen(ctx->bss_config[bss_index].ssid));
		res = snprintf(json+per_obj_len, sizeof(json) - per_obj_len, ",\"ssid\":\"%s\"", ssid);
	} else
		res = snprintf(json+per_obj_len, sizeof(json) - per_obj_len, ",\"ssid\":\"\"");

	if (os_snprintf_error(JSON_LEN - per_obj_len, res))
		goto fail;
	per_obj_len += res;

	if (!ctx->MAP_Cer && ctx->bss_config[bss_index].hidden_ssid) {
		res = snprintf(json+per_obj_len, sizeof(json) - per_obj_len, ",\"hidden-ssid\":\"1\"");
		if (os_snprintf_error(JSON_LEN - per_obj_len, res))
			goto fail;
		per_obj_len += res;
	}

	/*
	** BSSID value only used by reconfiguration
	** ignore here
	*/
	res = snprintf(json+per_obj_len, sizeof(json) - per_obj_len, ",\"BSSID\":\"000000000000\"");
	if (os_snprintf_error(JSON_LEN - per_obj_len, res))
		goto fail;
	per_obj_len += res;

	res = snprintf(json+per_obj_len, sizeof(json) - per_obj_len, "}");
	if (os_snprintf_error(JSON_LEN - per_obj_len, res))
		goto fail;
	per_obj_len += res;

	if (bss_found) {
		os_memset(authStr, 0, sizeof(authStr));
		/* CERT mode, authmode from wts file */
		if (ctx->MAP_Cer) {
#ifdef MAP_R6
			if (ctx->bss_config[bss_index].authmode & AUTH_AKM_SAE24)
				authmode |= AUTH_AKM_SAE24;
#endif
			if (ctx->bss_config[bss_index].authmode & AUTH_DPP_ONLY)
				authmode |= AUTH_DPP_ONLY;
			if (ctx->bss_config[bss_index].authmode & AUTH_SAE_PERSONAL)
				authmode |= AUTH_SAE_PERSONAL;
			if (ctx->bss_config[bss_index].authmode & AUTH_WPA2_PERSONAL)
				authmode |= AUTH_WPA2_PERSONAL;
		}
		/* Turnkey mode, authmode from akm tlv in bss config request */
		else {
			/* turnkey need check akm in wts as well */
			for (akm_idx = 0; akm_idx < peer->bh_akm.akm_suite_cnt; akm_idx ++) {
				if ((!os_memcmp(peer->bh_akm.akm_suite_info[akm_idx].oui, OUI_AKM_DPP, 3)) &&
					(peer->bh_akm.akm_suite_info[akm_idx].akm_suit_type == OUI_AKM_DPP[3]) &&
					(ctx->bss_config[bss_index].authmode & AUTH_DPP_ONLY))
					authmode |= AUTH_DPP_ONLY;
				if ((!os_memcmp(peer->bh_akm.akm_suite_info[akm_idx].oui, OUI_WPA2_AKM_SAE_SHA256, 3)) &&
					(peer->bh_akm.akm_suite_info[akm_idx].akm_suit_type == OUI_WPA2_AKM_SAE_SHA256[3]) &&
					(ctx->bss_config[bss_index].authmode & AUTH_SAE_PERSONAL))
					authmode |= AUTH_SAE_PERSONAL;
				if ((!os_memcmp(peer->bh_akm.akm_suite_info[akm_idx].oui, OUI_WPA2_AKM_PSK, 3)) &&
					((peer->bh_akm.akm_suite_info[akm_idx].akm_suit_type == OUI_WPA2_AKM_PSK[3]) ||
					(peer->bh_akm.akm_suite_info[akm_idx].akm_suit_type == OUI_WPA2_AKM_PSK_SHA256[3])) &&
					(ctx->bss_config[bss_index].authmode & AUTH_WPA2_PERSONAL))
					authmode |= AUTH_WPA2_PERSONAL;
#ifdef MAP_R6
				if ((!os_memcmp(peer->bh_akm.akm_suite_info[akm_idx].oui, OUI_AKM_SAE24, 3)) &&
					(peer->bh_akm.akm_suite_info[akm_idx].akm_suit_type == OUI_AKM_SAE24[3]) &&
					(ctx->bss_config[bss_index].authmode & AUTH_AKM_SAE24))
					authmode |= AUTH_AKM_SAE24;
#endif
			}
			/* owe for fh is from wts file */
			if (ctx->bss_config[bss_index].authmode & AUTH_OWE)
				authmode |= AUTH_OWE;
			if (ctx->bss_config[bss_index].authmode & AUTH_OWE_TRANSITION)
				authmode |= AUTH_OWE_TRANSITION;
		}

		if ((authmode & AUTH_DPP_ONLY) &&
			(authmode & AUTH_SAE_PERSONAL) &&
			(authmode & AUTH_WPA2_PERSONAL)) {
			(void)os_snprintf(dbg_authStr, sizeof(dbg_authStr), "dpp+psk+sae");
			(void)os_snprintf(authStr, sizeof(authStr), "dpp+psk+sae");
		} else if ((authmode & AUTH_DPP_ONLY) &&
			(authmode & AUTH_SAE_PERSONAL)) {
			(void)os_snprintf(dbg_authStr, sizeof(dbg_authStr), "dpp+sae");
			(void)os_snprintf(authStr, sizeof(authStr), "dpp+sae");
		} else if ((authmode & AUTH_DPP_ONLY) &&
			(authmode & AUTH_WPA2_PERSONAL)) {
			(void)os_snprintf(dbg_authStr, sizeof(dbg_authStr), "dpp+psk");
			(void)os_snprintf(authStr, sizeof(authStr), "dpp+psk");
		} else if (authmode & AUTH_DPP_ONLY) {
			(void)os_snprintf(dbg_authStr, sizeof(dbg_authStr), "dpp");
			(void)os_snprintf(authStr, sizeof(authStr), "dpp");
		} else if ((authmode & AUTH_SAE_PERSONAL) &&
			(authmode & AUTH_WPA2_PERSONAL)) {
			(void)os_snprintf(dbg_authStr, sizeof(dbg_authStr), "sae+psk");
			(void)os_snprintf(authStr, sizeof(authStr), "sae+psk");
		} else if (authmode & AUTH_SAE_PERSONAL) {
			(void)os_snprintf(dbg_authStr, sizeof(dbg_authStr), "sae");
			(void)os_snprintf(authStr, sizeof(authStr), "sae");
		} else if (authmode & AUTH_WPA2_PERSONAL) {
			(void)os_snprintf(dbg_authStr, sizeof(dbg_authStr), "psk");
			(void)os_snprintf(authStr, sizeof(authStr), "psk");
		} else if (authmode & AUTH_OWE) {
			(void)os_snprintf(dbg_authStr, sizeof(dbg_authStr), "owe");
			(void)os_snprintf(authStr, sizeof(authStr), "owe");
		} else if (authmode & AUTH_OWE_TRANSITION) {
			(void)os_snprintf(dbg_authStr, sizeof(dbg_authStr), "owe_transition");
			(void)os_snprintf(authStr, sizeof(authStr), "owe_transition");
		}

#ifdef MAP_R6
		/* DPP + PSK + SAE + SAE24 */
		if ((authmode & AUTH_DPP_ONLY) && (authmode & AUTH_WPA2_PERSONAL) &&
			(authmode & AUTH_SAE_PERSONAL) && (authmode & AUTH_AKM_SAE24)) {
			(void)os_snprintf(dbg_authStr, sizeof(dbg_authStr), "DPP + PSK + SAE + SAE24");
			(void)os_snprintf(authStr, sizeof(authStr), "506F9A02+000FAC02+000FAC08+000FAC24");
		}
		/* DPP + SAE + SAE24 */
		else if ((authmode & AUTH_DPP_ONLY) && (authmode & AUTH_SAE_PERSONAL) && (authmode & AUTH_AKM_SAE24)) {
			(void)os_snprintf(dbg_authStr, sizeof(dbg_authStr), "DPP + SAE + SAE24");
			(void)os_snprintf(authStr, sizeof(authStr), "506F9A02+000FAC08+000FAC24");
		}
		/* DPP + PSK + SAE24 */
		else if ((authmode & AUTH_DPP_ONLY) && (authmode & AUTH_WPA2_PERSONAL) && (authmode & AUTH_AKM_SAE24)) {
			(void)os_snprintf(dbg_authStr, sizeof(dbg_authStr), "DPP + PSK + SAE24");
			(void)os_snprintf(authStr, sizeof(authStr), "506F9A02+000FAC02+000FAC24");
		}
		/* DPP + SAE24 */
		else if ((authmode & AUTH_DPP_ONLY) && (authmode & AUTH_AKM_SAE24)) {
			(void)os_snprintf(dbg_authStr, sizeof(dbg_authStr), "DPP + SAE24");
			(void)os_snprintf(authStr, sizeof(authStr), "506F9A02+000FAC24");
		}
		/* PSK + SAE + SAE24 */
		else if ((authmode & AUTH_WPA2_PERSONAL) && (authmode & AUTH_SAE_PERSONAL) && (authmode & AUTH_AKM_SAE24)) {
			(void)os_snprintf(dbg_authStr, sizeof(dbg_authStr), "PSK + SAE + SAE24");
			(void)os_snprintf(authStr, sizeof(authStr), "000FAC02++000FAC08+000FAC24");
		}
		/* PSK + SAE24 */
		else if ((authmode & AUTH_WPA2_PERSONAL) && (authmode & AUTH_AKM_SAE24)) {
			(void)os_snprintf(dbg_authStr, sizeof(dbg_authStr), "PSK + SAE24");
			(void)os_snprintf(authStr, sizeof(authStr), "000FAC02+000FAC24");
		}
		/* SAE + SAE24 */
		else if ((authmode & AUTH_SAE_PERSONAL) && (authmode & AUTH_AKM_SAE24)) {
			(void)os_snprintf(dbg_authStr, sizeof(dbg_authStr), "SAE + SAE24");
			(void)os_snprintf(authStr, sizeof(authStr), "000FAC08+000FAC24");
		}
		/* SAE24 only */
		else if (authmode & AUTH_AKM_SAE24) {
			(void)os_snprintf(dbg_authStr, sizeof(dbg_authStr), "SAE24");
			(void)os_snprintf(authStr, sizeof(authStr), "000FAC24");
		}
#endif

		/* akm:  */
		res = snprintf(json+per_obj_len, sizeof(json) - per_obj_len, ",\"cred\":{\"akm\":\"%s\"", authStr);
		if (os_snprintf_error(JSON_LEN - per_obj_len, res))
			goto fail;
		per_obj_len += res;

		/* pass: WPA2 Passphrase */
		json_escape_string(pass, sizeof(pass),
			(const char *)ctx->bss_config[bss_index].key,
			os_strlen(ctx->bss_config[bss_index].key));

		if (os_strlen(pass) >= 8 && os_strlen(pass) <= 63)
			res = os_snprintf(json+per_obj_len, JSON_LEN - per_obj_len, ",\"pass\":\"%s\"", pass);
		else if (os_strlen(pass) == 64)
			res = os_snprintf(json+per_obj_len, JSON_LEN - per_obj_len, ",\"psk_hex\":\"%s\"", pass);
		else {
			warn(DEBUG_CAT_DPP, "invalid passphrase length %d\n", (int)os_strlen(pass));
			goto fail;
		}

		if (os_snprintf_error(JSON_LEN - per_obj_len, res))
			goto fail;

		per_obj_len += res;

		/* add pre-shared key but no value
		per_obj_len += sprintf(json+per_obj_len, ",\"psk_hex\":\"\"");*/

		/* connector for BH or FH */
		if (bss_type & BIT_BH_BSS)
			res = snprintf(json+per_obj_len, sizeof(json) - per_obj_len, ",%s", bc_item->bh_connector);
		else
			res = snprintf(json+per_obj_len, sizeof(json) - per_obj_len, ",%s", bc_item->fh_connector);

		if (os_snprintf_error(JSON_LEN - per_obj_len, res))
			goto fail;
		per_obj_len += res;

		res = snprintf(json+per_obj_len, sizeof(json) - per_obj_len, "}");
		if (os_snprintf_error(JSON_LEN - per_obj_len, res))
			goto fail;
		per_obj_len += res;

		notice(DEBUG_CAT_DPP, "SSID:%s", ssid);
		notice_np(DEBUG_CAT_DPP, ", AKM:%s\n", dbg_authStr);
	}
	res = snprintf(json+per_obj_len, sizeof(json) - per_obj_len, "}");
	if (os_snprintf_error(JSON_LEN - per_obj_len, res))
		goto fail;
	per_obj_len += res;
	debug(DEBUG_CAT_DPP, "bss conf JSON:%s\n", json);

	/* configAttrib */
	wpabuf_put_le16(buf, DPP_ATTR_CONFIG_OBJ);
	wpabuf_put_le16(buf, per_obj_len);

	wpabuf_put_data(buf, json, per_obj_len);

	/* copy each tlv to pkt */
	os_memcpy(temp_buf, wpabuf_head(buf), wpabuf_len(buf));

	temp_buf += wpabuf_len(buf);

fail:
	wpabuf_free(buf);

	return temp_buf;
}

unsigned char *build_bss_config_obj_attr(unsigned char *pkt, struct p1905_managerd_ctx* ctx,
	struct r3_member *peer, unsigned char *radio_identifier, unsigned char bss_index, unsigned char bss_found)
{
	unsigned char *temp_buf = pkt;

	if (bss_found) {
		if (ctx->bss_config[bss_index].wfa_vendor_extension & BIT_BH_BSS)
			temp_buf = build_config_obj_attr(temp_buf, ctx, peer, radio_identifier, bss_index, bss_found, BIT_BH_BSS);
		if (ctx->bss_config[bss_index].wfa_vendor_extension & BIT_FH_BSS)
			temp_buf = build_config_obj_attr(temp_buf, ctx, peer, radio_identifier, bss_index, bss_found, BIT_FH_BSS);
	} else {
		temp_buf = build_config_obj_attr(temp_buf, ctx, peer, radio_identifier, 0, bss_found, 0);
	}
	return temp_buf;
}


/*
**	BSS Configuration Response TLV 1
**		DPP Configuration Object (16bss of radio 1)
**	BSS Configuration Response TLV 2
**		DPP Configuration Object (rest of 16bss of radio 1 )
**	BSS Configuration Response TLV 3
**		DPP Configuration Object (16bss of radio 2)
**	BSS Configuration Response TLV 4
**		DPP Configuration Object (rest of 16bss of radio 2 )
**	BSS Configuration Response TLV 5
**		DPP Configuration Object (16bss of radio 3)
**	BSS Configuration Response TLV 6
**		DPP Configuration Object (rest of 16bss of radio 3)
*/
int append_bss_config_response_tlv(unsigned char *pkt, struct p1905_managerd_ctx* ctx, unsigned char *al_mac)
{
	unsigned char *temp_buf = NULL;
	/* base pointer of each tlv */
	unsigned char *tlv_base_ptr = NULL;
	unsigned short total_length = 0;
	unsigned char *p_tlv_len = 0;
	/* bss num in one bss config response tlv */
	unsigned char bss_num_in_tlv = 0;
	/* bss num per radio */
	unsigned char bss_num_per_radio = 0;
	/* idx in wts file for each radio */
	unsigned char bss_conf_idx = 0;
	unsigned char radio_idx = 0;
	//unsigned char bss_cnt[MAX_RADIO_NUM];
	struct agent_list_db *agent = NULL;
	struct agent_radio_info *radio = NULL;
	struct r3_member *peer = NULL;
	int k = 0;
	unsigned char band = BAND_INVALID_CAP;
	unsigned char wild_card_mac[ETH_ALEN] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};

	tlv_base_ptr = temp_buf = pkt;

	find_agent_info(ctx, al_mac, &agent);
	if (!agent) {
		warn(DEBUG_CAT_DPP, "error!agent not found"MACSTR"\n",
			PRINT_MAC(al_mac));
		return 0;
	}

	peer = get_r3_member(al_mac);

	if (!peer) {
		warn(DEBUG_CAT_DPP, "peer info not found\n");
		return 0;
	}

	while (radio_idx < agent->radio_num) {
		radio = &agent->ra_info[radio_idx];

		/* build TLV once:
		**  1. first radio && first time
		**  2. bss num in the tlv bigger than 16
		*/
		if ((radio_idx == 0 && bss_num_in_tlv == 0) ||
			(bss_num_in_tlv >= BSSNUM_PER_BSS_RESPONSE_TLV)) {

			/* reset bss num in the tlv to 0
			** and set base pointer for next tlv
			** once tlv num in the tlv bigger than 16
			*/
			if (bss_num_in_tlv >= BSSNUM_PER_BSS_RESPONSE_TLV) {
				bss_num_in_tlv = 0;
				tlv_base_ptr = temp_buf;
			}

			/* build bss config response tlv */
			*temp_buf++ = BSS_CONFIG_RESPONSE_TYPE;
			p_tlv_len = temp_buf;
			temp_buf += 2;

			notice(DEBUG_CAT_DPP, "begin build bss config response tlv\n");

		}

		band = determin_band_config(ctx, al_mac, radio->band);
		/* NULL-SSID config obj if:
		**	1. no bss info in wts
		**	2. invalid band cap from agent
		*/
		if (band == BAND_INVALID_CAP || (ctx->block_bss_info.block_bss_autoconfig && agent->is_block)) {
			notice(DEBUG_CAT_DPP, "invalid band 0x%02x for radio"MACSTR"\n",
				radio->band, PRINT_MAC(radio->identifier));
			notice(DEBUG_CAT_DPP, "build NULL-SSID config obj\n");

			temp_buf = build_bss_config_obj_attr(temp_buf, ctx, peer, radio->identifier, 0, 0);

			radio_idx++;
		} else {
			debug(DEBUG_CAT_DPP, "band cap 0x%02x for radio %d\n", band, radio_idx);
			/* idx in wts should start from last one of the radio */
			for (k = bss_conf_idx; k < ctx->bss_config_num; k++) {
				if (band == ctx->bss_config[k].band_support &&
					(!os_memcmp(al_mac, ctx->bss_config[k].mac, ETH_ALEN) ||
					!os_memcmp(ctx->bss_config[k].mac, wild_card_mac, ETH_ALEN))) {
					if ((bss_num_per_radio < radio->max_bss_num) &&
							bss_num_in_tlv < BSSNUM_PER_BSS_RESPONSE_TLV) {
						notice(DEBUG_CAT_DPP, "build config obj for bss(%d) of band %d(%s)\n",
							bss_num_per_radio, radio->band, band_2_string(radio->band));
						temp_buf = build_bss_config_obj_attr(
							temp_buf, ctx, peer, radio->identifier,
							k, 1);

						/* increasement bss_num of current radio */
						bss_num_per_radio++;
						bss_num_in_tlv++;

						/* store idx in wts to the last + 1 */
						bss_conf_idx = k+1;
					}
				}
			}

			if (!bss_num_per_radio) {
				/* build null obj when bss num eqaul to 0 */
				notice(DEBUG_CAT_DPP, "build NULL-SSID config obj for bind(%d)\n", radio_idx);
				temp_buf = build_bss_config_obj_attr(temp_buf, ctx, peer, radio->identifier, 0, 0);
			} else {
				/* build config obj with NULL-SSID for the rest bss of the radio */
				while ((bss_num_per_radio < radio->max_bss_num) &&
						bss_num_in_tlv < BSSNUM_PER_BSS_RESPONSE_TLV) {

					notice(DEBUG_CAT_DPP,
						"build NULL-SSID config obj for bss index(%d) band %d(%s)\n",
						bss_num_per_radio, radio->band, band_2_string(radio->band));
					/* build config obj attr for this bss with NULL-SSID */
					temp_buf = build_bss_config_obj_attr(
						temp_buf, ctx, peer, radio->identifier, 0, 0);

					/* increasement bss_num of current radio */
					bss_num_per_radio++;
					bss_num_in_tlv++;
				}
			}

			if (bss_num_per_radio >= radio->max_bss_num) {
				/* bss num greater than or eqaul to
				**	max bss num of this radio
				*/
				radio_idx++;
				bss_num_per_radio = 0;
				bss_conf_idx = 0;
				info(DEBUG_CAT_DPP, "goto next radio[%d]\n", radio_idx);
			} else
				info(DEBUG_CAT_DPP, "stay on current radio[%d]\n", radio_idx);
		}

		/* update each tlv len here, avoid tlv len of last tlv is missing */
		*((unsigned short *)p_tlv_len) = host_to_be16(temp_buf - tlv_base_ptr - 3);
	}
	/* update each tlv len */
	total_length = (unsigned short)(temp_buf - pkt);
	return total_length;
}

/* spec is not ready, just keep as a reminder here */
int append_bss_config_report_tlv(unsigned char *pkt, struct p1905_managerd_ctx* ctx)
{
	unsigned char *temp_buf = NULL;
	unsigned short total_length = 0;
	int i = 0, j = 0;

	temp_buf = pkt;
	(*temp_buf) = BSS_CONFIG_REPORT_TYPE;
	temp_buf += 3;

	/*
	Number of radios reported.
	*/
	*temp_buf++ = ctx->radio_number;
	info(DEBUG_CAT_DPP, "\nradio num:%d\n", ctx->radio_number);

	for (i = 0; i < ctx->radio_number; i++) {
		/* Radio Unique Identifier of a radio */
		os_memcpy(temp_buf, ctx->rinfo[i].identifier, ETH_ALEN);
		info_np(DEBUG_CAT_DPP, "radio identifier "MACSTR"", MAC2STR(ctx->rinfo[i].identifier));
		temp_buf += ETH_ALEN;

		/* Number of BSS */
		*temp_buf++ = ctx->rinfo[i].bss_number;
		info_np(DEBUG_CAT_DPP, ", bss num %d\n", ctx->rinfo[i].bss_number);

		for (j = 0; j < ctx->rinfo[i].bss_number; j++) {
			/* MAC Address of Local Interface (equal to BSSID) */
			os_memcpy(temp_buf, ctx->rinfo[i].bss[j].mac, ETH_ALEN);
			info_np(DEBUG_CAT_DPP, "\tbssid "MACSTR"", MAC2STR(ctx->rinfo[i].bss[j].mac));
			temp_buf += ETH_ALEN;
			info_np(DEBUG_CAT_DPP, ", ssid:%s", ctx->rinfo[i].bss[j].config.Ssid);

			*temp_buf = 0;

			/* bit7: Backhaul BSS */
			if (ctx->rinfo[i].bss[j].config.map_vendor_extension & BIT_BH_BSS) {
				*temp_buf |= 0x80;
				info_np(DEBUG_CAT_DPP,  "BH in use\n");
			}
			/* bit6: Fronthaul BSS */
			if (ctx->rinfo[i].bss[j].config.map_vendor_extension & BIT_FH_BSS) {
				*temp_buf |= 0x40;
				info_np(DEBUG_CAT_DPP, "FH in use\n");
			}

			/* bit5: R1 disallowed status */
			if (ctx->rinfo[i].bss[j].config.map_vendor_extension & BIT_PROFILE1_DISALLOW) {
				*temp_buf |= 0x20;
				info_np(DEBUG_CAT_DPP, ", R1 disallowed");
			} else
				info_np(DEBUG_CAT_DPP, ", R1 allowed");

			/* bit4: R2 disallowed status */
			if (ctx->rinfo[i].bss[j].config.map_vendor_extension & BIT_PROFILE2_DISALLOW) {
				*temp_buf |= 0x10;
				info_np(DEBUG_CAT_DPP, ", R2 allowed");
			} else
				info_np(DEBUG_CAT_DPP, ", R2 allowed");

			/* bit1 bit0 reserved */
			temp_buf++;

			/* one more byte reserved */
			temp_buf++;

			/* SSID length: 1 byte */
			*temp_buf++ = 33;
			info_np(DEBUG_CAT_DPP, ", ssid len:%d\n", 33);

			/* SSID */
			os_memcpy(temp_buf, ctx->rinfo[i].bss[j].config.Ssid, 33);
			temp_buf += 33;
        }
    }

	total_length = (unsigned short)(temp_buf - pkt);

	*(unsigned short *)(pkt + 1) = host_to_be16(total_length - 3);

	return total_length;
}


int append_dpp_chirp_value_tlv
(
	unsigned char *pkt,
	struct chirp_tlv_info *chirp
)
{
	unsigned char *temp_buf = NULL;
	unsigned short total_length = 0;

	temp_buf = pkt;
	(*temp_buf) = DPP_CHIRP_VALUE_TYPE;
	temp_buf += 3;

    /*
    1. one byte
       bit 7, Enrollee MAC Address Present field,
        This field is only set to 1 for reconfiguration purposes
       Bit 6: Hash Validity
        1: establish DPP authentication state pertaining to the hash value in this TLV
        0: purge any DPP authentication state pertaining to the hash value in this TLV
    2. Destination STA MAC Address
    3. hash length 1 octet
    4. hash value k octets
    */
    *temp_buf = 0;
    if (chirp->enrollee_mac_address_present)
        *temp_buf |= 0x80;

    /* hash type and hash validity bitmapt */
    if (chirp->hash_validity == 1)
        *temp_buf |= 0x40;

    temp_buf++;

    if (chirp->enrollee_mac_address_present) {
        os_memcpy(temp_buf, chirp->enrollee_mac, ETH_ALEN);
        temp_buf += ETH_ALEN;
    }

    /* hash len: 1 byte */
    *(temp_buf++) = chirp->hash_len;

    /* hash */
    os_memcpy(temp_buf, chirp->hash_payload, chirp->hash_len);

    temp_buf += chirp->hash_len;

	total_length = (unsigned short)(temp_buf - pkt);

	*(unsigned short *)(pkt + 1) = host_to_be16(total_length - 3);

	return total_length;
}

int append_1905_layer_security_tlv(unsigned char *pkt)
{
	unsigned char *temp_buf = NULL;
	unsigned short total_length = 0;

	temp_buf = pkt;
	(*temp_buf) = _1905_LAYER_SECURITY_CAPABILITY_TYPE;
	temp_buf += 1;

	/* len : 3 bytes */
	*((unsigned short *)temp_buf) = host_to_be16(3);
	temp_buf += 2;

	/* Onboarding protocols supported: 1905 Device Provisioning Protocol */
	(*temp_buf) = 0;
	temp_buf += 1;

	/* Message integrity algorithms supported: HMAC-SHA256 */
	(*temp_buf) = 0;
	temp_buf += 1;

	/* Message encryption algorithms supported: AES-SIV */
	(*temp_buf) = 0;
	temp_buf += 1;

	total_length = (unsigned short)(temp_buf - pkt);

	return total_length;
}

int append_1905_encap_eapol_tlv(unsigned char *pkt, struct p1905_managerd_ctx* ctx)
{
	unsigned char *temp_buf = NULL;
	unsigned short total_length = 0;

	temp_buf = pkt;
	(*temp_buf++) = _1905_ENCAP_EAPOL_MESSAGE_TYPE;

	*((unsigned short *)temp_buf) = host_to_be16(ctx->send_tlv_len);
	temp_buf += 2;

	memcpy(temp_buf, ctx->send_tlv, ctx->send_tlv_len);
	temp_buf += ctx->send_tlv_len;

	ctx->send_tlv_len = 0;

	total_length = (unsigned short)(temp_buf - pkt);

	return total_length;
}

int append_bootstrap_uri_notification_tlv(unsigned char *pkt, struct p1905_managerd_ctx* ctx)
{
	unsigned char *temp_buf = NULL;
	unsigned short total_length = 0;

	temp_buf = pkt;
	memcpy(temp_buf, ctx->send_tlv, ctx->send_tlv_len);
	temp_buf += ctx->send_tlv_len;

	ctx->send_tlv_len = 0;

	total_length = (unsigned short)(temp_buf - pkt);

	*(unsigned short *)(pkt + 1) = host_to_be16(total_length - 3);

	return total_length;
}

int append_bss_configuration_request_tlv(unsigned char *pkt, struct p1905_managerd_ctx* ctx)
{
	unsigned char *temp_buf = NULL;
	unsigned short total_length = 0;
	char json[512] = {0x00};
	struct wpabuf *msg = NULL;

	temp_buf = pkt;

	*temp_buf = BSS_CONFIG_REQUEST_TYPE;
	temp_buf += 3;

    /*
        DPP Configuration Request Object with the following content:
        "   netRole set to "mapAgent"
        "   wi-fi_tech set to "map"
    */

	(void)os_snprintf(json, sizeof(json),
		    "{"
		        "\"netRole\":\"mapAgent\","
		        "\"wi-fi_tech\":\"map\""
		    "}");

	debug(DEBUG_CAT_DPP, "BSS configuration req obj: %s\n", json);

	msg = wpabuf_alloc(4 + os_strlen(json));

	if (!msg) {
		warn(DEBUG_CAT_DPP, "fail to malloc msg\n");
		goto end;
	}

	/* configAttrib */
	wpabuf_put_le16(msg, DPP_ATTR_CONFIG_ATTR_OBJ);
	wpabuf_put_le16(msg, os_strlen(json));
	wpabuf_put_data(msg, json, os_strlen(json));

	os_memcpy(temp_buf, wpabuf_mhead(msg), wpabuf_len(msg));

	total_length = 3 + wpabuf_len(msg);
	*(unsigned short *)(pkt + 1) = host_to_be16(total_length - 3);
	if (msg)
		os_free(msg);
end:
	return total_length;
}


#ifdef MAP_R3_WF6
unsigned short append_ap_wf6_capability_tlv(
        unsigned char *pkt, struct ap_wf6_role_db *wf6_cap)
{
	unsigned short total_length = 0;
	unsigned char *temp_buf = NULL;
	unsigned char *length = NULL;
	int i = 0;

	temp_buf = pkt;

	*temp_buf++ = 0xAA;

	length = temp_buf;
	temp_buf += 2;

	memcpy(temp_buf, wf6_cap->identifier, ETH_ALEN);
	temp_buf += ETH_ALEN;
	total_length += ETH_ALEN;

	*temp_buf++ = wf6_cap->role_supp;
	total_length++;

	for(i = 0; i < wf6_cap->role_supp; i++) {
		*temp_buf++ = (wf6_cap->wf6_role[i].agent_role << 6) | (wf6_cap->wf6_role[i].he_160 << 5) |
			(wf6_cap->wf6_role[i].he_8080 << 4 | wf6_cap->wf6_role[i].he_mcs_len);
		total_length++;

		os_memcpy(temp_buf, wf6_cap->wf6_role[i].he_mcs, wf6_cap->wf6_role[i].he_mcs_len);
		temp_buf += wf6_cap->wf6_role[i].he_mcs_len;
		total_length += wf6_cap->wf6_role[i].he_mcs_len;

		*temp_buf++ = (wf6_cap->wf6_role[i].su_bf_cap << 7) |(wf6_cap->wf6_role[i].su_beamformee_status << 6) |
			(wf6_cap->wf6_role[i].mu_bf_cap << 5) | (wf6_cap->wf6_role[i].beamformee_sts_less80 << 4) |
			(wf6_cap->wf6_role[i].beamformee_sts_more80 << 3) | (wf6_cap->wf6_role[i].ul_mu_mimo_cap << 2) |
			(wf6_cap->wf6_role[i].ul_ofdma_cap << 1) | wf6_cap->wf6_role[i].dl_ofdma_cap;
		total_length++;


		*temp_buf++ = (wf6_cap->wf6_role[i].max_user_dl_tx_mu_mimo << 4) |
			(wf6_cap->wf6_role[i].max_user_ul_rx_mu_mimo);
		total_length++;

		*temp_buf++ = wf6_cap->wf6_role[i].max_user_dl_tx_ofdma;
		total_length++;

		*temp_buf++ = wf6_cap->wf6_role[i].max_user_ul_rx_ofdma;
		total_length++;

		*temp_buf++ = (wf6_cap->wf6_role[i].rts_status << 7) | (wf6_cap->wf6_role[i].mu_rts_status << 6) |
			(wf6_cap->wf6_role[i].m_bssid_status << 5) | (wf6_cap->wf6_role[i].mu_edca_status << 4) |
			(wf6_cap->wf6_role[i].twt_requester_status <<3) | (wf6_cap->wf6_role[i].twt_responder_status <<2)
#ifdef MAP_R4_SPT
			| (wf6_cap->sr_mode << 1)
#endif
		;
		total_length++;
	}

	*(unsigned short *)length = host_to_be16(total_length);

	return (total_length + 3);
}
#endif

#ifdef MAP_R3_DE
unsigned short append_dev_inven_tlv(
		unsigned char *pkt, struct dev_inven *de)
{
	unsigned short total_length = 0;
	unsigned char *temp_buf = NULL;
	unsigned char *length = NULL;
	int i = 0;

	temp_buf = pkt;

	*temp_buf++ = R3_DE_INVENTORY_TLV_TYPE;

	length = temp_buf;
	temp_buf += 2;

	*temp_buf++ = de->ser_num_len;
	total_length++;

	os_memcpy(temp_buf, de->ser_num, de->ser_num_len);
	temp_buf += de->ser_num_len;
	total_length += de->ser_num_len;

	*temp_buf++ = de->sw_ver_len;
	total_length++;

	os_memcpy(temp_buf, de->sw_ver, de->sw_ver_len);
	temp_buf += de->sw_ver_len;
	total_length += de->sw_ver_len;

	*temp_buf++ = de->exec_env_len;
	total_length++;

	os_memcpy(temp_buf, de->exec_env, de->exec_env_len);
	temp_buf += de->exec_env_len;
	total_length += de->exec_env_len;

	*temp_buf++ = de->num_radio;
	total_length ++;

	for(i = 0; i < de->num_radio; i++)
	{
		os_memcpy(temp_buf, de->ruid[i].identifier, ETH_ALEN);
		temp_buf += ETH_ALEN;
		total_length += ETH_ALEN;

		*temp_buf++ = de->ruid[i].chip_ven_len;
		total_length++;

		os_memcpy(temp_buf, de->ruid[i].chip_ven, de->ruid[i].chip_ven_len);
		temp_buf += de->ruid[i].chip_ven_len;
		total_length += de->ruid[i].chip_ven_len;

	}

	*(unsigned short *)length = host_to_be16(total_length);

	return total_length + 3;
}
#endif /*MAP_R3_DE*/
#endif

/*MLO related API*/
unsigned short append_bss_mld_report_vendor_tlv(unsigned char *pkt, struct p1905_managerd_ctx *ctx)
{
	unsigned short total_length = 0;
	unsigned char *temp_buf = pkt;
	int radio_num = 0;
	struct op_bss_db *bss_info = NULL;
	struct operational_bss_db *operbss_info = NULL;
	unsigned char *p_radio_num = NULL;
	unsigned char *p_tlv_len = NULL;
	unsigned char i = 0, j = 0;
	unsigned char einfo = 0;
	unsigned char valid = 0;

	SLIST_FOREACH(operbss_info, &ctx->ap_cap_entry.oper_bss_head, oper_bss_entry)
	{
		SLIST_FOREACH(bss_info, &operbss_info->op_bss_head, op_bss_entry)
		{

			if (bss_info->mlo_info.mld_idx) {
				valid = 1;
				break;
			}

		}
		if (valid)
			break;
	}
	if (!valid)
		return 0;

	*temp_buf = VENDOR_SPECIFIC_TLV_TYPE;
	total_length += 1;
	temp_buf += 1;

	/*shift to OUI field*/
	p_tlv_len = temp_buf;
	temp_buf += 2;
	total_length += 2;
	memcpy(temp_buf, OUI_MEDIATEK, OUI_LEN);
	temp_buf += OUI_LEN;
	total_length += OUI_LEN;

	/*functype BSS MLD Report*/
	*temp_buf = BSS_MLD_REPORT_TYPE;
	temp_buf += 1;
	total_length += 1;

	/*skip radio number*/
	p_radio_num = temp_buf;
	temp_buf += 1;
	total_length += 1;

	SLIST_FOREACH(operbss_info, &ctx->ap_cap_entry.oper_bss_head, oper_bss_entry)
	{
		radio_num++;
		memcpy(temp_buf, operbss_info->identifier, ETH_ALEN);
		info(DEBUG_CAT_MLO, "identifier("MACSTR")\n", PRINT_MAC(operbss_info->identifier));
		temp_buf += ETH_ALEN;
		total_length += ETH_ALEN;
		*temp_buf = operbss_info->oper_bss_num;
		temp_buf += 1;
		total_length += 1;
		if (!operbss_info->oper_bss_num)
			continue;
		SLIST_FOREACH(bss_info, &operbss_info->op_bss_head, op_bss_entry)
		{
			info_np(DEBUG_CAT_MLO, "BSSID("MACSTR")", PRINT_MAC(bss_info->bssid));
			memcpy(temp_buf, bss_info->bssid, ETH_ALEN);
			temp_buf += ETH_ALEN;
			total_length += ETH_ALEN;
			/*check if it is bh/fh bss*/
			for (i = 0; i < ctx->radio_number; i++) {
				if (memcmp(operbss_info->identifier,
					ctx->rinfo[i].identifier, ETH_ALEN))
					continue;
				for (j = 0; j < ctx->rinfo[i].bss_number; j++) {
					if (memcmp(bss_info->bssid,
						ctx->rinfo[i].bss[j].mac, ETH_ALEN))
						continue;
					break;
				}
				break;
			}
			if (i < ctx->radio_number && j < ctx->rinfo[i].bss_number) {
#ifdef MAP_R2
				if (ctx->rinfo[i].bss[j].config.map_vendor_extension & BIT_BH_BSS)
					einfo |= 1 << 7;
				if (ctx->rinfo[i].bss[j].config.map_vendor_extension & BIT_FH_BSS)
					einfo |= 1 << 6;
#endif
				*temp_buf = einfo;
				temp_buf += 1;
				total_length += 1;
			}
			info_np(DEBUG_CAT_MLO, ", mld_idx(%d)", bss_info->mlo_info.mld_idx);
			*temp_buf = bss_info->mlo_info.mld_idx;
			temp_buf += 1;
			total_length += 1;
			info_np(DEBUG_CAT_MLO, ", mld_addr("MACSTR")\n",
				PRINT_MAC(bss_info->mlo_info.mld_addr));
			memcpy(temp_buf, bss_info->mlo_info.mld_addr, ETH_ALEN);
			temp_buf += ETH_ALEN;
			total_length += ETH_ALEN;
		}
	}

	*(unsigned short *)p_tlv_len = host_to_be16(total_length - 3);
	*p_radio_num = radio_num;

	return total_length;
}

unsigned short append_mlo_cap_vendor_tlv(unsigned char *pkt, struct ap_mlo_cap_db *cap)
{
	unsigned short total_length = 0;
	unsigned char *temp_buf = pkt;
	struct mlo_cap_per_role *role = NULL;
	unsigned char *p_tlv_len = NULL;
	unsigned char i = 0;
	unsigned short eml_cap = 0, mld_cap = 0;

	*temp_buf = VENDOR_SPECIFIC_TLV_TYPE;
	total_length += 1;
	temp_buf += 1;

	/*shift to OUI field*/
	p_tlv_len = temp_buf;
	temp_buf += 2;
	total_length += 2;
	memcpy(temp_buf, OUI_MEDIATEK, OUI_LEN);
	temp_buf += OUI_LEN;
	total_length += OUI_LEN;

	/*functype BSS MLD Report*/
	*temp_buf = MLO_CAPABILITY_TYPE;
	temp_buf += 1;
	total_length += 1;

	memcpy(temp_buf, cap->identifier, ETH_ALEN);

	temp_buf += ETH_ALEN;
	total_length += ETH_ALEN;

	*temp_buf = cap->role_num;
	temp_buf += 1;
	total_length += 1;

	for (i = 0; i < cap->role_num; i++) {
		role = &cap->role_cap[i];
		*temp_buf = role->dev_role << 6;
		*temp_buf |= role->static_punc_supp << 5;
		*temp_buf |= role->mlo_enable << 4;
		temp_buf += 1;
		total_length += 1;

		eml_cap |= (unsigned short)role->eml_cap.trans_timeout << 11;
		eml_cap |= (unsigned short)role->eml_cap.emlmr_delay << 8;
		eml_cap |= (unsigned short)role->eml_cap.emlmr_supp << 7;
		eml_cap |= (unsigned short)role->eml_cap.emlsr_trans_delay << 4;
		eml_cap |= (unsigned short)role->eml_cap.emlsr_padding_delay << 1;
		eml_cap |= (unsigned short)role->eml_cap.emlmr_supp;
		*(unsigned short *)temp_buf = host_to_be16(eml_cap);
		temp_buf += 2;
		total_length += 2;

		mld_cap |= (unsigned short)role->mld_cap.aar_supp << 12;
		mld_cap |= (unsigned short)role->mld_cap.freq_sep_str << 7;
		mld_cap |= (unsigned short)role->mld_cap.t2l_nego_supp << 5;
		mld_cap |= (unsigned short)role->mld_cap.srs_supp << 4;
		mld_cap |= (unsigned short)role->mld_cap.max_simul_link;
		*(unsigned short *)temp_buf = host_to_be16(mld_cap);
		temp_buf += 2;
		total_length += 2;
	}

	*(unsigned short *)p_tlv_len = host_to_be16(total_length - 3);

	return total_length;
}

unsigned short append_mlo_cap_announce_vendor_tlv(
		unsigned char *pkt, struct ap_mlo_cap_db *mlo_cap)
{
	/*1905 vendor specific tlv format
	* type		1byte			0x11
	* length			2bytes		0x, 0x
	* oui			3bytes		0x00, 0x0C, 0xE7
	* function type 1byte			0x02
	* identifier	6bytes			0x, 0x, 0x, 0x, 0x, 0x
	* ap_mlo_cap	1byte			0x
	* sta_mlo_cap	1byte			0x
	*/
	unsigned char *p = pkt;
	unsigned char ap_mlo = 0, sta_mlo = 0;
	unsigned char i = 0;

	/*vendor specific tlv type*/
	*p++ = VENDOR_SPECIFIC_TLV_TYPE;

	/*vendor specific tlv length*/
	*((unsigned short *)(p)) = host_to_be16(12);
	p += 2;

	/*oui*/
	os_memcpy(p, OUI_MEDIATEK, OUI_LEN);
	p += 3;

	/*function type*/
	*p++ = MLO_CAP_ANNOUNCE_TYPE;

	os_memcpy(p, mlo_cap->identifier, ETH_ALEN);
	p += ETH_ALEN;
	notice(DEBUG_CAT_MLO, "radio "MACSTR"\n", MAC2STR(mlo_cap->identifier));

	for (i = 0; i < mlo_cap->role_num; i++) {
		if (mlo_cap->role_cap[i].dev_role == 0 &&
			mlo_cap->role_cap[i].mlo_enable)
			ap_mlo = 1;
		if (mlo_cap->role_cap[i].dev_role == 1 &&
			mlo_cap->role_cap[i].mlo_enable)
			sta_mlo = 1;
		notice(DEBUG_CAT_MLO, "role %d, mlo enable %d\n", i, mlo_cap->role_cap[i].mlo_enable);
	}

	*p++ = ap_mlo;
	*p++ = sta_mlo;

	return p - pkt;
}


int build_mld_affiliated_ap(unsigned char *temp_buf, struct affiliated_ap_db *aff_ap)
{
	int totol_len = 0;

	/* Affiliated_AP_MAC_Addr_Valid */
	*temp_buf = 0;
	if (!is_zero_ether_addr(aff_ap->affiliated_ap_bssid))
		*temp_buf |= 0x80;
	if (aff_ap->link_id)
		*temp_buf |= 0x40;
	temp_buf++;
	totol_len += 1;

	/* RUID */
	os_memcpy(temp_buf, aff_ap->ruid, ETH_ALEN);
	temp_buf += ETH_ALEN;
	totol_len += ETH_ALEN;
	info(DEBUG_CAT_MLO, "ruid "MACSTR"", MAC2STR(aff_ap->ruid));

	/* Affiliated_AP_MAC_Addr */
	os_memcpy(temp_buf, aff_ap->affiliated_ap_bssid, ETH_ALEN);
	temp_buf += ETH_ALEN;
	totol_len += ETH_ALEN;
	info_np(DEBUG_CAT_MLO, ", bssid "MACSTR"", MAC2STR(aff_ap->affiliated_ap_bssid));

	/* link id */
	*temp_buf++ = aff_ap->link_id;
	totol_len += 1;
	info_np(DEBUG_CAT_MLO, ", link_id %d\n", aff_ap->link_id);

	/* Reserved 18 bytes */
	os_memset(temp_buf, 0, 18);
	temp_buf += 18;
	totol_len += 18;

	return totol_len;
}

int append_agent_t2lm_config_tlv(unsigned char *pkt, struct p1905_managerd_ctx *ctx)
{
	unsigned char *temp_buf = NULL, *p = NULL;
	unsigned short total_length = 0;
	int j;
	struct sp_t2lm_db *t2lm_db = NULL, *t2lm_db_tmp = NULL;
	struct ap_t2lm_mapping_db *tlm_map = NULL, *tlm_map_tmp = NULL;

	temp_buf = pkt;

	if (ctx->mlo_t2lm_db.num_mld == 0)
		return total_length;

	dl_list_for_each_safe(t2lm_db, t2lm_db_tmp, &ctx->mlo_t2lm_db.t2lm_cfg_list, struct sp_t2lm_db, list) {
		(*temp_buf) = TID_2_LINK_MAPPING_POLICY_TLV_TYPE;

		p = temp_buf;
		p += 3;
		*p++ = t2lm_db->is_bsta_config ? 0x80 : 0x00;

		os_memcpy(p, t2lm_db->mld_mac, ETH_ALEN);
		p += ETH_ALEN;
		*p++ = t2lm_db->t2lm_negotiation ? 0x80 : 0x00;
		p += 22;
		*((unsigned short *)p) = host_to_be16(t2lm_db->num_mapping);
		p += 2;

		dl_list_for_each_safe(tlm_map, tlm_map_tmp, &t2lm_db->ap_t2lm_mapping, struct ap_t2lm_mapping_db, list) {
			*p++ = tlm_map->add_remove ? 0x80 : 0x00;

			os_memcpy(p, tlm_map->sta_ml_mac, ETH_ALEN);
			p += ETH_ALEN;

			*p++ = tlm_map->t2l_control;
			*p++ = tlm_map->lm_Presence_Indicator;
			*p++ = tlm_map->expected_duration[0];
			*p++ = tlm_map->expected_duration[1];
			*p++ = tlm_map->expected_duration[2];

			for (j = 0; j < MAX_TID_PER_LINK; j++) {
				if (tlm_map->lm_Presence_Indicator & BIT(j)) {
					*((unsigned short *)p) = host_to_be16(tlm_map->t2lm[j]);
					p += 2;
				}
			}
			p += 7;
		}
		*(unsigned short *)(temp_buf + 1) = host_to_be16((p - temp_buf) - 3);
		temp_buf = p;
	}
	total_length = (unsigned short)(temp_buf - pkt);
	return total_length;
}

int append_agent_ap_mld_config_tlv(unsigned char *pkt, struct p1905_managerd_ctx *ctx, unsigned char *al_mac)
{
	unsigned char *temp_buf = NULL;
	unsigned char *p_num_ap_mld = NULL;
	unsigned char *p_aff_num = NULL;
	unsigned short total_length = 0;
	int aff_ap_len = 0;
	/* free mld bss info after each using */
	struct mld_bss_config_db *mld_bss = NULL;
	struct affiliated_ap_db *aff_ap = NULL, *aff_ap_tmp = NULL;
	struct affiliated_ap_db add_aff_ap = {0};
	struct mlo_config_db *mlo_cfg = NULL, *mlo_cfg_tmp = NULL;
	struct agent_list_db *agent = NULL;
	int ret = 0;
	unsigned char ap_added = 0;
	unsigned char *p_mld_mac_valid = NULL;
	unsigned char *p_mld_mac = NULL;
	int ra_idx = 0, ap_mlo_enable = 0;

	temp_buf = pkt;
	(*temp_buf) = AGENT_AP_MLD_CONFIG_TLV_TYPE;
	temp_buf += 3;

	mld_bss = get_agent_ap_mld(ctx, al_mac);
	if (!mld_bss) {
		err(DEBUG_CAT_MLO, "no agent ap mld found by almac "MACSTR"\n", MAC2STR(al_mac));
		goto error;
	}

	if (mld_bss->num_ap_mld == 0) {
		info(DEBUG_CAT_MLO, "no ap mld group setting for almac "MACSTR"\n", MAC2STR(al_mac));
		goto error;
	}

	find_agent_info(ctx, al_mac, &agent);
	if (!agent) {
		err(DEBUG_CAT_MLO, "no agent info found by almac "MACSTR"\n", MAC2STR(al_mac));
		goto error;
	}

	for (ra_idx = 0; ra_idx < ctx->radio_number; ra_idx++) {
		if (agent->ap_mlo_cap[ra_idx]) {
			ap_mlo_enable = 1;
			break;
		}
	}

	if (!ap_mlo_enable)
		goto error;

	update_agt_ap_mld_info(mld_bss, &agent->mld_cfg);
	info_dump_agent_ap_mld(mld_bss);

	/* numAPMLDs */
	*temp_buf = 0;
	p_num_ap_mld = temp_buf;
	temp_buf++;

	dl_list_for_each_safe(mlo_cfg, mlo_cfg_tmp, &mld_bss->mlo_cfg_list, struct mlo_config_db, list) {

		if (dl_list_empty(&mlo_cfg->aff_ap_list))
			continue;

		*p_num_ap_mld += 1;
		/* AP_MLD_MAC_Addr_Valid */
		*temp_buf = 0;
		p_mld_mac_valid = temp_buf;
		if (!is_zero_ether_addr(mlo_cfg->mld_mac))
			*temp_buf |= 0x80;
		temp_buf++;

		/* ssidLength */
		*temp_buf++ = mlo_cfg->ssid_len;
		/* ssid */
		os_memcpy(temp_buf, mlo_cfg->ssid, mlo_cfg->ssid_len);
		temp_buf += mlo_cfg->ssid_len;
		info(DEBUG_CAT_MLO, "ssid %s, mld grp id %d", mlo_cfg->ssid, mlo_cfg->mld_grp_id);

		/* MLD_MAC_Addr */
		p_mld_mac = temp_buf;
		os_memcpy(temp_buf, mlo_cfg->mld_mac, ETH_ALEN);
		info_np(DEBUG_CAT_MLO, ", mld mac "MACSTR"\n", MAC2STR(mlo_cfg->mld_mac));
		temp_buf += ETH_ALEN;

		/* STR, NSTR, EMLSR, EMLMR bit */
		*temp_buf = 0;
		if (mlo_cfg->ap_str_support)
			*temp_buf |= 0x80;
		if (mlo_cfg->ap_nstr_support)
			*temp_buf |= 0x40;
		if (mlo_cfg->ap_emlsr_support)
			*temp_buf |= 0x20;
		if (mlo_cfg->ap_emlmr_support)
			*temp_buf |= 0x10;
		temp_buf += 1;

		/* 20 reserved bytes */
		os_memset(temp_buf, 0, 20);
		temp_buf += 20;

		/* numAffiliatedAPs */
		p_aff_num = temp_buf;
		*temp_buf++ = 0;

		dl_list_for_each_safe(aff_ap, aff_ap_tmp, &mlo_cfg->aff_ap_list, struct affiliated_ap_db, list) {
#ifdef MAP_R6
			info(DEBUG_CAT_MLO, "aff_num %d\n", *p_aff_num);
			if ((*p_aff_num) >= agent->wifi7_mlo_cap.ap_max_link + 1) {
				info(DEBUG_CAT_MLO, "skip %d one\n", (*p_aff_num));
				break;
			}
#endif
			/* ap mld link removal from existed links */
			if ((os_memcmp(aff_ap->ruid, ctx->mld_chg.ruid, ETH_ALEN) == 0) &&
				(ctx->mld_chg.type == MLD_AP_LINK_CHANGE && ctx->mld_chg.action == MLD_LINK_RM)) {
				*p_mld_mac_valid = 0x80;
				os_memcpy(p_mld_mac, ctx->mld_chg.mld_mac, ETH_ALEN);
				info(DEBUG_CAT_MLO, "ap mld link removal "MACSTR",", MAC2STR(aff_ap->ruid));
				info_np(DEBUG_CAT_MLO, "alter mld mac "MACSTR"\n", MAC2STR(p_mld_mac));
				continue;
			}

			/* ap mld link addition from existed links */
			if ((os_memcmp(aff_ap->ruid, ctx->mld_chg.ruid, ETH_ALEN) == 0) &&
				(ctx->mld_chg.type == MLD_AP_LINK_CHANGE && ctx->mld_chg.action == MLD_LINK_ADD)) {
				ap_added = 1;
				*p_mld_mac_valid = 0x80;
				os_memcpy(p_mld_mac, ctx->mld_chg.mld_mac, ETH_ALEN);
				info(DEBUG_CAT_MLO, "ap mld link addition(existed) "MACSTR",", MAC2STR(aff_ap->ruid));
				info_np(DEBUG_CAT_MLO, "alter mld mac "MACSTR"\n", MAC2STR(p_mld_mac));
			}

			aff_ap_len = build_mld_affiliated_ap(temp_buf, aff_ap);
			temp_buf += aff_ap_len;
			*p_aff_num += 1;
		}

		/* ap mld link addition if no this link in wts_bss_info_config */
		if (!ap_added &&
			ctx->mld_chg.type == MLD_BSTA_LINK_CHANGE &&
			ctx->mld_chg.action == MLD_LINK_ADD) {
			ret = is_zero_ether_addr(ctx->mld_chg.bssid);
			if (!ret)
				add_aff_ap.affiliated_ap_valid = 1;
			add_aff_ap.link_id = ctx->mld_chg.link_id;
			os_memcpy(add_aff_ap.ruid, ctx->mld_chg.ruid, ETH_ALEN);
			os_memcpy(add_aff_ap.affiliated_ap_bssid, ctx->mld_chg.bssid, ETH_ALEN);
			info_np(DEBUG_CAT_MLO, "bsta mld link addtion(non-existed) "MACSTR"\n", MAC2STR(add_aff_ap.ruid));
			aff_ap_len = build_mld_affiliated_ap(temp_buf, &add_aff_ap);
			temp_buf += aff_ap_len;
			*p_aff_num += 1;
		}
		info(DEBUG_CAT_MLO, "\taffiliated ap cnt %d\n", *p_aff_num);
	}

	total_length = (unsigned short)(temp_buf - pkt);

	*(unsigned short *)(pkt + 1) = host_to_be16(total_length - 3);
error:
	return total_length;
}


int append_own_ap_mld_config_tlv(unsigned char *pkt, struct p1905_managerd_ctx *ctx)
{
	unsigned char *temp_buf = NULL;
	unsigned char *p_num_ap_mld = NULL;
	unsigned char *p_aff_num = NULL;
	unsigned short total_length = 0;
	int aff_ap_len = 0;
	/* free mld bss info after each using */
	struct mld_bss_config_db *mld_bss = NULL;
	struct affiliated_ap_db *aff_ap = NULL, *aff_ap_tmp = NULL;
	struct mlo_config_db *mlo_cfg = NULL, *mlo_cfg_tmp = NULL;

	temp_buf = pkt;
	(*temp_buf) = AGENT_AP_MLD_CONFIG_TLV_TYPE;
	temp_buf += 3;

	mld_bss = &ctx->opcls_mld_cfg;

	/* numAPMLDs */
	*temp_buf = 0;
	p_num_ap_mld = temp_buf;
	temp_buf++;

	dl_list_for_each_safe(mlo_cfg, mlo_cfg_tmp, &mld_bss->mlo_cfg_list, struct mlo_config_db, list) {
		if (dl_list_empty(&mlo_cfg->aff_ap_list))
			continue;

		*p_num_ap_mld += 1;

		/* AP_MLD_MAC_Addr_Valid */
		*temp_buf = 0;
		if (!is_zero_ether_addr(mlo_cfg->mld_mac))
			*temp_buf |= 0x80;

		temp_buf++;

		/* ssidLength */
		*temp_buf++ = mlo_cfg->ssid_len;
		/* ssid */
		os_memcpy(temp_buf, mlo_cfg->ssid, mlo_cfg->ssid_len);
		temp_buf += mlo_cfg->ssid_len;
		info(DEBUG_CAT_MLO, "\nssid %s, mld grp id %d", mlo_cfg->ssid, mlo_cfg->mld_grp_id);

		/* MLD_MAC_Addr */
		os_memcpy(temp_buf, mlo_cfg->mld_mac, ETH_ALEN);
		info_np(DEBUG_CAT_MLO, ", mld mac "MACSTR", affiliated ap cnt %d\n",
			MAC2STR(mlo_cfg->mld_mac), mlo_cfg->num_affiliated_ap);
		temp_buf += ETH_ALEN;

		/* STR, NSTR, EMLSR, EMLMR bit */
		*temp_buf = 0;
		if (mlo_cfg->ap_str_support)
			*temp_buf |= 0x80;
		if (mlo_cfg->ap_nstr_support)
			*temp_buf |= 0x40;
		if (mlo_cfg->ap_emlsr_support)
			*temp_buf |= 0x20;
		if (mlo_cfg->ap_emlmr_support)
			*temp_buf |= 0x10;
		temp_buf += 1;

		/* 20 reserved bytes */
		os_memset(temp_buf, 0, 20);
		temp_buf += 20;

		/* numAffiliatedAPs */
		p_aff_num = temp_buf;
		*temp_buf++ = 0;

		dl_list_for_each_safe(aff_ap, aff_ap_tmp, &mlo_cfg->aff_ap_list, struct affiliated_ap_db, list) {
			aff_ap_len = build_mld_affiliated_ap(temp_buf, aff_ap);
			temp_buf += aff_ap_len;
			*p_aff_num += 1;
		}
	}

	total_length = (unsigned short)(temp_buf - pkt);

	*(unsigned short *)(pkt + 1) = host_to_be16(total_length - 3);

	return total_length;
}




#ifdef MAP_R6
int build_mld_affiliated_bsta(unsigned char *temp_buf, struct affiliated_sta_db *aff_sta)
{
	int totol_len = 0;

	/* Affiliated_bSTA_MAC_Addr_Valid	bit 7 */
	*temp_buf++ = 0;
	totol_len += 1;

	/* RUID 6 octets */
	os_memcpy(temp_buf, aff_sta->ruid, ETH_ALEN);
	temp_buf += ETH_ALEN;
	totol_len += ETH_ALEN;
	info_np(DEBUG_CAT_MLO, "ruid "MACSTR"", MAC2STR(aff_sta->ruid));

	/* Affilated_bSTA_MAC_Addr	6 octets*/
	os_memcpy(temp_buf, aff_sta->affiliated_sta_bssid, ETH_ALEN);
	temp_buf += ETH_ALEN;
	totol_len += ETH_ALEN;
	info_np(DEBUG_CAT_MLO, ", bssid "MACSTR"\n", MAC2STR(aff_sta->affiliated_sta_bssid));

	/* 19 bytes reserved */
	os_memset(temp_buf, 0, 19);
	temp_buf += 19;
	totol_len += 19;

	return totol_len;
}

int append_bsta_mld_config_tlv(unsigned char *pkt, struct p1905_managerd_ctx *ctx, unsigned char *al_mac)
{
	unsigned char *temp_buf = NULL;
	unsigned char sta_idx = 0;
	unsigned char ridx = 0;
	unsigned short total_length = 0;
	int aff_sta_len = 0;
	struct bh_mld_bsta_config *mldinfo = NULL;
	struct mld_bsta_config_db *bsta_db = NULL;
	struct affiliated_sta_db *aff_sta = NULL;
	struct affiliated_sta_db add_aff_sta = {0};
	struct agent_list_db *agent = NULL;
	unsigned char *p_aff_num = NULL;
	unsigned char bsta_added = 0;
	unsigned char wildcard_mac[ETH_ALEN] = {0xff, 0xff, 0xff, 0xff, 0xff, 0xff};
	int sta_mlo_enable = 0;

	temp_buf = pkt;
	(*temp_buf) = BSTA_MLD_CONFIG_TLV_TYPE;

	temp_buf += 3;

	if (ctx->role == CONTROLLER) {
		find_agent_info(ctx, al_mac, &agent);
		if (!agent) {
			notice(DEBUG_CAT_MLO, "not found agent by almac "MACSTR"\n", MAC2STR(al_mac));
			return 0;
		}

		for (ridx = 0; ridx < ctx->radio_number; ridx++) {
			if (agent->sta_mlo_cap[ridx]) {
				sta_mlo_enable = 1;
				break;
			}
		}
		if (!sta_mlo_enable) {
			notice(DEBUG_CAT_MLO, "agent "MACSTR" not support bsta mlo\n", MAC2STR(al_mac));
			return 0;
		}

		if (dl_list_empty(&ctx->agent_bsta_list)) {
			notice(DEBUG_CAT_MLO, "bsta list is empty, skip\n");
			return 0;
		}
		info(DEBUG_CAT_MLO, "almac from outside "MACSTR"\n", MAC2STR(al_mac));
		dl_list_for_each(bsta_db, &ctx->agent_bsta_list, struct mld_bsta_config_db, list) {
			info(DEBUG_CAT_MLO, "almac "MACSTR" in wts file\n", MAC2STR(bsta_db->al_mac));

			/* match bss once:
			 *    1. wildcard almac from wts bsta file
			 *    2. almac from wts btsa file equals to dest almac
			 */
			if (os_memcmp(bsta_db->al_mac, wildcard_mac, ETH_ALEN) &&
				os_memcmp(bsta_db->al_mac, al_mac, ETH_ALEN))
				continue;

			info(DEBUG_CAT_MLO, "almac "MACSTR"\n", MAC2STR(al_mac));
			update_affilliated_sta_ruid(bsta_db, agent);
			if (ctx->MAP_Cer)
				update_affilliated_sta_mac(bsta_db, &agent->bsta_mld);
			break;
		}

		if (!bsta_db) {
			err(DEBUG_CAT_MLO, "not found agent bsta DB by almac "MACSTR"\n", MAC2STR(al_mac));
			return 0;
		}

		/* MLD_MAC_Addr_Valid	bit 7
		 * BSS_MLD_MAC_Addr_valid	bit 6
		*/
		*temp_buf++ = 0;

		/* MLD_MAC_Addr */
		os_memset(temp_buf, 0, ETH_ALEN);
		temp_buf += ETH_ALEN;

		/* BSS_MLD_MAC_Addr */
		os_memset(temp_buf, 0, ETH_ALEN);
		temp_buf += ETH_ALEN;

		/* STR	bit 7
		 * NSTR bit 6
		 * EMLSR	bit 5
		 * EMLMR	bit 4
		*/
		*temp_buf = 0;
		if (agent->wifi7_mlo_cap.ap_str_support)
			*temp_buf |= 0x80;
		if (agent->wifi7_mlo_cap.ap_nstr_support)
			*temp_buf |= 0x40;
		if (agent->wifi7_mlo_cap.ap_emlsr_support)
			*temp_buf |= 0x20;
		if (agent->wifi7_mlo_cap.ap_emlmr_support)
			*temp_buf |= 0x10;
		temp_buf += 1;

		/* 17 bytes reserved */
		os_memset(temp_buf, 0, 17);
		temp_buf += 17;

		/* numAffiliatedbSTAs	1 octet */
		p_aff_num = temp_buf;
		*temp_buf++ = 0;

		dl_list_for_each(aff_sta, &bsta_db->affiliated_sta_list, struct affiliated_sta_db, list) {
			if (agent->wifi7_mlo_cap.bsta_max_link &&
				((*p_aff_num) >= agent->wifi7_mlo_cap.bsta_max_link + 1))
				break;
			if (is_zero_ether_addr(aff_sta->ruid))
				continue;
			for (ridx = 0; ridx < MAX_RADIO_NUM; ridx++) {
				if (!os_memcmp(agent->ra_info[ridx].identifier, aff_sta->ruid, ETH_ALEN))
					break;
			}
			if (ridx >= MAX_RADIO_NUM)
				continue;

			/* bsta mld link removal from existed links */
			if ((os_memcmp(aff_sta->ruid, ctx->mld_chg.ruid, ETH_ALEN) == 0) &&
				(ctx->mld_chg.type == MLD_BSTA_LINK_CHANGE && ctx->mld_chg.action == MLD_LINK_RM)) {
				notice(DEBUG_CAT_MLO, "bsta mld link removal "MACSTR"\n", MAC2STR(aff_sta->ruid));
				continue;
			}
			/* bsta mld link addition from existed links */
			if ((os_memcmp(aff_sta->ruid, ctx->mld_chg.ruid, ETH_ALEN) == 0) &&
				(ctx->mld_chg.type == MLD_BSTA_LINK_CHANGE && ctx->mld_chg.action == MLD_LINK_ADD)) {
				bsta_added = 1;
				notice(DEBUG_CAT_MLO, "bsta mld link addition(existed) "MACSTR"\n", MAC2STR(aff_sta->ruid));
			}

			aff_sta_len = build_mld_affiliated_bsta(temp_buf, aff_sta);
			temp_buf += aff_sta_len;
			*p_aff_num += 1;
		}

		/* bsta mld link addition if no this link in wts_bsta_mlo_config */
		if (!bsta_added &&
			ctx->mld_chg.type == MLD_BSTA_LINK_CHANGE &&
			ctx->mld_chg.action == MLD_LINK_ADD) {
			add_aff_sta.bitmap = 0;
			os_memcpy(add_aff_sta.ruid, ctx->mld_chg.ruid, ETH_ALEN);
			os_memcpy(add_aff_sta.affiliated_sta_bssid, ctx->mld_chg.bssid, ETH_ALEN);
			notice(DEBUG_CAT_MLO, "bsta mld link addtion(non-existed) "MACSTR"\n", MAC2STR(add_aff_sta.ruid));
			aff_sta_len = build_mld_affiliated_bsta(temp_buf, &add_aff_sta);
			temp_buf += aff_sta_len;
			*p_aff_num += 1;
		}
		info(DEBUG_CAT_MLO, "num affiliated sta %d\n", *p_aff_num);
	} else {
		mldinfo = &ctx->mld_bsta_info;
		if (is_zero_ether_addr(mldinfo->mld_mac) || (!mldinfo->num_affiliated_sta))
			return 0;

		/* MLD_MAC_Addr_Valid	bit 7
		 * BSS_MLD_MAC_Addr_valid	bit 6
		*/
		*temp_buf++ = mldinfo->mld_mac_bitmap;
		info(DEBUG_CAT_MLO, "mld_mac_bitmap %02x", mldinfo->mld_mac_bitmap);

		/* MLD_MAC_Addr */
		os_memcpy(temp_buf, mldinfo->mld_mac, ETH_ALEN);
		temp_buf += ETH_ALEN;
		info_np(DEBUG_CAT_MLO, ", sta mld "MACSTR"", MAC2STR(mldinfo->mld_mac));

		/* BSS_MLD_MAC_Addr */
		os_memcpy(temp_buf, mldinfo->bss_mld_mac, ETH_ALEN);
		temp_buf += ETH_ALEN;
		info_np(DEBUG_CAT_MLO, ", ap mld "MACSTR"", MAC2STR(mldinfo->bss_mld_mac));

		/* STR	bit 7
		 * NSTR	bit 6
		 * EMLSR	bit 5
		 * EMLMR	bit 4
		*/
		*temp_buf++ = mldinfo->switch_bitmap;
		info_np(DEBUG_CAT_MLO, ", switch_bitmap %02x", mldinfo->switch_bitmap);

		/* 17 bytes reserved */
		os_memset(temp_buf, 0, 17);
		temp_buf += 17;

		/* numAffiliatedbSTAs	1 octet */
		*temp_buf++ = mldinfo->num_affiliated_sta;
		info_np(DEBUG_CAT_MLO, ", affiliated sta cnt %d\n", mldinfo->num_affiliated_sta);

		for (sta_idx = 0; sta_idx < mldinfo->num_affiliated_sta; sta_idx++) {
			/* Affiliated_bSTA_MAC_Addr_Valid	bit 7 */
			*temp_buf++ = mldinfo->sta[sta_idx].bitmap;
			info(DEBUG_CAT_MLO, "\t sta bitmap %02x", mldinfo->sta[sta_idx].bitmap);

			/* RUID	6 octets */
			os_memcpy(temp_buf, mldinfo->sta[sta_idx].ruid, ETH_ALEN);
			temp_buf += ETH_ALEN;
			info(DEBUG_CAT_MLO, ", ruid "MACSTR"", MAC2STR(mldinfo->sta[sta_idx].ruid));

			/* Affilated_bSTA_MAC_Addr	6 octets */
			os_memcpy(temp_buf, mldinfo->sta[sta_idx].affiliated_sta_bssid, ETH_ALEN);
			temp_buf += ETH_ALEN;
			info(DEBUG_CAT_MLO, ", affiliated_sta_bssid "MACSTR"\n", MAC2STR(mldinfo->sta[sta_idx].affiliated_sta_bssid));

			/* 19 bytes reserved */
			os_memset(temp_buf, 0, 19);
			temp_buf += 19;
		}
	}

	total_length = (unsigned short)(temp_buf - pkt);

	*(unsigned short *)(pkt + 1) = host_to_be16(total_length - 3);

	return total_length;
}

#endif
unsigned short append_eht_operations_tlv(struct p1905_managerd_ctx *ctx, unsigned char *pkt)
{
	unsigned short total_length = 0;
	unsigned char *p_num_radio = NULL;
	unsigned char *p_num_bss = NULL;
	unsigned char *temp_buf = pkt;
	unsigned char idx = 0;
	unsigned char zero_mac[ETH_ALEN] = {0};
	struct eht_operations_db *config = NULL;
	struct eht_operations_info_db *record = NULL;

	*temp_buf++ = EHT_OPERATION_TLV_TYPE;
	temp_buf += 2;

	/* 32 bytes reserved */
	os_memset(temp_buf, 0, 32);
	temp_buf += 32;

	/* numRadios */
	p_num_radio = temp_buf;
	*p_num_radio = 0;
	temp_buf += 1;

	for (idx = 0; idx < MAX_RADIO_NUM; idx++) {
		config = &ctx->ap_cap_entry.eht_op[idx];
		if (os_memcmp(zero_mac, config->ruid, ETH_ALEN) == 0)
			break;

		*p_num_radio += 1;

		/* RUID */
		os_memcpy(temp_buf, config->ruid, ETH_ALEN);
		temp_buf += ETH_ALEN;

		/* numBSSs */
		p_num_bss = temp_buf;
		*p_num_bss = 0;
		temp_buf += 1;
		dl_list_for_each(record, &config->eht_op_list,
			struct eht_operations_info_db, list) {
			*p_num_bss += 1;

			/* BSSID */
			os_memcpy(temp_buf, record->bssid, ETH_ALEN);
			temp_buf += ETH_ALEN;

			/* EHT_Operation_Information_Valid bit 7
			 * Disabled_Subchannel_Valid	bit 6
			 * EHT Default PE Duration bit 5
			 * Group Addressed BU Indication Limit bit 4
			 * Group Addressed BU Indication Exponent	bits 3-2
			*/
			*temp_buf = 0;
			if (record->eht_operation_information_valid)
				*temp_buf |= 0x80;
			if (record->dscb_bitmap)
				*temp_buf |= 0x40;
			if (record->eht_default_pe_duration)
				*temp_buf |= 0x20;
			if (record->group_addressed_BU_indication_limit)
				*temp_buf |= 0x10;
			if (record->group_addressed_BU_indication_exponent)
				*temp_buf |= 0x04;
			temp_buf += 1;

			/* Basic EHT-MCS And Nss Set */
			os_memcpy(temp_buf, &record->eht_mcs_nss_set, sizeof(struct eht_mcs_nss));
			temp_buf += sizeof(struct eht_mcs_nss);

			/* Control */
			*temp_buf++ = record->control;
			/* CCFS0 */
			*temp_buf++ = record->ccfs0;
			/* CCFS1 */
			*temp_buf++ = record->ccfs1;

			/* Disabled_Subchannel_Bitmap */
			*(unsigned short *)temp_buf = host_to_be16(record->dscb_bitmap);
			temp_buf += 2;

			/* 16 bytes reserved */
			os_memset(temp_buf, 0, 16);
			temp_buf += 16;
		}

		/* 25 bytes reserved */
		os_memset(temp_buf, 0, 25);
		temp_buf += 25;
	}

	if (*p_num_radio == 0)
		return 0;

	total_length = (unsigned short)(temp_buf - pkt);

	*(unsigned short *)(pkt + 1) = host_to_be16(total_length - 3);
	return total_length;
}
#if defined(MAP_R6) || defined(EM_PLUS_SUPPORT)
unsigned short append_wifi7_cap_tlv(struct p1905_managerd_ctx *ctx, unsigned char *pkt)
{
	unsigned short total_length = 0;
	unsigned char *p_num_radio = NULL;
	unsigned char maxNumMld = 0;
	unsigned char apMaxLink = 0;
	unsigned char staMaxLink = 0;
	unsigned char tidLinkMap = 0;
	unsigned char *temp_buf = pkt;

	struct wifi7_mlo_cap_db *cap = NULL, *cap_tmp = NULL;
	struct mlo_record_db *record = NULL, *record_tmp = NULL;

	*temp_buf = WIFI7_AGENT_CAPABILITY_TLV_TYPE;

	temp_buf += 3;

	cap = (struct wifi7_mlo_cap_db *)dl_list_first(
		&ctx->ap_cap_entry.wifi7_mlo_cap_list, struct wifi7_mlo_cap_db, list);
	if (cap) {
		maxNumMld = cap->max_num_mld;
		apMaxLink = cap->ap_max_link;
		staMaxLink = cap->bsta_max_link;
#ifdef MAP_R6
		if (ctx->mlo_max_links > 0) {
			apMaxLink = ctx->mlo_max_links - 1;
			staMaxLink = ctx->mlo_max_links - 1;
		}
#endif
		tidLinkMap = cap->tid_to_link_map;
	} else {
		maxNumMld = 0;
		apMaxLink = 1;
		staMaxLink = 1;
		tidLinkMap = 0;
	}

	/* MaxNumMLDs */
	*temp_buf++ = maxNumMld;
	info(DEBUG_CAT_MLO, "maxNumMld %d", maxNumMld);

	*temp_buf = 0;
	/* AP Maximum Links	bits 7-4 */
	*temp_buf |= (apMaxLink << 4) & 0xf0;
	/* bSTA Maximum Links	bits 3-0 */
	*temp_buf |= staMaxLink & 0x0f;
	info_np(DEBUG_CAT_MLO, ", max_link byte %02x", *temp_buf);
	temp_buf += 1;

	/* TID-To-Link Mapping, bit 7-6
	 * 0: The Agent does not support TID-to-Link mapping
	 * 1: The Agent supports the mapping of each TID to the same or different link set.
	 * 2: The Agent only supports the mapping of all TIDs to the same link set.
	 * 3: Reserved
	*/
	*temp_buf = 0;
	*temp_buf++ |= (tidLinkMap << 6) & 0xC0;
	info_np(DEBUG_CAT_MLO, ", tidLinkMap %02x\n", tidLinkMap);

	/* reserved 13 bytes */
	os_memset(temp_buf, 0, 13);
	temp_buf += 13;

	/* num of Radios */
	p_num_radio = temp_buf;
	*p_num_radio = 0;
	temp_buf += 1;

	dl_list_for_each_safe(cap, cap_tmp, &ctx->ap_cap_entry.wifi7_mlo_cap_list,
		struct wifi7_mlo_cap_db, list) {
		*p_num_radio += 1;
		info_np(DEBUG_CAT_MLO, "radio idx %d", *p_num_radio);

		/* RUID */
		os_memcpy(temp_buf, cap->identifier, ETH_ALEN);
		temp_buf += ETH_ALEN;
		info_np(DEBUG_CAT_MLO, ", radio ruid "MACSTR"", MAC2STR(cap->identifier));

		/* reserved 24 bytes */
		os_memset(temp_buf, 0, 24);
		temp_buf += 24;

		/* AP STR NSTR, EMLSR, EMLMR Support */
		*temp_buf = 0;
		if (cap->ap_str_support)
			*temp_buf |= 0x80;
		if (cap->ap_nstr_support)
			*temp_buf |= 0x40;
		if (cap->ap_emlsr_support)
			*temp_buf |= 0x20;
		if (cap->ap_emlmr_support)
			*temp_buf |= 0x10;
		temp_buf += 1;
		info_np(DEBUG_CAT_MLO, ",(AP) STR %d, NSTR %d, EMLSR %d, EMLMR %d",
			cap->ap_str_support, cap->ap_nstr_support,
			cap->ap_emlsr_support, cap->ap_emlmr_support);

		/* bSTA STR,NSTR, EMLSR, EMLMR Support */
		*temp_buf = 0;
		if (cap->sta_str_support)
			*temp_buf |= 0x80;
		if (cap->sta_nstr_support)
			*temp_buf |= 0x40;
		if (cap->sta_emlsr_support)
			*temp_buf |= 0x20;
		if (cap->sta_emlmr_support)
			*temp_buf |= 0x10;
		temp_buf += 1;
		info_np(DEBUG_CAT_MLO, " ,(BSTA) STR %d, NSTR %d, EMLSR %d, EMLMR %d\n",
			cap->sta_str_support, cap->sta_nstr_support,
			cap->sta_emlsr_support, cap->sta_emlmr_support);

		/* num_AP_STR_Records */
		*temp_buf++ = cap->num_ap_str_records;
		dl_list_for_each_safe(record, record_tmp, &cap->ap_str_record_list,
			struct mlo_record_db, list) {
			/* RUID */
			os_memcpy(temp_buf, record->identifier, ETH_ALEN);
			temp_buf += ETH_ALEN;

			/* AP_STR_Freq_Separation	bits 7-3 */
			*temp_buf = 0;
			*temp_buf++ = (record->freq_separation << 3) & 0xf8;
		}

		/* num_AP_NSTR_Records */
		*temp_buf++ = cap->num_ap_nstr_records;
		dl_list_for_each_safe(record, record_tmp, &cap->ap_nstr_record_list,
			struct mlo_record_db, list) {
			/* RUID */
			os_memcpy(temp_buf, record->identifier, ETH_ALEN);
			temp_buf += ETH_ALEN;

			/* AP_STR_Freq_Separation	bits 7-3 */
			*temp_buf = 0;
			*temp_buf++ = (record->freq_separation << 3) & 0xf8;
		}

		/* num_AP_EMLSR_Records */
		*temp_buf++ = cap->num_ap_emlsr_records;
		dl_list_for_each_safe(record, record_tmp, &cap->ap_emlsr_record_list,
			struct mlo_record_db, list) {
			/* RUID */
			os_memcpy(temp_buf, record->identifier, ETH_ALEN);
			temp_buf += ETH_ALEN;

			/* AP_STR_Freq_Separation	bits 7-3 */
			*temp_buf = 0;
			*temp_buf++ = (record->freq_separation << 3) & 0xf8;
		}

		/* num_AP_EMLMR_Records */
		*temp_buf++ = cap->num_ap_emlmr_records;
		dl_list_for_each_safe(record, record_tmp, &cap->ap_emlmr_record_list,
			struct mlo_record_db, list) {
			/* RUID */
			os_memcpy(temp_buf, record->identifier, ETH_ALEN);
			temp_buf += ETH_ALEN;

			/* AP_STR_Freq_Separation	bits 7-3 */
			*temp_buf = 0;
			*temp_buf++ = (record->freq_separation << 3) & 0xf8;
		}

		/* num_STA_STR_Records */
		*temp_buf++ = cap->num_sta_str_records;
		dl_list_for_each_safe(record, record_tmp, &cap->sta_str_record_list,
			struct mlo_record_db, list) {
			/* RUID */
			os_memcpy(temp_buf, record->identifier, ETH_ALEN);
			temp_buf += ETH_ALEN;

			/* AP_STR_Freq_Separation	bits 7-3 */
			*temp_buf = 0;
			*temp_buf++ = (record->freq_separation << 3) & 0xf8;
		}

		/* num_STA_NSTR_Records */
		*temp_buf++ = cap->num_sta_nstr_records;
		dl_list_for_each_safe(record, record_tmp, &cap->sta_nstr_record_list,
			struct mlo_record_db, list) {
			/* RUID */
			os_memcpy(temp_buf, record->identifier, ETH_ALEN);
			temp_buf += ETH_ALEN;

			/* AP_STR_Freq_Separation	bits 7-3 */
			*temp_buf = 0;
			*temp_buf++ = (record->freq_separation << 3) & 0xf8;
		}

		/* num_STA_EMLSR_Records */
		*temp_buf++ = cap->num_sta_emlsr_records;
		dl_list_for_each_safe(record, record_tmp, &cap->sta_emlsr_record_list,
			struct mlo_record_db, list) {
			/* RUID */
			os_memcpy(temp_buf, record->identifier, ETH_ALEN);
			temp_buf += ETH_ALEN;

			/* AP_STR_Freq_Separation	bits 7-3 */
			*temp_buf = 0;
			*temp_buf++ = (record->freq_separation << 3) & 0xf8;
		}

		/* num_STA_EMLMR_Records */
		*temp_buf++ = cap->num_sta_emlmr_records;
		dl_list_for_each_safe(record, record_tmp, &cap->sta_emlmr_record_list,
			struct mlo_record_db, list) {
			/* RUID */
			os_memcpy(temp_buf, record->identifier, ETH_ALEN);
			temp_buf += ETH_ALEN;

			/* AP_STR_Freq_Separation	bits 7-3 */
			*temp_buf = 0;
			*temp_buf++ = (record->freq_separation << 3) & 0xf8;
		}
	}

	total_length = (unsigned short)(temp_buf - pkt);

	*(unsigned short *)(pkt + 1) = host_to_be16(total_length - 3);

	return total_length;
}
#endif

#ifdef MAP_R6
unsigned short append_assoc_sta_mld_cfg_rpt_tlv(struct mlo_sta_config_db *cfg, unsigned char *pkt)
{
	unsigned short total_length = 0;
	unsigned char *temp_buf = pkt;
	struct mlo_sta_db *record = NULL;

	*temp_buf = ASSOCIATED_STA_MLD_CONFIG_REPORT_TLV_TYPE;
	temp_buf += 3;

	/* STA_MLD_MAC_Addr */
	os_memcpy(temp_buf, cfg->sta_mld_mac, ETH_ALEN);
	temp_buf += ETH_ALEN;
	info(DEBUG_CAT_MLO, "sta_mld_mac "MACSTR", ", MAC2STR(cfg->sta_mld_mac));

	/* AP_MLD_MAC_Addr */
	os_memcpy(temp_buf, cfg->ap_mld_mac, ETH_ALEN);
	temp_buf += ETH_ALEN;
	info_np(DEBUG_CAT_MLO, "ap_mld_mac "MACSTR",", MAC2STR(cfg->ap_mld_mac));

	/* one byte for
	 * STR		bit 7
	 * NSTR		bit 6
	 * EMLSR	bit 5
	 * EMLMR	bit 4
	*/
	*temp_buf = 0;
	if (cfg->str_support)
		*temp_buf |= 0x80;
	if (cfg->nstr_support)
		*temp_buf |= 0x40;
	if (cfg->emlsr_support)
		*temp_buf |= 0x20;
	if (cfg->emlmr_support)
		*temp_buf |= 0x10;
	temp_buf += 1;

	/* reserved 18 bytes */
	os_memset(temp_buf, 0, 18);
	temp_buf += 18;

	/* numAffiliatedSTAs */
	*temp_buf++ = cfg->num_affiliates_sta;
	info_np(DEBUG_CAT_MLO, "affi sta num %d\n", cfg->num_affiliates_sta);

	dl_list_for_each(record, &cfg->mlo_sta_list, struct mlo_sta_db, list) {
		/* BSSID */
		os_memcpy(temp_buf, record->bssid, ETH_ALEN);
		temp_buf += ETH_ALEN;
		info_np(DEBUG_CAT_MLO, "\tbssid "MACSTR", ", MAC2STR(record->bssid));

		/* Affilated_STA_MAC_Addr */
		os_memcpy(temp_buf, record->affiliated_sta_mac, ETH_ALEN);
		temp_buf += ETH_ALEN;
		info_np(DEBUG_CAT_MLO, "\taffiliated_sta_mac "MACSTR"\n", MAC2STR(record->affiliated_sta_mac));

		/* reserved 19 bytes */
		os_memcpy(temp_buf, record->reserved, sizeof(record->reserved));
		temp_buf += sizeof(record->reserved);
	}

	total_length = (unsigned short)(temp_buf - pkt);
	*(unsigned short *)(pkt + 1) = host_to_be16(total_length - 3);
	return total_length;
}

#endif

#ifdef BR_IP_TLV_SUPPORT
unsigned short append_br_ip_vendor_tlv(unsigned char *pkt, struct p1905_managerd_ctx *ctx)
{
	unsigned short total_length = 0;
	unsigned char *temp_buf;
	struct br_info brinfo = {0};
	unsigned char msg_len = sizeof(struct br_info);
	u8 MTK_OUI[OUI_LEN] = {0x00, 0x0C, 0xE7};

	memcpy(brinfo.br_name, ctx->br_name, IFNAMSIZ);
	ether_addr_copy(brinfo.br_addr, ctx->br_addr);
	brinfo.br_ip = ctx->br_ip;

	temp_buf = pkt;
	*pkt = VENDOR_SPECIFIC_TLV_TYPE;
	total_length += 1;
	temp_buf += 1;

	/*shift to OUI field*/
	temp_buf += 2;
	total_length += 2;

	/* add mtk oui */
	memcpy(temp_buf, MTK_OUI, OUI_LEN);
	temp_buf += OUI_LEN;
	total_length += OUI_LEN;

	/* vs func type */
	*temp_buf = BR_IP_TYPE;
	temp_buf += 1;
	total_length += 1;

	/* add br_info */
	memcpy(temp_buf, &brinfo, msg_len);
	temp_buf += msg_len;
	total_length += msg_len;

	*(pkt + 1) =  (unsigned char)(((total_length - 3) >> 8) & 0xff);
	*(pkt + 2) =  (unsigned char)((total_length - 3) & 0xff);

	return total_length;
}
#endif /* BR_IP_TLV_SUPPORT */

