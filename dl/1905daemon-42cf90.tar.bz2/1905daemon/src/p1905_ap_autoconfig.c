/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <errno.h>
#include <pthread.h>
#include "p1905_ap_autoconfig.h"
#include "p1905_managerd.h"
#include "cmdu_message.h"
#include "cmdu.h"
#include "multi_ap.h"
#include "_1905_lib_io.h"
#include "debug.h"
#include "eloop.h"
#include "topology.h"
#include "wsc_attr_tlv.h"
#include "cmdu_tlv.h"

#define WSC_TLV_LENGTH 1024
#define CONFIG_SYNC_TOLERATE_TIME 30
#define RENEW_ROUND 4

struct wsc_context {
	struct p1905_managerd_ctx *ctx;
	unsigned char *pkt;
	unsigned char wsc_type;
	WSC_CONFIG config_data;
	unsigned char wfa_vendor_extension;
	unsigned short out_len;
};

char *get_encryption_str(unsigned short encrypt)
{
	switch (encrypt) {
	case ENCRYP_NONE:
		return "ENCRYP_NONE";
	case ENCRYP_WEP:
		return "ENCRYP_WEP";
	case ENCRYP_TKIP:
		return "ENCRYP_TKIP";
	case ENCRYP_AES:
		return "ENCRYP_AES";
	default:
		return "INVALID_ENCRYP";
	}

}

char *get_authmode_str(unsigned short authmode, char *buf, int max_len)
{
	int ret = 0, len = 0;
	unsigned short mode = 0;
	unsigned char i = 0;

	while (authmode) {
		if ((authmode & BIT(i)) == 0) {
			i++;
			if (i == 16)
				break;
			continue;
		}
		mode = BIT(i);
		switch (mode) {
		case AUTH_OPEN:
			ret = snprintf(buf + len, max_len - len, "|%s", "AUTH_OPEN");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_AUTOCONF, "snprintf error\n");
				return "INVALID_AUTH";
			}
			len += ret;
			break;
		case AUTH_WPA_PERSONAL:
			ret = snprintf(buf + len, max_len - len, "|%s", "AUTH_WPA_PERSONAL");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_AUTOCONF, "snprintf error\n");
				return "INVALID_AUTH";
			}
			len += ret;
			break;
		case AUTH_SHARED:
			ret = snprintf(buf + len, max_len - len, "|%s", "AUTH_SHARED");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_AUTOCONF, "snprintf error\n");
				return "INVALID_AUTH";
			}
			len += ret;
			break;
		case AUTH_WPA_ENTERPRISE:
			ret = snprintf(buf + len, max_len - len, "|%s", "AUTH_WPA_ENTERPRISE");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_AUTOCONF, "snprintf error\n");
				return "INVALID_AUTH";
			}
			len += ret;
			break;
		case AUTH_WPA2_ENTERPRISE:
			ret = snprintf(buf + len, max_len - len, "|%s", "AUTH_WPA2_ENTERPRISE");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_AUTOCONF, "snprintf error\n");
				return "INVALID_AUTH";
			}
			len += ret;
			break;
		case AUTH_WPA2_PERSONAL:
			ret = snprintf(buf + len, max_len - len, "|%s", "AUTH_WPA2_PERSONAL");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_AUTOCONF, "snprintf error\n");
				return "INVALID_AUTH";
			}
			len += ret;
			break;
		case AUTH_SAE_PERSONAL:
			ret = snprintf(buf + len, max_len - len, "|%s", "AUTH_SAE_PERSONAL");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_AUTOCONF, "snprintf error\n");
				return "INVALID_AUTH";
			}
			len += ret;
			break;
		case AUTH_DPP_ONLY:
			ret = snprintf(buf + len, max_len - len, "|%s", "AUTH_DPP_ONLY");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_AUTOCONF, "snprintf error\n");
				return "INVALID_AUTH";
			}
			len += ret;
			break;
		case AUTH_AKM_SAE24:
			ret = snprintf(buf + len, max_len - len, "|%s", "AUTH_AKM_SAE24");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_AUTOCONF, "snprintf error\n");
				return "INVALID_AUTH";
			}
			len += ret;
			break;
		case AUTH_OWE:
			ret = snprintf(buf + len, max_len - len, "|%s", "AUTH_OWE");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_AUTOCONF, "snprintf error\n");
				return "INVALID_AUTH";
			}
			len += ret;
			break;
		case AUTH_OWE_TRANSITION:
			ret = snprintf(buf + len, max_len - len, "|%s", "AUTH_OWE_TRANSITION");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_AUTOCONF, "snprintf error\n");
				return "INVALID_AUTH";
			}
			len += ret;
			break;
		default:
			return "INVALID_AUTH";
		}
		i++;
		if (i == 16)
			break;
	}

	return buf;
}

char *get_map_vendor_extension_str(unsigned char vendor_extension, char *buf, int max_len)
{
	int ret = 0, len = 0;
	unsigned short extension = 0;
	unsigned char i = 0;

	while (vendor_extension) {
		if ((vendor_extension & BIT(i)) == 0) {
			i++;
			if (i == 8)
				break;
			continue;
		}
		extension = BIT(i);
		switch (extension) {
		case BIT(0):
			ret = snprintf(buf + len, max_len - len, "|%s", "REUSE_RESERVED_NO_6G");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_AUTOCONF, "snprintf error\n");
				return "INVALID_EXTENSION";
			}
			len += ret;
			break;
		case BIT(2):
			ret = snprintf(buf + len, max_len - len, "|%s", "BIT_PROFILE2_DISALLOW");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_AUTOCONF, "snprintf error\n");
				return "INVALID_EXTENSION";
			}
			len += ret;
			break;
		case BIT(3):
			ret = snprintf(buf + len, max_len - len, "|%s", "BIT_PROFILE1_DISALLOW");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_AUTOCONF, "snprintf error\n");
				return "INVALID_EXTENSION";
			}
			len += ret;
			break;
		case BIT(4):
			ret = snprintf(buf + len, max_len - len, "|%s", "BIT_TEAR_DOWN");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_AUTOCONF, "snprintf error\n");
				return "INVALID_EXTENSION";
			}
			len += ret;
			break;
		case  BIT(5):
			ret = snprintf(buf + len, max_len - len, "|%s", "BIT_FH_BSS");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_AUTOCONF, "snprintf error\n");
				return "INVALID_EXTENSION";
			}
			len += ret;
			break;
		case BIT(6):
			ret = snprintf(buf + len, max_len - len, "|%s", "BIT_BH_BSS");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_AUTOCONF, "snprintf error\n");
				return "INVALID_EXTENSION";
			}
			len += ret;
			break;
		case BIT(7):
			ret = snprintf(buf + len, max_len - len, "|%s", "BIT_BH_STA");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_AUTOCONF, "snprintf error\n");
				return "INVALID_EXTENSION";
			}
			len += ret;
			break;
		default:
			return "INVALID_EXTENSION";
		}
		i++;
		if (i == 8)
			break;
	}

	return buf;
}

char *get_band_cap_str(int band)
{
	switch (band) {
	case BAND_2G_CAP:
		return "BAND_2G_CAP";
	case BAND_5GL_CAP:
		return "BAND_5GL_CAP";
	case BAND_5GH_CAP:
		return "BAND_5GH_CAP";
	case BAND_5G_CAP:
		return "BAND_5G_CAP";
	case BAND_6G_CAP:
		return "BAND_6G_CAP";
	default:
		return "BAND_INVALID_CAP";
	}
}

char *get_search_state_str(int state)
{
	switch (state) {
	case controller_search_idle:
		return "controller_search_idle";
	case bk_link_ready:
		return "bk_link_ready";
	case wait_4_send_controller_search:
		return "wait_4_send_controller_search";
	case wait_4_recv_controller_search_rsp:
		return "wait_4_recv_controller_search_rsp";
	case controller_search_done:
		return "controller_search_done";
	default:
		return "unknown state";
	}
}

char *get_enrollee_state_str(int state)
{
	switch (state) {
	case no_ap_autoconfig:
		return "no_ap_autoconfig";
	case wait_4_send_m1:
		return "wait_4_send_m1";
	case wait_4_recv_m2:
		return "wait_4_recv_m2";
	case wait_4_set_config:
		return "wait_4_set_config";
	default:
		return "unknown state";
	}
}

int ap_autoconfig_init(struct p1905_managerd_ctx *ctx)
{
	if (ctx->role == AGENT) {
		/*set defalut index = -1*/
		ctx->current_autoconfig_info.radio_index = -1;
	    ctx->enrolle_state = no_ap_autoconfig;
	    ctx->current_rx_data = NULL;
	    ctx->is_authenticator_exist_in_M2 = 0;
	    ctx->is_in_encrypt_settings = 0;
	    ctx->get_config_attr_kind = 0;
	}

	ctx->last_rx_data = os_malloc(10240);
	if (!ctx->last_rx_data) {
		err(DEBUG_CAT_INIT, "failed to alloc last_rx_data\n");
		goto fail3;
	}
	ctx->last_rx_buf_len = 10240;
	ctx->last_rx_length = 0;

	ctx->last_tx_data = os_malloc(10240);
	if (!ctx->last_tx_data) {
		err(DEBUG_CAT_INIT, "failed to alloc last_tx_data\n");
		goto fail2;
	}
	ctx->last_tx_buf_len = 10240;
	ctx->last_tx_length = 0;


    ctx->is_ap_config_by_eth = 0;

	return 0;
fail2:
	os_free(ctx->last_rx_data);
fail3:
	return -1;
}

void ap_autoconfig_search(struct p1905_managerd_ctx* ctx, unsigned short mid)
{
	multicast_cmdu_tx(ctx, e_ap_autoconfiguration_search, mid, 1);
}

void ap_controller_search_step(void *eloop_ctx, void *timeout_ctx)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx*)eloop_ctx;

	multi_ap_controller_search_sm(ctx);
	common_process(ctx, &ctx->trx_buf);
}

void multi_ap_controller_search_sm(struct p1905_managerd_ctx* ctx)
{
	int controller_cnt = 0;
	int reconfirm_time = 10; /*set reconfirm controlller count time as 10 sec*/

	notice(DEBUG_CAT_AUTOCONF, "controller_search_state=%d(%s)\n",
		ctx->controller_search_state,
		get_search_state_str(ctx->controller_search_state));

	switch(ctx->controller_search_state) {
	case bk_link_ready:
		/*check if exist multiple controller in topo*/
		controller_cnt = cal_controller_num_in_topo(ctx);
		if (controller_cnt > 1) {
			err(DEBUG_CAT_AUTOCONF, "more than one controller exist; "
				"wait %ds to reconfirm controller count\n", reconfirm_time);
			ctx->controller_search_state = bk_link_ready;
			eloop_cancel_timeout(ap_controller_search_step, (void *)ctx, NULL);
			eloop_register_timeout(reconfirm_time, 0, ap_controller_search_step, (void *)ctx, NULL);
		} else {
			ctx->controller_search_state = wait_4_send_controller_search;
			eloop_cancel_timeout(ap_controller_search_step, (void *)ctx, NULL);
			eloop_register_timeout(0, 0, ap_controller_search_step, (void *)ctx, NULL);
		}
		break;
	case wait_4_send_controller_search:
	    ctx->autoconfig_search_mid = ++ctx->mid;
		reset_send_tlv(ctx);
		multicast_cmdu_tx(ctx, e_ap_autoconfiguration_search, ctx->autoconfig_search_mid, 1);
	    ctx->controller_search_state = wait_4_recv_controller_search_rsp;
		eloop_register_timeout(RECV_CONFIG_RSP_TIME, 0, ap_controller_search_step,
			(void *)ctx, NULL);
		break;
	case wait_4_recv_controller_search_rsp:
		/*re-send autoconfiguration search*/
		ctx->controller_search_cnt++;
		ctx->autoconfig_search_mid = ++ctx->mid;
		reset_send_tlv(ctx);
		multicast_cmdu_tx(ctx, e_ap_autoconfiguration_search, ctx->autoconfig_search_mid, 1);
		eloop_register_timeout(3, 0, ap_controller_search_step, (void *)ctx, NULL);
		break;
	case controller_search_done:
		_1905_notify_controller_found(ctx);
		ctx->controller_search_state = controller_search_idle;
		eloop_cancel_timeout(ap_controller_search_step, (void *)ctx, NULL);
#ifdef MAP_R3
		if (ctx->map_version == MAP_PROFILE_R3 && ctx->r3_oboard_ctx.active) {
			/*r3 onboarding*/
			if (ctx->r3_oboard_ctx.bh_type == MAP_BH_WIFI) {
				if ((ctx->r3_dpp.onboarding_type == MAP_ONBOARDING_TYPE_DPP) &&
					ctx->r3_dpp.connector_len) {
					struct r3_member *peer = NULL;
					notice(DEBUG_CAT_DPP, "WIFI BH and dpp onboarding type, "
						"trigger dpp introduction with Controller("
						MACSTR")\n", MAC2STR(ctx->r3_oboard_ctx.peer_almac));

					peer = get_r3_member(ctx->r3_oboard_ctx.peer_almac);
					if (!peer) {
						notice(DEBUG_CAT_DPP, "R3 member("MACSTR") not found\n",
								MAC2STR(ctx->r3_oboard_ctx.peer_almac));
						break;
					}

					if (peer->profile < MAP_PROFILE_R3) {
						notice(DEBUG_CAT_DPP, "peer("MACSTR") not R3 dev\n",
								MAC2STR(peer->al_mac));
						break;
					}
					/*trigger 1905 dpp introduction with Controller first*/
					peer->r3_info.cur_dpp_state = dpp_idle;
					map_cancel_onboarding_timer(ctx, peer);

					map_dpp_trigger_member_dpp_intro(ctx, peer);
				} else {
					if (ctx->r3_dpp.onboarding_type != MAP_ONBOARDING_TYPE_DPP)
						notice(DEBUG_CAT_DPP, "WIFI BH, but PBC case, trigger WSC\n");
					if (!ctx->r3_dpp.connector_len)
						notice(DEBUG_CAT_DPP, "WIFI BH, no connector set, trigger WSC\n");
					reset_radio_config_state(ctx);
					trigger_auto_config_flow(ctx);
				}
			}
			else if (ctx->r3_oboard_ctx.bh_type == MAP_BH_ETH) {
				unsigned int wait_auth_time = 10;
				notice(DEBUG_CAT_DPP, "ETH BH, wait dpp auth req for 10 sec\n");

				/*start 10s timer to wait for Direct Encap DPP MSG*/
				eloop_cancel_timeout(r3_wait_for_dpp_auth_req, (void *)ctx, NULL);
				/* R3 testbed, QC Controller reply dpp auth req right after 10 sec
				** so need wait more time
				*/
				if (ctx->MAP_Cer)
					wait_auth_time = 20;
				eloop_register_timeout(wait_auth_time, 0, r3_wait_for_dpp_auth_req, (void *)ctx, NULL);
			}
			break;
		}
#endif
		if (!ctx->renew_ctx.is_renew_ongoing) {
			reset_radio_config_state(ctx);
			trigger_auto_config_flow(ctx);
		} else {
			notice(DEBUG_CAT_AUTOCONF, "renew is ongoing; skip auto configuration\n");
		}
		break;
	default:
		break;
	}
}


void ap_autoconfig_enrolle_step(void *eloop_ctx, void *timeout_ctx)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx*)eloop_ctx;

	ap_autoconfig_enrolle_sm(ctx);
	common_process(ctx, &ctx->trx_buf);
}

#ifdef EM_PLUS_SUPPORT
void trigger_operating_channel_report(void *eloop_ctx, void *timeout_ctx)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx *)eloop_ctx;

	debug(DEBUG_CAT_AUTOCONF, "trigger an operating channel report to controller\n");
	_1905_trigger_operating_ch_report(ctx);
}
#endif

void ap_autoconfig_enrolle_sm(struct p1905_managerd_ctx *ctx)
{
	static unsigned int search_retry_count = 0, m1_retry_count = 0;
	unsigned char radio_index = 0, bss_idx = 0;

	notice(DEBUG_CAT_AUTOCONF, "enrolle_state=%d(%s)\n",
		ctx->enrolle_state, get_enrollee_state_str(ctx->enrolle_state));

	switch (ctx->enrolle_state) {
        case wait_4_send_ap_autoconfig_search:
            /* if PLC is not authenticated and
             * if ctx->is_ap_config_by_eth = 1 and ETH doesn't connect
             * break!!!
             * this function will be called periodically by timer handler
             * so system will check PLC and ETH status periodically
             */
            ctx->autoconfig_search_mid = ++ctx->mid;
			reset_send_tlv(ctx);
			ap_autoconfig_search(ctx, ctx->mid);

			ctx->enrolle_state = wait_4_recv_ap_autoconfig_resp;
			eloop_cancel_timeout(ap_autoconfig_enrolle_step, (void *)ctx, NULL);
			eloop_register_timeout(RECV_CONFIG_RSP_TIME, 0,
				ap_autoconfig_enrolle_step, (void *)ctx, NULL);
            break;

        case wait_4_recv_ap_autoconfig_resp:
			/* ap auto config timeout. Set state to no_ap_autoconfig
			 * re-trigger ap autoconfig search process.
			 */
			if (search_retry_count < 2) {
				notice(DEBUG_CAT_AUTOCONF, "timeout, retry ap autoconfig search\n");
				search_retry_count++;
				ctx->autoconfig_search_mid = ++ctx->mid;
				reset_send_tlv(ctx);
				ap_autoconfig_search(ctx, ctx->mid);
				eloop_cancel_timeout(ap_autoconfig_enrolle_step, (void *)ctx, NULL);
				eloop_register_timeout(RECV_CONFIG_RSP_TIME, 0,
					ap_autoconfig_enrolle_step, (void *)ctx, NULL);
			} else {
				notice(DEBUG_CAT_AUTOCONF, "cannot find any controller!!!\n");
				ctx->enrolle_state = no_ap_autoconfig;
				auto_configuration_done(ctx);
				search_retry_count = 0;
			}
            break;
		case wait_4_send_m1:
			ctx->mid++;
			notice(DEBUG_CAT_AUTOCONF, "tx WSC M1(mid-%04x) to "MACSTR" on %s\n",
				ctx->mid, PRINT_MAC(ctx->cinfo.almac), ctx->itf[ctx->cinfo.recv_ifid].if_name);
			insert_cmdu_txq(ctx->cinfo.almac, ctx->p1905_al_mac_addr,
				e_ap_autoconfiguration_wsc_m1, ctx->mid,
				ctx->itf[ctx->cinfo.recv_ifid].if_name, 0);
	        ctx->enrolle_state = wait_4_recv_m2;
			os_memset(&ctx->ap_config_data, 0, sizeof(WSC_CONFIG));
			eloop_cancel_timeout(ap_autoconfig_enrolle_step, (void *)ctx, NULL);
			eloop_register_timeout(RECV_WSC_M2_TIME, 0, ap_autoconfig_enrolle_step,
				(void *)ctx, NULL);
			break;
        case wait_4_recv_m2:
            /*check timeout*/
            /*if timeout happen, need to free ctx->ap_config_data*/
			search_retry_count = 0;

			if (m1_retry_count < M1_RETRY_CNT) {
				ctx->enrolle_state = wait_4_send_m1;
				notice(DEBUG_CAT_AUTOCONF, "timeout, retry m1\n");
				m1_retry_count++;
				eloop_cancel_timeout(ap_autoconfig_enrolle_step, (void *)ctx, NULL);
				eloop_register_timeout(0, 0, ap_autoconfig_enrolle_step, (void *)ctx, NULL);
			} else {
				notice(DEBUG_CAT_AUTOCONF, "retry %d wsc m1, no wsc m2; stop\n", m1_retry_count);
				ctx->enrolle_state = no_ap_autoconfig;
				m1_retry_count = 0;
				auto_configuration_done(ctx);
			}
            break;
        case wait_4_set_config:
		{
        	unsigned char map_vendor_extension = 0, radio_left = 0;
			int i = 0;
			unsigned char no_6G = 0;

			search_retry_count = 0;
			m1_retry_count = 0;

			for (i = 0; i < ctx->current_autoconfig_info.config_number; i++)
				map_vendor_extension |= ctx->current_autoconfig_info.config_data[i].map_vendor_extension;
			/*MAP controller let agent tear down*/
#ifdef EM_PLUS_SUPPORT
			if (ctx->ignore_renew == 1) {
				debug(DEBUG_CAT_AUTOCONF, "don't set config during adding/deleting intf\n");

				/*trigger a operating channel report to controller after 5s,
				 *or else the controller will keep the status at onboarding
				 */
				eloop_cancel_timeout(trigger_operating_channel_report, (void *)ctx, NULL);
				eloop_register_timeout(5, 0, trigger_operating_channel_report, (void *)ctx, NULL);
			} else
#endif
			if (map_vendor_extension & BIT_TEAR_DOWN) {
				if (ctx->current_autoconfig_info.radio_index != -1) {
					radio_index = (unsigned char)ctx->current_autoconfig_info.radio_index;
					notice(DEBUG_CAT_AUTOCONF, "tear down radio "MACSTR"\n",
						PRINT_MAC(ctx->rinfo[radio_index].identifier));
					ctx->rinfo[radio_index].teared_down = 1;
					for (bss_idx = 0; bss_idx < ctx->rinfo[radio_index].bss_number; bss_idx++)
						ctx->rinfo[radio_index].bss[bss_idx].config_status = 0;
					delete_exist_operational_bss(ctx, ctx->rinfo[radio_index].identifier);
					/*to do tear down this radio*/
					if (map_vendor_extension & REUSE_RESERVED_NO_6G) {
						no_6G = 1;
						notice(DEBUG_CAT_AUTOCONF, "do not tear down 6G\n");
					}
					_1905_set_radio_tear_down(ctx, ctx->rinfo[radio_index].identifier, no_6G);
				} else {
					err(DEBUG_CAT_AUTOCONF, "no ongoing autoconf radio; "
						"ctx->current_autoconfig_info.radio_index=-1\n");
						break;
				}
			} else if (wifi_utils_success != set_wsc_config((void *)ctx)) {
				err(DEBUG_CAT_AUTOCONF, "set_wsc_config err for radio("MACSTR")\n",
					MAC2STR(ctx->rinfo[radio_index].identifier));
			}

			ctx->enrolle_state = no_ap_autoconfig;
			auto_configuration_done(ctx);
			trigger_auto_config_flow(ctx);

			if (ctx->renew_ctx.is_renew_ongoing) {
				radio_left = get_left_unconfig_radio(ctx);
				eloop_cancel_timeout(agent_apply_new_config, (void *)ctx, NULL);

				if (!radio_left) {
					/*all radios have been configured successfully, apply its wireless setting immediately*/
					eloop_register_timeout(0, 0,
							agent_apply_new_config, (void *)ctx, NULL);
				} else {
					/*wait for left unconfiguring process*/
					eloop_register_timeout(radio_left * ONE_RADIO_CONFIG_TIME_MAX, 0,
							agent_apply_new_config, (void *)ctx, NULL);
				}
			}
#if defined(MAP_R3) && !defined(EM_PLUS_SUPPORT)
			if (ctx->map_version == MAP_PROFILE_R3 &&
				(ctx->r3_oboard_ctx.bh_type == MAP_BH_ETH)) {
				/* R1|R2 onboarding on R3 device, need send autoconfig search periodicly */
				eloop_cancel_timeout(periodic_send_autoconfig_search, (void *)ctx, NULL);
				notice(DEBUG_CAT_DPP, "R1|R2 onboarding on R3 dev");
				notice_np(DEBUG_CAT_DPP, ",register 30s timer to send autoconfig search periodicly\n");
				eloop_register_timeout(30, 0, periodic_send_autoconfig_search, (void *)ctx, NULL);
			}
#endif
        }
            break;
		default:
			break;
    }
}

int pop_node_from_stack(struct p1905_managerd_ctx *ctx)
{
	leaf_info *leaf_top = NULL;
#ifdef MAP_R3
	struct r3_member *peer = NULL;
#endif
	unsigned int apply_local_timer = 0;

	if (get_top(&ctx->topo_stack, &leaf_top) < 0) {
		notice(DEBUG_CAT_RENEW, "controller_renew_bss: topo stack empty\n");
		ctx->renew_ctx.trigger_renew = 0;
		return -1;
	}

	notice(DEBUG_CAT_RENEW, "pop out mac("MACSTR")\n",
		MAC2STR(leaf_top->al_mac));

	if (!os_memcmp(ctx->p1905_al_mac_addr, leaf_top->al_mac, ETH_ALEN)) {
		notice(DEBUG_CAT_RENEW, "do not renew to controller almac("MACSTR")\n",
			PRINT_MAC(leaf_top->al_mac));
		ctx->renew_state = wait_4_apply_local;
		if (ctx->renew_ctx.wait_apply == 1) {
			apply_local_timer = 5;
			ctx->renew_ctx.wait_apply = 0;
			notice(DEBUG_CAT_RENEW, "R3 renew: controller need wait %d s to apply setting.\n", apply_local_timer);
		}
		eloop_register_timeout(apply_local_timer, 0, controller_renew_bss_step,
					(void *)ctx, NULL);
		return 0;
	}

#ifdef MAP_R3
	if (ctx->map_version == MAP_PROFILE_R3) {
		peer = get_r3_member(leaf_top->al_mac);
	}

	if (peer && peer->security_1905) {
		ctx->renew_ctx.wait_apply = 1;
		ctx->renew_state = wait_4_send_bss_reconfig_trigger;
		notice(DEBUG_CAT_DPP, "peer almac("MACSTR") is R3 onboarded\n",
			PRINT_MAC(leaf_top->al_mac));
	}
	else
#endif
		ctx->renew_state = wait_4_send_renew;

	leaf_top->renew_retry_cnt = 3;
	eloop_register_timeout(0, 0, controller_renew_bss_step, (void *)ctx, NULL);

	return 0;
}

int controller_send_renew(struct p1905_managerd_ctx *ctx)
{
	struct topology_response_db *rpdb = NULL;
	leaf_info *leaf_top = NULL;
	int ret = 0;
	struct agent_list_db *agent_info = NULL;
	unsigned char *if_name = NULL;
	unsigned char freq_band = 0x00;
	int i = 0;

	ret = get_top(&ctx->topo_stack, &leaf_top);
	if (ret < 0) {
		warn(DEBUG_CAT_RENEW, "BUG here!!!! get top node from stack error\n");
		ctx->renew_ctx.trigger_renew = 0;
		return -1;
	}

	rpdb = lookup_tprdb_by_almac(ctx, leaf_top->al_mac);
	if (!rpdb) {
		notice(DEBUG_CAT_RENEW, "BUG here!!!! rpdb almac("MACSTR") not exist\n",
			PRINT_MAC(leaf_top->al_mac));
		ctx->renew_ctx.trigger_renew = 0;
		return -1;
	}
	if_name = ctx->itf[rpdb->recv_ifid].if_name;

	find_agent_info(ctx, leaf_top->al_mac, &agent_info);
	if (!agent_info) {
		notice(DEBUG_CAT_RENEW, "cannot find agent info "MACSTR"\n", PRINT_MAC(leaf_top->al_mac));
		ctx->renew_state = wait_4_pop_node;
		pop_node(&ctx->topo_stack);
		eloop_register_timeout(0, 0, controller_renew_bss_step, (void *)ctx, NULL);
		return -1;
	}

	/*in order to be compatible with older version, change the renew freq band*/
	for (i = 0; i < agent_info->radio_num; i++) {
		if (!agent_info->ra_info[i].conf_ctx.config_status) {
			if (agent_info->ra_info[i].band & BAND_2G_CAP)
				freq_band = 0x00;
			else if (agent_info->ra_info[i].band & BAND_5G_CAP)
				freq_band = 0x01;
			break;
		}
	}

	if (fill_send_tlv(ctx, &freq_band, 1) < 0) {
		ctx->renew_ctx.trigger_renew = 0;
		return -1;
	}
	notice(DEBUG_CAT_RENEW, "controller send WSC renew to "MACSTR"\n",
		MAC2STR(leaf_top->al_mac));

	insert_cmdu_txq(leaf_top->al_mac, ctx->p1905_al_mac_addr,
		e_ap_autoconfiguration_renew, ++ctx->mid, if_name, 0);

	if (!ctx->MAP_Cer) {
		if (agent_info && agent_info->wts_syn_done == 1) {
			debug(DEBUG_CAT_RENEW, "reset agent wts sync state\n");
			agent_info->wts_syn_done = 0;
		}
	}

	ctx->renew_state = wait_4_check_renew_result;
	eloop_register_timeout(RECV_WSC_M1_TIME, 0, controller_renew_bss_step, (void *)ctx, NULL);

	return 0;

}

void controller_check_agent_renew_state(struct p1905_managerd_ctx *ctx)
{
	leaf_info *leaf_top = NULL;
	int ret = 0;
	struct agent_list_db *agent_info = NULL;

	ret = get_top(&ctx->topo_stack, &leaf_top);
	if (ret < 0) {
		warn(DEBUG_CAT_RENEW, "BUG here!!!! get top node from stack error\n");
		ctx->renew_ctx.trigger_renew = 0;
		return;
	}

	find_agent_info(ctx, leaf_top->al_mac, &agent_info);
	if (!agent_info) {
		notice(DEBUG_CAT_RENEW, "cannot find agent info for "MACSTR"\n",
			MAC2STR(leaf_top->al_mac));
		ctx->renew_ctx.trigger_renew = 0;
		return;
	}

	if (get_agent_all_radio_config_state(agent_info)) {
		/*all radio if agent have been configured, renew next agent*/
		pop_node(&ctx->topo_stack);
		ctx->renew_state = wait_4_pop_node;
		notice(DEBUG_CAT_RENEW,
			"all radios have been configured of agent "MACSTR", renew next one\n",
			PRINT_MAC(agent_info->almac));
	} else {
		leaf_top->renew_retry_cnt--;
		if (leaf_top->renew_retry_cnt > 0) {
			/*not all radio if agent have been configured, retry renew*/
			ctx->renew_state = wait_4_send_renew;
			notice(DEBUG_CAT_RENEW, "send renew but get M1/M2_ack timeout, retry\n");
		}
		else {
			/*disappointing agent, renew next agent*/
			pop_node(&ctx->topo_stack);
			ctx->renew_state = wait_4_pop_node;
			notice(DEBUG_CAT_RENEW, "send renew but get M1/M2_ack timeout, renew next agent\n");
		}
	}

	eloop_register_timeout(0, 0, controller_renew_bss_step, (void *)ctx, NULL);

}

void controller_renew_bss_step(void *eloop_ctx, void *timeout_ctx)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx*)eloop_ctx;

	controller_renew_bss_sm(ctx);

	common_process(ctx, &ctx->trx_buf);
}

void controller_renew_bss_sm(struct p1905_managerd_ctx *ctx)
{
#ifdef MAP_R3
	leaf_info *leaf_top = NULL;
#endif

	switch(ctx->renew_state)
	{
		case wait_4_dump_topo:
		{
			empty_stack(&ctx->topo_stack);
			/*travel topology tree and dump the topo*/
			topology_tree_travel_preorder(ctx, ctx->root_leaf);

			ctx->renew_state = wait_4_pop_node;
			eloop_register_timeout(0, 0, controller_renew_bss_step, (void *)ctx, NULL);
		}
		break;

		case wait_4_pop_node:
		{
			pop_node_from_stack(ctx);
		}
		break;

		case wait_4_send_renew:
		{
			controller_send_renew(ctx);
		}
		break;

		case wait_4_check_renew_result:
		{
			controller_check_agent_renew_state(ctx);
		}
		break;

		case wait_4_apply_local:
		{
			int i = 0;
			notice(DEBUG_CAT_RENEW, "apply bss config locally\n");

			ctx->block_bss_info.auto_config_num = 0;
			delete_ap_mld_conf(&ctx->wts_ctrl_mld_cfg);
			for (i = 0; i < ctx->radio_number; i++)
				_1905_update_bss_info_per_radio(ctx, &ctx->rinfo[i]);

			/* notify ap mld config on controller */
			if (dl_list_empty(&ctx->wts_ctrl_mld_cfg.mlo_cfg_list)) {
				notice(DEBUG_CAT_MLO,
					RED("no mld group configured in wts file, please check!!!!\n"));
			} else {
				update_agt_ap_mld_info(&ctx->wts_ctrl_mld_cfg, &ctx->opcls_mld_cfg);
				delete_ap_mld_conf(&ctx->opcls_mld_cfg);

				for (i = 0; i < ctx->radio_number; i++) {
					debug(DEBUG_CAT_RENEW, "ruid "MACSTR" mlo enable %d\n",
						MAC2STR(ctx->rinfo[i].identifier), ctx->rinfo[i].mlo_cap);
					if (ctx->rinfo[i].mlo_cap) {
						_1905_notify_ap_mld_config(ctx, &ctx->wts_ctrl_mld_cfg, 0);
						break;
					}
				}
			}

			ctx->renew_ctx.trigger_renew = 0;
#ifdef MAP_R2
			eloop_cancel_timeout(map_r2_notify_ts_config, (void *)ctx, NULL);
			eloop_cancel_timeout(map_notify_transparent_vlan_setting, (void *)ctx, NULL);
			eloop_register_timeout(0, 0, map_r2_notify_ts_config, (void *)ctx, NULL);
			eloop_register_timeout(0, 0, map_notify_transparent_vlan_setting, (void *)ctx, NULL);
#endif
		}
		break;
#ifdef MAP_R3
	case wait_4_send_bss_reconfig_trigger:
		r3_send_bss_reconfig_trigger(ctx);
		break;
	case wait_4_recv_bss_autoconfig_req:
		/* wait for bss config req timeout*/
		if (get_top(&ctx->topo_stack, &leaf_top) < 0) {
			notice(DEBUG_CAT_DPP, "BUG here!!!! get top node from stack error\n");
			ctx->renew_ctx.trigger_renew = 0;
			return;
		}
		notice(DEBUG_CAT_DPP, "send bss reconfig trigger but get bss config req timeout\n");
		leaf_top->renew_retry_cnt--;

		if (leaf_top->renew_retry_cnt <= 0) {
			//renew next agent
			pop_node(&ctx->topo_stack);
			ctx->renew_state = wait_4_pop_node;
		} else {
			ctx->renew_state = wait_4_send_bss_reconfig_trigger;
		}

		eloop_cancel_timeout(controller_renew_bss_step, (void *)ctx, NULL);
		eloop_register_timeout(0, 0, controller_renew_bss_step, (void *)ctx, NULL);
		break;
#endif
	default:
			break;

	}
}


void agent_apply_new_config(void *eloop_ctx, void *timeout_ctx) {
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx*)eloop_ctx;
	notice(DEBUG_CAT_RENEW, "agent apply new_config\n");

	ctx->renew_ctx.is_renew_ongoing = 0;
#ifdef EM_PLUS_SUPPORT
	if (ctx->ignore_renew == 0)
#endif
		flash_wsc_config(ctx);
}

void reset_radio_config_state(struct p1905_managerd_ctx *ctx)
{
	int i = 0;

	if (ctx->role == CONTROLLER)
		return;

	for (i = 0; i < ctx->radio_number; i++) {
		ctx->rinfo[i].config_status = MAP_CONF_UNCONF;
		ctx->rinfo[i].teared_down = 0;
	}

	ctx->current_autoconfig_info.radio_index = -1;
}

/*get config state of all radios
 *return value: number of left radios that are not configured
 */
unsigned char get_left_unconfig_radio(struct p1905_managerd_ctx *ctx)
{
	int i = 0;
	unsigned char left = 0;

	for (i = 0; i < ctx->radio_number; i++) {
		if (ctx->rinfo[i].config_status == MAP_CONF_UNCONF)
			left++;
	}

	return left;
}

void trigger_auto_config_flow(struct p1905_managerd_ctx *ctx)
{
	int i = 0;
	int ret =0;

	if (ctx->role == CONTROLLER)
		return;

	for (i = 0; i < ctx->radio_number; i++) {
		if (ctx->rinfo[i].config_status == MAP_CONF_UNCONF)
			break;
	}

	if (i >= ctx->radio_number) {
		notice(DEBUG_CAT_AUTOCONF, "auto configuration done\n");
		if (!ctx->renew_ctx.is_renew_ongoing) {
			if (ctx->ap_mld_cfg) {
				_1905_notify_ap_mld_config(ctx, &ctx->mld_bss, 0);
				delete_ap_mld_conf(&ctx->mld_bss);
				ctx->ap_mld_cfg = 0;
			}
#ifdef MAP_R6
			if (ctx->wsc_msg_type) {
				_1905_notify_wsc_reconfig(ctx);
				ctx->wsc_msg_type = 0;
				os_memset(&ctx->cred_reconfig, 0, sizeof(ctx->cred_reconfig));
			}
			if (ctx->bsta_mld_cfg) {
				_1905_notify_bsta_mld_config(ctx, &ctx->mld_bsta);
				delete_bsta_mld_conf(&ctx->mld_bsta);
				ctx->bsta_mld_cfg = 0;
			}
			if (ctx->eht_op_cfg) {
				_1905_notify_eht_operations(ctx, ctx->eht_op);
				delete_eht_operations(ctx->eht_op);
				ctx->eht_op_cfg = 0;
			}
#endif
		}
		return;
	}

	ret= set_radio_autoconf_trriger(ctx, i, 1);
	if (ret == -2) {
		notice(DEBUG_CAT_AUTOCONF, "set tear down radio configured, trigger next radio\n");
		ctx->rinfo[i].config_status = MAP_CONF_CONFED;
		trigger_auto_config_flow(ctx);
	} else if (ret == 0) {
		triger_autoconfiguration(ctx);
	}
}

int cont_handle_autoconfig_wsc(struct p1905_managerd_ctx *ctx, unsigned char *al_mac,
	unsigned char *if_name, unsigned short mid, struct agent_radio_info *r,
	unsigned char radio_cnt, unsigned char *radio_identifier)
{
	if (ctx->role == AGENT) {
		struct radio_info *own_radio = NULL, *current_config_radio = NULL;

		if (ctx->current_autoconfig_info.radio_index == -1) {
			err(DEBUG_CAT_AUTOCONF, "no ongoing auto config radio\n");
			goto fail;
		}

		own_radio = get_rainfo_by_id(ctx, radio_identifier);
		if (own_radio == NULL) {
			err(DEBUG_CAT_AUTOCONF, "get rainfo by raid "MACSTR" fail!\n",
				MAC2STR(radio_identifier));
			goto fail;
		}
		current_config_radio = &ctx->rinfo[ctx->current_autoconfig_info.radio_index];

		if (own_radio != current_config_radio) {
			err(DEBUG_CAT_AUTOCONF, "radio mismatch; current_config_radio="MACSTR"; band=%s; "
				"own_radio="MACSTR"; band=%s\n",
				MAC2STR(current_config_radio->identifier),
				get_band_cap_str(current_config_radio->band),
				MAC2STR(own_radio->identifier),
				get_band_cap_str(own_radio->band));
			goto fail;
		}

		/*we got correct M2, so enter the set config state*/
		notice(DEBUG_CAT_AUTOCONF, "recv WSC M2; mid=0x%04x; almac="MACSTR"; raid="MACSTR"; band=%s\n",
			mid, MAC2STR(al_mac), MAC2STR(own_radio->identifier),
			get_band_cap_str(own_radio->band));
		ctx->enrolle_state = wait_4_set_config;
		eloop_cancel_timeout(ap_autoconfig_enrolle_step, (void *)ctx, NULL);
		eloop_register_timeout(0, 0, ap_autoconfig_enrolle_step, (void *)ctx, NULL);
		if (ctx->renew_ctx.is_renew_ongoing) {
			/*send private m2 ack for agent*/
			notice(DEBUG_CAT_AUTOCONF, "respond private ack(%04x) to ("MACSTR") on %s\n",
				mid, PRINT_MAC(al_mac), if_name);
			insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr,
				e_1905_ack, mid, if_name, 0);
			process_cmdu_txq(ctx, ctx->trx_buf.buf);
		}
	} else {
		struct agent_list_db *agent_info = NULL;
		struct agent_radio_info *radio = NULL;
		struct mld_bss_config_db *mld_bss = NULL;
		int agent_bss_num = 0;
		int current_bss_num = 0;
		/* Registrar got correct M1. Need to response M2.(Unicast)
		 * It has a strange behavior about mid. Spec does not specify we
		 * need to use same mid for M1 and M2. So I create a new mid for M2
		 */
		find_agent_info(ctx, al_mac, &agent_info);
		if (!agent_info) {
			err(DEBUG_CAT_AUTOCONF, "no agent "MACSTR" info exist\n",
				MAC2STR(al_mac));
			goto fail;
		}
		if (radio_cnt != 1) {
			err(DEBUG_CAT_AUTOCONF, "ap radio basic cap tlv in M1 is incorrect; != 1\n");
			goto fail;
		}

		/* wts to ap mld need agent's radio info, so place here after recv 1st m1
		 * no need this action while renew
		 */
		mld_bss = get_agent_ap_mld(ctx, al_mac);
		if (mld_bss)
			delete_ap_mld_conf(mld_bss);
		wts_2_mlo_agent(ctx, al_mac);

		radio = find_agent_radio_info(agent_info, r->identifier);
		if (!radio) {
			err(DEBUG_CAT_AUTOCONF, "can't find radio "MACSTR" on agent "MACSTR"\n",
				MAC2STR(r->identifier), MAC2STR(al_mac));
			goto fail;
		}

		if (ctx->block_bss_info.block_bss_autoconfig && !agent_info->is_block) {
			/*1.get agent total bss number*/
			agent_bss_num = precheck_obj_num(ctx, al_mac);
			/*2.get current bss number except the agent*/
			current_bss_num = get_current_bss_num(ctx, al_mac);
			/*3. check if the total bss number exceeds the maximum limit*/
			if ((current_bss_num + agent_bss_num) > ctx->block_bss_info.max_bss_count) {
				char *dump_buf = NULL;
				int dump_len = 0;

				notice(DEBUG_CAT_AUTOCONF, "The total bss number exceeds limit!! cur(%d) + agent(%d) > max(%d)\n",
					current_bss_num, agent_bss_num, ctx->block_bss_info.max_bss_count);

				agent_info->is_block = 1;
				agent_info->retry_block_count = 4;
				clear_agent_config_bss_num(agent_info);
				dump_buf = os_zalloc(MAX_PKT_LEN);
				if (!dump_buf) {
					err(DEBUG_CAT_AUTOCONF, "os_zalloc fail!\n");
					return -1;
				}
				dump_len = dump_bss_config_info(ctx, dump_buf, MAX_PKT_LEN);
				if (dump_len < 0) {
					err(DEBUG_CAT_AUTOCONF, "dump_bss_config_info fail\n");
					os_free(dump_buf);
					return -1;
				}
				notice(DEBUG_CAT_AUTOCONF, "%s", dump_buf);
				os_free(dump_buf);
				dump_buf = NULL;
				/*send renew msg to block bss config of the enrollee agent*/
				if (controller_trigger_block_bss_r2(ctx, al_mac) < 0) {
					err(DEBUG_CAT_AUTOCONF, "trigger block bss config failed!\n");
					return -1;
				}
				notice(DEBUG_CAT_AUTOCONF, "trigger block bss config success!\n");
				return 0;
			}
		}

		set_agent_wsc_doing_radio(agent_info, radio->identifier);
		notice(DEBUG_CAT_AUTOCONF,
			"recv WSC M1 from "MACSTR" on %s; mid=0x%04x; raid="MACSTR"; band_cap=0x%02x(%s)\n",
			MAC2STR(al_mac), if_name, mid, MAC2STR(radio->identifier),
			radio->band, get_band_cap_str(radio->band));
		ctx->mid++;
		notice(DEBUG_CAT_AUTOCONF, "send WSC M2 to "MACSTR" on %s; mid=0x%04x\n",
			MAC2STR(al_mac), if_name, ctx->mid);
		insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr,
			e_ap_autoconfiguration_wsc_m2, ctx->mid,
			if_name, 0);
		/*
		* After Registrar send out M2, it will send out a Vendor Specific
		* Message including Registrar's wts content.
		* And Enrollee will update itself's wts file.
		*/
		if (ctx->auto_role_sync_wts_file && !ctx->MAP_Cer) {
			if (agent_info->wts_syn_done == 0) {
				ctx->mid++;
				notice(DEBUG_CAT_AUTOCONF, "send e_vendor_specific_wts_content msg to "MACSTR" on %s; mid=0x%04x\n",
					MAC2STR(al_mac), if_name, ctx->mid);
				insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr, e_vendor_specific_wts_content, ctx->mid,
					if_name, 0);
				agent_info->wts_syn_done = 1;
			}
		}

		set_agent_radio_config_stat(agent_info, radio->identifier, 1);
		if (ctx->renew_ctx.trigger_renew) {
			eloop_cancel_timeout(controller_renew_bss_step, (void *)ctx, NULL);
			if (get_agent_all_radio_config_state(agent_info)) {
				/*if all radios have been configured, renew next one*/
				pop_node(&ctx->topo_stack);
				ctx->renew_state = wait_4_pop_node;
				eloop_register_timeout(0, 0,
					controller_renew_bss_step, (void *)ctx, NULL);
				notice(DEBUG_CAT_RENEW,
					"all radios have been configured on agent "MACSTR", renew next agent\n",
					MAC2STR(agent_info->almac));
			} else {
				/*wait for m1 for another radio*/
				ctx->renew_state = wait_4_check_renew_result;
				eloop_register_timeout(RECV_WSC_M1_TIME, 0,
					controller_renew_bss_step, (void *)ctx, NULL);
				notice(DEBUG_CAT_RENEW, "renew ongoing for agent "MACSTR", wait all radio done\n",
					MAC2STR(agent_info->almac));
			}
		}
	}
	return 0;
fail:
	return -1;
}

int cont_handle_autoconfig_renew(struct p1905_managerd_ctx *ctx, unsigned char *al_mac,
	unsigned char *if_name, unsigned char band)
{
	int ret = 0;
	int controller_num = 0;
	unsigned char i = 0;

	if (ctx->role != AGENT)
		goto fail;

#ifdef MAP_R3
	if ((ctx->map_version >= MAP_PROFILE_R3) &&
		(ctx->r3_oboard_ctx.onboarding_stage != R3_ONBOARDING_STAGE_INVALID)) {
		notice(DEBUG_CAT_DPP, "R3 onboarding is ongoing, skip autoconfig renew\n");
		goto end;
	}
#endif
	for (i = 0; i < ctx->radio_number; i++) {
		if (ctx->rinfo[i].band == 0) {
			notice(DEBUG_CAT_RENEW, "band information not ready for raid-"MACSTR" drop the renew",
				MAC2STR(ctx->rinfo[i].identifier));
			return 0;
		}
	}

	controller_num = cal_controller_num_in_topo(ctx);
	if (controller_num > 1) {
		err(DEBUG_CAT_RENEW, "multiple controller in topo, don't do renew\n");
		return 0;
	}

#ifdef EM_PLUS_SUPPORT
	if (ctx->renew_ctx.is_renew_ongoing == 1) {
		err(DEBUG_CAT_RENEW, "renew is already ongoing delete Existing setting\n");
		_1905_flash_del_config(ctx);
	}
#endif /* EM_PLUS_SUPPORT */

	ctx->renew_ctx.is_renew_ongoing = 1;

	os_memcpy(ctx->cinfo.almac, al_mac, ETH_ALEN);
	ctx->cinfo.supported_freq = band;
	ret = os_snprintf((char *)ctx->cinfo.local_ifname, sizeof(ctx->cinfo.local_ifname), "%s", if_name);
	if (os_snprintf_error(sizeof(ctx->cinfo.local_ifname), ret)) {
		warn(DEBUG_CAT_RENEW, "[%d]snprintf fail!\n", __LINE__);
		goto fail;
	}
	ctx->cinfo.recv_ifid = ctx->recent_cmdu_rx_if_number;
	notice(DEBUG_CAT_RENEW, "recv renew message from "MACSTR" on interface=%s\n",
		MAC2STR(al_mac),  ctx->cinfo.local_ifname);

	/* Only the wan interface can send search message*/
	if (ctx->restrict_wan_onboarding) {
		if ((ctx->role != CONTROLLER &&
			ctx->itf[ctx->recent_cmdu_rx_if_number].media_type <= IEEE802_3_AB_GROUP &&
			!ctx->itf[ctx->recent_cmdu_rx_if_number].is_wan)) {
			notice(DEBUG_CAT_RENEW, "Don't trigger auto-config on %s\n",
				ctx->itf[ctx->recent_cmdu_rx_if_number].if_name);
			ctx->renew_ctx.is_renew_ongoing = 0;
			return 0;
		}
	}
	reset_radio_config_state(ctx);
	trigger_auto_config_flow(ctx);
#ifdef MAP_R3
end:
#endif
	return 0;
fail:
	return -1;
}

int cont_handle_autoconfig_response(struct p1905_managerd_ctx *ctx, unsigned char *al_mac,
	unsigned char *if_name, unsigned char band, unsigned char role, unsigned char profile,
	struct controller_capability contr_cap)
{
#ifdef MAP_R3
	struct r3_member *peer = NULL;
#endif
	int ret = 0;

#ifdef MAP_R6
	ctx->cinfo.early_apcap = contr_cap.early_apcap;
	if (ctx->cinfo.early_apcap && is_zero_ether_addr(ctx->cinfo.almac)) {
		insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr, e_early_ap_cap_report, ++ctx->mid,
				ctx->itf[ctx->recent_cmdu_rx_if_number].if_name, 0);
		notice(DEBUG_CAT_MLO, "cntr with early ap cap, insert txq e_early_ap_cap_report\n");
	}
#endif

	ctx->is_authenticator_exist_in_M2 = 0;
	os_memcpy(ctx->cinfo.almac, al_mac, ETH_ALEN);
	ctx->cinfo.supported_freq = band;
	ctx->cinfo.supported_role_registrar = role;
	ctx->cinfo.profile = profile;
	ctx->cinfo.kibmib = contr_cap.kibmib;

	ret = os_snprintf((char *)ctx->cinfo.local_ifname, sizeof(ctx->cinfo.local_ifname), "%s", if_name);
	if (os_snprintf_error(sizeof(ctx->cinfo.local_ifname), ret)) {
		err(DEBUG_CAT_AUTOCONF, "snprintf fail!\n");
		goto end;
	}
	ctx->cinfo.recv_ifid = ctx->recent_cmdu_rx_if_number;
#ifdef MAP_R3
	if (NULL == (peer = get_r3_member(al_mac)) && ctx->map_version == MAP_PROFILE_R3) {
		notice(DEBUG_CAT_DPP, "create R3 member for "MACSTR"\n", MAC2STR(al_mac));
		peer = create_r3_member(al_mac);
	}

	if (peer) {
		peer->profile = profile;
		/* peer->role change to Controller after receive autoconfig resp */
		peer->role = CONTROLLER;
		if (peer->security_1905 && (peer->profile < MAP_PROFILE_R3)) {
			notice(DEBUG_CAT_DPP, "disable security_1905 for " MACSTR "\n", MAC2STR(al_mac));
			peer->security_1905 = 0;
		}
	}
#endif
	notice(DEBUG_CAT_AUTOCONF, "conroller info; al_mac="MACSTR"; band=%d; recv_ifid=%d(%s)\n",
		MAC2STR(ctx->cinfo.almac), band, ctx->cinfo.recv_ifid, ctx->cinfo.local_ifname);


	if (ctx->enrolle_state == no_ap_autoconfig && ctx->controller_search_state == controller_search_idle) {
		_1905_notify_autoconfig_rsp_event(ctx, al_mac);
		goto end;
	}
	if (((ctx->enrolle_state != wait_4_recv_ap_autoconfig_resp) &&
		ctx->controller_search_state == controller_search_idle)) {
		notice(DEBUG_CAT_AUTOCONF, "enrolle_state mismatch; "
			"enrolle_state=%d; controller_search_state=%d\n",
			ctx->enrolle_state, ctx->controller_search_state);
       goto end;
    }

	if (ctx->controller_search_state != controller_search_idle) {
		ctx->controller_search_state = controller_search_done;
#ifdef MAP_R3
		if (ctx->map_version == MAP_PROFILE_R3 &&
			profile == MAP_PROFILE_R3 && peer) {
			/*
			 * wifi case: if connector was set, launch DPP Onboarding
			 *            else, WSC onboarding
			 * eth case:  still run DPP onboarding state machine
			 *            if not receive DPP Auth in 10 sec, will start WSC
			 */
			if ((ctx->r3_dpp.connector_len &&
				ctx->r3_oboard_ctx.bh_type == MAP_BH_WIFI) ||
				ctx->r3_oboard_ctx.bh_type == MAP_BH_ETH) {
				/* it is r3 onboarding */
				ctx->r3_oboard_ctx.active = 1;
				ctx->r3_oboard_ctx.peer_profile = profile;
				/* 1 means peer is controller */
				ctx->r3_oboard_ctx.peer_service_type = role;
				os_memcpy(ctx->r3_oboard_ctx.peer_almac, al_mac, ETH_ALEN);
				peer->r3_info.cur_dpp_state = dpp_idle;
			} else
				notice(DEBUG_CAT_DPP, "R3 device BH-WIFI, but"
					" connector not set, start WSC onboarding\n");
		}
#endif
		eloop_cancel_timeout(ap_controller_search_step, (void *)ctx, NULL);
		eloop_register_timeout(0, 0, ap_controller_search_step, (void *)ctx, NULL);
	}
end:
	return 0;
}

int cont_handle_autoconfig_search(struct p1905_managerd_ctx *ctx, unsigned char *al_mac,
	unsigned char *if_name, unsigned char profile, unsigned short mid)
{
	struct agent_list_db *agent_info = NULL;

	if (ctx->role == CONTROLLER) {
#ifdef MAP_R3
		if (ctx->map_version == MAP_PROFILE_R3)
			create_r3_member(al_mac);
#endif
		/*insert agent entry*/
		agent_info = insert_agent_info(ctx, al_mac);
		if (agent_info)
			agent_info->profile = profile;
        /*send ap auto config response message, unicast*/
		notice(DEBUG_CAT_MSG, "recv ap autoconf search, send rsp to "MACSTR" with mid=%04x on %s\n",
			      MAC2STR(al_mac), ctx->mid, if_name);
		insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr,
			e_ap_autoconfiguration_response, mid, if_name, 0);
#ifdef MAP_R3
		if ((ctx->map_version == MAP_PROFILE_R3 && profile == MAP_PROFILE_R3) ||
			(agent_info && agent_info->r2_cap.dpp_flag)) {
			info(DEBUG_CAT_DPP, "notify autoconfig search to mapd for "MACSTR"\n", MAC2STR(al_mac));
			_1905_notify_autoconfig_search_event(ctx, al_mac);
		}
#endif
	} else {
		if(ctx->enrolle_state == no_ap_autoconfig &&
			ctx->controller_search_state == controller_search_idle)
			_1905_notify_autoconfig_search_event(ctx, al_mac);
	}

	return 0;
}


/**
 *  get WSC config for ap-auto configure use.
 *
 * \param  wsc  pointer of  wsc_config.
 * \return  error code.
 */
WIFI_UTILS_STATUS get_wsc_config(void *pctx, WSC_CONFIG* wsc,
	unsigned char *wfa_vendor_extension, struct agent_radio_info *agent_radio,
	unsigned char is_block)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx *)pctx;
	unsigned char band = 0;
#ifdef MAP_NON6E_CONTROLLER
	char buf[256] = {0};
#endif

	memset(wsc, 0, sizeof(WSC_CONFIG));
	band = determin_band_config(ctx, ctx->ap_config.enrolle_mac, agent_radio->band);
	if (band == BAND_INVALID_CAP ||
		(ctx->block_bss_info.block_bss_autoconfig && is_block)) {
		*wfa_vendor_extension = 0x10;
#ifdef MAP_NON6E_CONTROLLER
		*wfa_vendor_extension = 0x11;
		notice(DEBUG_CAT_AUTOCONF, "NON6E_CONTROLLER; set wfa_vendor_extension to 0x11(%s)\n",
			get_map_vendor_extension_str(*wfa_vendor_extension, buf, 256));
#endif
		return wifi_utils_success;
	} else {
		return config_bss_by_band(ctx, band, wsc, wfa_vendor_extension);
	}
}

/**
 *  set WSC config for ap-auto configure use.
 *
 * \param  wsc  pointer of  wsc_config.
 * \return  error code.
 */
WIFI_UTILS_STATUS set_wsc_config(void *pctx)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx *)pctx;

	if(_1905_set_wireless_setting(ctx) == wapp_utils_error)
		return wifi_utils_error;

#ifdef MAP_R2
	eloop_cancel_timeout(map_r2_notify_ts_config, (void *)ctx, NULL);
	eloop_cancel_timeout(map_notify_transparent_vlan_setting, (void *)ctx, NULL);
	eloop_register_timeout(0, 0, map_r2_notify_ts_config, (void *)ctx, NULL);
	eloop_register_timeout(0, 0, map_notify_transparent_vlan_setting, (void *)ctx, NULL);
#endif

	return wifi_utils_success;
}

WIFI_UTILS_STATUS flash_wsc_config(void *pctx) {
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx *)pctx;

	notice(DEBUG_CAT_RENEW, "flash wsc_config\n");
	_1905_flash_out_config(ctx);

#ifdef MAP_R2
	eloop_cancel_timeout(map_r2_notify_ts_config, (void *)ctx, NULL);
	eloop_cancel_timeout(map_notify_transparent_vlan_setting, (void *)ctx, NULL);
	eloop_register_timeout(0, 0, map_r2_notify_ts_config, (void *)ctx, NULL);
	eloop_register_timeout(0, 0, map_notify_transparent_vlan_setting, (void *)ctx, NULL);
#endif

	if (ctx->ap_mld_cfg) {
		_1905_notify_ap_mld_config(ctx, &ctx->mld_bss, 0);
		delete_ap_mld_conf(&ctx->mld_bss);
		ctx->ap_mld_cfg = 0;
	}
#ifdef MAP_R6
	if (ctx->wsc_msg_type) {
		_1905_notify_wsc_reconfig(ctx);
		ctx->wsc_msg_type = 0;
		os_memset(&ctx->cred_reconfig, 0, sizeof(ctx->cred_reconfig));
	}
	if (ctx->bsta_mld_cfg) {
		_1905_notify_bsta_mld_config(ctx, &ctx->mld_bsta);
		delete_bsta_mld_conf(&ctx->mld_bsta);
		ctx->bsta_mld_cfg = 0;
	}

	if (ctx->eht_op_cfg) {
		_1905_notify_eht_operations(ctx, ctx->eht_op);
		delete_eht_operations(ctx->eht_op);
		ctx->eht_op_cfg = 0;
	}
#endif
	return wifi_utils_success;
}

void *create_m2_thread_func(void *arg)
{
	struct wsc_context *wsc_ctx = (struct wsc_context *)arg;
	wsc_ctx->out_len = append_WSC_tlv(wsc_ctx->pkt, wsc_ctx->ctx, wsc_ctx->wsc_type,
		&wsc_ctx->config_data, wsc_ctx->wfa_vendor_extension);

	return NULL;
}

int create_all_m2s(struct p1905_managerd_ctx *ctx, unsigned char *buf,
	unsigned char num, unsigned short *total_len, struct agent_radio_info *agent_radio,
	unsigned char is_block)
{
	unsigned char i = 0, j = 0;
	int ret = 0;
	pthread_t m2_thread_id[16];
	unsigned short len = 0;
	unsigned char *m2_buf = NULL;
	WIFI_UTILS_STATUS status = wifi_utils_success;
	struct wsc_context *wsc = NULL;
	unsigned char tear_down_bss_cnt = 0;

	wsc = (struct wsc_context *)os_malloc(16 * sizeof(struct wsc_context));
	if (wsc == NULL)
		return -1;

	*total_len = 0;

	m2_buf = os_malloc(WSC_TLV_LENGTH * num);
	if (!m2_buf) {
		err(DEBUG_CAT_MISC, "failed to alloc m2_buf on controller\n");
		goto fail;
	}

	/*before building m2, get the corresponding wsc config_data firstly*/
	for (i = 0; i < num; i++) {
		memset(&wsc[j].config_data, 0, sizeof(WSC_CONFIG));

	    status = get_wsc_config((void *)ctx, &wsc[j].config_data,
			&wsc[j].wfa_vendor_extension, agent_radio, is_block);
		if (status == wifi_utils_success)
			j++;
	}

	/*number of j represents that only j configuration data have been get successfully*/
	num = j;

	for (i = 0; i < num; i++) {
		if (wsc[i].wfa_vendor_extension & 0x10)
			tear_down_bss_cnt += 1;
	}

	/* only one M2 for tear down band */
	if (tear_down_bss_cnt == num)
		num = 1;

	for (i = 0; i < num; i++) {
		wsc[i].ctx = ctx;
		wsc[i].pkt = m2_buf + i * WSC_TLV_LENGTH;
		wsc[i].out_len = 0;
		wsc[i].wsc_type = MESSAGE_TYPE_M2;
		ret = pthread_create(&m2_thread_id[i], NULL, create_m2_thread_func, &wsc[i]);
		if (ret < 0)
			err(DEBUG_CAT_AUTOCONF, "worker task init fail for bss(%d)\n", i);
	}

	for (i = 0; i < num; i++) {
		if (pthread_join(m2_thread_id[i], NULL))
			err(DEBUG_CAT_AUTOCONF, "pthread_join fail for bss(%d)\n", i);
	}

	for (i = 0; i < num; i++) {
		if (wsc[i].out_len > WSC_TLV_LENGTH) {
			err(DEBUG_CAT_AUTOCONF, "one wsc message len(%d) > WSC_TLV_LENGTH(%d) bytes\n",
				wsc[i].out_len, WSC_TLV_LENGTH);
			len = 0;
			break;
		}
		os_memcpy(buf + len, wsc[i].pkt, wsc[i].out_len);
		len += wsc[i].out_len;
	}

	*total_len = len;

	os_free(m2_buf);
	os_free(wsc);
	return 1;
fail:
	os_free(wsc);
	return -1;

}

int triger_autoconfiguration(struct p1905_managerd_ctx *ctx)
{
	int i = 0;
	unsigned char radio_id = 0;

	if (ctx->current_autoconfig_info.radio_index != -1) {
		radio_id = ctx->current_autoconfig_info.radio_index;
		notice(DEBUG_CAT_AUTOCONF, "radio "MACSTR" ongoing, wait it done\n",
			MAC2STR(ctx->rinfo[radio_id].identifier));
		return -1;
	}

	for (i = 0; i < ctx->radio_number; i++) {
		if (ctx->rinfo[i].trrigerd_autoconf == 1) {
			ctx->current_autoconfig_info.radio_index = i;
			ctx->enrolle_state = wait_4_send_m1;
			eloop_cancel_timeout(ap_autoconfig_enrolle_step, (void *)ctx, NULL);
			eloop_register_timeout(0, 0, ap_autoconfig_enrolle_step, (void *)ctx, NULL);
			break;
		}
	}
	if (i >= ctx->radio_number) {
		notice(DEBUG_CAT_AUTOCONF, "auto-configuration done on all the radio\n");
		return 2;
	} else {
		notice(DEBUG_CAT_AUTOCONF, "trigger radio "MACSTR" to do auto-configuration\n",
			MAC2STR(ctx->rinfo[i].identifier));
		return 0;
	}
}
void auto_configuration_done(struct p1905_managerd_ctx *ctx)
{
	unsigned char radio_index = 0;

	if (ctx->current_autoconfig_info.radio_index != -1) {
		radio_index = (unsigned char)ctx->current_autoconfig_info.radio_index;
	} else {
		err(DEBUG_CAT_AUTOCONF, "no ongoing autoconfig radio; "
			"ctx->current_autoconfig_info.radio_index=-1;\n");
		return;
	}

	/*set to 0 to stop sm*/
	set_radio_autoconf_trriger(ctx, radio_index, 0);
	ctx->rinfo[radio_index].config_status = MAP_CONF_CONFED;
	ctx->current_autoconfig_info.radio_index = -1;

	triger_autoconfiguration(ctx);
}

int set_radio_autoconf_prepare(struct p1905_managerd_ctx* ctx, unsigned int band, unsigned char set_value)
{
	int i = 0;

	for (i = 0; i < ctx->radio_number; i++) {
		if (ctx->rinfo[i].band == band) {
			ctx->rinfo[i].trrigerd_autoconf = set_value;
			notice(DEBUG_CAT_AUTOCONF, "radio("MACSTR") need %s to do autoconfig\n",
				MAC2STR(ctx->rinfo[i].identifier), set_value ? "" : "not ");
		}
	}

	return 0;
}

int set_radio_autoconf_trriger(struct p1905_managerd_ctx *ctx, unsigned char radio_id, unsigned char set_value)
{
	unsigned char radio_index = 0;

	if (radio_id >= ctx->radio_number) {
		err(DEBUG_CAT_AUTOCONF, "radio_id(%d) > total_radio_number(%d)\n",
			radio_id, ctx->radio_number);
		return -1;
	}

	if (set_value == 1) {
		if (ctx->rinfo[radio_id].teared_down == 1) {
			notice(DEBUG_CAT_AUTOCONF, "radio "MACSTR" teared down, need wait for renew\n",
				MAC2STR(ctx->rinfo[radio_id].identifier));
			return -2;
		}
		if (ctx->current_autoconfig_info.radio_index == radio_id) {
			notice(DEBUG_CAT_AUTOCONF, "radio "MACSTR" ongoing; wait it done\n",
				MAC2STR(ctx->rinfo[radio_id].identifier));
			return -1;
		}
		if (ctx->current_autoconfig_info.radio_index != -1) {
			radio_index = ctx->current_autoconfig_info.radio_index;
			notice(DEBUG_CAT_AUTOCONF, "cancel current radio "MACSTR"\n",
				MAC2STR(ctx->rinfo[radio_index].identifier));
			ctx->enrolle_state = no_ap_autoconfig;
			ctx->rinfo[radio_id].config_status = MAP_CONF_UNCONF;
		}
	}
	ctx->rinfo[radio_id].trrigerd_autoconf = set_value;
	notice(DEBUG_CAT_AUTOCONF, "set radio("MACSTR") autoconfig %strrigered\n",
		MAC2STR(ctx->rinfo[radio_id].identifier), set_value ? "" : "un");

	return 0;
}

unsigned char determin_band_config(struct p1905_managerd_ctx *ctx, unsigned char *almac,
	unsigned char band_cap)
{
	unsigned char i = 0;
	unsigned char bss_cap = 0;
	unsigned char wild_card_mac[ETH_ALEN] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};

	for(i = 0; i < ctx->bss_config_num; i++) {
		if ((!os_memcmp(almac, ctx->bss_config[i].mac, ETH_ALEN) ||
		   !os_memcmp(wild_card_mac, ctx->bss_config[i].mac, ETH_ALEN))
		   && os_strlen(ctx->bss_config[i].ssid)) {
			bss_cap |= ctx->bss_config[i].band_support;
		}
	}

	if (band_cap & bss_cap & BAND_2G_CAP) {
		return BAND_2G_CAP;
	} else if (band_cap & bss_cap & BAND_6G_CAP) {
		return BAND_6G_CAP;
	} else if (band_cap & bss_cap & BAND_5GL_CAP) {
		return BAND_5GL_CAP;
	} else if (band_cap & bss_cap & BAND_5GH_CAP) {
		return BAND_5GH_CAP;
	} else {
		err(DEBUG_CAT_AUTOCONF, "cannot decide config band; bandcap=%02x; bsscap=%02x\n",
			band_cap, bss_cap);
		return BAND_INVALID_CAP;
	}
}

WIFI_UTILS_STATUS config_bss_by_band(struct p1905_managerd_ctx *ctx, unsigned char band,
	WSC_CONFIG *wsc, unsigned char *wfa_vendor_extension)
{
	unsigned char i = 0;
	unsigned char wild_card_mac[ETH_ALEN] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};

	os_memset(wsc, 0, sizeof(WSC_CONFIG));
	for (i = 0; i < ctx->bss_config_num; i++) {
		/*2.4g/5g band*/
		if (!(ctx->bss_config_bitmap[i/(sizeof(int)*8)] & BIT(i%(sizeof(int)*8))) &&
			band == ctx->bss_config[i].band_support) {
			if (!os_memcmp(ctx->ap_config.enrolle_mac, ctx->bss_config[i].mac, ETH_ALEN) ||
				!os_memcmp(wild_card_mac, ctx->bss_config[i].mac, ETH_ALEN)) {
				ctx->bss_config_bitmap[i/(sizeof(int)*8)] |= BIT(i%(sizeof(int)*8));
				break;
			}
		}

	}

	if (i >= ctx->bss_config_num) {
		if (!ctx->bss_config_bitmap[0] && !ctx->bss_config_bitmap[1] &&
			!ctx->bss_config_bitmap[2] && !ctx->bss_config_bitmap[3]) {
			err(DEBUG_CAT_AUTOCONF, "[%d]can not get any wsc config(almac="MACSTR"), no bss config from file\n",
				i, PRINT_MAC(ctx->ap_config.enrolle_mac));
			err(DEBUG_CAT_AUTOCONF, "error!!! cannot happen!!! no bss info for band=%02x! send tear down bit in m2\n", band);
			*wfa_vendor_extension = 0x10;
			goto fail;
		} else {
			err(DEBUG_CAT_AUTOCONF, "no enough bss info for band=%02x! not add extra m2 now\n", band);
			goto fail;
		}
	}

	memcpy(wsc->Ssid, ctx->bss_config[i].ssid, 32);
	wsc->EncrypType = ctx->bss_config[i].encryptype;
	wsc->AuthMode = ctx->bss_config[i].authmode;
	memcpy(wsc->WPAKey, ctx->bss_config[i].key, 64);
	*wfa_vendor_extension = ctx->bss_config[i].wfa_vendor_extension;
	wsc->hidden_ssid = ctx->bss_config[i].hidden_ssid;
	return wifi_utils_success;
fail:
	return wifi_utils_error;
}

void config_sync_error_handler(void *context, void* parent_leaf, void *current_leaf, void *data)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx*)context;
	struct leaf *cur_leaf = (struct leaf *)current_leaf;
	struct os_time now;
	struct topology_response_db *rpdb = NULL;
	unsigned char band = 0;
	struct agent_list_db *agent = NULL;
	unsigned char *if_name = NULL;
	int i = 0;

#ifdef MAP_R3
	struct r3_member *peer = NULL;
	if (ctx->map_version == MAP_PROFILE_R3) {
		peer = get_r3_member(cur_leaf->al_mac);
	}
#endif
	/*doing renew, do not start config error sync*/
	if (ctx->renew_ctx.trigger_renew)
		return;

	os_get_time(&now);

	find_agent_info(ctx, cur_leaf->al_mac, &agent);
	if (!agent) {
		err(DEBUG_CAT_AUTOCONF, "can't find agent info; almac="MACSTR"\n",
			MAC2STR(cur_leaf->al_mac));
		return;
	}

	/*it means only after autoconfig, can check whether should renew the deivce*/
	/*
	if (cur_leaf->band_cap == 0)
		return;
	*/
	if (now.sec - cur_leaf->create_time.sec > CONFIG_SYNC_TOLERATE_TIME) {
		/*to let send renew per about 20 seconds if peer device still can not be configured*/
		if (cur_leaf->renew_send_round > 0)
			cur_leaf->renew_send_round--;

		if (cur_leaf->renew_send_round == 0) {
			rpdb = lookup_tprdb_by_almac(ctx, cur_leaf->al_mac);
			if (!rpdb) {
				err(DEBUG_CAT_RENEW, "can't find topo rsp for agent; almac="MACSTR"\n",
					MAC2STR(cur_leaf->al_mac));
				return;
			}
			if_name = ctx->itf[rpdb->recv_ifid].if_name;
			cur_leaf->renew_send_round = RENEW_ROUND;
			if (!get_agent_all_radio_config_state(agent)) {
#ifdef MAP_R3
				if (peer && peer->security_1905) {
					notice(DEBUG_CAT_DPP, "agent("MACSTR") not finish conifg for all radio; do R3 renew\n",
						MAC2STR(cur_leaf->al_mac));
					insert_cmdu_txq(cur_leaf->al_mac, ctx->p1905_al_mac_addr,
							e_bss_reconfiguration_trigger, ++ctx->mid, if_name, 0);
					process_cmdu_txq(ctx, ctx->trx_buf.buf);
					return;
				}
#endif
				for (i = 0; i < agent->radio_num; i++) {
					if (!agent->ra_info[i].conf_ctx.config_status) {
						if (agent->ra_info[i].band & BAND_2G_CAP)
							band = IEEE802_11_band_2P4G;
						else if (agent->ra_info[i].band & (BAND_5G_CAP))
							band = IEEE802_11_band_5G;
						else if (agent->ra_info[i].band & (BAND_6G_CAP))
							band = IEEE802_11_band_6G;
						break;
					}
				}
				notice(DEBUG_CAT_RENEW,
					"agent("MACSTR") not finish conifg for all radio; do renew on band=%d(0:2G;1:5G;3:6G)\n",
					MAC2STR(cur_leaf->al_mac), band);
				fill_send_tlv(ctx, &band, 1);
				insert_cmdu_txq(cur_leaf->al_mac, ctx->p1905_al_mac_addr,
						e_ap_autoconfiguration_renew, ++ctx->mid, if_name, 0);
				notice(DEBUG_CAT_RENEW,
					"send renew msg on %s to "MACSTR"; mid=0x%04x\n",
					if_name, MAC2STR(cur_leaf->al_mac), ctx->mid);
				process_cmdu_txq(ctx, ctx->trx_buf.buf);
			}
		}
	}
}

int precheck_obj_num(struct p1905_managerd_ctx *ctx, unsigned char *al_mac)
{
	unsigned char radio_idx = 0;
	struct agent_list_db *agent = NULL;
	struct agent_radio_info *radio = NULL;
	int k = 0;
	unsigned char band = BAND_INVALID_CAP;
	unsigned char bss_num_per_radio = 0;
	unsigned char total_bss_num = 0;
	unsigned char wild_card_mac[ETH_ALEN] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};

	find_agent_info(ctx, al_mac, &agent);
	if (!agent) {
		err(DEBUG_CAT_AUTOCONF, "agent not found"MACSTR"\n",
			PRINT_MAC(al_mac));
		return 0;
	}
	while (radio_idx < agent->radio_num) {
		bss_num_per_radio = 0;
		radio = &agent->ra_info[radio_idx];

		band = determin_band_config(ctx, al_mac, radio->band);
		/* idx in wts should start from last one of the radio */
		for (k = 0; k < ctx->bss_config_num; k++) {
			if (band == ctx->bss_config[k].band_support &&
				(!os_memcmp(al_mac, ctx->bss_config[k].mac, ETH_ALEN) ||
				!os_memcmp(ctx->bss_config[k].mac, wild_card_mac, ETH_ALEN))) {
				if (bss_num_per_radio < radio->max_bss_num)
					bss_num_per_radio++;
			}
		}
		/* add max bss num to total once radio match in wts */
		if (bss_num_per_radio)
			total_bss_num += radio->max_bss_num;
		/* how many valid bss configured for the radio */
		radio->config_bss_num = bss_num_per_radio;
		info(DEBUG_CAT_AUTOCONF, "valid bss cnt %d total bss cnt %d of ruid "MACSTR"\n",
			bss_num_per_radio, radio->max_bss_num, MAC2STR(radio->identifier));
		radio_idx++;
	}
	/* total bss num should be sum of max bss num of each radio */
	return total_bss_num;
}

#ifdef MAP_R3
void periodic_send_autoconfig_search(void *eloop_ctx, void *timeout_ctx)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx*)eloop_ctx;
	notice(DEBUG_CAT_DPP, "periodic_send_autoconfig_search on R3 device while R1|R2 onboarding\n");
	ctx->controller_search_cnt++;
	ctx->autoconfig_search_mid = ++ctx->mid;
	reset_send_tlv(ctx);
	ap_autoconfig_search(ctx, ctx->mid);

	eloop_cancel_timeout(periodic_send_autoconfig_search, (void *)ctx, NULL);
	eloop_register_timeout(30, 0, periodic_send_autoconfig_search, (void *)ctx, NULL);
}

int r3_send_bss_reconfig_trigger(struct p1905_managerd_ctx *ctx)
{
	struct topology_response_db *rpdb = NULL;
	leaf_info *leaf_top = NULL;
	int ret = 0;
	unsigned char *if_name = NULL;

	ret = get_top(&ctx->topo_stack, &leaf_top);
	if (ret < 0) {
		notice(DEBUG_CAT_DPP, "BUG here!!!! get top node from stack error\n");
		ctx->renew_ctx.trigger_renew = 0;
		return -1;
	}

	rpdb = lookup_tprdb_by_almac(ctx, leaf_top->al_mac);
	if (!rpdb) {
		notice(DEBUG_CAT_DPP, "BUG here!!!! rpdb almac("MACSTR") not exist\n",
			PRINT_MAC(leaf_top->al_mac));
		ctx->renew_ctx.trigger_renew = 0;
		return -1;
	}
	if_name = ctx->itf[rpdb->recv_ifid].if_name;

	insert_cmdu_txq(leaf_top->al_mac, ctx->p1905_al_mac_addr,
		e_bss_reconfiguration_trigger, ++ctx->mid, if_name, 0);

	ctx->renew_state = wait_4_recv_bss_autoconfig_req;
	eloop_cancel_timeout(controller_renew_bss_step, (void *)ctx, NULL);
	eloop_register_timeout(5, 0, controller_renew_bss_step, (void *)ctx, NULL);
	notice(DEBUG_CAT_DPP, "[R3 renew] send bss reconfig trigger message to "MACSTR"\n",
		MAC2STR(leaf_top->al_mac));

	return 0;
}

/* action frame type from DPP SPEC R2 */
char *actionFrame_typeNum2str(unsigned char type)
{
	switch (type) {
	case DPP_PA_AUTHENTICATION_REQ:
		return "Authentication Request";
	case DPP_PA_AUTHENTICATION_RESP:
		return "Authentication Response";
	case DPP_PA_AUTHENTICATION_CONFIRM:
		return "Authentication Confirm";
	case DPP_PA_PEER_DISCOVERY_REQ:
		return "Peer Discovery Request";
	case DPP_PA_PEER_DISCOVERY_RESP:
		return "Peer Discovery Response";
	case DPP_PA_PKEX_EXCHANGE_REQ:
		return "PKEX Exchange Request";
	case DPP_PA_PKEX_EXCHANGE_RESP:
		return "PKEX Exchange Response";
	case DPP_PA_PKEX_COMMIT_REVEAL_REQ:
		return "PKEX Commit-Reveal Request";
	case DPP_PA_PKEX_COMMIT_REVEAL_RESP:
		return "PKEX Commit-Reveal Response";
	case DPP_PA_CONFIGURATION_RESULT:
		return "Configuration Result";
	case DPP_PA_CONNECTION_STATUS_RESULT:
		return "Connection Status Result";
	case DPP_PA_PRESENCE_ANNOUNCEMENT:
		return "DPP Presence Announcement";
	case DPP_PA_RECONFIG_ANNOUNCEMENT:
		return "DPP Reconfig Announcement";
	case DPP_PA_RECONFIG_AUTH_REQ:
		return "DPP Reconfig Auth Req";
	case DPP_PA_RECONFIG_AUTH_RESP:
		return "DPP Reconfig Auth Resp";
	case DPP_PA_RECONFIG_AUTH_COMFIRM:
		return "DPP Reconfig Auth Confirm";
	default:
		return "unsupported type";
	}
}


char *GasFrame_actionNum2str(unsigned char action)
{
	switch (action) {
	case 0x0A:
	case 0x0C:
		return "DPP Configuration Request";
	case 0x0B:
	case 0x0D:
		return "DPP Configuration Response";
	default:
		return "unsupported type";
	}
}

int dev_send_eapol(void *ctx, unsigned char *dst_almac, unsigned char *eapol_frame, unsigned short eapol_len)
{
	struct p1905_managerd_ctx *pctx = (struct p1905_managerd_ctx *)ctx;

	reset_send_tlv(pctx);
	if (fill_send_tlv(pctx, eapol_frame, eapol_len) == -1)
		notice(DEBUG_CAT_DPP, "fill_send_tlv fail!\n");
	insert_cmdu_txq(dst_almac, pctx->p1905_al_mac_addr,
			e_1905_encap_eapol, ++pctx->mid, pctx->br_name, 0);
	process_cmdu_txq(pctx, eapol_frame);

	return 0;
}

int r3_send_bss_config_req(struct p1905_managerd_ctx *ctx)
{
	unsigned int if_index = 0;

	if_index = ctx->cinfo.recv_ifid;
	insert_cmdu_txq(ctx->cinfo.almac, ctx->p1905_al_mac_addr,
			e_bss_configuration_request, ++ctx->mid,
			ctx->itf[if_index].if_name, 0);
	return 0;
}

int transfer_r3_config_2_wireless_setting(struct p1905_managerd_ctx *ctx)
{
	struct r3_onboarding_info *r3_ctx = &ctx->r3_oboard_ctx;
	unsigned char i, index = 0, j = 0;
	struct r3_member *peer= NULL;

	/*step1. transfer r3 configuration data to r1/r2 autoconfiguration data*/
	if (ctx->current_autoconfig_info.radio_index != -1)
		i = ctx->current_autoconfig_info.radio_index;
	else {
		info(DEBUG_CAT_DPP, "radio index %d invalid\n",
			ctx->current_autoconfig_info.radio_index);
		return wapp_utils_error;
	}

	for (j = 0; j < r3_ctx->total_config_num; j++) {
		if (!os_memcmp(ctx->rinfo[i].identifier,
			r3_ctx->bss_config_data[j].radio_identifier, ETH_ALEN)) {
			os_memcpy(&ctx->current_autoconfig_info.config_data[index++],
				&r3_ctx->bss_config_data[j].config_data, sizeof(WSC_CONFIG));
		}
	}


	if (!index) {
		notice(DEBUG_CAT_DPP, "tear down radio %d, identifier["MACSTR"]\n",
			i, MAC2STR(ctx->rinfo[i].identifier));
		_1905_set_radio_tear_down(ctx, ctx->rinfo[i].identifier, 0);
	}
	else {
		ctx->current_autoconfig_info.config_number = index;

		/*step2. set wireless setting to mapd/wappd/driver*/
		set_wsc_config(ctx);
	}

	/*step3. check whether need we do this for another band*/
	if (++ctx->current_autoconfig_info.radio_index < ctx->radio_number) {
		eloop_cancel_timeout(r3_set_config, (void *)ctx, NULL);
		eloop_register_timeout(1, 0, r3_set_config, (void *)ctx, NULL);
		notice(DEBUG_CAT_DPP, "trigger radio(%d) to do bss config\n",
			ctx->current_autoconfig_info.radio_index);
	}
	else {
		r3_set_config_state(ctx, r3_autoconfig_done);
		ctx->r3_oboard_ctx.onboarding_stage = R3_ONBOARDING_STAGE_DONE;
		notice(DEBUG_CAT_DPP, "bss config done\n");
		ctx->current_autoconfig_info.radio_index = -1;

		peer = get_r3_member(r3_ctx->peer_almac);

		if (peer) {
			/* send bss configuration result message after configuration done */
			eloop_cancel_timeout(wait_send_bss_configuration_result, (void *)ctx, (void *)peer);
			eloop_register_timeout(3, 0, wait_send_bss_configuration_result, (void *)ctx, peer);
		}

		if (ctx->ap_mld_cfg) {
			_1905_notify_ap_mld_config(ctx, &ctx->mld_bss, 0);
			delete_ap_mld_conf(&ctx->mld_bss);
			ctx->ap_mld_cfg = 0;
		}
#ifdef MAP_R6
		if (ctx->bsta_mld_cfg) {
			_1905_notify_bsta_mld_config(ctx, &ctx->mld_bsta);
			delete_bsta_mld_conf(&ctx->mld_bsta);
			ctx->bsta_mld_cfg = 0;
		}
#endif
	}

	return 0;
}

void r3_set_config(void *eloop_ctx, void *timeout_ctx)
{
	transfer_r3_config_2_wireless_setting((struct p1905_managerd_ctx *)eloop_ctx);
}

void r3_set_config_state(struct p1905_managerd_ctx *ctx,  unsigned char state)
{
	struct r3_onboarding_info *r3_info = &ctx->r3_oboard_ctx;

	r3_info->r3_config_state = state;
}

void r3_config_sm(struct p1905_managerd_ctx *ctx)
{
	struct r3_onboarding_info *r3_info = &ctx->r3_oboard_ctx;

	switch(r3_info->r3_config_state) {
		case wait_4_send_bss_autoconfig_req:
		{
			r3_send_bss_config_req(ctx);
			r3_set_config_state(ctx, wait_4_recv_bss_autoconfig_resp);
			eloop_cancel_timeout(r3_config_sm_step, (void *)ctx, NULL);
			eloop_register_timeout(2, 0, r3_config_sm_step, (void *)ctx, NULL);
		}
			break;
		case wait_4_recv_bss_autoconfig_resp:
		{
			if (r3_info->bss_req_retry_cnt < 4) {
				r3_info->bss_req_retry_cnt ++;
				notice(DEBUG_CAT_DPP, "[BSS Config]retry %d times BSS Config procedure\n", r3_info->bss_req_retry_cnt);
				r3_set_config_state(ctx, wait_4_send_bss_autoconfig_req);

				eloop_cancel_timeout(r3_config_sm_step, (void *)ctx, NULL);
				eloop_register_timeout(2, 0, r3_config_sm_step, (void *)ctx, NULL);
			} else {
				r3_info->bss_req_retry_cnt = 0;
				ctx->r3_oboard_ctx.bss_renew = 0;
				r3_set_config_state(ctx, no_r3_autoconfig);

				ctx->r3_oboard_ctx.onboarding_stage = R3_ONBOARDING_STAGE_INVALID;
				eloop_cancel_timeout(r3_config_sm_step, (void *)ctx, NULL);
				//eloop_register_timeout(0, 0, r3_config_sm_step, (void *)ctx, NULL);
				notice(DEBUG_CAT_DPP, "[BSS Config]retry timeout,start autoconfig search procedure\n");
				eloop_cancel_timeout(ap_controller_search_step, (void *)ctx, NULL);
				ctx->enrolle_state = wait_4_send_controller_search;
				eloop_register_timeout(RECV_CONFIG_RSP_TIME, 0, ap_controller_search_step, (void *)ctx, NULL);
			}
		}
			break;
		case wait_4_set_r3_config:
		{
			ctx->current_autoconfig_info.radio_index = 0;
			r3_set_config((void *)ctx, NULL);
		}
			break;
		default:
			break;
	}
}

void r3_config_sm_step(void *eloop_ctx, void *timeout_ctx)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx*)eloop_ctx;

	r3_config_sm(ctx);

	common_process(ctx, &ctx->trx_buf);
}


void wait_send_bss_configuration_result(void *eloop_ctx, void *timeout_ctx)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx*)eloop_ctx;
	struct r3_member *peer = timeout_ctx;

	if (!eloop_ctx || !timeout_ctx) {
		warn(DEBUG_CAT_DPP, "NULL pointer\n");
		return;
	}

	notice(DEBUG_CAT_DPP, "send bss config result to "MACSTR"\n", MAC2STR(peer->al_mac));

	insert_cmdu_txq(peer->al_mac, ctx->p1905_al_mac_addr,
		e_bss_configuration_result, ++ctx->mid, ctx->br_name, 0);
    return;
}
#endif

int dump_bss_config_info(struct p1905_managerd_ctx *ctx, char *buf, int max_len)
{
	int ret = 0, len = 0;
	struct agent_list_db *agent = NULL;
	int agent_max_bss_num = 0;
	int controller_max_bss_num = 0;
	int agent_conf_bss_num = 0;
	int total_bss_num = 0;
	int j = 0;

	ret = snprintf(buf, max_len, "bss_config_info:\n====================BSS Configuration Info====================\n\n");
	if (os_snprintf_error(max_len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	total_bss_num = get_current_bss_num(ctx, NULL);
	ret = snprintf(buf + len, max_len - len, "== The number of configured BSS in the topology: %d\n\n", total_bss_num);
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;
	ret = snprintf(buf + len, max_len - len, "== The maximum number of BSS: %d\n\n", ctx->block_bss_info.max_bss_count);
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	for (j = 0; j < ctx->radio_number; j++)
		controller_max_bss_num += ctx->rinfo[j].bss_number;

	ret = snprintf(buf + len, max_len - len, "== Controller("MACSTR"): max bss(%d) configured bss(%d)\n\n",
		PRINT_MAC(ctx->p1905_al_mac_addr), controller_max_bss_num, ctx->block_bss_info.auto_config_num);
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	SLIST_FOREACH(agent, &(ctx->agent_head), agent_entry)
	{
		agent_conf_bss_num = get_agent_total_config_bss_num(agent);
		agent_max_bss_num = get_agent_total_bss_num(agent);
		if (agent->is_block == 1) {
			ret = snprintf(buf + len, max_len - len,  "== Agent("MACSTR
				"): max bss(%d) configured bss(%d) (Unconfig) exceeding the maximum BSS quantity limit(%d)\n\n",
				PRINT_MAC(agent->almac), agent_max_bss_num, agent_conf_bss_num, ctx->block_bss_info.max_bss_count);
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf fail\n");
				return -1;
			}
			len += ret;
		} else {
			ret = snprintf(buf + len, max_len - len, "== Agent("MACSTR"): max bss(%d) configured bss(%d)\n\n",
				PRINT_MAC(agent->almac), agent_max_bss_num, agent_conf_bss_num);
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf fail\n");
				return -1;
			}
			len += ret;
		}
	}
	ret = snprintf(buf + len, max_len - len,  "==============================================================\n");
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	return len;
}

int dump_sm_state_info(struct p1905_managerd_ctx *ctx, char *buf, int max_len)
{
	int ret = 0, len = 0;

	ret = snprintf(buf, max_len, "\nsm state info:\n");
	if (os_snprintf_error(max_len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	ret = snprintf(buf + len, max_len - len,
		"\tcontroller_search_state=%d(%s), enrollee_state=%d(%s)\n",
			ctx->controller_search_state,
			get_search_state_str(ctx->controller_search_state),
			ctx->enrolle_state, get_enrollee_state_str(ctx->enrolle_state));
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	return len;
}

int dump_controller_info(struct p1905_managerd_ctx *ctx, char *buf, int max_len)
{
	int ret = 0, len = 0;

	ret = snprintf(buf, max_len, "\ncontroller info:\n");
	if (os_snprintf_error(max_len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	ret = snprintf(buf + len, max_len - len,
		"\talmac="MACSTR"; recv_ifid=%d; recv_ifname=%s; "
		"map_ver=%d\n",
		MAC2STR(ctx->cinfo.almac), ctx->cinfo.recv_ifid,
		ctx->cinfo.local_ifname, ctx->cinfo.profile);
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	return len;
}

int controller_trigger_block_bss_r2(struct p1905_managerd_ctx *ctx, unsigned char *almac)
{
	struct topology_response_db *rpdb = NULL;
	struct agent_list_db *agent_info = NULL;
	unsigned char *if_name = NULL;
	unsigned char freq_band = 0x00;
	int i = 0;
	int retry_timer = 5;

	if (ctx == NULL || almac == NULL) {
		err(DEBUG_CAT_AUTOCONF, "BUG here!!Invalid input parameters\n");
		return -1;
	}

	rpdb = lookup_tprdb_by_almac(ctx, almac);
	if (rpdb == NULL) {
		err(DEBUG_CAT_AUTOCONF, "Cannot find for almac("MACSTR") in topology response database\n", PRINT_MAC(almac));
		eloop_register_timeout(retry_timer, 0, controller_block_bss_configuration, (void *)ctx,
			(void *)almac);
		return 0;
	} else
		eloop_cancel_timeout(controller_block_bss_configuration, (void *)ctx, (void *)almac);

	if_name = ctx->itf[rpdb->recv_ifid].if_name;

	find_agent_info(ctx, almac, &agent_info);
	if (agent_info == NULL) {
		err(DEBUG_CAT_AUTOCONF, "Cannot find agent_info for almac("MACSTR")\n", PRINT_MAC(almac));
		return -1;
	}

	/*in order to be compatible with older version, change the renew freq band*/
	for (i = 0; i < agent_info->radio_num; i++) {
		if (!agent_info->ra_info[i].conf_ctx.config_status) {
			if (agent_info->ra_info[i].band & BAND_2G_CAP)
				freq_band = 0x00;
			else if (agent_info->ra_info[i].band & BAND_5G_CAP)
				freq_band = 0x01;
			break;
		}
	}

	if (fill_send_tlv(ctx, &freq_band, 1) < 0)
		return -1;

	info(DEBUG_CAT_AUTOCONF, "controller_send_renew ++ freq_band=%02x(0 indicates 2.4G, 1 indicates 5G)\n",
		freq_band);

	insert_cmdu_txq(almac, ctx->p1905_al_mac_addr,
		e_ap_autoconfiguration_renew, ++ctx->mid, if_name, 0);

	if (!ctx->MAP_Cer) {
		if (agent_info && agent_info->wts_syn_done == 1) {
			info(DEBUG_CAT_AUTOCONF, "reset agent wts sync state\n");
			agent_info->wts_syn_done = 0;
		}
	}
	return 0;
}

int controller_trigger_block_bss_r3(struct p1905_managerd_ctx *ctx, unsigned char *almac)
{
#ifdef MAP_R3
	struct topology_response_db *rpdb = NULL;
	unsigned char *if_name = NULL;
	int retry_timer = 5;

	rpdb = lookup_tprdb_by_almac(ctx, almac);
	if (rpdb == NULL) {
		err(DEBUG_CAT_AUTOCONF, "Cannot find for almac("MACSTR") in topology response database\n", PRINT_MAC(almac));
		eloop_register_timeout(retry_timer, 0, controller_block_bss_configuration, (void *)ctx,
			(void *)almac);
		return 0;
	} else
		eloop_cancel_timeout(controller_block_bss_configuration, (void *)ctx, (void *)almac);

	if_name = ctx->itf[rpdb->recv_ifid].if_name;

	insert_cmdu_txq(almac, ctx->p1905_al_mac_addr,
		e_bss_reconfiguration_trigger, ++ctx->mid, if_name, 0);

	notice(DEBUG_CAT_AUTOCONF, "[BSS Re-Config] send bss reconfig trigger message to "MACSTR" with mid=%04x on %s\n",
		 MAC2STR(almac), ctx->mid, if_name);
#endif /*MAP_R3*/
	return 0;
}

void controller_block_bss_configuration(void *eloop_ctx, void *user_ctx)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx *)eloop_ctx;
	unsigned char *almac = (unsigned char *)user_ctx;
	struct agent_list_db *agent = NULL;
#ifdef MAP_R3
	struct r3_member *peer = NULL;
#endif /*MAP_R3*/

	find_agent_info(ctx, almac, &agent);
	if (!agent) {
		err(DEBUG_CAT_AUTOCONF, "Cannot find agent info for al_mac("MACSTR")\n", MAC2STR(almac));
		return;
	}

	if (agent->retry_block_count > 0) {
		agent->retry_block_count--;
#ifdef MAP_R3
		if (ctx->map_version == MAP_PROFILE_R3)
			peer = get_r3_member(agent->almac);
		if (peer != NULL && peer->security_1905)
			controller_trigger_block_bss_r3(ctx, agent->almac);
		else
#endif /*MAP_R3*/
			controller_trigger_block_bss_r2(ctx, agent->almac);
	}
}


void controller_block_bss_configuration_mechanism(struct p1905_managerd_ctx *ctx)
{
	struct agent_list_db *agent = NULL;
	int current_bss_num = 0;
	int agent_bss_num = 0;
	int left_bss_num = 0;
	char *dump_buf = NULL;
	int dump_len = 0;

	dump_buf =  os_zalloc(MAX_PKT_LEN);
	if (!dump_buf) {
		err(DEBUG_CAT_AUTOCONF, "os_zalloc fail\n");
		return;
	}

	/*1.check if current number of bss exceeds the limit*/
	current_bss_num = get_current_bss_num(ctx, NULL);

	SLIST_FOREACH(agent, &(ctx->agent_head), agent_entry)
	{
		if (current_bss_num <= ctx->block_bss_info.max_bss_count)
			break;
		if (agent->is_block == 1)
			continue;

		agent_bss_num = get_agent_total_config_bss_num(agent);
		agent->is_block = 1;

		err(DEBUG_CAT_AUTOCONF, "current bss num:%d agent bss num:%d\\n", current_bss_num, agent_bss_num);
		err(DEBUG_CAT_AUTOCONF, "Block agent"MACSTR"\n", MAC2STR(agent->almac));
		os_memset(dump_buf, 0, MAX_PKT_LEN);
		dump_len = dump_bss_config_info(ctx, dump_buf, MAX_PKT_LEN);
		if (dump_len < 0) {
			err(DEBUG_CAT_AUTOCONF, "dump_bss_config_info fail\n");
			goto error;
		}
		notice(DEBUG_CAT_AUTOCONF, "%s", dump_buf);
		agent->retry_block_count = 4;
		eloop_register_timeout(0, 0, controller_block_bss_configuration,
			(void *)ctx, (void *)agent->almac);
		current_bss_num -= agent_bss_num;
	}

	/*2. get left bss number*/
	left_bss_num = ctx->block_bss_info.max_bss_count - current_bss_num;

	/*3. get agent bss number to unblock*/
	SLIST_FOREACH(agent, &(ctx->agent_head), agent_entry)
	{
		if (left_bss_num <= 0)
			break;

		if (agent->is_block == 0)
			continue;

		agent_bss_num = precheck_obj_num(ctx, agent->almac);

		if (agent_bss_num > left_bss_num) {
			clear_agent_config_bss_num(agent);
			continue;
		}

		agent->is_block = 0;
		agent->retry_block_count = 4;
		err(DEBUG_CAT_AUTOCONF, "left bss num:%d agent bss num:%d\n", left_bss_num, agent_bss_num);
		err(DEBUG_CAT_AUTOCONF, "Unblock agent"MACSTR"\n", MAC2STR(agent->almac));
		os_memset(dump_buf, 0, MAX_PKT_LEN);
		dump_len = dump_bss_config_info(ctx, dump_buf, MAX_PKT_LEN);
		if (dump_len < 0) {
			err(DEBUG_CAT_AUTOCONF, "dump_bss_config_info fail\n");
			goto error;
		}
		notice(DEBUG_CAT_AUTOCONF, "%s", dump_buf);
		eloop_register_timeout(0, 0, controller_block_bss_configuration,
				(void *)ctx, (void *)agent->almac);
		left_bss_num -= agent_bss_num;
	}

error:
	if (dump_buf)
		os_free(dump_buf);
}

#ifdef EM_PLUS_SUPPORT
void reset_ignore_renew_flag(void *eloop_ctx, void *timeout_ctx)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx *)eloop_ctx;

	ctx->ignore_renew = 0;
	debug(DEBUG_CAT_AUTOCONF, "change ignore_renew flag to %d\n", ctx->ignore_renew);

}
#endif
