/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2021-2022  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

/*
 * qos.c, it's used to support MAP R4 qos management
 *
 */
#ifdef MAP_R5
#include <arpa/inet.h>

#include "qos.h"
#include "debug.h"
#include "cmdu_message.h"
#include "multi_ap.h"
#include "_1905_lib_io.h"
#include "service_prioritization.h"
#include "cmdu_tlv.h"
#include "cmdu.h"
#include "eloop.h"

#define IPV4STR "%d.%d.%d.%d"
#define IPV6STR "%04x:%04x:%04x:%04x:%04x:%04x:%04x:%04x"
#define QOS_CONF_PATH "/etc/map/qos.cfg"

#define NIP4(addr) \
	((unsigned char *)&addr)[0], \
	((unsigned char *)&addr)[1], \
	((unsigned char *)&addr)[2], \
	((unsigned char *)&addr)[3]

#define NIP6(addr) \
	ntohs(addr[0]), \
	ntohs(addr[1]), \
	ntohs(addr[2]), \
	ntohs(addr[3]), \
	ntohs(addr[4]), \
	ntohs(addr[5]), \
	ntohs(addr[6]), \
	ntohs(addr[7])

#define MAX_MSCS_CFG_CNT 32
#define MAX_SCS_CFG_CNT 32

unsigned char max_mscs_cfg_count = MAX_MSCS_CFG_CNT;
unsigned char max_scs_cfg_count = MAX_SCS_CFG_CNT;

unsigned char send_buf[2048] = {0};
char g_bitmap[9] = {0};

struct qos_management_descriptor_tlv g_qos_mgmt_des_tlv;

u8 zero_mac[] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
u16 g_qmid = 1;

struct index_string_tbl {
	int idx;
	char *str;
};

struct index_string_tbl err_code_tbl[] = {
	{STATUS_SUCCESS,		"success"},
	{STATUS_INVALID_POINTER,	"invalid pointer"},
	{STATUS_INVALID_PARAM,		"invalid parameter"},
	{STATUS_INVALID_CMD_TYPE,	"invalid cmd type"},
	{STATUS_INVALID_ALMAC,		"invalid almac address"},
	{STATUS_INVALID_STAMAC,		"invalid stamac address"},
	{STATUS_INVALID_BSSID,		"invalid bssid address"},
	{STATUS_INVALID_ACTION,		"invalid action type"},
	{STATUS_INVALID_BITMAP,		"invalid bitmap"},
	{STATUS_INVALID_UP,		"invalid up"},
	{STATUS_INVALID_VERSION,	"invalid ip version"},
	{STATUS_INVALID_IP,		"invalid ip address"},
	{STATUS_INVALID_PORT,		"invalid port"},
	{STATUS_INVALID_PROTOCOL,	"invalid protocol"},
	{STATUS_INVALID_DIR,		"invalid direction"},
	{STATUS_INVALID_QOSCHAR,	"invalid qos characteristics parameter"},
	{STATUS_INVALID_DSCP_EXCEPTION, "invalid dscp exception"},
	{STATUS_INVALID_DSCP_RANGE,	"invalid dscp range"},
	{STATUS_INVALID_BUFLEN,		"invalid buffer length"},
	{STATUS_CFG_EXISTED,		"configuration is existed"},
	{STATUS_CFG_NOT_EXISTED,	"configuration is not existed"},
	{STATUS_CFG_IS_THE_SAME,	"configuration is the same"},
	{STATUS_ALLOC_MEM_FAIL,		"allocate memory fail"},
	{STATUS_INSUFFICIENT_PARAM,	"insufficient parameters"},
	{STATUS_NO_CLIENT_FOUND,	"no client found"},
	{STATUS_CMD_NOT_SUPPORT,	"command not support on this device"},
	{STATUS_INSUFFICIENT_RESOURCE,	"insufficient resource for request"},
	{STATUS_MEMORY_OVERFLOW,	"memory overflow"},
	{STATUS_UNKNOWN,		"unknown status"}
};

struct index_string_tbl ip_protocol_tbl[] = {
	{IP_TYPE_ICMP,		"ICMP\0"},
	{IP_TYPE_IGMP,		"IGMP\0"},
	{IP_TYPE_TCP,		"TCP\0"},
	{IP_TYPE_UDP,		"UDP\0"},
	{IP_TYPE_ESP,		"ESP\0"},
	{IP_TYPE_IGRP,		"IGRP\0"},
	{IP_TYPE_OSPF,		"OSPF\0"},
	{IP_TYPE_UNKNOWN,	"unknown type\0"}
};

extern void insert_cmdu_txq(unsigned char *dmac, unsigned char *smac, msgtype mtype,
	unsigned short mid, unsigned char *ifname, unsigned char need_update_mid);

void qos_mgmt_init(void *context)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx *)context;

	if (!ctx)
		return;

	memset(&ctx->map_policy.qos_mgmt_policy, 0, sizeof(ctx->map_policy.qos_mgmt_policy));
	memset(&ctx->dscp_policy_act_frm, 0, sizeof(ctx->dscp_policy_act_frm));
	dl_list_init(&ctx->qos_mgmt_desc_list);

	ctx->mscs_list_cnt = 0;
	ctx->scs_list_cnt = 0;
	dl_list_init(&ctx->mscs_list);
	dl_list_init(&ctx->scs_list);
	dl_list_init(&ctx->qosmap_list);
	dl_list_init(&ctx->disallowed_list);
}

#define clear_dl_list(type, target_list)				\
{									\
	type *p = NULL, *n = NULL;					\
									\
	dl_list_for_each_safe(p, n, target_list, type, list) {		\
		dl_list_del(&p->list);					\
		os_free(p);						\
	}								\
}

void qos_mgmt_deinit(void *context)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx *)context;

	if (!ctx)
		return;

	ctx->mscs_list_cnt = 0;
	ctx->scs_list_cnt = 0;
	clear_dl_list(struct mscs_cfg, &ctx->mscs_list);
	clear_dl_list(struct scs_cfg, &ctx->scs_list);
	clear_dl_list(struct qos_map, &ctx->qosmap_list);
	clear_dl_list(struct mscs_scs_disallowed, &ctx->disallowed_list);
	clear_dl_list(struct qos_mgmt_descriptor, &ctx->qos_mgmt_desc_list);
}

int parse_qos_management_policy_tlv(unsigned char *buf,
	unsigned short len, struct qos_management_policy *qos_policy)
{
	unsigned char *temp_buf;
	unsigned short i = 0, num = 0;
	int total_tlv_length = 0, leftlen = len;

	if (!buf || !leftlen || !qos_policy) {
		err(DEBUG_CAT_QOS, "invalid parameters, buf:%p, leftlen:%d, qos_policy:%p.\n",
			buf, leftlen, qos_policy);
		return -1;
	}

	temp_buf = buf;
	memset(qos_policy, 0, sizeof(*qos_policy));
	if (leftlen < 3) {
		err(DEBUG_CAT_QOS, "invalid qos mgmt policy tlv len:%d.\n", leftlen);
		goto error;
	}

	num = *temp_buf++;
	debug(DEBUG_CAT_QOS, "numMSCSDisallowed = %d\n", num);
	leftlen--;

	if (leftlen < (num * MAC_ADDR_LEN + 2)) {
		err(DEBUG_CAT_QOS, "no enough data for MSCSDisallowed STA list leftlen:%d.\n", leftlen);
		goto error;
	}

	for (i = 0; i < num; i++) {
		if (i >= MAX_NUM_DISALLOWED) {
			warn(DEBUG_CAT_QOS, "Num of MSCS disallowed exceed, %d > %d, it was trimmed\n",
				num, MAX_NUM_DISALLOWED);
			continue;
		}
		memcpy(qos_policy->MSCSDisallowed[i], (temp_buf + (i * MAC_ADDR_LEN)), MAC_ADDR_LEN);
		qos_policy->numMSCSDisallowed = i + 1;

		info(DEBUG_CAT_QOS, "add STA ("MACSTR") to MSCS disallow list, cnt = %d.\n",
			PRINT_MAC(qos_policy->MSCSDisallowed[i]), i + 1);
	}
	temp_buf += (num * MAC_ADDR_LEN);
	total_tlv_length += (num * MAC_ADDR_LEN);
	leftlen -= (num * MAC_ADDR_LEN);

	num = *temp_buf++;
	debug(DEBUG_CAT_QOS, "numSCSDisallowed = %d\n", num);
	leftlen--;

	if (leftlen < (num * MAC_ADDR_LEN + 1)) {
		err(DEBUG_CAT_QOS, "no enough data for SCSDisallowed STA list leftlen:%d.\n", leftlen);
		goto error;
	}

	for (i = 0; i < num; i++) {
		if (i >= MAX_NUM_DISALLOWED) {
			warn(DEBUG_CAT_QOS, "Num of SCS disallowed exceed, %d > %d, it was trimmed\n",
				num, MAX_NUM_DISALLOWED);
			continue;
		}
		memcpy(qos_policy->SCSDisallowed[i], (temp_buf + (i * MAC_ADDR_LEN)), MAC_ADDR_LEN);
		qos_policy->numSCSDisallowed = i + 1;

		info(DEBUG_CAT_QOS, "add STA ("MACSTR") to SCS disallow list, cnt=%d.\n",
			PRINT_MAC(qos_policy->SCSDisallowed[i]), i + 1);
	}
	temp_buf += (num * MAC_ADDR_LEN);
	total_tlv_length += (num * MAC_ADDR_LEN);
	leftlen -= (num * MAC_ADDR_LEN);

	if ((*temp_buf) & 0x80)
		qos_policy->dscp_to_up_en = 1;
	if ((*temp_buf) & 0x40)
		qos_policy->dscp_policy_en = 1;

	temp_buf++;
	total_tlv_length++;
	leftlen--;

	return 0;

error:
	err(DEBUG_CAT_QOS, "parse tlv error; type=0x%02x, len=%d\n", *(buf-3), *(buf-2));
	err_hexdump(DEBUG_CAT_QOS, "dump tlv:", buf, len);
	return -1;
}

int parse_qos_management_descriptor_tlv(unsigned char *buf, unsigned short len,
	struct qos_management_descriptor_tlv *tlv)
{
	unsigned short leftlen = 0;
	unsigned char *temp = buf;

	if (!temp || !len || !tlv) {
		err(DEBUG_CAT_QOS, "null pointer found, temp:%p, len:%d, tlv:%p\n", temp, len, tlv);
		return -1;
	}

	leftlen = len;
	if (leftlen > (2 + MAC_ADDR_LEN*2 + MAX_DESCRIPTOR_LEN) ||
		leftlen <= (2 + MAC_ADDR_LEN*2)) {
		err(DEBUG_CAT_QOS, "error, too large/small qos management descriptor tlv length=%d\n", leftlen);
		goto error;
	}

	os_memset(tlv, 0, sizeof(struct qos_management_descriptor_tlv));

	tlv->type = QOS_MANAGEMENT_DESCRIPTOR_TLV_TYPE;
	tlv->length = leftlen;
	tlv->qmid = be_to_host16(*((unsigned short *)temp));
	temp += 2;
	leftlen -= 2;

	memcpy(tlv->bssid, temp, MAC_ADDR_LEN);
	temp += MAC_ADDR_LEN;
	leftlen -= MAC_ADDR_LEN;

	memcpy(tlv->sta_mac, temp, MAC_ADDR_LEN);
	temp += MAC_ADDR_LEN;
	leftlen -= MAC_ADDR_LEN;

	if (leftlen > 0) {
		memcpy(tlv->descriptor, temp, leftlen);
		temp += leftlen;
	}

	return 0;

error:
	err(DEBUG_CAT_QOS, "parse tlv error; type=0x%02x, len=%d\n", *(buf-3), *(buf-2));
	err_hexdump(DEBUG_CAT_QOS, "dump tlv:", buf, len);
	return -1;
}

void qos_management_policy_check(void *context, void *timeout_ctx)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx *)context;
	struct qos_management_policy *Policy = NULL;

	if (!ctx) {
		err(DEBUG_CAT_QOS, "ctx is null pointer.\n");
		return;
	}

	Policy = &ctx->map_policy.qos_mgmt_policy;
	if (Policy->numMSCSDisallowed || Policy->numSCSDisallowed) {
		_1905_notify_qos_mgmt_policy(ctx, Policy);
		memset(Policy, 0, sizeof(*Policy));
	}
}

void qos_management_descriptor_tlv_check(void *context, void *timeout_ctx)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx *)context;
	struct qos_management_descriptor_tlv *tlv = NULL;
	struct qos_mgmt_descriptor *pos = NULL, *tmp = NULL;

	if (!ctx) {
		err(DEBUG_CAT_QOS, "ctx is null pointer.\n");
		return;
	}

	dl_list_for_each_safe(pos, tmp, &ctx->qos_mgmt_desc_list, struct qos_mgmt_descriptor, list) {
		tlv = &pos->qosmgmttlv;
		if (tlv->type == QOS_MANAGEMENT_DESCRIPTOR_TLV_TYPE &&
			tlv->length < (2 + MAC_ADDR_LEN*2 + MAX_DESCRIPTOR_LEN) &&
			tlv->length > (2 + MAC_ADDR_LEN*2)) {
			tlv->length = host_to_be16(tlv->length);

			debug(DEBUG_CAT_QOS, "send qos mgmt descriptor to mapd.\n");
			_1905_notify_qos_mgmt_descriptor(ctx, tlv);
		}

		/*remove node*/
		dl_list_del(&pos->list);
		os_free(pos);
	}
}

void qos_management_dscp_mapping_tbl_check(void *context, void *timeout_ctx)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx *)context;
	struct sp_dscp_pcp_mapping_table *table = NULL;

	if (!ctx) {
		err(DEBUG_CAT_QOS, "ctx is null pointer.\n");
		return;
	}

	table = &ctx->sp_dp_table;
	if (table->enable != 1)
		return;

	_1905_notify_qos_mgmt_dscp_tbl(ctx, table);
}

unsigned short append_qos_mgmt_descriptor_tlv(unsigned char *pkt,
	struct qos_management_descriptor_tlv *tlv)
{
	unsigned short total_length = 0;

	*pkt++ = tlv->type;
	total_length += 1;

	*(unsigned short *)(pkt) = host_to_be16(tlv->length);
	pkt += 2;
	total_length += 2;

	memcpy(pkt, &tlv->qmid, tlv->length);
	total_length += tlv->length;

	return total_length;
}

/**
 *  create qos management notification message.
 *
 * \param  buf  pointer to cmdu message header start position.
 * \param  al_mac  pointer of local abstraction layer mac address.
 * \return length of total tlvs included in this message
 */
unsigned short create_qos_management_notification_message(
	unsigned char *tlv_buf, unsigned char *buf, unsigned char *al_mac)
{
	unsigned char *tlv_temp_buf = tlv_buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length = 0;

	msg_hdr = (cmdu_message_header *)buf;

	length = append_qos_mgmt_descriptor_tlv(tlv_temp_buf, &g_qos_mgmt_des_tlv);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	*-8(cmdu header size)) ==>padding
	*/
	if (total_tlvs_length < MIN_TLVS_LENGTH)	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	/*0x00: for this version of the specification */
	/*0x01~0xFF: Reserved Values */
	msg_hdr->message_version = 0x0;

	/*set reserve field to 0 */
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(QOS_MANAGEMENT_NOTIFICATION);
	msg_hdr->relay_indicator = 0x0;
	/* set reserve field to 0 */
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;
}

int process_qos_management_notification_message(
	void *context, unsigned char *buf, unsigned int left_tlv_len)
{
	int ret = -1;
	unsigned char *type = NULL, *value = NULL;
	unsigned short len = 0, temp = 0;
	unsigned int tlv_len = 0;
	struct qos_management_descriptor_tlv qosmgmttlv = {0};
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx *)context;
	struct qos_mgmt_descriptor *newnode = NULL;

	if (!buf) {
		err(DEBUG_CAT_QOS, "buf is NULL.\n");
		return -1;
	}

	type = buf;
	while (1) {
		if (left_tlv_len < 3) {
			err(DEBUG_CAT_QOS, "TLV content is empty. type:0x%0x)\n", *type);
			break;
		}

		temp = *((unsigned short *)(type+1));
		len = be_to_host16(temp);
		if (len == 0 || len > 1024) {
			err(DEBUG_CAT_QOS, "invalid TLV len:%d.\n", len);
			ret = -1;
			break;
		}
		value = type + 3;
		tlv_len = len + 3;

		if (left_tlv_len < tlv_len) {
			err(DEBUG_CAT_QOS, "invalid TLV len, type:0x%0x,tlv_len:%d, left_tlv_length:%d.\n",
			      *type, tlv_len, left_tlv_len);
			break;
		}

		if (*type == QOS_MANAGEMENT_DESCRIPTOR_TLV_TYPE) {
			ret = parse_qos_management_descriptor_tlv(value, len, &qosmgmttlv);
			if (ret < 0)
				err(DEBUG_CAT_QOS, "parse qos mgmt descriptor tlv\n");

			/*add new node*/
			newnode = (struct qos_mgmt_descriptor *)os_malloc(sizeof(struct qos_mgmt_descriptor));
			if (newnode) {
				os_memcpy(&newnode->qosmgmttlv, &qosmgmttlv, sizeof(qosmgmttlv));
				dl_list_add_tail(&ctx->qos_mgmt_desc_list, &newnode->list);
			}
			break;
		} else if (*type == END_OF_TLV_TYPE)
			break;

		type += tlv_len;
		left_tlv_len -= tlv_len;
	}

	eloop_register_timeout(2, 0, qos_management_descriptor_tlv_check, (void *)ctx, NULL);

	return ret;
}

int qos_management_tlv_process(void *context, unsigned char *rcv_buf, unsigned short len)
{
	int ret = 0;
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx *)context;
	struct qos_management_descriptor_tlv *ptlv = (struct qos_management_descriptor_tlv *)rcv_buf;

	debug(DEBUG_CAT_QOS, "-->process qos mgmt tlv.\n");

	if (!context || !rcv_buf) {
		err(DEBUG_CAT_QOS, "NULL pointer context:%p, rcv_buf:%p\n", context, rcv_buf);
		return -1;
	}

	if (ptlv->type != QOS_MGMT_DESCRIPTOR_TLV) {
		err(DEBUG_CAT_QOS, " incorrect qos management descriptor type:0x%x\n", ptlv->type);
		return -1;
	}


	if (len != sizeof(g_qos_mgmt_des_tlv) ||
		(ptlv->length > (QOS_MGMT_DES_TLV_HEADER_LEN + MAX_DESCRIPTOR_LEN))) {
		err(DEBUG_CAT_QOS, " incorrect qos management tlv, buflen:%d, tlvlen:%d\n", len, ptlv->length);
		return -1;
	}

	memset(&g_qos_mgmt_des_tlv, 0, sizeof(g_qos_mgmt_des_tlv));
	memcpy(&g_qos_mgmt_des_tlv, rcv_buf, sizeof(g_qos_mgmt_des_tlv));

	info(DEBUG_CAT_QOS, "send QOS_MANAGEMENT_NOTIFICATION to Controller "MACSTR", tlv_len=%d\n",
		MAC2STR(ctx->cinfo.almac), g_qos_mgmt_des_tlv.length);

	insert_cmdu_txq(ctx->cinfo.almac, ctx->p1905_al_mac_addr, e_qos_management_notification,
		++ctx->mid, ctx->itf[ctx->cinfo.recv_ifid].if_name, 1);

	return ret;
}

int build_mscs_descriptor(unsigned char *buf, unsigned short buflen, struct mscs_cfg *pmscs)
{
	unsigned short len = 0;
	unsigned int timeout = 60000;

	if (!buf || !buflen || !pmscs)
		return STATUS_INVALID_POINTER;

	if (buflen < 31)
		return STATUS_INVALID_BUFLEN;

	/*===>1. build MSCS Descriptor Element<=======================*/
	/*element ID*/
	buf[len] = 0xFF;
	len += 1;

	/*always set length of mscs descriptor to 29*/
	buf[len] = 29;
	len += 1;

	/*element ID extension*/
	buf[len] = 88;
	len += 1;

	/*request type*/
	buf[len] = pmscs->request_type;
	len += 1;

	/*user priority bitmap*/
	buf[len] = pmscs->up_bitmap;
	len += 1;

	/*user priority limit*/
	buf[len] = 7;
	len += 1;

	/*stream timeout*/
	os_memcpy(&buf[len], &timeout, sizeof(timeout));
	len += sizeof(timeout);

	/*===>2. build TCLAS Mask Element<============================*/
	/*element ID*/
	buf[len] = 0xFF;
	len += 1;

	/*always set length of TCLAS Mask Element to 19*/
	buf[len] = 19;
	len += 1;

	/*element ID extension*/
	buf[len] = 89;
	len += 1;

	/*classifier type*/
	buf[len] = 4;
	len += 1;

	/*classifier mask*/
	buf[len] = pmscs->cs_mask;
	len += 1;

	/*set all other fields to zero*/
	os_memset(&buf[len], 0, 16);
	len += 16;

	return len;
}

int build_scs_descriptor(unsigned char *buf, unsigned short buflen, struct scs_cfg *pscs)
{
	unsigned short len = 0;
	unsigned char intra_access_cate_elem[3] = {0}, intra_access_cate_elem_len = 3;
	unsigned char tclas_elem[64] = {0}, tclas_elem_len = 0;
	unsigned char qoschar_elem[64] = {0}, qoschar_elem_len = 0;
	unsigned char flag_intra_access_cate_elem = 0, flag_tclas_elem = 0, flag_qoschar_elem = 0;
	unsigned int u4value = 0;
	struct qchar_control_info ctrlinfo = {0};

	if (!buf || !buflen || !pscs)
		return STATUS_INVALID_POINTER;

	/* at least need 54 bytes for scs descriptor with ipv6. */
	if (buflen < 54)
		return STATUS_INVALID_BUFLEN;

	if (pscs->cs_mask) {
		flag_intra_access_cate_elem = 1;
		flag_tclas_elem = 1;

		/*====> 1. build Intra-Access Category Priority element. <==== */
		/* Element ID*/
		intra_access_cate_elem[0] = IE_INTRA_ACCESS_CATE_PRI_ID;
		/* Length */
		intra_access_cate_elem[1] = 1;
		/* Intra-Access Priority */
		intra_access_cate_elem[2] = pscs->up & 0x07;

		/*====> 2. build TCLAS element. <============================= */
		/* Element ID */
		tclas_elem[tclas_elem_len] = IE_TCLAS_ELEMENT_ID;
		tclas_elem_len += 1;

		/* Length, will update length according to IP version */
		tclas_elem[tclas_elem_len] = 0;
		tclas_elem_len += 1;

		/* User Priority, reserved, will set to 255 */
		tclas_elem[tclas_elem_len] = 0xFF;
		tclas_elem_len += 1;

		/* Classifier Type */
		tclas_elem[tclas_elem_len] = 4;
		tclas_elem_len += 1;

		/* Classifier Mask */
		tclas_elem[tclas_elem_len] = pscs->cs_mask;
		tclas_elem_len += 1;

		/* Version */
		if (pscs->cs_mask & TYPE4_CS_MASK_VERSION)
			tclas_elem[tclas_elem_len] = pscs->version;
		tclas_elem_len += 1;

		/* Source/Destination IP Address */
		if (pscs->version == VER_IPV4) {
			if (pscs->cs_mask & TYPE4_CS_MASK_SRC_IP)
				os_memcpy(&tclas_elem[tclas_elem_len], &pscs->srcIp.ipv4, sizeof(pscs->srcIp.ipv4));
			tclas_elem_len += sizeof(pscs->srcIp.ipv4);

			if (pscs->cs_mask & TYPE4_CS_MASK_DST_IP)
				os_memcpy(&tclas_elem[tclas_elem_len], &pscs->destIp.ipv4, sizeof(pscs->destIp.ipv4));
			tclas_elem_len += sizeof(pscs->destIp.ipv4);
		} else if (pscs->version == VER_IPV6) {
			if (pscs->cs_mask & TYPE4_CS_MASK_SRC_IP)
				os_memcpy(&tclas_elem[tclas_elem_len], &pscs->srcIp.ipv6, sizeof(pscs->srcIp.ipv6));
			tclas_elem_len += sizeof(pscs->srcIp.ipv6);

			if (pscs->cs_mask & TYPE4_CS_MASK_DST_IP)
				os_memcpy(&tclas_elem[tclas_elem_len], &pscs->destIp.ipv6, sizeof(pscs->destIp.ipv6));
			tclas_elem_len += sizeof(pscs->destIp.ipv6);
		} else
			return STATUS_INVALID_VERSION;

		/* Source Port */
		if (pscs->cs_mask & TYPE4_CS_MASK_SRC_PORT)
			*((unsigned short *)&tclas_elem[tclas_elem_len]) = htons(pscs->srcPort);
		tclas_elem_len += 2;

		/* Destination Port */
		if (pscs->cs_mask & TYPE4_CS_MASK_DST_PORT)
			*((unsigned short *)&tclas_elem[tclas_elem_len]) = htons(pscs->destPort);
		tclas_elem_len += 2;

		/* Skip DSCP */
		tclas_elem_len += 1;

		if (pscs->version == VER_IPV4) {
			/* Protocol */
			if (pscs->cs_mask & TYPE4_CS_MASK_PROTOCOL)
				tclas_elem[tclas_elem_len] = pscs->protocol;
			tclas_elem_len += 1;

			/* Skip Reserved */
			tclas_elem_len += 1;
		} else {
			/* Skip Next Header */
			tclas_elem_len += 1;

			/* Skip Flow Label */
			tclas_elem_len += 3;
		}

		/* update length */
		tclas_elem[1] = tclas_elem_len - 2;
	} else if (pscs->qchar_mask) {
		flag_qoschar_elem = 1;

		/*====> 3. build QoS Characteristics element. <==== */
		/*Element ID*/
		qoschar_elem[qoschar_elem_len] = 0xFF;
		qoschar_elem_len += 1;

		/*Length*/
		qoschar_elem[qoschar_elem_len] = 19;
		qoschar_elem_len += 1;

		/*Element ID Extension*/
		qoschar_elem[qoschar_elem_len] = IE_QOS_CHARACTERISTICS_ID;
		qoschar_elem_len += 1;

		/*Control Info*/
		os_memset(&ctrlinfo, 0, sizeof(ctrlinfo));
		ctrlinfo.dir = pscs->qoschar_dir;
		ctrlinfo.tid = pscs->up;
		ctrlinfo.up = pscs->up;
		os_memcpy(&qoschar_elem[qoschar_elem_len], (unsigned int *)&ctrlinfo, 4);
		qoschar_elem_len += 4;

		/*Minimum Service Interval*/
		if (pscs->qchar_mask & QCHAR_MASK_MIN_INTERVAL)
			*((u32 *)&qoschar_elem[qoschar_elem_len]) = pscs->qoschar_min_interval;
		else
			*((u32 *)&qoschar_elem[qoschar_elem_len]) = 0;
		qoschar_elem_len += 4;

		/*Maximum Service Interval*/
		if (pscs->qchar_mask & QCHAR_MASK_MAX_INTERVAL)
			*((u32 *)&qoschar_elem[qoschar_elem_len]) = pscs->qoschar_max_interval;
		else
			*((u32 *)&qoschar_elem[qoschar_elem_len]) = 0;
		qoschar_elem_len += 4;

		/*Minimum Data Rate*/
		if (pscs->qchar_mask & QCHAR_MASK_MIN_DATA_RATE)
			u4value = pscs->qoschar_min_datarate;
		else
			u4value = 0;
		os_memcpy(&qoschar_elem[qoschar_elem_len], &u4value, 3);
		qoschar_elem_len += 3;

		/*Delay Bound*/
		if (pscs->qchar_mask & QCHAR_MASK_DELAY_BOUND)
			u4value = pscs->qoschar_delaybound;
		else
			u4value = 0;
		os_memcpy(&qoschar_elem[qoschar_elem_len], &u4value, 3);
		qoschar_elem_len += 3;
	} else if (pscs->request_type != REQUEST_TYPE_REMOVE) {
		return STATUS_INSUFFICIENT_PARAM;
	}

	/*====> 4. build SCS Descriptor element. <==================== */
	/*element ID*/
	buf[len] = IE_SCS_DESCRIPTOR_ELEMENT_ID;
	len += 1;

	/*set length to 2 (scsid + request type), will update in below*/
	buf[len] = 2;
	len += 1;

	/*scsid*/
	buf[len] = pscs->scsid;
	len += 1;

	/*Request Type*/
	buf[len] = pscs->request_type;
	len += 1;

	if (flag_intra_access_cate_elem == 1 && flag_tclas_elem == 1) {
		/*update length of scs descriptor*/
		buf[1] = 2 + intra_access_cate_elem_len + tclas_elem_len;

		/*Intra-Access Category Priority element*/
		os_memcpy(&buf[len], intra_access_cate_elem, intra_access_cate_elem_len);
		len += intra_access_cate_elem_len;

		/*tclas element*/
		os_memcpy(&buf[len], tclas_elem, tclas_elem_len);
		len += tclas_elem_len;
	}
	if (flag_qoschar_elem == 1) {
		/*update length of scs descriptor*/
		buf[1] = 2 + qoschar_elem_len;

		/*QoS Characteristics element*/
		os_memcpy(&buf[len], qoschar_elem, qoschar_elem_len);
		len += qoschar_elem_len;
	}

	return len;
}

int build_qos_management_descriptor_tlv(struct qos_management_descriptor_tlv *qosmgmttlv,
		unsigned char *bssid, unsigned char *stamac, unsigned char *desbuff, unsigned char deslen)
{
	if (!qosmgmttlv || !bssid || !stamac || !desbuff)
		return STATUS_INVALID_POINTER;

	qosmgmttlv->type = QOS_MANAGEMENT_DESCRIPTOR_TLV_TYPE;
	qosmgmttlv->length = host_to_be16(14 + deslen);
	qosmgmttlv->qmid = g_qmid++;
	os_memcpy(qosmgmttlv->bssid, bssid, ETH_ALEN);
	os_memcpy(qosmgmttlv->sta_mac, stamac, ETH_ALEN);
	os_memcpy(qosmgmttlv->descriptor, desbuff, deslen);

	/*return total length of management descriptor tlv*/
	return (3 + 14 + deslen);
}

char *err2str(int errcode)
{
	int i = 0, tblsize = 0;

	tblsize = ARRAY_SIZE(err_code_tbl);
	for (i = 0; i < tblsize; i++) {
		if (errcode == err_code_tbl[i].idx)
			return err_code_tbl[i].str;
	}

	return err_code_tbl[tblsize-1].str;
}

int str2protocol(char *strp)
{
	int i = 0, tblsize = 0;

	if (!strp)
		return IP_TYPE_UNKNOWN;

	tblsize = ARRAY_SIZE(ip_protocol_tbl);
	debug(DEBUG_CAT_QOS, "strp:%s, tblsize, %d\n", strp, tblsize);
	for (i = 0; i < tblsize; i++) {
		if (os_strncmp(strp, ip_protocol_tbl[i].str, os_strlen(ip_protocol_tbl[i].str)) == 0)
			return ip_protocol_tbl[i].idx;
	}

	return IP_TYPE_UNKNOWN;
}

char *protocol2str(int proto)
{
	int i = 0, tblsize = 0;

	tblsize = ARRAY_SIZE(ip_protocol_tbl);
	for (i = 0; i < tblsize; i++) {
		if (proto == ip_protocol_tbl[i].idx)
			return ip_protocol_tbl[i].str;
	}

	return ip_protocol_tbl[tblsize-1].str;
}

static inline int str2num(char *str)
{
	int num = 0;
	char *endptr = NULL;

	if (!str) {
		err(DEBUG_CAT_QOS, "input str is NULL.\n");
		return -1;
	}

	num = strtol(str, &endptr, 10);
	if (errno == ERANGE) {
		err(DEBUG_CAT_QOS, "%s is out of range.\n", str);
		return -2;
	} else if (*endptr != '\0' && *endptr != ' ') {
		warn(DEBUG_CAT_QOS, "convert %s to number fail.\n", str);
		return -3;
	}

	return num;
}

int convert_mac_addr(char *strmac, unsigned char *mac_addr)
{
	int ret = STATUS_SUCCESS;
	unsigned char i = 0;
	char *token = NULL, *pos = NULL;

	if (!strmac || !mac_addr) {
		err(DEBUG_CAT_QOS, "invalid parameters, strmac:%p, mac_addr:%p\n", strmac, mac_addr);
		return STATUS_INVALID_POINTER;
	}

	token = strtok_r(strmac, ":", &pos);
	while (token != NULL) {
		AtoH(token, (char *) &mac_addr[i], 1);
		i++;
		if (i >= MAC_ADDR_LEN)
			break;
		token = strtok_r(NULL, ":", &pos);
	}
	if (i != MAC_ADDR_LEN)
		ret = STATUS_INVALID_STAMAC;

	return ret;
}

unsigned char convert_action(char *strop)
{
	unsigned char optype = REQUEST_TYPE_UNKNOWN;

	if (os_strncmp(strop, "add", os_strlen("add")) == 0)
		optype = REQUEST_TYPE_ADD;
	else if (os_strncmp(strop, "remove", os_strlen("remove")) == 0)
		optype = REQUEST_TYPE_REMOVE;
	else if (os_strncmp(strop, "change", os_strlen("change")) == 0)
		optype = REQUEST_TYPE_CHANGE;
	else
		warn(DEBUG_CAT_QOS, "invalid op:%s\n", strop);

	return optype;
}

unsigned char convert_strbitmap2i(char *strbitmap)
{
	char *p = NULL;
	unsigned char i = 0, ret = 0;

	if (!strbitmap || !strlen(strbitmap))
		return ret;

	p = strbitmap;
	for (i = 0; i < strlen(strbitmap) && i < 8; i++) {
		if (*p++ == '1')
			ret |= (1 << i);
	}

	return ret;
}

char *convert_i2strbitmap(unsigned char value)
{
	unsigned char i = 0;

	memset(g_bitmap, 0, sizeof(g_bitmap));
	for (i = 0; i < 8; i++) {
		if (value & (1 << i))
			g_bitmap[i] = '1';
		else
			g_bitmap[i] = '0';
	}
	g_bitmap[8] = '\0';

	return g_bitmap;
}

int convert_ip_address(u8 type, char *strip, char *buf, int buflen)
{
	if (!strip || !buf || !buflen)
		return STATUS_INVALID_POINTER;

	if (type == VER_IPV4) {
		if (buflen < 4) {
			err(DEBUG_CAT_QOS, "invalid buflen: %d\n", buflen);
			return STATUS_INVALID_BUFLEN;
		}

		/* convert IPv4 address*/
		if (inet_pton(AF_INET, strip, buf) <= 0) {
			err(DEBUG_CAT_QOS, "ipv4 inet_pton got error when converting :%s\n", strip);
			return STATUS_INVALID_IP;
		}
	} else if (type == VER_IPV6) {
		if (buflen < 16) {
			err(DEBUG_CAT_QOS, "invalid buflen: %d\n", buflen);
			return STATUS_INVALID_BUFLEN;
		}

		/*convert IPv6 address*/
		if (inet_pton(AF_INET6, strip, buf) <= 0) {
			err(DEBUG_CAT_QOS, "ipv6 inet_pton got error when converting :%s\n", strip);
			return STATUS_INVALID_IP;
		}
	} else {
		warn(DEBUG_CAT_QOS, "invalid type: %d\n", type);
		return STATUS_INVALID_CMD_TYPE;
	}
	return STATUS_SUCCESS;
}

unsigned char convert_direction(char *strdir)
{
	unsigned char dir = DIR_UNKNOWN;

	if (os_strncmp(strdir, "UL", os_strlen("UL")) == 0)
		dir = DIR_UPLINK;
	else if (os_strncmp(strdir, "DL", os_strlen("DL")) == 0)
		dir = DIR_DOWNLINK;
	else
		warn(DEBUG_CAT_QOS, "invalid dir:%s\n", strdir);

	return dir;
}

/*
 * This function will parse mscs command.
 * Example:
 *  - MSCSReq,action,add,sta_mac,01:02:03:45:67:89,up_bitmap, 00001111,cs_mask,11111010
 */
int parse_mscs_cmd(char *buf, struct mscs_cfg *pmscs)
{
	int ret = STATUS_SUCCESS, num = 0;
	char *token = NULL, *value = NULL, *pos = NULL;

	if (!buf || !pmscs) {
		err(DEBUG_CAT_QOS, "invalid pointer, buf:%p, pmscs:%p.\n", buf, pmscs);
		return STATUS_INVALID_POINTER;
	}
	if (!os_strlen(buf)) {
		err(DEBUG_CAT_QOS, "invalid parameters, buf is empty.\n");
		return STATUS_INVALID_PARAM;
	}

	token = strtok_r(buf, ",", &pos);
	if (token == NULL || os_strncmp(token, "MSCSReq", os_strlen("MSCSReq")) != 0) {
		err(DEBUG_CAT_QOS, "invalid pmscs command.\n");
		return STATUS_INVALID_CMD_TYPE;
	}

	token = strtok_r(NULL, ",", &pos);
	while (token != NULL) {
		value = strtok_r(NULL, ",", &pos);
		if (value == NULL)
			break;

		info(DEBUG_CAT_QOS, "token: %s, value: %s.\n", token, value);

		if (os_strncmp(token, "index", os_strlen("index")) == 0) {
			num = str2num(value);
			if (num > 0 && num < 0xFF)
				pmscs->index = num;
			else
				pmscs->index = 1;
		} else if (os_strncmp(token, "sta_mac", os_strlen("sta_mac")) == 0) {
			if (convert_mac_addr(value, pmscs->sta_mac) != STATUS_SUCCESS) {
				ret = STATUS_INVALID_STAMAC;
				break;
			}
		} else if (os_strncmp(token, "action", os_strlen("action")) == 0) {
			pmscs->request_type = convert_action(value);
			if (pmscs->request_type == REQUEST_TYPE_UNKNOWN) {
				ret = STATUS_INVALID_ACTION;
				break;
			}
		} else if (os_strncmp(token, "up_bitmap", os_strlen("up_bitmap")) == 0) {
			pmscs->up_bitmap = convert_strbitmap2i(value);
			if (pmscs->up_bitmap == 0) {
				ret = STATUS_INVALID_BITMAP;
				break;
			}
		} else if (os_strncmp(token, "cs_mask", os_strlen("cs_mask")) == 0) {
			pmscs->cs_mask = convert_strbitmap2i(value);
			if (pmscs->cs_mask == 0) {
				ret = STATUS_INVALID_BITMAP;
				break;
			}
		} else {
			warn(DEBUG_CAT_QOS, "unknown parameter:%s.\n", token);
		}
		token = strtok_r(NULL, ",", &pos);
	}

	if (ret == STATUS_SUCCESS) {
		/*set default values*/
		if (pmscs->up_bitmap == 0)
			pmscs->up_bitmap = 0xF0;
		if (pmscs->cs_mask == 0)
			pmscs->cs_mask = 0x5F;
	}

	return ret;
}

/*
 * This function will parse scs command.
 * Example:
 *  - SCSReq,action,add,sta_mac,01:02:03:45:67:89,up,6,ipver,4,srcip,192.165.100.101,dstip,192.165.100.70,
 *    srcport,5002,dstport,10002,protocol,17
 *  - SCSReq,action,add,al_mac,00:0c:43:11:22:33,sta_mac,01:02:03:45:67:89,qoschar_dir,UL,qoschar_min_interval,40000,
 *    qoschar_max_interval,40000,qoschar_min_datarate,5000,qoschar_delaybound,40000,qoschar_userpriority,4
 */
int parse_scs_cmd(char *buf, struct scs_cfg *pscs)
{
	int ret = STATUS_SUCCESS;
	char *token = NULL, *value = NULL, *pos = NULL;
	int num = 0;

	if (!buf || !pscs) {
		err(DEBUG_CAT_QOS, "invalid pointer, buf:%p, pscs:%p.\n", buf, pscs);
		return STATUS_INVALID_POINTER;
	}
	if (!os_strlen(buf)) {
		err(DEBUG_CAT_QOS, "invalid parameters, buf is empty.\n");
		return STATUS_INVALID_PARAM;
	}

	token = strtok_r(buf, ",", &pos);
	if (token == NULL || os_strncmp(token, "SCSReq", os_strlen("SCSReq")) != 0) {
		err(DEBUG_CAT_QOS, "invalid pscs command.\n");
		return STATUS_INVALID_CMD_TYPE;
	}

	token = strtok_r(NULL, ",", &pos);
	while (token != NULL) {
		value = strtok_r(NULL, ",", &pos);
		if (value == NULL)
			break;

		info(DEBUG_CAT_QOS, "token: %s, value: %s.\n", token, value);

		if (os_strncmp(token, "index", os_strlen("index")) == 0) {
			num = str2num(value);
			if (num > 0 && num < 0xFF)
				pscs->index = num;
			else
				pscs->index = 1;
		} else if (os_strncmp(token, "sta_mac", os_strlen("sta_mac")) == 0) {
			if (convert_mac_addr(value, pscs->sta_mac) != STATUS_SUCCESS) {
				ret = STATUS_INVALID_STAMAC;
				break;
			}
		} else if (os_strncmp(token, "scsid", os_strlen("scsid")) == 0) {
			num = str2num(value);
			if (num >= 0)
				pscs->scsid = num;
		} else if (os_strncmp(token, "action", os_strlen("action")) == 0) {
			pscs->request_type = convert_action(value);
			if (pscs->request_type == REQUEST_TYPE_UNKNOWN) {
				ret = STATUS_INVALID_ACTION;
				break;
			}
		} else if (os_strncmp(token, "up", os_strlen("up")) == 0) {
			num = str2num(value);
			if (num <= 0 || num > 7) {
				ret = STATUS_INVALID_UP;
				break;
			}
			pscs->up = num;
		} else if (os_strncmp(token, "ipver", os_strlen("ipver")) == 0) {
			num = str2num(value);
			if (num < 0 || (num != VER_IPV4 && num != VER_IPV6)) {
				ret = STATUS_INVALID_VERSION;
				break;
			}
			pscs->version = num;
			pscs->cs_mask |= TYPE4_CS_MASK_VERSION;
		} else if (os_strncmp(token, "srcip", os_strlen("srcip")) == 0) {
			if (convert_ip_address(pscs->version, value,
				(char *)&pscs->srcIp, sizeof(pscs->srcIp)) < 0) {
				ret = STATUS_INVALID_IP;
				break;
			}
			pscs->cs_mask |= TYPE4_CS_MASK_SRC_IP;
		} else if (os_strncmp(token, "dstip", os_strlen("dstip")) == 0) {
			if (convert_ip_address(pscs->version, value,
				(char *)&pscs->destIp, sizeof(pscs->destIp)) < 0) {
				ret = STATUS_INVALID_IP;
				break;
			}
			pscs->cs_mask |= TYPE4_CS_MASK_DST_IP;
		} else if (os_strncmp(token, "srcport", os_strlen("srcport")) == 0) {
			num = str2num(value);
			if (num < 0) {
				ret = STATUS_INVALID_PORT;
				break;
			}
			pscs->srcPort = num;
			pscs->cs_mask |= TYPE4_CS_MASK_SRC_PORT;
		} else if (os_strncmp(token, "dstport", os_strlen("dstport")) == 0) {
			num = str2num(value);
			if (num < 0) {
				ret = STATUS_INVALID_PORT;
				break;
			}
			pscs->destPort = num;
			pscs->cs_mask |= TYPE4_CS_MASK_DST_PORT;
		} else if (os_strncmp(token, "protocol", os_strlen("protocol")) == 0) {
			num = str2protocol(value);
			if (num == IP_TYPE_UNKNOWN) {
				ret = STATUS_INVALID_PROTOCOL;
				break;
			}
			pscs->protocol = num;
			pscs->cs_mask |= TYPE4_CS_MASK_PROTOCOL;
		} else if (os_strncmp(token, "qoschar_dir", os_strlen("qoschar_dir")) == 0) {
			pscs->qoschar_dir = convert_direction(value);
			pscs->qchar_mask |= QCHAR_MASK_DIR;
		} else if (os_strncmp(token, "qoschar_min_interval", os_strlen("qoschar_min_interval")) == 0) {
			num = str2num(value);
			if (num < 0) {
				ret = STATUS_INVALID_QOSCHAR;
				break;
			}
			pscs->qoschar_min_interval = num;
			pscs->qchar_mask |= QCHAR_MASK_MIN_INTERVAL;
		} else if (os_strncmp(token, "qoschar_max_interval", os_strlen("qoschar_max_interval")) == 0) {
			num = str2num(value);
			if (num < 0) {
				ret = STATUS_INVALID_QOSCHAR;
				break;
			}
			pscs->qoschar_max_interval = num;
			pscs->qchar_mask |= QCHAR_MASK_MAX_INTERVAL;
		} else if (os_strncmp(token, "qoschar_min_datarate", os_strlen("qoschar_min_datarate")) == 0) {
			num = str2num(value);
			if (num < 0) {
				ret = STATUS_INVALID_QOSCHAR;
				break;
			}
			pscs->qoschar_min_datarate = num;
			pscs->qchar_mask |= QCHAR_MASK_MIN_DATA_RATE;
		} else if (os_strncmp(token, "qoschar_delaybound", os_strlen("qoschar_delaybound")) == 0) {
			num = str2num(value);
			if (num < 0) {
				ret = STATUS_INVALID_QOSCHAR;
				break;
			}
			pscs->qoschar_delaybound = num;
			pscs->qchar_mask |= QCHAR_MASK_DELAY_BOUND;
		} else if (os_strncmp(token, "qoschar_userpriority", os_strlen("qoschar_userpriority")) == 0) {
			num = str2num(value);
			if (num < 0 || num > 7) {
				ret = STATUS_INVALID_UP;
				break;
			}
			pscs->up = num;
		} else {
			warn(DEBUG_CAT_QOS, "unknown parameter:%s.\n", token);
		}
		token = strtok_r(NULL, ",", &pos);
	}
	return ret;
}

/*
 * This function will parse qosmap command.
 * Example:
 *  - Qosmap,al_mac,00:0c:43:11:22:33,dscp_exception,53,3,54,2,
 *    dsccp_range,8,15,0,7,255,255,16,31,32,39,255,255,40,47,255,255
 */
int parse_qosmap_cmd(char *buf, struct qos_map *pqosmap)
{
	int ret = STATUS_INSUFFICIENT_PARAM;
	unsigned char i = 0;
	char *token = NULL, *value = NULL, *pos = NULL;
	int dscp = 0, dscp_l = 0, dscp_h = 0, up = 0, num = 0;

	if (!buf || !pqosmap) {
		err(DEBUG_CAT_QOS, "invalid parameters, buf:%p, pqosmap:%p.\n", buf, pqosmap);
		return STATUS_INVALID_POINTER;
	}
	if (!os_strlen(buf)) {
		err(DEBUG_CAT_QOS, "invalid parameters, buf is empty.\n");
		return STATUS_INVALID_PARAM;
	}

	token = strtok_r(buf, ",", &pos);
	if (token == NULL || os_strncmp(token, "Qosmap", os_strlen("Qosmap")) != 0) {
		err(DEBUG_CAT_QOS, "invalid pqosmap command.\n");
		return STATUS_INVALID_CMD_TYPE;
	}

	token = strtok_r(NULL, ",", &pos);
	while (token != NULL) {
		value = strtok_r(NULL, ",", &pos);
		if (value == NULL)
			break;

		info(DEBUG_CAT_QOS, "token: %s, value: %s.\n", token, value);

		if (os_strncmp(token, "al_mac", os_strlen("al_mac")) == 0) {
			if (convert_mac_addr(value, pqosmap->al_mac) != STATUS_SUCCESS) {
				ret = STATUS_INVALID_ALMAC;
				break;
			}
		} else if (os_strncmp(token, "dscp_exception", os_strlen("dscp_exception")) == 0) {
			pqosmap->num = 0;
			while (pqosmap->num < MAX_EXCEPT_CNT) {
				num = str2num(value);
				if (num < 0)
					break;
				dscp = num;

				value = strtok_r(NULL, ",", &pos);
				num = str2num(value);
				if (num < 0)
					break;
				up = num;

				if (dscp < DSCP_TBL_SIZE && up < MAX_UP) {
					pqosmap->dscp_ex[pqosmap->num].dscp = dscp;
					pqosmap->dscp_ex[pqosmap->num].up = up;
					pqosmap->num++;
					ret = STATUS_SUCCESS;
				}
				value = strtok_r(NULL, ",", &pos);
			}
			token = value;
			continue;
		} else if (os_strncmp(token, "dscp_range", os_strlen("dscp_range")) == 0) {
			i = 0;
			while (i < MAX_UP) {
				num = str2num(value);
				if (num < 0)
					break;
				dscp_l = num;

				value = strtok_r(NULL, ",", &pos);
				num = str2num(value);
				if (num < 0)
					break;
				dscp_h = num;

				if ((dscp_l < DSCP_TBL_SIZE && dscp_h < DSCP_TBL_SIZE && dscp_l < dscp_h) ||
					(dscp_l == 255 && dscp_h == 255)) {
					pqosmap->dscp_rg[i].low = dscp_l;
					pqosmap->dscp_rg[i].high = dscp_h;
					i++;
					ret = STATUS_SUCCESS;
				}
				value = strtok_r(NULL, ",", &pos);
			}
			token = value;
			continue;
		} else {
			warn(DEBUG_CAT_QOS, "unknown parameter:%s.\n", token);
		}
		token = strtok_r(NULL, ",", &pos);
	}
	return ret;
}


/*
 * This function will parse disallow command.
 * Example:
 *  - Disallowed,al_mac,00:0c:43:11:22:33,mscslist,xx:xx:xx:xx:xx:xx,yy:yy:yy:yy:yy:yy,zz:zz:zz:zz:zz:zz,
 *    scslist,xx:xx:xx:xx:xx:xx,yy:yy:yy:yy:yy:yy,zz:zz:zz:zz:zz:zz
 */
int parse_disallow_cmd(char *buf, struct mscs_scs_disallowed *pdisallow)
{
	int ret = STATUS_SUCCESS;
	char *token = NULL, *value = NULL, *pos = NULL;
	unsigned char mac_addr[MAC_ADDR_LEN] = {0}, disnum = 0;

	if (!buf || !pdisallow) {
		err(DEBUG_CAT_QOS, "invalid parameters, buf:%p, pdisallow:%p.\n", buf, pdisallow);
		return STATUS_INVALID_POINTER;
	}
	if (!os_strlen(buf)) {
		err(DEBUG_CAT_QOS, "invalid parameters, buf is empty.\n");
		return STATUS_INVALID_PARAM;
	}

	token = strtok_r(buf, ",", &pos);
	if (token == NULL || os_strncmp(token, "Disallowed", os_strlen("Disallowed")) != 0) {
		err(DEBUG_CAT_QOS, "invalid qosmap command.\n");
		return STATUS_INVALID_CMD_TYPE;
	}

	token = strtok_r(NULL, ",", &pos);
	while (token != NULL) {
		value = strtok_r(NULL, ",", &pos);
		if (value == NULL)
			break;

		if (os_strncmp(token, "al_mac", os_strlen("al_mac")) == 0) {
			if (convert_mac_addr(value, pdisallow->al_mac) != STATUS_SUCCESS) {
				ret = -STATUS_INVALID_ALMAC;
				break;
			}
		} else if (os_strncmp(token, "mscslist", os_strlen("mscslist")) == 0) {
			disnum = 0;
			while (value && disnum < MAX_NUM_DISALLOWED) {
				if (convert_mac_addr(value, mac_addr) != STATUS_SUCCESS)
					break;

				os_memcpy(pdisallow->qpolicy.MSCSDisallowed[disnum++], mac_addr, MAC_ADDR_LEN);

				value = strtok_r(NULL, ",", &pos);
			}
			pdisallow->qpolicy.numMSCSDisallowed = disnum;
			token = value;
			continue;
		} else if (os_strncmp(token, "scslist", os_strlen("scslist")) == 0) {
			disnum = 0;
			while (value && disnum < MAX_NUM_DISALLOWED) {
				if (convert_mac_addr(value, mac_addr) != STATUS_SUCCESS)
					break;

				os_memcpy(pdisallow->qpolicy.SCSDisallowed[disnum++], mac_addr, MAC_ADDR_LEN);

				value = strtok_r(NULL, ",", &pos);
			}
			pdisallow->qpolicy.numSCSDisallowed = disnum;
			token = value;
			continue;
		} else {
			warn(DEBUG_CAT_QOS, "unknown parameter:%s.\n", token);
		}
		token = strtok_r(NULL, ",", &pos);
	}
	return ret;
}
/*
 * will do sanity check on mscs structure and fill default for some of fields.
 */
int mscs_sanity_check(struct mscs_cfg *pmscs)
{
	int ret = STATUS_UNKNOWN;

	if (!pmscs)
		ret = STATUS_INVALID_POINTER;
	else if (mac_addr_equal(pmscs->sta_mac, zero_mac))
		ret = STATUS_INVALID_STAMAC;
	else if (pmscs->request_type >= REQUEST_TYPE_UNKNOWN)
		ret = STATUS_INVALID_ACTION;
	else
		ret = STATUS_SUCCESS;

	return ret;
}

int scs_sanity_check(struct scs_cfg *pscs)
{
	int ret = STATUS_UNKNOWN;

	if (!pscs)
		ret = STATUS_INVALID_POINTER;
	else if (mac_addr_equal(pscs->sta_mac, zero_mac))
		ret = STATUS_INVALID_STAMAC;
	else if (pscs->request_type >= REQUEST_TYPE_UNKNOWN)
		ret = STATUS_INVALID_ACTION;
	else if (pscs->up >= MAX_UP)
		ret = STATUS_INVALID_UP;
	else if (pscs->request_type == REQUEST_TYPE_REMOVE)
		ret = STATUS_SUCCESS;
	else if (pscs->cs_mask == 0 && pscs->qchar_mask == 0)
		ret = STATUS_INSUFFICIENT_PARAM;
	else if ((pscs->cs_mask & TYPE4_CS_MASK_VERSION) && (pscs->version != VER_IPV4 && pscs->version != VER_IPV6))
		ret = STATUS_INVALID_VERSION;
	else if (((pscs->cs_mask & TYPE4_CS_MASK_SRC_IP) && (pscs->version == VER_IPV4 && pscs->srcIp.ipv4 == 0)) ||
		((pscs->cs_mask & TYPE4_CS_MASK_DST_IP) && (pscs->version == VER_IPV4 && pscs->destIp.ipv4 == 0)))
		ret = STATUS_INVALID_IP;
	else if (((pscs->cs_mask & TYPE4_CS_MASK_SRC_PORT) && (pscs->srcPort == 0)) ||
		((pscs->cs_mask & TYPE4_CS_MASK_DST_PORT) && (pscs->destPort == 0)))
		ret = STATUS_INVALID_PORT;
	else if ((pscs->cs_mask & TYPE4_CS_MASK_PROTOCOL) && (pscs->protocol == 0))
		ret = STATUS_INVALID_PROTOCOL;
	else if ((pscs->qchar_mask & QCHAR_MASK_DIR) &&
		(pscs->qoschar_dir != DIR_UPLINK && pscs->qoschar_dir != DIR_DOWNLINK))
		ret = STATUS_INVALID_DIR;
	else if (((pscs->qchar_mask & QCHAR_MASK_MIN_INTERVAL) && (pscs->qoschar_min_interval == 0)) ||
		((pscs->qchar_mask & QCHAR_MASK_MAX_INTERVAL) && (pscs->qoschar_max_interval == 0)) ||
		((pscs->qchar_mask & QCHAR_MASK_MIN_DATA_RATE) && (pscs->qoschar_min_datarate == 0)) ||
		((pscs->qchar_mask & QCHAR_MASK_DELAY_BOUND) && (pscs->qoschar_delaybound == 0)))
		ret = STATUS_INVALID_QOSCHAR;
	else
		ret = STATUS_SUCCESS;

	return ret;
}

int qosmap_sanity_check(struct qos_map *pqosmap)
{
	unsigned char i = 0;
	int ret = STATUS_UNKNOWN, flag = 0;

	if (!pqosmap)
		ret = STATUS_INVALID_POINTER;
	else if (mac_addr_equal(pqosmap->al_mac, zero_mac))
		ret = STATUS_INVALID_ALMAC;
	else {
		ret = STATUS_SUCCESS;
		for (i = 0; i < pqosmap->num; i++) {
			if ((pqosmap->dscp_ex[i].dscp == 0 && pqosmap->dscp_ex[i].up == 0) ||
				(pqosmap->dscp_ex[i].dscp >= DSCP_TBL_SIZE) ||
				(pqosmap->dscp_ex[i].up >= MAX_UP)) {
				ret = STATUS_INVALID_DSCP_EXCEPTION;
				break;
			}
			flag = 1;
		}

		for (i = 0; i < MAX_UP; i++) {
			if (((pqosmap->dscp_rg[i].low != 255) && (pqosmap->dscp_rg[i].low >= DSCP_TBL_SIZE)) ||
				((pqosmap->dscp_rg[i].high != 255) && (pqosmap->dscp_rg[i].high >= DSCP_TBL_SIZE)) ||
				(pqosmap->dscp_rg[i].low > pqosmap->dscp_rg[i].high)) {
				ret = STATUS_INVALID_DSCP_RANGE;
				break;
			}
			flag = 1;
		}

		if (flag == 0)
			ret = STATUS_INSUFFICIENT_PARAM;
	}

	return ret;
}

int disallow_sanity_check(struct mscs_scs_disallowed *pdisallow)
{
	unsigned char i = 0;
	int ret = STATUS_UNKNOWN;

	if (!pdisallow)
		ret = STATUS_INVALID_POINTER;
	else if (mac_addr_equal(pdisallow->al_mac, zero_mac))
		ret = STATUS_INVALID_ALMAC;
	else if (pdisallow->qpolicy.numMSCSDisallowed == 0 || pdisallow->qpolicy.numSCSDisallowed == 0)
		ret = STATUS_INSUFFICIENT_PARAM;
	else {
		ret = STATUS_SUCCESS;
		for (i = 0; i < pdisallow->qpolicy.numMSCSDisallowed && i < MAX_NUM_DISALLOWED; i++) {
			if (mac_addr_equal(pdisallow->qpolicy.MSCSDisallowed[i], zero_mac)) {
				ret = STATUS_INVALID_STAMAC;
				break;
			}
		}

		for (i = 0; i < pdisallow->qpolicy.numSCSDisallowed && i < MAX_NUM_DISALLOWED; i++) {
			if (mac_addr_equal(pdisallow->qpolicy.SCSDisallowed[i], zero_mac)) {
				ret = STATUS_INVALID_STAMAC;
				break;
			}
		}
	}

	return ret;
}

int get_associated_agent_almac(struct p1905_managerd_ctx *ctx, unsigned char *stamac, unsigned char *almac)
{
	struct assoc_client *client = NULL;

	if (!ctx || !stamac || !almac) {
		err(DEBUG_CAT_QOS, "Invalid pointer.\n");
		return STATUS_INVALID_POINTER;
	}

	client = get_assoc_cli_by_mac(ctx, stamac);
	if (!client) {
		/* err(DEBUG_CAT_QOS, "can't find client entry.\n"); */
		return STATUS_NO_CLIENT_FOUND;
	}
	if (mac_addr_equal(client->al_mac, zero_mac)) {
		err(DEBUG_CAT_QOS, "invalid agent al_mac address.\n");
		return STATUS_INVALID_ALMAC;
	}

	os_memcpy(almac, client->al_mac, ETH_ALEN);

	return STATUS_SUCCESS;
}

int update_mscs_to_list(struct p1905_managerd_ctx *ctx, struct mscs_cfg *pmscs)
{
	int ret = STATUS_UNKNOWN;
	unsigned char delete_idx = 0;
	struct mscs_cfg *pos = NULL, *tmp = NULL, *newnode = NULL;

	if (!ctx || !pmscs)
		return STATUS_INVALID_POINTER;

	if (pmscs->request_type == REQUEST_TYPE_ADD) {
		dl_list_for_each_safe(pos, tmp, &ctx->mscs_list, struct mscs_cfg, list) {
			if (mac_addr_equal(pos->sta_mac, pmscs->sta_mac))
				return STATUS_CFG_EXISTED;
		}

		if (ctx->mscs_list_cnt > max_mscs_cfg_count) {
			err(DEBUG_CAT_QOS, "mscs config reach max count %u\n", ctx->mscs_list_cnt);
			return STATUS_INSUFFICIENT_RESOURCE;
		}

		/*add new node*/
		newnode = (struct mscs_cfg *)os_malloc(sizeof(struct mscs_cfg));
		if (newnode) {
			os_memcpy(newnode, pmscs, sizeof(*newnode));
			newnode->index = ctx->mscs_list_cnt + 1;
			dl_list_add_tail(&ctx->mscs_list, &newnode->list);
			ctx->mscs_list_cnt++;
			ret = STATUS_SUCCESS;
		} else {
			err(DEBUG_CAT_QOS, "memory alloc fail\n");
			ret = STATUS_ALLOC_MEM_FAIL;
		}
	} else if (pmscs->request_type == REQUEST_TYPE_CHANGE) {
		dl_list_for_each_safe(pos, tmp, &ctx->mscs_list, struct mscs_cfg, list) {
			if ((pos->index == pmscs->index) && mac_addr_equal(pos->sta_mac, pmscs->sta_mac)) {
				if ((pos->up_bitmap == pmscs->up_bitmap) && (pos->cs_mask == pmscs->cs_mask))
					return STATUS_CFG_IS_THE_SAME;

				pos->up_bitmap = pmscs->up_bitmap;
				pos->cs_mask = pmscs->cs_mask;
				return STATUS_SUCCESS;
			}
		}
		return STATUS_CFG_NOT_EXISTED;
	} else if (pmscs->request_type == REQUEST_TYPE_REMOVE) {
		dl_list_for_each_safe(pos, tmp, &ctx->mscs_list, struct mscs_cfg, list) {
			if ((pos->index == pmscs->index) || mac_addr_equal(pos->sta_mac, pmscs->sta_mac)) {
				delete_idx = pos->index;
				/*remove node*/
				dl_list_del(&pos->list);
				os_free(pos);
				ret = STATUS_SUCCESS;
				if (ctx->mscs_list_cnt)
					ctx->mscs_list_cnt--;
			}
		}
		if (ret == STATUS_SUCCESS) {
			/*re-arrange the index of list*/
			dl_list_for_each_safe(pos, tmp, &ctx->mscs_list, struct mscs_cfg, list) {
				if (pos->index > delete_idx)
					pos->index--;
			}
		} else
			ret = STATUS_CFG_NOT_EXISTED;
	} else {
		warn(DEBUG_CAT_QOS, "invalid op type:%u\n", pmscs->request_type);
		ret = STATUS_INVALID_ACTION;
	}
	return ret;
}
static unsigned char allocate_scsid(struct p1905_managerd_ctx *ctx, struct scs_cfg *pscs)
{
	unsigned char i = 0, used = 0;
	struct scs_cfg *pos = NULL;

	if (!ctx->scs_list_cnt)
		return 0;

	if (pscs->request_type == REQUEST_TYPE_ADD) {
		for (i = 0; i < ctx->scs_list_cnt; i++) {
			used = 0;
			dl_list_for_each(pos, &ctx->scs_list, struct scs_cfg, list) {
				if (mac_addr_equal(pos->sta_mac, pscs->sta_mac) && (pos->scsid == i)) {
					used = 1;
					break;
				}
			}
			if (used == 0)
				break;
		}
		return i;
	}

	dl_list_for_each(pos, &ctx->scs_list, struct scs_cfg, list) {
		if (mac_addr_equal(pos->sta_mac, pscs->sta_mac))
			return pos->scsid;
	}
	return 0;
}

static inline int compare_scs_config(struct scs_cfg *pcfg1, struct scs_cfg *pcfg2)
{
	unsigned char mask;

	if (!pcfg1 || !pcfg2)
		return STATUS_INVALID_POINTER;

	if (!mac_addr_equal(pcfg1->sta_mac, pcfg2->sta_mac))
		return 0;

	if (pcfg1->up != pcfg2->up)
		return 0;

	if (pcfg1->cs_mask != pcfg2->cs_mask)
		return 0;

	mask = pcfg1->cs_mask;
	if ((mask & TYPE4_CS_MASK_VERSION) && (pcfg1->version != pcfg2->version))
		return 0;

	if (pcfg1->version == VER_IPV4) {
		if (mask & TYPE4_CS_MASK_SRC_IP) {
			if (pcfg1->srcIp.ipv4 != pcfg2->srcIp.ipv4)
				return 0;
		}
		if (mask & TYPE4_CS_MASK_DST_IP) {
			if (pcfg1->destIp.ipv4 != pcfg2->destIp.ipv4)
				return 0;
		}
	}

	if (pcfg1->version == VER_IPV6) {
		if (mask & TYPE4_CS_MASK_SRC_IP) {
			if (!IPV6_ADDR_EQUAL(pcfg1->srcIp.ipv6, pcfg2->srcIp.ipv6))
				return 0;
		}
		if (mask & TYPE4_CS_MASK_DST_IP) {
			if (!IPV6_ADDR_EQUAL(pcfg1->destIp.ipv6, pcfg2->destIp.ipv6))
				return 0;
		}
	}
	if (mask & TYPE4_CS_MASK_SRC_PORT) {
		if (pcfg1->srcPort != pcfg2->srcPort)
			return 0;
	}
	if (mask & TYPE4_CS_MASK_DST_PORT) {
		if (pcfg1->destPort != pcfg2->destPort)
			return 0;
	}
	if (mask & TYPE4_CS_MASK_PROTOCOL) {
		if (pcfg1->protocol != pcfg2->protocol)
			return 0;
	}

	if (pcfg1->qchar_mask != pcfg2->qchar_mask)
		return 0;

	mask = pcfg1->qchar_mask;
	if ((mask & QCHAR_MASK_DIR) && (pcfg1->qoschar_dir != pcfg2->qoschar_dir))
		return 0;

	if ((mask & QCHAR_MASK_MIN_INTERVAL) && (pcfg1->qoschar_min_interval != pcfg2->qoschar_min_interval))
		return 0;

	if ((mask & QCHAR_MASK_MAX_INTERVAL) && (pcfg1->qoschar_max_interval != pcfg2->qoschar_max_interval))
		return 0;

	if ((mask & QCHAR_MASK_MIN_DATA_RATE) && (pcfg1->qoschar_min_datarate != pcfg2->qoschar_min_datarate))
		return 0;

	if ((mask & QCHAR_MASK_DELAY_BOUND) && (pcfg1->qoschar_delaybound != pcfg2->qoschar_delaybound))
		return 0;

	/*all parameters are matched*/
	return 1;
}


int update_scs_to_list(struct p1905_managerd_ctx *ctx, struct scs_cfg *pscs)
{
	int ret = STATUS_UNKNOWN;
	struct scs_cfg *pos = NULL, *tmp = NULL, *newnode = NULL;
	unsigned char delete_idx = 0;

	if (!ctx || !pscs)
		return STATUS_INVALID_POINTER;

	if (pscs->request_type == REQUEST_TYPE_ADD) {
		dl_list_for_each_safe(pos, tmp, &ctx->scs_list, struct scs_cfg, list) {
			if (compare_scs_config(pos, pscs) == 1)
				return STATUS_CFG_EXISTED;
		}

		if (ctx->scs_list_cnt > max_scs_cfg_count) {
			err(DEBUG_CAT_QOS, "scs config reach max count %u\n", ctx->scs_list_cnt);
			return STATUS_INSUFFICIENT_RESOURCE;
		}

		/*add new node*/
		newnode = (struct scs_cfg *)os_malloc(sizeof(struct scs_cfg));
		if (newnode) {
			pscs->scsid = allocate_scsid(ctx, pscs);
			pscs->index = ctx->scs_list_cnt + 1;
			os_memcpy(newnode, pscs, sizeof(*newnode));
			dl_list_add_tail(&ctx->scs_list, &newnode->list);
			ctx->scs_list_cnt++;
			ret = STATUS_SUCCESS;
		} else {
			err(DEBUG_CAT_QOS, "memory alloc fail\n");
			ret = STATUS_ALLOC_MEM_FAIL;
		}
	} else if (pscs->request_type == REQUEST_TYPE_CHANGE) {
		dl_list_for_each_safe(pos, tmp, &ctx->scs_list, struct scs_cfg, list) {
			if ((pos->index == pscs->index) && mac_addr_equal(pos->sta_mac, pscs->sta_mac)) {
				if (compare_scs_config(pos, pscs) == 1)
					return STATUS_CFG_IS_THE_SAME;

				/* update scsid for building IE */
				pscs->scsid = pos->scsid;

				/*update tclas parameters*/
				pos->up = pscs->up;
				pos->cs_mask = pscs->cs_mask;
				pos->version = pscs->version;
				os_memcpy(&pos->srcIp, &pscs->srcIp, sizeof(pscs->srcIp));
				os_memcpy(&pos->destIp, &pscs->destIp, sizeof(pscs->destIp));
				pos->srcPort = pscs->srcPort;
				pos->destPort = pscs->destPort;
				pos->protocol = pscs->protocol;

				/*update qos characteristics parameters*/
				pos->qchar_mask = pscs->qchar_mask;
				pos->qoschar_dir = pscs->qoschar_dir;
				pos->qoschar_min_interval = pscs->qoschar_min_interval;
				pos->qoschar_max_interval = pscs->qoschar_max_interval;
				pos->qoschar_min_datarate = pscs->qoschar_min_datarate;
				pos->qoschar_delaybound = pscs->qoschar_delaybound;

				return STATUS_SUCCESS;
			}
		}
		ret = STATUS_CFG_NOT_EXISTED;
	} else if (pscs->request_type == REQUEST_TYPE_REMOVE) {
		dl_list_for_each_safe(pos, tmp, &ctx->scs_list, struct scs_cfg, list) {
			if (pos->index == pscs->index) {
				delete_idx = pos->index;

				/*save scsid & sta_mac to removed node*/
				pscs->scsid = pos->scsid;
				if (!mac_addr_equal(pscs->sta_mac, pos->sta_mac))
					os_memcpy(pscs->sta_mac, pos->sta_mac, MAC_ADDR_LEN);

				/*remove node*/
				dl_list_del(&pos->list);
				os_free(pos);
				ret = STATUS_SUCCESS;
				if (ctx->scs_list_cnt)
					ctx->scs_list_cnt--;
			}
		}
		if (ret == STATUS_SUCCESS) {
			/*re-arrange the index of list*/
			dl_list_for_each_safe(pos, tmp, &ctx->scs_list, struct scs_cfg, list) {
				if (pos->index > delete_idx)
					pos->index--;
			}
		} else
			ret = STATUS_CFG_NOT_EXISTED;
	} else {
		warn(DEBUG_CAT_QOS, "invalid op type:%u\n", pscs->request_type);
		ret = STATUS_INVALID_ACTION;
	}
	return ret;
}

int update_qosmap_to_list(struct p1905_managerd_ctx *ctx, struct qos_map *pqosmap)
{
	int ret = STATUS_UNKNOWN;
	struct qos_map *pos = NULL, *tmp = NULL, *newnode = NULL;

	if (!ctx || !pqosmap)
		return STATUS_INVALID_POINTER;

	dl_list_for_each_safe(pos, tmp, &ctx->qosmap_list, struct qos_map, list) {
		if (mac_addr_equal(pos->al_mac, pqosmap->al_mac)) {
			/*update qosmap config*/
			pos->num = pqosmap->num;
			os_memcpy(&pos->dscp_ex, &pqosmap->dscp_ex, sizeof(pqosmap->dscp_ex));
			os_memcpy(&pos->dscp_rg, &pqosmap->dscp_rg, sizeof(pqosmap->dscp_rg));
			return STATUS_SUCCESS;
		}
	}

	/*add new node*/
	newnode = (struct qos_map *)os_malloc(sizeof(struct qos_map));
	if (newnode) {
		os_memcpy(newnode, pqosmap, sizeof(*newnode));
		dl_list_add_tail(&ctx->qosmap_list, &newnode->list);
		ret = STATUS_SUCCESS;
	} else {
		err(DEBUG_CAT_QOS, "memory alloc fail\n");
		ret = STATUS_ALLOC_MEM_FAIL;
	}
	return ret;
}

int update_disallow_to_list(struct p1905_managerd_ctx *ctx, struct mscs_scs_disallowed *pdisallow)
{
	int ret = STATUS_UNKNOWN;
	struct mscs_scs_disallowed *pos = NULL, *tmp = NULL, *newnode = NULL;

	if (!ctx || !pdisallow)
		return STATUS_INVALID_POINTER;

	dl_list_for_each_safe(pos, tmp, &ctx->disallowed_list, struct mscs_scs_disallowed, list) {
		if (mac_addr_equal(pos->al_mac, pdisallow->al_mac)) {
			/*update disallow config*/
			os_memcpy(&pos->qpolicy, &pdisallow->qpolicy, sizeof(pdisallow->qpolicy));
			return STATUS_SUCCESS;
		}
	}

	/*add new node*/
	newnode = (struct mscs_scs_disallowed *)os_malloc(sizeof(struct mscs_scs_disallowed));
	if (newnode) {
		os_memcpy(newnode, pdisallow, sizeof(*newnode));
		dl_list_add_tail(&ctx->disallowed_list, &newnode->list);
		ret = STATUS_SUCCESS;
	} else {
		err(DEBUG_CAT_QOS, "memory alloc fail\n");
		ret = STATUS_ALLOC_MEM_FAIL;
	}
	return ret;
}

void show_mscs_list(struct p1905_managerd_ctx *ctx)
{
	int ret = 0;
	struct mscs_cfg *pos = NULL;
	char *tmpbuf = NULL;
	unsigned int buflen = 10240, offset = 0;

	if (!ctx)
		return;

	if (ctx->mscs_list_cnt == 0)
		return;

	tmpbuf = os_malloc(buflen);
	if (!tmpbuf) {
		err(DEBUG_CAT_QOS, "memory alloc fail\n");
		return;
	}
	offset += ret;

	ret = snprintf(tmpbuf + offset, buflen - offset, "---------MAP MSCS Configuration---------\n");
	if (os_snprintf_error(buflen - offset, ret))
		goto exit;
	offset += ret;

	dl_list_for_each(pos, &ctx->mscs_list, struct mscs_cfg, list) {
		ret = snprintf(tmpbuf + offset, buflen - offset,
			" %02d. sta_mac,"MACSTR",up_bitmap,0x%02x,cs_mask,0x%02x,agent_almac,"MACSTR"\n",
			pos->index, PRINT_MAC(pos->sta_mac), pos->up_bitmap, pos->cs_mask, PRINT_MAC(pos->agent_almac));
		if (os_snprintf_error(buflen - offset, ret))
			goto exit;
		offset += ret;
	}

exit:
	if (os_snprintf_error(buflen - offset, ret))
		err(DEBUG_CAT_QOS, "error happen, ret = %d\n", ret);
	else if (os_strlen(tmpbuf))
		printf("%s\n", tmpbuf);
	else
		printf("---------no MSCS configuration---------\n");

	if (tmpbuf)
		os_free(tmpbuf);
}

char *dir2str(unsigned char dir)
{
	if (dir == DIR_UPLINK)
		return "UL";
	else if (dir == DIR_DOWNLINK)
		return "DL";
	else
		return "unknown";
}

void show_scs_list(struct p1905_managerd_ctx *ctx)
{
	int ret = 0;
	struct scs_cfg *pos = NULL;
	char *tmpbuf = NULL;
	unsigned int buflen = 10240, offset = 0;

	if (!ctx)
		return;

	if (ctx->scs_list_cnt == 0)
		return;

	tmpbuf = os_malloc(buflen);
	if (!tmpbuf) {
		err(DEBUG_CAT_QOS, "memory alloc fail\n");
		return;
	}

	ret = snprintf(tmpbuf + offset, buflen - offset, "---------MAP SCS Configuration---------\n");
	if (os_snprintf_error(buflen - offset, ret))
		goto exit;
	offset += ret;

	dl_list_for_each(pos, &ctx->scs_list, struct scs_cfg, list) {
		ret = snprintf(tmpbuf + offset, buflen - offset,
			" %02d. sta_mac,"MACSTR",scsid,%d,up,%d,",
			pos->index, PRINT_MAC(pos->sta_mac), pos->scsid, pos->up);
		if (os_snprintf_error(buflen - offset, ret))
			goto exit;
		offset += ret;

		if (pos->cs_mask) {
			ret = snprintf(tmpbuf + offset, buflen - offset, "cs_mask,0x%02x,", pos->cs_mask);
			if (os_snprintf_error(buflen - offset, ret))
				goto exit;
			offset += ret;
		}

		if (pos->cs_mask & TYPE4_CS_MASK_VERSION) {
			ret = snprintf(tmpbuf + offset, buflen - offset, "ipver,%d,", pos->version);
			if (os_snprintf_error(buflen - offset, ret))
				goto exit;
			offset += ret;
		}

		if (pos->version == VER_IPV4) {
			if (pos->cs_mask & TYPE4_CS_MASK_SRC_IP) {
				ret = snprintf(tmpbuf + offset, buflen - offset,
					"srcip,"IPV4STR",", NIP4(pos->srcIp.ipv4));
				if (os_snprintf_error(buflen - offset, ret))
					goto exit;
				offset += ret;
			}
			if (pos->cs_mask & TYPE4_CS_MASK_DST_IP) {
				ret = snprintf(tmpbuf + offset, buflen - offset,
					"dstip,"IPV4STR",", NIP4(pos->destIp.ipv4));
				if (os_snprintf_error(buflen - offset, ret))
					goto exit;
				offset += ret;
			}
		} else if (pos->version == VER_IPV6) {
			if (pos->cs_mask & TYPE4_CS_MASK_SRC_IP) {
				ret = snprintf(tmpbuf + offset, buflen - offset,
					"srcip,"IPV6STR",", NIP6(pos->srcIp.ipv6));
				if (os_snprintf_error(buflen - offset, ret))
					goto exit;
				offset += ret;
			}
			if (pos->cs_mask & TYPE4_CS_MASK_DST_IP) {
				ret = snprintf(tmpbuf + offset, buflen - offset,
					"dstip,"IPV6STR",", NIP6(pos->destIp.ipv6));
				if (os_snprintf_error(buflen - offset, ret))
					goto exit;
				offset += ret;
			}
		}

		if (pos->cs_mask & TYPE4_CS_MASK_SRC_PORT) {
			ret = snprintf(tmpbuf + offset, buflen - offset, "srcport,%d,", pos->srcPort);
			if (os_snprintf_error(buflen - offset, ret))
				goto exit;
			offset += ret;
		}
		if (pos->cs_mask & TYPE4_CS_MASK_DST_PORT) {
			ret = snprintf(tmpbuf + offset, buflen - offset, "dstport,%d,",	pos->destPort);
			if (os_snprintf_error(buflen - offset, ret))
				goto exit;
			offset += ret;
		}
		if (pos->cs_mask & TYPE4_CS_MASK_PROTOCOL) {
			ret = snprintf(tmpbuf + offset, buflen - offset, "protocol,%s,", protocol2str(pos->protocol));
			if (os_snprintf_error(buflen - offset, ret))
				goto exit;
			offset += ret;
		}

		/*show qos characteristics IE*/
		if (pos->qchar_mask & QCHAR_MASK_DIR) {
			ret = snprintf(tmpbuf + offset, buflen - offset,
			       "qoschar_dir,%s,", dir2str(pos->qoschar_dir));
			if (os_snprintf_error(buflen - offset, ret))
				goto exit;
			offset += ret;
		}
		if (pos->qchar_mask & QCHAR_MASK_MIN_INTERVAL) {
			ret = snprintf(tmpbuf + offset, buflen - offset,
			       "qoschar_min_interval,%d,", pos->qoschar_min_interval);
			if (os_snprintf_error(buflen - offset, ret))
				goto exit;
			offset += ret;
		}
		if (pos->qchar_mask & QCHAR_MASK_MAX_INTERVAL) {
			ret = snprintf(tmpbuf + offset, buflen - offset,
			       "qoschar_max_interval,%d,", pos->qoschar_max_interval);
			if (os_snprintf_error(buflen - offset, ret))
				goto exit;
			offset += ret;
		}
		if (pos->qchar_mask & QCHAR_MASK_MIN_DATA_RATE) {
			ret = snprintf(tmpbuf + offset, buflen - offset,
			       "qoschar_min_datarate,%d,", pos->qoschar_min_datarate);
			if (os_snprintf_error(buflen - offset, ret))
				goto exit;
			offset += ret;
		}
		if (pos->qchar_mask & QCHAR_MASK_DELAY_BOUND) {
			ret = snprintf(tmpbuf + offset, buflen - offset,
			       "qoschar_delaybound,%d,", pos->qoschar_delaybound);
			if (os_snprintf_error(buflen - offset, ret))
				goto exit;
			offset += ret;
		}

		ret = snprintf(tmpbuf + offset, buflen - offset, "agent_almac,"MACSTR"\n", PRINT_MAC(pos->agent_almac));
		if (os_snprintf_error(buflen - offset, ret))
			goto exit;
		offset += ret;
	}

exit:
	if (os_snprintf_error(buflen - offset, ret))
		err(DEBUG_CAT_QOS, "error happen, ret = %d\n", ret);
	else if (os_strlen(tmpbuf))
		printf("%s\n", tmpbuf);
	else
		printf("---------no SCS configuration---------\n");

	if (tmpbuf)
		os_free(tmpbuf);
}

void show_qosmap_list(struct p1905_managerd_ctx *ctx)
{
	int ret = 0, i = 0, j = 0, count = 0;
	struct qos_map *pos = NULL;
	char *tmpbuf = NULL;
	unsigned int buflen = 10240, offset = 0;

	if (!ctx)
		return;

	dl_list_for_each(pos, &ctx->qosmap_list, struct qos_map, list)
		count++;
	if (count == 0)
		return;

	tmpbuf = os_malloc(buflen);
	if (!tmpbuf) {
		err(DEBUG_CAT_QOS, "memory alloc fail\n");
		return;
	}

	ret = snprintf(tmpbuf + offset, buflen - offset, "---------MAP QoSMap Configuration---------\n");
	if (os_snprintf_error(buflen - offset, ret))
		goto exit;
	offset += ret;

	dl_list_for_each(pos, &ctx->qosmap_list, struct qos_map, list) {
		ret = snprintf(tmpbuf + offset, buflen - offset, " %02d. al_mac,"MACSTR",",
			i++, PRINT_MAC(pos->al_mac));
		if (os_snprintf_error(buflen - offset, ret))
			goto exit;
		offset += ret;

		if (pos->num) {
			ret = snprintf(tmpbuf + offset, buflen - offset, "dscp_exception,");
			if (os_snprintf_error(buflen - offset, ret))
				goto exit;
			offset += ret;
		}
		for (j = 0; j < pos->num && j < MAX_EXCEPT_CNT; j++) {
			ret = snprintf(tmpbuf + offset, buflen - offset, "%d,%d,",
				pos->dscp_ex[j].dscp, pos->dscp_ex[j].up);
			if (os_snprintf_error(buflen - offset, ret))
				goto exit;
			offset += ret;
		}
		ret = snprintf(tmpbuf + offset, buflen - offset, "dscp_range,");
		if (os_snprintf_error(buflen - offset, ret))
			goto exit;
		offset += ret;

		for (j = 0; j < MAX_UP; j++) {
			ret = snprintf(tmpbuf + offset, buflen - offset, "%d,%d,",
				pos->dscp_rg[j].low, pos->dscp_rg[j].high);
			if (os_snprintf_error(buflen - offset, ret))
				goto exit;
			offset += ret;
		}

		ret = snprintf(tmpbuf + offset, buflen - offset, "\n");
		if (os_snprintf_error(buflen - offset, ret))
			goto exit;
		offset += ret;
	}

exit:
	if (os_snprintf_error(buflen - offset, ret))
		err(DEBUG_CAT_QOS, "error happen, ret = %d\n", ret);
	else if (os_strlen(tmpbuf))
		printf("%s\n", tmpbuf);
	else
		printf("---------no qosmap configuration---------\n");

	if (tmpbuf)
		os_free(tmpbuf);
}

void show_disallow_list(struct p1905_managerd_ctx *ctx)
{
	int ret = 0, i = 0, j = 0, count = 0;
	struct mscs_scs_disallowed *pos = NULL;
	char *tmpbuf = NULL;
	unsigned int buflen = 10240, offset = 0;

	if (!ctx)
		return;

	dl_list_for_each(pos, &ctx->disallowed_list, struct mscs_scs_disallowed, list)
		count++;
	if (count == 0)
		return;

	tmpbuf = os_malloc(buflen);
	if (!tmpbuf) {
		err(DEBUG_CAT_QOS, "memory alloc fail\n");
		return;
	}

	ret = snprintf(tmpbuf + offset, buflen - offset, "-------MAP MSCS/SCS Disallowed Configuration-------\n");
	if (os_snprintf_error(buflen - offset, ret))
		goto exit;
	offset += ret;

	dl_list_for_each(pos, &ctx->disallowed_list, struct mscs_scs_disallowed, list) {
		ret = snprintf(tmpbuf + offset, buflen - offset, " %02d. al_mac,"MACSTR",",
			i++, PRINT_MAC(pos->al_mac));
		if (os_snprintf_error(buflen - offset, ret))
			goto exit;
		offset += ret;

		if (pos->qpolicy.numMSCSDisallowed) {
			ret = snprintf(tmpbuf + offset, buflen - offset, "mscslist,");
			if (os_snprintf_error(buflen - offset, ret))
				goto exit;
			offset += ret;
		}
		for (j = 0; j < pos->qpolicy.numMSCSDisallowed && j < MAX_NUM_DISALLOWED; j++) {
			ret = snprintf(tmpbuf + offset, buflen - offset, MACSTR",",
				PRINT_MAC(pos->qpolicy.MSCSDisallowed[j]));
			if (os_snprintf_error(buflen - offset, ret))
				goto exit;
			offset += ret;
		}
		if (pos->qpolicy.numSCSDisallowed) {
			ret = snprintf(tmpbuf + offset, buflen - offset, "scslist,");
			if (os_snprintf_error(buflen - offset, ret))
				goto exit;
			offset += ret;
		}
		for (j = 0; j < pos->qpolicy.numSCSDisallowed && j < MAX_NUM_DISALLOWED; j++) {
			ret = snprintf(tmpbuf + offset, buflen - offset, MACSTR",",
				PRINT_MAC(pos->qpolicy.SCSDisallowed[j]));
			if (os_snprintf_error(buflen - offset, ret))
				goto exit;
			offset += ret;
		}

		ret = snprintf(tmpbuf + offset, buflen - offset, "\n");
		if (os_snprintf_error(buflen - offset, ret))
			goto exit;
		offset += ret;
	}

exit:
	if (os_snprintf_error(buflen - offset, ret))
		err(DEBUG_CAT_QOS, "error happen, ret = %d\n", ret);
	else if (os_strlen(tmpbuf))
		printf("%s\n", tmpbuf);
	else
		printf("---------no qosmap configuration---------\n");

	if (tmpbuf)
		os_free(tmpbuf);
}

int send_1905_message(struct p1905_managerd_ctx *ctx,
	unsigned char *destalmac, unsigned short type, unsigned short tlv_len, unsigned char *pay_load)
{
	struct _1905_cmdu_request *request = (struct _1905_cmdu_request *)send_buf;

	if (!ctx || !destalmac || !pay_load) {
		err(DEBUG_CAT_QOS, "Invalid pointer.\n");
		return STATUS_INVALID_POINTER;
	}

	if (tlv_len > MAX_TLVS_LENGTH) {
		err(DEBUG_CAT_QOS, "too large tlv_len:%d\n", tlv_len);
		return STATUS_INVALID_BUFLEN;
	}

	request->type = type;
	request->len = tlv_len;
	os_memcpy(request->dest_al_mac, destalmac, ETH_ALEN);
	os_memcpy(request->body, pay_load, tlv_len);

	dev_send_1905(ctx, request);
	process_cmdu_txq(ctx, ctx->trx_buf.buf);

	return STATUS_SUCCESS;
}

int apply_mscs_to_agent(struct p1905_managerd_ctx *ctx, struct mscs_cfg *pmscs)
{
	int ret = 0, descrlen = 0, qosmgmttlv_len = 0;
	unsigned char descrbuff[64] = {0};
	struct assoc_client *client = NULL;
	struct qos_management_descriptor_tlv qosmgmttlv = {0};

	if (!ctx || !pmscs) {
		err(DEBUG_CAT_QOS, "Invalid pointer.\n");
		return STATUS_INVALID_POINTER;
	}

	client = get_assoc_cli_by_mac(ctx, pmscs->sta_mac);
	if (!client) {
		err(DEBUG_CAT_QOS, "can't find client entry.\n");
		return STATUS_NO_CLIENT_FOUND;
	}
	if (mac_addr_equal(client->al_mac, zero_mac)) {
		err(DEBUG_CAT_QOS, "invalid agent al_mac address.\n");
		return STATUS_INVALID_ALMAC;
	}

	/*build mscs descriptor*/
	descrlen = build_mscs_descriptor(descrbuff, sizeof(descrbuff), pmscs);
	if (descrlen < 0 || descrlen > sizeof(descrbuff)) {
		err(DEBUG_CAT_QOS, "build mscs descriptor failed, %s\n", err2str(descrlen));
		return descrlen;
	}

	/*fill qos management tlv*/
	qosmgmttlv_len = build_qos_management_descriptor_tlv(&qosmgmttlv,
		client->bssid, client->mac, descrbuff, descrlen);
	if (qosmgmttlv_len < 0 || qosmgmttlv_len > MAX_DESCRIPTOR_LEN) {
		err(DEBUG_CAT_QOS, "build qos management descriptor tlv failed, %s\n", err2str(qosmgmttlv_len));
		return qosmgmttlv_len;
	}

	ret = send_1905_message(ctx, client->al_mac, SERVICE_PRIORITIZATION_REQUEST,
		qosmgmttlv_len, (unsigned char *)&qosmgmttlv);
	if (ret < 0) {
		err(DEBUG_CAT_QOS, "send 1905 message failed, %s\n", err2str(ret));
		return ret;
	}

	return STATUS_SUCCESS;
}

int apply_scs_to_agent(struct p1905_managerd_ctx *ctx, struct scs_cfg *pscs)
{
	int ret = 0, descrlen = 0, qosmgmttlv_len = 0;
	unsigned char descrbuff[1024] = {0};
	struct assoc_client *client = NULL;
	struct qos_management_descriptor_tlv qosmgmttlv = {0};

	if (!ctx || !pscs) {
		err(DEBUG_CAT_QOS, "Invalid pointer.\n");
		return STATUS_INVALID_POINTER;
	}

	client = get_assoc_cli_by_mac(ctx, pscs->sta_mac);
	if (!client) {
		err(DEBUG_CAT_QOS, "can't find client entry.\n");
		return STATUS_NO_CLIENT_FOUND;
	}
	if (mac_addr_equal(client->al_mac, zero_mac)) {
		err(DEBUG_CAT_QOS, "invalid agent al_mac address.\n");
		return STATUS_INVALID_ALMAC;
	}

	/*build scs descriptor*/
	descrlen = build_scs_descriptor(descrbuff, sizeof(descrbuff), pscs);
	if (descrlen < 0 || descrlen > 0xFF) {
		err(DEBUG_CAT_QOS, "build scs descriptor failed, %s\n", err2str(descrlen));
		return descrlen;
	}

	/*fill qos management tlv*/
	qosmgmttlv_len = build_qos_management_descriptor_tlv(&qosmgmttlv,
		client->bssid, client->mac, descrbuff, descrlen);
	if (qosmgmttlv_len < 0 || qosmgmttlv_len > MAX_DESCRIPTOR_LEN) {
		err(DEBUG_CAT_QOS, "build qos management descriptor tlv failed, %s\n", err2str(qosmgmttlv_len));
		return qosmgmttlv_len;
	}

	ret = send_1905_message(ctx, client->al_mac, SERVICE_PRIORITIZATION_REQUEST,
		qosmgmttlv_len, (unsigned char *)&qosmgmttlv);
	if (ret < 0) {
		err(DEBUG_CAT_QOS, "send 1905 message failed, %s\n", err2str(ret));
		return ret;
	}

	return STATUS_SUCCESS;
}

int agent_valid_check(struct p1905_managerd_ctx *ctx, unsigned char *almac)
{
	struct agent_list_db *agent_info = NULL;

	SLIST_FOREACH(agent_info, &(ctx->agent_head), agent_entry) {
		if (!memcmp(agent_info->almac, almac, ETH_ALEN))
			return STATUS_SUCCESS;
	}
	return STATUS_INVALID_ALMAC;
}

int apply_qosmap_to_agent(struct p1905_managerd_ctx *ctx, struct qos_map *pqosmap)
{
	int ret = 0;
	unsigned char buff[67] = {0}, i = 0, j = 0, *pdscptbl = NULL;

	if (!ctx || !pqosmap) {
		err(DEBUG_CAT_QOS, "Invalid pointer.\n");
		return STATUS_INVALID_POINTER;
	}

	ret = agent_valid_check(ctx, pqosmap->al_mac);
	if (ret < 0) {
		err(DEBUG_CAT_QOS, "can't find MAP Agent with almac:"MACSTR"\n", MAC2STR(pqosmap->al_mac));
		return ret;
	}

	/*update qosmap structure to list*/
	ret = update_qosmap_to_list(ctx, pqosmap);
	if (ret < 0) {
		err(DEBUG_CAT_QOS, "update qosmap to list failed, %s\n", err2str(ret));
		return ret;
	}

	/*build DSCP Mapping Table TLV*/
	buff[0] = DSCP_MAPPING_TABLE_TYPE;

	/* length */
	*((unsigned short *)&buff[1]) = host_to_be16(DSCP_TBL_SIZE);

	pdscptbl = &buff[3];
	/*fill DSCP range to DSCP table*/
	for (i = 0; i < MAX_UP; i++) {
		if ((pqosmap->dscp_rg[i].low > pqosmap->dscp_rg[i].high) ||
			(pqosmap->dscp_rg[i].low >= DSCP_TBL_SIZE) ||
			(pqosmap->dscp_rg[i].high >= DSCP_TBL_SIZE))
			continue;
		for (j = pqosmap->dscp_rg[i].low; j <= pqosmap->dscp_rg[i].high; j++)
			pdscptbl[j] = i;
	}
	/*fill DSCP exception to DSCP table*/
	for (i = 0; i < pqosmap->num; i++) {
		if ((pqosmap->dscp_ex[i].dscp >= DSCP_TBL_SIZE) ||
			(pqosmap->dscp_ex[i].up >= MAX_UP))
			continue;
		pdscptbl[pqosmap->dscp_ex[i].dscp] = pqosmap->dscp_ex[i].up;
	}

	ret = send_1905_message(ctx, pqosmap->al_mac, SERVICE_PRIORITIZATION_REQUEST, sizeof(buff), buff);
	if (ret < 0) {
		err(DEBUG_CAT_QOS, "send 1905 message failed, %s\n", err2str(ret));
		return ret;
	}

	return STATUS_SUCCESS;
}

int apply_disallow_to_agent(struct p1905_managerd_ctx *ctx, struct mscs_scs_disallowed *pdisallow)
{
	int ret = 0;
	unsigned char buff[128] = {0}, len = 0, i = 0;

	if (!ctx || !pdisallow) {
		err(DEBUG_CAT_QOS, "Invalid pointer.\n");
		return STATUS_INVALID_POINTER;
	}

	ret = agent_valid_check(ctx, pdisallow->al_mac);
	if (ret < 0) {
		err(DEBUG_CAT_QOS, "can't find MAP Agent with almac:"MACSTR"\n", MAC2STR(pdisallow->al_mac));
		return ret;
	}

	/*update disallow structure to list*/
	ret = update_disallow_to_list(ctx, pdisallow);
	if (ret < 0) {
		err(DEBUG_CAT_QOS, "update disallow to list failed, %s\n", err2str(ret));
		return ret;
	}

	/*build QoS Management Policy TLV*/
	buff[len] = QOS_MANAGEMENT_POLICY_TYPE;
	len += 1;

	/*length, set to 0 here, will update later*/
	*((unsigned short *)&buff[len]) = 0;
	len += 2;

	/*Number of STAs for which MSCS operation is disallowed*/
	buff[len] = (pdisallow->qpolicy.numMSCSDisallowed < MAX_NUM_DISALLOWED) ?
			pdisallow->qpolicy.numMSCSDisallowed : MAX_NUM_DISALLOWED;
	len += 1;

	/*MAC address of STA for which MSCS operation is disallowed*/
	for (i = 0; i < pdisallow->qpolicy.numMSCSDisallowed && i < MAX_NUM_DISALLOWED; i++) {
		os_memcpy(&buff[len], pdisallow->qpolicy.MSCSDisallowed[i], MAC_ADDR_LEN);
		len += MAC_ADDR_LEN;
	}

	/*Number of STAs for which SCS operation is disallowed*/
	buff[len] = (pdisallow->qpolicy.numSCSDisallowed < MAX_NUM_DISALLOWED) ?
			pdisallow->qpolicy.numSCSDisallowed : MAX_NUM_DISALLOWED;
	len += 1;

	/*MAC address of STA for which SCS operation is disallowed*/
	for (i = 0; i < pdisallow->qpolicy.numSCSDisallowed && i < MAX_NUM_DISALLOWED; i++) {
		os_memcpy(&buff[len], pdisallow->qpolicy.SCSDisallowed[i], MAC_ADDR_LEN);
		len += MAC_ADDR_LEN;
	}

	/* skip 20 octets reserved*/
	len += 20;

	/*update length*/
	*((unsigned short *)&buff[1]) = host_to_be16(len - 3);

	ret = send_1905_message(ctx, pdisallow->al_mac, MAP_POLICY_CONFIG_REQUEST, len, buff);
	if (ret < 0) {
		err(DEBUG_CAT_QOS, "send 1905 message failed, %s\n", err2str(ret));
		return ret;
	}

	return STATUS_SUCCESS;
}

int apply_mscs_to_controller(struct p1905_managerd_ctx *ctx, struct mscs_cfg *pmscs)
{
	int descrlen = 0, qosmgmttlv_len = 0;
	unsigned char descrbuff[64] = {0};
	struct qos_management_descriptor_tlv qosmgmttlv = {0};
	u8 bssid[] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};

	if (!ctx || !pmscs) {
		err(DEBUG_CAT_QOS, "Invalid pointer.\n");
		return STATUS_INVALID_POINTER;
	}

	/*build mscs descriptor*/
	descrlen = build_mscs_descriptor(descrbuff, sizeof(descrbuff), pmscs);
	if (descrlen < 0 || descrlen > sizeof(descrbuff)) {
		err(DEBUG_CAT_QOS, "build mscs descriptor failed, %s\n", err2str(descrlen));
		return descrlen;
	}

	/*fill qos management tlv*/
	qosmgmttlv_len = build_qos_management_descriptor_tlv(&qosmgmttlv,
		bssid, pmscs->sta_mac, descrbuff, descrlen);
	if (qosmgmttlv_len < 0 || qosmgmttlv_len > MAX_DESCRIPTOR_LEN) {
		err(DEBUG_CAT_QOS, "build qos management descriptor tlv failed, %s\n", err2str(qosmgmttlv_len));
		return qosmgmttlv_len;
	}

	debug(DEBUG_CAT_QOS, "call _1905_notify_qos_mgmt_descriptor()\n");

	/*notify qos management tlv to mapd*/
	_1905_notify_qos_mgmt_descriptor(ctx, &qosmgmttlv);

	return STATUS_SUCCESS;
}

int apply_scs_to_controller(struct p1905_managerd_ctx *ctx, struct scs_cfg *pscs)
{
	int descrlen = 0, qosmgmttlv_len = 0;
	unsigned char descrbuff[1024] = {0};
	struct qos_management_descriptor_tlv qosmgmttlv = {0};
	u8 bssid[] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};

	if (!ctx || !pscs) {
		err(DEBUG_CAT_QOS, "Invalid pointer.\n");
		return STATUS_INVALID_POINTER;
	}

	/*build scs descriptor*/
	descrlen = build_scs_descriptor(descrbuff, sizeof(descrbuff), pscs);
	if (descrlen < 0 || descrlen > 0xFF) {
		err(DEBUG_CAT_QOS, "build scs descriptor failed, %s\n", err2str(descrlen));
		return descrlen;
	}

	/*fill qos management tlv*/
	qosmgmttlv_len = build_qos_management_descriptor_tlv(&qosmgmttlv,
		bssid, pscs->sta_mac, descrbuff, descrlen);
	if (qosmgmttlv_len < 0 || qosmgmttlv_len > MAX_DESCRIPTOR_LEN) {
		err(DEBUG_CAT_QOS, "build qos management descriptor tlv failed, %s\n", err2str(qosmgmttlv_len));
		return qosmgmttlv_len;
	}

	/*notify qos management tlv to mapd*/
	_1905_notify_qos_mgmt_descriptor(ctx, &qosmgmttlv);

	return STATUS_SUCCESS;
}

int set_qos_config(void *context, char *buf)
{
	int ret = STATUS_SUCCESS;
	struct mscs_cfg mscs;
	struct scs_cfg scs;
	struct qos_map qosmap;
	struct mscs_scs_disallowed disallow;
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx *)context;

	if (ctx->role != CONTROLLER) {
		warn(DEBUG_CAT_QOS, "command only available on controller.\n");
		return STATUS_CMD_NOT_SUPPORT;
	}

	if (!buf) {
		err(DEBUG_CAT_QOS, "invalid pointer buf:%p\n", buf);
		return STATUS_INVALID_POINTER;
	}
	if (!os_strlen(buf)) {
		err(DEBUG_CAT_QOS, "invalid cmd, buf is empty.\n");
		return STATUS_INVALID_PARAM;
	}

	if (os_strncmp(buf, "MSCSReq", os_strlen("MSCSReq")) == 0) {
		os_memset(&mscs, 0, sizeof(mscs));

		/*1. parse mscs cmd*/
		ret = parse_mscs_cmd(buf, &mscs);
		if (ret != STATUS_SUCCESS) {
			err(DEBUG_CAT_QOS, "parsing mscs cmd failed, %s\n", err2str(ret));
			return ret;
		}

		/*2. sanity check*/
		ret = mscs_sanity_check(&mscs);
		if (ret != STATUS_SUCCESS) {
			err(DEBUG_CAT_QOS, "mscs cmd sanity check failed, %s\n", err2str(ret));
			return ret;
		}

		/*3. update mscs associated Agent almac*/
		ret = get_associated_agent_almac(ctx, mscs.sta_mac, mscs.agent_almac);
		if (ret != STATUS_SUCCESS)
			warn(DEBUG_CAT_QOS, "the sta "MACSTR" wasn't online yet\n", MAC2STR(mscs.sta_mac));

		/*4. update mscs structure to list*/
		ret = update_mscs_to_list(ctx, &mscs);
		if (ret != STATUS_SUCCESS) {
			err(DEBUG_CAT_QOS, "update mscs to list failed, %s\n",	err2str(ret));
			return ret;
		}

		/*5. apply mscs to the Agent the STA connected*/
		if (!mac_addr_equal(mscs.agent_almac, zero_mac)) {
			ret = apply_mscs_to_agent(ctx, &mscs);
			if (ret != STATUS_SUCCESS)
				warn(DEBUG_CAT_QOS, "apply mscs to agent failed, %s\n", err2str(ret));
		}

		/*6. apply mscs to the Controller*/
		ret = apply_mscs_to_controller(ctx, &mscs);
		if (ret != STATUS_SUCCESS)
			warn(DEBUG_CAT_QOS, "apply mscs to controller failed, %s\n", err2str(ret));
	} else if (os_strncmp(buf, "SCSReq", os_strlen("SCSReq")) == 0) {
		os_memset(&scs, 0, sizeof(scs));

		/*1. parse scs cmd*/
		ret = parse_scs_cmd(buf, &scs);
		if (ret != STATUS_SUCCESS) {
			err(DEBUG_CAT_QOS, "parsing scs cmd failed, %s\n", err2str(ret));
			return ret;
		}

		/*2. sanity check*/
		ret = scs_sanity_check(&scs);
		if (ret != STATUS_SUCCESS) {
			err(DEBUG_CAT_QOS, "scs cmd sanity check failed, %s\n", err2str(ret));
			return ret;
		}

		/*3. update scs associated Agent almac*/
		ret = get_associated_agent_almac(ctx, scs.sta_mac, scs.agent_almac);
		if (ret != STATUS_SUCCESS)
			warn(DEBUG_CAT_QOS, "the sta "MACSTR" wasn't online yet\n", MAC2STR(scs.sta_mac));

		/*4. update scs structure to list*/
		ret = update_scs_to_list(ctx, &scs);
		if (ret != STATUS_SUCCESS) {
			err(DEBUG_CAT_QOS, "update scs to list failed, %s\n",	err2str(ret));
			return ret;
		}

		/*5. apply scs to the Agent the STA connected*/
		if (!mac_addr_equal(scs.agent_almac, zero_mac)) {
			ret = apply_scs_to_agent(ctx, &scs);
			if (ret != STATUS_SUCCESS)
				warn(DEBUG_CAT_QOS, "apply scs to agent failed, %s\n", err2str(ret));
		}

		/*6. apply scs to the Controller*/
		ret = apply_scs_to_controller(ctx, &scs);
		if (ret != STATUS_SUCCESS)
			warn(DEBUG_CAT_QOS, "apply scs to controller failed, %s\n", err2str(ret));
	} else if (os_strncmp(buf, "Qosmap", os_strlen("Qosmap")) == 0) {
		os_memset(&qosmap, 0, sizeof(qosmap));

		/*1. parse qosmap cmd*/
		ret = parse_qosmap_cmd(buf, &qosmap);
		if (ret != STATUS_SUCCESS) {
			err(DEBUG_CAT_QOS, "parsing qosmap cmd failed, %s\n", err2str(ret));
			return ret;
		}

		/*2. sanity check*/
		ret = qosmap_sanity_check(&qosmap);
		if (ret != STATUS_SUCCESS) {
			err(DEBUG_CAT_QOS, "qosmap cmd sanity check failed, %s\n", err2str(ret));
			return ret;
		}

		/*3. apply qosmap to agent*/
		ret = apply_qosmap_to_agent(ctx, &qosmap);
		if (ret != STATUS_SUCCESS)
			warn(DEBUG_CAT_QOS, "apply qosmap to agent failed, %s\n", err2str(ret));
	} else if (os_strncmp(buf, "Disallowed", os_strlen("Disallowed")) == 0) {
		os_memset(&disallow, 0, sizeof(disallow));

		/*1. parse disallow cmd*/
		ret = parse_disallow_cmd(buf, &disallow);
		if (ret != STATUS_SUCCESS) {
			err(DEBUG_CAT_QOS, "parsing disallow cmd failed, %s\n", err2str(ret));
			return ret;
		}

		/*2. sanity check*/
		ret = disallow_sanity_check(&disallow);
		if (ret != STATUS_SUCCESS) {
			err(DEBUG_CAT_QOS, "disallow cmd sanity check failed, %s\n", err2str(ret));
			return ret;
		}

		/*3. apply disalow to agent*/
		ret = apply_disallow_to_agent(ctx, &disallow);
		if (ret != STATUS_SUCCESS)
			warn(DEBUG_CAT_QOS, "apply disallow to agent failed, %s\n", err2str(ret));
	} else {
		err(DEBUG_CAT_QOS, "invalid qos commands type.\n");
		ret = STATUS_INVALID_CMD_TYPE;
	}
	return ret;
}

int get_qos_config(void *context, char *cmdstr, char *reply_buf, int *reply_len)
{
	int ret = STATUS_SUCCESS;
	struct mscs_cfg *pos_mscs = NULL;
	struct scs_cfg *pos_scs = NULL;
	char *tmpbuf = NULL;
	unsigned int buflen = 10240, offset = 0;
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx *)context;

	if (!ctx)
		return STATUS_INVALID_POINTER;

	if (ctx->role != CONTROLLER) {
		warn(DEBUG_CAT_QOS, "command only available on controller.\n");
		return STATUS_CMD_NOT_SUPPORT;
	}

	if (os_strncmp(cmdstr, "MSCSReq", os_strlen("MSCSReq")) == 0) {
		if (ctx->mscs_list_cnt == 0)
			return STATUS_CFG_NOT_EXISTED;

		tmpbuf = os_malloc(buflen);
		if (!tmpbuf) {
			err(DEBUG_CAT_QOS, "memory alloc fail\n");
			return STATUS_ALLOC_MEM_FAIL;
		}
		offset += ret;

		/* Form MSCS configuration as below format.
		 * MSCSReq,index,i,action,add,sta_mac,01:02:03:45:67:89,up_bitmap, 00001111,cs_mask,11111010
		 */
		dl_list_for_each(pos_mscs, &ctx->mscs_list, struct mscs_cfg, list) {
			ret = snprintf(tmpbuf + offset, buflen - offset,
				"MSCSReq,index,%u,sta_mac,"MACSTR",up_bitmap,%s,",
				pos_mscs->index, PRINT_MAC(pos_mscs->sta_mac),
				convert_i2strbitmap(pos_mscs->up_bitmap));
			if (os_snprintf_error(buflen - offset, ret))
				goto exit;
			offset += ret;

			ret = snprintf(tmpbuf + offset, buflen - offset, "cs_mask,%s\n",
				convert_i2strbitmap(pos_mscs->cs_mask));
			if (os_snprintf_error(buflen - offset, ret))
				goto exit;
			offset += ret;
		}
	} else if (os_strncmp(cmdstr, "SCSReq", os_strlen("SCSReq")) == 0) {
		if (ctx->scs_list_cnt == 0)
			return STATUS_CFG_NOT_EXISTED;

		tmpbuf = os_malloc(buflen);
		if (!tmpbuf) {
			err(DEBUG_CAT_QOS, "memory alloc fail\n");
			return STATUS_ALLOC_MEM_FAIL;
		}
		offset += ret;

		/* Form SCS configuration as below format.
		 * SCSReq,index,i,action,add,sta_mac,01:02:03:45:67:89,up,6,ipver,4,srcip,192.165.100.101,
		 * dstip,192.165.100.70,srcport,5002,dstport,10002,protocol,UDP
		 */
		dl_list_for_each(pos_scs, &ctx->scs_list, struct scs_cfg, list) {
			ret = snprintf(tmpbuf + offset, buflen - offset,
				"SCSReq,index,%u,sta_mac,"MACSTR",up,%u,",
				pos_scs->index, PRINT_MAC(pos_scs->sta_mac), pos_scs->up);
			if (os_snprintf_error(buflen - offset, ret))
				goto exit;
			offset += ret;

			if (pos_scs->cs_mask & TYPE4_CS_MASK_VERSION) {
				ret = snprintf(tmpbuf + offset, buflen - offset, "ipver,%d,", pos_scs->version);
				if (os_snprintf_error(buflen - offset, ret))
					goto exit;
				offset += ret;
			}

			if (pos_scs->version == VER_IPV4) {
				if (pos_scs->cs_mask & TYPE4_CS_MASK_SRC_IP) {
					ret = snprintf(tmpbuf + offset, buflen - offset,
						"srcip,"IPV4STR",", NIP4(pos_scs->srcIp.ipv4));
					if (os_snprintf_error(buflen - offset, ret))
						goto exit;
					offset += ret;
				}
				if (pos_scs->cs_mask & TYPE4_CS_MASK_DST_IP) {
					ret = snprintf(tmpbuf + offset, buflen - offset,
						"dstip,"IPV4STR",", NIP4(pos_scs->destIp.ipv4));
					if (os_snprintf_error(buflen - offset, ret))
						goto exit;
					offset += ret;
				}
			} else if (pos_scs->version == VER_IPV6) {
				if (pos_scs->cs_mask & TYPE4_CS_MASK_SRC_IP) {
					ret = snprintf(tmpbuf + offset, buflen - offset,
						"srcip,"IPV6STR",", NIP6(pos_scs->srcIp.ipv6));
					if (os_snprintf_error(buflen - offset, ret))
						goto exit;
					offset += ret;
				}
				if (pos_scs->cs_mask & TYPE4_CS_MASK_DST_IP) {
					ret = snprintf(tmpbuf + offset, buflen - offset,
						"dstip,"IPV6STR",", NIP6(pos_scs->destIp.ipv6));
					if (os_snprintf_error(buflen - offset, ret))
						goto exit;
					offset += ret;
				}
			}

			if (pos_scs->cs_mask & TYPE4_CS_MASK_SRC_PORT) {
				ret = snprintf(tmpbuf + offset, buflen - offset, "srcport,%d,", pos_scs->srcPort);
				if (os_snprintf_error(buflen - offset, ret))
					goto exit;
				offset += ret;
			}
			if (pos_scs->cs_mask & TYPE4_CS_MASK_DST_PORT) {
				ret = snprintf(tmpbuf + offset, buflen - offset, "dstport,%d,",	pos_scs->destPort);
				if (os_snprintf_error(buflen - offset, ret))
					goto exit;
				offset += ret;
			}
			if (pos_scs->cs_mask & TYPE4_CS_MASK_PROTOCOL) {
				ret = snprintf(tmpbuf + offset, buflen - offset, "protocol,%s,", protocol2str(pos_scs->protocol));
				if (os_snprintf_error(buflen - offset, ret))
					goto exit;
				offset += ret;
			}

			ret = snprintf(tmpbuf + offset, buflen - offset, "\n");
			if (os_snprintf_error(buflen - offset, ret))
				goto exit;
			offset += ret;
		}
	} else {
		ret = STATUS_INVALID_CMD_TYPE;
		warn(DEBUG_CAT_QOS, "not support command type for getting qos config.\n");
	}

exit:
	if (os_snprintf_error(buflen - offset, ret)) {
		err(DEBUG_CAT_QOS, "snprintf failed, ret = %d\n", ret);
		ret = STATUS_MEMORY_OVERFLOW;
	} else if (os_strlen(tmpbuf) && os_strlen(tmpbuf) < *reply_len) {
		memcpy(reply_buf, tmpbuf, os_strlen(tmpbuf));
		*reply_len = os_strlen(tmpbuf);
		ret = STATUS_SUCCESS;
	}

	if (tmpbuf)
		os_free(tmpbuf);

	return ret;
}

int save_qos_config(void *context)
{
	FILE *f = NULL;
	int ret = STATUS_SUCCESS;
	char *mscsbuf = NULL, *scsbuf = NULL;
	int mscsbuflen = 0, scsbuflen = 0;
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx *)context;

	if (!ctx)
		return STATUS_INVALID_POINTER;

	if (ctx->role != CONTROLLER) {
		warn(DEBUG_CAT_QOS, "command only available on controller.\n");
		return STATUS_CMD_NOT_SUPPORT;
	}
	if (ctx->mscs_list_cnt == 0 && ctx->scs_list_cnt == 0)
		warn(DEBUG_CAT_QOS, "no qos config existed.\n");

	if (ctx->mscs_list_cnt) {
		mscsbuflen = ctx->mscs_list_cnt * 256;
		mscsbuf = os_malloc(mscsbuflen);
		if (!mscsbuf) {
			err(DEBUG_CAT_QOS, "MSCS memory alloc fail\n");
			ret = STATUS_ALLOC_MEM_FAIL;
			goto exit;
		}

		ret = get_qos_config(context, "MSCSReq", mscsbuf, &mscsbuflen);
		if (ret != STATUS_SUCCESS) {
			err(DEBUG_CAT_QOS, "get MSCS config fail.%s\n", err2str(ret));
			goto exit;
		}
	}

	if (ctx->scs_list_cnt) {
		scsbuflen = ctx->scs_list_cnt * 512;
		scsbuf = os_malloc(scsbuflen);
		if (!scsbuf) {
			err(DEBUG_CAT_QOS, "SCS memory alloc fail\n");
			ret = STATUS_ALLOC_MEM_FAIL;
			goto exit;
		}

		ret = get_qos_config(context, "SCSReq", scsbuf, &scsbuflen);
		if (ret != STATUS_SUCCESS) {
			err(DEBUG_CAT_QOS, "get SCS config fail.%s\n", err2str(ret));
			goto exit;
		}
	}

	/* write configuration to file. */
	f = fopen(QOS_CONF_PATH, "w");
	if (f == NULL)
		goto exit;

	if (mscsbuflen) {
		ret = fwrite(mscsbuf, 1, mscsbuflen, f);
		if (mscsbuflen != ret) {
			err(DEBUG_CAT_QOS, "write mscs error. mscsbuflen:%d, ret:%d\n", mscsbuflen, ret);
			goto exit1;
		}
	}
	if (scsbuflen) {
		ret = fwrite(scsbuf, 1, scsbuflen, f);
		if (scsbuflen != ret) {
			err(DEBUG_CAT_QOS, "write scs error. mscsbuflen:%d, ret:%d\n", scsbuflen, ret);
			goto exit1;
		}
	}

exit1:
	ret = fclose(f);
	if (ret != 0)
		err(DEBUG_CAT_QOS, "fclose fail\n");

exit:
	if (mscsbuf)
		os_free(mscsbuf);
	if (scsbuf)
		os_free(scsbuf);

	return ret;
}

int load_qos_config(void *context)
{
	FILE *f = NULL;
	int ret = STATUS_SUCCESS, buflen = 1024;
	char *buf = NULL;
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx *)context;

	if (!ctx)
		return STATUS_INVALID_POINTER;

	if (ctx->role != CONTROLLER) {
		err(DEBUG_CAT_QOS, "operation is valid only on controller.\n");
		return STATUS_CMD_NOT_SUPPORT;
	}

	/* write configuration to file. */
	f = fopen(QOS_CONF_PATH, "r");
	if (f == NULL) {
		err(DEBUG_CAT_QOS, "open config file failed.\n");
		ret = STATUS_CFG_NOT_EXISTED;
		goto exit;
	}

	buf = os_malloc(buflen);
	if (!buf) {
		err(DEBUG_CAT_QOS, "memory alloc fail\n");
		goto exit1;
	}

	while (fgets(buf, buflen, f)) {
		ret = set_qos_config(context, buf);
		if (ret != STATUS_SUCCESS)
			err(DEBUG_CAT_QOS, "set config(%s) failed, %s\n", buf, err2str(ret));
	}

	if (buf)
		os_free(buf);
exit1:

	ret = fclose(f);
	if (ret < 0)
		err(DEBUG_CAT_QOS, "close file fail\n");
exit:
	return ret;
}

int get_qos_error_code(void *context, char *reply_buf, int *reply_len)
{
	int ret = STATUS_UNKNOWN;
	char tmpbuf[100] = {};
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx *)context;

	if (!reply_buf || *reply_len == 0) {
		ret = snprintf(tmpbuf, sizeof(tmpbuf),
			"invalid reply_buf:%p or *reply_len:%d.\n", reply_buf, *reply_len);
		if (os_snprintf_error(sizeof(tmpbuf), ret))
			goto exit;
		err(DEBUG_CAT_QOS, "%s\n", tmpbuf);
		return STATUS_INVALID_POINTER;
	}

	if (!ctx) {
		ret = snprintf(tmpbuf, sizeof(tmpbuf), "ctx is NULL.\n");
		if (os_snprintf_error(sizeof(tmpbuf), ret))
			goto exit;
		ret = STATUS_INVALID_POINTER;
		goto exit1;
	}

	if (ctx->role != CONTROLLER) {
		ret = snprintf(tmpbuf, sizeof(tmpbuf), "command only available on controller.\n");
		if (os_snprintf_error(sizeof(tmpbuf), ret))
			goto exit;
		ret = STATUS_CMD_NOT_SUPPORT;
		goto exit1;
	}


	ret = snprintf(tmpbuf, sizeof(tmpbuf), "%s\n", err2str(ctx->qos_operation_errorcode));
	if (os_snprintf_error(sizeof(tmpbuf), ret))
		goto exit;

	ret = STATUS_SUCCESS;
exit1:
	if (os_strlen(tmpbuf) && (os_strlen(tmpbuf) < *reply_len)) {
		os_memcpy(reply_buf, tmpbuf, os_strlen(tmpbuf));
		*reply_len = os_strlen(tmpbuf);
	} else {
		err(DEBUG_CAT_QOS, "os_strlen(tmpbuf):%zu, *reply_len:%d\n", os_strlen(tmpbuf), *reply_len);
		ret = STATUS_INVALID_PARAM;
	}
exit:
	if (os_snprintf_error(sizeof(tmpbuf), ret)) {
		err(DEBUG_CAT_QOS, "memory over flow, ret = %d\n", ret);
		ret = STATUS_MEMORY_OVERFLOW;
	}

	return ret;
}

void recheck_and_apply_qos_config(void *context)
{
	int ret = STATUS_UNKNOWN;
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx *)context;
	struct mscs_cfg *pmscs = NULL;
	struct scs_cfg *pscs = NULL;
	unsigned char agentalmac[MAC_ADDR_LEN] = {0};

	if (!ctx) {
		err(DEBUG_CAT_QOS, "ctx is NULL.\n");
		return;
	}

	if (ctx->role != CONTROLLER)
		return;

	dl_list_for_each(pmscs, &ctx->mscs_list, struct mscs_cfg, list) {
		ret = get_associated_agent_almac(ctx, pmscs->sta_mac, agentalmac);
		if (ret != STATUS_SUCCESS) {
			memset(pmscs->agent_almac, 0, ETH_ALEN);
			continue;
		}
		if (!mac_addr_equal(agentalmac, pmscs->agent_almac)) {
			memcpy(pmscs->agent_almac, agentalmac, ETH_ALEN);
			apply_mscs_to_agent(ctx, pmscs);
		}
	}

	dl_list_for_each(pscs, &ctx->scs_list, struct scs_cfg, list) {
		ret = get_associated_agent_almac(ctx, pscs->sta_mac, agentalmac);
		if (ret != STATUS_SUCCESS) {
			memset(pscs->agent_almac, 0, ETH_ALEN);
			continue;
		}
		if (!mac_addr_equal(agentalmac, pscs->agent_almac)) {
			memcpy(pscs->agent_almac, agentalmac, ETH_ALEN);
			apply_scs_to_agent(ctx, pscs);
		}
	}
}

void show_qos_config(void *context)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx *)context;

	if (ctx->role != CONTROLLER) {
		warn(DEBUG_CAT_QOS, "command only available on controller.\n");
		return;
	}
	show_mscs_list(ctx);
	show_scs_list(ctx);
	show_qosmap_list(ctx);
	show_disallow_list(ctx);
}

#endif /* MAP_R5 */
