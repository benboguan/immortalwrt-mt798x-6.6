/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */
#include <stdio.h>
#include <string.h>
#include <linux/if_ether.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include "debug.h"
#include "p1905_managerd.h"
#include "common.h"

#define MAP_SO_BASE 1905

int get_receive_port_addr(unsigned char *brname, unsigned char *inputmac,unsigned char *outputmac)
{
	int fd = 0, ret = 0;
	int size = ETH_ALEN;
	unsigned char mac[ETH_ALEN] = {0};

	errno = 0;
	fd = socket(PF_INET, SOCK_RAW, IPPROTO_RAW);
	if (fd < 0) {
		err(DEBUG_CAT_MSG, "socket create fail; errno=%d(%s)\n",
			errno, strerror(errno));
		return -1;
	}
	memcpy(mac, inputmac, ETH_ALEN);
	errno = 0;
	ret = getsockopt(fd, IPPROTO_IP, MAP_SO_BASE, mac, (socklen_t *)&size);
	if (ret < 0) {
		err(DEBUG_CAT_MSG, "getsockopt fail; ret=%d; errno=%d(%s)\n",
			ret, errno, strerror(errno));
		close(fd);
		return -1;
	}
	close(fd);

	memcpy(outputmac, mac, ETH_ALEN);

	return 0;
}

int set_opt_not_forward_dest(unsigned char *inputmac)
{
	int fd = 0, ret = 0;
	int size = ETH_ALEN;
	unsigned char mac[ETH_ALEN] = {0};

	errno = 0;
	fd = socket(PF_INET, SOCK_RAW, IPPROTO_RAW);
	if (fd < 0) {
		err(DEBUG_CAT_INIT, "fail to create socket; errno=%d(%s)\n",
			errno, strerror(errno));
		return -1;
	}
	memcpy(mac, inputmac, ETH_ALEN);

	errno = 0;
	ret = setsockopt(fd, IPPROTO_IP, MAP_SO_BASE, mac, (socklen_t)size);
	close(fd);

	if (ret < 0) {
		err(DEBUG_CAT_INIT, "fail to setsockopt; errno=%d(%s)\n",
			errno, strerror(errno));
		return -1;
	}

	notice(DEBUG_CAT_INIT, "do not forward mac("MACSTR") in bridge\n", MAC2STR(mac));

	return 0;
}

char mac_to_string(unsigned char *mac, char *mac_str, unsigned char size)
{
	static char hex[] = {'0', '1', '2', '3', '4',
		'5', '6', '7', '8', '9', 'a', 'b',
		'c', 'd', 'e', 'f'};
	unsigned char i, p = 0;

	if (!mac || !mac_str)
		return -1;

	for (i = 0; i < size; i++) {
		mac_str[p++] = hex[(mac[i] >> 4) & 0x0f];
		mac_str[p++] = hex[mac[i] & 0x0f];
		mac_str[p++] = (i < (size - 1)) ? ':' : '\0';
	}

	return 0;
}

void ebtables_insert(const char *mac_str)
{
	if (os_execute("ebtables", 11, "-t", "broute", "-I", "BROUTING", "1",
			"-p", "0x893a", "-d", mac_str, "-j", "DROP") < 0)
		err(DEBUG_CAT_INIT, "os_execute cmd fail\n");
}

void ebtables_delete_insert(const char *mac_str)
{
	if (os_execute("ebtables", 10, "-t", "broute", "-D", "BROUTING", "-p",
			"0x893a", "-d", mac_str, "-j", "DROP") < 0)
		err(DEBUG_CAT_INIT, "os_execute cmd fail\n");
}

int forbid_almac_and_multicast_forward(struct p1905_managerd_ctx *ctx)
{
	char mac_str[18] = {0};

	if (!ctx)
		return -1;

	mac_to_string(ctx->p1905_al_mac_addr, mac_str, 6);

	ebtables_delete_insert("01:80:c2:00:00:13");
	ebtables_delete_insert(mac_str);

	ebtables_insert("01:80:c2:00:00:13");
	ebtables_insert(mac_str);

	return 0;
}

int clear_forward_rule(struct p1905_managerd_ctx *ctx)
{
	char mac_str[18] = {0};

	if (!ctx)
		return -1;

	mac_to_string(ctx->p1905_al_mac_addr, mac_str, 6);
	ebtables_delete_insert("01:80:c2:00:00:13");
	ebtables_delete_insert(mac_str);

	return 0;
}

