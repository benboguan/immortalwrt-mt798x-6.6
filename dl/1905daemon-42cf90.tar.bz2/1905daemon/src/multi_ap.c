/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#include <stdio.h>
#include <string.h>
#include <syslog.h>
#include <assert.h>
#include <linux/if_ether.h>
#include <asm/byteorder.h>
#include <stdlib.h>
#include <pthread.h>
#include <regex.h>
#include <linux/sockios.h>

#include <sys/socket.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <linux/ethtool.h>

#include "common.h"
#include "multi_ap.h"
#include "cmdu.h"
#include "cmdu_tlv_parse.h"
#include "cmdu_tlv.h"
#include "debug.h"
#include "_1905_lib_io.h"
#include "file_io.h"
#include "message_wait_queue.h"
#include "topology.h"
#include "eloop.h"
#include "mapfilter_if.h"
#include "ethernet_layer.h"
#include "lldp.h"
#include "_1905_lib_internal.h"
#include "_1905_interface.h"
#include "p1905_utils.h"
#ifdef MAP_R3
#include "security_engine.h"
#include "json.h"
#include "wpabuf.h"
#include "wpa_extern.h"
#endif
#ifdef MAP_R5
#include "qos.h"
#endif
#ifdef EM_PLUS_SUPPORT
#include "emplus.h"
#endif
#include "_1905_interface_ctrl.h"

#ifdef MAP_R3
static unsigned char OUI_WPA2_AKM_PSK[4] = {0x00, 0x0F, 0xAC, 0x02};
static unsigned char OUI_WPA2_AKM_FT_PSK[4] = {0x00, 0x0F, 0xAC, 0x04};
static unsigned char OUI_WPA2_AKM_PSK_SHA256[4] = {0x00, 0x0F, 0xAC, 0x06};
static unsigned char OUI_WPA2_AKM_SAE_SHA256[4] = {0x00, 0x0F, 0xAC, 0x08};
static unsigned char OUI_WPA2_AKM_FT_SAE_SHA256[4] = {0x00, 0x0F, 0xAC, 0x09};
static unsigned char OUI_AKM_DPP[4] = {0x50, 0x6F, 0x9A, 0x02};
#endif


static unsigned char p1905_multicast_address[6]
	= { 0x01, 0x80, 0xc2, 0x00, 0x00, 0x13 };
unsigned char dev_send_1905_buf[3072*2] = {0};

struct global_oper_class
{
	unsigned char opclass;			/* regulatory class */
	unsigned char channel_num;
	unsigned char channel_set[59];	/* max 59 channels, use 0 as terminator */
};

/*Global operating classes*/
 struct global_oper_class oper_class[] = {
	{0, 0, {0}},			/* Invlid entry */
	{81, 13, {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13}},
	{82, 1, {14}},
	{83, 9, {1, 2, 3, 4, 5, 6, 7, 8, 9}},
	{84, 9, {5, 6, 7, 8, 9, 10, 11, 12, 13}},
	{94, 2, {133, 137}},
	{95, 4, {132, 134, 136, 138}},
	{96, 8, {131, 132, 133, 134, 135, 136, 137, 138}},
	{101, 2, {21, 25}},
	{102, 5, {11, 13, 15, 17, 19}},
	{103, 10, {1, 2, 3, 4, 5, 6, 7, 8, 9, 10}},
	{104, 2, {184, 192}},
	{105, 2, {188, 196}},
	{106, 2, {191, 195}},
	{107, 5, {189, 191, 193, 195, 197}},
	{108, 10, {188, 189, 190, 191, 192, 193, 194, 195, 196, 197}},
	{109, 4, {184, 188, 192, 196}},
	{110, 7, {183, 184, 185, 186, 187, 188, 189}},
	{111, 8, {182, 183, 184, 185, 186, 187, 188, 189}},
	{112, 3, {8, 12, 16}},
	{113, 5, {7, 8, 9, 10, 11}},
	{114, 6, {6, 7, 8, 9, 10, 11}},
	{115, 4, {36, 40, 44, 48} },
	{116, 2, {36, 44}},
	{117, 2, {40, 48}},
	{118, 4, {52, 56, 60, 64}},
	{119, 2, {52, 60}},
	{120, 2, {56, 64}},
	{121, 12, {100, 104, 108, 112, 116, 120, 124, 128, 132, 136, 140, 144}},
	{122, 6, {100, 108, 116, 124, 132, 140}},
	{123, 6, {104, 112, 120, 128, 136, 144}},
	{124, 4, {149, 153, 157, 161}},
	{125, 8, {149, 153, 157, 161, 165, 169, 173, 177}},
	{126, 4, {149, 157, 165, 173}},
	{127, 4, {153, 161, 169, 177}},
	{128, 7, {42, 58, 106, 122, 138, 155, 171}},
	{129, 3, {50, 114, 163}},
	{130, 7, {42, 58, 106, 122, 138, 155, 171}},
	{131, 59, {1, 5, 9, 13, 17, 21, 25, 29, 33, 37,
				41, 45, 49, 53, 57, 61, 65, 69, 73, 77,
				81, 85, 89, 93, 97, 101, 105, 109, 113, 117,
				121, 125, 129, 133, 137, 141, 145, 149, 153, 157,
				161, 165, 169, 173, 177, 181, 185, 189, 193, 197,
				201, 205, 209, 213, 217, 221, 225, 229, 233}},
	{132, 29, {3, 11, 19, 27, 35, 43, 51, 59, 67, 75,
				83, 91, 99, 107, 115, 123, 131, 139, 147, 155,
				163, 171, 179, 187, 195, 203, 211, 219, 227}},
	{133, 14, {7, 23, 39, 55, 71, 87, 103, 119, 135, 151, 167, 183, 199, 215}},
	{134, 7, {15, 47, 79, 111, 143, 175, 207}},
	{135, 14, {7, 23, 39, 55, 71, 87, 103, 119, 135, 151, 167, 183, 199, 215}},
	{137, 6, {31, 63, 95, 127, 159, 191} },
	{0, 0, {0}}			/* end */
};

unsigned char opclass_2g[] = {
	81, 82, 83, 84, 101, 102, 103, 112, 113, 114, 0
};

unsigned char opclass_5gh[] = {
	94, 95, 96, 104, 105, 106, 107, 108, 109, 110, 111, 121, 122,
	123, 124, 125, 126, 127, 0
};

unsigned char opclass_5gl[] = {
	115, 116, 117, 118, 119, 120, 0
};


/**
 *  get cmdu message version from header.
 *
 * \param  buf  input, cmdu message header start address
 * \retun  cmdu message version
 */
unsigned char get_mversion_from_msg_hdr(unsigned char *buf)
{
	return *buf;
}

/**
 *  get cmdu message type from header.
 *
 * \param  buf  input, cmdu message header start address
 * \retun  cmdu message type
 */
unsigned short get_mtype_from_msg_hdr(unsigned char *buf)
{
	unsigned short mtype = 0;

	mtype = *(unsigned short *)(buf + 2);
	mtype = be_to_host16(mtype);

	return mtype;
}

/**
 *  get cmdu message type string from header.
 *
 * \param  buf  input, cmdu message header start address
 * \retun  cmdu message type string
 */
char *get_mtype_str_from_msg_hdr(unsigned char *buf)
{
	static char str[64];
	unsigned short mtype = get_mtype_from_msg_hdr(buf);
	(void)snprintf((char *)str, sizeof(str), "Unknown:%04x", mtype);
	switch (mtype) {
	case TOPOLOGY_DISCOVERY:
		return "Topology Discovery";
	case TOPOLOGY_NOTIFICATION:
		return "Topology Notification";
	case TOPOLOGY_QUERY:
		return "Topology Query";
	case TOPOLOGY_RESPONSE:
		return "Topology Response";
	case VENDOR_SPECIFIC:
		return "Vendor Specific";
	case LINK_METRICS_QUERY:
		return "Link Metric Query";
	case LINK_METRICS_RESPONSE:
		return "Link Metric Response";
	case AP_AUTOCONFIG_SEARCH:
		return "AP-autoconfiguration Search";
	case AP_AUTOCONFIG_RESPONSE:
		return "AP-autoconfiguration Response";
	case AP_AUTOCONFIG_WSC:
		return "AP-autoconfiguration WSC";
	case AP_AUTOCONFIG_RENEW:
		return "AP-autoconfiguration Renew";
	case P1905_PB_EVENT_NOTIFY:
		return "1905.1 Push Button Event";
	case P1905_PB_JOIN_NOTIFY:
		return "1905.1 Push Button Join Notification";
	default:
		return str;
	}
}

/**
 *  get cmdu message id from header.
 *
 * \param  buf  input, cmdu message header start address
 * \retun  cmdu message id
 */
unsigned short get_mid_from_msg_hdr(unsigned char *buf)
{
	unsigned short mid = 0;

	mid = *(unsigned short *)(buf + 4);
	mid = be_to_host16(mid);

	return mid;
}

/**
 *  get cmdu fragment id from header.
 *
 * \param  buf  input, cmdu message header start address
 * \retun  cmdu fragment id
 */
unsigned char get_fid_from_msg_hdr(unsigned char *buf)
{
	return *(buf + 6);
}

/**
 *  get cmdu last fragment ind from header.
 *
 * \param  buf  input, cmdu message header start address
 * \retun  cmdu last fragment ind
 */
unsigned char get_last_fragment_ind_from_msg_hdr(unsigned char *buf)
{
	if (((*(buf + 7)) & 0x80) == 0x80)
		return 1;
	else
		return 0;
}

/**
 *  get cmdu relay ind from header.
 *
 * \param  buf  input, cmdu message header start address
 * \retun  cmdu relay ind
 */
unsigned char get_relay_ind_from_msg_hdr(unsigned char *buf)
{
	if (((*(buf + 7)) & 0x40) == 0x40)
		return 1;
	else
		return 0;
}

/**
 *  check whether receive a relay multicast message
 *
 *
 * \param  relay_ind  input, get from relay ind field of message header
 * \param  mtype  input, get from message type field og message header
 * \return -1: error  0: relay message
 */
int check_relay_message(unsigned char relay_ind, unsigned short mtype)
{
	if (relay_ind) {
		if ((mtype != TOPOLOGY_NOTIFICATION) && (mtype != VENDOR_SPECIFIC) &&
		    (mtype != AP_AUTOCONFIG_SEARCH) && (mtype != AP_AUTOCONFIG_RENEW) &&
		    (mtype != P1905_PB_EVENT_NOTIFY) && (mtype != P1905_PB_JOIN_NOTIFY)) {
			return -1;
		}
	}
	return 0;
}


int check_recv_mid(struct p1905_managerd_ctx *ctx, unsigned char *salmac, unsigned short mid, unsigned short mtype)
{
	struct topology_device_db *tpdev_db = NULL, *exist_tpdev_db = NULL;
	unsigned short i = 0;

	if ((mtype == TOPOLOGY_RESPONSE) || (mtype == LINK_METRICS_RESPONSE) ||
		(mtype == AP_AUTOCONFIG_RESPONSE) || (mtype == AP_CAPABILITY_REPORT) ||
		(mtype == CHANNEL_PREFERENCE_REPORT) || (mtype == CHANNEL_SELECTION_RESPONSE) ||
		(mtype == CLIENT_CAPABILITY_REPORT) || (mtype == AP_LINK_METRICS_RESPONSE) ||
		(mtype == ASSOC_STA_LINK_METRICS_RESPONSE) || (mtype == Ack_1905)) {
		return 0;
	}

	if (!SLIST_EMPTY(&ctx->topodev_entry.tpdevdb_head)) {
		SLIST_FOREACH(tpdev_db, &ctx->topodev_entry.tpdevdb_head, tpdev_entry) {
			if (!memcmp(tpdev_db->aldev_mac, salmac, ETH_ALEN)) {
				exist_tpdev_db = tpdev_db;
				break;
			}
		}
	}
	if (!exist_tpdev_db) {
		exist_tpdev_db = (struct topology_device_db *)malloc(sizeof(struct topology_device_db));
		if (exist_tpdev_db == NULL) {
			err(DEBUG_CAT_MISC, "alloc struct topology_device_db fail\n");
			return -1;
		}
		memset(exist_tpdev_db, 0, sizeof(struct topology_device_db));
		memcpy(exist_tpdev_db->aldev_mac, salmac, ETH_ALEN);
		exist_tpdev_db->time_to_live = TOPOLOGY_DEVICE_TTL;
		exist_tpdev_db->mid_list[0] = mid;
		exist_tpdev_db->mid_set = 0;
		exist_tpdev_db->recv_mid = mid;
		SLIST_INSERT_HEAD(&ctx->topodev_entry.tpdevdb_head, exist_tpdev_db, tpdev_entry);
	} else {
		for (i = 0; i < MAX_MID_QUEUE; i++) {
			if (mid == exist_tpdev_db->mid_list[i]) {
				if (mtype == TOPOLOGY_DISCOVERY)
					debug(DEBUG_CAT_MSG,
					    "duplicate msg on dev("MACSTR"); mid(%04x); msgtype=0x%04x(%s)\n",
					    MAC2STR(salmac), mid, mtype, get_1905_mtype_str(mtype));
				else
					notice(DEBUG_CAT_MSG,
					    "duplicate msg on dev("MACSTR"); mid(%04x); msgtype=0x%04x(%s)\n",
					    MAC2STR(salmac), mid, mtype, get_1905_mtype_str(mtype));
				return -1;
			}
		}
		exist_tpdev_db->time_to_live = TOPOLOGY_DEVICE_TTL;
		exist_tpdev_db->recv_mid = mid;
		exist_tpdev_db->mid_set++;
		if (exist_tpdev_db->mid_set == MAX_MID_QUEUE)
			exist_tpdev_db->mid_set = 0;
		exist_tpdev_db->mid_list[exist_tpdev_db->mid_set] = mid;
	}

	return 0;
}

void relay_fragment_send(struct p1905_managerd_ctx *ctx,
			 unsigned char *tlv, unsigned int tlv_len, unsigned char *eth_hdr, unsigned char *almac)
{
	unsigned short msg_len = 0;
	unsigned char *msg = NULL;
	unsigned int i = 0;

	msg_len = ETH_HLEN + CMDU_HLEN + tlv_len;
	msg = (unsigned char *)malloc(msg_len);
	if (!msg) {
		err(DEBUG_CAT_MISC, "allco msg fail\n");
		return;
	}

	memcpy(msg, eth_hdr, (ETH_HLEN + CMDU_HLEN));
	memcpy((msg + ETH_ALEN), almac, ETH_ALEN);
	memcpy((msg + ETH_ALEN + CMDU_HLEN), tlv, tlv_len);

	for (i = 0; i < ctx->itf_number; i++) {
		/*do not relay to original receive interface */
		if (i != ctx->recent_cmdu_rx_if_number) {
			if (tlv_len > MAX_TLVS_LENGTH) {
				if (0 > cmdu_tx_fragment(ctx, msg, msg_len, ctx->itf[i].if_name)) {
					err(DEBUG_CAT_MSG, "fragment cmdu send fail\n");
					free(msg);
					return;
				}
			}
		}
	}

	free(msg);
}


int set_bss_config_priority_by_str(struct p1905_managerd_ctx *ctx)
{
	char *token = NULL, *prio_str = NULL;
	size_t prio_str_len = 0;
	unsigned char priority = 1, i = 0;

	prio_str_len = os_strlen(ctx->bss_priority_str);
	prio_str = os_malloc(prio_str_len + 1);
	if (prio_str == NULL) {
		err(DEBUG_CAT_MISC, "alloc prio_str fail\n");
		return -1;
	}
	memset(prio_str, 0, prio_str_len + 1);
	os_memcpy(prio_str, ctx->bss_priority_str, prio_str_len);

	token = strtok(prio_str, ";");
	while (token != NULL) {
		for (i = 0; i < ctx->itf_number; i++) {
			if (os_strcmp((char *)ctx->itf[i].if_name, token) == 0) {
				ctx->itf[i].config_priority = priority;
				break;
			}
		}
		if (i >= ctx->itf_number)
			info(DEBUG_CAT_AUTOCONF, "bss intf(%s) not exist in local interface\n", token);
		token = strtok(NULL, ";");
		priority++;
	}
	os_free(prio_str);

	return 0;
}

void update_radio_bss_priority(struct p1905_managerd_ctx *ctx)
{
	int i = 0, j = 0, k = 0;

	for (i = 0; i < ctx->radio_number; i++) {
		for (j = 0; j < ctx->rinfo[i].bss_number; j++) {
			for (k = 0; k < ctx->itf_number; k++) {
				if (!os_memcmp(ctx->rinfo[i].identifier,
					ctx->itf[k].identifier, ETH_ALEN) &&
					!os_memcmp((char *)ctx->rinfo[i].bss[j].mac,
					ctx->itf[k].mac_addr, ETH_ALEN)) {
					ctx->rinfo[i].bss[j].priority = ctx->itf[k].config_priority;
				}
			}
		}
	}
}

int fill_send_tlv(struct p1905_managerd_ctx* ctx, unsigned char* buf, unsigned short len)
{
	if (len >= sizeof(ctx->send_tlv)) {
		err(DEBUG_CAT_MSG, "send tlv len(%d) > ctx->send_tlv len(%zu)",
			len, sizeof(ctx->send_tlv));
		return -1;
	}

	if (ctx->send_tlv_len != 0)
		notice(DEBUG_ERROR, "receive new send tlv, replace old one(%lu)\n", ctx->send_tlv_cookie);

	ctx->send_tlv_cookie = os_random();
	debug(DEBUG_CAT_MSG, "send_tlv_cookie=%ld, len=%d\n", ctx->send_tlv_cookie, len);
	memcpy(ctx->send_tlv, buf, len);
	ctx->send_tlv_len = len;

	return 0;
}

int reset_send_tlv(struct p1905_managerd_ctx *ctx)
{
	ctx->send_tlv_len = 0;
	return 0;
}

void reset_stored_tlv(struct p1905_managerd_ctx *ctx)
{
	ctx->revd_tlv.buf_len = 0;
}

int store_revd_tlvs(struct p1905_managerd_ctx* ctx, unsigned char *revd_buf, unsigned short len)
{
	if ((ctx->revd_tlv.buf_len + len) > 10240) {
		err(DEBUG_CAT_MSG, "total revd_tlv len > 10240\n");
		return -1;
	} else {
		memcpy(ctx->revd_tlv.buf + ctx->revd_tlv.buf_len, revd_buf, len);
		ctx->revd_tlv.buf_len += len;
		return 0;
	}
}
int get_tlv_len_by_tlvtype(unsigned char *ptlvtype)
{
	unsigned short tlvlen;

	/*jump to tlv len field*/
	tlvlen = *(unsigned short *)(ptlvtype + 1);
	/*endian change*/
	tlvlen = be_to_host16(tlvlen);
	/*add byte of tlytyle & tlvlength*/
	tlvlen += 3;

	return tlvlen;
}

struct radio_info *get_rainfo_by_id(struct p1905_managerd_ctx *ctx, unsigned char* identifier)
{
	int i = 0;

	for (i = 0; i < ctx->radio_number; i++) {
		if (!os_memcmp(ctx->rinfo[i].identifier, identifier, ETH_ALEN))
			return &ctx->rinfo[i];
	}

	return NULL;
}

int delete_exist_radio_basic_capability(
	struct p1905_managerd_ctx *ctx, unsigned char* identifier)
{
	struct radio_info *r = NULL;
	struct operating_class *opc = NULL, *opc_tmp = NULL;

	r = get_rainfo_by_id(ctx, identifier);

	if (!r) {
		err(DEBUG_CAT_EVENT, "radio not found by "MACSTR"\n", MAC2STR(identifier));
		return -1;
	}

	if (!dl_list_empty(&r->basic_cap.op_class_list) && r->basic_cap.op_class_num) {
		dl_list_for_each_safe(opc, opc_tmp, &r->basic_cap.op_class_list, struct operating_class, entry) {
			dl_list_del(&opc->entry);
			os_free(opc);
		}
	}

	r->basic_cap.max_bss_num = 0;
	r->basic_cap.op_class_num = 0;
	dl_list_init(&r->basic_cap.op_class_list);

	return 0;
}

int update_radio_basic_capability(struct p1905_managerd_ctx *ctx, struct ap_radio_basic_cap *bcap,
	unsigned short cap_len)
{
	struct radio_info *r = NULL;
	unsigned char i = 0;
	struct operating_class *opc = NULL;

	/*check bcap and its length*/
	if (cap_len != sizeof(struct ap_radio_basic_cap) +
		bcap->op_class_num * sizeof(struct radio_basic_cap)) {
		err(DEBUG_CAT_EVENT, "cap_len(%d) != real length(%u)\n",
			cap_len, (unsigned int)(sizeof(struct ap_radio_basic_cap) +
			bcap->op_class_num * sizeof(struct radio_basic_cap)));
		return -1;
	}

	r = get_rainfo_by_id(ctx, bcap->identifier);
	if (!r) {
		err(DEBUG_CAT_EVENT, "radio not found by "MACSTR"\n", MAC2STR(bcap->identifier));
		return -1;
	}

	r->band = 0;
	r->basic_cap.max_bss_num = bcap->max_bss_num;
	r->basic_cap.op_class_num = bcap->op_class_num;
	for (i = 0; i < bcap->op_class_num; i++) {
		opc = (struct operating_class *)os_zalloc(sizeof(struct operating_class));

		if (!opc) {
			err(DEBUG_CAT_MISC, "alloc struct operating_class fail\n");
			continue;
		}
		opc->class_number = bcap->opcap[i].op_class;
		opc->max_tx_pwr = bcap->opcap[i].max_tx_pwr;
		opc->non_operch_num = bcap->opcap[i].non_operch_num;
		os_memcpy(opc->non_operch_list, bcap->opcap[i].non_operch_list, MAX_CH_NUM);
		dl_list_add_tail(&r->basic_cap.op_class_list, &opc->entry);

		r->band |= get_bandcap(ctx, opc->class_number, opc->non_operch_num, opc->non_operch_list);
	}

	info(DEBUG_CAT_AUTOCONF, "the band_cap for radio "MACSTR" is 0x%02x(%s)\n",
		MAC2STR(r->identifier), r->band, get_band_cap_str(r->band));

	return 0;

}

int delete_exist_operational_bss(
	struct p1905_managerd_ctx *ctx, unsigned char *identifier)
{
	 struct operational_bss_db *opcap = NULL;
	 struct op_bss_db *opbss = NULL, *opbss_tmp = NULL;

	SLIST_FOREACH(opcap, &(ctx->ap_cap_entry.oper_bss_head), oper_bss_entry) {
		if (!memcmp(opcap->identifier, identifier, ETH_ALEN)) {
			if (!SLIST_EMPTY(&(opcap->op_bss_head))) {
				opbss = SLIST_FIRST(&(opcap->op_bss_head));
				while (opbss) {
					opbss_tmp = SLIST_NEXT(opbss, op_bss_entry);
					SLIST_REMOVE(&(opcap->op_bss_head), opbss,
								op_bss_db, op_bss_entry);
					free(opbss);
					opbss = opbss_tmp;
				}
			}
			opcap->oper_bss_num = 0;
			break;
		}
	}

	return wapp_utils_success;
}

int delete_exist_operational_bss_by_mac(
	struct p1905_managerd_ctx *ctx, unsigned char *identifier, unsigned char *bssid)
{
	struct operational_bss_db *opcap = NULL;
	struct op_bss_db *opbss = NULL, *opbss_tmp = NULL;

	SLIST_FOREACH(opcap, &(ctx->ap_cap_entry.oper_bss_head), oper_bss_entry) {
		if (!memcmp(opcap->identifier, identifier, ETH_ALEN)) {
			if (!SLIST_EMPTY(&(opcap->op_bss_head))) {
				opbss = SLIST_FIRST(&(opcap->op_bss_head));
				while (opbss) {
					opbss_tmp = SLIST_NEXT(opbss, op_bss_entry);
					info(DEBUG_CAT_EVENT, "opbss->bssid "MACSTR"\n", MAC2STR(opbss->bssid));
					if (!memcmp(opbss->bssid, bssid, ETH_ALEN)) {
						SLIST_REMOVE(&(opcap->op_bss_head), opbss,
									op_bss_db, op_bss_entry);
						notice(DEBUG_CAT_INIT, DYN_INTF_PREX" del op info "MACSTR"\n",
							MAC2STR(bssid));
						free(opbss);
						opcap->oper_bss_num--;
						return wapp_utils_success;
					}
					opbss = opbss_tmp;
				}
			}
		}
	}

	return wapp_utils_error;
}

int check_sta_in_oper_bss(struct list_head_oper_bss *opbss_head,
		struct map_client_association_event *assc_evt
#ifdef MAP_R6
		, struct mld_bss_config_db *mld_cfg
#endif

	)
{
	struct op_bss_db *bss_info = NULL;
	struct operational_bss_db *operbss_info = NULL;
#ifdef MAP_R6
	struct mlo_config_db *mlo_cfg = NULL, *mlo_cfg_tmp = NULL;
#endif

	SLIST_FOREACH(operbss_info, opbss_head, oper_bss_entry) {
		SLIST_FOREACH(bss_info, &operbss_info->op_bss_head, op_bss_entry)
		{
			if (!memcmp(bss_info->bssid, assc_evt->bssid, ETH_ALEN))
				return 0;
		}
	}

#ifdef MAP_R6
	info(DEBUG_CAT_MLO, "assoc bssid "MACSTR"\n", MAC2STR(assc_evt->bssid));
	dl_list_for_each_safe(mlo_cfg, mlo_cfg_tmp, &mld_cfg->mlo_cfg_list, struct mlo_config_db, list) {
		info(DEBUG_CAT_MLO, "mld_mac "MACSTR"\n", MAC2STR(mlo_cfg->mld_mac));
		if (!os_memcmp(mlo_cfg->mld_mac, assc_evt->bssid, ETH_ALEN))
			return 0;
	}
#endif
	return -1;
}



int insert_new_operational_bss(
	struct p1905_managerd_ctx *ctx, struct oper_bss_cap *opcap)
{
	struct op_bss_cap *opbss_cap = NULL;
	struct operational_bss_db *opcap_db = NULL;
	struct op_bss_db *opbss_db = NULL;
	int oper_bss_num = 0;
	int i = 0;
#ifdef MAP_R2
	struct operational_bss *bss = NULL;
#endif

	SLIST_FOREACH(opcap_db, &ctx->ap_cap_entry.oper_bss_head, oper_bss_entry)
    {
		if (!memcmp(opcap_db->identifier, opcap->identifier, ETH_ALEN))
			break;
    }

	if (!opcap_db) {
		opcap_db = (struct operational_bss_db *)malloc(sizeof(struct operational_bss_db));
		if (!opcap_db) {
			err(DEBUG_CAT_MISC, "alloc struct operational_bss_db fail\n");
			return wapp_utils_error;
		}
		memcpy(opcap_db->identifier, opcap->identifier, ETH_ALEN);
		SLIST_INSERT_HEAD(&ctx->ap_cap_entry.oper_bss_head, opcap_db, oper_bss_entry);
	}

	opcap_db->oper_bss_num = opcap->oper_bss_num;
	opcap_db->band = opcap->band;

	SLIST_INIT(&(opcap_db->op_bss_head));
	oper_bss_num = opcap_db->oper_bss_num;
	for(i = 0; i < oper_bss_num; i++) {
		opbss_cap = &opcap->cap[i];
		opbss_db = (struct op_bss_db *)malloc(sizeof(*opbss_db));
		if (!opbss_db) {
			err(DEBUG_CAT_MISC, "alloc struct op_bss_db fail\n");
			return wapp_utils_error;
		}
		memset(opbss_db, 0, sizeof(*opbss_db));
		memcpy(opbss_db->bssid, opbss_cap->bssid, ETH_ALEN);
		opbss_db->ssid_len = opbss_cap->ssid_len;
		(void)snprintf((char *)opbss_db->ssid, sizeof(opbss_db->ssid), "%s", opbss_cap->ssid);
#ifdef MTK_MLO_MAP_SUPPORT
		opbss_db->mlo_info.mld_idx = opbss_cap->mlo_info.mld_idx;
		memcpy(opbss_db->mlo_info.mld_addr, opbss_cap->mlo_info.mld_addr, ETH_ALEN);
		info(DEBUG_CAT_MLO, "mld_idx-%d mld_addr("MACSTR")\n",
			opbss_db->mlo_info.mld_idx,
			PRINT_MAC(opbss_db->mlo_info.mld_addr));
#endif
#ifdef MAP_R6
		opbss_db->mlo_info.link_id = opbss_cap->mlo_info.link_id;
		opbss_db->mlo_info.ap_str_support = opbss_cap->mlo_info.ap_str_support;
		opbss_db->mlo_info.ap_nstr_support = opbss_cap->mlo_info.ap_nstr_support;
		opbss_db->mlo_info.ap_emlsr_support = opbss_cap->mlo_info.ap_emlsr_support;
		opbss_db->mlo_info.ap_emlmr_support = opbss_cap->mlo_info.ap_emlmr_support;
		info(DEBUG_CAT_MLO, "link_id-%d ap_str_support-%d, ap_nstr_support-%d, ap_emlsr_support-%d, ap_emlmr_support-%d\n",
			opbss_db->mlo_info.link_id, opbss_db->mlo_info.ap_str_support,
			opbss_db->mlo_info.ap_nstr_support, opbss_db->mlo_info.ap_emlsr_support,
			opbss_db->mlo_info.ap_emlmr_support);
#endif
		SLIST_INSERT_HEAD(&opcap_db->op_bss_head, opbss_db, op_bss_entry);
#ifdef MAP_R2
		bss = get_bss_by_bssid(ctx, opbss_cap->bssid);
		if (!bss) {
			bss = create_oper_bss(ctx, opbss_cap->bssid, (char *)opbss_cap->ssid, opbss_db->ssid_len,
				ctx->p1905_al_mac_addr, &ctx->bss_head);
			if (!bss) {
				err(DEBUG_CAT_MISC, "alloc struct operational_bss fail\n");
				continue;
			}

		} else {
			if (os_strncmp(bss->ssid, (char *)opbss_cap->ssid, opbss_db->ssid_len) ||
				opbss_db->ssid_len != os_strlen(bss->ssid)) {
				os_memset(bss->ssid, 0, sizeof(bss->ssid));
				os_strncpy(bss->ssid, (char *)opbss_cap->ssid, opbss_db->ssid_len);
			}
		}
#endif
	}

#ifdef MAP_R2
	update_operation_bss_vlan(ctx, &ctx->bss_head, &ctx->map_policy.tpolicy,
		ctx->p1905_al_mac_addr);
#endif
	return wapp_utils_success;

}

void delete_legacy_assoc_clients_db(struct p1905_managerd_ctx *ctx)
{
	struct associated_clients_db *assoc_cli_db = NULL, *assoc_cli_db_tmp = NULL;
	struct operational_bss_db *opcap_db = NULL;
	struct op_bss_db *bss_info = NULL;
	struct clients_db *cli_db = NULL, *cli_db_tmp = NULL;
	char bss_find = 0;

	assoc_cli_db = SLIST_FIRST(&ctx->ap_cap_entry.assoc_clients_head);
	while (assoc_cli_db) {
		bss_find = 0;
		assoc_cli_db_tmp = SLIST_NEXT(assoc_cli_db, assoc_clients_entry);
		SLIST_FOREACH(opcap_db, &ctx->ap_cap_entry.oper_bss_head, oper_bss_entry) {
			SLIST_FOREACH(bss_info, &opcap_db->op_bss_head, op_bss_entry) {
				if (!os_memcmp(bss_info->bssid, assoc_cli_db->bssid, ETH_ALEN)) {
					bss_find = 1;
					break;
				}
			}
			if (bss_find)
				break;
		}
		if (!bss_find) {
			SLIST_REMOVE(&ctx->ap_cap_entry.assoc_clients_head, assoc_cli_db,
			associated_clients_db, assoc_clients_entry);
			cli_db = SLIST_FIRST(&assoc_cli_db->clients_head);
			while (cli_db != NULL) {
				cli_db_tmp = SLIST_NEXT(cli_db, clients_entry);
				os_free(cli_db);
				cli_db = cli_db_tmp;
			}
			os_free(assoc_cli_db);
		}
		assoc_cli_db = assoc_cli_db_tmp;
	}
}

int update_assoc_sta_info(struct p1905_managerd_ctx *ctx,
	struct map_client_association_event *cinfo)
{
	struct associated_clients_db *bss_db = NULL;
	struct associated_clients_db *bss_db_tmp = NULL;
	struct clients_db *sta_db = NULL;
	struct os_reltime assoc_time;

	SLIST_FOREACH(bss_db, &(ctx->ap_cap_entry.assoc_clients_head), assoc_clients_entry)
	{
		if (!memcmp(bss_db->bssid, cinfo->bssid, ETH_ALEN))
			break;
	}
	if (bss_db == NULL) {
		bss_db = (struct associated_clients_db*)malloc(sizeof(struct associated_clients_db));
		if (bss_db == NULL) {
			err(DEBUG_CAT_MISC, "alloc struct associated_clients_db fail\n");
			return -1;
		}
		memset(bss_db, 0, sizeof(struct associated_clients_db));
		memcpy(bss_db->bssid, cinfo->bssid, ETH_ALEN);
		SLIST_INIT(&(bss_db->clients_head));
		SLIST_INSERT_HEAD(&(ctx->ap_cap_entry.assoc_clients_head), bss_db, assoc_clients_entry);
	}
	bss_db_tmp = bss_db;
	bss_db = NULL;

	SLIST_FOREACH(bss_db, &(ctx->ap_cap_entry.assoc_clients_head), assoc_clients_entry)
	{
		if (os_memcmp(bss_db->bssid, cinfo->bssid, ETH_ALEN))
			continue;
		SLIST_FOREACH(sta_db, &(bss_db->clients_head), clients_entry)
		{
			if (!memcmp(sta_db->mac, cinfo->sta_mac, ETH_ALEN)) {
				/*free all stainfo for assoc req frame len may be different*/
				SLIST_REMOVE(&(bss_db->clients_head), sta_db, clients_db, clients_entry);
				free(sta_db);
				bss_db->assco_clients_num--;
				break;
			}
		}
	}

	/*station connect to bss*/
	if (cinfo->assoc_evt == 0x80) {
		sta_db = (struct clients_db *)malloc(sizeof(struct clients_db) + cinfo->assoc_req_len);
		if (!sta_db) {
			err(DEBUG_CAT_MISC, "alloc struct clients_db fail\n");
			return -1;
		}
		os_get_reltime(&assoc_time);
		cinfo->assoc_time = assoc_time.sec;

		memcpy(sta_db->mac, cinfo->sta_mac, ETH_ALEN);
		sta_db->time = cinfo->assoc_time;
		sta_db->frame_len = cinfo->assoc_req_len;
		memcpy(sta_db->frame, cinfo->assoc_req, cinfo->assoc_req_len);
		SLIST_INSERT_HEAD(&(bss_db_tmp->clients_head), sta_db, clients_entry);
		bss_db_tmp->assco_clients_num++;
	}

	SLIST_FOREACH(bss_db, &ctx->ap_cap_entry.assoc_clients_head, assoc_clients_entry) {
		if (!os_memcmp(bss_db->bssid, cinfo->bssid, ETH_ALEN) && bss_db->assco_clients_num == 0) {
			SLIST_REMOVE(&ctx->ap_cap_entry.assoc_clients_head, bss_db, associated_clients_db, assoc_clients_entry);
			os_free(bss_db);
			break;
		}
	}

	return 0;
}

int get_bandcap(struct p1905_managerd_ctx *ctx, unsigned char opclass,
	unsigned char non_opch_num, unsigned char *non_opch)
{
	unsigned char chnum = 0;
	int i = 0, j = 0, k = 0;
	struct global_oper_class *opcls = oper_class;
	unsigned char *chset = NULL;
	unsigned char cap = BAND_INVALID_CAP;

	do {
		if (opcls[i].opclass == opclass) {
			chnum = opcls[i].channel_num;
			chset = opcls[i].channel_set;
			if (non_opch_num == chnum) {
				cap = BAND_INVALID_CAP;
			} else {
				switch (opclass) {
				case 81:
				case 82:
				case 83:
				case 84:
				case 101:
				case 102:
				case 103:
				case 112:
				case 113:
				case 114:
					cap = BAND_2G_CAP;
				break;
				case 94:
				case 95:
				case 96:
				case 104:
				case 105:
				case 106:
				case 107:
				case 108:
				case 109:
				case 110:
				case 111:
				case 121:
				case 122:
				case 123:
				case 124:
				case 125:
				case 126:
				case 127:
					cap = BAND_5GH_CAP;
				break;
				case 115:
				case 116:
				case 117:
				case 118:
				case 119:
				case 120:
					cap = BAND_5GL_CAP;
				break;
				case 128:
				case 129:
				case 130:
					for (j = 0; j < chnum; j++) {
						for (k = 0; k < non_opch_num; k++) {
							if (chset[j] == non_opch[k])
								break;
						}
						if (k == non_opch_num) {
							if (chset[j] < 100)
								cap |= BAND_5GL_CAP;
							else
								cap |= BAND_5GH_CAP;
						}
					}
					break;
				case 131:
				case 132:
				case 133:
				case 134:
				case 137:
				case 135:
					for (j = 0; j < chnum; j++) {
						for (k = 0; k < non_opch_num; k++) {
							if (chset[j] == non_opch[k])
								break;
						}
						if (k == non_opch_num) {
							cap |= BAND_6G_CAP;
							break;
						}
					}
					break;
				default:
					notice(DEBUG_CAT_AUTOCONF, "unknown opclass %d\n", opclass);
					break;

				}
			}
			break;
		}
		i++;
	} while (opcls[i].opclass != 0);

	return cap;
}



int update_ap_ht_cap(struct p1905_managerd_ctx* ctx, struct ap_ht_capability *pcap)
{
	struct ap_ht_cap_db *pdb;
	SLIST_FOREACH(pdb, &(ctx->ap_cap_entry.ap_ht_cap_head), ap_ht_cap_entry)
	{
		/*exist entry, update it*/
		if (!memcmp(pdb->identifier, pcap->identifier, ETH_ALEN)) {
			pdb->tx_stream = pcap->tx_stream;
			pdb->rx_stream = pcap->rx_stream;
			pdb->sgi_20 = pcap->sgi_20;
			pdb->sgi_40 = pcap->sgi_40;
			pdb->ht_40 = pcap->ht_40;
			return 0;
		}
	}
	/*insert new one*/
	pdb = (struct ap_ht_cap_db *)malloc(sizeof(struct ap_ht_cap_db));
	if (pdb == NULL) {
		err(DEBUG_CAT_MISC, "alloc struct ap_ht_cap_db fail\n");
		return -1;
	}
	memcpy(pdb->identifier, pcap->identifier, ETH_ALEN);
	pdb->tx_stream = pcap->tx_stream;
	pdb->rx_stream = pcap->rx_stream;
	pdb->sgi_20 = pcap->sgi_20;
	pdb->sgi_40 = pcap->sgi_40;
	pdb->ht_40 = pcap->ht_40;
	SLIST_INSERT_HEAD(&(ctx->ap_cap_entry.ap_ht_cap_head), pdb, ap_ht_cap_entry);

	return 0;
}
int update_ap_eht_cap(struct p1905_managerd_ctx *ctx, struct ap_eht_capability *pcap)
{
	struct ap_eht_cap_db *pdb;

	SLIST_FOREACH(pdb, &(ctx->ap_cap_entry.ap_eht_cap_head), ap_eht_cap_entry)
	{
		/*exist entry, update it*/
		if (!memcmp(pdb->identifier, pcap->identifier, 6)) {
			pdb->tx_stream = pcap->tx_stream;
			pdb->rx_stream = pcap->rx_stream;
			pdb->eht_ch_width = pcap->eht_ch_width;
			pdb->ccfs0 = pcap->ccfs0;
			pdb->ccfs1 = pcap->ccfs1;
			return 0;
		}
	}
	/*insert new one*/
	pdb = (struct ap_eht_cap_db *)malloc(sizeof(struct ap_eht_cap_db));
	if (pdb == NULL) {
		warn(DEBUG_CAT_MLO, "allocate memory fail\n");
		return -1;
	}
	memcpy(pdb->identifier, pcap->identifier, 6);
	pdb->tx_stream = pcap->tx_stream;
	pdb->rx_stream = pcap->rx_stream;
	pdb->eht_ch_width = pcap->eht_ch_width;
	pdb->ccfs0 = pcap->ccfs0;
	pdb->ccfs1 = pcap->ccfs1;
	SLIST_INSERT_HEAD(&(ctx->ap_cap_entry.ap_eht_cap_head), pdb, ap_eht_cap_entry);
	return 0;
}
int update_ap_vht_cap(struct p1905_managerd_ctx* ctx, struct ap_vht_capability *pcap)
{
	struct ap_vht_cap_db *pdb;
	SLIST_FOREACH(pdb, &(ctx->ap_cap_entry.ap_vht_cap_head), ap_vht_cap_entry)
	{
		/*exist entry, update it*/
		if (!memcmp(pdb->identifier, pcap->identifier, ETH_ALEN)) {
			pdb->vht_tx_mcs = pcap->vht_tx_mcs;
			pdb->vht_rx_mcs = pcap->vht_rx_mcs;
			pdb->mu_beamformer = pcap->mu_beamformer;
			pdb->sgi_160 = pcap->sgi_160;
			pdb->sgi_80 = pcap->sgi_80;
			pdb->vht_160 = pcap->vht_160;
			pdb->vht_8080 = pcap->vht_8080;
			pdb->tx_stream = pcap->tx_stream;
			pdb->rx_stream = pcap->rx_stream;
			pdb->su_beamformer = pcap->su_beamformer;
			return 0;
		}
	}
	/*insert new one*/
	pdb = (struct ap_vht_cap_db*)malloc(sizeof(struct ap_vht_cap_db));
	if (pdb == NULL) {
		err(DEBUG_CAT_MISC, "alloc struct ap_vht_cap_db fail\n");
		return -1;
	}
	memcpy(pdb->identifier, pcap->identifier, ETH_ALEN);
	pdb->vht_tx_mcs = pcap->vht_tx_mcs;
	pdb->vht_rx_mcs = pcap->vht_rx_mcs;
	pdb->mu_beamformer = pcap->mu_beamformer;
	pdb->sgi_160 = pcap->sgi_160;
	pdb->sgi_80 = pcap->sgi_80;
	pdb->vht_160 = pcap->vht_160;
	pdb->vht_8080 = pcap->vht_8080;
	pdb->tx_stream = pcap->tx_stream;
	pdb->rx_stream = pcap->rx_stream;
	pdb->su_beamformer = pcap->su_beamformer;
	SLIST_INSERT_HEAD(&(ctx->ap_cap_entry.ap_vht_cap_head), pdb, ap_vht_cap_entry);

	return 0;
}

int update_ap_he_cap(struct p1905_managerd_ctx* ctx, struct ap_he_capability *pcap)
{
	struct ap_he_cap_db *pdb;

	if (pcap->he_mcs_len > 12 || pcap->he_mcs_len < 2) {
		err(DEBUG_CAT_EVENT, "invalid he_mcs_len(%d); not in (2,12)\n",
			pcap->he_mcs_len);
		return -1;
	}

	SLIST_FOREACH(pdb, &(ctx->ap_cap_entry.ap_he_cap_head), ap_he_cap_entry)
	{
		/*exist entry, update it*/
		if (!memcmp(pdb->identifier, pcap->identifier, ETH_ALEN)) {
			pdb->he_mcs_len = pcap->he_mcs_len;
			os_memcpy(pdb->he_mcs, pcap->he_mcs, pdb->he_mcs_len);
			pdb->tx_stream = pcap->tx_stream;
			pdb->rx_stream = pcap->rx_stream;
			pdb->he_8080 = pcap->he_8080;
			pdb->he_160 = pcap->he_160;
			pdb->su_bf_cap = pcap->su_bf_cap;
			pdb->mu_bf_cap = pcap->mu_bf_cap;
			pdb->ul_mu_mimo_cap = pcap->ul_mu_mimo_cap;
			pdb->ul_mu_mimo_ofdma_cap = pcap->ul_mu_mimo_ofdma_cap;
			pdb->dl_mu_mimo_ofdma_cap = pcap->dl_mu_mimo_ofdma_cap;
			pdb->ul_ofdma_cap = pcap->ul_ofdma_cap;
			pdb->dl_ofdma_cap = pcap->dl_ofdma_cap;
#ifdef MAP_R3
			pdb->agent_role = pcap->agent_role;
			pdb->su_beamformee_status = pcap->su_beamformee_status;
			pdb->beamformee_sts_less80 = pcap->beamformee_sts_less80;
			pdb->beamformee_sts_more80= pcap->beamformee_sts_more80;
			pdb->max_user_dl_tx_mu_mimo = pcap->max_user_dl_tx_mu_mimo;
			pdb->max_user_ul_rx_mu_mimo = pcap->max_user_ul_rx_mu_mimo;
			pdb->max_user_dl_tx_ofdma = pcap->max_user_dl_tx_ofdma;
			pdb->max_user_ul_rx_ofdma = pcap->max_user_ul_rx_ofdma;
			pdb->rts_status = pcap->rts_status;
			pdb->mu_rts_status = pcap->mu_rts_status;
			pdb->m_bssid_status = pcap->m_bssid_status;
			pdb->mu_edca_status = pcap->mu_edca_status;
			pdb->twt_requester_status = pcap->twt_requester_status;
			pdb->twt_responder_status = pcap->twt_responder_status;
#endif //MAP_R3
			return 0;
		}
	}
	/*insert new one*/
	pdb = (struct ap_he_cap_db*)malloc(sizeof(struct ap_he_cap_db));
	if (pdb == NULL) {
		err(DEBUG_CAT_MISC, "alloc struct ap_he_cap_db fail\n");
		return -2;
	}
	memcpy(pdb->identifier, pcap->identifier, ETH_ALEN);
	pdb->he_mcs_len = pcap->he_mcs_len;
	os_memcpy(pdb->he_mcs, pcap->he_mcs, pdb->he_mcs_len);
	pdb->tx_stream = pcap->tx_stream;
	pdb->rx_stream = pcap->rx_stream;
	pdb->he_8080 = pcap->he_8080;
	pdb->he_160 = pcap->he_160;
	pdb->su_bf_cap = pcap->su_bf_cap;
	pdb->mu_bf_cap = pcap->mu_bf_cap;
	pdb->ul_mu_mimo_cap = pcap->ul_mu_mimo_cap;
	pdb->ul_mu_mimo_ofdma_cap = pcap->ul_mu_mimo_ofdma_cap;
	pdb->dl_mu_mimo_ofdma_cap = pcap->dl_mu_mimo_ofdma_cap;
	pdb->ul_ofdma_cap = pcap->ul_ofdma_cap;
	pdb->dl_ofdma_cap = pcap->dl_ofdma_cap;
#ifdef MAP_R3
	pdb->agent_role = pcap->agent_role;
	pdb->su_beamformee_status = pcap->su_beamformee_status;
	pdb->beamformee_sts_less80 = pcap->beamformee_sts_less80;
	pdb->beamformee_sts_more80= pcap->beamformee_sts_more80;
	pdb->max_user_dl_tx_mu_mimo = pcap->max_user_dl_tx_mu_mimo;
	pdb->max_user_ul_rx_mu_mimo = pcap->max_user_ul_rx_mu_mimo;
	pdb->max_user_dl_tx_ofdma = pcap->max_user_dl_tx_ofdma;
	pdb->max_user_ul_rx_ofdma = pcap->max_user_ul_rx_ofdma;
	pdb->rts_status = pcap->rts_status;
	pdb->mu_rts_status = pcap->mu_rts_status;
	pdb->m_bssid_status = pcap->m_bssid_status;
	pdb->mu_edca_status = pcap->mu_edca_status;
	pdb->twt_requester_status = pcap->twt_requester_status;
	pdb->twt_responder_status = pcap->twt_responder_status;
#endif //MAP_R3

	SLIST_INSERT_HEAD(&(ctx->ap_cap_entry.ap_he_cap_head), pdb, ap_he_cap_entry);

	return 0;
}

int delete_exist_ch_prefer_info(struct p1905_managerd_ctx *ctx,
	unsigned char *identifier)
{
	 struct ch_prefer_db *chcap = NULL;
	 struct prefer_info_db *prefer = NULL, *prefer_tmp = NULL;

	SLIST_FOREACH(chcap, &(ctx->ap_cap_entry.ch_prefer_head), ch_prefer_entry)
	{
		if (!memcmp(chcap->identifier, identifier, ETH_ALEN)) {
			if (!SLIST_EMPTY(&(chcap->prefer_info_head))) {
				prefer = SLIST_FIRST(&(chcap->prefer_info_head));
				while (prefer) {
					prefer_tmp = SLIST_NEXT(prefer, prefer_info_entry);
					SLIST_REMOVE(&(chcap->prefer_info_head), prefer,
								prefer_info_db, prefer_info_entry);
					free(prefer);
					prefer = prefer_tmp;
				}
			}
			SLIST_REMOVE(&(ctx->ap_cap_entry.ch_prefer_head), chcap, ch_prefer_db, ch_prefer_entry);
			free(chcap);
			break;
		}
	}

	return wapp_utils_success;
}

int delete_all_ch_prefer_info(struct list_head_ch_prefer *ch_prefer_head)
{
	struct ch_prefer_db *chcap = NULL, *chcap_tmp = NULL;
	struct prefer_info_db *prefer = NULL, *prefer_tmp = NULL;

	chcap = SLIST_FIRST(ch_prefer_head);
	while (chcap != NULL) {
		chcap_tmp = SLIST_NEXT(chcap, ch_prefer_entry);
        prefer = SLIST_FIRST(&(chcap->prefer_info_head));
		while (prefer) {
            prefer_tmp = SLIST_NEXT(prefer, prefer_info_entry);
            free(prefer);
            prefer = prefer_tmp;
        }
		free(chcap);
		chcap = chcap_tmp;
    }
	SLIST_INIT(ch_prefer_head);

	return wapp_utils_success;
}

int insert_new_channel_prefer_info(struct p1905_managerd_ctx *ctx,
	struct ch_prefer *prefer)
{
	struct ch_prefer_db *chcap = NULL;
	struct prefer_info_db *prefer_db = NULL;
	struct prefer_info *info = NULL;
	int i = 0;

	chcap = (struct ch_prefer_db *)malloc(sizeof(struct ch_prefer_db));
	if (!chcap) {
		err(DEBUG_CAT_MISC, "alloc struct ch_prefer_db fail\n");
		return wapp_utils_error;
	}
	memset(chcap, 0, sizeof(struct ch_prefer_db));
	memcpy(chcap->identifier, prefer->identifier, ETH_ALEN);
	chcap->op_class_num = prefer->op_class_num;
	SLIST_INIT(&(chcap->prefer_info_head));
	SLIST_INSERT_HEAD(&(ctx->ap_cap_entry.ch_prefer_head), chcap, ch_prefer_entry);

	for(i = 0; i < chcap->op_class_num; i++) {
		info = &prefer->opinfo[i];
		prefer_db = (struct prefer_info_db *)malloc(sizeof(struct prefer_info_db));
		if (!prefer_db) {
			err(DEBUG_CAT_MISC, "alloc struct prefer_info_db fail\n");
			return wapp_utils_error;
		}
		prefer_db->op_class = info->op_class;
		prefer_db->ch_num= info->ch_num;
		memcpy(prefer_db->ch_list, info->ch_list, prefer_db->ch_num);
		prefer_db->perference= info->perference;
		prefer_db->reason= info->reason;
		SLIST_INSERT_HEAD(&(chcap->prefer_info_head), prefer_db, prefer_info_entry);
	}

	return wapp_utils_success;

}

int delete_exist_ch_prefer(struct list_head_ch_prefer *ch_prefer_head, unsigned char *identifier)
{
	struct ch_prefer_db *chcap = NULL;
	struct ch_prefer_db *chcap_tmp = NULL;
	struct prefer_info_db *prefer = NULL;
	struct prefer_info_db *prefer_tmp = NULL;

	if (!ch_prefer_head)
		return wapp_utils_error;

	if (SLIST_EMPTY(ch_prefer_head))
		return wapp_utils_success;

	chcap = SLIST_FIRST(ch_prefer_head);
	while (chcap) {
		if (!os_memcmp(chcap->identifier, identifier, ETH_ALEN)) {
			if (!SLIST_EMPTY(&chcap->prefer_info_head)) {
				prefer = SLIST_FIRST(&chcap->prefer_info_head);
				while (prefer) {
					prefer_tmp = SLIST_NEXT(prefer, prefer_info_entry);
					SLIST_REMOVE(&(chcap->prefer_info_head), prefer, prefer_info_db, prefer_info_entry);
					free(prefer);
					prefer = prefer_tmp;
				}
			}

			SLIST_REMOVE(ch_prefer_head, chcap, ch_prefer_db, ch_prefer_entry);
			free(chcap);
			break;
		}
		chcap = chcap_tmp;
	}

	return wapp_utils_success;
}

void update_ch_prefer_list_info(struct list_head_ch_prefer *dest_ch_prefer_head, struct list_head_ch_prefer *src_ch_prefer_head)
{
	struct ch_prefer_db *chcap = NULL;
	struct ch_prefer_db *chcap_tmp = NULL;
	struct ch_prefer_db *dst_chcap = NULL;
	int exists = 0;

	if (!dest_ch_prefer_head || !src_ch_prefer_head)
		return;

	if (SLIST_EMPTY(src_ch_prefer_head))
		return;

	/* first check chcap whether exist in dest_ch_prefer_head */
	/*if true, should remove the same one in dest_ch_prefer_head, then add new*/

	chcap = SLIST_FIRST(src_ch_prefer_head);
	while (chcap != NULL) {
		chcap_tmp = SLIST_NEXT(chcap, ch_prefer_entry);
		SLIST_REMOVE(src_ch_prefer_head, chcap, ch_prefer_db, ch_prefer_entry);
		exists = 0;
		if (!SLIST_EMPTY(dest_ch_prefer_head)) {
			SLIST_FOREACH(dst_chcap, dest_ch_prefer_head, ch_prefer_entry) {
				if (!os_memcmp(dst_chcap->identifier, chcap->identifier, ETH_ALEN)) {
					exists = 1;
					break;
				}
			}

			if (exists && dst_chcap)
				delete_exist_ch_prefer(dest_ch_prefer_head, dst_chcap->identifier);
		}

		SLIST_INSERT_HEAD(dest_ch_prefer_head, chcap, ch_prefer_entry);
		chcap = chcap_tmp;
	}
}


void update_ch_prefer_info(struct p1905_managerd_ctx *ctx, struct list_head_ch_prefer *ch_prefer_head)
{
	struct ch_prefer_db *prefer = NULL;
	struct ch_prefer_db *prefer_tmp = NULL;

	if (!ctx || !ch_prefer_head)
		return;
	if (SLIST_EMPTY(ch_prefer_head))
		return;

	prefer = SLIST_FIRST(ch_prefer_head);
	while (prefer) {
		prefer_tmp = SLIST_NEXT(prefer, ch_prefer_entry);
		SLIST_REMOVE(ch_prefer_head, prefer, ch_prefer_db, ch_prefer_entry);
		delete_exist_ch_prefer_info(ctx, prefer->identifier);
		SLIST_INSERT_HEAD(&(ctx->ap_cap_entry.ch_prefer_head), prefer, ch_prefer_entry);
		prefer = prefer_tmp;
	}
}

int insert_new_ch_prefer_info(
	struct list_head_ch_prefer *ch_prefer_head, unsigned short len, unsigned char *val)
{
	struct ch_prefer_db *chcap = NULL;
	struct prefer_info_db *prefer = NULL;
	unsigned char *pos = val;
	unsigned short prefer_len = 0;
	unsigned char i = 0, op_class = 0, ch_num = 0;
	int left = (int)len;

	SLIST_FOREACH(chcap, ch_prefer_head, ch_prefer_entry) {
		if (!memcmp(chcap->identifier, pos, ETH_ALEN))
			break;
	}

	if (left - ETH_ALEN - 1 < 0) {
		err(DEBUG_CAT_MSG, "len pre check fail\n");
		goto err;
	}

	if (!chcap) {
		chcap = (struct ch_prefer_db *)malloc(sizeof(*chcap));
		if (!chcap) {
			err(DEBUG_CAT_MISC, "alloc struct ch_prefer_db fail\n");
			goto err;
		}
		memset(chcap, 0, sizeof(*chcap));
		memcpy(chcap->identifier, pos, ETH_ALEN);
		pos += ETH_ALEN;
		chcap->op_class_num = *pos;
		pos += 1;
		SLIST_INIT(&(chcap->prefer_info_head));
		SLIST_INSERT_HEAD(ch_prefer_head, chcap, ch_prefer_entry);
	}else {
		pos += ETH_ALEN;
		chcap->op_class_num = *pos;
		pos += 1;
	}

	left -= (ETH_ALEN + 1);

	for(i = 0; i < chcap->op_class_num; i++) {
		if (left - 2 < 0) {
			err(DEBUG_CAT_MSG, "len pre check fail\n");
			goto err;
		}
		op_class = *pos;
		pos += 1;
		ch_num = *pos;
		pos += 1;
		left -= 2;

		if (left - ch_num < 0) {
			err(DEBUG_CAT_MSG, "len pre check fail\n");
			goto err;
		}
		prefer = (struct prefer_info_db *)malloc(sizeof(struct prefer_info_db));
		if (!prefer) {
			err(DEBUG_CAT_MISC, "alloc struct prefer_info_db fail\n");
			goto err;
		}
		memset(prefer, 0 , prefer_len);
		prefer->op_class = op_class;
		prefer->ch_num = ch_num;
		if (prefer->ch_num) {
			memcpy(prefer->ch_list, pos, ch_num);
			pos += ch_num;
		}
		left -= ch_num;

		if (left - 1 < 0) {
			err(DEBUG_CAT_MSG, "len pre check fail\n");
			free(prefer);
			goto err;
		}
		/*bit 4~7*/
		prefer->perference = *pos >> 4;
		/*bit 0~3*/
		prefer->reason = *pos & 0x0f;
		pos += 1;
		SLIST_INSERT_HEAD(&(chcap->prefer_info_head), prefer, prefer_info_entry);
		left -= 1;
	}

	return 0;
err:
	delete_all_ch_prefer_info(ch_prefer_head);
	err_hexdump(DEBUG_CAT_MSG, "err ch_preference_tlv", val - 3, len + 3);
	return -1;
}

int delete_exist_restriction_info(struct p1905_managerd_ctx *ctx,
	unsigned char *identifier)
{
	 struct oper_restrict_db *restriction = NULL;
	 struct restrict_db *resdb = NULL, *resdb_tmp = NULL;

	SLIST_FOREACH(restriction, &(ctx->ap_cap_entry.oper_restrict_head), oper_restrict_entry)
	{
		if (!memcmp(restriction->identifier, identifier, ETH_ALEN)) {
			if (!SLIST_EMPTY(&(restriction->restrict_head))) {
				resdb = SLIST_FIRST(&(restriction->restrict_head));
				while (resdb) {
					resdb_tmp = SLIST_NEXT(resdb, restrict_entry);
					SLIST_REMOVE(&(restriction->restrict_head), resdb,
								restrict_db, restrict_entry);
					free(resdb);
					resdb = resdb_tmp;
				}
			}
			SLIST_REMOVE(&(ctx->ap_cap_entry.oper_restrict_head), restriction,
						oper_restrict_db, oper_restrict_entry);
			free(restriction);
			break;
		}
	}

	return wapp_utils_success;
}

int insert_new_restriction_info(struct p1905_managerd_ctx *ctx,
	struct restriction *op_restrict)
{
	struct oper_restrict_db *restriction_db = NULL;
	struct restrict_db *resdb = NULL;
	struct restrict_info *info = NULL;
	int i = 0;

	restriction_db = (struct oper_restrict_db *)malloc(sizeof(struct oper_restrict_db));
	if (!restriction_db) {
		err(DEBUG_CAT_MISC, "alloc struct oper_restrict_db fail\n");
		return wapp_utils_error;
	}
	memset(restriction_db, 0, sizeof(struct oper_restrict_db));
	memcpy(restriction_db->identifier, op_restrict->identifier, ETH_ALEN);
	restriction_db->op_class_num = op_restrict->op_class_num;
	SLIST_INIT(&(restriction_db->restrict_head));
	SLIST_INSERT_HEAD(&(ctx->ap_cap_entry.oper_restrict_head),
		restriction_db, oper_restrict_entry);

	for(i = 0; i < restriction_db->op_class_num; i++) {
		info = &op_restrict->opinfo[i];
		resdb = (struct restrict_db *)malloc(sizeof(struct restrict_db));
		if (!resdb) {
			err(DEBUG_CAT_MISC, "alloc struct restrict_db fail\n");
			return wapp_utils_error;
		}
		resdb->op_class = info->op_class;
		resdb->ch_num= info->ch_num;
		memcpy(resdb->ch_list, info->ch_list, resdb->ch_num);
		memcpy(resdb->min_fre_sep, info->fre_separation, resdb->ch_num);
		SLIST_INSERT_HEAD(&(restriction_db->restrict_head), resdb, restrict_entry);
	}

	return wapp_utils_success;
}

unsigned char check_invalid_channel(unsigned char op_class,
	unsigned char ch_num, unsigned char *ch_list)
{
	struct global_oper_class *opcls = oper_class;
	int i = 0, j = 0, k = 0;
	unsigned char opcls_found = 0;

	/*check if the channel is in oper_class*/
	do {
		if (opcls[i].opclass == op_class) {
			opcls_found = 1;
			for (k = 0; k < ch_num; k++) {
				for (j = 0; j < opcls[i].channel_num; j++) {
					if (opcls[i].channel_set[j] == ch_list[k])
						break;
				}
				if (j == opcls[i].channel_num) {
					return 0; /*invalid channel*/
				}
			}
			break;
		}
		i++;
	} while (opcls[i].opclass != 0);

	if (opcls_found)
		return 1;
	else
		return 0;
}


unsigned char find_oper_channel(unsigned char op_class,
	unsigned char ch_num, unsigned char *ch_list)
{
	struct global_oper_class *opcls = oper_class;
	int i = 1; /* skip Invlid entry */
	int j = 0, k = 0;
	unsigned char channel = 0;

	do {
		if (opcls[i].opclass == op_class) {
			for (j = 0; j < opcls[i].channel_num; j++) {
				channel = opcls[i].channel_set[j];
				for (k = 0; k < ch_num; k++) {
					if (channel == ch_list[k])
						break;
				}
				if (k == ch_num) {
					return channel;
				}
			}
			break;
		}
		i++;
	} while (opcls[i].opclass != 0);

	return 0;
}

unsigned char find_first_oper_channel(unsigned char op_class)
{
	struct global_oper_class *opcls = oper_class;
	int i = 1; /* skip Invlid entry */
	unsigned char channel = 0;

	do {
		if (opcls[i].opclass == op_class) {
			channel = opcls[i].channel_set[0];
			return channel;
		}
		i++;
	} while (opcls[i].opclass != 0);

	return 0;
}

int update_channel_report_info(struct p1905_managerd_ctx *ctx,
	struct channel_report *rep, unsigned char len)
{
	if (ctx->ch_rep) {
		os_free(ctx->ch_rep);
		ctx->ch_rep = NULL;
	}
#ifndef MAP_R4_SPT
	ctx->ch_rep = (struct channel_report *)malloc(len);
#else
	unsigned char ch_rpt_len = sizeof(struct channel_report) + (rep->ch_rep_num* sizeof(struct ch_rep_info));
	ctx->ch_rep = (struct channel_report *)malloc(ch_rpt_len);
	if (ctx->ch_rep && len > ch_rpt_len) {
		if (ctx->spt_report) {
			os_free(ctx->spt_report);
			ctx->spt_report = NULL;
		}
		ctx->spt_report = (struct spt_reuse_report *)malloc(len - ch_rpt_len);
		if (!ctx->spt_report) {
			free(ctx->ch_rep);
			ctx->ch_rep = NULL;
			err(DEBUG_CAT_MISC, "alloc struct spt_reuse_report fail\n");
			return -1;
		}
		memcpy(ctx->spt_report, rep + ch_rpt_len, len - ch_rpt_len);
		len = ch_rpt_len;
	}
#endif
	if (!ctx->ch_rep) {
		err(DEBUG_CAT_MISC, "alloc struct channel_report fail\n");
		return -1;
	}
	memcpy(ctx->ch_rep, rep, len);

	return 0;
}

void add_control_policy_info(struct control_policy *steer_cntrl, struct control_policy_db *new_policy)
{
	struct control_policy_db *policy = NULL;
	struct control_policy_db *policy_tmp = NULL;
	struct list_head_control_policy *policy_head = NULL;
	struct sta_db *sta = NULL;
	struct sta_db *sta_tmp = NULL;

	if (!steer_cntrl || !new_policy)
		return;
	policy_head = &(steer_cntrl->policy_head);

	policy = SLIST_FIRST(policy_head);
	while (policy) {
		policy_tmp = SLIST_NEXT(policy, policy_entry);
		if (!os_memcmp(policy->bssid, new_policy->bssid, ETH_ALEN)) {
			SLIST_REMOVE(policy_head, policy, control_policy_db, policy_entry);

			if (!SLIST_EMPTY(&policy->sta_head)) {
				sta = SLIST_FIRST(&policy->sta_head);
				while (sta) {
					sta_tmp = SLIST_NEXT(sta, sta_entry);
					free(sta);
					sta = sta_tmp;
				}
			}
			free(policy);
			steer_cntrl->policy_cnt--;
			break;
		}
		policy = policy_tmp;
	}

	SLIST_INSERT_HEAD(&(steer_cntrl->policy_head), new_policy, policy_entry);
	steer_cntrl->policy_cnt++;
}

void update_control_policy_info(struct control_policy *dst_steer_cntrl, struct control_policy *src_steer_cntrl)
{
	struct control_policy_db *policy = NULL;
	struct control_policy_db *policy_tmp = NULL;
	struct list_head_control_policy *src_policy_head = NULL;

	if (!dst_steer_cntrl || !src_steer_cntrl)
		return;
	src_policy_head = &(src_steer_cntrl->policy_head);

	if (SLIST_EMPTY(src_policy_head))
		return;

	policy = SLIST_FIRST(src_policy_head);
	while (policy) {
		policy_tmp = SLIST_NEXT(policy, policy_entry);
		add_control_policy_info(dst_steer_cntrl, policy);
		SLIST_REMOVE(src_policy_head, policy, control_policy_db, policy_entry);
		policy = policy_tmp;
	}
}





int delete_exist_metrics_policy(struct p1905_managerd_ctx *ctx, struct metrics_policy *mpolicy)
{
	struct metric_policy_db *policy = NULL, *policy_tmp = NULL;

	policy = SLIST_FIRST(&mpolicy->policy_head);
	while(policy != NULL) {
		policy_tmp = SLIST_NEXT(policy, policy_entry);
		free(policy);
		policy = policy_tmp;
	}
	SLIST_INIT(&mpolicy->policy_head);
	mpolicy->report_interval = 0;
	mpolicy->radio_num = 0;

	return wapp_utils_success;
}

int fill_metrics_policy(struct p1905_managerd_ctx *ctx, struct metrics_policy *mpolicy)
{
	struct metric_policy_db *policy = NULL, *policy_tmp = NULL;

	policy = SLIST_FIRST(&mpolicy->policy_head);
	while (policy != NULL) {

		policy_tmp = SLIST_NEXT(policy, policy_entry);
		SLIST_REMOVE(&(mpolicy->policy_head), policy, metric_policy_db, policy_entry);
		SLIST_INSERT_HEAD(&(ctx->map_policy.mpolicy.policy_head), policy, policy_entry);
		policy = policy_tmp;
	}
	ctx->map_policy.mpolicy.report_interval = mpolicy->report_interval;
	ctx->map_policy.mpolicy.radio_num = mpolicy->radio_num;
	mpolicy->report_interval = 0;
	mpolicy->radio_num = 0;

	return wapp_utils_success;
}

void update_metrics_policy(struct p1905_managerd_ctx *ctx, struct metrics_policy *mpolicy)
{
	/*delete the previously reserved metrics policy*/
	delete_exist_metrics_policy(ctx, &ctx->map_policy.mpolicy);
	fill_metrics_policy(ctx, mpolicy);
}

int delete_exist_metrics_info(struct p1905_managerd_ctx *ctx,
	unsigned char *bssid)
{
	 struct mrsp_db *mrsp = NULL;
	 struct esp_db *esp = NULL, *esp_tmp = NULL;

    SLIST_FOREACH(mrsp, &(ctx->metric_entry.metrics_rsp_head), mrsp_entry)
    {
		if (!memcmp(mrsp->bssid, bssid, ETH_ALEN)) {
			if (!SLIST_EMPTY(&(mrsp->esp_head))) {
                esp = SLIST_FIRST(&(mrsp->esp_head));
				while (esp) {
                    esp_tmp = SLIST_NEXT(esp, esp_entry);
                    SLIST_REMOVE(&(mrsp->esp_head), esp, esp_db, esp_entry);
                    free(esp);
                    esp = esp_tmp;
                }
            }
            SLIST_REMOVE(&(ctx->metric_entry.metrics_rsp_head), mrsp,
                        mrsp_db, mrsp_entry);
            free(mrsp);
            break;
        }
    }

	return wapp_utils_success;
}

int insert_new_metrics_info(struct p1905_managerd_ctx *ctx,
	struct ap_metrics_info *minfo)
{
	struct mrsp_db *mrsp = NULL;
	struct esp_db *esp = NULL;
	struct esp_info *info = NULL;
	int i = 0;

	mrsp = (struct mrsp_db *)malloc(sizeof(struct mrsp_db));
	if (!mrsp) {
		err(DEBUG_CAT_MISC, "alloc struct mrsp_db fail\n");
		return wapp_utils_error;
	}
	memset(mrsp, 0, sizeof(struct mrsp_db));
	memcpy(mrsp->bssid, minfo->bssid, ETH_ALEN);
	mrsp->ch_util = minfo->ch_util;
	mrsp->assoc_sta_cnt = minfo->assoc_sta_cnt;
	mrsp->esp_cnt = minfo->valid_esp_count;
	SLIST_INIT(&(mrsp->esp_head));
	SLIST_INSERT_HEAD(&(ctx->metric_entry.metrics_rsp_head), mrsp, mrsp_entry);

	for(i = 0; i < mrsp->esp_cnt; i++) {
		info = &minfo->esp[i];
		esp = (struct esp_db *)malloc(sizeof(struct esp_db));
		if (!esp) {
			err(DEBUG_CAT_MISC, "alloc struct esp_db fail\n");
			return wapp_utils_error;
		}
		esp->ac = info->ac;
		esp->format = info->format;
		esp->ba_win_size = info->ba_win_size;
		esp->e_air_time_fraction = info->e_air_time_fraction;
		esp->ppdu_dur_target = info->ppdu_dur_target;
		SLIST_INSERT_HEAD(&(mrsp->esp_head), esp, esp_entry);
	}

	return wapp_utils_success;
}

unsigned short append_ap_metrics_tlv(
        unsigned char *pkt, struct mrsp_db *mrsp)
{
    unsigned short total_length = 0;
    unsigned char *temp_buf;
	struct esp_db *esp = NULL;
	unsigned char ac[4] = {1,0,3,2};
	unsigned char i = 0;
	unsigned char *esp_pos = NULL;

    temp_buf = pkt;

    *temp_buf++ = AP_METRICS_TYPE;
	total_length += 1;

    temp_buf += 2;
	total_length += 2;

	memcpy(temp_buf, mrsp->bssid, ETH_ALEN);
	temp_buf += ETH_ALEN;
	total_length += ETH_ALEN;

	*temp_buf++ = mrsp->ch_util;
	total_length += 1;

	*(unsigned short *)(temp_buf) = host_to_be16(mrsp->assoc_sta_cnt);
	temp_buf += 2;
	total_length += 2;

	esp_pos = temp_buf;
	temp_buf += 1;
	total_length += 1;

	*esp_pos = 0;
	for (i = 0; i < 4; i++) {
		SLIST_FOREACH(esp, &(mrsp->esp_head), esp_entry)
	    {
	    	if (esp->ac == ac[i]) {
				*esp_pos |= 1 << (7 - i);
				*temp_buf++ = (esp->ba_win_size << 5) | (esp->format << 3) | esp->ac;
				*temp_buf++ = esp->e_air_time_fraction;
				*temp_buf++ = esp->ppdu_dur_target;
				total_length += 3;
				break;
	    	}
		}
	}

	/*calculate totoal length & fill into the length field*/
	*(unsigned short *)(pkt+1) = host_to_be16(total_length - 3);

    return total_length;
}

unsigned short append_sta_traffic_stats_tlv(unsigned char *pkt, struct stats_db *stats
#ifdef MAP_R2
, unsigned char unit
#endif
)
{
	unsigned short total_length = 0;
	unsigned char *temp_buf;
	unsigned int bytes_sent = 0;
	unsigned int bytes_received = 0;

    temp_buf = pkt;

    *temp_buf++ = ASSOC_STA_TRAFFIC_STATS_TYPE;
	total_length += 1;

    temp_buf += 2;
	total_length += 2;

	memcpy(temp_buf, stats->mac, ETH_ALEN);
	temp_buf += ETH_ALEN;
	total_length += ETH_ALEN;

	/* BytesSent && BytesReceived Units specified by R2 AP Capability TLV */
	/* bytes, default, mapd guarantee this unit */
	bytes_sent = stats->bytes_sent;
	bytes_received = stats->bytes_received;
#ifdef MAP_R2
	/*BytesSent*/
	if (unit == 1) {
		/* kibibytes (KiB) */
		bytes_sent = stats->bytes_sent/1024;
		bytes_received = stats->bytes_received/1024;
	}
	else if (unit == 2) {
		/* mebibytes (MiB) */
		bytes_sent = stats->bytes_sent/1024/1024;
		bytes_received = stats->bytes_received/1024/1024;
	}
#endif

	*(unsigned int *)(temp_buf) = host_to_be32(bytes_sent);
	temp_buf += 4;
	total_length += 4;

	/*BytesReceived*/
	*(unsigned int *)(temp_buf) = host_to_be32(bytes_received);
	temp_buf += 4;
	total_length += 4;

	/*PacketsSent*/
	*(unsigned int *)(temp_buf) = host_to_be32(stats->packets_sent);
	temp_buf += 4;
	total_length += 4;

	/*PacketsReceived*/
	*(unsigned int *)(temp_buf) = host_to_be32(stats->packets_received);
	temp_buf += 4;
	total_length += 4;


	/*TxPacketsErrors*/
	*(unsigned int *)(temp_buf) = host_to_be32(stats->tx_packets_errors);
	temp_buf += 4;
	total_length += 4;

	/*RxPacketsErrors*/
	*(unsigned int *)(temp_buf) = host_to_be32(stats->rx_packets_errors);
	temp_buf += 4;
	total_length += 4;

	/*RetransmissionCount*/
	*(unsigned int *)(temp_buf) = host_to_be32(stats->retransmission_count);
	temp_buf += 4;
	total_length += 4;

	/*calculate totoal length & fill into the length field*/
	*(unsigned short *)(pkt+1) = host_to_be16(total_length - 3);

    return total_length;
}

unsigned short append_sta_link_metrics_tlv(
        unsigned char *pkt, struct metrics_db *metrics)
{
    unsigned short total_length = 0;
    unsigned char *temp_buf;

    temp_buf = pkt;

    *temp_buf++ = ASSOC_STA_LINK_METRICS_TYPE;
	total_length += 1;

    temp_buf += 2;
	total_length += 2;

	memcpy(temp_buf, metrics->mac, ETH_ALEN);
	temp_buf += ETH_ALEN;
	total_length += ETH_ALEN;

	/*BSSID number*/
	*temp_buf++ = 1;
	total_length += 1;

	memcpy(temp_buf, metrics->bssid, ETH_ALEN);
	temp_buf += ETH_ALEN;
	total_length += ETH_ALEN;

	/*TimeDelta*/
	*(unsigned int *)(temp_buf) = host_to_be32(metrics->time_delta);
	temp_buf += 4;
	total_length += 4;

	/*Estimated MAC Date Rate in Downlink*/
	*(unsigned int *)(temp_buf) = host_to_be32(metrics->erate_downlink);
	temp_buf += 4;
	total_length += 4;

	/*Estimated MAC Date Rate in Uplink*/
	*(unsigned int *)(temp_buf) = host_to_be32(metrics->erate_uplink);
	temp_buf += 4;
	total_length += 4;

	/*Measured Uplink RSSI*/
	*temp_buf++ = metrics->rssi_uplink & 0xff;
	total_length += 1;

	/*calculate totoal length & fill into the length field*/
	*(unsigned short *)(pkt+1) = host_to_be16(total_length - 3);

    return total_length;
}

int delete_exist_traffic_stats_info(struct p1905_managerd_ctx *ctx,
	unsigned char *identifier)
{
	struct traffic_stats_db *traffic_stats = NULL;
	struct stats_db *stats = NULL, *stats_tmp = NULL;

    SLIST_FOREACH(traffic_stats, &ctx->metric_entry.traffic_stats_head, traffic_stats_entry)
    {
		if (!memcmp(traffic_stats->identifier, identifier, ETH_ALEN)) {
            stats = SLIST_FIRST(&traffic_stats->stats_head);
			while (stats) {
                stats_tmp = SLIST_NEXT(stats, stats_entry);
                SLIST_REMOVE(&traffic_stats->stats_head, stats, stats_db, stats_entry);
                free(stats);
                stats = stats_tmp;
            }
            SLIST_REMOVE(&ctx->metric_entry.traffic_stats_head, traffic_stats,
                        traffic_stats_db, traffic_stats_entry);
            free(traffic_stats);
            break;
        }
    }

	return wapp_utils_success;
}

int insert_new_traffic_stats_info(struct p1905_managerd_ctx *ctx,
	struct sta_traffic_stats *traffic_stats)
{
	struct traffic_stats_db *tstats = NULL;
	struct stats_db *stats = NULL;
	struct stat_info *info = NULL;
	int i = 0;

	tstats = (struct traffic_stats_db *)malloc(sizeof(struct traffic_stats_db));
	if (!tstats) {
		err(DEBUG_CAT_MISC, "alloc struct traffic_stats_db fail\n");
		return wapp_utils_error;
	}
	memset(tstats, 0, sizeof(struct traffic_stats_db));
	memcpy(tstats->identifier, traffic_stats->identifier, ETH_ALEN);
	tstats->sta_cnt= traffic_stats->sta_cnt;
	SLIST_INIT(&tstats->stats_head);
	SLIST_INSERT_HEAD(&(ctx->metric_entry.traffic_stats_head), tstats, traffic_stats_entry);

	for(i = 0; i < traffic_stats->sta_cnt; i++) {
		info = &traffic_stats->stats[i];
		stats = (struct stats_db *)malloc(sizeof(struct stats_db));
		if (!stats) {
			err(DEBUG_CAT_MISC, "alloc struct stats_db fail\n");
			return wapp_utils_error;
		}
		memcpy(stats->mac, info->mac, ETH_ALEN);
		stats->bytes_sent = info->bytes_sent;
		stats->bytes_received = info->bytes_received;
		stats->packets_sent = info->packets_sent;
		stats->packets_received = info->packets_received;
		stats->tx_packets_errors = info->tx_packets_errors;
		stats->rx_packets_errors = info->rx_packets_errors;
		stats->retransmission_count = info->retransmission_count;
		SLIST_INSERT_HEAD(&tstats->stats_head, stats, stats_entry);
	}

	return wapp_utils_success;

}

int delete_exist_link_metrics_info(struct p1905_managerd_ctx *ctx,
	unsigned char *identifier)
{
	struct link_metrics_db *link_metrics = NULL;
	struct metrics_db *metrics = NULL, *metrics_tmp = NULL;

    SLIST_FOREACH(link_metrics, &ctx->metric_entry.link_metrics_head, link_metrics_entry)
    {
		if (!memcmp(link_metrics->identifier, identifier, ETH_ALEN)) {
            metrics = SLIST_FIRST(&link_metrics->metrics_head);
			while (metrics) {
                metrics_tmp = SLIST_NEXT(metrics, metrics_entry);
                SLIST_REMOVE(&link_metrics->metrics_head, metrics, metrics_db, metrics_entry);
                free(metrics);
                metrics = metrics_tmp;
            }
            SLIST_REMOVE(&ctx->metric_entry.link_metrics_head, link_metrics,
                        link_metrics_db, link_metrics_entry);
            free(link_metrics);
            break;
        }
    }

	return wapp_utils_success;
}

int insert_new_link_metrics_info(struct p1905_managerd_ctx *ctx,
	struct sta_link_metrics *metrics_info)
{
	struct link_metrics_db *link_metrics_ctx = NULL;
	struct metrics_db *metrics_ctx = NULL;
	struct link_metrics *info = NULL;
	int i = 0;

	link_metrics_ctx = (struct link_metrics_db *)malloc(sizeof(struct link_metrics_db));
	if (!link_metrics_ctx) {
		err(DEBUG_CAT_MISC, "alloc struct link_metrics_db fail\n");
		return wapp_utils_error;
	}
	memset(link_metrics_ctx, 0, sizeof(struct link_metrics_db));
	memcpy(link_metrics_ctx->identifier, metrics_info->identifier, ETH_ALEN);
	link_metrics_ctx->sta_cnt= metrics_info->sta_cnt;
	SLIST_INIT(&link_metrics_ctx->metrics_head);
	SLIST_INSERT_HEAD(&ctx->metric_entry.link_metrics_head, link_metrics_ctx, link_metrics_entry);

	for(i = 0; i < link_metrics_ctx->sta_cnt; i++) {
		info = &metrics_info->info[i];
		metrics_ctx = (struct metrics_db *)malloc(sizeof(struct metrics_db));
		if (!metrics_ctx) {
			err(DEBUG_CAT_MISC, "alloc struct metrics_db fail\n");
			return wapp_utils_error;
		}
		memcpy(metrics_ctx->mac, info->mac, ETH_ALEN);
		memcpy(metrics_ctx->bssid, info->bssid, ETH_ALEN);
		metrics_ctx->time_delta = info->time_delta;
		metrics_ctx->erate_downlink = info->erate_downlink;
		metrics_ctx->erate_uplink = info->erate_uplink;
		metrics_ctx->rssi_uplink = info->rssi_uplink;
		SLIST_INSERT_HEAD(&link_metrics_ctx->metrics_head, metrics_ctx, metrics_entry);
	}

	return wapp_utils_success;
}

int dev_send_1905(struct p1905_managerd_ctx *ctx, struct _1905_cmdu_request *request)
{
	struct p1905_neighbor_info *dev_info = NULL;
	struct topology_response_db *tpgr_db = NULL;
	int i = 0, ifidx = -1;
	int is_mal = 0;
	unsigned char al_multi_address[6] = { 0x01, 0x80, 0xc2, 0x00, 0x00, 0x13 };
	unsigned char need_update_mid = 1;
	unsigned char *if_name = NULL;

	if (memcmp(al_multi_address, request->dest_al_mac, ETH_ALEN)) {
		for(i = 0; i < ctx->itf_number; i++) {
			LIST_FOREACH(dev_info, &(ctx->p1905_neighbor_dev[i].p1905nbr_head), p1905nbr_entry) {
				if (!memcmp(dev_info->al_mac_addr, request->dest_al_mac, ETH_ALEN)) {
					ifidx = i;
					break;
				}
			}
		}
		if (ifidx == -1) {
			SLIST_FOREACH(tpgr_db, &(ctx->topology_entry.tprdb_head), tprdb_entry) {
				if(!memcmp(request->dest_al_mac, tpgr_db->al_mac_addr, ETH_ALEN)) {
				   ifidx = tpgr_db->recv_ifid;
				}
			}
		}

		if (ifidx == -1) {
			warn(DEBUG_CAT_EVENT, "almac "MACSTR" not in topo db; tx to brige; mtype=0x%04x(%s)\n",
				MAC2STR(request->dest_al_mac), request->type, get_1905_mtype_str(request->type));
			if_name = ctx->br_name;
		} else {
			if_name = ctx->itf[ifidx].if_name;
		}
	} else {
		is_mal = 1;
		if_name = ctx->br_name;
	}

	debug(DEBUG_CAT_EVENT, "recv DEV_SEND_1905; dest_al_mac="MACSTR";"
		" type=%04x(%s); request_len=%d\n",
			MAC2STR(request->dest_al_mac), request->type,
			get_1905_mtype_str(request->type), request->len);

	if (request->len > 0) {
		ctx->mid++;
		if (is_mal == 1) {
			if (request->type == TOPOLOGY_NOTIFICATION ||
				request->type == AP_AUTOCONFIG_RENEW)
				multicast_cmdu_tx(ctx, request->type, ctx->mid, 1);
			else
				multicast_cmdu_tx(ctx, request->type, ctx->mid, 0);
		} else {
			insert_cmdu_txq(request->dest_al_mac, ctx->p1905_al_mac_addr,
				e_dev_send_1905_request, ctx->mid,
				if_name, need_update_mid);
		}
		ctx->pcmdu_tx_buf = request->body;
		ctx->cmdu_tx_msg_type = request->type;
		ctx->cmdu_tx_buf_len = request->len;

		return 0;
	}

	switch (request->type) {
	case TOPOLOGY_DISCOVERY:
		ctx->mid++;
		multicast_cmdu_tx(ctx, e_topology_discovery, ctx->mid, 0);
		break;
	case TOPOLOGY_NOTIFICATION:
		ctx->mid++;
		multicast_cmdu_tx(ctx, e_topology_notification, ctx->mid, 1);
		break;
	case TOPOLOGY_QUERY:
		insert_cmdu_txq(request->dest_al_mac, ctx->p1905_al_mac_addr,
			e_topology_query, ++ctx->mid, if_name, need_update_mid);
		break;
	case AP_CAPABILITY_QUERY:
		insert_cmdu_txq(request->dest_al_mac, ctx->p1905_al_mac_addr,
			e_ap_capability_query, ++ctx->mid, if_name, need_update_mid);
		break;
	case CHANNEL_PREFERENCE_QUERY:
		insert_cmdu_txq(request->dest_al_mac, ctx->p1905_al_mac_addr,
			e_channel_preference_query, ++ctx->mid,
			if_name, need_update_mid);
		break;
	case CHANNEL_SELECTION_REQUEST:
		reset_send_tlv(ctx);
		insert_cmdu_txq(request->dest_al_mac, ctx->p1905_al_mac_addr,
			e_channel_selection_request, ++ctx->mid, if_name, need_update_mid);
		break;
	case COMBINED_INFRASTRUCTURE_METRICS:
		_1905_notify_combined_infrastructure_metrics_query(ctx, ctx->p1905_al_mac_addr,
			request->dest_al_mac);
		break;
	default:
		err(DEBUG_CAT_EVENT, "unknown msg type 0x%04x\n", request->type);
		break;
	}

	return 0;
}


/*process event from 1905.1 library*/
int process_1905_request(struct p1905_managerd_ctx* ctx, struct _1905_cmdu_request* request)
{
	struct p1905_neighbor_info* dev_info = NULL;
	struct topology_response_db *tpgr_db = NULL;
	unsigned int i = 0, j = 0;
	int ifidx = -1;
	unsigned char al_multi_address[6] = { 0x01, 0x80, 0xc2, 0x00, 0x00, 0x13 };
#ifdef MAP_R2
	unsigned char all_agent_mac[ETH_ALEN] = { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff };
#endif
#ifdef MAP_R3
	struct agent_list_db *agent_info = NULL;
	struct r3_member *peer = NULL;
#endif
	unsigned char need_update_mid = 0;
	unsigned char zero_mac[6] = {0};
	unsigned char *if_name = NULL;
	struct radio_info *r = NULL;
	unsigned char band = 0;

	if (memcmp(al_multi_address, request->dest_al_mac, ETH_ALEN)) {
		for (i = 0; i < ctx->itf_number; i++) {
			LIST_FOREACH(dev_info, &(ctx->p1905_neighbor_dev[i].p1905nbr_head), p1905nbr_entry) {
				if (!memcmp(dev_info->al_mac_addr, request->dest_al_mac, ETH_ALEN)) {
					ifidx = i;
					break;
				}
			}
		}
		if (ifidx == -1) {
			SLIST_FOREACH(tpgr_db, &(ctx->topology_entry.tprdb_head), tprdb_entry) {
				if (!memcmp(request->dest_al_mac, tpgr_db->al_mac_addr, ETH_ALEN)) {
					ifidx = tpgr_db->recv_ifid;
					break;
				}
			}
		}
		if (ifidx == -1) {
			debug(DEBUG_CAT_EVENT, "almac "MACSTR" not in topo db; tx to brige; mtype=0x%04x(%s)\n",
				MAC2STR(request->dest_al_mac), request->type, get_1905_mtype_str(request->type));
			if_name = ctx->br_name;
		} else {
			if_name = ctx->itf[ifidx].if_name;
		}
	} else {
		if_name = ctx->br_name;
	}

	/*below code for DEV_SEND_1905 length==0, so 1905 must build the content of 1905 cmdu*/
	switch (request->type) {
		case TOPOLOGY_DISCOVERY:
			ctx->mid++;
			multicast_cmdu_tx(ctx, e_topology_discovery, ctx->mid, 0);
			break;
		case TOPOLOGY_NOTIFICATION:
			ctx->mid++;
			multicast_cmdu_tx(ctx, e_topology_notification, ctx->mid, 1);
			break;
		case TOPOLOGY_QUERY:
			 /* if a AP want to send unicast cmdu to STA, it needs to use interface mac
		   	   * instead of AL mac address
		  	   */
	        insert_cmdu_txq(request->dest_al_mac, ctx->p1905_al_mac_addr,
	                e_topology_query, ++ctx->mid,
	                if_name, need_update_mid);
			break;
		case AP_CAPABILITY_QUERY:
			 /* if a AP want to send unicast cmdu to STA, it needs to use interface mac
			   * instead of AL mac address
			   */
			insert_cmdu_txq(request->dest_al_mac, ctx->p1905_al_mac_addr,
					e_ap_capability_query, ++ctx->mid,
					if_name, need_update_mid);
			break;
		case CHANNEL_PREFERENCE_QUERY:
			insert_cmdu_txq(request->dest_al_mac, ctx->p1905_al_mac_addr,
				e_channel_preference_query, ++ctx->mid,
				if_name, need_update_mid);
			break;
		case COMBINED_INFRASTRUCTURE_METRICS:
			if (fill_send_tlv(ctx, request->body, request->len) < 0) {
				err(DEBUG_CAT_EVENT, "[COMBINED_INFRASTRUCTURE_METRICS]fill_send_tlv fail");
				break;
			}
			need_update_mid = 1;
	        insert_cmdu_txq(request->dest_al_mac, ctx->p1905_al_mac_addr,
			e_combined_infrastructure_metrics, ctx->dev_send_1905_mid,
	                if_name, need_update_mid);
			break;
		case LINK_METRICS_QUERY:
			memcpy(ctx->link_metric_query_para.target, request->body, ETH_ALEN);
			memcpy(&(ctx->link_metric_query_para.type), request->body + ETH_ALEN, sizeof(unsigned char));
			insert_cmdu_txq(request->dest_al_mac, ctx->p1905_al_mac_addr,
	                e_link_metric_query, ++ctx->mid,
	                if_name, need_update_mid);
			break;
		case AP_AUTOCONFIG_SEARCH:
			if(ctx->controller_search_state != controller_search_idle ||
				ctx->enrolle_state != no_ap_autoconfig) {
				notice(DEBUG_CAT_AUTOCONF, "autoconfig is ongoing, drop this autoconfig search\n");
				break;
			}
#ifdef MAP_R3
			reset_send_tlv(ctx);
			if(fill_send_tlv(ctx, request->body, request->len) < 0)
			{
				break;
			}
#endif // MAP_R3
			ctx->autoconfig_search_mid = ++ctx->mid;
			for(j = 0; j < ctx->itf_number; j++) {
				if ((ctx->itf[j].is_wifi_sta && os_memcmp(ctx->itf[j].vs_info, zero_mac, 6)) ||
					(ctx->itf[j].media_type <= IEEE802_3_AB_GROUP)) {
					r = get_rainfo_by_id(ctx, ctx->itf[j].identifier);
					if (r) {
						if (r->band & BAND_2G_CAP)
							band = IEEE802_11_band_2P4G;
						else if (r->band & BAND_5G_CAP)
							band = IEEE802_11_band_5GL;
						else if (r->band & BAND_6G_CAP)
							band = 0xFF;
					} else
						band = IEEE802_11_band_2P4G;
					reset_send_tlv(ctx);
					fill_send_tlv(ctx, &band, 1);
					notice(DEBUG_CAT_MSG, "send search on %s; mid=0x%04x\n",
						ctx->itf[j].if_name,
						ctx->autoconfig_search_mid);
					insert_cmdu_txq(al_multi_address, ctx->p1905_al_mac_addr,
						e_ap_autoconfiguration_search, ctx->autoconfig_search_mid,
						ctx->itf[j].if_name, need_update_mid);
#ifdef SUPPORT_CMDU_RELIABLE
					cmdu_reliable_send(ctx, e_ap_autoconfiguration_search,
						ctx->autoconfig_search_mid, j);
#endif
					process_cmdu_txq(ctx, ctx->trx_buf.buf);
				}
			}
			break;
		case AP_AUTOCONFIG_RENEW:
			if (fill_send_tlv(ctx, request->body, request->len) < 0) {
				err(DEBUG_CAT_EVENT, "[AP_AUTOCONFIG_RENEW]fill_send_tlv fail");
				break;
			}
			ctx->mid++;
			multicast_cmdu_tx(ctx, e_ap_autoconfiguration_renew, ctx->mid, 1);
			break;
		case CLIENT_CAPABILITY_QUERY:
		{
			struct client_info *cinfo = NULL;

			cinfo = (struct client_info *)ctx->send_tlv;
			memcpy(cinfo->bssid, request->body, ETH_ALEN);
			memcpy(cinfo->sta_mac, request->body + ETH_ALEN, ETH_ALEN);
			ctx->send_tlv_len = sizeof(struct client_info);
			insert_cmdu_txq(request->dest_al_mac, ctx->p1905_al_mac_addr,
					e_cli_capability_query, ++ctx->mid,
					if_name, need_update_mid);
		}
			break;
		case AP_LINK_METRICS_QUERY:
			if (fill_send_tlv(ctx, request->body, request->len) < 0) {
				err(DEBUG_CAT_EVENT, "[AP_LINK_METRICS_QUERY]fill_send_tlv fail");
				break;
			}
			insert_cmdu_txq(request->dest_al_mac, ctx->p1905_al_mac_addr,
					e_ap_metrics_query, ++ctx->mid,
					if_name, need_update_mid);
			break;
		case ASSOC_STA_LINK_METRICS_QUERY:
			if (fill_send_tlv(ctx, request->body, request->len) < 0) {
				err(DEBUG_CAT_EVENT, "[ASSOC_STA_LINK_METRICS_QUERY]fill_send_tlv fail");
				break;
			}
			insert_cmdu_txq(request->dest_al_mac, ctx->p1905_al_mac_addr,
	                e_associated_sta_link_metrics_query, ++ctx->mid,
	                if_name, need_update_mid);
			break;
		case UNASSOC_STA_LINK_METRICS_QUERY:
			if (fill_send_tlv(ctx, request->body, request->len) < 0) {
				err(DEBUG_CAT_EVENT, "[UNASSOC_STA_LINK_METRICS_QUERY]fill_send_tlv fail");
				break;
			}
			insert_cmdu_txq(request->dest_al_mac, ctx->p1905_al_mac_addr,
	                e_unassociated_sta_link_metrics_query, ++ctx->mid,
	                if_name, need_update_mid);
			break;
		case BEACON_METRICS_QUERY:
			if (fill_send_tlv(ctx, request->body, request->len) < 0) {
				err(DEBUG_CAT_EVENT, "[BEACON_METRICS_QUERY]fill_send_tlv fail");
				break;
			}
			insert_cmdu_txq(request->dest_al_mac, ctx->p1905_al_mac_addr,
	                e_beacon_metrics_query, ++ctx->mid,
	                if_name, need_update_mid);
			break;
		case CLIENT_STEERING_REQUEST:
			if (fill_send_tlv(ctx, request->body, request->len) < 0) {
				err(DEBUG_CAT_EVENT, "[CLIENT_STEERING_REQUEST]fill_send_tlv fail");
				break;
			}
			insert_cmdu_txq(request->dest_al_mac, ctx->p1905_al_mac_addr,
	                e_client_steering_request, ++ctx->mid,
	                if_name, need_update_mid);
			break;
		case CLIENT_ASSOC_CONTROL_REQUEST:
			if (fill_send_tlv(ctx, request->body, request->len) < 0) {
				err(DEBUG_CAT_EVENT, "[CLIENT_ASSOC_CONTROL_REQUEST]fill_send_tlv fail");
				break;
			}
			insert_cmdu_txq(request->dest_al_mac, ctx->p1905_al_mac_addr,
	                e_client_association_control_request, ++ctx->mid,
	                if_name, need_update_mid);
			break;
		case HIGHER_LAYER_DATA_MESSAGE:
			if (fill_send_tlv(ctx, request->body, request->len) < 0) {
				err(DEBUG_CAT_EVENT, "[HIGHER_LAYER_DATA_MESSAGE]fill_send_tlv fail");
				break;
			}
			insert_cmdu_txq(request->dest_al_mac, ctx->p1905_al_mac_addr,
	                e_higher_layer_data, ++ctx->mid,
	                if_name, need_update_mid);
			break;
		case BACKHAUL_STEERING_REQUEST:
			if (fill_send_tlv(ctx, request->body, request->len) < 0) {
				err(DEBUG_CAT_EVENT, "[BACKHAUL_STEERING_REQUEST]fill_send_tlv fail");
				break;
			}
			insert_cmdu_txq(request->dest_al_mac, ctx->p1905_al_mac_addr,
	                e_backhaul_steering_request, ++ctx->mid,
	                if_name, need_update_mid);
			break;
		case CHANNEL_SELECTION_REQUEST:
			if (fill_send_tlv(ctx, request->body, request->len) < 0) {
				err(DEBUG_CAT_EVENT, "[CHANNEL_SELECTION_REQUEST]fill_send_tlv fail");
				break;
			}
			insert_cmdu_txq(request->dest_al_mac, ctx->p1905_al_mac_addr,
	                e_channel_selection_request, ++ctx->mid,
	                if_name, need_update_mid);
			break;
		case MAP_POLICY_CONFIG_REQUEST:
			if (fill_send_tlv(ctx, request->body, request->len) < 0) {
				err(DEBUG_CAT_EVENT, "[MAP_POLICY_CONFIG_REQUEST]fill_send_tlv fail");
				break;
			}
			insert_cmdu_txq(request->dest_al_mac, ctx->p1905_al_mac_addr,
	                e_multi_ap_policy_config_request, ++ctx->mid,
	                if_name, need_update_mid);
			break;
		case VENDOR_SPECIFIC:
			if (fill_send_tlv(ctx, request->body, request->len) < 0) {
				err(DEBUG_CAT_EVENT, "[VENDOR_SPECIFIC]fill_send_tlv fail");
				break;
			}
			insert_cmdu_txq(request->dest_al_mac, ctx->p1905_al_mac_addr,
	                e_vendor_specific, ++ctx->mid,
	                if_name, need_update_mid);
			break;

#ifdef MAP_R2
		/*channel scan feature*/
		case CHANNEL_SCAN_REQUEST:
			if (fill_send_tlv(ctx, request->body, request->len) < 0) {
				err(DEBUG_CAT_EVENT, "[CHANNEL_SCAN_REQUEST]fill_send_tlv fail");
				break;
			}
			insert_cmdu_txq(request->dest_al_mac, ctx->p1905_al_mac_addr,
	                e_channel_scan_request, ++ctx->mid,
	               if_name, need_update_mid);
			break;
		case CHANNEL_SCAN_REPORT:
			if (fill_send_tlv(ctx, request->body, request->len) < 0) {
				err(DEBUG_CAT_EVENT, "[CHANNEL_SCAN_REPORT]fill_send_tlv fail");
				break;
			}
			insert_cmdu_txq(request->dest_al_mac, ctx->p1905_al_mac_addr,
					e_channel_scan_report, ++ctx->mid,
					if_name, need_update_mid);
			break;

		case TUNNELED_MESSAGE:
			if (fill_send_tlv(ctx, request->body, request->len) < 0) {
				err(DEBUG_CAT_EVENT, "[TUNNELED_MESSAGE]fill_send_tlv fail");
				break;
			}
			insert_cmdu_txq(request->dest_al_mac, ctx->p1905_al_mac_addr,
					e_tunneled_message, ++ctx->mid,
					if_name, need_update_mid);
			break;
		case ASSOCIATION_STATUS_NOTIFICATION:
			if (fill_send_tlv(ctx, request->body, request->len) < 0) {
				err(DEBUG_CAT_EVENT, "[ASSOCIATION_STATUS_NOTIFICATION]fill_send_tlv fail");
				break;
			}
			ctx->mid++;
			if (0 == memcmp(all_agent_mac, request->dest_al_mac, ETH_ALEN)) {
				multicast_cmdu_tx(ctx, e_association_status_notification, ctx->mid, 1);
			} else {
				insert_cmdu_txq(request->dest_al_mac, ctx->p1905_al_mac_addr,
					e_association_status_notification, ctx->mid,
					if_name, need_update_mid);
			}
			break;
	    case CAC_REQUEST:
			if (fill_send_tlv(ctx, request->body, request->len) < 0) {
				err(DEBUG_CAT_EVENT, "[CAC_REQUEST]fill_send_tlv fail");
				break;
			}
		    insert_cmdu_txq(request->dest_al_mac, ctx->p1905_al_mac_addr,
				    e_cac_request, ++ctx->mid,
				    if_name, need_update_mid);
		    break;

		case CAC_TERMINATION:
			if (fill_send_tlv(ctx, request->body, request->len) < 0) {
				err(DEBUG_CAT_EVENT, "[CAC_TERMINATION]fill_send_tlv fail");
				break;
			}
			insert_cmdu_txq(request->dest_al_mac, ctx->p1905_al_mac_addr,
					e_cac_termination, ++ctx->mid,
					if_name, need_update_mid);
			break;
		case CLIENT_DISASSOCIATION_STATS:
			if (fill_send_tlv(ctx, request->body, request->len) < 0) {
				err(DEBUG_CAT_EVENT, "[CLIENT_DISASSOCIATION_STATS]fill_send_tlv fail");
				break;
			}
			insert_cmdu_txq(request->dest_al_mac, ctx->p1905_al_mac_addr,
					e_client_disassociation_stats, ++ctx->mid,
					if_name, need_update_mid);
			break;

		case FAILED_CONNECTION_MESSAGE:
			if (fill_send_tlv(ctx, request->body, request->len) < 0) {
				err(DEBUG_CAT_EVENT, "[FAILED_CONNECTION_MESSAGE]fill_send_tlv fail");
				break;
			}
			insert_cmdu_txq(request->dest_al_mac, ctx->p1905_al_mac_addr,
					e_failed_connection_message, ++ctx->mid,
					if_name, need_update_mid);
			break;
		case BACKHAUL_STA_CAP_QUERY_MESSAGE:
			insert_cmdu_txq(request->dest_al_mac, ctx->p1905_al_mac_addr,
					e_backhual_sta_cap_query_message, ++ctx->mid,
					if_name, need_update_mid);
			break;

#endif // #ifdef MAP_R2

#ifdef MAP_R3
		case PROXIED_ENCAP_DPP_MESSAGE:
		{
#ifndef EM_PLUS_SUPPORT
			unsigned char send_flag = 0;
#endif /* EM_PLUS_SUPPORT */

			if(fill_send_tlv(ctx, request->body, request->len) < 0)
				break;

#ifdef EM_PLUS_SUPPORT
			if (os_memcmp(ctx->cinfo.almac, request->dest_al_mac, ETH_ALEN) == 0
				|| os_memcmp(all_agent_mac, request->dest_al_mac, ETH_ALEN) == 0) {
				info(DEBUG_CAT_DPP, "send 0x8029(PROXIED_ENCAP_DPP_MESSAGE) to Controller"MACSTR"\n",
								MAC2STR(ctx->cinfo.almac));
				insert_cmdu_txq(ctx->cinfo.almac, ctx->p1905_al_mac_addr,
						e_proxied_encap_dpp, ++ctx->mid,
						ctx->itf[ctx->cinfo.recv_ifid].if_name,
						need_update_mid);
			} else {
				notice(DEBUG_CAT_DPP, "peer "MACSTR" is not Controller/multicast\n"
					", can not send proxied encap dpp msg\n", MAC2STR(request->dest_al_mac));
			}
#else
			if (0 == memcmp(all_agent_mac, request->dest_al_mac, ETH_ALEN)) {
				dl_list_for_each(peer, &r3_member_head, struct r3_member, entry) {
					send_flag = 0;
					if ((peer->r3_info.cur_dpp_state == dpp_disc_suc) &&
					    ((ctx->role == CONTROLLER) || (peer->role == CONTROLLER)))
						send_flag = 1;

					if (send_flag) {
						info(DEBUG_CAT_DPP, "send 0x8029(PROXIED_ENCAP_DPP_MESSAGE) to "MACSTR"\n",
						    MAC2STR(peer->al_mac));
						insert_cmdu_txq(peer->al_mac, ctx->p1905_al_mac_addr,
						    e_proxied_encap_dpp, ++ctx->mid,
						    if_name,
						    need_update_mid);
					} else
						notice(DEBUG_CAT_DPP, "peer "MACSTR" not R3 onboarded\n"
						    ", can not send proxied encap dpp msg\n", MAC2STR(peer->al_mac));
				}
			} else {
				peer = get_r3_member(request->dest_al_mac);
				if (peer && (peer->r3_info.cur_dpp_state == dpp_disc_suc) &&
					((ctx->role == CONTROLLER) || (peer->role == CONTROLLER)))
					send_flag = 1;

				if (send_flag) {
					notice(DEBUG_CAT_DPP, "send 0x8029(PROXIED_ENCAP_DPP_MESSAGE) to "MACSTR"\n",
					    MAC2STR(request->dest_al_mac));
					insert_cmdu_txq(request->dest_al_mac, ctx->p1905_al_mac_addr,
					    e_proxied_encap_dpp, ++ctx->mid,
					    if_name,
					    need_update_mid);
				}
				else {
					notice(DEBUG_CAT_DPP, "peer "MACSTR" not R3 onboarded\n"
					    ", can not send proxied encap dpp msg\n", MAC2STR(request->dest_al_mac));
				}
			}
#endif /* EM_PLUS_SUPPORT */

		}
		break;

		case DIRECT_ENCAP_DPP_MESSAGE:
		{
			char frame_str[36] = {0};

			reset_send_tlv(ctx);
			if(fill_send_tlv(ctx, request->body, request->len) < 0)
				break;
			ctx->mid++;

			/* first 3 bytes: one byte tlv 0xD1 and 2 bytes length */
			if (request->body[3] == 0x09)
				(void)os_snprintf(frame_str, sizeof(frame_str), "%s", actionFrame_typeNum2str(request->body[9]));
			else
				(void)os_snprintf(frame_str, sizeof(frame_str), "%s", GasFrame_actionNum2str(request->body[3]));

			if (0 == memcmp(all_agent_mac, request->dest_al_mac, ETH_ALEN)) {
				SLIST_FOREACH(agent_info, &(ctx->agent_head), agent_entry)
				{
					notice(DEBUG_CAT_DPP, "send 0x802A(DIRECT_ENCAP_DPP_MESSAGE) with %s to "MACSTR"\n",
								frame_str, MAC2STR(agent_info->almac));
					insert_cmdu_txq(agent_info->almac, ctx->p1905_al_mac_addr,
						e_direct_encap_dpp, ctx->mid,
						ctx->br_name, need_update_mid);
				}
			}
			else {
				notice(DEBUG_CAT_DPP, "send 0x802A(DIRECT_ENCAP_DPP_MESSAGE) with %s to "MACSTR"\n",
							frame_str, MAC2STR(request->dest_al_mac));
				insert_cmdu_txq(request->dest_al_mac, ctx->p1905_al_mac_addr,
					e_direct_encap_dpp, ctx->mid,
					ctx->br_name, need_update_mid);
			}
		}
		break;

		case CHIRP_NOTIFICATION_MESSAGE:
		{
			reset_send_tlv(ctx);
			if(fill_send_tlv(ctx, request->body, request->len) < 0)
				break;

#ifdef EM_PLUS_SUPPORT
			if (os_memcmp(ctx->cinfo.almac, request->dest_al_mac, ETH_ALEN) == 0
				|| os_memcmp(all_agent_mac, request->dest_al_mac, ETH_ALEN) == 0) {

				notice(DEBUG_CAT_DPP, "send 0x802F(CHIRP_NOTIFICATION_MESSAGE) to Controller "MACSTR"\n",
							MAC2STR(ctx->cinfo.almac));
				insert_cmdu_txq(ctx->cinfo.almac, ctx->p1905_al_mac_addr,
					e_chirp_notification, ++ctx->mid,
					ctx->itf[ctx->cinfo.recv_ifid].if_name, need_update_mid);
			} else {
				notice(DEBUG_CAT_DPP, "peer "MACSTR" is not Controller/multicast\n"
					", can not send CHIRP_NOTIFICATION_MESSAGE\n", MAC2STR(request->dest_al_mac));
			}
#else
			if (0 == memcmp(all_agent_mac, request->dest_al_mac, ETH_ALEN)) {
				/* send to all agents */
				if (ctx->role == CONTROLLER) {
					SLIST_FOREACH(agent_info, &(ctx->agent_head), agent_entry) {
						notice(DEBUG_CAT_DPP, "send 0x802F(CHIRP_NOTIFICATION_MESSAGE) to "MACSTR"\n",
									MAC2STR(agent_info->almac));
						insert_cmdu_txq(agent_info->almac, ctx->p1905_al_mac_addr,
							e_chirp_notification, ++ctx->mid, if_name, need_update_mid);
					}
				}
				/* send to controller */
				else {
					notice(DEBUG_CAT_DPP, "send 0x802F(CHIRP_NOTIFICATION_MESSAGE) to Controller "MACSTR"\n",
								MAC2STR(ctx->cinfo.almac));
					insert_cmdu_txq(ctx->cinfo.almac, ctx->p1905_al_mac_addr,
						e_chirp_notification, ++ctx->mid,
						ctx->itf[ctx->cinfo.recv_ifid].if_name, need_update_mid);
				}
			}
			else {
				notice(DEBUG_CAT_DPP, "send 0x802F(CHIRP_NOTIFICATION_MESSAGE) to "MACSTR"\n",
							MAC2STR(request->dest_al_mac));
				insert_cmdu_txq(request->dest_al_mac, ctx->p1905_al_mac_addr,
					e_chirp_notification, ++ctx->mid, if_name, need_update_mid);
			}
#endif /* EM_PLUS_SUPPORT */
		}
        break;

		case DPP_BOOTSTRAPING_URI_NOTIFICATION:
		{
			reset_send_tlv(ctx);
			if(fill_send_tlv(ctx, request->body, request->len) < 0)
				break;

			if (ctx->role != CONTROLLER) {
				notice(DEBUG_CAT_DPP, "send 0x8031(CHIRP_NOTIFICATION_MESSAGE) to Controller "MACSTR"\n",
							MAC2STR(ctx->cinfo.almac));
				insert_cmdu_txq(ctx->cinfo.almac, ctx->p1905_al_mac_addr,
					e_dpp_bootstrapping_uri_notification, ++ctx->mid,
					ctx->itf[ctx->cinfo.recv_ifid].if_name, need_update_mid);
			}
		}
		break;

		case DPP_BOOTSTRAPING_URI_QUERY:
			notice(DEBUG_CAT_DPP, "send 0x8032(DPP_BOOTSTRAPING_URI_QUERY) message to "MACSTR"\n",
				MAC2STR(request->dest_al_mac));
			insert_cmdu_txq(request->dest_al_mac, ctx->p1905_al_mac_addr,
				e_dpp_bootstrapping_uri_query, ++ctx->mid, if_name, need_update_mid);
		break;

		case DPP_CCE_INDICATION_MESSAGE:
		{
			unsigned char send_flag = 0;

			reset_send_tlv(ctx);
			if(fill_send_tlv(ctx, request->body, request->len) < 0)
				break;
			ctx->mid++;

			if (0 == memcmp(all_agent_mac, request->dest_al_mac, ETH_ALEN)) {
				SLIST_FOREACH(agent_info, &(ctx->agent_head), agent_entry)
				{
					peer = get_r3_member(agent_info->almac);
					/* controller send pkt to agent which onboarded */
					if (ctx->role == CONTROLLER) {
						if (get_agent_all_radio_config_state(agent_info)) {
							send_flag = 0;
							notice(DEBUG_CAT_DPP, "peer R1/R2 onboarded\n");
						}

						if (peer && peer->r3_info.cur_dpp_state == dpp_disc_suc) {
							send_flag = 1;
							notice(DEBUG_CAT_DPP, "peer R3 onboarded\n");
						}
					}
					else {
						/* agent, send directly */
						send_flag = 1;
					}

					if (send_flag) {
						notice(DEBUG_CAT_DPP, "send 0x801D(DPP_CCE_INDICATION_MESSAGE) to "MACSTR"\n",
									MAC2STR(agent_info->almac));
						insert_cmdu_txq(agent_info->almac, ctx->p1905_al_mac_addr,
							e_dpp_cce_indication, ctx->mid, if_name, need_update_mid);
					}
					else {
						notice(DEBUG_CAT_DPP, "peer "MACSTR" not onboarded"
							", can not send dpp cce indication\n", MAC2STR(agent_info->almac));
					}
				}
			}
			else {
				find_agent_info(ctx, request->dest_al_mac, &agent_info);
				peer = get_r3_member(request->dest_al_mac);
				/* controller send pkt to agent which onboarded */
				if (ctx->role == CONTROLLER) {
					notice(DEBUG_CAT_DPP, "controller check to send the DPP CCE indication\n");
					if (agent_info && get_agent_all_radio_config_state(agent_info)) {
						send_flag = 1;
						notice(DEBUG_CAT_DPP, "peer R1/R2 onboarded\n");
					}

					if (peer && peer->r3_info.cur_dpp_state == dpp_disc_suc) {
						send_flag = 1;
						notice(DEBUG_CAT_DPP, "peer R3 onboarded\n");
					}
				}
				else {
					/* agent, send directly */
					send_flag = 1;
				}

				if (send_flag) {
					notice(DEBUG_CAT_DPP, "send 0x801D(DPP_CCE_INDICATION_MESSAGE) to "MACSTR"\n",
								MAC2STR(request->dest_al_mac));
					insert_cmdu_txq(request->dest_al_mac, ctx->p1905_al_mac_addr,
						e_dpp_cce_indication, ctx->mid, if_name, need_update_mid);
				}
				else {
					notice(DEBUG_CAT_DPP, "peer "MACSTR" not onboarded\n"
						", can not send dpp cce indication\n", MAC2STR(request->dest_al_mac));
				}
			}
		}
		break;

#endif // MAP_R3
		case SERVICE_PRIORITIZATION_REQUEST:
		{
			notice(DEBUG_CAT_SP, "send SERVICE_PRIORITIZATION_REQUEST message to "MACSTR"\n",
				PRINT_MAC(request->dest_al_mac));

			if (fill_send_tlv(ctx, request->body, request->len) < 0) {
				warn(DEBUG_CAT_SP, "fail to fill_send_tlv\n");
				break;
			}

			insert_cmdu_txq(request->dest_al_mac, ctx->p1905_al_mac_addr,
					e_service_prioritization_request_4_t2lm_conf, ++ctx->mid,
					if_name, need_update_mid);
		}
		break;
		default:
			err(DEBUG_CAT_EVENT, "unknown msg type 0x%04x\n", request->type);
			break;
	}
	return 0;
}

struct agent_list_db *insert_agent_info(struct p1905_managerd_ctx *ctx, unsigned char *almac)
{
	unsigned char is_found = 0;
	struct agent_list_db *agent_info = NULL;

	SLIST_FOREACH(agent_info, &(ctx->agent_head), agent_entry)
	{
		if (!memcmp(agent_info->almac, almac, ETH_ALEN)) {
			is_found = 1;
			break;
		}
	}

	if (is_found)
		return agent_info;

	agent_info = (struct agent_list_db *)malloc(sizeof(struct agent_list_db));
	if (!agent_info) {
		err(DEBUG_CAT_MISC, "alloc struct agent_list_db fail\n");
		return NULL;
	}

	notice(DEBUG_CAT_AUTOCONF, "insert new agent; almac="MACSTR";"
		" expire_wait_time=%d; bss_prio_sync=1\n",
		MAC2STR(almac), AGENT_EXPIRE_WAIT_TIME);
	memset(agent_info, 0, sizeof(struct agent_list_db));
	memcpy(agent_info->almac, almac, ETH_ALEN);
	agent_info->expire_wait_time = AGENT_EXPIRE_WAIT_TIME;
	agent_info->bss_prio_sync = 1;
	SLIST_INIT(&(agent_info->ch_prefer_head));
	SLIST_INIT(&(agent_info->oper_restrict_head));
	SLIST_INIT(&(agent_info->metrics_rsp_head));
	SLIST_INIT(&(agent_info->tx_metrics_head));
	SLIST_INIT(&(agent_info->rx_metrics_head));

	SLIST_INSERT_HEAD(&(ctx->agent_head), agent_info, agent_entry);
	dl_list_init(&agent_info->mld_cfg.mlo_cfg_list);
#ifdef MAP_R2
	SLIST_INIT(&agent_info->ts_cap_head);
#endif
#ifdef MAP_R6
	dl_list_init(&agent_info->bsta_mld.affiliated_sta_list);
#endif
	return agent_info;

}

void delete_agent_info(struct agent_list_db *agent_info)
{
	delete_all_ch_prefer_info((struct list_head_ch_prefer *)&agent_info->ch_prefer_head);
	delete_all_radio_oper_restrict_info((struct list_head_oper_restrict *)&agent_info->oper_restrict_head);
	delete_agent_ap_metrics_info(&agent_info->metrics_rsp_head);
	delete_agent_tx_link_metrics_info(&agent_info->tx_metrics_head);
	delete_agent_rx_link_metrics_info(&agent_info->rx_metrics_head);
#ifdef MAP_R2
	delete_agent_ts_cap_info(&agent_info->ts_cap_head);
#endif
	delete_ap_mld_conf(&agent_info->mld_cfg);
#ifdef MAP_R6
	delete_bsta_mld_conf(&agent_info->bsta_mld);
#endif
}


struct agent_radio_info *insert_agent_radio_info(struct agent_list_db *agent, unsigned char *id)
{
	if (agent->radio_num == MAX_RADIO_NUM) {
		err(DEBUG_CAT_AUTOCONF, "current radio num is MAX_RADIO_NUM(%d); "
			"can't insert raid "MACSTR"\n", MAX_RADIO_NUM, MAC2STR(id));
		return NULL;
	} else {
		os_memset(&agent->ra_info[agent->radio_num], 0, sizeof(struct agent_radio_info));
		os_memcpy(agent->ra_info[agent->radio_num].identifier, id, ETH_ALEN);
		agent->radio_num++;
		return &agent->ra_info[agent->radio_num - 1];
	}
}

struct agent_radio_info *find_agent_radio_info(struct agent_list_db *agent, unsigned char *id)
{
	struct agent_radio_info *r = NULL;
	int i = 0;

	for (i = 0; i < agent->radio_num; i++) {
		if (!os_memcmp(agent->ra_info[i].identifier, id, ETH_ALEN)) {
			r = &agent->ra_info[i];
			break;
		}
	}

	return r;
}

int update_agent_radio_info(struct agent_list_db *agent, struct agent_radio_info *r)
{
	struct agent_radio_info *org = NULL;

	org = find_agent_radio_info(agent, r->identifier);
	if (!org)
		org = insert_agent_radio_info(agent, r->identifier);

	if (org) {
		org->band = r->band;
		org->max_bss_num = r->max_bss_num;
		org->op_class_num = r->op_class_num;
	}

	return 0;
}

void find_agent_info(struct p1905_managerd_ctx *ctx,
	unsigned char *almac, struct agent_list_db **agent)
{
	struct agent_list_db *agent_info = NULL;

	SLIST_FOREACH(agent_info, &(ctx->agent_head), agent_entry)
	{
		if (!memcmp(agent_info->almac, almac, ETH_ALEN)) {
			*agent = agent_info;
			break;
		}
	}

}

void set_agent_wsc_doing_radio(struct agent_list_db *agent, unsigned char *id)
{
	unsigned char i = 0;

	for (i = 0; i < agent->radio_num; i++) {
		if (!os_memcmp(agent->ra_info[i].identifier, id, ETH_ALEN))
			agent->ra_info[i].doing_wsc = 1;
		else
			agent->ra_info[i].doing_wsc = 0;
	}
}

unsigned char find_agent_wsc_doing_radio(struct agent_list_db *agent)
{
	unsigned char i = 0;

	for (i = 0; i < agent->radio_num; i++) {
		if (agent->ra_info[i].doing_wsc)
			return i;
	}

	return 0xff;
}

void clear_agent_all_radio_config_stat(struct agent_list_db *agent)
{
	unsigned char i = 0;

	for (i = 0; i < agent->radio_num; i++)
		agent->ra_info[i].conf_ctx.config_status = 0;
}

void config_agent_all_radio_config_stat(struct agent_list_db *agent)
{
	unsigned char i = 0;

	for (i = 0; i < agent->radio_num; i++)
		agent->ra_info[i].conf_ctx.config_status = 1;
}

void set_agent_radio_config_stat(struct agent_list_db *agent,
	unsigned char *radio_id, unsigned char state)
{
	unsigned char i = 0;

	for (i = 0; i < agent->radio_num; i++) {
		if (!os_memcmp(agent->ra_info[i].identifier, radio_id, ETH_ALEN))
			agent->ra_info[i].conf_ctx.config_status = state;
	}
}

/*
 * get radio config status
 * return:0-not been configured 1-configured
 */
int get_agent_all_radio_config_state(struct agent_list_db *agent)
{
	int i = 0;

	for (i = 0; i < agent->radio_num; i++) {
		if (!agent->ra_info[i].conf_ctx.config_status)
			return 0;
	}

	return 1;
}

int get_agent_total_config_bss_num(struct agent_list_db *agent)
{
	int i = 0;
	int total_num = 0;

	for (i = 0; i < agent->radio_num; i++)
		total_num += agent->ra_info[i].config_bss_num;

	return total_num;
}

int get_agent_total_bss_num(struct agent_list_db *agent)
{
	int i = 0;
	int total_num = 0;

	for (i = 0; i < agent->radio_num; i++)
		total_num += agent->ra_info[i].max_bss_num;

	return total_num;
}

int get_current_bss_num(struct p1905_managerd_ctx *ctx, unsigned char *almac)
{
	struct agent_list_db *agent_info = NULL;
	int total_bss_num = 0;

	/*add the number of bss in controller*/
	total_bss_num = ctx->block_bss_info.auto_config_num;

	SLIST_FOREACH(agent_info, &(ctx->agent_head), agent_entry)
	{
		if (almac && !memcmp(agent_info->almac, almac, ETH_ALEN))
			continue;
		if (agent_info->is_block == 1)
			continue;

		total_bss_num += get_agent_total_config_bss_num(agent_info);
	}

	return total_bss_num;
}

void clear_agent_config_bss_num(struct agent_list_db *agent)
{
	int i = 0;

	for (i = 0; i < agent->radio_num; i++)
		agent->ra_info[i].config_bss_num = 0;

}


int delete_agent_ch_prefer_info(struct p1905_managerd_ctx *ctx,
	struct agent_list_db *agent)
{
	struct ch_prefer_db *chcap = NULL, *chcap_tmp = NULL;
	struct prefer_info_db *prefer = NULL, *prefer_tmp = NULL;
	struct oper_restrict_db *restriction = NULL, *restriction_tmp = NULL;;
	struct restrict_db *resdb = NULL, *resdb_tmp = NULL;

	chcap = SLIST_FIRST(&(agent->ch_prefer_head));
	while (chcap != NULL) {
		chcap_tmp = SLIST_NEXT(chcap, ch_prefer_entry);
  	  	prefer = SLIST_FIRST(&(chcap->prefer_info_head));
    	while(prefer) {
        	prefer_tmp = SLIST_NEXT(prefer, prefer_info_entry);
       	 	free(prefer);
        	prefer = prefer_tmp;
    	}
		free(chcap);
		chcap = chcap_tmp;
	}
	SLIST_INIT(&(agent->ch_prefer_head));

	restriction = SLIST_FIRST(&(agent->oper_restrict_head));
	while (restriction != NULL) {
		restriction_tmp = SLIST_NEXT(restriction, oper_restrict_entry);
  	  	resdb = SLIST_FIRST(&(restriction->restrict_head));
    	while(resdb) {
        	resdb_tmp = SLIST_NEXT(resdb, restrict_entry);
       	 	free(resdb);
        	resdb = resdb_tmp;
    	}
		free(restriction);
		restriction = restriction_tmp;
	}
	SLIST_INIT(&(agent->oper_restrict_head));

	return 0;
}

int delete_all_radio_oper_restrict_info(struct list_head_oper_restrict *oper_restrict_head)
{
	struct oper_restrict_db *restriction = NULL, *restriction_tmp = NULL;
	struct restrict_db *resdb = NULL, *resdb_tmp = NULL;

	restriction = SLIST_FIRST(oper_restrict_head);
	while (restriction != NULL) {
		restriction_tmp = SLIST_NEXT(restriction, oper_restrict_entry);
		resdb = SLIST_FIRST(&(restriction->restrict_head));
		while (resdb) {
			resdb_tmp = SLIST_NEXT(resdb, restrict_entry);
			free(resdb);
			resdb = resdb_tmp;
		}
		free(restriction);
		restriction = restriction_tmp;
	}
	SLIST_INIT(oper_restrict_head);

	return wapp_utils_success;
}

int delete_agent_ap_metrics_info(struct list_head_metrics_rsp_agent *metrics_head)
{
	struct mrsp_db *mrsp = NULL, *mrsp_tmp = NULL;
	struct esp_db *esp = NULL, *esp_tmp = NULL;

	mrsp = SLIST_FIRST(metrics_head);
	while (mrsp != NULL) {
		mrsp_tmp = SLIST_NEXT(mrsp, mrsp_entry);
        esp = SLIST_FIRST(&mrsp->esp_head);
		while (esp) {
            esp_tmp = SLIST_NEXT(esp, esp_entry);
            free(esp);
            esp = esp_tmp;
        }
		free(mrsp);
		mrsp = mrsp_tmp;
    }
	SLIST_INIT(metrics_head);

	return wapp_utils_success;
}

int delete_agent_tx_link_metrics_info(struct list_head_tx_metrics_agent *tx_metrics_head)
{
	 struct tx_link_metric_db *tx_link_metric = NULL, *tx_link_metric_tmp = NULL;
	 struct tx_metric_db *tx_metric = NULL, *tx_metric_tmp = NULL;

	tx_link_metric = SLIST_FIRST(tx_metrics_head);
	while (tx_link_metric != NULL) {
		tx_link_metric_tmp = SLIST_NEXT(tx_link_metric, tx_link_metric_entry);
        tx_metric = SLIST_FIRST(&tx_link_metric->tx_metric_head);
		while (tx_metric) {
            tx_metric_tmp = SLIST_NEXT(tx_metric, tx_metric_entry);
            free(tx_metric);
            tx_metric = tx_metric_tmp;
        }
		free(tx_link_metric);
		tx_link_metric = tx_link_metric_tmp;
    }
	SLIST_INIT(tx_metrics_head);

	return wapp_utils_success;
}

int delete_agent_rx_link_metrics_info(struct list_head_rx_metrics_agent *rx_metrics_head)
{
	 struct rx_link_metric_db *rx_link_metric = NULL, *rx_link_metric_tmp = NULL;
	 struct rx_metric_db *rx_metric = NULL, *rx_metric_tmp = NULL;

	rx_link_metric = SLIST_FIRST(rx_metrics_head);
	while (rx_link_metric != NULL) {
		rx_link_metric_tmp = SLIST_NEXT(rx_link_metric, rx_link_metric_entry);
        rx_metric = SLIST_FIRST(&rx_link_metric->rx_metric_head);
		while (rx_metric) {
            rx_metric_tmp = SLIST_NEXT(rx_metric, rx_metric_entry);
            free(rx_metric);
            rx_metric = rx_metric_tmp;
        }
		rx_link_metric = rx_link_metric_tmp;
    }
	SLIST_INIT(rx_metrics_head);

	return wapp_utils_success;
}

int free_all_the_agents_info(struct list_head_agent *agent_head)
{
	struct agent_list_db *agent = SLIST_FIRST(agent_head);
	struct agent_list_db *agent_tmp = NULL;

	while(agent != NULL) {
		agent_tmp = SLIST_NEXT(agent, agent_entry);
		delete_agent_info(agent);
		os_free(agent);
		agent = agent_tmp;
	}
	SLIST_INIT(agent_head);

	return 0;
}

void show_1905_mapfilter_version(struct p1905_managerd_ctx* ctx)
{
	printf("Currrent 1905 verion %s\n", VERSION_1905);
	mapfilter_show_version();
}


void send_1905_raw_data(struct p1905_managerd_ctx* ctx, char *file)
{
	struct _1905_cmdu_request *request = (struct _1905_cmdu_request*)dev_send_1905_buf;

	if (_1905_read_dev_send_1905(ctx, file, request->dest_al_mac, &request->type,
			&request->len, request->body) < 0) {
		err(DEBUG_CAT_MISC, "parse raw data from %s fail\n", file);
		return;
	}
	dev_send_1905(ctx, request);
	process_cmdu_txq(ctx, ctx->trx_buf.buf);
}

void read_1905_bss_config(struct p1905_managerd_ctx *ctx, char *file)
{
	if (_1905_read_set_config(ctx, file, ctx->bss_config, MAX_SET_BSS_INFO_NUM, &ctx->bss_config_num) < 0)
		err(DEBUG_CAT_AUTOCONF, "load bss config fail from %s\n", file);
}

#ifdef SUPPORT_CMDU_RELIABLE
void cmdu_reliable_send(struct p1905_managerd_ctx *ctx, unsigned short msg_type,
		unsigned short mid, unsigned int ifidx)
{
	struct topology_response_db *tpr_db = NULL;
	unsigned char *if_name = NULL;

	SLIST_FOREACH(tpr_db, &ctx->topology_entry.tprdb_head, tprdb_entry)
	{
		/*relay this unicast message to all devices in the same topology*/
		if (tpr_db->recv_ifid == ifidx) {
			if_name = ctx->itf[ifidx].if_name;
			insert_cmdu_txq(tpr_db->al_mac_addr, ctx->p1905_al_mac_addr,
					msg_type, mid, if_name, 0);
			notice(DEBUG_CAT_MSG, "tx unicast to "MACSTR" on %s; type=%04x(%s); mid=%04x\n",
				MAC2STR(tpr_db->al_mac_addr), if_name, msg_type,
				get_1905_send_mtype_str(msg_type), mid);
		}
	}
}
#endif

int update_bss_prio_str(struct p1905_managerd_ctx *ctx,
	unsigned char *prio_str, unsigned short prio_str_len)
{
	int ret = 0;

	if (prio_str_len >= (MAX_RADIO_NUM * (IFNAMSIZ + 1) * MAX_BSS_NUM)) {
		err(DEBUG_CAT_AUTOCONF, "prio_str too long; str=%s\n",
			prio_str);
		return -1;
	}
	os_memset(ctx->bss_priority_str, 0, sizeof(ctx->bss_priority_str));
	ret = snprintf(ctx->bss_priority_str, prio_str_len, "%s", prio_str);
	if (os_snprintf_error(prio_str_len, ret)) {
		err(DEBUG_CAT_AUTOCONF, "snprintf fail!\n");
		return -1;
	}

	return 0;
}


void clear_all_agent_bss_prio(struct p1905_managerd_ctx *ctx)
{
	struct agent_list_db *agent_info = NULL;

	SLIST_FOREACH(agent_info, &ctx->agent_head, agent_entry) {
		agent_info->bss_prio_sync = 0;
	}
}

void sync_bss_prio_to_agent(void *eloop_ctx, void *data)
{
	struct agent_list_db *agent_info = NULL;
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx *)eloop_ctx;
	int ifid = 0;

	SLIST_FOREACH(agent_info, &ctx->agent_head, agent_entry) {
		if (!agent_info->bss_prio_sync) {
			ctx->mid++;
			ifid = get_ifid_by_almac(ctx, agent_info->almac);
			if (ifid == -1) {
				warn(DEBUG_CAT_AUTOCONF, "agent "MACSTR" not exist in topo rsp db; ignore\n",
					MAC2STR(agent_info->almac));
				continue;
			}
			notice(DEBUG_CAT_AUTOCONF, "send e_vendor_specific_bss_prio to "MACSTR"; "
				"mid=0x%04x, ifname=%s", MAC2STR(agent_info->almac),
				ctx->mid, ctx->itf[ifid].if_name);
			insert_cmdu_txq(agent_info->almac, ctx->p1905_al_mac_addr,
				e_vendor_specific_bss_prio, ctx->mid,
				ctx->itf[ifid].if_name, 0);
		}
	}

	if (!SLIST_EMPTY(&ctx->agent_head)) {
		eloop_register_timeout(BSS_PRIO_WAIT_TIME, 0, sync_bss_prio_to_agent,
			(void *)ctx, NULL);
	}
}

void sync_bss_prio_done(void *eloop_ctx, void *data)
{
	struct agent_list_db *agent_info = NULL;
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx *)eloop_ctx;
	int cnt = 0;

	eloop_cancel_timeout(sync_bss_prio_to_agent, ctx, NULL);

	SLIST_FOREACH(agent_info, &ctx->agent_head, agent_entry)
	{
		if (!agent_info->bss_prio_sync) {
			cnt++;
			err(DEBUG_CAT_AUTOCONF, "agent%d "MACSTR" do not finish bss priority sync\n",
				cnt, MAC2STR(agent_info->almac));
		}
	}

	if (!cnt)
		err(DEBUG_CAT_AUTOCONF, "all agents finish bss priority sync\n");
}

void set_bss_prio_for_agent(struct p1905_managerd_ctx *ctx, unsigned char *almac)
{
	struct agent_list_db *agent_info = NULL;

	SLIST_FOREACH(agent_info, &ctx->agent_head, agent_entry)
	{
		if (!os_memcmp(agent_info->almac, almac, ETH_ALEN)) {
			agent_info->bss_prio_sync = 1;
			break;
		}
	}
}

int check_all_agent_sync_bss_prio(struct p1905_managerd_ctx *ctx)
{
	struct agent_list_db *agent_info = NULL;

	SLIST_FOREACH(agent_info, &ctx->agent_head, agent_entry)
	{
		if (!agent_info->bss_prio_sync)
			return -1;
	}

	return 0;
}

int check_device_in_topo(struct p1905_managerd_ctx *ctx, unsigned char *almac)
{
	if (find_discovery_by_almac(ctx, almac) ||
		find_response_by_almac(ctx, almac))
		return 0;
	else
		return -1;
}

void check_and_delete_expired_agent(struct p1905_managerd_ctx *ctx, int sec)
{
	struct agent_list_db *agent_info = NULL, *agent_info_tmp = NULL;

	if (ctx->role != CONTROLLER)
		return;

	agent_info = SLIST_FIRST(&ctx->agent_head);
	while (agent_info) {
		agent_info_tmp = SLIST_NEXT(agent_info, agent_entry);
		if (agent_info->expire_wait_time <= 0) {
			if (check_device_in_topo(ctx, agent_info->almac)) {
				notice(DEBUG_CAT_TOPO, "time(%d) expired; del agent "MACSTR" not in topology\n",
					AGENT_EXPIRE_WAIT_TIME, MAC2STR(agent_info->almac));
				SLIST_REMOVE(&ctx->agent_head,
					     agent_info, agent_list_db, agent_entry);
				delete_agent_info(agent_info);
				os_free(agent_info);
			}
		} else {
			agent_info->expire_wait_time -= sec;
		}
		agent_info = agent_info_tmp;
	}

	if (SLIST_EMPTY(&ctx->agent_head)) {
		SLIST_INIT(&ctx->agent_head);
	}
}

static char *get_manage_cmd_str(int cmd)
{
	switch (cmd) {
	case MANAGE_SET_ROLE:
		return "MANAGE_SET_ROLE";
	case MANAGE_SET_LOG_LEVEL:
		return "MANAGE_SET_LOG_LEVEL";
	case MANAGE_GET_LOCAL_DEVINFO:
		return "MANAGE_GET_LOCAL_DEVINFO";
	case MANAGE_SET_BSS_CONF:
		return "MANAGE_SET_BSS_CONF";
	default:
		return "UNKNOWN_CMD";
	}
}

static void manage_cmd_process(struct p1905_managerd_ctx *ctx, struct manage_cmd *cmd)
{
#define REPLY_BUF_LEN 2048
	unsigned char *buf = NULL;
	size_t len = 0;
	unsigned short length = 0;

	buf = os_zalloc(REPLY_BUF_LEN);
	if (!buf) {
		err(DEBUG_CAT_MISC, "alloc buf_size(%d) fail\n", REPLY_BUF_LEN);
		return;
	}

	switch(cmd->cmd_id) {
	case MANAGE_SET_ROLE:
		if (change_role_dynamic(ctx, cmd->content[0]) < 0) {
			os_strncpy((char *)buf, "FAIL\n", 5);
			len = 5;
		} else {
			os_strncpy((char *)buf, "OK\n", 3);
			len = 3;
		}
		_1905_notify_raw_data(ctx, buf, len);
		break;
	case MANAGE_SET_LOG_LEVEL:
		break;
	case MANAGE_GET_LOCAL_DEVINFO:
		if (get_local_device_info(ctx, buf, REPLY_BUF_LEN, &length) < 0) {
			err(DEBUG_CAT_EVENT, "[MANAGE_GET_LOCAL_DEVINFO]get_local_device_info fail\n");
			break;
		}
		len = length;
		_1905_notify_raw_data(ctx, buf, len);
		eloop_register_timeout(1, 0, attach_action, (void *)ctx, NULL);
		break;
	case MANAGE_SET_BSS_CONF:
	{
		unsigned char oper = cmd->content[0];

		set_bss_config(ctx, oper, (struct bss_config_info *)(&cmd->content[1]));
	}
		break;
	default:
		break;
	}
	os_free(buf);
}

#ifdef EM_PLUS_SUPPORT
int update_radio_temperature(struct p1905_managerd_ctx *ctx,
	unsigned char *prio_str, unsigned short prio_str_len)
{
	struct radio_temperature *radio_temp = NULL;
	int i = 0, j = 0;
	u8 radio_cnt = 0;
	unsigned char *p;

	p = prio_str;
	if (prio_str_len < sizeof(char)) {
		err(DEBUG_CAT_EMPLUS, "radio temperatur buffer(%s) length is not enough\n", prio_str);
		return -1;
	}
	radio_cnt = *p;
	p += sizeof(char);
	prio_str_len -= sizeof(char);

	if (prio_str_len < sizeof(struct radio_temperature) * radio_cnt) {
		err(DEBUG_CAT_EMPLUS, "radio temperatur buffer(%s) length is not enough\n", prio_str);
		return -1;
	}
	radio_temp = (struct radio_temperature *)p;
	for (i = 0; i < radio_cnt && i < MAX_RADIO_NUM; i++) {
		for (j = 0; j < MAX_RADIO_NUM; j++) {
			if (os_memcmp(ctx->rinfo[j].identifier, radio_temp[i].identifier, ETH_ALEN) == 0)
				ctx->rinfo[j].temperature = radio_temp[i].temperature;
		}
	}
	return 0;
}
#endif

int update_t2lm_confirguration(struct p1905_managerd_ctx *ctx,
		unsigned char *buf, unsigned short len)
{
	struct sp_t2lm_request_lib *t2lm = (struct sp_t2lm_request_lib *)buf;
	struct sp_t2lm_db *t2lm_db = NULL, *t2lm_db_tmp = NULL;
	struct ap_t2lm_mapping_db *tlm_map = NULL, *tlm_map_tmp = NULL;
	int i, found_db = 0, found_map_db = 0;

	if (ctx->mlo_t2lm_db.num_mld == 0) {
		dl_list_init(&ctx->mlo_t2lm_db.t2lm_cfg_list);

		t2lm_db = (struct sp_t2lm_db *)os_zalloc(sizeof(struct sp_t2lm_db));

		t2lm_db->is_bsta_config = t2lm->is_bsta_config;
		t2lm_db->t2lm_negotiation = t2lm->t2lm_negotiation;
		t2lm_db->num_mapping = t2lm->num_mapping;
		os_memcpy(t2lm_db->mld_mac, t2lm->mld_mac, ETH_ALEN);
		dl_list_add_tail(&ctx->mlo_t2lm_db.t2lm_cfg_list, &t2lm_db->list);
		dl_list_init(&t2lm_db->ap_t2lm_mapping);

		for (i = 0; i < t2lm_db->num_mapping; i++) {
			tlm_map = (struct ap_t2lm_mapping_db *)os_zalloc(sizeof(struct ap_t2lm_mapping_db));

			tlm_map->add_remove = t2lm->ap_t2lm_mapping[i].add_remove;
			tlm_map->t2l_control = t2lm->ap_t2lm_mapping[i].t2l_control;
			tlm_map->lm_Presence_Indicator = t2lm->ap_t2lm_mapping[i].lm_Presence_Indicator;
			os_memcpy(tlm_map->expected_duration, t2lm->ap_t2lm_mapping[i].expected_duration, 3);
			os_memcpy(tlm_map->sta_ml_mac, t2lm->ap_t2lm_mapping[i].sta_ml_mac, ETH_ALEN);
			os_memcpy(tlm_map->t2lm, t2lm->ap_t2lm_mapping[i].t2lm, 2 * MAX_TID_PER_LINK);
			dl_list_add_tail(&t2lm_db->ap_t2lm_mapping, &tlm_map->list);
		}
		ctx->mlo_t2lm_db.num_mld++;
		return 0;
	}

	dl_list_for_each_safe(t2lm_db, t2lm_db_tmp, &ctx->mlo_t2lm_db.t2lm_cfg_list, struct sp_t2lm_db, list) {
		if (os_memcmp(t2lm_db->mld_mac, t2lm->mld_mac, ETH_ALEN))
			continue;
		found_db = 1;

		t2lm_db->is_bsta_config = t2lm->is_bsta_config;
		t2lm_db->t2lm_negotiation = t2lm->t2lm_negotiation;
		t2lm_db->num_mapping = t2lm->num_mapping;
		for (i = 0; i < t2lm_db->num_mapping; i++) {
			dl_list_for_each_safe(tlm_map, tlm_map_tmp, &t2lm_db->ap_t2lm_mapping, struct ap_t2lm_mapping_db, list) {
				if (os_memcmp(tlm_map->sta_ml_mac, t2lm->ap_t2lm_mapping[i].sta_ml_mac, ETH_ALEN))
					continue;
				found_map_db = 1;
				tlm_map->add_remove = t2lm->ap_t2lm_mapping[i].add_remove;
				tlm_map->t2l_control = t2lm->ap_t2lm_mapping[i].t2l_control;
				tlm_map->lm_Presence_Indicator = t2lm->ap_t2lm_mapping[i].lm_Presence_Indicator;
				os_memcpy(tlm_map->expected_duration, t2lm->ap_t2lm_mapping[i].expected_duration, 3);
				os_memcpy(tlm_map->t2lm, t2lm->ap_t2lm_mapping[i].t2lm, MAX_TID_PER_LINK);
				break;
			}
			if (found_map_db == 0) {
				tlm_map = (struct ap_t2lm_mapping_db *)os_zalloc(sizeof(struct ap_t2lm_mapping_db));

				tlm_map->add_remove = t2lm->ap_t2lm_mapping[i].add_remove;
				tlm_map->t2l_control = t2lm->ap_t2lm_mapping[i].t2l_control;
				tlm_map->lm_Presence_Indicator = t2lm->ap_t2lm_mapping[i].lm_Presence_Indicator;
				os_memcpy(tlm_map->expected_duration, t2lm->ap_t2lm_mapping[i].expected_duration, 3);
				os_memcpy(tlm_map->sta_ml_mac, t2lm->ap_t2lm_mapping[i].sta_ml_mac, ETH_ALEN);
				os_memcpy(tlm_map->t2lm, t2lm->ap_t2lm_mapping[i].t2lm, 2 * MAX_TID_PER_LINK);
				dl_list_add_tail(&t2lm_db->ap_t2lm_mapping, &tlm_map->list);
			}
		}
		break;
	}

	if (found_db == 0) {
		t2lm_db = (struct sp_t2lm_db *)os_zalloc(sizeof(struct sp_t2lm_db));

		t2lm_db->is_bsta_config = t2lm->is_bsta_config;
		t2lm_db->t2lm_negotiation = t2lm->t2lm_negotiation;
		t2lm_db->num_mapping = t2lm->num_mapping;
		os_memcpy(t2lm_db->mld_mac, t2lm->mld_mac, ETH_ALEN);
		dl_list_add_tail(&ctx->mlo_t2lm_db.t2lm_cfg_list, &t2lm_db->list);
		dl_list_init(&t2lm_db->ap_t2lm_mapping);

		for (i = 0; i < t2lm_db->num_mapping; i++) {
			tlm_map = (struct ap_t2lm_mapping_db *)os_zalloc(sizeof(struct ap_t2lm_mapping_db));

			tlm_map->add_remove = t2lm->ap_t2lm_mapping[i].add_remove;
			tlm_map->t2l_control = t2lm->ap_t2lm_mapping[i].t2l_control;
			tlm_map->lm_Presence_Indicator = t2lm->ap_t2lm_mapping[i].lm_Presence_Indicator;
			os_memcpy(tlm_map->expected_duration, t2lm->ap_t2lm_mapping[i].expected_duration, 3);
			os_memcpy(tlm_map->sta_ml_mac, t2lm->ap_t2lm_mapping[i].sta_ml_mac, ETH_ALEN);
			os_memcpy(tlm_map->t2lm, t2lm->ap_t2lm_mapping[i].t2lm, 2 * MAX_TID_PER_LINK);
			dl_list_add_tail(&t2lm_db->ap_t2lm_mapping, &tlm_map->list);
		}
		ctx->mlo_t2lm_db.num_mld++;
	}
	return 0;
}

void update_eth_rate_for_metrics(struct p1905_managerd_ctx *ctx,
		unsigned char *buf, unsigned short total_tlv_len)
{
	unsigned char *type = NULL;
	unsigned char *nalmac = NULL;
	unsigned char *p_phyRate = NULL;
	unsigned char *pos = NULL;
	int speed = 0;
	int ret = 0;
	unsigned int tlv_len = 0;
	unsigned short len = 0, len_sum = 0;
	unsigned short link_pair_cnt = 0;
	unsigned short intftype = 0;
	unsigned char i = 0;

	type = buf;
	while (len_sum < total_tlv_len) {
		len = get_tlv_len(type);
		tlv_len = len + 3;
		if (*type == TRANSMITTER_LINK_METRIC_TYPE) {
			link_pair_cnt = (len - 12) / 29;
			pos = type + 3;
			pos += 6;
			nalmac = pos;
			pos += 6;
			for (i = 0; i < link_pair_cnt; i++) {
				pos += 12;
				intftype = *((unsigned short *)pos);
				intftype = be_to_host16(intftype);
				/*IEEE 802.3u fast Ethernet or IEEE 802.3ab gigabit Ethernet*/
				if (intftype > 0x0001) {
					pos += 17;
					continue;
				}
				ret = eth_layer_get_client_port_by_mac(nalmac);
				if (ret < 0) {
					pos += 17;
					continue;
				}
				ret = eth_layer_get_port_speed(ret, &speed);
				if (ret < 0) {
					pos += 17;
					continue;
				}
				p_phyRate = pos + 15;
				*((unsigned short *)p_phyRate) = host_to_be16(speed);
				pos += 2;
			}
		}
		type += tlv_len;
		len_sum += tlv_len;
	}
}

#ifdef MAP_R6
void opclass_2_mld_event(void *eloop_ctx, void *timeout_ctx)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx *)eloop_ctx;

	if (ctx->role == CONTROLLER) {
		notice(DEBUG_CAT_MLO, "dump wts mld\n");
		notice_dump_agent_ap_mld(&ctx->wts_ctrl_mld_cfg);
	} else {
		notice(DEBUG_CAT_MLO, "tx ap mld config response to controller "MACSTR"\n",
			MAC2STR(ctx->cinfo.almac));
		notice(DEBUG_CAT_MLO, "dump opcls mld\n");
		notice_dump_agent_ap_mld(&ctx->opcls_mld_cfg);
		insert_cmdu_txq(ctx->cinfo.almac, ctx->p1905_al_mac_addr,
			e_ap_mld_configuration_response, ++ctx->mid, ctx->cinfo.local_ifname, 0);
	}
}
#endif

int map_event_handler(struct p1905_managerd_ctx *ctx, char *buf, int len, unsigned char type,
	unsigned char *reply, int *reply_len)
{
	struct msg *wapp_event = NULL;
	int if_num = 0;
	int ret = 0;
	unsigned short mid = 0;

	wapp_event = (struct msg *)buf;

	if ((type != 0x00) && (wapp_event->type == type)) {
		if (wapp_event->length == 0)
			return -2;
	}

	if (wapp_event->length == 0) {
		if (wapp_event->type != LIB_1905_CMDU_REQUEST &&
			wapp_event->type != LIB_STEERING_COMPLETED &&
			wapp_event->type != WAPP_GET_OWN_TOPOLOGY_RSP &&
			wapp_event->type != LIB_CLEAR_SWITCH_TABLE &&
			wapp_event->type != LIB_QOS_SAVE_CONFIG &&
			wapp_event->type != LIB_QOS_GET_ERROR_CODE
			) {
			err(DEBUG_CAT_EVENT, "invalid event type; len=0; type=0x%04x(%s)\n",
				wapp_event->type, get_1905_lib_event_str(wapp_event->type));
			return -1;
		}
	}

	if ((type != 0x00) && wapp_event->type != type) {
		info(DEBUG_CAT_EVENT, "insert message wait queue; wait_type=0x%04x(%s); "
			"lib_event_type=0x%04x(%s)\n", type, get_1905_lib_event_str(type),
			wapp_event->type, get_1905_lib_event_str(wapp_event->type));
		/*avoid to drop unsolicited message, insert to a waitq*/
		insert_message_wait_queue(wapp_event->type, (unsigned char *)buf, len);
		return -1;
	}

	debug(DEBUG_CAT_EVENT, "receive lib event=0x%04x(%s)\n",
		wapp_event->type, get_1905_lib_event_str(wapp_event->type));

	switch (wapp_event->type) {
	case LIB_WIRELESS_INTERFACE_INFO:
	{
		struct interface_info_list_hdr *info = NULL;
		unsigned short real_len = 0;

		info = (struct interface_info_list_hdr *)wapp_event->buffer;
		real_len = sizeof(struct interface_info_list_hdr) + \
			info->interface_count * sizeof(struct interface_info);
		/*event length check*/
		if (wapp_event->length != real_len) {
			err(DEBUG_CAT_EVENT, "length check fail for LIB_WIRELESS_INTERFACE_INFO; "
				"recv_length(%u); real_length(%u)\n", wapp_event->length, real_len);
			err_hexdump_ascii(DEBUG_CAT_EVENT, "err LIB_WIRELESS_INTERFACE_INFO",
				wapp_event->buffer, wapp_event->length);
			exit(1);
		}
		ret = init_wireless_interface(ctx, info);
		if (ret < 0) {
			err(DEBUG_CAT_EVENT, "init_wireless_interface fail\n");
			if (ret == -1)
				err_hexdump_ascii(DEBUG_CAT_EVENT, "err LIB_WIRELESS_INTERFACE_INFO",
					wapp_event->buffer, wapp_event->length);
			exit(1);
		}
		ret = set_bss_config_priority_by_str(ctx);
		if (ret < 0) {
			err(DEBUG_CAT_EVENT, "set_bss_config_priority_by_str fail\n");

			exit(1);
		}
		ret = common_info_init(ctx);
		if (ret < 0) {
			err(DEBUG_CAT_EVENT, "common_info_init fail\n");
			exit(1);
		}
#ifdef MAP_R2
		if (ctx->role == CONTROLLER)
			update_mapfilter_wan_tag(ctx, 1);
		else
			update_mapfilter_wan_tag(ctx, 0);
#endif

		/*
		 *for scenario almac is setting as brlan mac, it may meet a case that
		 *make a loop (both eth and wifi bh link exist) and all pkt can not received from eth port.
		 *for this case, it can only 1905 pkt recived from eth port when loop form,
		 *after mapd break the loop, allow all the data pkt received.
		 *so default will set block mode block mode(only 1905 pkt can be received),
		 *only eth plug in case will set eth port as forward mode(all data pkt can be received),
		 *eth plug out case, so should change back as block mode.
		 *set switch acl rule for scenario that 1905 pkt still can be received when eth port set as block mode
		 */

		if (!ctx->MAP_Cer && !os_memcmp(ctx->br_addr, ctx->p1905_al_mac_addr, ETH_ALEN)) {
			notice(DEBUG_CAT_INIT, "set switch acl rule due to own almac is br_mac\n");
			ctx->swtich_rule_set = 1;
			eth_layer_set_acl_enable();
			eth_layer_set_lan_rule(ctx->p1905_al_mac_addr);
		}

#ifdef MAP_R3
		eloop_register_timeout(2, 0, report_akm_suit_cap_to_mapd, (void *)ctx, NULL);
		eloop_register_timeout(2, 0, report_1905_secure_cap_to_mapd, (void *)ctx, NULL);
		eloop_register_timeout(2, 0, report_sp_standard_rule_to_mapd_timeout, (void *)ctx, NULL);
#endif

		notice(DEBUG_CAT_INIT, "recv LIB_WIRELESS_INTERFACE_INFO; init stage done\n");
		{
			char *buf = NULL;
			int len = 0;

			buf = (char *)os_zalloc(20480);
			if (buf) {
				len = dump_init_info(ctx, buf, 20480);
				if (len > 0)
					notice(DEBUG_CAT_INIT, "dump init info\n%s", buf);
				os_free(buf);
			} else {
				err(DEBUG_CAT_MISC, "alloc 20480 buffer fail; can't print init info\n");
			}
		}
	}
		break;
	case LIB_CLEAR_SWITCH_TABLE:
	{
		eth_layer_clear_switch_table();
	}
		break;
	case LIB_MAP_BH_READY:
	{
		struct bh_link_info *info = NULL;
		int i = 0;
		int ret = 0;
#ifndef EM_PLUS_EXT_SUPPORT
		int ret1 = 0;
		unsigned char notify = 0;
#endif
		unsigned char almac[ETH_ALEN] = {0};

		info = (struct bh_link_info *)wapp_event->buffer;

		if (ctx->role == CONTROLLER) {
			err(DEBUG_CAT_ONBOARD, "ignore LIB_MAP_BH_READY event; current role is controller\n");
			goto error;
		}
#ifdef MAP_R3
		/* avoid r3 onboarding sm abnormality */
		ctx->r3_oboard_ctx.active = 0;
		ctx->r3_oboard_ctx.peer_profile = 0;
		ctx->r3_oboard_ctx.peer_service_type = 0;
		ctx->r3_oboard_ctx.bh_type = 0;
		ctx->r3_oboard_ctx.r3_config_state = no_r3_autoconfig;
		ctx->r3_oboard_ctx.bss_req_retry_cnt = 0;
		ctx->r3_oboard_ctx.bss_renew = 0;
		ctx->r3_oboard_ctx.onboarding_stage = 0;

		if (info->type)
			ctx->r3_oboard_ctx.bh_type = MAP_BH_WIFI;
		else
			ctx->r3_oboard_ctx.bh_type = MAP_BH_ETH;

		/* cancel timer to stop sending autoconfig search periodicly */
		eloop_cancel_timeout(periodic_send_autoconfig_search, (void *)ctx, NULL);
#endif /* MAP_R3.*/

#ifdef MAP_R6
		os_memset(&ctx->mld_bsta_info, 0, sizeof(struct bh_mld_bsta_config));
		os_memcpy(&ctx->mld_bsta_info, &info->mldinfo, sizeof(struct bh_mld_bsta_config));

		if (ctx->mld_bsta_info.num_affiliated_sta) {
			notice(DEBUG_CAT_MLO, "send bsta mld config response to controller\n");
			insert_cmdu_txq(ctx->cinfo.almac, ctx->p1905_al_mac_addr,
				e_bsta_mld_configuration_response, ++ctx->mid, ctx->itf[ctx->cinfo.recv_ifid].if_name, 0);
		}
#endif /* MAP_R6.*/

#ifdef BR_IP_TLV_SUPPORT
		/* for agent, IP get changed after BH connection, poll it */
		eloop_cancel_timeout(get_br_ip_proc, (void *)ctx, ELOOP_ALL_CTX);
		eloop_register_timeout(0, 100000, get_br_ip_proc, (void *)ctx, (void *)1);
#endif /* BR_IP_TLV_SUPPORT.*/

		if (info->type == MAP_BH_ETH) {
			notice(DEBUG_CAT_ONBOARD, "[LIB_MAP_BH_READY]ETH link up\n");
			ctx->controller_search_state = bk_link_ready;
			ctx->controller_search_cnt = 0;
#ifdef MAP_R3
			int j = 0;
			for (j = 1; j < ctx->itf_number; j++) {
				/*send multicast cmdu to all the ethenet interface */
				if (ctx->itf[j].media_type <= IEEE802_3_AB_GROUP) {
					for (i = 0; i < 3; i++) {
						ctx->mid++;
						insert_cmdu_txq(p1905_multicast_address, ctx->p1905_al_mac_addr,
							e_topology_discovery_with_vendor_ie, ctx->mid, ctx->itf[j].if_name, 0);
					}
				}
			}
#endif /* MAP_R3.*/
			eloop_cancel_timeout(ap_controller_search_step, (void *)ctx, NULL);
#ifdef EM_PLUS_SUPPORT
			eloop_register_timeout(0, 0, ap_controller_search_step, (void *)ctx, NULL);
#else
			/*set timer = 2s to check topologay to avoiding to multiple eth bh*/
			eloop_register_timeout(2, 0, ap_controller_search_step, (void *)ctx, NULL);
#endif
			break;
		}

		for (i = 0; i < ctx->itf_number; i++) {
			if (!os_memcmp(info->mac_addr, ctx->itf[i].mac_addr, ETH_ALEN)) {
				if (ctx->itf[i].is_wifi_sta != 1) {
					err(DEBUG_CAT_ONBOARD, "ignore LIB_MAP_BH_READY event; current connected"
						" intf "MACSTR" is not a sta intf\n",
						MAC2STR(info->mac_addr));
					goto error;
				}
				break;
			}
		}
		if (i >= ctx->itf_number) {
			err(DEBUG_CAT_ONBOARD, "ignore LIB_MAP_BH_READY event; can't find matched sta intf"
				" with the connected intf "MACSTR"\n",
				MAC2STR(info->mac_addr));
			goto error;
		}

		notice(DEBUG_CAT_ONBOARD, "[LIB_MAP_BH_READY]apcli(%s) "MACSTR" connect to bssid "MACSTR
			"; enable trx config; send discovery and notification\n",
			ctx->itf[i].if_name, MAC2STR(info->mac_addr), MAC2STR(info->bssid));
		eloop_register_timeout(0, 0, discovery_at_interface_link_up,
			(void *)ctx, (void *)ctx->itf[i].if_name);
		memcpy(ctx->itf[i].vs_info, info->bssid, ETH_ALEN);
#ifdef MAP_R6
		memcpy(ctx->itf[i].bakchaul_bss_mld_addr, info->mldinfo.bss_mld_mac, ETH_ALEN);
#endif
		ctx->itf[i].trx_config = TX_MUL | RX_MUL | TX_UNI | RX_UNI;

		/*check if bssid in this event is operating on one of neighbor MAP device*/
		ret = find_almac_by_connect_mac(ctx, info->bssid, almac);
		if (ret == 1) {
			info(DEBUG_CAT_ONBOARD, "[LIB_MAP_BH_READY]already receive discovery from "MACSTR"\n",
					MAC2STR(almac));
		} else if (ret == 2) {
			info(DEBUG_CAT_ONBOARD, "[LIB_MAP_BH_READY]no discovery; recv response from "MACSTR
				"; create discovery and neighbor info based on rsp\n",
					MAC2STR(almac));
#ifndef EM_PLUS_EXT_SUPPORT
			ret1 = insert_topology_discovery_database(ctx, almac,
					info->bssid, info->mac_addr);
			if (ret1 >= 0) {
				update_p1905_neighbor_dev_info(ctx, almac, info->bssid,
					info->mac_addr, &notify);
				/*report updated own topology response to mapd*/
				report_own_topology_rsp(ctx, ctx->p1905_al_mac_addr, ctx->br_cap,
					ctx->p1905_neighbor_dev, ctx->non_p1905_neighbor_dev,
					ctx->service, &ctx->ap_cap_entry.oper_bss_head,
					&ctx->ap_cap_entry.assoc_clients_head, ctx->cnt);
				update_topology_tree(ctx);
			}
#endif
		} else {
			info(DEBUG_CAT_ONBOARD, "[LIB_MAP_BH_READY]no topo msg from bssid "MACSTR"\n",
				MAC2STR(info->bssid));
		}
#ifndef EM_PLUS_EXT_SUPPORT
		/*send notification to notify other device my topology is changed*/
		ctx->mid++;
		multicast_cmdu_tx(ctx, e_topology_notification, ctx->mid, 1);
#endif
		/*trigger_autconf will be set in first wifi link in wifi case or in eth case*/
		if (info->trigger_autconf) {
			notice(DEBUG_CAT_ONBOARD, "[LIB_MAP_BH_READY]trigger autconf procedure\n");
			ctx->controller_search_state = bk_link_ready;
		    ctx->controller_search_cnt = 0;
			eloop_cancel_timeout(ap_controller_search_step, (void *)ctx, NULL);
			eloop_register_timeout(0, 0, ap_controller_search_step, (void *)ctx, NULL);
		} else {
			notice(DEBUG_CAT_ONBOARD, "[LIB_MAP_BH_READY]do not trigger autconf; trigger_autconf=0\n");
		}
	}
		break;
	case WAPP_NOTIFY_WIRELESS_BH_LINK_DOWN:
	{
		struct bh_link_info *info = NULL;
		struct topology_discovery_db *db = NULL;
		int i = 0;
		unsigned char delete_almac[ETH_ALEN] = {0};
		int ret = 0;
		struct p1905_neighbor_info *dev_info, *dev_info_temp = NULL;

		info = (struct bh_link_info *)wapp_event->buffer;

		if (info->type != MAP_BH_WIFI) {
			err(DEBUG_CAT_ONBOARD, "ignore WAPP_NOTIFY_WIRELESS_BH_LINK_DOWN event; "
				"type is not MAP_BH_WIFI\n");
			goto error;
		}

		for (i = 0; i < ctx->itf_number; i++) {
			if (!os_memcmp(info->mac_addr, ctx->itf[i].mac_addr, ETH_ALEN)) {
				ret = 1;
				if (ctx->itf[i].is_wifi_sta != 1) {
					err(DEBUG_CAT_ONBOARD, "ignore WAPP_NOTIFY_WIRELESS_BH_LINK_DOWN event;"
						" current connected intf "MACSTR" is not a sta intf\n",
						MAC2STR(info->mac_addr));
					ret = -1;
				}
				break;
			}
		}
		if (ret != 1) {
			err(DEBUG_CAT_ONBOARD, "ignore WAPP_NOTIFY_WIRELESS_BH_LINK_DOWN event; "
				"can't find matched sta intf with the connected intf "MACSTR"\n",
				MAC2STR(info->mac_addr));
			break;
		}

		reset_controller_connect_ifname(ctx, ctx->itf[i].if_name);
		notice(DEBUG_CAT_ONBOARD, "[WAPP_NOTIFY_WIRELESS_BH_LINK_DOWN]bh apcli(%s) "MACSTR
			" link down to bssid "MACSTR"; disable trx config; remove topo discovery/rsp/neighbor info; "
			"send notification\n",
			info->ifname, MAC2STR(info->mac_addr), MAC2STR(info->bssid));
		db = get_tpd_db_by_mac(ctx, ctx->itf[i].vs_info);
		os_memset(ctx->itf[i].vs_info, 0, ETH_ALEN);
		/*temporarily set sta interface not to send multicast cmdu which is not connected*/
		ctx->itf[i].trx_config = 0;
		if (!db) {
			info(DEBUG_CAT_ONBOARD,
				"[WAPP_NOTIFY_WIRELESS_BH_LINK_DOWN]no discovery in db for peer_intf "MACSTR"\n",
				MAC2STR(ctx->itf[i].vs_info));
			/*clear neighbor info for apcli for error handle*/
			dev_info = LIST_FIRST(&ctx->p1905_neighbor_dev[i].p1905nbr_head);
			while (dev_info) {
				dev_info_temp = LIST_NEXT(dev_info, p1905nbr_entry);
				LIST_REMOVE(dev_info, p1905nbr_entry);
				info(DEBUG_CAT_ONBOARD, "[WAPP_NOTIFY_WIRELESS_BH_LINK_DOWN]del neighbor "MACSTR" on %s\n",
					PRINT_MAC(dev_info->al_mac_addr), ctx->itf[i].if_name);
				os_free(dev_info);
				dev_info = dev_info_temp;
			}
			break;
		}

		os_memcpy(delete_almac, db->al_mac, ETH_ALEN);
		delete_exist_topology_discovery_database(ctx, db->al_mac, db->itf_mac);
		/*cannot refer db, the memory is free*/
		report_own_topology_rsp(ctx, ctx->p1905_al_mac_addr, ctx->br_cap,
			ctx->p1905_neighbor_dev, ctx->non_p1905_neighbor_dev,
			ctx->service, &ctx->ap_cap_entry.oper_bss_head,
			&ctx->ap_cap_entry.assoc_clients_head, ctx->cnt);
		if (find_discovery_by_almac(ctx, delete_almac) == NULL) {
			info(DEBUG_CAT_ONBOARD, "[WAPP_NOTIFY_WIRELESS_BH_LINK_DOWN]del topology rsp\n");
			delete_exist_topology_response_database(ctx, delete_almac);
			mark_valid_topo_rsp_node(ctx);
		}
		update_topology_tree(ctx);

		ctx->mid++;
		multicast_cmdu_tx(ctx, e_topology_notification, ctx->mid, 1);
	}
		break;
	case WAPP_NOTIFY_CH_BW_INFO:
	{
		struct channel_bw_info *info = NULL;
		info = (struct channel_bw_info *)wapp_event->buffer;
		for(if_num = 0; if_num < ctx->itf_number; if_num++) {
			if (!memcmp(ctx->itf[if_num].mac_addr, info->iface_addr,
				ETH_ALEN)) {
				ctx->itf[if_num].channel_bw = info->channel_bw;
				ctx->itf[if_num].channel_freq = info->channel_num;
			}
		}
	}
		break;
	case WAPP_GET_OWN_TOPOLOGY_RSP:
	{
		report_own_topology_rsp(ctx, ctx->p1905_al_mac_addr, ctx->br_cap,
			ctx->p1905_neighbor_dev, ctx->non_p1905_neighbor_dev,
	       	ctx->service, &ctx->ap_cap_entry.oper_bss_head,
	        &ctx->ap_cap_entry.assoc_clients_head, ctx->cnt);
	}
		break;
	case GET_SWITCH_STATUS:
	{
		int i = 0, status_temp = 0;
		unsigned char status = 0;

		for (i = 0; i < MAX_LAN_PORT_NUM; i++) {
			if ((status_temp = eth_layer_get_eth_port_status(i)) < 0) {
				status = 0xff;
				break;
			} else {
				if (status_temp)
					status |= (1 << i);
			}
		}

		_1905_notify_switch_status(ctx, status);
	}
		break;
	case LIB_RADIO_BASIC_CAP:
	{
		struct ap_radio_basic_cap *bcap = NULL;

		bcap = (struct ap_radio_basic_cap *)wapp_event->buffer;
		delete_exist_radio_basic_capability(ctx, bcap->identifier);
		ret = update_radio_basic_capability(ctx, bcap, wapp_event->length);
		if (ret < 0)
			goto error;
	}
		break;
	case LIB_AP_CAPABILITY:
	{
		struct ap_capability *cap = NULL;

		cap = (struct ap_capability *)wapp_event->buffer;
		memcpy(&ctx->ap_cap_entry.ap_cap, cap, sizeof(*cap));
#ifdef MAP_R6
		ctx->ap_cap_entry.ap_cap.bsta_wsc_reconfig = 1;
#endif
	}
		break;
	case LIB_AP_HT_CAPABILITY:
	{
		struct ap_ht_capability *cap = NULL;

		cap = (struct ap_ht_capability *)wapp_event->buffer;
		update_ap_ht_cap(ctx, cap);
	}
		break;
	case LIB_AP_VHT_CAPABILITY:
	{
		struct ap_vht_capability *cap = NULL;

		cap = (struct ap_vht_capability *)wapp_event->buffer;
		update_ap_vht_cap(ctx, cap);
	}
		break;
	case LIB_AP_HE_CAPABILITY:
	{
		struct ap_he_capability *cap = NULL;

		cap = (struct ap_he_capability *)wapp_event->buffer;
		ret = update_ap_he_cap(ctx, cap);
		if (ret == -1)
			goto error;
	}
		break;
	case LIB_AP_EHT_CAPABILITY:
	{
		struct ap_eht_capability *cap = NULL;

		cap = (struct ap_eht_capability *)wapp_event->buffer;
		update_ap_eht_cap(ctx, cap);
	}
		break;
#ifdef MAP_R2
	/*channel scan feature*/
	//case WAPP_CHANNEL_SCAN_CAP:
	case LIB_CHANNEL_SCAN_CAPAB:
	{
		struct scan_capability_lib *scap = NULL;

		scap = (struct scan_capability_lib *)wapp_event->buffer;
		delete_exist_channel_scan_capability(ctx, scap->identifier);
		insert_new_channel_scan_capability(ctx, scap);
	}
		break;
#endif
	case LIB_CLI_CAPABILITY_REPORT:
	{
		struct client_capa_rep *cap = NULL;
		struct client_capa_rep *ctx_cap = NULL;

		cap = (struct client_capa_rep *)wapp_event->buffer;
		free(ctx->sinfo.pcli_rep);
		ctx->sinfo.pcli_rep = (struct client_capa_rep *)malloc(cap->length + 1);
		if (ctx->sinfo.pcli_rep == NULL) {
			err(DEBUG_CAT_EVENT, "[LIB_CLI_CAPABILITY_REPORT] alloc struct client_capa_rep fail\n");
       		break;
    	}
		ctx_cap = ctx->sinfo.pcli_rep;
		ctx_cap->result = cap->result;
		ctx_cap->length = 0;
		if (ctx_cap->result == 0) {
			ctx_cap->length = cap->length;
			memcpy(ctx_cap->body, cap->body, ctx_cap->length);
		}
	}
		break;
	case LIB_OPERBSS_REPORT:
	{
		struct oper_bss_cap *opcap = NULL;

		opcap = (struct oper_bss_cap *)wapp_event->buffer;
		delete_exist_operational_bss(ctx, opcap->identifier);
		insert_new_operational_bss(ctx, opcap);
		delete_legacy_assoc_clients_db(ctx);
#ifdef MAP_R6
		/* don't trans operbss to mlo while bootup  */
		if (!is_zero_ether_addr(ctx->cinfo.almac) ||
			!dl_list_empty(&ctx->wts_ctrl_mld_cfg.mlo_cfg_list)) {
			trans_opbss_2_mlo(ctx, &ctx->opcls_mld_cfg, opcap->identifier);
			info(DEBUG_CAT_MLO, "dump opclass mld\n");
			info_dump_agent_ap_mld(&ctx->opcls_mld_cfg);
		}

		if (dl_list_empty(&ctx->opcls_mld_cfg.mlo_cfg_list))
			break;

		if (ctx->role == CONTROLLER) {
			info(DEBUG_CAT_MLO, "update mld cfg from opclass mld on controller\n");
			update_agt_ap_mld_info(&ctx->wts_ctrl_mld_cfg, &ctx->opcls_mld_cfg);
			info(DEBUG_CAT_MLO, "dump wts mld\n");
			info_dump_agent_ap_mld(&ctx->wts_ctrl_mld_cfg);
		}

		eloop_cancel_timeout(opclass_2_mld_event, ctx, NULL);
		eloop_register_timeout(2, 0, opclass_2_mld_event, ctx, NULL);
#endif

	}
		break;
	case LIB_CHANNLE_PREFERENCE:
	{
		struct ch_prefer *prefer = NULL;

		prefer = (struct ch_prefer *)wapp_event->buffer;
		delete_exist_ch_prefer_info(ctx, prefer->identifier);
		insert_new_channel_prefer_info(ctx, prefer);
	}
		break;
	case WAPP_CHANNEL_PREFERENCE_REPORT_INFO:
	{
		if (fill_send_tlv(ctx, wapp_event->buffer, wapp_event->length) < 0) {
			err(DEBUG_CAT_EVENT, "[WAPP_CHANNEL_PREFERENCE_REPORT_INFO]fill_send_tlv fail");
			break;
		}
		if (wapp_event->mid)
			mid = wapp_event->mid;
		else
			mid = ++ctx->mid;
		insert_cmdu_txq(ctx->cinfo.almac, ctx->p1905_al_mac_addr,
			e_channel_preference_report, mid, ctx->cinfo.local_ifname, 0);
	}
		break;
	case WAPP_CHANNEL_SELECTION_RSP_INFO:
	{
		if (fill_send_tlv(ctx, wapp_event->buffer, wapp_event->length) < 0) {
			err(DEBUG_CAT_EVENT, "[WAPP_CHANNEL_SELECTION_RSP_INFO]fill_send_tlv fail");
			break;
		}
		insert_cmdu_txq(ctx->cinfo.almac, ctx->p1905_al_mac_addr,
			e_channel_selection_response, wapp_event->mid, ctx->cinfo.local_ifname, 0);
	/* This fixes the dealy in AP metric dring channel selection process by notifying
	 * to wapp and reset the timer for metrics.
	 */
	}
		break;
	case LIB_RADIO_OPERATION_RESTRICTION:
	{
		struct restriction *resdb = NULL;

		resdb = (struct restriction *)wapp_event->buffer;
		delete_exist_restriction_info(ctx, resdb->identifier);
		insert_new_restriction_info(ctx, resdb);
	}
		break;
	case LIB_TX_LINK_STATISTICS:
	{
		struct tx_link_stat_rsp *rsp = NULL;

		rsp = (struct tx_link_stat_rsp *)wapp_event->buffer;
		memcpy(&ctx->link_stat.tx_link_stat, rsp,
			sizeof(struct tx_link_stat_rsp));
	}
		break;
	case LIB_RX_LINK_STATISTICS:
	{
		struct rx_link_stat_rsp *rsp = NULL;

		rsp = (struct rx_link_stat_rsp *)wapp_event->buffer;
		memcpy(&ctx->link_stat.rx_link_stat, rsp,
			sizeof(struct rx_link_stat_rsp));
	}
		break;
	case WAPP_AP_METRICS_RSP_INFO:
	{
#ifdef EM_PLUS_SUPPORT
		unsigned char *p = NULL;
		unsigned short len = 0;
#endif /*EM_PLUS_SUPPORT*/

		if (fill_send_tlv(ctx, wapp_event->buffer, wapp_event->length) < 0) {
			err(DEBUG_CAT_EVENT, "[WAPP_AP_METRICS_RSP_INFO]fill_send_tlv fail");
			break;
		}
#ifdef EM_PLUS_SUPPORT
		/*append emplus ethernet stats tlv*/
		p = ctx->send_tlv;
		p += ctx->send_tlv_len;
		len = append_emplus_eth_host_stats_tlv(ctx, p);
		ctx->send_tlv_len += len;
		/*append emplus device metrics tlv*/
		p += len;
		len = append_emplus_dev_metircs(ctx, p);
		ctx->send_tlv_len += len;
#endif /*EM_PLUS_SUPPORT*/
		if (wapp_event->mid)
			mid = wapp_event->mid;
		else
			mid = ++ctx->mid;
		insert_cmdu_txq(ctx->cinfo.almac, ctx->p1905_al_mac_addr,
			e_ap_metrics_response, mid, ctx->cinfo.local_ifname, 0);
	}
		break;
	case LIB_AP_METRICS_INFO:
	{
		struct ap_metrics_info *minfo = NULL;

		minfo = (struct ap_metrics_info *)wapp_event->buffer;
		delete_exist_metrics_info(ctx, minfo->bssid);
		insert_new_metrics_info(ctx, minfo);
	}
		break;
	case LIB_ALL_ASSOC_STA_TRAFFIC_STATS:
	{
		struct sta_traffic_stats *stats = NULL;

		stats = (struct sta_traffic_stats *)wapp_event->buffer;
		delete_exist_traffic_stats_info(ctx, stats->identifier);
		insert_new_traffic_stats_info(ctx, stats);
	}
		break;
	case LIB_ALL_ASSOC_STA_LINK_METRICS:
	{
		struct sta_link_metrics *metrics = NULL;

		metrics = (struct sta_link_metrics *)wapp_event->buffer;
		delete_exist_link_metrics_info(ctx, metrics->identifier);
		insert_new_link_metrics_info(ctx, metrics);
	}
		break;
	case LIB_ONE_ASSOC_STA_LINK_METRICS:
	{
		if (fill_send_tlv(ctx, wapp_event->buffer, wapp_event->length) < 0) {
			err(DEBUG_CAT_EVENT, "[LIB_ONE_ASSOC_STA_LINK_METRICS]fill_send_tlv fail");
			break;
		}
		if (wapp_event->mid)
			mid = wapp_event->mid;
		else
			mid = ++ctx->mid;
		insert_cmdu_txq(ctx->cinfo.almac, ctx->p1905_al_mac_addr,
					e_associated_sta_link_metrics_response,
					mid, ctx->cinfo.local_ifname, 0);
	}
		break;
	case LIB_UNASSOC_STA_LINK_METRICS:
	{
		struct delayed_message_buf dm_buf;

		memset(&dm_buf, 0, sizeof(dm_buf));
		if (!pop_dm_buffer(ctx, LIB_UNASSOC_STA_LINK_METRICS, dm_buf.al_mac, &dm_buf.mid, dm_buf.if_name)) {
			if (fill_send_tlv(ctx, wapp_event->buffer, wapp_event->length) < 0) {
				err(DEBUG_CAT_EVENT, "[LIB_UNASSOC_STA_LINK_METRICS]fill_send_tlv fail");
				break;
			}
			insert_cmdu_txq(dm_buf.al_mac, ctx->p1905_al_mac_addr,
				e_unassociated_sta_link_metrics_response, ctx->mid++, (unsigned char *)dm_buf.if_name, 0);
		} else {
			err(DEBUG_CAT_EVENT, "can't find msg with type LIB_UNASSOC_STA_LINK_METRICS from dm_buffer\n");
		}
	}
		break;
	case LIB_OPERATING_CHANNEL_INFO:
		update_channel_report_info(ctx, (struct channel_report *)wapp_event->buffer,
			wapp_event->length);
		break;
	case LIB_CLIENT_NOTIFICATION:
	{
		struct client_association_event *evt = NULL;
		struct map_client_association_event *pevt = NULL;
		struct topology_discovery_db *db = NULL;
		unsigned char delete_almac[ETH_ALEN] = {0};
#ifdef MAP_R2
		struct assoc_client *client = NULL;
#endif
#ifdef MAP_R6
		struct mlo_sta_db *record = NULL;
		struct mlo_sta_config_db *cfg = NULL;
#endif /* MAP_R6 */

		evt = (struct client_association_event *)wapp_event->buffer;
		pevt = (struct map_client_association_event *)&evt->map_assoc_evt;
		memcpy(&ctx->sinfo.sassoc_evt.sta_mac, pevt->sta_mac, ETH_ALEN);
		memcpy(&ctx->sinfo.sassoc_evt.bssid, pevt->bssid, ETH_ALEN);
		ctx->sinfo.sassoc_evt.assoc_evt = pevt->assoc_evt;

		notice(DEBUG_CAT_EVENT, "recv LIB_CLIENT_NOTIFICATION; "
			"sta_mac="MACSTR"; bssid="MACSTR"; assoc=%d; is_APCLI=%d;"
			"send topo notification to MAP network",
			MAC2STR(pevt->sta_mac), MAC2STR(pevt->bssid),
			pevt->assoc_evt, pevt->is_APCLI);
#ifdef MAP_R6
		/* for MLO STA connection we need to send topo notification after MLD stats update */
		if ((pevt->assoc_evt && is_zero_ether_addr(pevt->sta_link_addr) &&
			is_zero_ether_addr(pevt->ap_link_addr)) || pevt->assoc_evt == 0) {
#endif /* MAP_R6 */
			ctx->sta_notifier = 1;
			/*send notification with assoc sta info to notify other device my own topology is changed*/
			ctx->mid++;
			multicast_cmdu_tx(ctx, e_topology_notification, ctx->mid, 1);
#ifdef MAP_R6
		}
#endif /* MAP_R6 */

		if (update_assoc_sta_info(ctx, pevt) < 0) {
			err(DEBUG_CAT_TOPO, "update station info fail\n");
			break;
		}
#ifdef MAP_R2
		client = get_assoc_cli_by_mac(ctx, pevt->sta_mac);

		if (client && pevt->assoc_evt == 0) {
			client->disassoc = 1;
		} else if (!client && pevt->assoc_evt) {
			client = create_assoc_cli(ctx, pevt->sta_mac, ctx->p1905_al_mac_addr);
			if (client)
				os_memcpy(client->bssid, pevt->bssid, ETH_ALEN);
		}
#endif

#ifdef MAP_R6
		if (client && pevt->assoc_evt == 0) {
			cfg = &client->sta_mld;

			if (!dl_list_empty(&cfg->mlo_sta_list) && !os_memcmp(cfg->sta_mld_mac, pevt->sta_mac, ETH_ALEN)) {
				info(DEBUG_CAT_EVENT, "\tIS MLO STA "MACSTR"\n", MAC2STR(cfg->sta_mld_mac));
				dl_list_for_each(record, &cfg->mlo_sta_list, struct mlo_sta_db, list) {
				/* BSSID */
				info(DEBUG_CAT_EVENT, "\tbssid "MACSTR"\n", MAC2STR(record->bssid));
				/* Affilated_STA_MAC_Addr */
				info(DEBUG_CAT_EVENT, "\taffiliated_sta_mac "MACSTR"\n", MAC2STR(record->affiliated_sta_mac));

				db = get_tpd_db_by_mac(ctx, record->affiliated_sta_mac);
				if (db) {
					if (!os_memcmp(db->receive_itf_mac, record->bssid, ETH_ALEN)) {
						os_memcpy(delete_almac, db->al_mac, ETH_ALEN);
						delete_exist_topology_discovery_database(ctx, db->al_mac, db->itf_mac);
						/*cannot refer db, the memory is free*/
						maintain_all_assoc_clients(ctx);
						report_own_topology_rsp(ctx, ctx->p1905_al_mac_addr, ctx->br_cap,
								ctx->p1905_neighbor_dev, ctx->non_p1905_neighbor_dev,
								ctx->service, &ctx->ap_cap_entry.oper_bss_head,
								&ctx->ap_cap_entry.assoc_clients_head, ctx->cnt);
						if (find_discovery_by_almac(ctx, delete_almac) == NULL) {
							delete_exist_topology_response_database(ctx, delete_almac);
							mark_valid_topo_rsp_node(ctx);
						}
						update_topology_tree(ctx);
						break;
					} else {
						notice(DEBUG_CAT_TOPO, "bssid "MACSTR" in evt not match receive_itf_mac "
							MACSTR" in topo discovery\n",
							MAC2STR(record->bssid), MAC2STR(db->receive_itf_mac));
					}
				}
				}
			}
			maintain_all_assoc_clients(ctx);
		}
#endif /* MAP_R6 */
		if (pevt->assoc_evt == 0) {
			db = get_tpd_db_by_mac(ctx, pevt->sta_mac);
			if (db) {
				if (!os_memcmp(db->receive_itf_mac, pevt->bssid, ETH_ALEN)) {
					os_memcpy(delete_almac, db->al_mac, ETH_ALEN);
					delete_exist_topology_discovery_database(ctx, db->al_mac, db->itf_mac);
					/*cannot refer db, the memory is free*/
					report_own_topology_rsp(ctx, ctx->p1905_al_mac_addr, ctx->br_cap,
						ctx->p1905_neighbor_dev, ctx->non_p1905_neighbor_dev,
				       	ctx->service, &ctx->ap_cap_entry.oper_bss_head,
				        &ctx->ap_cap_entry.assoc_clients_head, ctx->cnt);
					if (find_discovery_by_almac(ctx, delete_almac) == NULL) {
						delete_exist_topology_response_database(ctx, delete_almac);
						mark_valid_topo_rsp_node(ctx);
					}
					update_topology_tree(ctx);
				} else {
					warn(DEBUG_CAT_TOPO, "bssid "MACSTR" in evt not match receive_itf_mac "
						MACSTR" in topo discovery\n",
						MAC2STR(pevt->bssid), MAC2STR(db->receive_itf_mac));
				}
			}
		} else {
			if (!ctx->MAP_Cer)
				detect_neighbor_existence(ctx, NULL, pevt->sta_mac);
		}

		if (pevt->assoc_evt) {
			if (check_sta_in_oper_bss(&(ctx->ap_cap_entry.oper_bss_head), pevt
#ifdef MAP_R6
				, &ctx->opcls_mld_cfg
#endif

			)) {
				warn(DEBUG_CAT_TOPO, "the bss "MACSTR" that the sta "MACSTR" associated is not operable\n",
					MAC2STR(pevt->bssid), MAC2STR(pevt->sta_mac));
				break;
			}
		}

#ifdef MAP_R2
		maintain_all_assoc_clients(ctx);
#endif

		if (pevt->assoc_evt && pevt->is_APCLI) {
			for(if_num = 0; if_num < ctx->itf_number; if_num++) {
				if (!os_memcmp(ctx->itf[if_num].mac_addr, pevt->bssid, ETH_ALEN)) {
					notice(DEBUG_CAT_TOPO, "[LIB_CLIENT_NOTIFICATION]%s connected by bh sta; "
						"tx topo discovery to downstream MAP agent\n", ctx->itf[if_num].if_name);
					eloop_register_timeout(0, 0, discovery_at_interface_link_up,
						(void *)ctx, (void *)ctx->itf[if_num].if_name);
					break;
				}
			}
		}
	}
		break;
	case LIB_OPERATING_CHANNEL_REPORT:
		update_channel_report_info(ctx, (struct channel_report *)wapp_event->buffer,
			wapp_event->length);
		ctx->mid++;
		insert_cmdu_txq(ctx->cinfo.almac, ctx->p1905_al_mac_addr,
			e_operating_channel_report, ctx->mid, ctx->cinfo.local_ifname, 0);
		break;
	case LIB_BEACON_METRICS_REPORT:
	{
		if (fill_send_tlv(ctx, wapp_event->buffer, wapp_event->length) < 0) {
			err(DEBUG_CAT_EVENT, "[LIB_BEACON_METRICS_REPORT]fill_send_tlv fail");
			break;
		}
		ctx->mid++;
        insert_cmdu_txq(ctx->cinfo.almac, ctx->p1905_al_mac_addr,
			e_beacon_metrics_response, ctx->mid, ctx->cinfo.local_ifname, 0);
	}
		break;
	case LIB_CLI_STEER_BTM_REPORT:
	{
		struct cli_steer_btm_event *evt = NULL;

		evt = (struct cli_steer_btm_event *)wapp_event->buffer;
		memcpy(ctx->sinfo.sbtm_evt.bssid, evt->bssid, ETH_ALEN);
		memcpy(ctx->sinfo.sbtm_evt.sta_mac, evt->sta_mac, ETH_ALEN);
		ctx->sinfo.sbtm_evt.status = evt->status;
		memcpy(ctx->sinfo.sbtm_evt.tbssid, evt->tbssid, ETH_ALEN);
		ctx->mid++;
        insert_cmdu_txq(ctx->cinfo.almac, ctx->p1905_al_mac_addr,
			e_client_steering_btm_report, ctx->mid, ctx->cinfo.local_ifname, 0);
	}
		break;
	case LIB_STEERING_COMPLETED:
	{
		ctx->mid++;
		insert_cmdu_txq(ctx->cinfo.almac, ctx->p1905_al_mac_addr,
			e_steering_completed, ctx->mid, ctx->cinfo.local_ifname, 0);
	}
		break;
	case LIB_BACKHAUL_STEER_RSP:
	{
		if (fill_send_tlv(ctx, wapp_event->buffer, wapp_event->length) < 0) {
			err(DEBUG_CAT_EVENT, "[LIB_BACKHAUL_STEER_RSP]fill_send_tlv fail");
			break;
		}
		ctx->mid++;
        insert_cmdu_txq(ctx->cinfo.almac, ctx->p1905_al_mac_addr,
			e_backhaul_steering_response, ctx->mid, ctx->cinfo.local_ifname, 0);
	}
		break;
	/*below event is mainly from 1905.1 library*/
	case LIB_1905_CMDU_REQUEST:
	{
		struct _1905_cmdu_request *request = (struct _1905_cmdu_request *)wapp_event->buffer;

		debug(DEBUG_CAT_EVENT, "recv LIB_1905_CMDU_REQUEST; dest_al_mac="MACSTR", type=%04x(%s)\n",
			MAC2STR(request->dest_al_mac), request->type,
			get_1905_mtype_str(request->type));
		process_1905_request(ctx, request);
	}
		break;
	case LIB_1905_READ_BSS_CONF_REQUEST:
	{
		if (ctx->role != CONTROLLER)
			break;

		if (_1905_read_set_config(ctx, ctx->wts_bss_cfg_file, ctx->bss_config, MAX_SET_BSS_INFO_NUM, &ctx->bss_config_num) < 0)
			err(DEBUG_CAT_EVENT, "[LIB_1905_READ_BSS_CONF_REQUEST]load bss config fail from %s\n",
				ctx->wts_bss_cfg_file);
	}
		break;
	case LIB_1905_READ_BSS_CONF_AND_RENEW:
	{
		unsigned char local_only = 0;
		unsigned char version = 0;

		if (ctx->role != CONTROLLER)
			break;

		if (check_all_agent_sync_bss_prio(ctx))
			notice(DEBUG_CAT_RENEW, "bss priority sync not done! may cause config issue\n");

		notice(DEBUG_CAT_RENEW, "[LIB_1905_READ_BSS_CONF_AND_RENEW]\n");

		local_only = *(wapp_event->buffer);
		version = *(wapp_event->buffer + 1);

		/*read bss info to 1905*/
		if (version == 1) {
			if (read_bss_conf_and_renew(ctx, local_only) < 0) {
				warn(DEBUG_CAT_RENEW, "load bss config fail\n");
				break;
			}
		} else {
			if (read_bss_conf_and_renew_v2(ctx, local_only) < 0) {
				warn(DEBUG_CAT_RENEW, "load bss config fail\n");
				break;
			}
		}
#ifdef MAP_R5
		load_qos_config((void *)ctx);
#endif
	}
		break;
	case LIB_1905_REQ:
		break;
	case WAPP_LINK_METRICS_RSP_INFO:
	{
		struct delayed_message_buf dm_buf;

		os_memset(&dm_buf, 0, sizeof(struct delayed_message_buf));
		if (!pop_dm_buffer(ctx, WAPP_LINK_METRICS_RSP_INFO, dm_buf.al_mac, &dm_buf.mid,
			dm_buf.if_name)) {
			/*refine link metrics for ethernet link*/
			update_eth_rate_for_metrics(ctx, wapp_event->buffer, wapp_event->length);
			if (fill_send_tlv(ctx, wapp_event->buffer, wapp_event->length) < 0) {
				err(DEBUG_CAT_EVENT, "[WAPP_LINK_METRICS_RSP_INFO]fill_send_tlv fail");
				break;
			}
			insert_cmdu_txq(dm_buf.al_mac, ctx->p1905_al_mac_addr,
				e_link_metric_response, dm_buf.mid, (unsigned char *)dm_buf.if_name, 0);
			process_cmdu_txq(ctx, ctx->trx_buf.buf);
		} else {
			err(DEBUG_CAT_EVENT, "can't find msg with type WAPP_LINK_METRICS_RSP_INFO from dm_buffer\n");
		}
	}
		break;
	case MANAGEMENT_1905_COMMAND:
	{
		struct manage_cmd *cmd = (struct manage_cmd *)(wapp_event->buffer);

		debug(DEBUG_CAT_EVENT, "recv MANAGEMENT_1905_COMMAND; cmd_id=0x%02x(%s)\n",
			cmd->cmd_id, get_manage_cmd_str(cmd->cmd_id));
		manage_cmd_process(ctx, cmd);
	}
		break;
	case LIB_SYNC_RECV_BUF_SIZE:
	{
		unsigned short length = 0, peer_len = 0, own_len = 0;
		int ret = 0, rsp = 0;

		os_memcpy(&length, wapp_event->buffer, sizeof(length));
		os_memcpy(&peer_len, wapp_event->buffer + sizeof(length), sizeof(peer_len));
		notice(DEBUG_CAT_EVENT, "recv LIB_SYNC_RECV_BUF_SIZE; notify_len=%d; peer_len=%d; "
			"own_recv_buf_len=%d; default_own_recv_len=%d\n",
			length, peer_len, ctx->_1905_ctrl.own_recv_buf_len, ctx->_1905_ctrl.default_own_recv_len);
		if (length > 0 && peer_len > 0) {
			if (ctx->_1905_ctrl.own_recv_buf_len != length) {
				if (length <= ctx->_1905_ctrl.default_own_recv_len)
					own_len = ctx->_1905_ctrl.default_own_recv_len;
				else
					own_len = length;
				ret = _1905_interface_set_sock_buf(ctx, own_len);
				if (ret == 0) {
					rsp = 1;
					ctx->_1905_ctrl.own_recv_buf_len = own_len;
					notice(DEBUG_CAT_EVENT, "change own_recv_buf_len to %d success\n",
						ctx->_1905_ctrl.own_recv_buf_len);
				}
			}
			if (ctx->_1905_ctrl.peer_recv_buf_len != peer_len) {
				if (!ctx->_1905_ctrl.peer_recv_buf_len && !ctx->_1905_ctrl.default_peer_recv_len)
					ctx->_1905_ctrl.default_peer_recv_len = peer_len;
				ctx->_1905_ctrl.peer_recv_buf_len = peer_len;
				notice(DEBUG_CAT_EVENT, "change peer_recv_buf_len to %d success\n",
					ctx->_1905_ctrl.peer_recv_buf_len);
			}
		}
		_1905_send_sync_recv_buf_size_rsp(ctx, ctx->_1905_ctrl.own_recv_buf_len, rsp);
	}
		break;
	case LIB_SYNC_RECV_BUF_SIZE_RSP:
	{
		unsigned short change_buf_len = 0, rsp = 0;

		memcpy(&change_buf_len, wapp_event->buffer, sizeof(change_buf_len));
		rsp = wapp_event->buffer[sizeof(change_buf_len)];
		if (rsp == 1) {
			if (!ctx->_1905_ctrl.peer_recv_buf_len && !ctx->_1905_ctrl.default_peer_recv_len)
					ctx->_1905_ctrl.default_peer_recv_len = change_buf_len;
			ctx->_1905_ctrl.peer_recv_buf_len = change_buf_len;
			notice(DEBUG_CAT_EVENT, "[LIB_SYNC_RECV_BUF_SIZE_RSP]change buf size to %d success\n",
				change_buf_len);
			return 0;
		}
		notice(DEBUG_CAT_EVENT, "[LIB_SYNC_RECV_BUF_SIZE_RSP]change buf size to %d fail\n",
			change_buf_len);
		return -1;
	}
		break;
#ifdef MAP_R2
	case LIB_CAC_CAPAB:
		insert_new_cac_capability(ctx, (struct cac_capability_lib *)wapp_event->buffer);
		break;
	case LIB_R2_AP_CAP:
		update_r2_ap_capability(ctx, (struct ap_r2_capability *)wapp_event->buffer);
		break;
	case LIB_METRIC_REP_INTERVAL_CAP:
	{
		unsigned int *interval = (unsigned int *)wapp_event->buffer;

		ctx->metric_entry.metric_collection_interval = *interval;
	}
		break;
	case LIB_AP_EXTENDED_METRICS_INFO:
		insert_new_ap_extended_capability(ctx, (struct ap_extended_metrics_lib *)wapp_event->buffer);
		break;

	case LIB_RADIO_METRICS_INFO:
		insert_new_radio_metric(ctx, (struct radio_metrics_lib *)wapp_event->buffer);
		break;

	case LIB_ASSOC_STA_EXTENDED_LINK_METRICS:
		insert_assoc_sta_extended_link_metric(ctx, (struct sta_extended_metrics_lib *)wapp_event->buffer);
		break;
#endif // #ifdef MAP_R2
#ifdef MAP_R3
	case LIB_SET_1905_CONNECTOR:
		{
			struct r3_dpp_information *dpp = &ctx->r3_dpp;
			unsigned char *p = wapp_event->buffer;
			unsigned short len = 0;
			struct r3_member *peer = NULL;

			notice(DEBUG_CAT_DPP, "[LIB_SET_1905_CONNECTOR]\n");
			/* 2 bytes decrypt_fail_threshold */
			ctx->decrypt_fail_threshold = *((unsigned short *)p);
			p += sizeof(unsigned short);

			/* 2 bytes connector len */
			len = *((unsigned short *)p);

			if (len == 0) {
				notice(DEBUG_CAT_DPP, "clear connector\n");
				/* connector */
				if (dpp->connector) {
					os_free(dpp->connector);
					dpp->connector = NULL;
				}

				if (dpp->CsignKey) {
					os_free(dpp->CsignKey);
					dpp->CsignKey = NULL;
				}

				if (dpp->netAccessKey) {
					os_free(dpp->netAccessKey);
					dpp->netAccessKey = NULL;
				}

				map_dpp_save_keys(dpp);

				dpp->initialized = 0;
				ctx->r3_oboard_ctx.active = 0;
				break;
			}
			dpp->connector_len = len;
			p += sizeof(unsigned short);

			/* connector */
			if (dpp->connector)
				os_free(dpp->connector);

			dpp->connector = os_zalloc(len + 1);
			if (!dpp->connector) {
				warn(DEBUG_CAT_DPP, "malloc connector space fail\n");
				break;
			}
			os_memcpy(dpp->connector, p, len);
			dpp->connector[len] = '\0';
			p += len;
			info_hexdump(DEBUG_CAT_DPP, "connector", (u8 *)dpp->connector, len);

			/* 2 bytes CsignKey len */
			len = *((unsigned short *)p);
			dpp->CsignKey_len = len;
			p += sizeof(unsigned short);

			/* CsignKey */
			if (dpp->CsignKey)
				os_free(dpp->CsignKey);

			dpp->CsignKey = os_zalloc(len + 1);
			if (!dpp->CsignKey) {
				warn(DEBUG_CAT_DPP, "malloc CsignKey space fail\n");
				break;
			}
			os_memcpy(dpp->CsignKey, p, len);
			dpp->CsignKey[len] = '\0';
			p += len;
			info_hexdump(DEBUG_CAT_DPP, "CsignKey", dpp->CsignKey, dpp->CsignKey_len);

			/* 2 bytes netAccessKey len */
			len = *((unsigned short *)p);
			dpp->netAccessKey_len = len;
			p += sizeof(unsigned short);

			/* netAccessKey */
			if (dpp->netAccessKey)
				os_free(dpp->netAccessKey);

			dpp->netAccessKey = os_zalloc(len + 1);
			if (!dpp->netAccessKey) {
				warn(DEBUG_CAT_DPP, "malloc netAccessKey space fail\n");
				break;
			}
			os_memcpy(dpp->netAccessKey, p, len);
			dpp->netAccessKey[len] = '\0';
			p += len;
			info_hexdump(DEBUG_CAT_DPP, "netAccessKey", dpp->netAccessKey, dpp->netAccessKey_len);

			/* 4 bytes expiry */
			dpp->netAccessKey_expiry = *(unsigned int *)p;
			p += sizeof(unsigned int);

			map_dpp_save_keys(dpp);

			dpp->initialized = 1;

			/* cancel timer to stop periodic autoconfig search  */
			eloop_cancel_timeout(periodic_send_autoconfig_search, (void *)ctx, NULL);

			/*for ethernet onboarding, trigger dpp discovery when set connector which means
			  *  DPP auth/config procedure have been completed
			  */
			if (ctx->r3_oboard_ctx.active && ctx->r3_oboard_ctx.bh_type == MAP_BH_ETH) {
				notice(DEBUG_CAT_DPP, "ETH case,ready to start dpp introduction with Controller\n");
				peer = get_r3_member(ctx->r3_oboard_ctx.peer_almac);
				if (!peer) {
					notice(DEBUG_CAT_DPP, "fail to start dpp introduction, no R3 member found\n");
					break;
				}
				peer->r3_info.cur_dpp_state = dpp_idle;

				map_cancel_onboarding_timer(ctx, peer);

				map_dpp_trigger_member_dpp_intro(ctx, peer);
			}

		}
		break;

		case LIB_SET_BSS_CONNECTOR:
		{
			struct r3_dpp_information *dpp = &ctx->r3_dpp;
			unsigned char *p = wapp_event->buffer;
			struct bss_connector_item *bc_item = NULL, *bc_item_nxt = NULL;
			struct bss_connector_item bc = {0};
			unsigned short found = 0;
			unsigned char all_zero_mac[ETH_ALEN];

			os_memset(&bc, 0, sizeof(bc));
			os_memset(&all_zero_mac, 0, sizeof(all_zero_mac));

			notice(DEBUG_CAT_DPP, "receive LIB_SET_BSS_CONNECTOR");
			/* mac of apcli */
			os_memcpy(bc.mac_apcli, p, ETH_ALEN);
			p += ETH_ALEN;

			/* almac */
			os_memcpy(bc.almac, p, ETH_ALEN);
			p += ETH_ALEN;

			/* 2 bytes bh connector len */
			bc.bh_connector_len = *((unsigned short *)p);
			p += sizeof(unsigned short);

			/* 2 bytes fh connector len */
			bc.fh_connector_len = *((unsigned short *)p);
			p += sizeof(unsigned short);

			bc.bh_connector = (char *)p;
			p += bc.bh_connector_len;
			bc.fh_connector = (char *)p;
			p += bc.fh_connector_len;

			notice_np(DEBUG_CAT_DPP, ", almac "MACSTR", apcli mac "MACSTR"",
				MAC2STR(bc.almac), MAC2STR(bc.mac_apcli));

			dl_list_for_each_safe(bc_item, bc_item_nxt,
				&dpp->bss_connector_list, struct bss_connector_item, member) {
				if ((!os_memcmp(bc.mac_apcli, all_zero_mac, ETH_ALEN)) &&
					(!os_memcmp(bc.almac, all_zero_mac, ETH_ALEN))) {
					if ((!os_memcmp(bc_item->mac_apcli, bc.mac_apcli, ETH_ALEN)) &&
						(!os_memcmp(bc_item->almac, bc.almac, ETH_ALEN))) {
						notice_np(DEBUG_CAT_DPP, ", update for myself\n");
						found = 1;
						break;
					}
				}
				else if (os_memcmp(bc.mac_apcli, all_zero_mac, ETH_ALEN)) {
					if (!os_memcmp(bc_item->mac_apcli, bc.mac_apcli, ETH_ALEN)) {
						notice_np(DEBUG_CAT_DPP, ", update for wifi case\n");
						found = 1;
						break;
					}
				}
				else if (os_memcmp(bc.almac, all_zero_mac, ETH_ALEN)) {
					if (!os_memcmp(bc_item->almac, bc.almac, ETH_ALEN)) {
						notice_np(DEBUG_CAT_DPP, ", update for eth case\n");
						found = 1;
						break;
					}
				}
			}

			/* update */
			if (found) {
				bc_item->bh_connector_len = bc.bh_connector_len;
				bc_item->fh_connector_len = bc.fh_connector_len;

				if (bc_item->bh_connector) {
					os_free(bc_item->bh_connector);
				}
				if (bc_item->fh_connector) {
					os_free(bc_item->fh_connector);
				}

				bc_item->bh_connector = os_zalloc(bc.bh_connector_len + 1);
				if (!bc_item->bh_connector) {
					return 0;
				}
				bc_item->fh_connector = os_zalloc(bc.fh_connector_len + 1);
				if (!bc_item->fh_connector) {
					os_free(bc_item->bh_connector);
					return 0;
				}

				os_memcpy(bc_item->bh_connector, bc.bh_connector, bc.bh_connector_len);
				bc_item->bh_connector[bc_item->bh_connector_len] = '\0';
				os_memcpy(bc_item->fh_connector, bc.fh_connector, bc.fh_connector_len);
				bc_item->fh_connector[bc_item->fh_connector_len] = '\0';
			}
			/* add new one */
			else {
				bc_item = os_zalloc(sizeof(struct bss_connector_item));
				if (!bc_item) {
					return 0;
				}
				bc_item->bh_connector = os_zalloc(bc.bh_connector_len + 1);
				if (!bc_item->bh_connector) {
					os_free(bc_item);
					return 0;
				}
				bc_item->fh_connector = os_zalloc(bc.fh_connector_len + 1);
				if (!bc_item->fh_connector) {
					os_free(bc_item->bh_connector);
					os_free(bc_item);
					return 0;
				}

				os_memcpy(bc_item->mac_apcli, (unsigned char *)bc.mac_apcli, ETH_ALEN);
				os_memcpy(bc_item->almac, (unsigned char *)bc.almac, ETH_ALEN);
				bc_item->bh_connector_len = bc.bh_connector_len;
				bc_item->fh_connector_len = bc.fh_connector_len;
				os_memcpy(bc_item->bh_connector, bc.bh_connector, bc.bh_connector_len);
				bc_item->bh_connector[bc_item->bh_connector_len] = '\0';
				os_memcpy(bc_item->fh_connector, bc.fh_connector, bc.fh_connector_len);
				bc_item->fh_connector[bc_item->fh_connector_len] = '\0';

				dl_list_add(&dpp->bss_connector_list, &bc_item->member);
			}


			if ((!os_memcmp(bc_item->almac, all_zero_mac, ETH_ALEN)) &&
				os_memcmp(bc_item->mac_apcli, all_zero_mac, ETH_ALEN)) {
				notice(DEBUG_CAT_DPP, "save later for apcli "MACSTR"\n", MAC2STR(bc_item->mac_apcli));
			}
			else {
				map_dpp_save_bss_connector(bc_item);
			}
			debug(DEBUG_CAT_DPP, "bh connector:\n %s\n\n", bc_item->bh_connector);
			debug(DEBUG_CAT_DPP, "fh connector:\n %s\n\n", bc_item->fh_connector);
		}
		break;

		case LIB_SET_CHIRP_VALUE:
		{
			struct chirp_tlv_info *p_chirp_tlv = NULL;

			unsigned char *p = wapp_event->buffer;
			unsigned char *mac1 = p;
			unsigned char all_zero_mac[ETH_ALEN];
			os_memset(all_zero_mac, 0, sizeof(all_zero_mac));

			p += ETH_ALEN;

			p_chirp_tlv = (struct chirp_tlv_info *)p;

			notice(DEBUG_CAT_DPP, "[LIB_SET_CHIRP_VALUE]\n");

			if (!p_chirp_tlv->hash_validity) {
				del_chirp_from_hash_list(ctx, p_chirp_tlv);
				break;
			}

			if ((!os_memcmp(p_chirp_tlv->enrollee_mac, all_zero_mac, ETH_ALEN)) &&
				(!os_memcmp(mac1, all_zero_mac, ETH_ALEN))) {
				if (ctx->role == CONTROLLER)
					break;

				notice(DEBUG_CAT_DPP, "store chirp for myself, will be appened in autoconfig search\n");
			} else {
				notice(DEBUG_CAT_DPP, "store chirp for almac "MACSTR" enrollee mac "MACSTR","
					" will be used in dpp auth to check if chirp match\n",
					MAC2STR(mac1), MAC2STR(p_chirp_tlv->enrollee_mac));
			}

			add_chirp_hash_list(ctx, p_chirp_tlv, ctx->p1905_al_mac_addr);
		}
		break;



		case LIB_SET_GTK_REKEY_INTERVAL:
		{
			unsigned char *p = wapp_event->buffer;
			unsigned int interval = *((unsigned int *)p);

			wpa_set_gtk_rekey_interval(interval);
		}
		break;

		case LIB_SET_R3_ONBOARDING_TYPE:
		{
			struct r3_dpp_information *dpp = &ctx->r3_dpp;

			dpp->onboarding_type = wapp_event->buffer[0];
			if (wapp_event->buffer[0] == 0)
				dpp->onboarding_type = MAP_ONBOARDING_TYPE_DPP;
			else
				dpp->onboarding_type = MAP_ONBOARDING_TYPE_WSC;

			notice(DEBUG_CAT_DPP, "set R3 onboarding type [%s]\n",
				(dpp->onboarding_type == MAP_ONBOARDING_TYPE_DPP)?"DPP":"WSC");
		}
		break;

#endif
#ifdef MAP_R3_WF6
		case LIB_AP_WF6_CAPABILITY:
		{
			struct ap_wf6_cap_roles *cap = NULL;

			cap = (struct ap_wf6_cap_roles *)wapp_event->buffer;
			update_ap_wf6_cap(ctx, cap);
		}
		break;
#endif
#ifdef MAP_R3_DE
		case LIB_DEV_INVEN_TLV:
		{
#ifdef EM_PLUS_SUPPORT
			int ret = 0;

			debug(DEBUG_CAT_DPP, "receive LIB_DEV_INVEN_TLV\n");
			ret = get_dev_inven(ctx);
			if (ret != 0) {
				warn(DEBUG_CAT_DPP, "get dev inven fail!\n");
				break;
			}
#else
			struct dev_inven *de = NULL;

			de = (struct dev_inven *)wapp_event->buffer;
			update_ap_dev_inven(ctx, de);
#endif
		}
		break;
#endif
#ifdef MAP_R3_SP
		case SERVICE_PRIORITIZATION_COMMAND:
		{
#ifdef MAP_R3
			struct sp_cmd *sp = NULL;
#endif
			notice(DEBUG_CAT_SP, "receive SERVICE_PRIORITIZATION_COMMAND\n");
			sp_process_1905_lib_cmd((void *)ctx, wapp_event->buffer, wapp_event->length, reply, reply_len);
#ifdef MAP_R3
			sp = (struct sp_cmd*)wapp_event->buffer;
			if (sp->cmd_id == SP_CMD_CONFIG_DONE)
				report_sp_standard_rule_to_mapd(ctx);
#endif
		}
		break;
#endif
	case LIB_SYNC_BSS_PRIO:
	{
		int ret = 0;

		if (ctx->role != CONTROLLER) {
			err(DEBUG_CAT_EVENT, "ignore the LIB_SYNC_BSS_PRIO event as current role is agent\n");
			break;
		}
		/*step1 update local bss priority on Controller*/
		ret = update_bss_prio_str(ctx, wapp_event->buffer, wapp_event->length);
		if (ret < 0) {
			err(DEBUG_CAT_AUTOCONF, "update_bss_prio_str fail\n");
			goto error;
		}
		ret = set_bss_config_priority_by_str(ctx);
		if (ret < 0)
			err(DEBUG_CAT_AUTOCONF, "set_bss_config_priority_by_str fail\n");
		update_radio_bss_priority(ctx);
		write_bss_prio_to_1905_cfg_file(ctx->map_cfg_file, ctx->bss_priority_str);
		/*step2 sync the new bss priority setting to the whole mesh network*/
		clear_all_agent_bss_prio(ctx);
		sync_bss_prio_to_agent(ctx, NULL);
		if (!SLIST_EMPTY(&ctx->agent_head)) {
			eloop_register_timeout(BSS_PRIO_DONE_TIME, 0, sync_bss_prio_done,
				(void *)ctx, NULL);
		}
	}
		break;
	case LIB_AP_MLO_CAPABILITY:
	{
#if defined(MAP_R6) || defined(EM_PLUS_SUPPORT)
		struct wifi7_ap_mlo_cap_lib *mlo_cap = (struct wifi7_ap_mlo_cap_lib *)wapp_event->buffer;

		delete_wifi7_mld_cap_by_ruid(ctx, mlo_cap->identifier);
		update_wifi7_mlo_cap(ctx, mlo_cap);
#else
		struct ap_mlo_cap_lib *mlo_cap = (struct ap_mlo_cap_lib *)wapp_event->buffer;

		delete_exist_mlo_cap_by_ruid(ctx, mlo_cap->identifier);
		update_radio_mlo_cap(ctx, mlo_cap);
#endif
	}
		break;
#ifdef MAP_R5
	case LIB_QOS_MGMT_TLV_MSG:
	{
		qos_management_tlv_process((void *)ctx, wapp_event->buffer, wapp_event->length);
		break;
	}
	case LIB_QOS_SET_CONFIG:
	{
		ctx->qos_operation_errorcode = set_qos_config((void *)ctx, (char *)wapp_event->buffer);
		return ctx->qos_operation_errorcode;
	}
	case LIB_QOS_GET_CONFIG:
	{
		ctx->qos_operation_errorcode =
			get_qos_config((void *)ctx, (char *)wapp_event->buffer, (char *)reply, reply_len);

		return ctx->qos_operation_errorcode;
	}
	case LIB_QOS_SAVE_CONFIG:
	{
		ctx->qos_operation_errorcode = save_qos_config((void *)ctx);
		return ctx->qos_operation_errorcode;
	}
	case LIB_QOS_GET_ERROR_CODE:
	{
		return get_qos_error_code((void *)ctx, (char *)reply, reply_len);
	}
#endif

	case LIB_EHT_OPERATION:
		update_eht_operations(ctx, wapp_event->buffer);
		break;

#ifdef MAP_R6
	case LIB_AKM_SUITE_CAPABILITY:
			update_akm_capability(ctx, wapp_event->buffer);
		break;

	case LIB_STA_MLD_CONFIG_REPORT:
		{
			struct assoc_client *client = NULL;

			notice(DEBUG_CAT_MLO, "receive LIB_STA_MLD_CONFIG_REPORT\n");
			client = get_assoc_cli_by_mac(ctx, wapp_event->buffer);
			if (!client)
				break;

			ctx->sta_notifier = 1;
			delete_sta_mld_cfg_rpt(&client->sta_mld, wapp_event->buffer);
			update_sta_mld_cfg_rpt(&client->sta_mld, (struct mlo_sta_config *)wapp_event->buffer);

			notice(DEBUG_CAT_MLO, "tx multicast notification(mid-%04x) on all intf\n", ctx->mid);
			/*send notification with assoc sta info to notify MLD STA is conneceted */
			ctx->mid++;
			multicast_cmdu_tx(ctx, e_topology_notification, ctx->mid, 1);

			report_own_topology_rsp(ctx, ctx->p1905_al_mac_addr, ctx->br_cap,
				ctx->p1905_neighbor_dev, ctx->non_p1905_neighbor_dev,
				ctx->service, &ctx->ap_cap_entry.oper_bss_head,
				&ctx->ap_cap_entry.assoc_clients_head, ctx->cnt);
		}
		break;

	case LIB_AFC_SPECTRUM_RESPONSE:
	{
		if (fill_send_tlv(ctx, wapp_event->buffer, wapp_event->length) < 0)
			break;
		debug(DEBUG_CAT_MLO, "send AFC_SPECTRUM_RESPONSE to "MACSTR"\n",
			PRINT_MAC(ctx->cinfo.almac));
		insert_cmdu_txq(ctx->cinfo.almac, ctx->p1905_al_mac_addr,
			e_afc_spectrum_inquiry_msg, ++ctx->mid, ctx->cinfo.local_ifname, 0);
	}
	break;
#endif

#ifdef EM_PLUS_SUPPORT
	case LIB_RADIO_TEMPERATURE:
	{
		int ret = 0;

		ret = update_radio_temperature(ctx, wapp_event->buffer, wapp_event->length);
		if (ret < 0) {
			err(DEBUG_CAT_EMPLUS, "radio temperature format error\n");
			goto error;
		}
	}
	break;
#endif
	case LIB_T2LM_CONFIGURATION:
	{
		update_t2lm_confirguration(ctx, wapp_event->buffer, wapp_event->length);
	}
	break;
	case LIB_NEW_INTERFACE_EVENT:
		handle_new_interface_event(ctx, wapp_event->buffer);
		break;
	case LIB_DEL_INTERFACE_EVENT:
		handle_del_interface_event(ctx, wapp_event->buffer);
		break;
	default:
		err(DEBUG_CAT_EVENT, "unknown lib event=0x%04x\n", wapp_event->type);
		break;
	}
	return 0;
error:
	err(DEBUG_CAT_EVENT, "err lib event; type=0x%04x(%s)\n",
		wapp_event->type, get_1905_lib_event_str(wapp_event->type));
	err_hexdump(DEBUG_CAT_EVENT, "event dump", wapp_event->buffer, wapp_event->length);
	return -1;
}

int change_role_dynamic(struct p1905_managerd_ctx* ctx, unsigned char role)
{
	if (ctx->current_autoconfig_info.radio_index != -1) {
		err(DEBUG_CAT_AUTOCONF, "auto configuration is ongoing; reject role change\n");
		return -1;
	}
	if (ctx->role == CONTROLLER) {
		err(DEBUG_CAT_EVENT, "can't set controller to other role\n");
		return -1;
	}
	if (ctx->role == role) {
		err(DEBUG_CAT_EVENT, "already set the role to agent\n");
		return -1;
	}

	ctx->role = role;
	ctx->service = ctx->role;
	err(DEBUG_CAT_EVENT, "change role from agent to controller; send topo notification to MAP network\n");
	ctx->mid++;
	multicast_cmdu_tx(ctx, e_topology_notification, ctx->mid, 1);

	return 0;
}

int get_local_device_info(struct p1905_managerd_ctx* ctx, unsigned char *buf,
	unsigned int buf_len, unsigned short *len)
{
	unsigned char *p = NULL, *old_p = NULL;
	int i = 0;
	unsigned int expected_len = 0;

	/*pre-check length of buf to avoid memory overwritten*/
	expected_len += 15 + 8 * ctx->itf_number;
	for (i = 0; i < BRIDGE_NUM; i++) {
		expected_len += 2 + os_strlen((char*)ctx->br_name) +
			ETH_ALEN * ctx->br_cap[i].interface_num;
	}

	if (expected_len > buf_len) {
		err(DEBUG_CAT_MSG, "len is not enough to get local device info; "
			"expected_len=%d; buf_len=%d\n",
			expected_len, buf_len);
		return -1;
	}

	p = buf;
	*(unsigned short*)p = MANAGE_GET_LOCAL_DEVINFO;
	p += sizeof(unsigned short);

	/*mid*/
	p += sizeof(unsigned short);

	old_p = p;

	p += sizeof(unsigned short);
	/*device info*/
	memcpy(p, ctx->p1905_al_mac_addr, ETH_ALEN);
	p += ETH_ALEN;

	*p++ = (unsigned char)ctx->itf_number;

	for (i = 0; i < ctx->itf_number; i++) {
		memcpy(p, ctx->itf[i].mac_addr, ETH_ALEN);
		p += ETH_ALEN;
		memcpy(p, &(ctx->itf[i].media_type), sizeof(unsigned short));
		p += sizeof(unsigned short);
	}

	/*bridge capa*/
	*p++ = BRIDGE_NUM;
	for (i = 0; i < BRIDGE_NUM; i++) {
		*p++ = os_strlen((char*)ctx->br_name);
		os_strncpy((char*)p, (char*)ctx->br_name, os_strlen((char*)ctx->br_name));
		p += os_strlen((char*)ctx->br_name);
		*p++ = ctx->br_cap[i].interface_num;
		memcpy(p, ctx->br_cap[i].itf_mac_list, ctx->br_cap[i].interface_num * ETH_ALEN);
		p += ctx->br_cap[i].interface_num * ETH_ALEN;
	}

	/*supported service*/
	*p++ = 1;
	*p++ = ctx->service;

	*(unsigned short*)old_p = (unsigned short)(p - old_p - 2);
	*len = (unsigned short)(p - buf);

	return 0;
}


int set_bss_config(struct p1905_managerd_ctx *ctx, enum BSS_CONFIG_OPERATION operation,
	struct bss_config_info* info)
{
	unsigned char i = 0, j = 0, k = 0;
	unsigned char band_mask = 0x01;
	struct config_info* conf = NULL;
	char opclass[3][4] = {"8x", "11x", "12x"};
	char buf[256] = {0};

	if (operation == BSS_ADD)
		j = ctx->bss_config_num;

	conf = info->info;
	for (i = 0; i < info->cnt; i++) {
		for (k = 0; k < 3; k ++) {
			if ((conf->band & (band_mask << k)) == 0x00) {
				continue;
			}
			memset(&(ctx->bss_config[j]), 0, sizeof(struct set_config_bss_info));
			memcpy(ctx->bss_config[j].mac, conf->almac, ETH_ALEN);
			ctx->bss_config[j].authmode = conf->auth_mode;
			ctx->bss_config[j].encryptype = conf->encry_type;
			ctx->bss_config[j].wfa_vendor_extension = conf->wfa_vendor_extension;
			ctx->bss_config[j].hidden_ssid = conf->hidden_ssid;
			(void)snprintf(ctx->bss_config[j].ssid, sizeof(ctx->bss_config[j].ssid), "%s", conf->ssid);
			memcpy(ctx->bss_config[j].key, conf->key, 64);
			ctx->bss_config[j].key[64] = '\0';
			memcpy(ctx->bss_config[j].oper_class, opclass[k], 3);
			ctx->bss_config[j].oper_class[3] = '\0';
			notice(DEBUG_CAT_AUTOCONF, "add bss; mac="MACSTR"; opclass=%s;"
				" ssid=%s; authmode=%04x(%s); encrytype=%04x(%s); key=%s; bh_bss=%s; fh_bss=%s; "
				"hidden_ssid=%d\n",
				PRINT_MAC(ctx->bss_config[j].mac), ctx->bss_config[j].oper_class,
				ctx->bss_config[j].ssid,
				ctx->bss_config[j].authmode,
				get_authmode_str(ctx->bss_config[j].authmode, buf, 256),
				ctx->bss_config[j].encryptype,
				get_encryption_str(ctx->bss_config[j].encryptype),
				ctx->bss_config[j].key,
				ctx->bss_config[j].wfa_vendor_extension & BIT_BH_BSS ? "1" : "0",
				ctx->bss_config[j].wfa_vendor_extension & BIT_FH_BSS ? "1" : "0",
				ctx->bss_config[j].hidden_ssid);
			j++;
		}
		conf++;
	}
	ctx->bss_config_num = j;
	notice(DEBUG_CAT_AUTOCONF, "total %d bss config number\n", ctx->bss_config_num);

	return 0;
}

int read_bss_conf_and_renew_v2(struct p1905_managerd_ctx *ctx, unsigned char local_only) {
	/*update bss setting into ctx->bss_config*/
	if (_1905_read_set_config(ctx, ctx->wts_bss_cfg_file, ctx->bss_config, MAX_SET_BSS_INFO_NUM, &ctx->bss_config_num) < 0 ||
		(ctx->bss_config_num == 0)) {
		warn(DEBUG_CAT_RENEW, "read wts_bss_info_config fail or no valid bss info\n");
		return -1;
	}
	notice(DEBUG_CAT_RENEW, "renew start, radio_number=%d\n", ctx->radio_number);
	ctx->renew_ctx.trigger_renew = 1;
	ctx->renew_state = wait_4_dump_topo;
	eloop_register_timeout(0, 0, controller_renew_bss_step, (void *)ctx, NULL);

	return 0;
}


int read_bss_conf_and_renew(struct p1905_managerd_ctx *ctx, unsigned char local_only)
{
	int i = 0;
	unsigned char band = 0;
	unsigned char buffer[1514] = {0};

	/*update bss setting into ctx->bss_config*/
	if (_1905_read_set_config(ctx, ctx->wts_bss_cfg_file, ctx->bss_config, MAX_SET_BSS_INFO_NUM, &ctx->bss_config_num) < 0 ||
		(ctx->bss_config_num == 0)) {
		warn(DEBUG_CAT_RENEW, "read wts_bss_info_config fail or no valid bss info\n");
		return -1;
	}

	notice(DEBUG_CAT_RENEW, "renew start, radio_number=%d\n", ctx->radio_number);
	ctx->block_bss_info.auto_config_num = 0;

	delete_ap_mld_conf(&ctx->wts_ctrl_mld_cfg);
	for (i = 0; i < ctx->radio_number; i++)
		_1905_update_bss_info_per_radio(ctx, &ctx->rinfo[i]);

	/* notify ap mld config on controller */
	if (dl_list_empty(&ctx->wts_ctrl_mld_cfg.mlo_cfg_list)) {
		notice(DEBUG_CAT_MLO,
			RED("no mld group configured in wts file, please check!!!!\n"));
	} else {
		for (i = 0; i < ctx->radio_number; i++) {
			debug(DEBUG_CAT_RENEW, "ruid "MACSTR" mlo enable %d\n",
				MAC2STR(ctx->rinfo[i].identifier), ctx->rinfo[i].mlo_cap);
			if (ctx->rinfo[i].mlo_cap) {
				_1905_notify_ap_mld_config(ctx, &ctx->wts_ctrl_mld_cfg, 0);
				break;
			}
		}
	}

#ifdef MAP_R2
	eloop_register_timeout(3, 0, map_r2_notify_ts_config, (void *)ctx, NULL);
	eloop_register_timeout(0, 0, map_notify_transparent_vlan_setting, (void *)ctx, NULL);
#endif


	if (!local_only) {
			band = 0;
			ctx->mid++;
			if (fill_send_tlv(ctx, &band, 1) < 0) {
				return 0;
			}

			for(i = 0; i < ctx->itf_number; i++) {
				insert_cmdu_txq(p1905_multicast_address, ctx->p1905_al_mac_addr,
					e_ap_autoconfiguration_renew, ctx->mid, ctx->itf[i].if_name, 0);
				debug(DEBUG_CAT_AUTOCONF, "insert renew message for %s band(%s)\n", ctx->itf[i].if_name, "2g");
#ifdef SUPPORT_CMDU_RELIABLE
				cmdu_reliable_send(ctx, e_ap_autoconfiguration_renew, ctx->mid, i);
#endif
			}
			/*handle the txq before insert another band renew message*/
			process_cmdu_txq(ctx, buffer);

			band = 1;
			ctx->mid++;
			if (fill_send_tlv(ctx, &band, 1) < 0) {
				return 0;
			}

			for(i = 0; i < ctx->itf_number; i++) {
				insert_cmdu_txq(p1905_multicast_address, ctx->p1905_al_mac_addr,
					e_ap_autoconfiguration_renew, ctx->mid, ctx->itf[i].if_name, 0);
				debug(DEBUG_CAT_AUTOCONF, "insert renew message for %s band(%s)\n", ctx->itf[i].if_name, "5g");
#ifdef SUPPORT_CMDU_RELIABLE
				cmdu_reliable_send(ctx, e_ap_autoconfiguration_renew, ctx->mid, i);
#endif
			}
			process_cmdu_txq(ctx, buffer);
	}
	return 0;
}


void init_radio_info_by_intf(struct p1905_managerd_ctx* ctx, struct p1905_interface *itf)
{
	unsigned char i = 0, j = 0;
	unsigned int k = 0;

	for (i = 0; i < ctx->radio_number; i++) {
		if (!os_memcmp(ctx->rinfo[i].identifier, itf->identifier, ETH_ALEN)) {
			for (j = 0; j < ctx->rinfo[i].bss_number; j++) {
				if (!os_memcmp(ctx->rinfo[i].bss[j].ifname, itf->if_name, IFNAMSIZ)) {
					break;
				}
			}
			if (j >= ctx->rinfo[i].bss_number) {
				if (ctx->rinfo[i].bss_number >= MAX_BSS_NUM) {
					info(DEBUG_CAT_INIT, DYN_INTF_PREX"rinfo[%d] bss_num is max %d, can not add new itf\n",
						i, ctx->rinfo[i].bss_number);
					break;
				}
				k = ctx->rinfo[i].bss_number;
				os_memcpy(ctx->rinfo[i].bss[k].ifname, itf->if_name, IFNAMSIZ);
				os_memcpy(ctx->rinfo[i].bss[k].mac, itf->mac_addr, ETH_ALEN);
				ctx->rinfo[i].bss[k].priority = 0;
				ctx->rinfo[i].bss_number++;
			}
			break;
		}
	}

	if (ctx->radio_number == MAX_RADIO_NUM) {
		err(DEBUG_CAT_INIT, "can't add raid "MACSTR"; radio number exceeds maximum(%d)\n",
			MAC2STR(itf->identifier), MAX_RADIO_NUM);
		return;
	}

	/*new radio, add new one*/
	if (i >= ctx->radio_number) {
		os_memcpy(ctx->rinfo[ctx->radio_number].identifier, itf->identifier, ETH_ALEN);
		ctx->rinfo[ctx->radio_number].bss_number = 1;
		(void)os_snprintf((char *)ctx->rinfo[ctx->radio_number].bss[0].ifname,
			sizeof(ctx->rinfo[ctx->radio_number].bss[0].ifname), "%s", itf->if_name);
		os_memcpy(ctx->rinfo[ctx->radio_number].bss[0].mac, itf->mac_addr, ETH_ALEN);
		ctx->rinfo[ctx->radio_number].bss[0].priority= 0;

		if (ctx->rinfo[ctx->radio_number].basic_cap.op_class_num &&
			!dl_list_empty(&ctx->rinfo[ctx->radio_number].basic_cap.op_class_list)) {
			struct operating_class *opc = NULL, *opc_tmp = NULL;

			dl_list_for_each_safe(opc, opc_tmp, &ctx->rinfo[ctx->radio_number].basic_cap.op_class_list, struct operating_class, entry) {
				dl_list_del(&opc->entry);
				os_free(opc);
			}
			info(DEBUG_CAT_INIT, "radio "MACSTR" op_class_lis free done\n", MAC2STR(ctx->rinfo[ctx->radio_number].identifier));
		}

		dl_list_init(&ctx->rinfo[ctx->radio_number].basic_cap.op_class_list);
		ctx->rinfo[ctx->radio_number].basic_cap.op_class_num = 0;
		ctx->rinfo[ctx->radio_number].basic_cap.max_bss_num = 0;
		ctx->radio_number++;
	}

	/*set the priority to the bss that will be configured*/
	for (i = 0; i < ctx->radio_number; i++) {
		if (!os_memcmp(ctx->rinfo[i].identifier, itf->identifier, ETH_ALEN)) {
			for (j = 0; j < ctx->rinfo[i].bss_number; j++) {
				for (k = 0; k < ctx->itf_number; k++) {
					/*if (os_strcmp((char*)ctx->rinfo[i].bss[j].ifname, (char*)ctx->itf[k].if_name) == 0) {*/
					if (os_memcmp((char*)ctx->rinfo[i].bss[j].mac, (char*)ctx->itf[k].mac_addr, ETH_ALEN) == 0) {
						ctx->rinfo[i].bss[j].priority = ctx->itf[k].config_priority;
					}
				}
			}
			break;
		}
	}
}

void metrics_report_timeout(void *eloop_data, void *user_ctx)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx *)eloop_data;

	/*build ap metric query tlv*/
	build_ap_metric_query_tlv(ctx);

	_1905_notify_ap_metrics_query(ctx, ctx->cinfo.almac, 0
#ifdef MAP_R2
	, 1
#endif
	);
	common_process(ctx, &ctx->trx_buf);

	eloop_register_timeout(ctx->map_policy.mpolicy.report_interval, 0,
		metrics_report_timeout, eloop_data, NULL);
}



void attach_action(void *eloop_data, void *user_ctx)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx*)eloop_data;
	struct topology_discovery_db *tpg_db = NULL;
	struct topology_response_db *tpgr_db = NULL;
	static int i = 2;

	report_own_topology_rsp(ctx, ctx->p1905_al_mac_addr, ctx->br_cap,
				ctx->p1905_neighbor_dev, ctx->non_p1905_neighbor_dev,
				ctx->service, &ctx->ap_cap_entry.oper_bss_head,
				&ctx->ap_cap_entry.assoc_clients_head, ctx->cnt);
    LIST_FOREACH(tpg_db, &ctx->topology_entry.tpddb_head, tpddb_entry) {
		insert_cmdu_txq(tpg_db->al_mac, ctx->p1905_al_mac_addr,
			e_topology_query, ++ctx->mid, ctx->br_name, 0);
    }
	SLIST_FOREACH(tpgr_db, &ctx->topology_entry.tprdb_head, tprdb_entry) {
		insert_cmdu_txq(tpgr_db->al_mac_addr, ctx->p1905_al_mac_addr,
			e_topology_query, ++ctx->mid, ctx->br_name, 0);
	}

	i--;
	if (i == 0) {
		i = 2;
		return;
	}

	eloop_register_timeout(1, 0, attach_action, (void *)ctx, NULL);
}



void reset_controller_connect_ifname(struct p1905_managerd_ctx *ctx,
	unsigned char *link_down_ifname)
{
	int i = 0;

	if (ctx->role == CONTROLLER)
		return;

	if (os_memcmp(link_down_ifname, ctx->cinfo.local_ifname, IFNAMSIZ))
		return;

	for (i = 0; i < ctx->itf_number; i++) {
		if (ctx->itf[i].is_wifi_sta &&
			os_memcmp(ctx->itf[i].if_name, ctx->cinfo.local_ifname, IFNAMSIZ) &&
			ctx->itf[i].trx_config & (TX_MUL | TX_UNI)) {
			notice(DEBUG_CAT_ONBOARD, "local_ifname(%s) link down; use another one(%s)\n",
				ctx->cinfo.local_ifname, ctx->itf[i].if_name);
			os_memcpy(ctx->cinfo.local_ifname, ctx->itf[i].if_name, IFNAMSIZ);
			return;
		}
	}
}

/**
 *  find remote device's al mac address
 *
 *
 * \param  ctx  1905.1 managerd context
 * \param  mac_addr  input, use the sa mac value we got from other unicast message .
 * \param  al_mac_addr  output, provide the al mac
 * \return error code
 */
int find_al_mac_address(struct p1905_managerd_ctx *ctx, unsigned char *mac_addr, unsigned char *al_mac_addr)
{
	struct topology_discovery_db *tpg_db;
	struct topology_response_db *tpgr_db;
	struct device_info_db *dev_db;
	int result = -1;

	/*search in topology discovery database */
	if (!LIST_EMPTY(&(ctx->topology_entry.tpddb_head))) {
		LIST_FOREACH(tpg_db, &(ctx->topology_entry.tpddb_head), tpddb_entry) {
			if (!memcmp(mac_addr, tpg_db->al_mac, ETH_ALEN)) {
				memcpy(al_mac_addr, mac_addr, ETH_ALEN);
				result = 0;
				goto find_finish;
			}
			if (!memcmp(mac_addr, tpg_db->itf_mac, ETH_ALEN)) {
				memcpy(al_mac_addr, tpg_db->al_mac, ETH_ALEN);
				result = 0;
				goto find_finish;
			}
		}
	}
	/* search in topology response database
	 * if no matched al mac in topology discovery databse, it means this
	 * device is not a neighbor. So we check the topology response database
	 * to find any matched device
	 */
	if (!SLIST_EMPTY(&(ctx->topology_entry.tprdb_head))) {
		SLIST_FOREACH(tpgr_db, &(ctx->topology_entry.tprdb_head), tprdb_entry) {
			if (!memcmp(mac_addr, tpgr_db->al_mac_addr, ETH_ALEN)) {
				memcpy(al_mac_addr, mac_addr, ETH_ALEN);
				result = 0;
				goto find_finish;
			}
			if (!SLIST_EMPTY(&(tpgr_db->devinfo_head))) {
				SLIST_FOREACH(dev_db, &(tpgr_db->devinfo_head), devinfo_entry) {
					if (!memcmp(mac_addr, dev_db->mac_addr, ETH_ALEN)) {
						memcpy(al_mac_addr, tpgr_db->al_mac_addr, ETH_ALEN);
						result = 0;
						goto find_finish;
					}
				}
			}
		}
	}

find_finish:
	return result;
}



static inline int eth_link_mode_test_bit(unsigned int nr, const unsigned int *mask)
{
	if (nr >= LINK_MODE_MASK_MAX_KERNEL_NBITS)
		return 0;
	return ((mask[nr / LINK_MODE_MASK_INT_NBITS] &
		(1 << (nr % LINK_MODE_MASK_INT_NBITS))) != 0);
}


void update_eth_intf_media_type(struct p1905_managerd_ctx *ctx)
{
#ifndef KERNEL_VERSION_4_4
	unsigned int intf_idx = 0, speed = 0;
	int sockfd = 0;
	struct ifreq ifr = {0};
	unsigned int link_usettings[LINK_MODE_MASK_MAX_KERNEL_NU32];
	struct {
		struct ethtool_link_settings req;
		unsigned int link_mode_data[3 * LINK_MODE_MASK_MAX_KERNEL_NU32];
	} ecmd;
	static const struct {
		unsigned int bit_index;
		const unsigned int speed;
	} mode_defs[] = {
		{ ETHTOOL_LINK_MODE_10baseT_Half_BIT, 10 },
		{ ETHTOOL_LINK_MODE_10baseT_Full_BIT, 10 },
		{ ETHTOOL_LINK_MODE_100baseT_Half_BIT, 100 },
		{ ETHTOOL_LINK_MODE_100baseT_Full_BIT, 100 },
		{ ETHTOOL_LINK_MODE_1000baseT_Half_BIT, 1000 },
		{ ETHTOOL_LINK_MODE_1000baseT_Full_BIT, 1000 },
		{ ETHTOOL_LINK_MODE_10000baseT_Full_BIT, 10000 },
		{ ETHTOOL_LINK_MODE_2500baseX_Full_BIT, 2500 },
		{ ETHTOOL_LINK_MODE_1000baseKX_Full_BIT, 1000 },
		{ ETHTOOL_LINK_MODE_10000baseKX4_Full_BIT, 10000 },
		{ ETHTOOL_LINK_MODE_10000baseKR_Full_BIT, 10000 },
		{ ETHTOOL_LINK_MODE_10000baseR_FEC_BIT, 10000 },
		{ ETHTOOL_LINK_MODE_20000baseMLD2_Full_BIT, 20000 },
		{ ETHTOOL_LINK_MODE_20000baseKR2_Full_BIT, 20000 },
		{ ETHTOOL_LINK_MODE_40000baseKR4_Full_BIT, 40000 },
		{ ETHTOOL_LINK_MODE_40000baseCR4_Full_BIT, 40000 },
		{ ETHTOOL_LINK_MODE_40000baseSR4_Full_BIT, 40000 },
		{ ETHTOOL_LINK_MODE_40000baseLR4_Full_BIT, 40000 },
		{ ETHTOOL_LINK_MODE_56000baseKR4_Full_BIT, 56000 },
		{ ETHTOOL_LINK_MODE_56000baseCR4_Full_BIT, 56000 },
		{ ETHTOOL_LINK_MODE_56000baseSR4_Full_BIT, 56000 },
		{ ETHTOOL_LINK_MODE_56000baseLR4_Full_BIT, 56000 },
		{ ETHTOOL_LINK_MODE_25000baseCR_Full_BIT, 25000 },
		{ ETHTOOL_LINK_MODE_25000baseKR_Full_BIT, 25000 },
		{ ETHTOOL_LINK_MODE_25000baseSR_Full_BIT, 25000 },
		{ ETHTOOL_LINK_MODE_50000baseCR2_Full_BIT, 50000 },
		{ ETHTOOL_LINK_MODE_50000baseKR2_Full_BIT, 50000 },
		{ ETHTOOL_LINK_MODE_100000baseKR4_Full_BIT, 100000 },
		{ ETHTOOL_LINK_MODE_100000baseSR4_Full_BIT, 100000 },
		{ ETHTOOL_LINK_MODE_100000baseCR4_Full_BIT, 100000 },
		{ ETHTOOL_LINK_MODE_100000baseLR4_ER4_Full_BIT, 100000 },
		{ ETHTOOL_LINK_MODE_50000baseSR2_Full_BIT, 50000 },
		{ ETHTOOL_LINK_MODE_1000baseX_Full_BIT, 1000 },
		{ ETHTOOL_LINK_MODE_10000baseCR_Full_BIT, 10000 },
		{ ETHTOOL_LINK_MODE_10000baseSR_Full_BIT, 10000 },
		{ ETHTOOL_LINK_MODE_10000baseLR_Full_BIT, 10000 },
		{ ETHTOOL_LINK_MODE_10000baseLRM_Full_BIT, 10000 },
		{ ETHTOOL_LINK_MODE_10000baseER_Full_BIT, 10000 },
		{ ETHTOOL_LINK_MODE_2500baseT_Full_BIT, 2500 },
		{ ETHTOOL_LINK_MODE_5000baseT_Full_BIT, 5000 },
		{ ETHTOOL_LINK_MODE_50000baseKR_Full_BIT, 50000 },
		{ ETHTOOL_LINK_MODE_50000baseSR_Full_BIT, 50000 },
		{ ETHTOOL_LINK_MODE_50000baseCR_Full_BIT, 50000 },
		{ ETHTOOL_LINK_MODE_50000baseLR_ER_FR_Full_BIT, 50000 },
		{ ETHTOOL_LINK_MODE_50000baseDR_Full_BIT, 50000 },
		{ ETHTOOL_LINK_MODE_100000baseKR2_Full_BIT, 100000 },
		{ ETHTOOL_LINK_MODE_100000baseSR2_Full_BIT, 100000 },
		{ ETHTOOL_LINK_MODE_100000baseCR2_Full_BIT, 100000 },
		{ ETHTOOL_LINK_MODE_100000baseLR2_ER2_FR2_Full_BIT, 100000 },
		{ ETHTOOL_LINK_MODE_100000baseDR2_Full_BIT, 100000 },
		{ ETHTOOL_LINK_MODE_100baseT1_Full_BIT, 100 },
		{ ETHTOOL_LINK_MODE_1000baseT1_Full_BIT, 1000 },
	};

	sockfd = socket(AF_INET, SOCK_DGRAM, 0);
	if (sockfd == -1) {
		err(DEBUG_CAT_INIT, "fail to create socket to get interface speed!\n");
		return;
	}

	for (intf_idx = 0; intf_idx < ITF_NUM; intf_idx++) {
		if ((os_strlen((char *)ctx->itf[intf_idx].if_name) == 0) ||
			(ctx->itf[intf_idx].media_type != IEEE802_3_GROUP))
			continue;

		os_memset(&ifr, 0, sizeof(ifr));
		os_memset(&ecmd, 0, sizeof(ecmd));
		speed = 0;

		err(DEBUG_CAT_INIT, "interface %s:\n", (char *)ctx->itf[intf_idx].if_name);

		/* Handshake with kernel to determine number of words for link
		 * mode bitmaps. When requested number of bitmap words is not
		 * the one expected by kernel, the latter returns the integer
		 * opposite of what it is expecting. We request length 0 below
		 * (aka. invalid bitmap length) to get this info.
		 */
		ecmd.req.cmd = ETHTOOL_GLINKSETTINGS;
		ifr.ifr_data = (caddr_t)&ecmd;
		os_strncpy(ifr.ifr_name, (char *)ctx->itf[intf_idx].if_name, IFNAMSIZ - 1);
		ifr.ifr_name[IFNAMSIZ - 1] = '\0';
		if (ioctl(sockfd, SIOCETHTOOL, &ifr) < 0) {
			debug(DEBUG_CAT_INIT, "fail to SIOCETHTOOL\n");
			goto remains;
		}
		debug(DEBUG_CAT_INIT, "link_mode_masks_nwords %d from kernel\n",
			ecmd.req.link_mode_masks_nwords);

		/* see above: we expect a strictly negative value from kernel */
		if (ecmd.req.link_mode_masks_nwords >= 0 ||
			ecmd.req.cmd != ETHTOOL_GLINKSETTINGS) {
			debug(DEBUG_CAT_INIT, "invalid link_mode_masks_nwords %d from kernel\n",
				ecmd.req.link_mode_masks_nwords);
			goto remains;
		}

		/* got the real ecmd.req.link_mode_masks_nwords,
		 * now send the real request
		 */
		ecmd.req.cmd = ETHTOOL_GLINKSETTINGS;
		ecmd.req.link_mode_masks_nwords = -ecmd.req.link_mode_masks_nwords;
		ifr.ifr_data = (caddr_t)&ecmd;
		os_strncpy(ifr.ifr_name, (char *)ctx->itf[intf_idx].if_name, IFNAMSIZ - 1);
		ifr.ifr_name[IFNAMSIZ - 1] = '\0';
		if (ioctl(sockfd, SIOCETHTOOL, &ifr) < 0) {
			debug(DEBUG_CAT_INIT, "fail to SIOCETHTOOL\n");
			goto remains;
		}
		debug(DEBUG_CAT_INIT, "real link_mode_masks_nwords %d\n",
			ecmd.req.link_mode_masks_nwords);

		if (ecmd.req.link_mode_masks_nwords <= 0
			|| ecmd.req.cmd != ETHTOOL_GLINKSETTINGS) {
			debug(DEBUG_CAT_INIT, "invalid real link_mode_masks_nwords %d\n",
				ecmd.req.link_mode_masks_nwords);
			goto remains;
		}

		os_memcpy(link_usettings,
			   &ecmd.link_mode_data[0],
			   4 * ecmd.req.link_mode_masks_nwords);

		for (int i = 0; i < ARRAY_SIZE(mode_defs); i++) {
			if (eth_link_mode_test_bit(mode_defs[i].bit_index, link_usettings)) {
				debug(DEBUG_CAT_INIT, "speed %d\n", mode_defs[i].speed);
				if (mode_defs[i].speed > speed) {
					speed = mode_defs[i].speed;
					debug(DEBUG_CAT_INIT, "final speed %d\n", speed);
				}

				if (speed > mode_defs[ETHTOOL_LINK_MODE_100baseT_Full_BIT].speed) {
					ctx->itf[intf_idx].media_type = IEEE802_3_AB_GROUP;
					err(DEBUG_CAT_INIT, "MediaType change to 802_3_ab(1G)\n");
					break;
				}
			}

		}
remains:
		if (ctx->itf[intf_idx].media_type == IEEE802_3_GROUP)
			err(DEBUG_CAT_INIT, "MediaType remains 802_3_u(100M)\n");
	}

	close(sockfd);
#endif
}

int init_interface_socket(struct p1905_managerd_ctx *ctx)
{
	unsigned int i = 0;
	struct sockaddr_ll sll;
	struct ifreq ifr;
	int ret = 0;

	for (i = 0; i < ctx->itf_number; i++) {
		errno = 0;
		ctx->sock_inf_recv_1905[i] = socket(AF_PACKET, SOCK_RAW, ETH_P_1905);
		if (ctx->sock_inf_recv_1905[i] < 0) {
			err(DEBUG_CAT_INIT, "can't create socket on %s; errno=%d(%s)",
				ctx->itf[i].if_name, errno, strerror(errno));
			goto fail;
		}

		os_memset(&ifr, 0, sizeof(ifr));
		ret = snprintf(ifr.ifr_name, sizeof(ifr.ifr_name), "%s", ctx->itf[i].if_name);
		if (os_snprintf_error(sizeof(ifr.ifr_name), ret)) {
			err(DEBUG_CAT_INIT, "snprintf fail!\n");
			goto fail;
		}
		errno = 0;
		if ((ioctl(ctx->sock_inf_recv_1905[i], SIOCGIFINDEX, &ifr)) == -1) {
			err(DEBUG_CAT_INIT, "can't get ifindex for %s; errno=%d(%s)\n",
				ctx->itf[i].if_name, errno, strerror(errno));
			goto fail;
		}

		os_memset(&sll, 0, sizeof(sll));
		sll.sll_family = AF_PACKET;
		sll.sll_ifindex = ifr.ifr_ifindex;
		ctx->itf[i].if_index = ifr.ifr_ifindex;
		sll.sll_protocol = host_to_be16(ETH_P_1905);

		/*Get interface mac address*/
		errno = 0;
		if ((ioctl(ctx->sock_inf_recv_1905[i], SIOCGIFHWADDR, &ifr)) == -1) {
			err(DEBUG_CAT_INIT, "can't get mac address for %s; errno=%d(%s)",
				ctx->itf[i].if_name, errno, strerror(errno));
			goto fail;
		}
		ether_addr_copy(ctx->itf[i].mac_addr, ifr.ifr_hwaddr.sa_data);

		errno = 0;
		if ((bind(ctx->sock_inf_recv_1905[i], (struct sockaddr *)&sll,
			sizeof(struct sockaddr_ll))) == -1) {
			err(DEBUG_CAT_INIT, "can't bind raw socket for %s; errno=%d(%s)",
				ctx->itf[i].if_name, errno, strerror(errno));
			goto fail;
		}

		ctx->itf[i].trx_config = 0;
	}

#ifdef SINGLE_BAND_SUPPORT
	ctx->wifi_present = 1;
#endif

	return 0;
fail:
	if (ctx->sock_inf_recv_1905[i] > 0) {
		close(ctx->sock_inf_recv_1905[i]);
		ctx->sock_inf_recv_1905[i] = -1;
	}
#ifdef SINGLE_BAND_SUPPORT
	ctx->wifi_present = 0;
	return 0;
#endif
	return -1;
}

int init_wireless_interface(struct p1905_managerd_ctx *ctx,
	struct interface_info_list_hdr *info)
{
	int i = 0;
	unsigned int itf_idx = 0;

	if (info->interface_count > ITF_NUM - 5) {
		err(DEBUG_CAT_EVENT, "intf num [%d] bigger than maxmum [%d]\n",
			info->interface_count, ITF_NUM - 5);
		return -1;
	}
	for (i = 0; i < info->interface_count; i++) {
		itf_idx = ctx->itf_number;

		os_strncpy((char *)ctx->itf[itf_idx].if_name, (char *)info->if_info[i].if_name, IFNAMSIZ-1);
		ether_addr_copy(ctx->itf[itf_idx].mac_addr, info->if_info[i].if_mac_addr);

		/* role */
		if (os_strcmp((char *)info->if_info[i].if_role, "wiap") == 0)
			ctx->itf[itf_idx].is_wifi_ap = 1;
		else
			ctx->itf[itf_idx].is_wifi_sta = 1;

		/* media type */
		if (info->if_info[i].if_ch <= 14 && os_strcmp((char *)info->if_info[i].if_phymode, "B") == 0)
			ctx->itf[itf_idx].media_type = IEEE802_11B_24G_GROUP;
		else if (info->if_info[i].if_ch <= 14 && os_strcmp((char *)info->if_info[i].if_phymode, "G") == 0)
			ctx->itf[itf_idx].media_type = IEEE802_11G_24G_GROUP;
		else if (info->if_info[i].if_ch <= 14 && os_strcmp((char *)info->if_info[i].if_phymode, "N") == 0)
			ctx->itf[itf_idx].media_type = IEEE802_11N_24G_GROUP;
		else if (info->if_info[i].if_ch <= 14 && os_strcmp((char *)info->if_info[i].if_phymode, "AX") == 0)
			ctx->itf[itf_idx].media_type = IEEE802_11AX_GROUP;
		else if (info->if_info[i].if_ch > 14 && os_strcmp((char *)info->if_info[i].if_phymode, "A") == 0)
			ctx->itf[itf_idx].media_type = IEEE802_11A_5G_GROUP;
		else if (info->if_info[i].if_ch > 14 && os_strcmp((char *)info->if_info[i].if_phymode, "N") == 0)
			ctx->itf[itf_idx].media_type = IEEE802_11N_5G_GROUP;
		else if (info->if_info[i].if_ch > 14 && os_strcmp((char *)info->if_info[i].if_phymode, "AC") == 0)
			ctx->itf[itf_idx].media_type = IEEE802_11AC_5G_GROUP;
		else if (info->if_info[i].if_ch > 14 && os_strcmp((char *)info->if_info[i].if_phymode, "AX") == 0)
			ctx->itf[itf_idx].media_type = IEEE802_11AX_GROUP;
		else if (os_strcmp((char *)info->if_info[i].if_phymode, "BE") == 0)
			ctx->itf[itf_idx].media_type = IEEE802_11BE_GROUP;
		else {
			err(DEBUG_CAT_EVENT, "band_ch(%d) and phymode(%s) mismatch for %s\n",
				info->if_info[i].if_ch, info->if_info[i].if_phymode, info->if_info[i].if_name);
			return -1;
		}
		/* radio indentifer */
		ether_addr_copy(ctx->itf[itf_idx].identifier, info->if_info[i].identifier);
		/* init vs_info */
		ctx->itf[itf_idx].vs_info_length = 10;
		ctx->itf[itf_idx].vs_info = os_zalloc(ctx->itf[itf_idx].vs_info_length);
		if (!ctx->itf[itf_idx].vs_info) {
			err(DEBUG_CAT_MISC, "cannot alloc vs_info for %s\n",
				info->if_info[i].if_name);
			return -2;
		}
		ether_addr_copy(ctx->itf[itf_idx].vs_info, ctx->itf[itf_idx].mac_addr);
		if (ctx->itf[itf_idx].is_wifi_sta) {
			/* non-ap station */
			*(ctx->itf[itf_idx].vs_info + 6) = 0x40;
			os_memset(ctx->itf[itf_idx].vs_info, 0, 6);
		}

		ctx->itf_number++;
	}

	if (init_interface_socket(ctx)) {
		err(DEBUG_CAT_INIT, "init_interface_socket fail\n");
		return -2;
	}

	if (ctx->rx_from_all) {
		for (i = 0; i < ctx->itf_number; i++) {
			eloop_register_read_sock(ctx->sock_inf_recv_1905[i], cmdu_process, (void *)ctx, NULL);
			debug(DEBUG_CAT_INIT, "register cmdu_process for %s\n", ctx->itf[i].if_name);
		}
	}

	if (lldpdu_init(ctx)) {
		err(DEBUG_CAT_INIT, "lldpdu_init fail\n");
		return -2;
	}

	return 0;
}


int common_info_init(struct p1905_managerd_ctx *ctx)
{
	unsigned int i = 0;

	if (!ctx->MAP_Cer) {
		if (os_strlen((char *)ctx->al_inf)) {
			/*reset 1905almac to ap interface mac*/
			for (i = 0; i < ctx->itf_number; i++) {
				/*find al_inf , chose it's mac as al_mac*/
				if (!os_memcmp(ctx->al_inf, ctx->itf[i].if_name, IFNAMSIZ) &&
					(ctx->itf[i].is_wifi_ap
#ifdef EM_PLUS_SUPPORT
					|| ctx->itf[i].is_veth
#endif /* EM_PLUS_SUPPORT  */
					) &&
					os_memcmp(ctx->itf[i].mac_addr, ctx->br_addr, ETH_ALEN)) {
					os_memcpy(ctx->p1905_al_mac_addr, ctx->itf[i].mac_addr, ETH_ALEN);
					/*reset to 1905 config file*/
					if (write_almac_to_1905_cfg_file(ctx->map_cfg_file,
							ctx->p1905_al_mac_addr)) {
						err(DEBUG_CAT_INIT, "write almac to 1905 cfg file fail\n");
						return -1;
					}
					if (ctx->rx_from_all) {
						if (forbid_almac_and_multicast_forward(ctx) < 0) {
							err(DEBUG_CAT_INIT, "set almac and mc to forward module fail\n");
							return -1;
						}
					} else {
						if (set_opt_not_forward_dest(ctx->p1905_al_mac_addr) < 0) {
							err(DEBUG_CAT_INIT, "set almac to forward module fail\n");
							return -1;
						}
					}
					break;
				}
			}
		}
		if (i == ctx->itf_number)
			notice(DEBUG_CAT_INIT,
				"almac addr update fail; can't find local intf by al_inf(%s), use orginal almac\n",
				ctx->al_inf);
	}

	create_topology_tree(ctx);
	ctx->br_cap[0].interface_num = ctx->itf_number;
	ctx->br_cap[0].itf_mac_list= os_malloc(ETH_ALEN * ctx->br_cap[0].interface_num);
	if (!ctx->br_cap[0].itf_mac_list) {
		err(DEBUG_CAT_MISC, "alloc br_cap.itf_mac_list fail\n");
		return -1;
	}
	for(i = 0; i < ctx->br_cap[0].interface_num; i++)
		os_memcpy(ctx->br_cap[0].itf_mac_list + i * ETH_ALEN, ctx->itf[i].mac_addr, ETH_ALEN);

	for (i = 0; i < ctx->itf_number; i++) {
		os_memcpy(ctx->non_p1905_neighbor_dev[i].local_mac_addr, ctx->itf[i].mac_addr, ETH_ALEN);
	    LIST_INIT(&(ctx->non_p1905_neighbor_dev[i].non_p1905nbr_head));
		os_memcpy(ctx->p1905_neighbor_dev[i].local_mac_addr, ctx->itf[i].mac_addr, ETH_ALEN);
		LIST_INIT(&(ctx->p1905_neighbor_dev[i].p1905nbr_head));
		if (ctx->itf[i].is_wifi_ap)
			init_radio_info_by_intf(ctx, &ctx->itf[i]);
		if (ctx->itf[i].media_type <= IEEE802_3_AB_GROUP)
			ctx->itf[i].trx_config = TX_MUL | RX_MUL | TX_UNI | RX_UNI;
	}

	/*controller set the maximum BSS count in the easymesh network*/
	if (ctx->role == CONTROLLER && ctx->block_bss_info.block_bss_autoconfig) {
		if (ctx->radio_number <= 2)
			ctx->block_bss_info.max_bss_count = DUAL_BAND_MAX_BSS_NUM;
		else
			ctx->block_bss_info.max_bss_count = TRI_BAND_MAX_BSS_NUM;
	}

	return 0;
}

int delete_exist_steer_cntrl_db(struct p1905_managerd_ctx *ctx)
{
	struct control_policy_db *con_policy = NULL, *con_policy_tmp = NULL;
	struct sta_db *sta = NULL, *sta_tmp = NULL;

	if (SLIST_EMPTY(&ctx->steer_cntrl.policy_head))
		return wapp_utils_success;

    con_policy = SLIST_FIRST(&ctx->steer_cntrl.policy_head);
	while(con_policy) {
		sta = SLIST_FIRST(&con_policy->sta_head);
		while (sta) {
	        sta_tmp = SLIST_NEXT(sta, sta_entry);
	        SLIST_REMOVE(&con_policy->sta_head, sta,
	                   sta_db, sta_entry);
	        free(sta);
	        sta = sta_tmp;
		}
		con_policy_tmp = SLIST_NEXT(con_policy, policy_entry);
		SLIST_REMOVE(&ctx->steer_cntrl.policy_head, con_policy,
		            control_policy_db, policy_entry);
		free(con_policy);
		con_policy = con_policy_tmp;
		ctx->steer_cntrl.policy_cnt--;
    }
	SLIST_INIT(&ctx->steer_cntrl.policy_head);
	ctx->steer_cntrl.policy_cnt = 0;

	return wapp_utils_success;
}



int check_add_error_code_tlv(struct p1905_managerd_ctx *ctx, unsigned char *pkt,
	unsigned char max_sta_cnt, unsigned short msgtype)
{
	struct associated_clients_db *bss_db = NULL;
	struct clients_db *cli = NULL;
	struct unlink_metrics_query *unlink_query = NULL;
	struct beacon_metrics_query *bcn_query = NULL;
	struct control_policy_db *policy = NULL;
	struct sta_db *sta = NULL;
	unsigned char *pos =NULL;
	unsigned int i = 0, ack_len = 0, err_sta_cnt = 0;

	pos = pkt;
	switch (msgtype) {
	case UNASSOC_STA_LINK_METRICS_QUERY:
		unlink_query = ctx->metric_entry.unlink_query;
		if (!unlink_query) {
			err(DEBUG_CAT_MSG, "no sta in UNASSOC_STA_LINK_METRICS_QUERY msg\n");
			return -1;
		}
		for (i = 0; i < unlink_query->sta_num; i++) {
			SLIST_FOREACH(bss_db, &ctx->ap_cap_entry.assoc_clients_head, assoc_clients_entry)
			{
				SLIST_FOREACH(cli, &bss_db->clients_head, clients_entry)
				{
					if (!memcmp(cli->mac, &(unlink_query->sta_list[i * ETH_ALEN]), ETH_ALEN)) {
						/*add error code tlv logic here*/
						*pos++ = ERROR_CODE_TYPE;
						*pos++ = 0x00;
						*pos++ = 0x07;
						*pos++ = 0x01;
						os_memcpy(pos, cli->mac, ETH_ALEN);
						pos += ETH_ALEN;
						ack_len += 10;
						err_sta_cnt++;
						if (err_sta_cnt > max_sta_cnt) {
							err(DEBUG_CAT_MSG, "too many error sta; err_sta_cnt=%d; max_sta_cnt=%d\n",
								err_sta_cnt, max_sta_cnt);
							return -1;
						}
						break;
					}
				}
				if (cli)
					break;
			}
		}
	break;
	case BEACON_METRICS_QUERY:
		bcn_query = ctx->metric_entry.bcn_query;
		if (!bcn_query) {
			err(DEBUG_CAT_MSG, "no sta in BEACON_METRICS_QUERY msg\n");
			return -1;
		}
		SLIST_FOREACH(bss_db, &ctx->ap_cap_entry.assoc_clients_head, assoc_clients_entry)
		{
			SLIST_FOREACH(cli, &bss_db->clients_head, clients_entry)
			{
				if (!memcmp(cli->mac, bcn_query->sta_mac, ETH_ALEN))
					break;
			}
			if (cli)
				break;
		}
		if (!cli) {
			/*add error code tlv logic here*/
			*pos++ = ERROR_CODE_TYPE;
			*pos++ = 0x00;
			*pos++ = 0x07;
			*pos++ = 0x02;
			os_memcpy(pos, bcn_query->sta_mac, ETH_ALEN);
			pos += ETH_ALEN;
			ack_len += 10;
			err_sta_cnt++;
		}
	break;
	case CLIENT_ASSOC_CONTROL_REQUEST:
		SLIST_FOREACH(policy, &ctx->steer_cntrl.policy_head, policy_entry)
		{
			SLIST_FOREACH(sta, &policy->sta_head, sta_entry)
			{
				SLIST_FOREACH(bss_db, &ctx->ap_cap_entry.assoc_clients_head, assoc_clients_entry)
				{
					SLIST_FOREACH(cli, &bss_db->clients_head, clients_entry)
					{
						if (!memcmp(cli->mac, sta->mac, ETH_ALEN) &&
							!memcmp(bss_db->bssid, policy->bssid, ETH_ALEN) &&
							policy->assoc_control == 0x00) {
							/*add error code tlv logic here*/
							*pos++ = ERROR_CODE_TYPE;
							*pos++ = 0x00;
							*pos++ = 0x07;
							*pos++ = 0x01;
							os_memcpy(pos, cli->mac, ETH_ALEN);
							pos += ETH_ALEN;
							ack_len += 10;
							err_sta_cnt++;
							if (err_sta_cnt > max_sta_cnt) {
								err(DEBUG_CAT_MSG, "too many error sta; err_sta_cnt=%d; max_sta_cnt=%d\n",
									err_sta_cnt, max_sta_cnt);
								return -1;
							}
							break;
						}
					}
					if (cli)
						break;
				}
			}
		}
	break;
	default:
	break;
	}

	if (ack_len) {
		reset_send_tlv(ctx);
		if (fill_send_tlv(ctx, pkt, ack_len) < 0) {
			err(DEBUG_CAT_MSG, "fill_send_tlv fail for ack to mtype=%04x(%s), "
				"msgtype, get_1905_mtype_str(msgtype)\n",
				msgtype, get_1905_mtype_str(msgtype));
			return -1;
		}
	}

	return 0;
}


void set_trx_config_for_bss(struct p1905_managerd_ctx*ctx, unsigned char map_vendor_extension, unsigned char *bss_mac)
{
	unsigned int i = 0;

	for (i = 0; i < ctx->itf_number; i++) {
		if (!os_memcmp(ctx->itf[i].mac_addr, bss_mac, ETH_ALEN) &&
			ctx->itf[i].is_wifi_ap) {
			if (!(map_vendor_extension & BIT_BH_BSS))
				ctx->itf[i].trx_config = 0;
			else
				ctx->itf[i].trx_config = TX_MUL | RX_MUL | TX_UNI | RX_UNI;
			notice(DEBUG_CAT_AUTOCONF, "%s is %s bss; %s all tx rx for this interface\n",
				ctx->itf[i].if_name,
				map_vendor_extension & BIT_BH_BSS ? "bh" : "fh",
				map_vendor_extension & BIT_BH_BSS ? "enable" : "disable"
			);
			return;
		}
	}
}

/*delaying meesage handling function-init*/
int dm_init(struct p1905_managerd_ctx *ctx)
{
	dl_list_init(&ctx->dm_ctx.buf_list_head);

	return 0;
}

struct delayed_message_buf *get_dm_buf_entry(struct dl_list *list_head, IN unsigned char *almac,
	IN unsigned char event, IN char *if_name)
{
	struct delayed_message_buf *dm_buf = NULL;

	dl_list_for_each_reverse(dm_buf, list_head, struct delayed_message_buf, entry) {
		if (dm_buf->wait_for_event == event && !os_memcmp(almac, dm_buf->al_mac, ETH_ALEN) &&
			!os_memcmp(if_name, dm_buf->if_name, IFNAMSIZ))
			return dm_buf;
	}

	return NULL;
}

/*delaying meesage handling function-store*/
int store_dm_buffer(IN struct p1905_managerd_ctx *ctx, IN unsigned char *almac, IN unsigned char event,
	IN unsigned short mid, IN char *if_name)
{
#define DM_BUF_TIMEOUT 1
	struct delayed_message_buf *dm_buf = NULL;
	struct os_time now;

	if (os_strlen(if_name) >= IFNAMSIZ)
		return -1;

	dm_buf = get_dm_buf_entry(&ctx->dm_ctx.buf_list_head, almac, event, if_name);

	if (dm_buf) {
		if (dm_buf->mid == mid){
			notice(DEBUG_CAT_MSG, "do not store this dm_buffer since mid(0x%04x) is same\n",
				mid);
			return -1;
		}

		if (ctx->MAP_Cer) {
			os_get_time(&now);

			if (now.sec <= dm_buf->time.sec + DM_BUF_TIMEOUT) {
				notice(DEBUG_CAT_MSG, "do not store this dm_buffer to prevent malicious attacks mid=%d\n",
					mid);
				return -1;
			}
		}
	}

	dm_buf = (struct delayed_message_buf*)os_zalloc(sizeof(struct delayed_message_buf));
	if (!dm_buf) {
		err(DEBUG_CAT_MISC, "fail to alloc dm_buf\n");
		return -1;
	}

	os_memcpy(dm_buf->al_mac, almac, ETH_ALEN);
	dm_buf->wait_for_event = event;
	dm_buf->mid = mid;
	os_strncpy(dm_buf->if_name, if_name, os_strlen(if_name));
	os_get_time(&dm_buf->time);

	dl_list_add_tail(&ctx->dm_ctx.buf_list_head, &dm_buf->entry);

	return 0;
}

/*delaying meesage handling function-pop*/
int pop_dm_buffer(IN struct p1905_managerd_ctx *ctx, IN unsigned char event, OUT unsigned char *almac,
	OUT unsigned short *mid, OUT char *if_name)
{
	struct delayed_message_buf *dm_buf = NULL;

	dl_list_for_each(dm_buf, &ctx->dm_ctx.buf_list_head, struct delayed_message_buf, entry) {
		if (dm_buf->wait_for_event == event) {
			os_memcpy(almac, dm_buf->al_mac, ETH_ALEN);
			*mid = dm_buf->mid;
			os_strncpy(if_name, dm_buf->if_name,os_strlen(dm_buf->if_name));
			if_name[IFNAMSIZ - 1] = '\0';
			dl_list_del(&dm_buf->entry);
			os_free(dm_buf);
			return 0;
		}
	}

	return -1;
}

/*delaying meesage handling function-clear_expired*/
int clear_expired_dm_buffer(IN struct p1905_managerd_ctx *ctx)
{
#define DM_BUF_EXPIRED 10

	struct os_time now;
	struct delayed_message_buf *dm_buf = NULL, *tmp = NULL;

	os_get_time(&now);
	dl_list_for_each_safe(dm_buf, tmp, &ctx->dm_ctx.buf_list_head, struct delayed_message_buf, entry) {
		if (now.sec >= dm_buf->time.sec + DM_BUF_EXPIRED) {
			err(DEBUG_CAT_MSG, "%ds timeout; do not recv wait_for_event(%02x); del dm_buf; "
				"almac="MACSTR"; ifname=%s; mid=%d\n",
				DM_BUF_EXPIRED, dm_buf->wait_for_event,
				MAC2STR(dm_buf->al_mac), dm_buf->if_name, dm_buf->mid);
			dl_list_del(&dm_buf->entry);
			os_free(dm_buf);
		}
	}

	return 0;
}

/*delaying meesage handling function-deinit*/
int dm_deinit(struct p1905_managerd_ctx *ctx)
{
	struct delayed_message_buf *dm_buf = NULL, *tmp = NULL;

	dl_list_for_each_safe(dm_buf, tmp, &ctx->dm_ctx.buf_list_head, struct delayed_message_buf, entry) {
		dl_list_del(&dm_buf->entry);
		os_free(dm_buf);
	}

	return 0;
}

unsigned char find_band_by_opclass(char *opclass)
{
	if (!os_memcmp(opclass, "8x", 2))
		return BAND_2G_CAP;
	else if (!os_memcmp(opclass, "11x", 3))
		return BAND_5GL_CAP;
	else if (!os_memcmp(opclass, "12x", 3))
		return BAND_5GH_CAP;
	else if ((!os_memcmp(opclass, "66x", 3)) || (!os_memcmp(opclass, "13x", 3)))
		return BAND_6G_CAP;
	else
		return BAND_INVALID_CAP;
}

const char *band_2_string(unsigned char band)
{
	switch (band) {
		case BAND_INVALID_CAP:
			return "INVALID_BAND";
		case BAND_2G_CAP:
			return "24G";
		case BAND_5GL_CAP:
			return "5GL";
		case BAND_5GH_CAP:
			return "5GH";
		case BAND_5G_CAP:
			return "5G";
		case BAND_6G_CAP:
			return "6G";
		default:
			return "Unknown band";
	}
}

int clear_all_exist_radio_basic_capability(
	struct p1905_managerd_ctx *ctx)
{
	int i = 0;
	struct radio_info *r = NULL;
	struct operating_class *opc = NULL, *opc_tmp = NULL;

	for (i = 0; i < ctx->radio_number; i++) {
		r = &ctx->rinfo[i];
		dl_list_for_each_safe(opc, opc_tmp, &r->basic_cap.op_class_list, struct operating_class, entry) {
			dl_list_del(&opc->entry);
			os_free(opc);
		}
	}
	return 0;
}

void clear_ap_capability_db(struct ap_capability_db *apcap_entry)
{
	struct ap_ht_cap_db *pht_cap_db = NULL, *pht_cap_db_tmp = NULL;
	struct ap_vht_cap_db *pvht_cap_db = NULL, *pvht_cap_db_tmp = NULL;
	struct operational_bss_db *oper_bss_db = NULL, *oper_bss_db_tmp = NULL;
	struct op_bss_db *bss_db = NULL, *bss_db_tmp = NULL;
	struct associated_clients_db *assoc_client_db = NULL, *assoc_client_db_tmp = NULL;
	struct clients_db *cli_db = NULL, *cli_db_tmp = NULL;
	struct ch_prefer_db *ch_pre_db	= NULL, *ch_pre_db_tmp = NULL;
	struct prefer_info_db *pre_db = NULL, *pre_db_tmp = NULL;
	struct oper_restrict_db *restriction  = NULL, *restriction_tmp = NULL;
	struct restrict_db *resdb = NULL, *resdb_tmp = NULL;
#ifdef MAP_R6
	struct wifi7_mlo_cap_db *cap = NULL, *cap_tmp = NULL;
	struct mlo_record_db *record = NULL, *record_tmp = NULL;
#endif

	/*free ap_ht_cap_head*/
	pht_cap_db = SLIST_FIRST(&apcap_entry->ap_ht_cap_head);
	while (pht_cap_db != NULL) {
		pht_cap_db_tmp = SLIST_NEXT(pht_cap_db, ap_ht_cap_entry);
		free(pht_cap_db);
		pht_cap_db = pht_cap_db_tmp;
	}
	SLIST_INIT(&apcap_entry->ap_ht_cap_head);

	/*free ap_vht_cap_head*/
	pvht_cap_db = SLIST_FIRST(&apcap_entry->ap_vht_cap_head);
	while (pvht_cap_db != NULL) {
		pvht_cap_db_tmp = SLIST_NEXT(pvht_cap_db, ap_vht_cap_entry);
		free(pvht_cap_db);
		pvht_cap_db = pvht_cap_db_tmp;
	}
	SLIST_INIT(&apcap_entry->ap_vht_cap_head);

	/*free oper_bss_head*/
	oper_bss_db = SLIST_FIRST(&apcap_entry->oper_bss_head);
	while (oper_bss_db != NULL) {
		oper_bss_db_tmp = SLIST_NEXT(oper_bss_db, oper_bss_entry);
		/*free basic_cap_db*/
		bss_db = SLIST_FIRST(&oper_bss_db->op_bss_head);
		while (bss_db != NULL) {
			bss_db_tmp = SLIST_NEXT(bss_db, op_bss_entry);
			free(bss_db);
			bss_db = bss_db_tmp;
		}
		SLIST_INIT(&oper_bss_db->op_bss_head);
		free(oper_bss_db);
		oper_bss_db = oper_bss_db_tmp;
	}
	SLIST_INIT(&apcap_entry->oper_bss_head);

	/*free assoc_clients_head*/
	assoc_client_db = SLIST_FIRST(&apcap_entry->assoc_clients_head);
	while (assoc_client_db != NULL) {
		assoc_client_db_tmp = SLIST_NEXT(assoc_client_db, assoc_clients_entry);
		/*free basic_cap_db*/
		cli_db = SLIST_FIRST(&assoc_client_db->clients_head);
		while (cli_db != NULL) {
			cli_db_tmp = SLIST_NEXT(cli_db, clients_entry);
			free(cli_db);
			cli_db = cli_db_tmp;
		}
		SLIST_INIT(&assoc_client_db->clients_head);
		free(assoc_client_db);
		assoc_client_db = assoc_client_db_tmp;
	}
	SLIST_INIT(&apcap_entry->assoc_clients_head);

	/*free ch_prefer_head*/
	ch_pre_db = SLIST_FIRST(&apcap_entry->ch_prefer_head);
	while (ch_pre_db != NULL) {
		ch_pre_db_tmp = SLIST_NEXT(ch_pre_db, ch_prefer_entry);
		/*free pre_db*/
		pre_db = SLIST_FIRST(&ch_pre_db->prefer_info_head);
		while (pre_db != NULL) {
			pre_db_tmp = SLIST_NEXT(pre_db, prefer_info_entry);
			free(pre_db);
			pre_db = pre_db_tmp;
		}
		SLIST_INIT(&ch_pre_db->prefer_info_head);
		free(ch_pre_db);
		ch_pre_db = ch_pre_db_tmp;
	}
	SLIST_INIT(&apcap_entry->ch_prefer_head);

	/*free oper_restrict_head*/
	restriction = SLIST_FIRST(&apcap_entry->oper_restrict_head);
	while (restriction != NULL) {
		restriction_tmp = SLIST_NEXT(restriction, oper_restrict_entry);
		/*free restrict_db*/
		resdb = SLIST_FIRST(&restriction->restrict_head);
		while (resdb != NULL) {
			resdb_tmp = SLIST_NEXT(resdb, restrict_entry);
			free(resdb);
			resdb = resdb_tmp;
		}
		SLIST_INIT(&restriction->restrict_head);
		free(restriction);
		restriction = restriction_tmp;
	}
	SLIST_INIT(&apcap_entry->oper_restrict_head);

#ifdef MAP_R6
	dl_list_for_each_safe(cap, cap_tmp, &apcap_entry->wifi7_mlo_cap_list,
		struct wifi7_mlo_cap_db, list) {
		dl_list_for_each_safe(record, record_tmp, &cap->ap_str_record_list,
			struct mlo_record_db, list) {
			dl_list_del(&record->list);
			os_free(record);
		}
		cap->num_ap_str_records = 0;

		dl_list_for_each_safe(record, record_tmp, &cap->ap_nstr_record_list,
			struct mlo_record_db, list) {
			dl_list_del(&record->list);
			os_free(record);
		}
		cap->num_ap_nstr_records = 0;

		dl_list_for_each_safe(record, record_tmp, &cap->ap_emlsr_record_list,
			struct mlo_record_db, list) {
			dl_list_del(&record->list);
			os_free(record);
		}
		cap->num_ap_emlsr_records = 0;

		dl_list_for_each_safe(record, record_tmp, &cap->ap_emlmr_record_list,
			struct mlo_record_db, list) {
			dl_list_del(&record->list);
			os_free(record);
		}
		cap->num_ap_emlmr_records = 0;
		dl_list_del(&cap->list);
		os_free(cap);
	}
#endif

	apcap_entry->ap_cap.rssi_steer = 0;
	apcap_entry->ap_cap.sta_report_not_cop = 0;
	apcap_entry->ap_cap.sta_report_on_cop = 0;
}

#ifdef MAP_R2
void delete_agent_ts_cap_info(struct list_head_ts_cap_agent *ts_cap_head)
{
	struct ts_cap_db *ts_cap = NULL, *ts_cap_tmp = NULL;

	ts_cap = SLIST_FIRST(ts_cap_head);
	while (ts_cap) {
		ts_cap_tmp = SLIST_NEXT(ts_cap, ts_cap_entry);
		os_free(ts_cap);
		ts_cap = ts_cap_tmp;
	}
	SLIST_INIT(ts_cap_head);
}


struct operational_bss *get_bss_by_bssid(struct p1905_managerd_ctx *ctx,
	unsigned char *mac)
{
	struct operational_bss *bss = NULL;

	dl_list_for_each(bss, &ctx->bss_head, struct operational_bss, entry) {
		if (!os_memcmp(bss->mac, mac, ETH_ALEN))
			return bss;
	}

	return NULL;
}


struct operational_bss *create_oper_bss(struct p1905_managerd_ctx *ctx,
	unsigned char *mac, char *ssid, unsigned char ssid_len, unsigned char *almac, struct dl_list *bss_list)
{
	struct operational_bss *bss = NULL;

	bss = (struct operational_bss *)os_malloc(sizeof(struct operational_bss));

	if (bss) {
		os_memset(bss, 0, sizeof(struct operational_bss));
		os_memcpy(bss->mac, mac, ETH_ALEN);
		if (ssid_len > 32)
			ssid_len = 32;
		os_strncpy(bss->ssid, ssid, ssid_len);
		bss->ssid[ssid_len] = '\0';
		os_memcpy(bss->almac, almac, ETH_ALEN);
		bss->vid = INVALID_VLAN_ID;
		dl_list_add(bss_list, &bss->entry);
	}

	return bss;
}



struct assoc_client *get_cli_by_mac(struct dl_list *clients_table, unsigned char mac[])
{
	struct assoc_client *client = NULL;

	if (dl_list_empty(clients_table))
		return NULL;

	dl_list_for_each(client, clients_table, struct assoc_client, entry) {
		if (!os_memcmp(client->mac, mac, ETH_ALEN))
			return client;
	}
	return NULL;
}

struct assoc_client *add_new_assoc_cli(struct dl_list *clients_table, unsigned char mac[], unsigned char *al_mac)
{
	struct assoc_client *client = NULL;

	client = (struct assoc_client *)os_malloc(sizeof(struct assoc_client));
	if (client) {
		os_memset(client, 0, sizeof(struct assoc_client));
		os_memcpy(client->mac, mac, ETH_ALEN);
		os_memcpy(client->al_mac, al_mac, ETH_ALEN);
		client->vlan_id = INVALID_VLAN_ID;
		dl_list_add(clients_table, &client->entry);
#ifdef MAP_R6
		dl_list_init(&client->sta_mld.mlo_sta_list);
#endif
	}

	return client;
}

struct assoc_client *get_assoc_cli_by_mac(struct p1905_managerd_ctx *ctx, unsigned char mac[])
{
	struct assoc_client *client = NULL;

	unsigned char hash = MAC_ADDR_HASH_INDEX(mac);

	dl_list_for_each(client, &ctx->clients_table[hash], struct assoc_client, entry) {
		if (!os_memcmp(client->mac, mac, ETH_ALEN))
			return client;
	}

	return NULL;
}

struct assoc_client *create_assoc_cli(struct p1905_managerd_ctx *ctx, unsigned char mac[],
	unsigned char *al_mac)
{
	struct assoc_client *client = NULL;
	unsigned char hash = 0;

	client = (struct assoc_client*)os_malloc(sizeof(struct assoc_client));

	if (client) {
		os_memset(client, 0, sizeof(struct assoc_client));
		os_memcpy(client->mac, mac, ETH_ALEN);
		os_memcpy(client->al_mac, al_mac, ETH_ALEN);
		client->vlan_id = INVALID_VLAN_ID;

		hash = MAC_ADDR_HASH_INDEX(mac);
		dl_list_add(&ctx->clients_table[hash], &client->entry);
#ifdef MAP_R6
		dl_list_init(&client->sta_mld.mlo_sta_list);
#endif
	}

	return client;
}



/***channel scan***/
int delete_exist_channel_scan_capability(
	struct p1905_managerd_ctx *ctx, unsigned char* identifier)
{
	 struct channel_scan_cap_db *scan_cap = NULL;
	 struct scan_opcap_db *scap = NULL, *scap_tmp = NULL;

	SLIST_FOREACH(scan_cap, &(ctx->ap_cap_entry.ch_scan_cap_head), ch_scan_cap_entry)
	{
		if (!memcmp(scan_cap->identifier, identifier, ETH_ALEN)) {
			if (!SLIST_EMPTY(&(scan_cap->scan_opcap_head))) {
				scap = SLIST_FIRST(&(scan_cap->scan_opcap_head));
				while (scap) {
					scap_tmp = SLIST_NEXT(scap, scan_opcap_entry);
					SLIST_REMOVE(&scan_cap->scan_opcap_head, scap,
								scan_opcap_db, scan_opcap_entry);
					free(scap);
					scap = scap_tmp;
				}
			}
			SLIST_REMOVE(&(ctx->ap_cap_entry.ch_scan_cap_head), scan_cap,
						channel_scan_cap_db, ch_scan_cap_entry);
			free(scan_cap);
			break;
		}
	}

	return wapp_utils_success;
}

int insert_new_channel_scan_capability(
	struct p1905_managerd_ctx *ctx, struct scan_capability_lib *scap)
{
	struct channel_scan_cap_db *scap_db = NULL;
	struct scan_opcap_db *opcap_db = NULL;
	struct scan_opcap *opcap = NULL;
	int op_class_num = 0;
	int i = 0;

	scap_db = (struct channel_scan_cap_db *)malloc(sizeof(*scap_db));
	if (!scap_db) {
		err(DEBUG_CAT_MISC, "alloc struct channel_scan_cap_db fail\n");
		return wapp_utils_error;
	}
	memcpy(scap_db->identifier, scap->identifier, ETH_ALEN);
	scap_db->boot_only = scap->boot_only;
	scap_db->scan_impact = scap->scan_impact;
	scap_db->min_scan_interval = scap->min_scan_interval;
	scap_db->op_class_num = scap->op_class_num;
	SLIST_INSERT_HEAD(&(ctx->ap_cap_entry.ch_scan_cap_head), scap_db, ch_scan_cap_entry);

	SLIST_INIT(&scap_db->scan_opcap_head);
	op_class_num = scap_db->op_class_num;
	for(i = 0; i < op_class_num; i++) {
		opcap = &scap->opcap[i];
		opcap_db = (struct scan_opcap_db *)malloc(sizeof(*opcap_db));
		if (!opcap_db) {
			err(DEBUG_CAT_MISC, "alloc struct scan_opcap_db fail\n");
			return wapp_utils_error;
		}
		memcpy(opcap_db, opcap, sizeof(*opcap));
		SLIST_INSERT_HEAD(&scap_db->scan_opcap_head, opcap_db, scan_opcap_entry);
	}

	return wapp_utils_success;

}

unsigned short append_channel_scan_capability_tlv(
        unsigned char *pkt, struct list_head_ch_scan_cap *shead)
{
    unsigned short total_length = 0, tlv_len = 0;;
    unsigned char *temp_buf = NULL;
	struct channel_scan_cap_db *pdb_scan = NULL;
	struct scan_opcap_db *pdb_op = NULL;
	unsigned char rnum = 0;

    temp_buf = pkt;

    *temp_buf++ = CHANNEL_SCAN_CAPABILITY_TYPE;
	/*skip tlv length field*/
    temp_buf += 2;
	/*skip radio number field*/
	temp_buf += 1;

	SLIST_FOREACH(pdb_scan, shead, ch_scan_cap_entry)
	{
		rnum++;
		/*radio identifier*/
		memcpy(temp_buf, pdb_scan->identifier, ETH_ALEN);
		temp_buf += ETH_ALEN;
		/*boot only flag & scan impact*/
		*temp_buf++ = (pdb_scan->boot_only << 7) | (pdb_scan->scan_impact << 5);
		/*minimum scan interval*/
		*((unsigned int *)temp_buf) = host_to_be32(pdb_scan->min_scan_interval);
		temp_buf += 4;
		/*number of operating classes*/
		*temp_buf++ = pdb_scan->op_class_num;
		SLIST_FOREACH(pdb_op, &pdb_scan->scan_opcap_head, scan_opcap_entry)
		{
			/*operating class*/
			*temp_buf++ = pdb_op->op_class;
			/*number of channels*/
			*temp_buf++ = pdb_op->ch_num;
			/*channel list*/
			if (pdb_op->ch_num)
				memcpy(temp_buf, pdb_op->ch_list, pdb_op->ch_num);
			temp_buf += pdb_op->ch_num;
		}
	}

	/*number of radios*/
	*(pkt + 3) = rnum;

	total_length = (unsigned short)(temp_buf - pkt);
	tlv_len = total_length - 3;
	*((unsigned short *)(pkt + 1)) = host_to_be16(tlv_len);

    return total_length;
}


/***dfs cac***/
int delete_exist_cac_capability(struct p1905_managerd_ctx *ctx, unsigned char *identifier)
{
	struct radio_cac_capability_db *p_radio_cac_cap_db = NULL;
	struct cac_capability_db *p_cac_capab_db = NULL, *p_cac_capab_db_tmp = NULL;
	struct cac_cap_db *p_cac_cap_db = NULL, *p_cac_cap_db_tmp = NULL;
	struct cac_opcap_db *p_cac_opcab_db = NULL, *p_cac_opcab_db_tmp = NULL;

	p_radio_cac_cap_db = &ctx->ap_cap_entry.radio_cac_cap;
	p_cac_capab_db = SLIST_FIRST(&(p_radio_cac_cap_db->radio_cac_capab_head));
	while (p_cac_capab_db) {
		p_cac_capab_db_tmp = SLIST_NEXT(p_cac_capab_db, cac_capab_entry);
		if (memcmp(p_cac_capab_db->identifier, identifier, ETH_ALEN)) {
			p_cac_capab_db = p_cac_capab_db_tmp;
			continue;
		}
		p_cac_cap_db = SLIST_FIRST(&(p_cac_capab_db->cac_capab_head));
		while (p_cac_cap_db) {
			p_cac_cap_db_tmp = SLIST_NEXT(p_cac_cap_db, cac_cap_entry);
			p_cac_opcab_db = SLIST_FIRST(&(p_cac_cap_db->cac_opcap_head));
			while (p_cac_opcab_db) {
				p_cac_opcab_db_tmp = SLIST_NEXT(p_cac_opcab_db, cac_opcap_entry);
				SLIST_REMOVE(&(p_cac_cap_db->cac_opcap_head), p_cac_opcab_db,
					cac_opcap_db, cac_opcap_entry);
				free(p_cac_opcab_db);
				p_cac_opcab_db = p_cac_opcab_db_tmp;
			}
			SLIST_REMOVE(&(p_cac_capab_db->cac_capab_head), p_cac_cap_db,
				cac_cap_db, cac_cap_entry);
			free(p_cac_cap_db);
			p_cac_cap_db = p_cac_cap_db_tmp;
		}
		SLIST_REMOVE(&(p_radio_cac_cap_db->radio_cac_capab_head), p_cac_capab_db,
			cac_capability_db, cac_capab_entry);
		free(p_cac_capab_db);
		break;
	}

	return wapp_utils_success;
}

int insert_new_cac_capability(
	struct p1905_managerd_ctx *ctx, struct cac_capability_lib *cac_capab_in)
{
	struct radio_cac_capability_db *p_radio_cac_cap_db = &ctx->ap_cap_entry.radio_cac_cap;
	struct cac_capability_db *p_cac_capab_db = NULL;
	struct cac_cap_db *p_cac_cap_db = NULL;
	struct cac_opcap_db *p_cac_opcap_db = NULL;
	struct cac_cap *p_cac_cap_in = NULL;
	struct cac_type *p_cac_type_in = NULL;
	struct cac_opcap *p_cac_opcap_in = NULL;
	int i = 0, j=0, k = 0, n = 0;
	int offset_type = 0, offset_opcap = 0;
	char ch_str[64] = {0}, offset_str = 0;
	int temp_len = 0;

	memcpy(p_radio_cac_cap_db->country_code, cac_capab_in->country_code, 2);
	p_radio_cac_cap_db->radio_num = cac_capab_in->radio_num;
	p_cac_cap_in = cac_capab_in->cap;
	for (i = 0; i < p_radio_cac_cap_db->radio_num; i ++) {
		delete_exist_cac_capability(ctx, p_cac_cap_in->identifier);
		p_cac_capab_db = (struct cac_capability_db *)malloc(sizeof(struct cac_capability_db));
		if (!p_cac_capab_db) {
			err(DEBUG_CAT_MISC, "alloc struct cac_capability_db fail\n");
			goto error;
		}
		memcpy(p_cac_capab_db->identifier, p_cac_cap_in->identifier, ETH_ALEN);
		p_cac_capab_db->cac_type_num = p_cac_cap_in->cac_type_num;
		SLIST_INIT(&p_cac_capab_db->cac_capab_head);
		SLIST_INSERT_HEAD(&(p_radio_cac_cap_db->radio_cac_capab_head), p_cac_capab_db, cac_capab_entry);
		p_cac_type_in = p_cac_cap_in->type;
		offset_type = 0;
		for (j = 0; j < p_cac_capab_db->cac_type_num; j ++) {
			p_cac_cap_db = (struct cac_cap_db *)malloc(sizeof(struct cac_cap_db));
			if (!p_cac_cap_db) {
				err(DEBUG_CAT_MISC, "alloc struct cac_cap_db fail\n");
				goto error;
			}
			p_cac_cap_db->cac_mode = p_cac_type_in->cac_mode;
			memcpy(p_cac_cap_db->cac_interval, p_cac_type_in->cac_interval, sizeof(p_cac_cap_db->cac_interval));
			p_cac_cap_db->op_class_num = p_cac_type_in->op_class_num;
			SLIST_INIT(&p_cac_cap_db->cac_opcap_head);
			SLIST_INSERT_HEAD(&p_cac_capab_db->cac_capab_head, p_cac_cap_db, cac_cap_entry);
			p_cac_opcap_in = p_cac_type_in->opcap;
			offset_opcap = 0;
			for (k = 0; k < p_cac_cap_db->op_class_num; k ++) {
				p_cac_opcap_db = (struct cac_opcap_db *)malloc(sizeof(struct cac_opcap_db));
				if (!p_cac_opcap_db) {
					err(DEBUG_CAT_MISC, "alloc struct cac_opcap_db fail\n");
					goto error;
				}
				p_cac_opcap_db->op_class = p_cac_opcap_in->op_class;
				p_cac_opcap_db->ch_num = p_cac_opcap_in->ch_num;
				memcpy(p_cac_opcap_db->ch_list, p_cac_opcap_in->ch_list, p_cac_opcap_db->ch_num);
				offset_str = 0;
				memset(ch_str, 0, sizeof(ch_str));
				for (n = 0; n < p_cac_opcap_db->ch_num; n++) {
					temp_len = os_snprintf(ch_str + offset_str, sizeof(ch_str) - offset_str, "%02x,",
							p_cac_opcap_db->ch_list[n]);
					if (os_snprintf_error(sizeof(ch_str) - offset_str, temp_len)) {
						err(DEBUG_CAT_MISC, "snprintf fail\n");
						free(p_cac_opcap_db);
						goto error;
					}
					offset_str += temp_len;
				}
				SLIST_INSERT_HEAD(&p_cac_cap_db->cac_opcap_head, p_cac_opcap_db, cac_opcap_entry);
				p_cac_opcap_in = (struct cac_opcap *)((char *)p_cac_opcap_in + sizeof(struct cac_opcap) + p_cac_opcap_db->ch_num);
				offset_opcap += sizeof(struct cac_opcap) + p_cac_opcap_db->ch_num;
			}
			p_cac_type_in = (struct cac_type *)((char *)p_cac_type_in + sizeof(struct cac_type) + offset_opcap);
			offset_type += sizeof(struct cac_type) + offset_opcap;
		}
		p_cac_cap_in = (struct cac_cap *)((char *)p_cac_cap_in + sizeof(struct cac_cap) + offset_type);
	}

	return wapp_utils_success;
error:
	return wapp_utils_error;

}

unsigned short append_cac_capability_tlv(
        unsigned char *pkt, struct radio_cac_capability_db *cachead)
{
	unsigned short total_length = 0, tlv_len = 0;;
	unsigned char *temp_buf = NULL;
	struct cac_capability_db *p_cac_capab = NULL;
	struct cac_cap_db *p_cac_cab = NULL;
	struct cac_opcap_db *p_cac_cab_opcap = NULL;

	temp_buf = pkt;

	*temp_buf++ = CAC_CAPABILITIES_TYPE;
	/*skip tlv length field*/
	temp_buf += 2;

	/* country code, 2 octets */
	memcpy(temp_buf, cachead->country_code, sizeof(cachead->country_code));
	temp_buf += 2;

	/* Number of radios, 1 octet */
	*temp_buf++ = cachead->radio_num;


	SLIST_FOREACH(p_cac_capab, &cachead->radio_cac_capab_head, cac_capab_entry)
	{
		/*radio identifier, 6 octets*/
		memcpy(temp_buf, p_cac_capab->identifier, ETH_ALEN);
		temp_buf += ETH_ALEN;

		/*Number of types of CAC, 1 octet*/
		*temp_buf++ = p_cac_capab->cac_type_num;

		SLIST_FOREACH(p_cac_cab, &p_cac_capab->cac_capab_head, cac_cap_entry)
		{
			/* CAC mode supported, 1 octet */
			*temp_buf++ = p_cac_cab->cac_mode;

			/* Number of seconds required to complete CAC, 3 octets */
			memcpy(temp_buf, p_cac_cab->cac_interval, 3);
			temp_buf += 3;

			/* Number of classes supported, 1 octet */
			*temp_buf++ = p_cac_cab->op_class_num;
			SLIST_FOREACH(p_cac_cab_opcap, &p_cac_cab->cac_opcap_head, cac_opcap_entry)
			{
				/* perating class, 1 octet */
				*temp_buf++ = p_cac_cab_opcap->op_class;

				/* perating class, 1 octet */
				*temp_buf++ = p_cac_cab_opcap->ch_num;

				/*channel number, */
				memcpy(temp_buf, p_cac_cab_opcap->ch_list, p_cac_cab_opcap->ch_num);
				temp_buf += p_cac_cab_opcap->ch_num;
			}

		}

	}

	total_length = (unsigned short)(temp_buf - pkt);
	tlv_len = total_length - 3;
	*((unsigned short *)(pkt + 1)) = host_to_be16(tlv_len);

    return total_length;
}


int update_r2_ap_capability(
	struct p1905_managerd_ctx *ctx, struct ap_r2_capability *ap_r2_cap)
{
	memcpy(&ctx->ap_cap_entry.ap_r2_cap, ap_r2_cap, sizeof(struct ap_r2_capability));

	return wapp_utils_success;
}



int insert_new_ap_extended_capability(
	struct p1905_managerd_ctx *ctx, struct ap_extended_metrics_lib *metric)
{
	struct ap_ext_cap_db *p_new_db = NULL;

	p_new_db = (struct ap_ext_cap_db *)malloc(sizeof(struct ap_ext_cap_db));
	if (p_new_db == NULL) {
		err(DEBUG_CAT_MISC, "alloc struct ap_ext_cap_db fail\n");
		return wapp_utils_error;
	}
	memcpy(p_new_db->bssid, metric->bssid, ETH_ALEN);
	p_new_db->uc_tx = metric->uc_tx;
	p_new_db->uc_rx = metric->uc_rx;
	p_new_db->mc_tx = metric->mc_tx;
	p_new_db->mc_rx = metric->mc_rx;
	p_new_db->bc_tx = metric->bc_tx;
	p_new_db->bc_rx = metric->bc_rx;
	SLIST_INSERT_HEAD(&(ctx->ap_cap_entry.ap_ext_cap_head), p_new_db, ap_ext_cap_entry);

	return wapp_utils_success;
}

int insert_new_radio_metric(
	struct p1905_managerd_ctx *ctx, struct radio_metrics_lib *metric)
{
	struct radio_metrics_db *p_new_db = NULL;

	p_new_db = (struct radio_metrics_db *)malloc(sizeof(struct radio_metrics_db));
	if (p_new_db == NULL) {
		err(DEBUG_CAT_MISC, "alloc struct radio_metrics_db fail\n");
		return wapp_utils_error;
	}
	memcpy(p_new_db->identifier, metric->identifier, ETH_ALEN);
	p_new_db->noise= metric->noise;
	p_new_db->transmit= metric->transmit;
	p_new_db->receive_self= metric->receive_self;
	p_new_db->receive_other= metric->receive_other;
	SLIST_INSERT_HEAD(&(ctx->metric_entry.radio_metrics_head), p_new_db, radio_metrics_entry);

	return wapp_utils_success;
}


int delete_assoc_sta_extended_link_metric(
	struct p1905_managerd_ctx *ctx, struct sta_extended_metrics_lib *metric)
{
	struct sta_extended_metrics_db *p_tmp = NULL, *p_next = NULL;
	struct extended_metrics_db *p_tmp_metric = NULL, * p_next_metric = NULL;

	/* rm exsited extended_metrics_db for the sta */
	if (!SLIST_EMPTY(&ctx->metric_entry.assoc_sta_extended_link_metrics_head)) {
		p_tmp = SLIST_FIRST(&ctx->metric_entry.assoc_sta_extended_link_metrics_head);
		while (p_tmp) {
			p_next = SLIST_NEXT(p_tmp, sta_extended_metrics_entry);
			if (!memcmp(p_tmp->sta_mac, metric->sta_mac, ETH_ALEN)) {
				p_tmp_metric = SLIST_FIRST(&(p_tmp->extended_metrics_head));
				while (p_tmp_metric) {
					p_next_metric = SLIST_NEXT(p_tmp_metric, metrics_entry);
					SLIST_REMOVE(&(p_tmp->extended_metrics_head), p_tmp_metric,
						extended_metrics_db, metrics_entry);
					free(p_tmp_metric);
					p_tmp_metric = p_next_metric;
				}
			}
			SLIST_REMOVE(&ctx->metric_entry.assoc_sta_extended_link_metrics_head, p_tmp,
				sta_extended_metrics_db, sta_extended_metrics_entry);
			free(p_tmp);
			p_tmp = p_next;
		}

	}

	return wapp_utils_success;
}

int insert_assoc_sta_extended_link_metric(
	struct p1905_managerd_ctx *ctx, struct sta_extended_metrics_lib *metric)
{
	struct sta_extended_metrics_db *p_new_db = NULL;
	struct extended_metrics_db *p_new_metric_db = NULL;
	struct extended_metrics_info *p_metric_in = NULL;
	int i = 0;

	delete_assoc_sta_extended_link_metric(ctx, metric);

	/* insert  */
	p_new_db = (struct sta_extended_metrics_db *)malloc(sizeof(struct sta_extended_metrics_db));
	if (p_new_db == NULL) {
		err(DEBUG_CAT_MISC, "alloc struct sta_extended_metrics_db fail\n");
		return wapp_utils_error;
	}
	memset(p_new_db, 0, sizeof(struct sta_extended_metrics_db));
	memcpy(p_new_db->sta_mac, metric->sta_mac, ETH_ALEN);
	p_new_db->extended_metric_cnt = metric->extended_metric_cnt;
	SLIST_INSERT_HEAD(&(ctx->metric_entry.assoc_sta_extended_link_metrics_head),
		p_new_db, sta_extended_metrics_entry);

	p_metric_in = metric->metric_info;
	while (i < metric->extended_metric_cnt) {
		p_new_metric_db = (struct extended_metrics_db *)malloc(sizeof(struct extended_metrics_db));
		if (p_new_metric_db == NULL) {
			err(DEBUG_CAT_MISC, "alloc struct extended_metrics_db fail\n");
			return wapp_utils_error;
		}

		memcpy(p_new_metric_db->bssid, p_metric_in->bssid, ETH_ALEN);
		p_new_metric_db->last_data_ul_rate = p_metric_in->last_data_ul_rate;
		p_new_metric_db->last_data_dl_rate = p_metric_in->last_data_dl_rate;
		p_new_metric_db->utilization_rx = p_metric_in->utilization_rx;
		p_new_metric_db->utilization_tx= p_metric_in->utilization_tx;
		SLIST_INSERT_HEAD(&(p_new_db->extended_metrics_head),
			p_new_metric_db, metrics_entry);

		p_metric_in += 1;
		i ++;
	}

	return wapp_utils_success;
}

int delete_exist_traffic_policy(struct p1905_managerd_ctx *ctx, struct traffics_policy *tpolicy)
{
	struct traffic_separation_db *policy = NULL, *policy_tmp = NULL;

	policy = SLIST_FIRST(&tpolicy->policy_head);
	while(policy != NULL) {
		free(policy->SSID);
		policy_tmp = SLIST_NEXT(policy, policy_entry);
		free(policy);
		policy = policy_tmp;
	}
	SLIST_INIT(&tpolicy->policy_head);
	tpolicy->SSID_num = 0;

	return wapp_utils_success;
}

unsigned char check_traffic_policy_config_valid(struct p1905_managerd_ctx *ctx, struct traffics_policy *tpolicy)
{
	struct traffic_separation_db *policy = NULL, *policy_tmp = NULL;
	unsigned char is_valid = 0;

	if (!tpolicy) {
		warn(DEBUG_CAT_TS, "input tpolicy is null\n");
		return is_valid;
	}

	policy = SLIST_FIRST(&tpolicy->policy_head);
	while (policy != NULL) {
		if (policy->vid >= 1 && policy->vid < INVALID_VLAN_ID) {
			info(DEBUG_CAT_TS, "SSID=%s, valid vlan_id=%d\n", policy->SSID, policy->vid);
			is_valid = 1;
			break;
		}
		policy_tmp = SLIST_NEXT(policy, policy_entry);
		policy = policy_tmp;
	}

	return is_valid;
}

unsigned char check_traffic_policy_config_updated(struct p1905_managerd_ctx *ctx, struct traffics_policy *old_tpolicy,
		struct traffics_policy *new_tpolicy)
{
	unsigned char is_updated = 0, old_ts_config = 0, new_ts_config = 0;

	old_ts_config = check_traffic_policy_config_valid(ctx, old_tpolicy);
	new_ts_config = check_traffic_policy_config_valid(ctx, new_tpolicy);

	info(DEBUG_CAT_TS, "ts config valid old=%d, new=%d\n", old_ts_config, new_ts_config);

	if (old_ts_config || new_ts_config)
		is_updated = 1;

	return is_updated;
}

int delete_exist_pfilter_policy(struct p1905_managerd_ctx *ctx, struct pfiltering_policy *fpolicy)
{
	struct pf_bssid_list *bssid = NULL, *bssid_tmp = NULL;
	struct dest_mac_list *dmac = NULL, *dmac_tmp = NULL;

	bssid = SLIST_FIRST(&fpolicy->bssid_head);
	while (bssid != NULL) {
		dmac = SLIST_FIRST(&bssid->dmac_head);
		while (dmac != NULL) {
			dmac_tmp = SLIST_NEXT(dmac, dmac_entry);
			free(dmac);
			dmac = dmac_tmp;
		}
		SLIST_INIT(&bssid->dmac_head);
		bssid->n = 0;

		bssid_tmp = SLIST_NEXT(bssid, bssid_entry);
		free(bssid);
		bssid = bssid_tmp;
	}
	SLIST_INIT(&fpolicy->bssid_head);
	fpolicy->k= 0;

	return wapp_utils_success;
}

void map_r2_notify_ts_config(void *eloop_ctx, void *timeout_ctx)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx*)eloop_ctx;
	struct ssid_2_vid_mapping *mapping = NULL, *mapping_org = NULL;
	struct traffics_policy *pts_policy = &ctx->map_policy.tpolicy;
	struct traffic_separation_db *policy_db = NULL;
	unsigned short vids[256] = {0};
	unsigned char vid_num = 0;
#ifdef EM_PLUS_SUPPORT
	int status, i, ret, if_num;
	unsigned char ifname[IFNAMSIZ] = {0};
#endif

	/*ts policy does not update, do not notify it*/
	if (!ctx->map_policy.setting.updated && !pts_policy->updated)
		return;

	mapfilter_set_ts_default_8021q(ctx->map_policy.setting.primary_vid, ctx->map_policy.setting.dft.PCP);
	mapping = os_zalloc(pts_policy->SSID_num * sizeof(struct ssid_2_vid_mapping));
	if (!mapping)
		return;
	mapping_org = mapping;

	SLIST_FOREACH(policy_db, &(pts_policy->policy_head), policy_entry)
	{
		mapping->vlan_id = policy_db->vid;
		os_memcpy(mapping->ssid, policy_db->SSID, policy_db->SSID_len);
		mapping->ssid[sizeof(mapping->ssid) - 1] = '\0';
		notice(DEBUG_CAT_TS, "apply traffic policy:%s --> %d\n", mapping->ssid, mapping->vlan_id);
		vids[vid_num++] = policy_db->vid;
		mapping++;
	}

#ifdef EM_PLUS_SUPPORT
	for (if_num = 0; if_num < ctx->itf_number; if_num++) {
		if (ctx->itf[if_num].update_vlan_tag == 1) {
			update_vlan_tag_inf(ctx, ctx->itf[if_num].if_name, 0);
			notice(DEBUG_CAT_EMPLUS, "[VLAN] removing vlan tags!!");
			ctx->itf[if_num].update_vlan_tag = 0;
		}
	}
#endif

	mapfilter_set_ts_policy(pts_policy->SSID_num, mapping_org);

	/*notify the WiFi driver*/
	_1905_notify_ts_setting(ctx, pts_policy->SSID_num, (void *)mapping_org);

#ifdef EM_PLUS_SUPPORT
	for (i = 0; i < MAX_LAN_PORT_NUM; i++) {
		status = eth_layer_update_eth_port_status(i);
		if (status < 0) {
			notice(DEBUG_CAT_EMPLUS, "[VLAN] get eth status fail on port(%d) status(%d)\n", i, status);
			continue;
		}

		ret = snprintf((char *)ifname, sizeof(ifname), "%s.%d", "eth0",
				i+1);
		if (os_snprintf_error(sizeof(ifname), ret)) {
			notice(DEBUG_CAT_EMPLUS, "[VLAN] eth ifname snprintf fail!\n");
			os_free(mapping_org);
			return;
		}
		if (status == 0)
			update_vlan_tag_inf(ctx, ifname, 0);
		else if (status == 1)
			update_vlan_tag_inf(ctx, ifname, 2);
	}
#endif

	os_free(mapping_org);

	/*fisrtly clear all vlan id and then re-set all vids included in traffic separation policy to switch*/
	eth_layer_set_traffic_separation_vlan(vids, 0);

	if (vid_num)
		eth_layer_set_traffic_separation_vlan(vids, vid_num);

	/* need rm hnat sessions after resetting the ts vlan */
	map_rm_hnat_session();

	/*reset policy*/
	ctx->map_policy.setting.updated = 0;
	pts_policy->updated = 0;

	update_operation_bss_vlan(ctx, &ctx->bss_head, pts_policy, NULL);
	maintain_all_assoc_clients(ctx);

}

void cmd_set_ts_pvlan(struct p1905_managerd_ctx *ctx, char* buf)
{
	struct def_8021q_setting *def_setting = &ctx->map_policy.setting;
	long pvid = 0;
	char *endptr;

	pvid = strtol(buf, &endptr, 10);

	if (pvid >= INVALID_VLAN_ID || pvid < 1) {
		warn(DEBUG_CAT_TS, "invalid pvid=%ld!\n", pvid);
		return;
	}
	if (buf == endptr || *endptr == '\0') {
		warn(DEBUG_CAT_TS, "invalid buf!\n");
		return;
	}

	def_setting->primary_vid = (unsigned short)pvid;
	notice(DEBUG_CAT_TS, "cmd to update primary_vid(%d)\n", def_setting->primary_vid);
//	mapfilter_set_ts_default_8021q(ctx->map_policy.setting.primary_vid, ctx->map_policy.setting.dft.PCP);
}

void cmd_set_ts_policy(struct p1905_managerd_ctx *ctx, char* buf)
{
	long vid = 0;
	char ssid[64];
	struct traffic_separation_db *trffic_policy = NULL;
	struct traffics_policy *policy = &ctx->map_policy.tpolicy;
	char *token;
	char *endptr;

	memset(ssid, 0, sizeof(ssid));

	token = strtok(buf, " ");
	if (token == NULL) {
		err(DEBUG_CAT_TS, "Failed to parse SSID\n");
		return;
	}
	if (strlen(token) >= sizeof(ssid)) {
		err(DEBUG_CAT_TS, "invalid ssid length\n");
		return;
	}
	memcpy(ssid, token, strlen(token));

	token = strtok(NULL, " ");
	if (token == NULL) {
		err(DEBUG_CAT_TS, "Failed to parse VID\n");
		return;
	}

	vid = strtol(token, &endptr, 10);
	if (vid >= INVALID_VLAN_ID || vid < 1) {
		err(DEBUG_CAT_TS, "invalid vidd=%ld!\n", vid);
		return;
	}
	if (token == endptr || *endptr != '\0') {
		err(DEBUG_CAT_TS, "Failed to parse VID\n");
		return;
	}

	trffic_policy = (struct traffic_separation_db *)os_malloc(sizeof(struct traffic_separation_db));
	if (!trffic_policy) {
		err(DEBUG_CAT_MISC, "alloc struct traffic_separation_db fail\n");
		return;
	}
	trffic_policy->SSID_len = os_strlen(ssid);
	info(DEBUG_CAT_TS, "cmd to update SSID_len(%d)\n", trffic_policy->SSID_len);

	trffic_policy->SSID = os_malloc(trffic_policy->SSID_len + 1);
	if (!trffic_policy->SSID) {
		err(DEBUG_CAT_MISC, "kmalloc for trffic_policy->SSID fail\n");
		free(trffic_policy);
		return;
	}

	os_memset(trffic_policy->SSID, 0, trffic_policy->SSID_len + 1);
	os_memcpy(trffic_policy->SSID, ssid, trffic_policy->SSID_len);
	trffic_policy->vid = (unsigned short)vid;
	notice(DEBUG_CAT_TS, "cmd to update SSID(%s) VID(%d)\n", trffic_policy->SSID, trffic_policy->vid);

	policy->SSID_num ++;
	info(DEBUG_CAT_TS, "cmd to update current SSID_num(%d)\n", policy->SSID_num);

	SLIST_INSERT_HEAD(&policy->policy_head, trffic_policy, policy_entry);
}

void cmd_set_ts_policy_done(struct p1905_managerd_ctx *ctx)
{
	ctx->map_policy.setting.updated = 1;
	ctx->map_policy.tpolicy.updated = 1;
	map_r2_notify_ts_config((void*)ctx, NULL);
}

void cmd_set_ts_policy_clear(struct p1905_managerd_ctx *ctx)
{
	ctx->map_policy.setting.primary_vid = VLAN_N_VID;
	ctx->map_policy.setting.dft.PCP = 0;
	delete_exist_traffic_policy(ctx, &ctx->map_policy.tpolicy);
	ctx->map_policy.setting.updated = 1;
	ctx->map_policy.tpolicy.updated = 1;
	map_r2_notify_ts_config((void*)ctx, NULL);
}


void assoc_client_table_init(struct p1905_managerd_ctx *ctx)
{
	int i = 0;

	for (i = 0; i < HASH_TABLE_SIZE; i++)
		dl_list_init(&ctx->clients_table[i]);
}

void traffic_separation_init(struct p1905_managerd_ctx *ctx)
{
	ctx->map_policy.setting.primary_vid = INVALID_VLAN_ID;
	ctx->map_policy.setting.dft.PCP = 0;
	SLIST_INIT(&ctx->map_policy.tpolicy.policy_head);
	ctx->map_policy.setting.updated = 1;
	ctx->map_policy.tpolicy.updated = 1;

	/*this field has been assigned while reading 1905d_cfg*/
	/*ctx->map_policy.trans_vlan.num = 0;

	for (i = 0; i < MAX_NUM_TRANSPARENT_VID; i++) {
		ctx->map_policy.trans_vlan.transparent_vids[i] = INVALID_VLAN_ID;
	}
	*/

	eloop_register_timeout(0, 0, map_r2_notify_ts_config, (void *)ctx, NULL);
	eloop_register_timeout(25, 0, map_notify_transparent_vlan_setting, (void *)ctx, NULL);

	dl_list_init(&ctx->bss_head);
	if (ctx->map_version >= DEV_TYPE_R2) {
		/*enable TS in mapfilter*/
		mapfilter_ts_onoff(1);
	}

}

void ts_traffic_separation_deinit(struct p1905_managerd_ctx *ctx)
{
	struct assoc_client *client = NULL, *client_tmp = NULL;
	struct operational_bss *bss = NULL, *bss_tmp = NULL;
	int i = 0;

	delete_exist_traffic_policy(ctx, &ctx->map_policy.tpolicy);
	ctx->map_policy.setting.primary_vid = INVALID_VLAN_ID;
	ctx->map_policy.setting.dft.PCP = 0;

	ctx->map_policy.setting.updated = 1;
	ctx->map_policy.tpolicy.updated = 1;

	map_r2_notify_ts_config((void*)ctx, NULL);

	for (i = 0; i < HASH_TABLE_SIZE; i++) {
		dl_list_for_each_safe(client, client_tmp, &ctx->clients_table[i],
			struct assoc_client, entry) {
			mapfilter_update_client_vid(client->mac, client->vlan_id, STATION_LEAVE,
				client->ssid_len, client->ssid, client->al_mac);
		}
	}

	dl_list_for_each_safe(bss, bss_tmp, &ctx->bss_head, struct operational_bss, entry) {
		dl_list_del(&bss->entry);
		os_free(bss);
	}

	/*disable TS in mapfilter*/
	mapfilter_ts_onoff(0);
}

int update_traffic_separation_policy(struct p1905_managerd_ctx *ctx,
	struct set_config_bss_info bss_info[], unsigned char bss_num)
{
	unsigned char i = 0;
	struct traffic_separation_db *traffic_policy = NULL;
	struct traffics_policy *policy = &ctx->map_policy.tpolicy;

	for (i = 0; i < bss_num; i++) {
		if (bss_info[i].vid == VLAN_N_VID)
			continue;
		traffic_policy = (struct traffic_separation_db*)os_malloc(sizeof(struct traffic_separation_db));
		if (!traffic_policy) {
			err(DEBUG_CAT_MISC, "fail to allocate memory\n");
			continue;
		}

		traffic_policy->vid = bss_info[i].vid;
		traffic_policy->SSID_len = bss_info[i].ssid_len;
		traffic_policy->SSID = os_malloc(bss_info[i].ssid_len + 1);
		if (!traffic_policy->SSID) {
			os_free(traffic_policy);
			err(DEBUG_CAT_MISC, "fail to allocate SSID\n");
			continue;
		}
		os_memset(traffic_policy->SSID, 0, bss_info[i].ssid_len + 1);
		os_memcpy(traffic_policy->SSID, bss_info[i].ssid, bss_info[i].ssid_len);
		SLIST_INSERT_HEAD(&policy->policy_head, traffic_policy, policy_entry);
		policy->SSID_num++;

		policy->updated = 1;
	}

	return 0;
}

int update_traffic_separation_policy_ex(struct p1905_managerd_ctx *ctx, struct traffics_policy *policy,
	struct set_config_bss_info bss_info[], unsigned char bss_num)
{
	unsigned char i = 0;
	struct traffic_separation_db *traffic_policy = NULL;

	if (!policy || !bss_num) {
		warn(DEBUG_CAT_TS, "invalid input policy or bss_num(%d)\n", bss_num);
		return -1;
	}

	for (i = 0; i < bss_num; i++) {
		if (bss_info[i].vid == VLAN_N_VID)
			continue;
		traffic_policy = (struct traffic_separation_db *)os_malloc(sizeof(struct traffic_separation_db));
		if (!traffic_policy) {
			err(DEBUG_CAT_TS, "fail to allocate memory for traffic_separation_db\n");
			continue;
		}

		traffic_policy->vid = bss_info[i].vid;
		traffic_policy->SSID_len = bss_info[i].ssid_len;
		traffic_policy->SSID = os_malloc(bss_info[i].ssid_len + 1);
		if (!traffic_policy->SSID) {
			os_free(traffic_policy);
			err(DEBUG_CAT_TS, "fail to allocate memory for SSID\n");
			continue;
		}
		os_memset(traffic_policy->SSID, 0, bss_info[i].ssid_len + 1);
		os_memcpy(traffic_policy->SSID, bss_info[i].ssid, bss_info[i].ssid_len);
		SLIST_INSERT_HEAD(&policy->policy_head, traffic_policy, policy_entry);
		policy->SSID_num++;

		policy->updated = 1;
	}
	return 0;
}

void map_notify_transparent_vlan_setting(void *eloop_ctx, void *timeout_ctx)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx*)eloop_ctx;

	if (!ctx->map_policy.trans_vlan.updated)
		return;

	mapfilter_set_transparent_vid(ctx->map_policy.trans_vlan.transparent_vids,
		ctx->map_policy.trans_vlan.num);
	_1905_notify_transparent_vlan_setting(ctx);

	/*firstly cleart the original transparent vlan ids, and the re-set new ones to switch*/
	eth_layer_set_switch_trasnparent_vlan(ctx->map_policy.trans_vlan.transparent_vids,
		0);

	if (ctx->map_policy.trans_vlan.num)
		eth_layer_set_switch_trasnparent_vlan(ctx->map_policy.trans_vlan.transparent_vids,
			ctx->map_policy.trans_vlan.num);

	ctx->map_policy.trans_vlan.updated = 0;
}

struct operational_bss *get_operational_bss_by_bssid(struct dl_list *bss_head,
	unsigned char bssid[])
{
	struct operational_bss *bss = NULL;

	dl_list_for_each(bss, bss_head, struct operational_bss, entry) {
		if (!os_memcmp(bss->mac, bssid, ETH_ALEN))
			return bss;
	}

	return NULL;
}

unsigned short get_vlan_by_ssid_from_ts_policy(char *ssid, unsigned char ssid_len,
	struct traffics_policy *policy)
{
	unsigned short vlan = INVALID_VLAN_ID;
	struct traffic_separation_db *policy_db = NULL;

	SLIST_FOREACH(policy_db, &(policy->policy_head), policy_entry)
	{
		if (ssid_len == policy_db->SSID_len && !os_memcmp(policy_db->SSID, ssid, ssid_len)) {
			vlan = policy_db->vid;
			break;
		}
	}

	return vlan;
}

void update_operation_bss_vlan(struct p1905_managerd_ctx *ctx,struct dl_list *bss_head,
	struct traffics_policy *policy, unsigned char *al_mac)
{
	struct operational_bss *bss = NULL;
	unsigned short vid = INVALID_VLAN_ID;
	struct topology_response_db *tpgr_db = NULL;
	enum MAP_PROFILE profile = MAP_PROFILE_REVD;

	dl_list_for_each(bss, bss_head, struct operational_bss, entry) {

		/*if only update bss for a specific almac*/
		if (al_mac && os_memcmp(al_mac, bss->almac, ETH_ALEN))
			continue;

		profile = MAP_PROFILE_REVD;
		tpgr_db = find_topology_rsp_by_almac(ctx, bss->almac);
		if (tpgr_db) {
			profile = tpgr_db->profile;
		} else {
			if (!os_memcmp(bss->almac, ctx->p1905_al_mac_addr, ETH_ALEN))
				profile = ctx->map_version;
		}
		if (profile == MAP_PROFILE_REVD || profile == MAP_PROFILE_R1)
			continue;

		vid = get_vlan_by_ssid_from_ts_policy(bss->ssid, os_strlen(bss->ssid), policy);

		if (bss->vid != vid) {
			notice(DEBUG_CAT_TS, "update bss("MACSTR") %s vlan from %d to %d",
				PRINT_MAC(bss->mac), bss->ssid, bss->vid, vid);
			bss->vid = vid;
		}

	}
}

void maintain_all_assoc_clients(struct p1905_managerd_ctx *ctx)
{
	struct dl_list *clients = NULL;
	struct assoc_client *client = NULL, *client_temp = NULL;
	struct operational_bss *bss = NULL;
	int i = 0;

	for (i = 0; i < HASH_TABLE_SIZE; i++) {
		clients = &ctx->clients_table[i];
		dl_list_for_each_safe (client, client_temp, clients, struct assoc_client, entry) {
			if (client->disassoc) {
#ifdef MAP_R6
				delete_sta_mld_cfg_rpt(&client->sta_mld, client->mac);
#endif
				dl_list_del(&client->entry);
				mapfilter_update_client_vid(client->mac, client->vlan_id, STATION_LEAVE,
					client->ssid_len, client->ssid, client->al_mac);
				os_free(client);
				continue;
			}
			bss = get_operational_bss_by_bssid(&ctx->bss_head, client->bssid);
			if (!bss)
				continue;
			/*if vid/ssid of bss has been changed, should reconfig client and set to mapfilter*/
			if (client->vlan_id != bss->vid || client->ssid_len != os_strlen(bss->ssid) ||
				os_strncmp(client->ssid, bss->ssid, client->ssid_len)) {
				client->vlan_id = bss->vid;
				if (os_strlen(bss->ssid) >= MAX_SSID_LEN)
					continue;
				client->ssid_len = os_strlen(bss->ssid);
				os_memset(client->ssid, 0, sizeof(client->ssid));
				os_strncpy(client->ssid, bss->ssid, client->ssid_len);
				client->apply_2_mapfilter = 0;
			}

			/*if (client->vlan_id != bss->vid) {*/
			if (!client->apply_2_mapfilter) {
				client->apply_2_mapfilter = 1;
				mapfilter_update_client_vid(client->mac, client->vlan_id, STATION_JOIN,
					client->ssid_len, client->ssid, client->al_mac);
			}
		}
	}
}

void show_all_assoc_clients(struct p1905_managerd_ctx *ctx)
{
	struct dl_list *clients = NULL;
	struct assoc_client *client = NULL;
	int i = 0;

	printf("index	mac	bssid	vid\n");
	for (i = 0; i < HASH_TABLE_SIZE; i++) {
		clients = &ctx->clients_table[i];
		dl_list_for_each(client, clients, struct assoc_client, entry) {
			printf("[%d] "MACSTR" "MACSTR" %d\n",
				i, PRINT_MAC(client->mac), PRINT_MAC(client->bssid), client->vlan_id);
		}
	}
}

void show_all_operational_bss(struct p1905_managerd_ctx *ctx)
{
	struct operational_bss *bss = NULL;
	int i = 0;

	printf("show_all_operational_bss\n");
	printf("index\tmac\t\tssid\tvid\talmac\n");
	dl_list_for_each(bss, &ctx->bss_head, struct operational_bss, entry) {
		printf("[%d] "MACSTR" %s %d "MACSTR"\n", i,
			PRINT_MAC(bss->mac), bss->ssid, bss->vid, PRINT_MAC(bss->almac));
		i++;
	}
}

void delete_exist_radio_identifier(struct p1905_managerd_ctx *ctx)
{
	struct radio_identifier_db *p_tmp = NULL, *p_next = NULL;

	if (!SLIST_EMPTY(&ctx->metric_entry.radio_identifier_head)) {
		p_tmp = SLIST_FIRST(&ctx->metric_entry.radio_identifier_head);
		while (p_tmp) {
			p_next = SLIST_NEXT(p_tmp, radio_identifier_entry);
			SLIST_REMOVE(&ctx->metric_entry.radio_identifier_head, p_tmp,
				radio_identifier_db, radio_identifier_entry);
			free(p_tmp);
			p_tmp = p_next;
		}
	}
}

void add_new_radio_identifier(struct p1905_managerd_ctx *ctx, unsigned char *identifier)
{
	struct radio_identifier_db *p_new = NULL;

	p_new = (struct radio_identifier_db *)malloc(sizeof(struct radio_identifier_db));

	if (!p_new)
		return;

	memcpy(p_new->identifier, identifier, ETH_ALEN);
	SLIST_INSERT_HEAD(&ctx->metric_entry.radio_identifier_head, p_new, radio_identifier_entry);
}

void clear_assoc_client_table(struct p1905_managerd_ctx *ctx)
{
	struct assoc_client *client = NULL, *client_tmp = NULL;
	int i = 0;
#ifdef MAP_R6
	struct mlo_sta_db *aff_sta = NULL, *aff_sta_tmp = NULL;
#endif

	for (i = 0; i < HASH_TABLE_SIZE; i++) {
		dl_list_for_each_safe(client, client_tmp, &ctx->clients_table[i],
			struct assoc_client, entry) {
#ifdef MAP_R6
			/* clear sta mld rpt db */
			dl_list_for_each_safe(aff_sta, aff_sta_tmp, &client->sta_mld.mlo_sta_list,
				struct mlo_sta_db, list) {
				dl_list_del(&aff_sta->list);
				os_free(aff_sta);
			}
#endif
			dl_list_del(&client->entry);
			os_free(client);
		}
	}
}
#endif/*MAP_R2*/


#ifdef MAP_R3
#define FRAME_INFO_FILE "/tmp/map_frameinfo.txt"
#define RETURN_CONTENT_TLV 1
#define RETURN_CONTENT_HEXDUMP 2
#define RETURN_CONTENT_CACMethod 3
#define FILTER_FLAG_FIRST 1
#define FILTER_FLAG_LAST 2
#define FILTER_FLAG_ALL  4

void buf_huge(
	struct buf_info *buf,
	unsigned int pkt_len,
	unsigned char bcopy)
{
	unsigned char *new_buf = NULL;

	if (pkt_len > MAX_PKT_LEN) {
		/* pkt_len > 20k, buf_len < pkt_len, will malloc 100K */
		if (buf->buf_len < PKT_LEN_100K) {
			/* store cmdu hdr before free */
			new_buf = os_zalloc(PKT_LEN_100K);
			if (new_buf) {
				/* store new buf and len */
				if (bcopy)
					/* copy cmdu hdr + tlv if bcopy*/
					os_memcpy(new_buf, buf->buf, buf->buf_len);
				os_free(buf->buf);
				buf->buf = new_buf;
				buf->buf_len = PKT_LEN_100K;
			}
		}
	}
}

/* reset buf to 20k size */
void buf_reset(struct buf_info *buf)
{
	unsigned char *new_buf = NULL;

	new_buf = os_zalloc(MAX_PKT_LEN);
	if (new_buf) {
		/* new buf, change buf_len */
		os_free(buf->buf);
		buf->buf_len = MAX_PKT_LEN;
		buf->buf = new_buf;
	}
}

void tm_reset_buf_size(void *eloop_data, void *user_ctx)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx *)eloop_data;

	notice(DEBUG_CAT_DPP, "reset 20k buf\n");
	buf_reset(&ctx->trx_buf);
	buf_reset(&ctx->encr_buf);
	buf_reset(&ctx->tlv_buf);
	buf_reset(&ctx->reassemble_buf);
	sec_update_buf(ctx->encr_buf.buf, ctx->encr_buf.buf_len);
}

int cont_handle_bss_configuration_request(struct p1905_managerd_ctx *ctx, unsigned char *al_mac)
{
	struct mld_bss_config_db *mld_bss = NULL;

	if (ctx->role != CONTROLLER)
		goto end;

	/* wts to ap mld need agent's radio info, so place here after recv 1st bss cfg req
	 * no need this action while renew
	 */
	mld_bss = get_agent_ap_mld(ctx, al_mac);
	if (mld_bss)
		delete_ap_mld_conf(mld_bss);
	wts_2_mlo_agent(ctx, al_mac);

	insert_cmdu_txq(al_mac, ctx->p1905_al_mac_addr,
		e_bss_configuration_response, ++ctx->mid, ctx->itf[ctx->recent_cmdu_rx_if_number].if_name, 0);
	common_process(ctx, &ctx->trx_buf);

	/* renew state on controller */
	if (ctx->renew_ctx.trigger_renew) {
		leaf_info *leaf_top = NULL;

		if (get_top(&ctx->topo_stack, &leaf_top) == 0) {
			if (!os_memcmp(al_mac, leaf_top->al_mac, ETH_ALEN)) {
				pop_node(&ctx->topo_stack);
				notice(DEBUG_CAT_DPP, "bss configuration renewing, pop another leaf\n");
			} else
				notice(DEBUG_CAT_DPP, "bss configuration renewing, wait other dev config\n");
		} else
			notice(DEBUG_CAT_DPP, "topo stack empty\n");

		ctx->renew_state = wait_4_pop_node;
		eloop_cancel_timeout(controller_renew_bss_step, (void *)ctx, NULL);
		eloop_register_timeout(0, 0, controller_renew_bss_step, (void *)ctx, NULL);
	}
end:
	return 0;
}

void dev_get_frame_info_init(struct p1905_managerd_ctx *ctx)
{
	ctx->frame_buff_switch = 0;
	dl_list_init(&ctx->frame_buff_head);
	notice(DEBUG_CAT_DPP, "success\n");
}

void dev_get_frame_info_deinit(struct p1905_managerd_ctx *ctx)
{
	struct frame_buff_struct *msg_info_entry, *msg_info_entry_next;
	struct frame_list_struct *msg_list_entry, *msg_list_entry_next;

	/* delete all the msg type info and packet list first */
	dl_list_for_each_safe(msg_info_entry, msg_info_entry_next,
		&ctx->frame_buff_head, struct frame_buff_struct, frame_info_list) {

		dl_list_for_each_safe(msg_list_entry, msg_list_entry_next,
			&msg_info_entry->frame_data_list, struct frame_list_struct, data_list) {
			notice(DEBUG_CAT_DPP, "rm frame data from frame list for msg type 0x%04x\n",
			msg_info_entry->msg_type);
			os_free(msg_list_entry->data);
			dl_list_del(&msg_list_entry->data_list);
			os_free(msg_list_entry);
		}

		notice(DEBUG_CAT_DPP, "rm frame info for msg type 0x%04x\n",
			msg_info_entry->msg_type);
		dl_list_del(&msg_info_entry->frame_info_list);
		os_free(msg_info_entry);
    }

	ctx->frame_buff_switch = 0;
	notice(DEBUG_CAT_DPP, "success\n");
}

void cmd_dev_start_buffer(struct p1905_managerd_ctx *ctx, char *buf)
{
	char *pos1, *pos2;
	struct frame_buff_struct *msg_info_entry, *msg_info_entry_next;
	struct frame_list_struct *msg_list_entry, *msg_list_entry_next;
	/* support 10 msg type total */
	int msg_type[10];
	unsigned char i = 0;

	os_memset(msg_type, 0, sizeof(msg_type));

	ctx->frame_buff_switch = 1;
	notice(DEBUG_CAT_DPP, "ctx->frame_buff_switch %d\n", ctx->frame_buff_switch);

	/* delete all the msg type info and packet list first */
	dl_list_for_each_safe(msg_info_entry, msg_info_entry_next,
			      &ctx->frame_buff_head, struct frame_buff_struct, frame_info_list) {

		dl_list_for_each_safe(msg_list_entry, msg_list_entry_next,
				      &msg_info_entry->frame_data_list, struct frame_list_struct, data_list) {
			os_free(msg_list_entry->data);
			dl_list_del(&msg_list_entry->data_list);
			os_free(msg_list_entry);
		}

		dl_list_del(&msg_info_entry->frame_info_list);
		os_free(msg_info_entry);
	}

	pos1 = buf;

	while (NULL != (pos2 = strstr(pos1, "0x"))) {
		if (sscanf(pos2, "0x%04x", &msg_type[i]) < 0)
			warn(DEBUG_CAT_DPP, "[%d]Unexpected fail at sscanf\n", __LINE__);
		notice(DEBUG_CAT_DPP, "msg type 0x%04x\n", msg_type[i]);
		pos1 = pos2 + 2;

		/* malloc buffer for msg info for each msg type */

		msg_info_entry = os_zalloc(sizeof(struct frame_buff_struct));
		if (!msg_info_entry) {
			warn(DEBUG_CAT_DPP, "malloc msg error\n");
			break;
		}

		msg_info_entry->msg_type = msg_type[i];

		/* init packet list  */
		dl_list_init(&msg_info_entry->frame_data_list);

		/* add msg info to frame_buff_head */
		dl_list_add(&ctx->frame_buff_head, &msg_info_entry->frame_info_list);
	}

	/* wait 30 min at most to stop buffer
	 ** to avoid not receive stop buffer cmd from ucc
	 */
	eloop_register_timeout(30 * 60, 0, cmd_dev_stop_buffer_timeout, (void *)ctx, NULL);
	notice(DEBUG_CAT_DPP, "success\n");
	return;
}

void cmd_dev_stop_buffer(struct p1905_managerd_ctx *ctx)
{
	ctx->frame_buff_switch = 0;
	notice(DEBUG_CAT_DPP, "ctx->frame_buff_switch %d\n", ctx->frame_buff_switch);
	notice(DEBUG_CAT_DPP, "success\n");
}

void cmd_dev_stop_buffer_timeout(void *eloop_data, void *user_ctx)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx *)eloop_data;

	if (ctx->frame_buff_switch) {
		notice(DEBUG_CAT_DPP, "timeout, need stop buffering the frames\n");
		cmd_dev_stop_buffer(ctx);
	}
}

void get_tlv_data(struct p1905_managerd_ctx *ctx,
		  unsigned int msg_type,
		  unsigned int mid,
		  unsigned int tlv[], unsigned int flag, unsigned int pkt_num, unsigned int return_content)
{
	FILE *file = NULL;
	unsigned char *tmp = NULL;
	unsigned char *pdata = tmp;
	unsigned char msg_found = 0;
	unsigned char start_idx = 0, stop_idx = 0, cur_idx = 0;
	unsigned char cur_frame_idx = 0;
	unsigned short pkt_tlv_len = 0;
	unsigned short left_tlv_len = 0;
	struct frame_buff_struct *msg_info_entry, *msg_info_entry_next;
	struct frame_list_struct *msg_list_entry = NULL, *msg_list_entry_next = NULL;

	dl_list_for_each_safe(msg_info_entry, msg_info_entry_next,
			      &ctx->frame_buff_head, struct frame_buff_struct, frame_info_list) {
		if (msg_info_entry->msg_type == msg_type) {

			notice(DEBUG_CAT_DPP, "Message Type 0x%04x found\n", msg_type);

			msg_found = 1;
			break;
		}
	}

	if (!msg_found) {
		notice(DEBUG_CAT_DPP, "msg type 0x%04x not found\n", msg_type);
		return;
	}

	/* write MessageType to tmp file */
	file = fopen(FRAME_INFO_FILE, "w");
	if (!file) {
		warn(DEBUG_CAT_DPP, "open file %s error\n", FRAME_INFO_FILE);
		return;
	}

	if (fprintf(file, "MessageType 0x%04x\n", msg_type) < 0) {
		warn(DEBUG_CAT_DPP, "fprintf fail!\n");
		goto end;
	}

	/* else, no tlv specified */
	if (flag == FILTER_FLAG_FIRST) {
		start_idx = 0;
		stop_idx = (pkt_num > msg_info_entry->msg_cnt) ? msg_info_entry->msg_cnt : pkt_num;
	} else if (flag == FILTER_FLAG_LAST) {
		start_idx = (msg_info_entry->msg_cnt > pkt_num) ? (msg_info_entry->msg_cnt - pkt_num) : 0;
		stop_idx = msg_info_entry->msg_cnt;
	} else {
		start_idx = 0;
		stop_idx = msg_info_entry->msg_cnt;
	}

	/* if mid specified, match the mid among all the frames buffered */
	if (mid > 0) {
		start_idx = 0;
		stop_idx = msg_info_entry->msg_cnt;
	}
	notice(DEBUG_CAT_DPP, "start index %d, stop index %d\n", start_idx, stop_idx);

	if (tlv[0]) {
		/* TLVFieldValue,00 */
		if (fprintf(file, "TLVFieldValue ") < 0) {
			warn(DEBUG_CAT_DPP, "fprintf fail!\n");
			goto end;
		}
		notice(DEBUG_CAT_DPP, "append TLVFieldValue\n");
	} else {
		/* TLVList,1_0xBD_0xBD_0xB5_0xB6_2_0xBD_0xB5 */
		if (return_content == RETURN_CONTENT_TLV) {
			if (fprintf(file, "TLVList ") < 0) {
				warn(DEBUG_CAT_DPP, "fprintf fail!\n");
				goto end;
			}
			notice(DEBUG_CAT_DPP, "append TLVList\n");
		}
		/* MessageDump,1_B9081020304050607080BA03AABBCC */
		else {
			if (fprintf(file, "MessageDump ") < 0) {
				warn(DEBUG_CAT_DPP, "fprintf fail!\n");
				goto end;
			}
			notice(DEBUG_CAT_DPP, "append MessageDump\n");
		}
	}

	dl_list_for_each_safe(msg_list_entry, msg_list_entry_next,
			      &msg_info_entry->frame_data_list, struct frame_list_struct, data_list) {
		if (cur_idx >= start_idx && cur_idx < stop_idx) {
			/* mid specified, */
			if (mid > 0) {
				/* msg id mismatch, skip current frame */
				if (mid != msg_list_entry->mid)
					continue;
				/* msg id match, continue to check  */
				else
					notice(DEBUG_CAT_DPP, "frame mid 0x%04x found\n", msg_list_entry->mid);
			}

			cur_frame_idx++;
			notice(DEBUG_CAT_DPP, "current frame idx %d\n", cur_frame_idx);
			tmp = msg_list_entry->data;
			left_tlv_len = msg_list_entry->len;

			/* not first pkt, append "_" before frame index */
			if (cur_frame_idx > 1)
				if (fprintf(file, "_") < 0) {
					warn(DEBUG_CAT_DPP, "fprintf fail!\n");
					goto end;
				}

			/* append frame index */
			if (fprintf(file, "%d", cur_frame_idx) < 0) {
				warn(DEBUG_CAT_DPP, "fprintf fail!\n");
				goto end;
			}

			/* there is "_" between two messages for hexdump */
			if (return_content == RETURN_CONTENT_HEXDUMP)
				if (fprintf(file, "_") < 0) {
					warn(DEBUG_CAT_DPP, "fprintf fail!\n");
					goto end;
				}

			/* return_content: TLV */
			/* return all the tlv types of all the packets */
			while (1) {
				/* end of tlv, skip */
				if (*tmp == 0)
					break;
				pdata = tmp;
				pkt_tlv_len = *((unsigned short *)(tmp + 1));
				pkt_tlv_len = be_to_host16(pkt_tlv_len);

				if (pkt_tlv_len > left_tlv_len) {
					warn(DEBUG_CAT_DPP, "pkt_tlv_len %d bigger than left_tlv_len %d\n", pkt_tlv_len, left_tlv_len);
					goto end;
				}

				/* there is "_" between two tlv types */
				if (return_content == RETURN_CONTENT_TLV) {
					if (fprintf(file, "_0x%02X", *tmp) < 0) {
						warn(DEBUG_CAT_DPP, "fprintf fail!\n");
						goto end;
					}
					notice(DEBUG_CAT_DPP, "\n*****************************\n");
					notice_np(DEBUG_CAT_DPP, "tlv 0x%02X\n", *tmp);
					notice_np(DEBUG_CAT_DPP, "*****************************\n");
				}
				/*  but no "_" between datas */
				else if (return_content == RETURN_CONTENT_HEXDUMP) {

					/* if tlv type specified, return data include [t l v] */
					if (tlv[0]) {
						if (tlv[0] == *tmp) {
							notice(DEBUG_CAT_DPP, "frame tlv 0x%02x found\n", *tmp);
							while (pdata - tmp < (pkt_tlv_len + 3)) {
								if (fprintf(file, "%02X", *pdata) < 0) {
									warn(DEBUG_CAT_DPP, "fprintf fail!\n");
									goto end;
								}
								pdata++;
							}
						}

					} else {
						while (pdata - tmp < (pkt_tlv_len + 3)) {
							if (fprintf(file, "%02X", *pdata) < 0) {
								warn(DEBUG_CAT_DPP, "fprintf fail!\n");
								goto end;
							}
							pdata++;
						}
					}
				}

				/* next tlv */
				tmp += (3 + pkt_tlv_len);
				left_tlv_len -= (3 + pkt_tlv_len);
			}
		}
		cur_idx++;
	}
	if (fprintf(file, "\n") < 0) {
		warn(DEBUG_CAT_DPP, "fprintf fail!\n");
		goto end;
	}
end:
	if (fclose(file) < 0)
		warn(DEBUG_CAT_DPP, "fclose fail, errno %d(%s)!\n", errno, strerror(errno));

	return;
}

void cmd_dev_get_frame_info(struct p1905_managerd_ctx *ctx, char *buf)
{
	unsigned int msg_type = 0;
	unsigned int tlv[8];
	unsigned int mid = 0;
	char *pos1 = NULL, *pos2 = NULL;
	unsigned int flag = 0, pkt_num = 0, return_content = 0;

	os_memset(tlv, 0, sizeof(tlv));

	notice(DEBUG_CAT_DPP, "\n");
	/* message type */
	pos1 = buf;
	pos2 = os_strstr(pos1, " ");
	if (!pos2)
		return;

	msg_type = (unsigned int)strtol(pos1, NULL, 16);
	if (errno != 0)
		warn(DEBUG_CAT_DPP, "Unexpected fail at strtol\n");
	notice(DEBUG_CAT_DPP, "set message type 0x%04x\n", msg_type);

	/* tlv */
	pos1 = pos2 + 1;
	pos2 = os_strstr(pos1, " ");
	if (!pos2)
		return;
	tlv[0] = (unsigned int)strtol(pos1, NULL, 16);
	if (errno != 0)
		warn(DEBUG_CAT_DPP, "Unexpected fail at strtol\n");
	notice(DEBUG_CAT_DPP, "set tlv 0x%02x\n", tlv[0]);

	/* MID */
	pos1 = pos2 + 1;
	pos2 = os_strstr(pos1, " ");
	if (!pos2)
		return;
	mid = (unsigned int)strtol(pos1, NULL, 16);
	if (errno != 0)
		warn(DEBUG_CAT_DPP, "Unexpected fail at strtol\n");
	notice(DEBUG_CAT_DPP, "set mid 0x%04x\n", mid);

	/* Filter */
	pos1 = pos2 + 1;
	pos2 = os_strstr(pos1, " ");
	if (!pos2)
		return;
	if (os_strstr(pos1, "first") != NULL) {
		pkt_num = 1;
		flag = FILTER_FLAG_FIRST;
		notice(DEBUG_CAT_DPP, "set First flag(First)\n");
	} else if (os_strstr(pos1, "last") != NULL) {
		flag = FILTER_FLAG_LAST;
		pkt_num = 1;
		notice(DEBUG_CAT_DPP, "set Last flag(Last)\n");
	} else if (os_strstr(pos1, "all") != NULL) {
		pkt_num = 0xff;
		flag = FILTER_FLAG_ALL;
		notice(DEBUG_CAT_DPP, "set All flag(All)\n");
	} else {
		if (sscanf(pos1, "%x", &pkt_num) < 0)
			warn(DEBUG_CAT_DPP, "Unexpected fail at sscanf\n");
		notice(DEBUG_CAT_DPP, "set pkt num %d\n", pkt_num);

		if (os_strstr(pos1, "_f") != NULL) {
			flag = FILTER_FLAG_FIRST;
			notice(DEBUG_CAT_DPP, "set First flag(_F)\n");
		} else if (os_strstr(pos1, "_l") != NULL) {
			flag = FILTER_FLAG_LAST;
			notice(DEBUG_CAT_DPP, "set Last flag(_L)\n");
		} else {
			notice(DEBUG_CAT_DPP, "no last or first flag be set\n");
			return;
		}
	}

	/* ReturnContent */
	pos1 = pos2 + 1;
	if (os_strstr(pos1, "tlv") != NULL) {
		return_content = RETURN_CONTENT_TLV;
		notice(DEBUG_CAT_DPP, "return content: TLV\n");
	} else if (os_strstr(pos1, "messagehexdump") != NULL) {
		return_content = RETURN_CONTENT_HEXDUMP;
		notice(DEBUG_CAT_DPP, "return content: HEXDUMP\n");
	}

	get_tlv_data(ctx, msg_type, mid, tlv, flag, pkt_num, return_content);
	return;
}

void dev_buffer_frame(struct p1905_managerd_ctx *ctx, unsigned short mtype,
		      unsigned short mid, unsigned char *tlv_pos, int tlv_len)
{
	struct frame_buff_struct *msg_info_entry, *msg_info_entry_next;
	struct frame_list_struct *msg_list_entry = NULL;
	unsigned char *msg_data = NULL;

	if (ctx->frame_buff_switch) {
		dl_list_for_each_safe(msg_info_entry, msg_info_entry_next,
				      &ctx->frame_buff_head, struct frame_buff_struct, frame_info_list) {
			if (msg_info_entry->msg_type == mtype) {
				notice(DEBUG_CAT_DPP, "store data for msg type 0x%04x\n", mtype);
				msg_list_entry = os_zalloc(sizeof(struct frame_list_struct));
				if (!msg_list_entry)
					break;
				msg_data = os_zalloc((size_t) tlv_len);
				if (!msg_data) {
					os_free(msg_list_entry);
					break;
				}

				/* will be free after next dev_start_buff cmd or daemon exit */
				os_memcpy(msg_data, tlv_pos, tlv_len);
				msg_list_entry->data = msg_data;
				msg_list_entry->len = tlv_len;
				msg_list_entry->mid = mid;
				msg_info_entry->msg_cnt++;
				dl_list_add(&msg_info_entry->frame_data_list, &msg_list_entry->data_list);
			}
		}
	}
}

int init_akm_capability(struct p1905_managerd_ctx *ctx)
{
	ctx->bsta_akm.akm_suite_cnt = 4;
	ctx->bsta_akm.akm_suite_info = (struct akm_suit *)os_malloc(4 * sizeof(struct akm_suit));
	if (!ctx->bsta_akm.akm_suite_info)
		goto fail3;

	os_memcpy(&ctx->bsta_akm.akm_suite_info[0], OUI_WPA2_AKM_PSK, 4);
	os_memcpy(&ctx->bsta_akm.akm_suite_info[1], OUI_WPA2_AKM_PSK_SHA256, 4);
	os_memcpy(&ctx->bsta_akm.akm_suite_info[2], OUI_WPA2_AKM_SAE_SHA256, 4);
	os_memcpy(&ctx->bsta_akm.akm_suite_info[3], OUI_AKM_DPP, 4);

	ctx->bh_akm.akm_suite_cnt = 4;
	ctx->bh_akm.akm_suite_info = (struct akm_suit *)os_malloc(4 * sizeof(struct akm_suit));
	if (!ctx->bh_akm.akm_suite_info)
		goto fail2;

	os_memcpy(&ctx->bh_akm.akm_suite_info[0], OUI_WPA2_AKM_PSK, 4);
	os_memcpy(&ctx->bh_akm.akm_suite_info[1], OUI_WPA2_AKM_PSK_SHA256, 4);
	os_memcpy(&ctx->bh_akm.akm_suite_info[2], OUI_WPA2_AKM_SAE_SHA256, 4);
	os_memcpy(&ctx->bh_akm.akm_suite_info[3], OUI_AKM_DPP, 4);

	ctx->fh_akm.akm_suite_cnt = 6;
	ctx->fh_akm.akm_suite_info = (struct akm_suit *)os_malloc(6 * sizeof(struct akm_suit));
	if (!ctx->fh_akm.akm_suite_info)
		goto fail1;

	os_memcpy(&ctx->fh_akm.akm_suite_info[0], OUI_WPA2_AKM_PSK, 4);
	os_memcpy(&ctx->fh_akm.akm_suite_info[1], OUI_WPA2_AKM_FT_PSK, 4);
	os_memcpy(&ctx->fh_akm.akm_suite_info[2], OUI_WPA2_AKM_PSK_SHA256, 4);
	os_memcpy(&ctx->fh_akm.akm_suite_info[3], OUI_WPA2_AKM_SAE_SHA256, 4);
	os_memcpy(&ctx->fh_akm.akm_suite_info[4], OUI_WPA2_AKM_FT_SAE_SHA256, 4);
	os_memcpy(&ctx->fh_akm.akm_suite_info[5], OUI_AKM_DPP, 4);

	return 0;
fail1:
	os_free(ctx->bh_akm.akm_suite_info);
fail2:
	os_free(ctx->bsta_akm.akm_suite_info);
fail3:
	return -1;
}

void deinit_akm_capability(struct p1905_managerd_ctx *ctx)
{
	os_free(ctx->fh_akm.akm_suite_info);
	os_free(ctx->bh_akm.akm_suite_info);
	os_free(ctx->bsta_akm.akm_suite_info);
}

#ifdef PTK_REKEY
void resend_ptk_rekey_request_msg(void *eloop_ctx, void *timeout_ctx)
{
	struct wpa_entry_info *entry = eloop_ctx;
	struct p1905_managerd_ctx *ctx = timeout_ctx;
	struct topology_response_db *tpgr_db = NULL;
	int ifidx = -1;

	SLIST_FOREACH(tpgr_db, &(ctx->topology_entry.tprdb_head), tprdb_entry) {
		if(!memcmp(entry->peer_addr, tpgr_db->al_mac_addr, ETH_ALEN)) {
		   ifidx = tpgr_db->recv_ifid;
		}
	}

	insert_cmdu_txq(entry->peer_addr, entry->own_addr,
		e_ptk_rekey_request, ++ctx->mid,
		(ifidx != -1) ? ctx->itf[ifidx].if_name : ctx->br_name, 0);

	notice(DEBUG_CAT_DPP, "to "MACSTR" on interface %s\n", MAC2STR(entry->peer_addr),
		(ifidx != -1) ? ctx->itf[ifidx].if_name : ctx->br_name);

	return;
}

void resend_ptk_rekey_request_timer(void *eloop_ctx, void *timeout_ctx)
{
	struct wpa_parameter *wpa_param = eloop_ctx;
	struct wpa_entry_info *entry, *entry_next;
	unsigned char peer_cnt = 0;

	dl_list_for_each_safe(entry, entry_next, &wpa_param->entry_list, struct wpa_entry_info, list) {
		/*  avoid creating a burst of control message traffic */
		notice(DEBUG_CAT_DPP, "start timer %d(s) to send ptk rekey request to "MACSTR"\n",
			peer_cnt * 10, MAC2STR(entry->peer_addr));
		eloop_cancel_timeout(resend_ptk_rekey_request_msg, (void *)entry, (void *)wpa_param->p1905_ctx);
		eloop_register_timeout(peer_cnt * 5, 0,
			resend_ptk_rekey_request_msg, (void *)entry, wpa_param->p1905_ctx);
		peer_cnt ++;
	}

	eloop_cancel_timeout(resend_ptk_rekey_request_timer, (void *)wpa_param, NULL);
	eloop_register_timeout(wpa_param->wpa_conf.ptk_rekey_timer, 0,
		resend_ptk_rekey_request_timer, (void *)wpa_param, NULL);
}
#endif /*PTK_REKEY*/

void resend_gtk_timer(void *eloop_ctx, void *timeout_ctx)
{
	struct wpa_parameter *wpa_param = eloop_ctx;
	struct wpa_entry_info *entry = NULL, *entry_next = NULL;

	/* GTK only can be update @ init or rekey stage */
	if (wpa_param->role == CONTROLLER) {
		wpa_gtk_update(&wpa_param->group);
	}

	dl_list_for_each_safe(entry, entry_next, &wpa_param->entry_list, struct wpa_entry_info, list) {
		wpa_send_group_msg_1(entry->wpa_sm);
	}

	eloop_cancel_timeout(resend_gtk_timer, (void *)wpa_param, NULL);
    eloop_register_timeout(wpa_param->wpa_conf.gtk_rekey_timer, 0,
		resend_gtk_timer, (void *)wpa_param, NULL);
}

void cmd_send_bss_reconfiguration_trigger(struct p1905_managerd_ctx *ctx, char *buf)
{
	int i = 0;
	unsigned char al_mac[ETH_ALEN] = {0};
	char *pos1 = buf, *pos2 = NULL;
	unsigned int mac_int[ETH_ALEN];
	struct r3_member *peer = NULL;

	if (_1905_read_set_config(ctx, ctx->wts_bss_cfg_file, ctx->bss_config,
		MAX_SET_BSS_INFO_NUM, &ctx->bss_config_num) < 0) {
		notice(DEBUG_CAT_DPP, "load bss config fail from %s\n", ctx->wts_bss_cfg_file);
		return;
	}

	if (buf && (os_strlen(buf) > 0)) {
		while (NULL != (pos2 = strstr(pos1, " "))) {

			if (sscanf(pos1, "%02x:%02x:%02x:%02x:%02x:%02x", mac_int,
				(mac_int + 1), (mac_int + 2), (mac_int + 3),
				(mac_int + 4), (mac_int + 5)) < 0) {
				warn(DEBUG_CAT_DPP, "sscanf fail\n");
				return;
			}

			pos1 = pos2+1;
			for (i = 0; i < ETH_ALEN; i++)
				al_mac[i] = (unsigned char)mac_int[i];

			peer = get_r3_member(al_mac);
			if (peer && peer->security_1905) {
				notice(DEBUG_CAT_DPP, "send bss reconfiguration trigger msg to special Agent "MACSTR"\n", MAC2STR(al_mac));
				insert_cmdu_txq(peer->al_mac, ctx->p1905_al_mac_addr,
					e_bss_reconfiguration_trigger, ++ctx->mid, ctx->br_name, 0);
			} else {
				notice(DEBUG_CAT_DPP, ""MACSTR" is not R3 onboarding, skip\n", MAC2STR(al_mac));
			}
		}
	} else {
		dl_list_for_each(peer, &r3_member_head, struct r3_member, entry) {
			if (peer->security_1905) {
				notice(DEBUG_CAT_DPP, "send bss reconfiguration trigger to "MACSTR" in R3 member list\n",
					MAC2STR(peer->al_mac));
				insert_cmdu_txq(peer->al_mac, ctx->p1905_al_mac_addr,
					e_bss_reconfiguration_trigger, ++ctx->mid, ctx->br_name, 0);
			}
		}
	}

}

void del_chirp_from_hash_list(struct p1905_managerd_ctx *ctx,
	struct chirp_tlv_info *chirp_tlv)

{
	struct hash_value_item *hv_item = NULL, *hv_item_nxt = NULL;

	dl_list_for_each_safe(hv_item, hv_item_nxt,
		&ctx->r3_dpp.hash_value_list, struct hash_value_item, member) {
		if (!os_memcmp(hv_item->hashValue, chirp_tlv->hash_payload, sizeof(hv_item->hashValue))) {
			notice(DEBUG_CAT_DPP, "del chirp for apcli "MACSTR"\n", MAC2STR(hv_item->mac_apcli));
			dl_list_del(&hv_item->member);
			break;
		}
	}
}

void add_chirp_hash_list(struct p1905_managerd_ctx *ctx,
	struct chirp_tlv_info *chirp_tlv, unsigned char *almac)
{
	struct hash_value_item *hv_item = NULL, *hv_item_nxt = NULL;
	int found = 0;
	unsigned char all_zero_mac[ETH_ALEN];

	os_memset(all_zero_mac, 0, sizeof(all_zero_mac));

	dl_list_for_each_safe(hv_item, hv_item_nxt,
		&ctx->r3_dpp.hash_value_list, struct hash_value_item, member) {
		if (!os_memcmp(hv_item->hashValue, chirp_tlv->hash_payload, chirp_tlv->hash_len)) {
			info(DEBUG_CAT_DPP, "update chirp");
			found = 1;
			break;
		}
	}

	if (!found) {
		hv_item = os_zalloc(sizeof(struct hash_value_item));
		if (!hv_item)
			return;
		os_memcpy(hv_item->almac, (unsigned char *)almac, ETH_ALEN);
		hv_item->hashLen = chirp_tlv->hash_len;
		os_memcpy(hv_item->hashValue, chirp_tlv->hash_payload, chirp_tlv->hash_len);
		info(DEBUG_CAT_DPP, "new chirp");

		dl_list_add(&ctx->r3_dpp.hash_value_list, &hv_item->member);
	}

	if ((os_memcmp(almac, all_zero_mac, ETH_ALEN))) {
		os_memcpy(hv_item->almac, (unsigned char *)almac, ETH_ALEN);
		info_np(DEBUG_CAT_DPP, ", almac "MACSTR"", MAC2STR(hv_item->almac));
	}
	if ((os_memcmp(chirp_tlv->enrollee_mac, all_zero_mac, ETH_ALEN))) {
		os_memcpy(hv_item->mac_apcli, chirp_tlv->enrollee_mac, ETH_ALEN);
		info_np(DEBUG_CAT_DPP, ", apcli mac "MACSTR"", MAC2STR(hv_item->mac_apcli));
	}
	info_np(DEBUG_CAT_DPP, "\n");
}

void report_akm_suit_cap_to_mapd(void *eloop_ctx, void *timeout_ctx)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx *)eloop_ctx;
	unsigned char tlv_buf[128] = {0};
	unsigned short tlv_len = 0;

	tlv_len = append_akm_suite_cap_tlv(tlv_buf, ctx);
	map_notify_akm_suit_cap(ctx, ctx->p1905_al_mac_addr, tlv_buf, tlv_len);
}

void report_1905_secure_cap_to_mapd(void *eloop_ctx, void *timeout_ctx)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx *)eloop_ctx;
	unsigned char tlv_buf[64] = {0};
	unsigned short tlv_len = 0;

	tlv_len = append_1905_layer_security_tlv(tlv_buf);
	map_notify_1905_secure_cap(ctx, ctx->p1905_al_mac_addr, tlv_buf, tlv_len);
}

void report_sp_standard_rule_to_mapd_timeout(void *eloop_ctx, void *timeout_ctx)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx *)eloop_ctx;

	report_sp_standard_rule_to_mapd(ctx);
}



void report_sp_standard_rule_to_mapd(struct p1905_managerd_ctx *ctx)
{
	ctx->revd_tlv.buf_len = get_standard_sp_rule(ctx->revd_tlv.buf, MAX_PKT_LEN,
						&ctx->sp_rule_static_list, &ctx->sp_dp_table,
						ADD_RULE, ctx->p1905_al_mac_addr);
	if (ctx->revd_tlv.buf_len)
		map_notify_standard_sp_rules(ctx, ctx->p1905_al_mac_addr,
			ctx->revd_tlv.buf, ctx->revd_tlv.buf_len);
}
#ifdef MAP_R3_WF6
int update_ap_wf6_cap(struct p1905_managerd_ctx* ctx, struct ap_wf6_cap_roles *pcap)
{
	struct ap_wf6_role_db *pdb;
	int i = 0;

	if (pcap->wf6_role[0].he_mcs_len > 12 || pcap->wf6_role[0].he_mcs_len < 4) {
		warn(DEBUG_CAT_DPP, "invalid he_mcs_len(%d)\n", pcap->wf6_role[0].he_mcs_len);
		return -1;
	}

	SLIST_FOREACH(pdb, &(ctx->ap_cap_entry.ap_wf6_cap_head), ap_wf6_role_entry)
	{
		/*exist entry, update it*/
		if(!memcmp(pdb->identifier, pcap->identifier, ETH_ALEN))
		{
			pdb->role_supp = pcap->role_supp;
#ifdef MAP_R4_SPT
			pdb->sr_mode = pcap->sr_mode;
#endif
			for(i = 0; i < pcap->role_supp; i++) {
				pdb->wf6_role[i].he_mcs_len = pcap->wf6_role[i].he_mcs_len;
				os_memcpy(pdb->wf6_role[i].he_mcs, pcap->wf6_role[i].he_mcs, pdb->wf6_role[i].he_mcs_len);
				pdb->wf6_role[i].tx_stream = pcap->wf6_role[i].tx_stream;
				pdb->wf6_role[i].rx_stream = pcap->wf6_role[i].rx_stream;
				pdb->wf6_role[i].he_8080 = pcap->wf6_role[i].he_8080;
				pdb->wf6_role[i].he_160 = pcap->wf6_role[i].he_160;
				pdb->wf6_role[i].su_bf_cap = pcap->wf6_role[i].su_bf_cap;
				pdb->wf6_role[i].mu_bf_cap = pcap->wf6_role[i].mu_bf_cap;
				pdb->wf6_role[i].ul_mu_mimo_cap = pcap->wf6_role[i].ul_mu_mimo_cap;
				pdb->wf6_role[i].ul_mu_mimo_ofdma_cap = pcap->wf6_role[i].ul_mu_mimo_ofdma_cap;
				pdb->wf6_role[i].dl_mu_mimo_ofdma_cap = pcap->wf6_role[i].dl_mu_mimo_ofdma_cap;
				pdb->wf6_role[i].ul_ofdma_cap = pcap->wf6_role[i].ul_ofdma_cap;
				pdb->wf6_role[i].dl_ofdma_cap = pcap->wf6_role[i].dl_ofdma_cap;
				pdb->wf6_role[i].agent_role = pcap->wf6_role[i].agent_role;
				pdb->wf6_role[i].su_beamformee_status = pcap->wf6_role[i].su_beamformee_status;
				pdb->wf6_role[i].beamformee_sts_less80 = pcap->wf6_role[i].beamformee_sts_less80;
				pdb->wf6_role[i].beamformee_sts_more80= pcap->wf6_role[i].beamformee_sts_more80;
				pdb->wf6_role[i].max_user_dl_tx_mu_mimo = pcap->wf6_role[i].max_user_dl_tx_mu_mimo;
				pdb->wf6_role[i].max_user_ul_rx_mu_mimo = pcap->wf6_role[i].max_user_ul_rx_mu_mimo;
				pdb->wf6_role[i].max_user_dl_tx_ofdma = pcap->wf6_role[i].max_user_dl_tx_ofdma;
				pdb->wf6_role[i].max_user_ul_rx_ofdma = pcap->wf6_role[i].max_user_ul_rx_ofdma;
				pdb->wf6_role[i].rts_status = pcap->wf6_role[i].rts_status;
				pdb->wf6_role[i].mu_rts_status = pcap->wf6_role[i].mu_rts_status;
				pdb->wf6_role[i].m_bssid_status = pcap->wf6_role[i].m_bssid_status;
				pdb->wf6_role[i].mu_edca_status = pcap->wf6_role[i].mu_edca_status;
				pdb->wf6_role[i].twt_requester_status = pcap->wf6_role[i].twt_requester_status;
				pdb->wf6_role[i].twt_responder_status = pcap->wf6_role[i].twt_responder_status;
			}

			return 0;
		}
	}
	/*insert new one*/
	pdb = (struct ap_wf6_role_db*)malloc(sizeof(struct ap_wf6_role_db));
	if(pdb == NULL)
	{
		warn(DEBUG_CAT_DPP, "allocate memory fail ap_wf6_role_db\n");
		return -1;
	}
	memcpy(pdb->identifier, pcap->identifier, ETH_ALEN);
	pdb->role_supp = pcap->role_supp;
#ifdef MAP_R4_SPT
	pdb->sr_mode = pcap->sr_mode;
#endif
	for(i = 0; i < pcap->role_supp; i++) {
		pdb->wf6_role[i].he_mcs_len = pcap->wf6_role[i].he_mcs_len;
		os_memcpy(pdb->wf6_role[i].he_mcs, pcap->wf6_role[i].he_mcs, pdb->wf6_role[i].he_mcs_len);
		pdb->wf6_role[i].tx_stream = pcap->wf6_role[i].tx_stream;
		pdb->wf6_role[i].rx_stream = pcap->wf6_role[i].rx_stream;
		pdb->wf6_role[i].he_8080 = pcap->wf6_role[i].he_8080;
		pdb->wf6_role[i].he_160 = pcap->wf6_role[i].he_160;
		pdb->wf6_role[i].su_bf_cap = pcap->wf6_role[i].su_bf_cap;
		pdb->wf6_role[i].mu_bf_cap = pcap->wf6_role[i].mu_bf_cap;
		pdb->wf6_role[i].ul_mu_mimo_cap = pcap->wf6_role[i].ul_mu_mimo_cap;
		pdb->wf6_role[i].ul_mu_mimo_ofdma_cap = pcap->wf6_role[i].ul_mu_mimo_ofdma_cap;
		pdb->wf6_role[i].dl_mu_mimo_ofdma_cap = pcap->wf6_role[i].dl_mu_mimo_ofdma_cap;
		pdb->wf6_role[i].ul_ofdma_cap = pcap->wf6_role[i].ul_ofdma_cap;
		pdb->wf6_role[i].dl_ofdma_cap = pcap->wf6_role[i].dl_ofdma_cap;
		pdb->wf6_role[i].agent_role = pcap->wf6_role[i].agent_role;
		pdb->wf6_role[i].su_beamformee_status = pcap->wf6_role[i].su_beamformee_status;
		pdb->wf6_role[i].beamformee_sts_less80 = pcap->wf6_role[i].beamformee_sts_less80;
		pdb->wf6_role[i].beamformee_sts_more80= pcap->wf6_role[i].beamformee_sts_more80;
		pdb->wf6_role[i].max_user_dl_tx_mu_mimo = pcap->wf6_role[i].max_user_dl_tx_mu_mimo;
		pdb->wf6_role[i].max_user_ul_rx_mu_mimo = pcap->wf6_role[i].max_user_ul_rx_mu_mimo;
		pdb->wf6_role[i].max_user_dl_tx_ofdma = pcap->wf6_role[i].max_user_dl_tx_ofdma;
		pdb->wf6_role[i].max_user_ul_rx_ofdma = pcap->wf6_role[i].max_user_ul_rx_ofdma;
		pdb->wf6_role[i].rts_status = pcap->wf6_role[i].rts_status;
		pdb->wf6_role[i].mu_rts_status = pcap->wf6_role[i].mu_rts_status;
		pdb->wf6_role[i].m_bssid_status = pcap->wf6_role[i].m_bssid_status;
		pdb->wf6_role[i].mu_edca_status = pcap->wf6_role[i].mu_edca_status;
		pdb->wf6_role[i].twt_requester_status = pcap->wf6_role[i].twt_requester_status;
		pdb->wf6_role[i].twt_responder_status = pcap->wf6_role[i].twt_responder_status;
	}
	SLIST_INSERT_HEAD(&(ctx->ap_cap_entry.ap_wf6_cap_head), pdb, ap_wf6_role_entry);
	return 0;
}
#endif/*MAP_R3_WF6*/
#ifdef MAP_R3_DE
int update_ap_dev_inven(struct p1905_managerd_ctx* ctx, struct dev_inven *de)
{
	int i = 0;
	struct dev_inven_ruid *de_ruid;
	struct dev_inven_ruid *ctx_ruid;

	os_memset(&ctx->de, '\0', sizeof(struct dev_inven));
	os_memcpy(ctx->de.sw_ver, de->sw_ver, de->sw_ver_len);
	ctx->de.sw_ver_len = de->sw_ver_len;

	os_memcpy(ctx->de.exec_env, de->exec_env, de->exec_env_len);
	ctx->de.exec_env_len = de->exec_env_len;

	os_memcpy(ctx->de.ser_num, de->ser_num, de->ser_num_len);
	ctx->de.ser_num_len = de->ser_num_len;

	ctx->de.num_radio = de->num_radio;

	for(i = 0; i < ctx->de.num_radio; i++)
	{
		de_ruid = &de->ruid[i];
		ctx_ruid = &ctx->de.ruid[i];

		os_memcpy(ctx_ruid->identifier, de_ruid->identifier, ETH_ALEN);

		os_memcpy(ctx_ruid->chip_ven, de_ruid->chip_ven, de_ruid->chip_ven_len);
		ctx_ruid->chip_ven_len = de_ruid->chip_ven_len;
	}

	return 0;
}
#endif /*MAP_R3_DE*/
#endif/*MAP_R3*/

/*MLO related change*/
int delete_exist_mlo_cap_by_ruid(struct p1905_managerd_ctx *ctx, unsigned char *identifier)
{
	struct ap_mlo_cap_db *cap = NULL;

	debug(DEBUG_CAT_MLO, "\n");

	SLIST_FOREACH(cap, &ctx->ap_cap_entry.ap_mlo_cap_head, entry)
	{
		if (os_memcmp(cap->identifier, identifier, ETH_ALEN) == 0) {
			debug(DEBUG_CAT_MLO, "delete_exist struct ap_mlo_cap_db\n");
			debug(DEBUG_CAT_MLO, "identifier("MACSTR")\n", PRINT_MAC(cap->identifier));
			SLIST_REMOVE(&ctx->ap_cap_entry.ap_mlo_cap_head,
				cap, ap_mlo_cap_db, entry);
			os_free(cap);
			return 0;
		}
	}

	if (SLIST_EMPTY(&ctx->ap_cap_entry.ap_mlo_cap_head))
		SLIST_INIT(&ctx->ap_cap_entry.ap_mlo_cap_head);

	return 0;
}

int delete_exist_mlo_cap(struct p1905_managerd_ctx *ctx)
{
	struct ap_mlo_cap_db *cap = NULL;
	struct ap_mlo_cap_db *cap_tmp = NULL;

	cap = SLIST_FIRST(&ctx->ap_cap_entry.ap_mlo_cap_head);
	while (cap) {
		cap_tmp = SLIST_NEXT(cap, entry);
		debug(DEBUG_CAT_MLO, "delete_exist struct ap_mlo_cap_db\n");
		debug(DEBUG_CAT_MLO, "identifier("MACSTR")\n", PRINT_MAC(cap->identifier));
		SLIST_REMOVE(&ctx->ap_cap_entry.ap_mlo_cap_head,
			cap, ap_mlo_cap_db, entry);
		os_free(cap);
		cap = cap_tmp;
	}

	return 0;
}


int update_radio_mlo_cap(struct p1905_managerd_ctx *ctx, struct ap_mlo_cap_lib *mlo_cap)
{
	struct ap_mlo_cap_db *new_mlo = NULL;
	struct mlo_cap_per_role *role = NULL;
	int i = 0;
	int mlo_enable = 0;

	/*check memory valid*/
	for (i = 0; i < mlo_cap->role_num; i++) {
		role = &mlo_cap->role_cap[i];
		if (role->dev_role > 1) {
			err(DEBUG_CAT_MLO, "dev_role err\n");
			goto err;
		}
		if (role->static_punc_supp > 1) {
			err(DEBUG_CAT_MLO, "static_punc_supp err\n");
			goto err;
		}
		if (role->mlo_enable > 1) {
			err(DEBUG_CAT_MLO, "mlo_enable err\n");
			goto err;
		}
		if (role->eml_cap.emlsr_supp > 1) {
			err(DEBUG_CAT_MLO, "emlsr_supp err\n");
			goto err;
		}
		if (role->eml_cap.emlsr_padding_delay > 7) {
			err(DEBUG_CAT_MLO, "emlsr_padding_delay err\n");
			goto err;
		}
		if (role->eml_cap.emlsr_trans_delay > 7) {
			err(DEBUG_CAT_MLO, "emlsr_trans_delay err\n");
			goto err;
		}
		if (role->eml_cap.emlmr_supp > 1) {
			err(DEBUG_CAT_MLO, "emlmr_supp err\n");
			goto err;
		}
		if (role->eml_cap.emlmr_delay > 7) {
			err(DEBUG_CAT_MLO, "emlmr_delay err\n");
			goto err;
		}
		if (role->eml_cap.trans_timeout > 15) {
			err(DEBUG_CAT_MLO, "trans_timeout err\n");
			goto err;
		}

		if (role->mld_cap.max_simul_link > 15) {
			err(DEBUG_CAT_MLO, "max_simul_link err\n");
			goto err;
		}
		if (role->mld_cap.srs_supp > 1) {
			err(DEBUG_CAT_MLO, "srs_supp err\n");
			goto err;
		}
		if (role->mld_cap.t2l_nego_supp > 3) {
			err(DEBUG_CAT_MLO, "t2l_nego_supp err\n");
			goto err;
		}
		if (role->mld_cap.freq_sep_str > 31) {
			err(DEBUG_CAT_MLO, "freq_sep_str err\n");
			goto err;
		}
		if (role->mld_cap.aar_supp > 1) {
			err(DEBUG_CAT_MLO, "aar_supp err\n");
			goto err;
		}
	}

	new_mlo = os_malloc(sizeof(struct ap_mlo_cap_db));
	if (!new_mlo) {
		err(DEBUG_CAT_MLO, "malloc error for radio mlo cap\n");
		return -1;
	}

	os_memset(new_mlo, 0, sizeof(struct ap_mlo_cap_db));
	os_memcpy(new_mlo->identifier, mlo_cap->identifier, ETH_ALEN);
	new_mlo->role_num = mlo_cap->role_num;
	debug(DEBUG_CAT_MLO, "ruid "MACSTR", role num %d\n", MAC2STR(new_mlo->identifier), new_mlo->role_num);

	for (i = 0; i < new_mlo->role_num; i++) {
		os_memcpy(&new_mlo->role_cap[i], &mlo_cap->role_cap[i],
			sizeof(struct mlo_cap_per_role));
		debug(DEBUG_CAT_MLO, "role %d mlo enable %d\n", i, new_mlo->role_cap[i].mlo_enable);
		if (new_mlo->role_cap[i].mlo_enable)
			mlo_enable = 1;
	}

	for (i = 0; i < ctx->radio_number; i++) {
		if (!os_memcmp(ctx->rinfo[i].identifier, mlo_cap->identifier, ETH_ALEN)) {
			ctx->rinfo[i].mlo_cap = 0;
			debug(DEBUG_CAT_MLO, "clear mlo enable for identifier "MACSTR"\n", MAC2STR(mlo_cap->identifier));
			if (mlo_enable) {
				ctx->rinfo[i].mlo_cap = 1;
				debug(DEBUG_CAT_MLO, "set mlo enable 1 for identifier "MACSTR"\n", MAC2STR(mlo_cap->identifier));
			}
		}
	}


	SLIST_INSERT_HEAD(&ctx->ap_cap_entry.ap_mlo_cap_head, new_mlo, entry);

	return 0;

err:
	notice_hexdump(DEBUG_CAT_MLO, "wrong radio_mlo_cap", (unsigned char *)mlo_cap, sizeof(*mlo_cap));
	return -1;
}

void delete_eht_operations(struct eht_operations_db *db)
{
	int idx = 0;
	struct eht_operations_info_db *eht_op = NULL, *eht_op_tmp = NULL;

	for (idx = 0; idx < MAX_RADIO_NUM; idx++) {
		dl_list_for_each_safe(eht_op, eht_op_tmp, &db[idx].eht_op_list,
		    struct eht_operations_info_db, list) {
			dl_list_del(&eht_op->list);
			os_free(eht_op);
		}
		os_memset(db[idx].ruid, 0, sizeof(ETH_ALEN));
		dl_list_init(&db[idx].eht_op_list);
	}
}

void update_eht_operations(struct p1905_managerd_ctx *ctx, unsigned char *data)
{
	unsigned char idx = 0;
	unsigned char update_flag = 0;
	struct eht_operations_lib *eht_op = (struct eht_operations_lib *)data;
	struct eht_operations_db *config = NULL;
	struct eht_operations_info_db *record = NULL, *record_tmp = NULL;
	unsigned char zero_mac[ETH_ALEN] = {0};

	for (idx = 0; idx < MAX_RADIO_NUM; idx++) {
		config = &ctx->ap_cap_entry.eht_op[idx];

		if (os_memcmp(config->ruid, eht_op->ruid, ETH_ALEN) &&
			os_memcmp(config->ruid, zero_mac, ETH_ALEN))
			continue;

		os_memcpy(config->ruid, eht_op->ruid, ETH_ALEN);

		dl_list_for_each_safe(record, record_tmp, &config->eht_op_list,
			struct eht_operations_info_db, list) {

			if (os_memcmp(record->bssid, eht_op->bssid, ETH_ALEN) == 0) {
				update_flag = 1;
				goto update;
			}
		}

		record = os_zalloc(sizeof(struct eht_operations_info_db));
		if (!record) {
			err(DEBUG_CAT_MLO, "fail to malloc\n");
			return;
		}
		update_flag = 1;

		dl_list_add_tail(&config->eht_op_list, &record->list);
		goto update;
	}

update:
	if (update_flag) {
		os_memcpy(record->bssid, eht_op->bssid, ETH_ALEN);
		record->eht_operation_information_valid = eht_op->eht_operation_information_valid;
		record->eht_default_pe_duration = eht_op->eht_default_pe_duration;
		record->group_addressed_BU_indication_limit = eht_op->group_addressed_BU_indication_limit;
		record->group_addressed_BU_indication_exponent = eht_op->group_addressed_BU_indication_exponent;
		os_memcpy(&record->eht_mcs_nss_set, &eht_op->eht_mcs_nss_set, sizeof(struct eht_mcs_nss));
		record->control = eht_op->control;
		record->ccfs0 = eht_op->ccfs0;
		record->ccfs1 = eht_op->ccfs1;
		record->dscb_bitmap = eht_op->dscb_bitmap;
	}
}


void opbss_2_aff_ap_list(struct mlo_config_db *mlo_cfg, struct op_bss_db *opbss, unsigned char *ruid)
{
	struct affiliated_ap_db *aff_ap = NULL;

	aff_ap = (struct affiliated_ap_db *)os_zalloc(sizeof(struct affiliated_ap_db));
	if (!aff_ap) {
		err(DEBUG_CAT_MLO, "%d fail to alloc\n", __LINE__);
		return;
	}

	aff_ap->link_id = opbss->mlo_info.link_id;
	os_memcpy(aff_ap->affiliated_ap_bssid, opbss->bssid, ETH_ALEN);
	os_memcpy(aff_ap->ruid, ruid, ETH_ALEN);

	dl_list_add_tail(&mlo_cfg->aff_ap_list, &aff_ap->list);

	mlo_cfg->num_affiliated_ap += 1;

	info(DEBUG_CAT_MLO, "ruid "MACSTR", bssid "MACSTR", linkid %d\n",
		MAC2STR(aff_ap->ruid), MAC2STR(aff_ap->affiliated_ap_bssid), aff_ap->link_id);

	info_np(DEBUG_CAT_MLO, ", total cnt %d\n", mlo_cfg->num_affiliated_ap);
}

struct mlo_config_db *find_mlo_grp_by_opbss(struct mld_bss_config_db *mld_bss, struct op_bss_db *opbss)
{
	struct mlo_config_db *mlo_cfg = NULL;

	dl_list_for_each(mlo_cfg,
		&mld_bss->mlo_cfg_list, struct mlo_config_db, list) {
		if (!os_memcmp(opbss->mlo_info.mld_addr, mlo_cfg->mld_mac, ETH_ALEN)) {
			info(DEBUG_CAT_MLO, "found mlo grp, ssid %s, mld mac "MACSTR"\n",
				opbss->ssid, MAC2STR(opbss->mlo_info.mld_addr));
			os_memset(mlo_cfg->ssid, 0, sizeof(mlo_cfg->ssid));
			/* only ssid changed by user, should update ssid in db */
			os_strncpy((char *)mlo_cfg->ssid, (char *)opbss->ssid, sizeof(mlo_cfg->ssid));
			mlo_cfg->ssid[sizeof(mlo_cfg->ssid)-1] = '\0';

			return mlo_cfg;
		}
	}

	return NULL;
}


struct affiliated_ap_db *find_aff_ap_by_opbss(struct mld_bss_config_db *mld_bss, struct op_bss_db *opbss, unsigned char *ruid)
{
	struct mlo_config_db *mlo_cfg = NULL, *mlo_cfg_tmp = NULL;
	struct affiliated_ap_db *aff_ap = NULL, *aff_ap_tmp = NULL;

	dl_list_for_each_safe(mlo_cfg, mlo_cfg_tmp,
		&mld_bss->mlo_cfg_list, struct mlo_config_db, list) {
		if (os_strncmp((char *)opbss->ssid, mlo_cfg->ssid, mlo_cfg->ssid_len) ||
			(opbss->ssid_len != mlo_cfg->ssid_len))
			continue;

		dl_list_for_each_safe(aff_ap, aff_ap_tmp,
			&mlo_cfg->aff_ap_list, struct affiliated_ap_db, list) {
			if (os_memcmp(aff_ap->ruid, ruid, ETH_ALEN))
				continue;

			info(DEBUG_CAT_MLO, "found existed aff ap ruid "MACSTR", bssid "MACSTR" in grp mld mac "MACSTR"\n",
				MAC2STR(aff_ap->ruid), MAC2STR(aff_ap->affiliated_ap_bssid), MAC2STR(mlo_cfg->mld_mac));
			return aff_ap;
		}
	}

	return NULL;
}


struct affiliated_ap_db *new_aff_ap(unsigned char *ruid)
{
	struct affiliated_ap_db *aff_ap = NULL;

	aff_ap = (struct affiliated_ap_db *)os_zalloc(sizeof(struct affiliated_ap_db));
	if (!aff_ap) {
		err(DEBUG_CAT_MLO, "%d fail to alloc\n", __LINE__);
		return NULL;
	}

	os_memcpy(aff_ap->ruid, ruid, ETH_ALEN);
	/*aff_ap->link_id = r->mlo_info.link_id;*/


	info(DEBUG_CAT_MLO, "new affiliated ap ruid "MACSTR"\n", MAC2STR(aff_ap->ruid));

	return aff_ap;
}


void insert_aff_ap(struct mlo_config_db *mlo_cfg, struct affiliated_ap_db *aff_ap)
{
	dl_list_add_tail(&mlo_cfg->aff_ap_list, &aff_ap->list);

	mlo_cfg->num_affiliated_ap += 1;
	info(DEBUG_CAT_MLO, "ruid "MACSTR", affiliated ap total cnt %d\n",
		MAC2STR(aff_ap->ruid), mlo_cfg->num_affiliated_ap);

	return;
}


struct mlo_config_db *new_mld_grp_by_opbss(struct mld_bss_config_db *mld_bss, struct op_bss_db *opbss)
{
	struct mlo_config_db *mlo_cfg = NULL;

	if (is_zero_ether_addr(opbss->mlo_info.mld_addr)) {
		warn(DEBUG_CAT_MLO, "ap mld mac "MACSTR" invalid, not create new mld group\n",
			MAC2STR(opbss->mlo_info.mld_addr));
		return NULL;
	}

	mlo_cfg = (struct mlo_config_db *)os_zalloc(sizeof(struct mlo_config_db));
	if (!mlo_cfg) {
		err(DEBUG_CAT_MLO, "%d fail to alloc\n", __LINE__);
		return NULL;
	}


	os_memcpy(mlo_cfg->mld_mac, opbss->mlo_info.mld_addr, ETH_ALEN);

	mlo_cfg->ssid_len = opbss->ssid_len;
	os_memcpy(mlo_cfg->ssid, opbss->ssid, opbss->ssid_len);
	mlo_cfg->ssid[MAX_SSID_LEN - 1] = '\0';
	info(DEBUG_CAT_MLO, "ap mld mac "MACSTR", ssid %s\n",
		MAC2STR(mlo_cfg->mld_mac), mlo_cfg->ssid);
#ifdef MAP_R6
	mlo_cfg->ap_str_support = opbss->mlo_info.ap_str_support;
	mlo_cfg->ap_nstr_support = opbss->mlo_info.ap_nstr_support;
	mlo_cfg->ap_emlsr_support = opbss->mlo_info.ap_emlsr_support;
	mlo_cfg->ap_emlmr_support = opbss->mlo_info.ap_emlmr_support;
#endif
	/* how to set str, nstr, emlsr, emlmr flag for turnkey mode??? */

	mld_bss->num_ap_mld += 1;
	dl_list_init(&mlo_cfg->aff_ap_list);
	dl_list_init(&mlo_cfg->free_aff_ap_list);
	dl_list_add_tail(&mld_bss->mlo_cfg_list, &mlo_cfg->list);

	return mlo_cfg;
}



struct mlo_config_db *new_mld_grp_by_bss(struct mld_bss_config_db *mld_bss, struct set_config_bss_info *bss, unsigned char *ruid)
{
	struct mlo_config_db *mlo_cfg = NULL;
	unsigned char zero_mac[ETH_ALEN] = {0};

	mlo_cfg = (struct mlo_config_db *)os_zalloc(sizeof(struct mlo_config_db));
	if (!mlo_cfg) {
		err(DEBUG_CAT_MLO, "%d fail to alloc\n", __LINE__);
		return NULL;
	}

	if (os_memcmp(mlo_cfg->mld_mac, zero_mac, ETH_ALEN))
		mlo_cfg->mld_mac_valid = 1;
	mlo_cfg->mld_grp_id = bss->mlo_grp_id;
	/*os_memcpy(mlo_cfg->mld_mac, opbss->mlo_info.mld_addr, ETH_ALEN);*/

	mlo_cfg->ssid_len = bss->ssid_len;
	os_memcpy(mlo_cfg->ssid, bss->ssid, bss->ssid_len);
	mlo_cfg->ssid[MAX_SSID_LEN - 1] = '\0';
	info(DEBUG_CAT_MLO, "ap mld grp id %d, ssid %s\n", mlo_cfg->mld_grp_id, mlo_cfg->ssid);
	mld_bss->num_ap_mld += 1;

	dl_list_init(&mlo_cfg->aff_ap_list);
	dl_list_init(&mlo_cfg->free_aff_ap_list);
	dl_list_add_tail(&mld_bss->mlo_cfg_list, &mlo_cfg->list);

	return mlo_cfg;
}


struct mlo_config_db *find_existed_mlo_grp(struct mld_bss_config_db *mld_bss, struct set_config_bss_info *bss)
{
	struct mlo_config_db *mlo_cfg = NULL, *mlo_cfg_tmp = NULL;

	dl_list_for_each_safe(mlo_cfg, mlo_cfg_tmp,
		&mld_bss->mlo_cfg_list, struct mlo_config_db, list) {
		if (bss->mlo_grp_id == mlo_cfg->mld_grp_id) {
			info(DEBUG_CAT_MLO, "found mlo grp %d\n", mlo_cfg->mld_grp_id);
			return mlo_cfg;
		}
	}

	return NULL;
}

struct affiliated_ap_db *find_existed_aff_ap(struct mld_bss_config_db *mld_bss, struct set_config_bss_info *bss, unsigned char *ruid)
{
	struct mlo_config_db *mlo_cfg = NULL, *mlo_cfg_tmp = NULL;

	struct affiliated_ap_db *aff_ap = NULL, *aff_ap_tmp = NULL;

	dl_list_for_each_safe(mlo_cfg, mlo_cfg_tmp,
		&mld_bss->mlo_cfg_list, struct mlo_config_db, list) {
		if ((os_strncmp(bss->ssid, mlo_cfg->ssid, mlo_cfg->ssid_len) ||
			(bss->ssid_len != mlo_cfg->ssid_len)) &&
			(bss->mlo_grp_id != mlo_cfg->mld_grp_id))
			continue;

		dl_list_for_each_safe(aff_ap, aff_ap_tmp,
			&mlo_cfg->aff_ap_list, struct affiliated_ap_db, list) {
			if (os_memcmp(aff_ap->ruid, ruid, ETH_ALEN))
				continue;

			debug(DEBUG_CAT_MLO, "found existed aff ap ruid "MACSTR" in grp %d\n",
				MAC2STR(ruid), mlo_cfg->mld_grp_id);
			return aff_ap;
		}
	}

	return NULL;
}

void wts_2_mld(struct mld_bss_config_db *mld_bss, struct set_config_bss_info *bss, unsigned char *ruid)
{
	struct mlo_config_db *mlo_cfg = NULL;
	struct affiliated_ap_db *aff_ap = NULL;

	if (!bss->mlo_grp_id)
		return;

	/* mlo grp not present by bss->mlo_grp_id */
	mlo_cfg = find_existed_mlo_grp(mld_bss, bss);
	if (!mlo_cfg) {
		info(DEBUG_CAT_MLO, "not found mld grp by grp id %d\n", bss->mlo_grp_id);
		if (bss->mlo_grp_id) {
			mlo_cfg = new_mld_grp_by_bss(mld_bss, bss, ruid);
			if (!mlo_cfg)
				return;
		}
	}

	aff_ap = new_aff_ap(ruid);
	if (!aff_ap)
		return;

	insert_aff_ap(mlo_cfg, aff_ap);
}


void wts_2_mlo_cntrl(struct p1905_managerd_ctx *ctx, unsigned char *al_mac, struct radio_info *r)
{
	unsigned char bss_idx = 0;
	struct set_config_bss_info *bss = NULL;
	unsigned char band = 0;
	unsigned char wildcard_mac[ETH_ALEN] = {0xff, 0xff, 0xff, 0xff, 0xff, 0xff};

	band = determin_band_config(ctx, al_mac, r->band);
	if (band == BAND_INVALID_CAP)
		return;

	info(DEBUG_CAT_MLO, "band %s\n", band_2_string(band));

	for (bss_idx = 0; bss_idx < ctx->bss_config_num; bss_idx++) {
		bss = &ctx->bss_config[bss_idx];

		if (band != bss->band_support)
			continue;

		if (os_memcmp(bss->mac, wildcard_mac, ETH_ALEN) &&
			os_memcmp(bss->mac, al_mac, ETH_ALEN))
			continue;

		debug(DEBUG_CAT_MLO, "ruid "MACSTR",mlo enable %d\n", MAC2STR(r->identifier), r->mlo_cap);
		if (!r->mlo_cap)
			continue;

		info(DEBUG_CAT_MLO, "ssid %s, band %s, mld grp id %d\n",
			bss->ssid, band_2_string(bss->band_support), bss->mlo_grp_id);

		wts_2_mld(&ctx->wts_ctrl_mld_cfg, bss, r->identifier);
	}
}


void info_dump_agent_ap_mld(struct mld_bss_config_db *mld_bss)
{
	struct mlo_config_db *mlo_cfg = NULL;
	struct affiliated_ap_db *aff_ap = NULL;

	info(DEBUG_CAT_MLO, "\nalmac "MACSTR"", MAC2STR(mld_bss->al_mac));
	info_np(DEBUG_CAT_MLO, ", ap mld grp cnt %d\n", mld_bss->num_ap_mld);
	dl_list_for_each(mlo_cfg, &mld_bss->mlo_cfg_list, struct mlo_config_db, list) {
		info_np(DEBUG_CAT_MLO, "\tap mld grp id %d", mlo_cfg->mld_grp_id);
		info_np(DEBUG_CAT_MLO, ", ap mld mac "MACSTR"", MAC2STR(mlo_cfg->mld_mac));
		info_np(DEBUG_CAT_MLO, ", ap mld ssid %s", mlo_cfg->ssid);
		info_np(DEBUG_CAT_MLO, ", affiliated ap cnt %d\n", mlo_cfg->num_affiliated_ap);
		dl_list_for_each(aff_ap, &mlo_cfg->aff_ap_list, struct affiliated_ap_db, list) {
			info_np(DEBUG_CAT_MLO, "\t\truid "MACSTR"", MAC2STR(aff_ap->ruid));
			info_np(DEBUG_CAT_MLO, ", bssid "MACSTR"\n", MAC2STR(aff_ap->affiliated_ap_bssid));
		}
	}
}


void notice_dump_agent_ap_mld(struct mld_bss_config_db *mld_bss)
{
	struct mlo_config_db *mlo_cfg = NULL;
	struct affiliated_ap_db *aff_ap = NULL;

	if (is_zero_ether_addr(mld_bss->al_mac))
		notice(DEBUG_CAT_MLO, "\nap mld grp cnt %d\n", mld_bss->num_ap_mld);
	else
		notice(DEBUG_CAT_MLO, "\nalmac "MACSTR", ap mld grp cnt %d\n",
			MAC2STR(mld_bss->al_mac), mld_bss->num_ap_mld);

	dl_list_for_each(mlo_cfg, &mld_bss->mlo_cfg_list, struct mlo_config_db, list) {
		notice_np(DEBUG_CAT_MLO, "\tap mld grp id %d", mlo_cfg->mld_grp_id);
		notice_np(DEBUG_CAT_MLO, ", ap mld mac "MACSTR"", MAC2STR(mlo_cfg->mld_mac));
		notice_np(DEBUG_CAT_MLO, ", ap mld ssid %s", mlo_cfg->ssid);
		notice_np(DEBUG_CAT_MLO, ", affiliated ap cnt %d\n", mlo_cfg->num_affiliated_ap);
		dl_list_for_each(aff_ap, &mlo_cfg->aff_ap_list, struct affiliated_ap_db, list) {
			notice_np(DEBUG_CAT_MLO, "\t\truid "MACSTR"", MAC2STR(aff_ap->ruid));
			notice_np(DEBUG_CAT_MLO, ", bssid "MACSTR"\n", MAC2STR(aff_ap->affiliated_ap_bssid));
		}
	}
}

struct mld_bss_config_db *get_agent_ap_mld(struct p1905_managerd_ctx *ctx, unsigned char *al_mac)
{
	struct mld_bss_config_db *mld_bss = NULL;

	dl_list_for_each(mld_bss, &ctx->agent_ap_mld_list, struct mld_bss_config_db, list) {
		if (os_memcmp(mld_bss->al_mac, al_mac, ETH_ALEN))
			continue;
		return mld_bss;
	}

	return NULL;
}

void clear_agent_ap_mld(struct p1905_managerd_ctx *ctx, unsigned char *al_mac)
{
	struct mld_bss_config_db *mld_bss = NULL;

	mld_bss = get_agent_ap_mld(ctx, al_mac);

	if (mld_bss)
		delete_ap_mld_conf(mld_bss);
}

struct mld_bss_config_db *wts_2_agent_mld_list(struct p1905_managerd_ctx *ctx, unsigned char *al_mac)
{
	struct mld_bss_config_db *mld_bss = NULL;

	mld_bss = get_agent_ap_mld(ctx, al_mac);
	if (!mld_bss) {
		mld_bss = (struct mld_bss_config_db *)os_zalloc(sizeof(struct mld_bss_config_db));
		if (!mld_bss) {
			err(DEBUG_CAT_MLO, "fail to malloc buf for mld bss\n");
			return NULL;
		}

		dl_list_init(&mld_bss->mlo_cfg_list);
		dl_list_add_tail(&ctx->agent_ap_mld_list, &mld_bss->list);
	}

	os_memcpy(mld_bss->al_mac, al_mac, ETH_ALEN);
	info(DEBUG_CAT_MLO, "new ap mld for almac "MACSTR"\n", MAC2STR(mld_bss->al_mac));

	return mld_bss;
}








void opbss_2_mld(struct mld_bss_config_db *mld_bss, struct op_bss_db *opbss, unsigned char *ruid)
{
	struct mlo_config_db *mlo_cfg = NULL;
	struct affiliated_ap_db *aff_ap = NULL;

	mlo_cfg = find_mlo_grp_by_opbss(mld_bss, opbss);
	if (!mlo_cfg) {
		mlo_cfg = new_mld_grp_by_opbss(mld_bss, opbss);

		/* new affiliated ap */
		if (!mlo_cfg)
			return;
	} else {
		aff_ap = find_aff_ap_by_opbss(mld_bss, opbss, ruid);
		if (aff_ap)
			return;
	}

	opbss_2_aff_ap_list(mlo_cfg, opbss, ruid);
}

void wts_2_mlo_agent(struct p1905_managerd_ctx *ctx, unsigned char *al_mac)
{
	struct mld_bss_config_db *mld_bss = NULL;
	unsigned char bss_idx = 0;
	struct set_config_bss_info *bss = NULL;
	unsigned char r_idx = 0;
	struct agent_radio_info *r = NULL;
	unsigned char band = 0;
	struct agent_list_db *agent = NULL;
	unsigned char wildcard_mac[ETH_ALEN] = {0xff, 0xff, 0xff, 0xff, 0xff, 0xff};

	find_agent_info(ctx, al_mac, &agent);
	if (!agent)
		return;

	info(DEBUG_CAT_MLO, "almac "MACSTR", radio cnt %d\n", MAC2STR(al_mac), agent->radio_num);

	for (r_idx = 0; r_idx < agent->radio_num; r_idx++) {
		r = &agent->ra_info[r_idx];

		debug(DEBUG_CAT_MLO, "ruid "MACSTR", mlo enable %d\n", MAC2STR(r->identifier), agent->ap_mlo_cap[r_idx]);
		if (!agent->ap_mlo_cap[r_idx])
			continue;

		band = determin_band_config(ctx, al_mac, r->band);
		if (band == BAND_INVALID_CAP)
			continue;
		info(DEBUG_CAT_MLO, "radio idx %d band %s\n", r_idx+1, band_2_string(band));

		for (bss_idx = 0; bss_idx < ctx->bss_config_num; bss_idx++) {
			bss = &ctx->bss_config[bss_idx];

			if (band != bss->band_support)
				continue;

			if (os_memcmp(bss->mac, wildcard_mac, ETH_ALEN) &&
				os_memcmp(bss->mac, al_mac, ETH_ALEN))
				continue;

			info(DEBUG_CAT_MLO, "ssid %s, band %s, mld grp id %d\n",
				bss->ssid, band_2_string(bss->band_support), bss->mlo_grp_id);

			mld_bss = wts_2_agent_mld_list(ctx, al_mac);
			if (!mld_bss)
				goto fail;

			wts_2_mld(mld_bss, bss, r->identifier);

		}
	}

	info(DEBUG_CAT_MLO, "dump ap mld for almac "MACSTR"\n", MAC2STR(al_mac));
	if (mld_bss == NULL) {
		notice(DEBUG_CAT_MLO, "mld_bss is null; need check\n");
		goto fail;
	}
	info_dump_agent_ap_mld(mld_bss);
	if (dl_list_empty(&mld_bss->mlo_cfg_list))
		notice(DEBUG_CAT_MLO, RED("no mld group configured in wts file, please check!!!!\n"));

fail:
	return;
}


void trans_opbss_2_mlo(struct p1905_managerd_ctx *ctx, struct mld_bss_config_db *mld_bss, unsigned char *ruid)
{
	struct operational_bss_db *opcap = NULL;
	struct op_bss_db *opbss = NULL;

	if (SLIST_EMPTY(&(ctx->ap_cap_entry.oper_bss_head))) {
		notice(DEBUG_CAT_MLO, "oper bss head empty\n");
		return;
	}

	SLIST_FOREACH(opcap, &(ctx->ap_cap_entry.oper_bss_head), oper_bss_entry) {
		if (os_memcmp(ruid, opcap->identifier, ETH_ALEN))
			continue;
		opbss = SLIST_FIRST(&(opcap->op_bss_head));
		while (opbss) {
			opbss_2_mld(mld_bss, opbss, opcap->identifier);
			opbss = SLIST_NEXT(opbss, op_bss_entry);
		}
	}

	return;
}


void delete_ap_mld_conf(struct mld_bss_config_db *mld_bss)
{
	struct mlo_config_db *mlo_cfg = NULL, *mlo_cfg_tmp = NULL;
	struct affiliated_ap_db *aff_ap = NULL, *aff_ap_tmp = NULL;

	dl_list_for_each_safe(mlo_cfg, mlo_cfg_tmp, &mld_bss->mlo_cfg_list,
		struct mlo_config_db, list) {
		dl_list_for_each_safe(aff_ap, aff_ap_tmp, &mlo_cfg->aff_ap_list,
			struct affiliated_ap_db, list) {
			dl_list_del(&aff_ap->list);
			os_free(aff_ap);
		}

		dl_list_for_each_safe(aff_ap, aff_ap_tmp, &mlo_cfg->free_aff_ap_list,
			struct affiliated_ap_db, list) {
			dl_list_del(&aff_ap->list);
			os_free(aff_ap);
		}

		dl_list_del(&mlo_cfg->list);
		os_free(mlo_cfg);
	}

	dl_list_init(&mld_bss->mlo_cfg_list);
	mld_bss->num_ap_mld = 0;
}



void update_ap_mld_conf(struct mld_bss_config_db *mlo_bss, struct mld_bss_config_db *mlo_bss_new)
{
	struct mlo_config_db *mlo_cfg = NULL, *mlo_cfg_tmp = NULL;

	dl_list_init(&mlo_bss->mlo_cfg_list);
	mlo_bss->num_ap_mld = mlo_bss_new->num_ap_mld;
	os_memcpy(mlo_bss->al_mac, mlo_bss_new->al_mac, ETH_ALEN);

	dl_list_for_each_safe(mlo_cfg, mlo_cfg_tmp, &mlo_bss_new->mlo_cfg_list,
		struct mlo_config_db, list) {
		dl_list_del(&mlo_cfg->list);
		dl_list_add_tail(&mlo_bss->mlo_cfg_list, &mlo_cfg->list);
	}
}


void update_agt_ap_mld_info(struct mld_bss_config_db *mlo_bss, struct mld_bss_config_db *mlo_bss_new)
{
	struct mlo_config_db *mlo_cfg = NULL, *mlo_cfg_new = NULL;
	struct affiliated_ap_db *aff_ap = NULL, *aff_ap_new = NULL;

	dl_list_for_each(mlo_cfg, &mlo_bss->mlo_cfg_list,
		struct mlo_config_db, list) {
		debug(DEBUG_CAT_MLO, "db mlo grp id %d, ssid %s\n",
			mlo_cfg->mld_grp_id, mlo_cfg->ssid);
		dl_list_for_each(mlo_cfg_new, &mlo_bss_new->mlo_cfg_list,
			struct mlo_config_db, list) {
			debug_np(DEBUG_CAT_MLO, "\tagt ssid %s", mlo_cfg_new->ssid);
			if (os_strncmp(mlo_cfg->ssid, mlo_cfg_new->ssid, mlo_cfg->ssid_len) ||
				(mlo_cfg_new->ssid_len != mlo_cfg->ssid_len))
				continue;

			os_memcpy(mlo_cfg->mld_mac, mlo_cfg_new->mld_mac, ETH_ALEN);
			if (!is_zero_ether_addr(mlo_cfg->mld_mac))
				mlo_cfg->mld_mac_valid = 1;
			else
				mlo_cfg->mld_mac_valid = 0;
			debug_np(DEBUG_CAT_MLO, ", update db mld_mac "MACSTR"\n", MAC2STR(mlo_cfg->mld_mac));

			dl_list_for_each(aff_ap, &mlo_cfg->aff_ap_list,
				struct affiliated_ap_db, list) {
				debug_np(DEBUG_CAT_MLO, "db ruid "MACSTR"\n", MAC2STR(aff_ap->ruid));
				dl_list_for_each(aff_ap_new, &mlo_cfg_new->aff_ap_list,
					struct affiliated_ap_db, list) {
					debug_np(DEBUG_CAT_MLO, "\tagt ruid "MACSTR"", MAC2STR(aff_ap_new->ruid));
					if (os_memcmp(aff_ap->ruid, aff_ap_new->ruid, ETH_ALEN))
						continue;

					os_memcpy(aff_ap->affiliated_ap_bssid, aff_ap_new->affiliated_ap_bssid, ETH_ALEN);
					if (!is_zero_ether_addr(aff_ap->affiliated_ap_bssid))
						aff_ap->affiliated_ap_valid = 1;
					else
						aff_ap->affiliated_ap_valid = 0;
					debug_np(DEBUG_CAT_MLO, ", update db affiliated_ap_bssid "MACSTR"\n",
						MAC2STR(aff_ap->affiliated_ap_bssid));
					break;
				}
			}
			break;
		}
	}
}

void delete_agent_ap_mld_list(struct dl_list *head)
{
	struct mld_bss_config_db *mld_bss = NULL, *mld_bss_tmp = NULL;

	dl_list_for_each_safe(mld_bss, mld_bss_tmp, head, struct mld_bss_config_db, list) {
		delete_ap_mld_conf(mld_bss);

		dl_list_del(&mld_bss->list);
		os_free(mld_bss);
	}
}


int cmd_show_map_r6_support(struct p1905_managerd_ctx *ctx, char *buf, int len)
{
	int r6_support = MAP_R6_NOT_SUPPORT;
	int ret = 0;

	if (!SLIST_EMPTY(&ctx->ap_cap_entry.ap_mlo_cap_head))
		r6_support = MAP_PRE_R6_SUPPORT;
#ifdef MAP_R6
	if (!dl_list_empty(&ctx->ap_cap_entry.wifi7_mlo_cap_list))
		r6_support = MAP_R6_SUPPORT;
#endif

	if (r6_support == MAP_R6_SUPPORT)
		ret = os_snprintf(buf, len, "MAP_R6_SUPPORT\n");
	else if (r6_support == MAP_PRE_R6_SUPPORT)
		ret = os_snprintf(buf, len, "MAP_PRE_R6_SUPPORT\n");
	else
		ret = os_snprintf(buf, len, "MAP_R6_NOT_SUPPORT\n");
	if (os_snprintf_error(len, ret)) {
		err(DEBUG_CAT_DPP, "snprintf error\n");
		return -1;
	}

	return ret;
}


#if defined(MAP_R6) || defined(EM_PLUS_SUPPORT)
void delete_exist_wifi7_mlo_cap(struct dl_list *mlo_list)
{
	struct wifi7_mlo_cap_db *cap = NULL, *cap_tmp = NULL;
	struct mlo_record_db *record = NULL, *record_tmp = NULL;

	dl_list_for_each_safe(cap, cap_tmp, mlo_list,
		struct wifi7_mlo_cap_db, list) {
		dl_list_for_each_safe(record, record_tmp, &cap->ap_str_record_list,
			struct mlo_record_db, list) {
			debug(DEBUG_CAT_MLO, "delete ap snr record ["MACSTR"]\n", MAC2STR(record->identifier));
			dl_list_del(&record->list);
			os_free(record);
		}
		cap->num_ap_str_records = 0;

		dl_list_for_each_safe(record, record_tmp, &cap->ap_nstr_record_list,
			struct mlo_record_db, list) {
			debug(DEBUG_CAT_MLO, "delete ap nsnr record ["MACSTR"]\n", MAC2STR(record->identifier));
			dl_list_del(&record->list);
			os_free(record);
		}
		cap->num_ap_nstr_records = 0;

		dl_list_for_each_safe(record, record_tmp, &cap->ap_emlsr_record_list,
			struct mlo_record_db, list) {
			debug(DEBUG_CAT_MLO, "delete ap emlsr record ["MACSTR"]\n", MAC2STR(record->identifier));
			dl_list_del(&record->list);
			os_free(record);
		}
		cap->num_ap_emlsr_records = 0;

		dl_list_for_each_safe(record, record_tmp, &cap->ap_emlmr_record_list,
			struct mlo_record_db, list) {
			debug(DEBUG_CAT_MLO, "delete ap emlmr record ["MACSTR"]\n", MAC2STR(record->identifier));
			dl_list_del(&record->list);
			os_free(record);
		}
		cap->num_ap_emlmr_records = 0;

		dl_list_for_each_safe(record, record_tmp, &cap->sta_str_record_list,
			struct mlo_record_db, list) {
			debug(DEBUG_CAT_MLO, "delete sta snr record ["MACSTR"]\n", MAC2STR(record->identifier));
			dl_list_del(&record->list);
			os_free(record);
		}
		cap->num_sta_str_records = 0;

		dl_list_for_each_safe(record, record_tmp, &cap->sta_nstr_record_list,
			struct mlo_record_db, list) {
			debug(DEBUG_CAT_MLO, "delete sta nsnr record ["MACSTR"]\n", MAC2STR(record->identifier));
			dl_list_del(&record->list);
			os_free(record);
		}
		cap->num_sta_nstr_records = 0;

		dl_list_for_each_safe(record, record_tmp, &cap->sta_emlsr_record_list,
			struct mlo_record_db, list) {
			debug(DEBUG_CAT_MLO, "delete sta emlsr record ["MACSTR"]\n", MAC2STR(record->identifier));
			dl_list_del(&record->list);
			os_free(record);
		}
		cap->num_sta_emlsr_records = 0;

		dl_list_for_each_safe(record, record_tmp, &cap->sta_emlmr_record_list,
			struct mlo_record_db, list) {
			debug(DEBUG_CAT_MLO, "delete sta emlmr record ["MACSTR"]\n", MAC2STR(record->identifier));
			dl_list_del(&record->list);
			os_free(record);
		}
		cap->num_sta_emlmr_records = 0;

		debug(DEBUG_CAT_MLO, "delete mlo for radio ["MACSTR"]\n", MAC2STR(cap->identifier));
		dl_list_del(&cap->list);
		os_free(cap);
	}
}

void delete_wifi7_mld_cap_by_ruid(struct p1905_managerd_ctx *ctx, unsigned char *ruid)
{
	struct wifi7_mlo_cap_db *cap = NULL, *cap_tmp = NULL;
	struct mlo_record_db *record = NULL, *record_tmp = NULL;

	dl_list_for_each_safe(cap, cap_tmp, &ctx->ap_cap_entry.wifi7_mlo_cap_list,
		struct wifi7_mlo_cap_db, list) {
		if (os_memcmp(ruid, cap->identifier, ETH_ALEN))
			continue;

		dl_list_for_each_safe(record, record_tmp, &cap->ap_str_record_list,
			struct mlo_record_db, list) {
			dl_list_del(&record->list);
			os_free(record);
		}
		cap->num_ap_str_records = 0;

		dl_list_for_each_safe(record, record_tmp, &cap->ap_nstr_record_list,
			struct mlo_record_db, list) {
			dl_list_del(&record->list);
			os_free(record);
		}
		cap->num_ap_nstr_records = 0;

		dl_list_for_each_safe(record, record_tmp, &cap->ap_emlsr_record_list,
			struct mlo_record_db, list) {
			dl_list_del(&record->list);
			os_free(record);
		}
		cap->num_ap_emlsr_records = 0;

		dl_list_for_each_safe(record, record_tmp, &cap->ap_emlmr_record_list,
			struct mlo_record_db, list) {
			dl_list_del(&record->list);
			os_free(record);
		}
		cap->num_ap_emlmr_records = 0;

		dl_list_for_each_safe(record, record_tmp, &cap->sta_str_record_list,
			struct mlo_record_db, list) {
			dl_list_del(&record->list);
			os_free(record);
		}
		cap->num_sta_str_records = 0;

		dl_list_for_each_safe(record, record_tmp, &cap->sta_nstr_record_list,
			struct mlo_record_db, list) {
			dl_list_del(&record->list);
			os_free(record);
		}
		cap->num_sta_nstr_records = 0;

		dl_list_for_each_safe(record, record_tmp, &cap->sta_emlsr_record_list,
			struct mlo_record_db, list) {
			dl_list_del(&record->list);
			os_free(record);
		}
		cap->num_sta_emlsr_records = 0;

		dl_list_for_each_safe(record, record_tmp, &cap->sta_emlmr_record_list,
			struct mlo_record_db, list) {
			dl_list_del(&record->list);
			os_free(record);
		}
		cap->num_sta_emlmr_records = 0;
		dl_list_del(&cap->list);
		os_free(cap);
	}
}

int update_wifi7_mlo_cap(struct p1905_managerd_ctx *ctx, struct wifi7_ap_mlo_cap_lib *mlo_cap)
{
	struct wifi7_mlo_cap_db *cap = NULL;
	struct mlo_record_db *record = NULL;
	struct mlo_record *record_ptr = NULL;
	int i = 0;

	cap = os_zalloc(sizeof(struct wifi7_mlo_cap_db));
	if (!cap) {
		err(DEBUG_CAT_MLO, "malloc error for wifi7 mlo cap\n");
		goto err;
	}
	dl_list_add(&ctx->ap_cap_entry.wifi7_mlo_cap_list, &cap->list);
	dl_list_init(&cap->ap_str_record_list);
	dl_list_init(&cap->ap_nstr_record_list);
	dl_list_init(&cap->ap_emlsr_record_list);
	dl_list_init(&cap->ap_emlmr_record_list);
	dl_list_init(&cap->sta_str_record_list);
	dl_list_init(&cap->sta_nstr_record_list);
	dl_list_init(&cap->sta_emlsr_record_list);
	dl_list_init(&cap->sta_emlmr_record_list);

	os_memcpy(cap->identifier, mlo_cap->identifier, ETH_ALEN);
	cap->max_num_mld = mlo_cap->mlo_cap.max_num_mld;
	cap->ap_max_link = mlo_cap->mlo_cap.ap_max_link;
	cap->bsta_max_link = mlo_cap->mlo_cap.bsta_max_link;
	cap->tid_to_link_map = mlo_cap->mlo_cap.tid_to_link_map;
	cap->legacy = mlo_cap->mlo_cap.legacy;
	cap->ap_str_support = mlo_cap->mlo_cap.ap_str_support;

	cap->ap_nstr_support = mlo_cap->mlo_cap.ap_nstr_support;
	cap->ap_emlsr_support = mlo_cap->mlo_cap.ap_emlsr_support;
	cap->ap_emlmr_support = mlo_cap->mlo_cap.ap_emlmr_support;
	cap->sta_str_support = mlo_cap->mlo_cap.sta_str_support;
	cap->sta_nstr_support = mlo_cap->mlo_cap.sta_nstr_support;
	cap->sta_emlsr_support = mlo_cap->mlo_cap.sta_emlsr_support;
	cap->sta_emlmr_support = mlo_cap->mlo_cap.sta_emlmr_support;
	cap->num_ap_str_records = mlo_cap->mlo_cap.num_ap_str_records;
	cap->num_ap_nstr_records = mlo_cap->mlo_cap.num_ap_nstr_records;
	cap->num_ap_emlsr_records = mlo_cap->mlo_cap.num_ap_emlsr_records;
	cap->num_ap_emlmr_records = mlo_cap->mlo_cap.num_ap_emlmr_records;
	cap->num_sta_str_records = mlo_cap->mlo_cap.num_sta_str_records;
	cap->num_sta_nstr_records = mlo_cap->mlo_cap.num_sta_nstr_records;
	cap->num_sta_emlsr_records = mlo_cap->mlo_cap.num_sta_emlsr_records;
	cap->num_sta_emlmr_records = mlo_cap->mlo_cap.num_sta_emlmr_records;
	cap->total_ap_sta_records = mlo_cap->mlo_cap.total_ap_sta_records;

	debug(DEBUG_CAT_MLO, "\n\tap_max_link %d, bsta_max_link %d\n",
		cap->ap_max_link, cap->bsta_max_link);
	debug_np(DEBUG_CAT_MLO, "\tap_str_support %d, ap_emlmr_support %d, ap_emlsr_support %d\n",
		mlo_cap->mlo_cap.ap_str_support, mlo_cap->mlo_cap.ap_emlmr_support,
		mlo_cap->mlo_cap.ap_emlsr_support);
	for (i = 0; i < ctx->radio_number; i++) {
		if (!os_memcmp(ctx->rinfo[i].identifier, mlo_cap->identifier, ETH_ALEN)) {
			ctx->rinfo[i].mlo_cap = 0;
			debug(DEBUG_CAT_MLO, "clear mlo enable for identifier "MACSTR"\n", MAC2STR(mlo_cap->identifier));
			if (cap->ap_str_support || cap->ap_nstr_support ||
				cap->ap_emlsr_support || cap->ap_emlmr_support) {
				ctx->rinfo[i].mlo_cap = 1;
				debug(DEBUG_CAT_MLO, "set mlo enable 1 for identifier "MACSTR"\n", MAC2STR(mlo_cap->identifier));
			}
		}
	}


	record_ptr = (struct mlo_record *)((unsigned char *)mlo_cap + sizeof(struct wifi7_ap_mlo_cap_lib));

	debug(DEBUG_CAT_MLO, "before ap str records %d\n", mlo_cap->mlo_cap.num_ap_str_records);

	for (i = 0; i < mlo_cap->mlo_cap.num_ap_str_records; i++) {
		if (is_zero_ether_addr(record_ptr->identifier)) {
			cap->num_ap_str_records--;
			record_ptr += 1;
			continue;
		}

		record = os_zalloc(sizeof(struct mlo_record_db));
		if (!record) {
			warn(DEBUG_CAT_MLO, "malloc error for ap_str_record\n");
			goto err;
		}

		os_memcpy(record->identifier, record_ptr->identifier, ETH_ALEN);
		record->freq_separation = record_ptr->freq_separation;

		dl_list_add(&cap->ap_str_record_list, &record->list);

		debug_np(DEBUG_CAT_MLO, " ["MACSTR"]\n", MAC2STR(record->identifier));
		record_ptr += 1;
	}


	for (i = 0; i < mlo_cap->mlo_cap.num_ap_nstr_records; i++) {
		record = os_zalloc(sizeof(struct mlo_record_db));
		if (!record) {
			warn(DEBUG_CAT_MLO, "malloc error for ap_nstr_record\n");
			goto err;
		}

		os_memcpy(record->identifier, record_ptr->identifier, ETH_ALEN);
		record->freq_separation = record_ptr->freq_separation;

		dl_list_add(&cap->ap_nstr_record_list, &record->list);

		record_ptr += 1;
	}

	debug(DEBUG_CAT_MLO, "before num_ap_emlsr_records %d\n", mlo_cap->mlo_cap.num_ap_emlsr_records);

	for (i = 0; i < mlo_cap->mlo_cap.num_ap_emlsr_records; i++) {
		if (is_zero_ether_addr(record_ptr->identifier)) {
			cap->num_ap_emlsr_records--;
			record_ptr += 1;
			continue;
		}

		record = os_zalloc(sizeof(struct mlo_record_db));
		if (!record) {
			warn(DEBUG_CAT_MLO, "malloc error for ap_emlsr_record\n");
			goto err;
		}

		os_memcpy(record->identifier, record_ptr->identifier, ETH_ALEN);
		record->freq_separation = record_ptr->freq_separation;

		dl_list_add(&cap->ap_emlsr_record_list, &record->list);
		notice(DEBUG_CAT_MLO, " ["MACSTR"]\n", MAC2STR(record->identifier));
		record_ptr += 1;
	}

	for (i = 0; i < mlo_cap->mlo_cap.num_ap_emlmr_records; i++) {
		record = os_zalloc(sizeof(struct mlo_record_db));
		if (!record) {
			warn(DEBUG_CAT_MLO, "malloc error for ap_emlmr_record\n");
			goto err;
		}

		os_memcpy(record->identifier, record_ptr->identifier, ETH_ALEN);
		record->freq_separation = record_ptr->freq_separation;

		dl_list_add(&cap->ap_emlmr_record_list, &record->list);

		record_ptr += 1;
	}

	debug(DEBUG_CAT_MLO, "before num_sta_str_records %d\n", mlo_cap->mlo_cap.num_sta_str_records);

	for (i = 0; i < mlo_cap->mlo_cap.num_sta_str_records; i++) {
		if (is_zero_ether_addr(record_ptr->identifier)) {
			cap->num_sta_str_records--;
			record_ptr += 1;
			continue;
		}

		record = os_zalloc(sizeof(struct mlo_record_db));
		if (!record) {
			warn(DEBUG_CAT_MLO, "malloc error for sta_str_record\n");
			goto err;
		}

		os_memcpy(record->identifier, record_ptr->identifier, ETH_ALEN);
		record->freq_separation = record_ptr->freq_separation;

		dl_list_add(&cap->sta_str_record_list, &record->list);
		notice(DEBUG_CAT_MLO, " ["MACSTR"]\n", MAC2STR(record->identifier));
		record_ptr += 1;
	}


	for (i = 0; i < mlo_cap->mlo_cap.num_sta_nstr_records; i++) {
		record = os_zalloc(sizeof(struct mlo_record_db));
		if (!record) {
			warn(DEBUG_CAT_MLO, "malloc error for sta_nstr_record\n");
			goto err;
		}

		os_memcpy(record->identifier, record_ptr->identifier, ETH_ALEN);
		record->freq_separation = record_ptr->freq_separation;

		dl_list_add(&cap->sta_nstr_record_list, &record->list);

		record_ptr += 1;
	}

	debug(DEBUG_CAT_MLO, "before num_sta_emlsr_records %d\n", mlo_cap->mlo_cap.num_sta_emlsr_records);
	for (i = 0; i < mlo_cap->mlo_cap.num_sta_emlsr_records; i++) {
		if (is_zero_ether_addr(record_ptr->identifier)) {
			cap->num_sta_emlsr_records--;
			record_ptr += 1;
			continue;
		}

		record = os_zalloc(sizeof(struct mlo_record_db));
		if (!record) {
			warn(DEBUG_CAT_MLO, "malloc error for sta_emlsr_record\n");
			goto err;
		}

		os_memcpy(record->identifier, record_ptr->identifier, ETH_ALEN);
		record->freq_separation = record_ptr->freq_separation;

		dl_list_add(&cap->sta_emlsr_record_list, &record->list);

		record_ptr += 1;
	}

	for (i = 0; i < mlo_cap->mlo_cap.num_sta_emlmr_records; i++) {
		record = os_zalloc(sizeof(struct mlo_record_db));
		if (!record) {
			warn(DEBUG_CAT_MLO, "malloc error for ap_emlmr_record\n");
			goto err;
		}

		os_memcpy(record->identifier, record_ptr->identifier, ETH_ALEN);
		record->freq_separation = record_ptr->freq_separation;

		dl_list_add(&cap->sta_emlmr_record_list, &record->list);

		record_ptr += 1;
	}

	return 0;

err:
	/*
	 * don't need free all alloced record
	 * delete_exist_wifi7_mlo_cap(ctx, mlo_cap->identifier);
	*/
	return -1;
}

void update_agent_wifi7_mlo_cap(struct agent_list_db *agent_info, struct dl_list *wifi7_mlo_cap_list)
{
	struct wifi7_mlo_cap_db *mlo_cap = NULL, *mlo_cap_tmp = NULL;
	unsigned char ra_idx = 0;

	os_memset(&agent_info->wifi7_mlo_cap, 0, sizeof(struct wifi7_mlo_cap_db));

	dl_list_for_each_safe(mlo_cap, mlo_cap_tmp, wifi7_mlo_cap_list,
		struct wifi7_mlo_cap_db, list) {
		debug(DEBUG_CAT_MLO, "mlo ruid "MACSTR"\n", MAC2STR(mlo_cap->identifier));
		for (ra_idx = 0; ra_idx < MAX_RADIO_NUM; ra_idx++) {
			debug(DEBUG_CAT_MLO, "agt info ruid "MACSTR"\n", MAC2STR(agent_info->ra_info[ra_idx].identifier));
			if (os_memcmp(mlo_cap->identifier, agent_info->ra_info[ra_idx].identifier, ETH_ALEN))
				continue;

			if (mlo_cap->ap_str_support || mlo_cap->ap_nstr_support ||
				mlo_cap->ap_emlsr_support || mlo_cap->ap_emlmr_support)
				agent_info->ap_mlo_cap[ra_idx] = 1;

			if (mlo_cap->sta_str_support || mlo_cap->sta_nstr_support ||
				mlo_cap->ap_emlsr_support || mlo_cap->sta_emlmr_support)
				agent_info->sta_mlo_cap[ra_idx] = 1;

			if (!agent_info->wifi7_mlo_cap.ap_max_link) {
				os_memcpy(&agent_info->wifi7_mlo_cap, mlo_cap, sizeof(struct wifi7_mlo_cap_db));
				info(DEBUG_CAT_MLO, "wifi7 ap_max_link %d\n", agent_info->wifi7_mlo_cap.ap_max_link);
			}

			info(DEBUG_CAT_MLO, "ruid "MACSTR", ap mlo %d(%s), sta mlo %d(%s)\n",
				 MAC2STR(mlo_cap->identifier),
				agent_info->ap_mlo_cap[ra_idx], (agent_info->ap_mlo_cap[ra_idx] == 1) ? "enable" : "disable",
				agent_info->sta_mlo_cap[ra_idx], (agent_info->sta_mlo_cap[ra_idx] == 1) ? "enable" : "disable");
		}
	}
}

#endif

#ifdef MAP_R6
void update_affilliated_sta_mac(struct mld_bsta_config_db *bsta_mld, struct mld_bsta_config_db *bsta_mld_new)
{
	struct affiliated_sta_db *aff_sta = NULL, *aff_sta_tmp = NULL;
	struct affiliated_sta_db *aff_sta_new = NULL, *aff_sta_new_tmp = NULL;

	dl_list_for_each_safe(aff_sta, aff_sta_tmp, &bsta_mld->affiliated_sta_list,
		struct affiliated_sta_db, list) {
		debug(DEBUG_CAT_MLO, "wts bsta mlo ruid "MACSTR"\n", MAC2STR(aff_sta->ruid));
		dl_list_for_each_safe(aff_sta_new, aff_sta_new_tmp, &bsta_mld_new->affiliated_sta_list,
		struct affiliated_sta_db, list) {
			debug(DEBUG_CAT_MLO, "bsta ruid["MACSTR"] from agent info\n", MAC2STR(aff_sta_new->ruid));
			if (os_memcmp(aff_sta->ruid, aff_sta_new->ruid, ETH_ALEN))
				continue;

			os_memcpy(aff_sta->affiliated_sta_bssid, aff_sta_new->affiliated_sta_bssid, ETH_ALEN);
			debug(DEBUG_CAT_MLO, "update aff sta mac["MACSTR"]\n", MAC2STR(aff_sta->affiliated_sta_bssid));
		}
	}
}

void update_affilliated_sta_ruid(struct mld_bsta_config_db *bsta_mld, struct agent_list_db *agent)
{
	struct affiliated_sta_db *aff_sta = NULL, *aff_sta_tmp = NULL;
	unsigned char r_idx = 0;
	unsigned char zero_mac[ETH_ALEN] = {0};

	debug(DEBUG_CAT_MLO, "\n");

	dl_list_for_each_safe(aff_sta, aff_sta_tmp, &bsta_mld->affiliated_sta_list,
		struct affiliated_sta_db, list) {
		if (aff_sta->band == BAND_INVALID_CAP)
			continue;
		debug(DEBUG_CAT_MLO, "aff_sta band %s\n", band_2_string(aff_sta->band));
		for (r_idx = 0; r_idx < MAX_RADIO_NUM; r_idx++) {
			debug(DEBUG_CAT_MLO, "radio idx %d band %s\n", r_idx, band_2_string(agent->ra_info[r_idx].band));
			if ((aff_sta->band == agent->ra_info[r_idx].band ||
				agent->ra_info[r_idx].band & aff_sta->band) &&
				os_memcmp(zero_mac, agent->ra_info[r_idx].identifier, ETH_ALEN)) {
				os_memcpy(aff_sta->ruid, agent->ra_info[r_idx].identifier, ETH_ALEN);
				debug(DEBUG_CAT_MLO, "update band %s ruid "MACSTR"\n",
				band_2_string(agent->ra_info[r_idx].band), MAC2STR(agent->ra_info[r_idx].identifier));
			}
		}
	}
}



void delete_agent_bsta_cfg(struct dl_list *bsta_list)
{
	struct mld_bsta_config_db *sta_db = NULL, *sta_db_tmp = NULL;
	struct affiliated_sta_db *aff_sta = NULL, *aff_sta_tmp = NULL;

	dl_list_for_each_safe(sta_db, sta_db_tmp, bsta_list, struct mld_bsta_config_db, list) {
		dl_list_for_each_safe(aff_sta, aff_sta_tmp, &sta_db->affiliated_sta_list,
			struct affiliated_sta_db, list) {
			dl_list_del(&aff_sta->list);
			os_free(aff_sta);
		}
		dl_list_del(&sta_db->list);
		os_free(sta_db);
	}
}


void delete_bsta_mld_conf(struct mld_bsta_config_db *bsta_mld)
{
	struct affiliated_sta_db *aff_sta = NULL, *aff_sta_tmp = NULL;

	dl_list_for_each_safe(aff_sta, aff_sta_tmp, &bsta_mld->affiliated_sta_list,
		struct affiliated_sta_db, list) {
		dl_list_del(&aff_sta->list);
		os_free(aff_sta);
	}

	bsta_mld->mld_mac_bitmap = 0;
	bsta_mld->switch_bitmap = 0;
	bsta_mld->num_affiliated_sta = 0;
	os_memset(bsta_mld->mld_mac, 0, ETH_ALEN);
	os_memset(bsta_mld->bss_mld_mac, 0, ETH_ALEN);
	dl_list_init(&bsta_mld->affiliated_sta_list);
}

void update_bsta_mld_conf(struct mld_bsta_config_db *bsta_mlo, struct mld_bsta_config_db *bsta_mlo_new)
{
	struct affiliated_sta_db *aff_sta = NULL, *aff_sta_tmp = NULL;

	dl_list_init(&bsta_mlo->affiliated_sta_list);
	bsta_mlo->mld_mac_bitmap = bsta_mlo_new->mld_mac_bitmap;
	bsta_mlo->switch_bitmap = bsta_mlo_new->switch_bitmap;
	bsta_mlo->num_affiliated_sta = bsta_mlo_new->num_affiliated_sta;
	os_memcpy(bsta_mlo->mld_mac, bsta_mlo_new->mld_mac, ETH_ALEN);
	os_memcpy(bsta_mlo->bss_mld_mac, bsta_mlo_new->bss_mld_mac, ETH_ALEN);

	dl_list_for_each_safe(aff_sta, aff_sta_tmp, &bsta_mlo_new->affiliated_sta_list,
		struct affiliated_sta_db, list) {

		dl_list_del(&aff_sta->list);
		dl_list_add_tail(&bsta_mlo->affiliated_sta_list, &aff_sta->list);
		debug(DEBUG_CAT_MLO, "ruid "MACSTR"\n", MAC2STR(aff_sta->ruid));
	}
}

void update_akm_capability(struct p1905_managerd_ctx *ctx, unsigned char *data)
{
	unsigned char idx = 0;
	struct akm_suite_cap_lib *akm_cap = (struct akm_suite_cap_lib *)data;

	debug(DEBUG_CAT_MLO, "bh akm count %d\n", akm_cap->num_bh_suite);
	debug(DEBUG_CAT_MLO, "fh akm count %d\n", akm_cap->num_fh_suite);

	if (!akm_cap->num_bh_suite || !akm_cap->num_fh_suite) {
		notice(DEBUG_CAT_MLO, "akm count invalid, skip\n");
		return;
	}

	ctx->bh_akm.akm_suite_cnt = akm_cap->num_bh_suite;
	if (ctx->bh_akm.akm_suite_info) {
		os_free(ctx->bh_akm.akm_suite_info);
		ctx->bh_akm.akm_suite_info = NULL;
	}
	ctx->bh_akm.akm_suite_info = (struct akm_suit *)os_malloc(akm_cap->num_bh_suite * sizeof(struct akm_suit));
	if (!ctx->bh_akm.akm_suite_info) {
		err(DEBUG_CAT_MLO, "fail to malloc akm\n");
		goto fail;
	}

	for (idx = 0; idx < akm_cap->num_bh_suite; idx++) {
		os_memcpy(&ctx->bh_akm.akm_suite_info[idx], &akm_cap->akm[idx], sizeof(struct akm_suit));
		debug(DEBUG_CAT_MLO, "bh akm oui [%02x%02x%02x] type %02x\n",
			ctx->bh_akm.akm_suite_info[idx].oui[0], ctx->bh_akm.akm_suite_info[idx].oui[1],
			ctx->bh_akm.akm_suite_info[idx].oui[2], ctx->bh_akm.akm_suite_info[idx].akm_suit_type);
	}

	ctx->fh_akm.akm_suite_cnt = akm_cap->num_fh_suite;
	ctx->fh_akm.akm_suite_info = (struct akm_suit *)os_malloc(akm_cap->num_fh_suite * sizeof(struct akm_suit));
	if (!ctx->fh_akm.akm_suite_info)
		goto fail;

	for (idx = 0; idx < akm_cap->num_fh_suite; idx++) {
		os_memcpy(&ctx->fh_akm.akm_suite_info[idx], &akm_cap->akm[akm_cap->num_bh_suite+idx], sizeof(struct akm_suit));
		debug(DEBUG_CAT_MLO, "fh akm oui [%02x%02x%02x] type %02x\n",
			ctx->fh_akm.akm_suite_info[idx].oui[0], ctx->fh_akm.akm_suite_info[idx].oui[1],
			ctx->fh_akm.akm_suite_info[idx].oui[2], ctx->fh_akm.akm_suite_info[idx].akm_suit_type);
	}

	return;
fail:
	if (ctx->bh_akm.akm_suite_info) {
		os_free(ctx->bh_akm.akm_suite_info);
		ctx->bh_akm.akm_suite_info = NULL;
	}
	if (ctx->fh_akm.akm_suite_info) {
		os_free(ctx->fh_akm.akm_suite_info);
		ctx->fh_akm.akm_suite_info = NULL;
	}
}

void delete_sta_mld_cfg_rpt(struct mlo_sta_config_db *sta_mld, unsigned char *sta_mld_mac)
{
	struct mlo_sta_db *aff_sta = NULL, *aff_sta_tmp = NULL;

	dl_list_for_each_safe(aff_sta, aff_sta_tmp, &sta_mld->mlo_sta_list,
		struct mlo_sta_db, list) {
		debug(DEBUG_CAT_MLO, "rm affiliated sta mac("MACSTR")\n", MAC2STR(aff_sta->affiliated_sta_mac));
		dl_list_del(&aff_sta->list);
		os_free(aff_sta);
	}
	os_memset(sta_mld, 0, sizeof(struct mlo_sta_config_db));
	dl_list_init(&sta_mld->mlo_sta_list);
}

void update_sta_mld_cfg_rpt(struct mlo_sta_config_db *sta_mld, struct mlo_sta_config *in_cfg)
{
	unsigned char idx = 0;
	struct mlo_sta_db *mlo_sta = NULL;

	os_memcpy(sta_mld->sta_mld_mac, in_cfg->sta_mld_mac, ETH_ALEN);
	os_memcpy(sta_mld->ap_mld_mac, in_cfg->ap_mld_mac, ETH_ALEN);
	notice(DEBUG_CAT_MLO, "sta_mld_mac "MACSTR", ap_mld_mac "MACSTR"\n",
		MAC2STR(sta_mld->sta_mld_mac), MAC2STR(sta_mld->ap_mld_mac));
	sta_mld->str_support = in_cfg->str_support;
	sta_mld->nstr_support = in_cfg->nstr_support;
	sta_mld->emlsr_support = in_cfg->emlsr_support;
	sta_mld->emlmr_support = in_cfg->emlmr_support;
	sta_mld->num_affiliates_sta = in_cfg->num_affiliates_sta;
	notice(DEBUG_CAT_MLO, "num_affiliates_sta %d\n", sta_mld->num_affiliates_sta);

	for (idx = 0; idx < in_cfg->num_affiliates_sta; idx++) {
		mlo_sta = (struct mlo_sta_db *)os_zalloc(sizeof(struct mlo_sta_db));
		if (!mlo_sta) {
			/* free buff while update next time or deinit */
			warn(DEBUG_CAT_MLO, "fail to malloc mlo sta record\n");
			return;
		}
		dl_list_add_tail(&sta_mld->mlo_sta_list, &mlo_sta->list);

		os_memcpy(mlo_sta->bssid, in_cfg->mlo_sta_info[idx].bssid, ETH_ALEN);
		os_memcpy(mlo_sta->affiliated_sta_mac, in_cfg->mlo_sta_info[idx].affiliated_sta_mac, ETH_ALEN);
		os_memcpy(mlo_sta->reserved, in_cfg->mlo_sta_info[idx].reserved, ETH_ALEN);
		notice(DEBUG_CAT_MLO, "bssid "MACSTR", sta mac "MACSTR"",
			MAC2STR(mlo_sta->bssid),  MAC2STR(mlo_sta->affiliated_sta_mac));
	}
}

void cmd_send_ap_mld_config_request(struct p1905_managerd_ctx *ctx)
{
	struct topology_response_db *tpgr_db = NULL;
	unsigned int recv_ifid = 0;
	unsigned char i = 0;
	struct mld_bss_config_db *mld_bss = NULL;

	if (ctx->MAP_Cer)
		_1905_read_mld_link_config(ctx);
	else {
		if (_1905_read_set_config(ctx, ctx->wts_bss_cfg_file,
			ctx->bss_config, MAX_SET_BSS_INFO_NUM, &ctx->bss_config_num) < 0)
			warn(DEBUG_CAT_MLO, "_1905_read_set_config fail\n");

	}

	delete_agent_ap_mld_list(&ctx->agent_ap_mld_list);
	SLIST_FOREACH(tpgr_db, &(ctx->topology_entry.tprdb_head), tprdb_entry) {
		recv_ifid = tpgr_db->recv_ifid;

		/* wts to ap mld once renew cmd
		 * no need this action after recv m1/bss cfg req once more
		 */
		wts_2_mlo_agent(ctx, tpgr_db->al_mac_addr);

		if (ctx->MAP_Cer) {
			/* for cert: mlo link change from /etc/map/mlo_link_config */
			if (os_memcmp(ctx->mld_chg.almac, tpgr_db->al_mac_addr, ETH_ALEN))
				continue;

			notice(DEBUG_CAT_MLO, "send ap mld config req to "MACSTR"\n", MAC2STR(ctx->mld_chg.almac));
			insert_cmdu_txq(ctx->mld_chg.almac, ctx->p1905_al_mac_addr,
				e_ap_mld_configuration_request, ++ctx->mid,
				(recv_ifid != -1) ? ctx->itf[recv_ifid].if_name : ctx->br_name, 0);
		} else {
			mld_bss = get_agent_ap_mld(ctx, tpgr_db->al_mac_addr);
			if (!mld_bss)
				continue;

			notice(DEBUG_CAT_MLO, "send ap mld config req to "MACSTR"\n", MAC2STR(tpgr_db->al_mac_addr));
			insert_cmdu_txq(tpgr_db->al_mac_addr, ctx->p1905_al_mac_addr,
				e_ap_mld_configuration_request, ++ctx->mid,
				(recv_ifid != -1) ? ctx->itf[recv_ifid].if_name : ctx->br_name, 0);
		}
	}

	if (!ctx->MAP_Cer) {
		delete_ap_mld_conf(&ctx->wts_ctrl_mld_cfg);
		for (i = 0; i < ctx->radio_number; i++)
			wts_2_mlo_cntrl(ctx, ctx->p1905_al_mac_addr, &ctx->rinfo[i]);

		update_agt_ap_mld_info(&ctx->wts_ctrl_mld_cfg, &ctx->opcls_mld_cfg);
		delete_ap_mld_conf(&ctx->opcls_mld_cfg);
		notice(DEBUG_CAT_MLO, "notify ap mld\n");
		_1905_notify_ap_mld_config(ctx, &ctx->wts_ctrl_mld_cfg, 1);
	}
}

void cmd_send_bsta_mld_config_request(struct p1905_managerd_ctx *ctx)
{
	struct topology_response_db *tpgr_db = NULL;
	unsigned int recv_ifid = 0;
	struct mld_bsta_config_db *bsta_db = NULL;
	unsigned char wildcard_mac[ETH_ALEN] = {0xff, 0xff, 0xff, 0xff, 0xff, 0xff};

	_1905_read_bsta_config(ctx);

	if (ctx->MAP_Cer)
		_1905_read_mld_link_config(ctx);

	SLIST_FOREACH(tpgr_db, &(ctx->topology_entry.tprdb_head), tprdb_entry) {
		recv_ifid = tpgr_db->recv_ifid;

		/* for cert: mlo link change from /etc/map/mlo_link_config */
		if (os_memcmp(ctx->mld_chg.almac, tpgr_db->al_mac_addr, ETH_ALEN) == 0) {
			notice(DEBUG_CAT_MLO, "send bsta mld config req to "MACSTR"\n", MAC2STR(ctx->mld_chg.almac));
			insert_cmdu_txq(ctx->mld_chg.almac, ctx->p1905_al_mac_addr,
				e_bsta_mld_configuration_request, ++ctx->mid,
				(recv_ifid != -1) ? ctx->itf[recv_ifid].if_name : ctx->br_name, 0);
			break;
		}

		/* for turnkey: mlo link change from /etc/map/wts_bsta_mlo_config */
		dl_list_for_each(bsta_db, &ctx->agent_bsta_list, struct mld_bsta_config_db, list) {
			if (os_memcmp(bsta_db->al_mac, wildcard_mac, ETH_ALEN) &&
				os_memcmp(bsta_db->al_mac, tpgr_db->al_mac_addr, ETH_ALEN))
				continue;

			notice(DEBUG_CAT_MLO, "send bsta mld config req to "MACSTR"\n", MAC2STR(tpgr_db->al_mac_addr));
			insert_cmdu_txq(tpgr_db->al_mac_addr, ctx->p1905_al_mac_addr,
				e_bsta_mld_configuration_request, ++ctx->mid,
				(recv_ifid != -1) ? ctx->itf[recv_ifid].if_name : ctx->br_name, 0);
			break;
		}
	}
}
#endif
#ifdef EM_PLUS_SUPPORT
int is_dev_wf7(struct p1905_managerd_ctx *ctx)
{
	struct p1905_interface *itf_list = NULL;
	int i = 0, send_wf7_cap = 0;

	itf_list = ctx->itf;
	for (i = 0; i < ctx->itf_number; i++) {
		if (itf_list[i].media_type == IEEE802_11BE_GROUP) {
			send_wf7_cap = 1;
			break;
		}
	}

	return send_wf7_cap;
}

void get_linux_ver(char *res)
{
	char *cmd = "uname -sr";
	char result[DE_MAX_LEN];
	char ret = 0;
	FILE *fp;

	os_memset(result, '\0', DE_MAX_LEN);

	fp = popen(cmd, "r");
	if (!fp) {
		warn(DEBUG_CAT_MISC, "Error opening pipe!\n");
		return;
	}
	/*read output from fp of cmd*/
	ret = fscanf(fp, "%63s", result);
	if (ret == EOF || ret == 0) {
		warn(DEBUG_CAT_MISC, "get linux version error!\n");
		pclose(fp);
		return;
	}

	if (pclose(fp))
		warn(DEBUG_CAT_MISC, "Command not found or exited with error status\n");

	os_memcpy(res, result, strlen(result));

}

void get_sw_version(char *res)
{
	char sw_verison[256] = {0};
	char *version = NULL;
	char *version_info = NULL;

	FILE *file = fopen("/proc/version", "r");

	if (file == NULL) {
		printf("Unable to open firmware version file.\n");
		return;
	}

	if (fgets(sw_verison, sizeof(sw_verison), file) == NULL) {
		err(DEBUG_CAT_MISC, "fgets fail\n");
		if (fclose(file))
			err(DEBUG_CAT_MISC, "fclose fail\n");
		return;
	}

	version = strstr(sw_verison, "SMP");
	if (version != NULL) {
		version_info = version + os_strlen("SMP");
		warn(DEBUG_CAT_MISC, "Sw verion info %s\n", version_info);
		(void)snprintf(res, DE_MAX_LEN, "%s", version_info);
	} else {
		warn(DEBUG_CAT_MISC, "Did not find version info!\n");
	}

	if (fclose(file)) {
		err(DEBUG_CAT_MISC, "fclose fail\n");
		return;
	}

	printf("Firmware version: %s\n", res);
}

int get_dev_inven(struct p1905_managerd_ctx *ctx)
{
	int i = 0, j = 0;
	struct dev_inven *de = NULL;
	struct dev_inven_ruid *de_ruid;
	struct radio_info *radio_info = NULL;

	de = os_zalloc(sizeof(struct dev_inven));
	if (!de) {
		warn(DEBUG_CAT_MISC, "Alloc memory fail!\n");
		return -1;
	}

	get_sw_version(de->sw_ver);
	de->sw_ver_len = os_strlen(de->sw_ver);

	get_linux_ver(de->exec_env);
	de->exec_env_len = os_strlen(de->exec_env);

	os_memcpy(de->ser_num, ctx->product.ser_num, ctx->product.ser_num_len);
		de->ser_num_len = ctx->product.ser_num_len;

	for (i = 0; i < ctx->radio_number; i++) {
		radio_info = &ctx->rinfo[i];
		de_ruid = &de->ruid[j];
		os_memcpy(de_ruid->identifier, radio_info->identifier, ETH_ALEN);
		os_memcpy(de_ruid->chip_ven, "Mediatek", os_strlen("Mediatek"));
		de_ruid->chip_ven[os_strlen("Mediatek")] = '\0';
		de_ruid->chip_ven_len = os_strlen(de_ruid->chip_ven);
		j++;

	}

	de->num_radio = ctx->radio_number;
	update_ap_dev_inven(ctx, de);
	os_free(de);
	return 0;
}
#endif

int add_new_interface(struct p1905_managerd_ctx *ctx, unsigned char *buf)
{
	struct interface_info *info = NULL;
	struct p1905_interface *itf = NULL;
	int index = 0;

	info = (struct interface_info *)buf;

	/*add new interface*/
	if (ctx->itf_number >= ITF_NUM) {
		warn(DEBUG_CAT_INIT, DYN_INTF_PREX"interface number(%d) equals/exceeds the max interface num(%d)",
			ctx->itf_number, ITF_NUM);
		return -1;
	}

	index = ctx->itf_number;
	itf = &ctx->itf[index];

	if (!itf->vs_info) {
		os_free(itf->vs_info);
		itf->vs_info = NULL;
	}
	os_memset(itf, 0, sizeof(struct p1905_interface));
	/*interface name*/
	os_memcpy(itf->if_name, info->if_name, IFNAMSIZ);
	itf->if_name[IFNAMSIZ - 1] = '\0';
	/*mac address*/
	os_memcpy(itf->mac_addr, info->if_mac_addr, ETH_ALEN);
	/*role*/
	if (os_strcmp((char *)info->if_role, "wiap") == 0)
		itf->is_wifi_ap = 1;
	else if (os_strcmp((char *)info->if_role, "wista") == 0)
		itf->is_wifi_sta = 1;
	else {
		warn(DEBUG_CAT_INIT, DYN_INTF_PREX"Unknown role[%s] = %s\n", info->if_name, info->if_role);
		return -1;
	}

	/*media type*/
	if (info->if_ch <= 14 && os_strcmp((char *)info->if_phymode, "B") == 0)
		itf->media_type = IEEE802_11B_24G_GROUP;
	else if (info->if_ch <= 14 && os_strcmp((char *)info->if_phymode, "G") == 0)
		itf->media_type = IEEE802_11G_24G_GROUP;
	else if (info->if_ch <= 14 && os_strcmp((char *)info->if_phymode, "N") == 0)
		itf->media_type = IEEE802_11N_24G_GROUP;
	else if (info->if_ch <= 14 && os_strcmp((char *)info->if_phymode, "AX") == 0)
		itf->media_type = IEEE802_11AX_GROUP;
	else if (info->if_ch > 14 && os_strcmp((char *)info->if_phymode, "A") == 0)
		itf->media_type = IEEE802_11A_5G_GROUP;
	else if (info->if_ch > 14 && os_strcmp((char *)info->if_phymode, "N") == 0)
		itf->media_type = IEEE802_11N_5G_GROUP;
	else if (info->if_ch > 14 && os_strcmp((char *)info->if_phymode, "AC") == 0)
		itf->media_type = IEEE802_11AC_5G_GROUP;
	else if (info->if_ch > 14 && os_strcmp((char *)info->if_phymode, "AX") == 0)
		itf->media_type = IEEE802_11AX_GROUP;
	else if (os_strcmp((char *)info->if_phymode, "BE") == 0)
		itf->media_type = IEEE802_11BE_GROUP;
	else {
		warn(DEBUG_CAT_INIT, DYN_INTF_PREX"%s band[%d] & phymode[%s] mismatch\n",
			info->if_name, info->if_ch, info->if_phymode);
		return -1;
	}
	/*radio indentifer*/
	os_memcpy(itf->identifier, info->identifier, ETH_ALEN);
	/*init vs_info*/
	itf->vs_info_length = 10;
	itf->vs_info = os_zalloc(itf->vs_info_length);
	if (!itf->vs_info) {
		warn(DEBUG_CAT_INIT, DYN_INTF_PREX"cannot alloc vs_info for %s\n", info->if_name);
		return -1;
	}
	os_memcpy(itf->vs_info, itf->mac_addr, ETH_ALEN);
	if (itf->is_wifi_sta) {
		*(itf->vs_info + 6) = 0x40;
		os_memset(itf->vs_info, 0, 6);
	}

	ctx->itf_number++;
	notice(DEBUG_CAT_INIT, DYN_INTF_PREX"add intf:%s itf_number:%d\n", itf->if_name, ctx->itf_number);
	return index;
}

void handle_new_interface_event(struct p1905_managerd_ctx *ctx, unsigned char *buf)
{
	int ret = 0, index = 0, i = 0;
	unsigned char num = 0;
	unsigned char *new_list = NULL;
	struct interface_info *info = NULL;

	if (!ctx || !buf) {
		warn(DEBUG_CAT_INIT, DYN_INTF_PREX"input params invalid\n");
		return;
	}

	/*duplicate check*/
	info = (struct interface_info *)buf;
	for (i = 0; i < ctx->itf_number; i++) {
		if (!os_memcmp(info->if_mac_addr, ctx->itf[i].mac_addr, ETH_ALEN)) {
			notice(DEBUG_CAT_INIT, DYN_INTF_PREX"exist interface:%s, not a new one\n", info->if_name);
			return;
		}
	}

	index = add_new_interface(ctx, buf);
	if (index < 0 || index >= ITF_NUM) {
		warn(DEBUG_CAT_INIT, DYN_INTF_PREX"add new interface fail for invalid index %d\n", index);
		return;
	}
	notice(DEBUG_CAT_INIT, DYN_INTF_PREX"add interface:%s index %d\n", info->if_name, index);
	/*common info for new interface*/
	num = ctx->br_cap[0].interface_num;

	new_list = os_realloc(ctx->br_cap[0].itf_mac_list, ETH_ALEN * (num + 1));
	if (new_list == NULL) {
		warn(DEBUG_CAT_INIT, DYN_INTF_PREX"os_realloc fail\n");
		return;
	}
	os_memset(new_list + (ETH_ALEN * num), 0, ETH_ALEN);
	ctx->br_cap[0].itf_mac_list = new_list;
	os_memcpy(ctx->br_cap[0].itf_mac_list + (ETH_ALEN * num), ctx->itf[index].mac_addr, ETH_ALEN);

	ctx->br_cap[0].interface_num++;

	os_memcpy(ctx->non_p1905_neighbor_dev[index].local_mac_addr, ctx->itf[index].mac_addr, ETH_ALEN);
	LIST_INIT(&(ctx->non_p1905_neighbor_dev[index].non_p1905nbr_head));
	os_memcpy(ctx->p1905_neighbor_dev[index].local_mac_addr, ctx->itf[index].mac_addr, ETH_ALEN);
	LIST_INIT(&(ctx->p1905_neighbor_dev[index].p1905nbr_head));
	if (ctx->itf[index].is_wifi_ap)
		init_radio_info_by_intf(ctx, &ctx->itf[index]);
	if (ctx->itf[index].media_type <= IEEE802_3_AB_GROUP) {
		ctx->itf[index].trx_config = TX_MUL | RX_MUL | TX_UNI | RX_UNI;
		warn(DEBUG_CAT_INIT, DYN_INTF_PREX"%s is the eth interface; enable all tx rx\n", ctx->itf[index].if_name);
	}

	/*write_bss_prio_to_1905_cfg_file*/

	/*create sock for new interface*/
	ret = create_sock_for_new_intf(ctx, index);
	if (ret != 0) {

		warn(DEBUG_CAT_INIT, DYN_INTF_PREX"create sock for %s fail\n", ctx->itf[index].if_name);
		return;
	}

	/*lldpdu init for new interface*/
	ret = lldpdu_init_for_new_intf(ctx, index);
	if (ret != 0) {
		warn(DEBUG_CAT_INIT, DYN_INTF_PREX"create lldpdu for %s fail\n", ctx->itf[index].if_name);
		return;
	}

	if (ctx->rx_from_all)
		eloop_register_read_sock(ctx->sock_inf_recv_1905[index], cmdu_process, (void *)ctx, NULL);
	eloop_register_read_sock(ctx->sock_lldp[index], lldp_process, (void *)ctx, NULL);
	info(DEBUG_CAT_INIT, DYN_INTF_PREX"ctx->itf_number=%d\n", ctx->itf_number);
}

void del_radio_info_by_intf(struct p1905_managerd_ctx *ctx, struct p1905_interface *itf)
{
	int i = 0, j = 0, k = 0;

	for (i = 0; i < ctx->radio_number; i++) {
		if (!os_memcmp(ctx->rinfo[i].identifier, itf->identifier, ETH_ALEN)) {
			if (!ctx->rinfo[i].bss_number) {
				warn(DEBUG_CAT_INIT, DYN_INTF_PREX" radio %d bss_number is 0\n", i);
				return;
			}
			for (j = 0; j < ctx->rinfo[i].bss_number; j++) {
				if (!os_memcmp(ctx->rinfo[i].bss[j].ifname, itf->if_name, IFNAMSIZ))
					break;
			}
			if (j >= ctx->rinfo[i].bss_number) {
				warn(DEBUG_CAT_INIT, DYN_INTF_PREX"can't find bss\n");
				return;
			}
			for (k = j + 1; k < ctx->rinfo[i].bss_number; k++) {
				os_memcpy((char *)&ctx->rinfo[i].bss[k - 1], (char *)&ctx->rinfo[i].bss[k],
					sizeof(struct config_bss_info));
			}

			k = ctx->rinfo[i].bss_number - 1;
			os_memset(&ctx->rinfo[i].bss[k], 0, sizeof(struct config_bss_info));
			ctx->rinfo[i].bss_number--;

			info(DEBUG_CAT_INIT, DYN_INTF_PREX"after del rinfo[%d] bss number = %d\n", i, ctx->rinfo[i].bss_number);
			break;
		}
	}
}

void update_non_p1905_neighbor(struct list_head_nonp1905nbr *dst_nonp1905nbr_head, struct list_head_nonp1905nbr *src_nonp1905nbr_head)
{
	struct non_p1905_neighbor_info *info = NULL;
	struct non_p1905_neighbor_info *info_temp = NULL;

	if (!dst_nonp1905nbr_head || !src_nonp1905nbr_head)
		return;
	if (LIST_EMPTY(src_nonp1905nbr_head))
		return;

	info = LIST_FIRST(src_nonp1905nbr_head);
	while (info) {
		info_temp = LIST_NEXT(info, non_p1905nbr_entry);
		LIST_REMOVE(info, non_p1905nbr_entry);
		LIST_INSERT_HEAD(dst_nonp1905nbr_head, info, non_p1905nbr_entry);
		info = info_temp;
	}
}

void update_p1905_neighbor(struct list_head_p1905nbr *dst_p1905nbr_head, struct list_head_p1905nbr *src_p1905nbr_head)
{
	struct p1905_neighbor_info *info = NULL;
	struct p1905_neighbor_info *info_temp = NULL;

	if (!dst_p1905nbr_head || !src_p1905nbr_head)
		return;
	if (LIST_EMPTY(src_p1905nbr_head))
		return;

	info = LIST_FIRST(src_p1905nbr_head);
	while (info) {
		info_temp = LIST_NEXT(info, p1905nbr_entry);
		LIST_REMOVE(info, p1905nbr_entry);
		LIST_INSERT_HEAD(dst_p1905nbr_head, info, p1905nbr_entry);
		info = info_temp;
	}
}

void handle_del_interface_event(struct p1905_managerd_ctx *ctx, unsigned char *buf)
{
	int index = 0;
	int i = 0, j = 0;
	struct p1905_neighbor_info *pinfo = NULL, *pinfo_tmp = NULL;
	struct non_p1905_neighbor_info *info = NULL, *info_tmp = NULL;
	unsigned char *new_list = NULL, *tmp_mac = NULL;

	if (!ctx || !buf) {
		warn(DEBUG_CAT_INIT, DYN_INTF_PREX"input params invalid\n");
		return;
	}
	notice(DEBUG_CAT_INIT, DYN_INTF_PREX"del itf=%s\n", buf);

	for (i = 0; i < ctx->itf_number; i++) {
		if (!os_memcmp(buf, ctx->itf[i].if_name, os_strlen((char *)buf))) {
			index = i;
			break;
		}
	}

	if (i == ctx->itf_number) {
		warn(DEBUG_CAT_INIT, DYN_INTF_PREX"find itf:%s fail\n", buf);
		return;
	}

	/*close lldp and sock*/
	eloop_unregister_read_sock(ctx->sock_lldp[index]);
	if (ctx->rx_from_all)
		eloop_unregister_read_sock(ctx->sock_inf_recv_1905[index]);

	close(ctx->sock_lldp[index]);
	close(ctx->sock_inf_recv_1905[index]);

	/*update bss priority str*/

	/* update p1905nbr_head */
	pinfo = LIST_FIRST(&ctx->p1905_neighbor_dev[index].p1905nbr_head);
	while (pinfo != NULL) {
		pinfo_tmp = LIST_NEXT(pinfo, p1905nbr_entry);
		notice(DEBUG_CAT_INIT, DYN_INTF_PREX"free p1905_neighbor_info(al="MACSTR")\n", PRINT_MAC(pinfo->al_mac_addr));
		os_free(pinfo);
		pinfo = pinfo_tmp;
	}
	LIST_INIT(&ctx->p1905_neighbor_dev[index].p1905nbr_head);
	os_memset(ctx->p1905_neighbor_dev[index].local_mac_addr, 0, ETH_ALEN);

	for (i = index + 1; i < ctx->itf_number; i++) {
		update_p1905_neighbor(&ctx->p1905_neighbor_dev[i - 1].p1905nbr_head, &ctx->p1905_neighbor_dev[i].p1905nbr_head);
		os_memcpy(ctx->p1905_neighbor_dev[i - 1].local_mac_addr, ctx->p1905_neighbor_dev[i].local_mac_addr, ETH_ALEN);
	}

	LIST_INIT(&ctx->p1905_neighbor_dev[ctx->itf_number - 1].p1905nbr_head);
	os_memset(ctx->p1905_neighbor_dev[ctx->itf_number - 1].local_mac_addr, 0, ETH_ALEN);

	/* update non_p1905nbr_head */
	info = LIST_FIRST(&ctx->non_p1905_neighbor_dev[index].non_p1905nbr_head);
	while (info != NULL) {
		info_tmp = LIST_NEXT(info, non_p1905nbr_entry);
		notice(DEBUG_CAT_INIT, DYN_INTF_PREX"free non neighbor_dev_db(al="MACSTR")\n",
			PRINT_MAC(info->itf_mac_addr));
			os_free(info);
			info = info_tmp;
	}
	LIST_INIT(&ctx->non_p1905_neighbor_dev[index].non_p1905nbr_head);
	os_memset(ctx->non_p1905_neighbor_dev[index].local_mac_addr, 0, ETH_ALEN);

	for (i = index + 1; i < ctx->itf_number; i++) {
		update_non_p1905_neighbor(&ctx->non_p1905_neighbor_dev[i - 1].non_p1905nbr_head, &ctx->non_p1905_neighbor_dev[i].non_p1905nbr_head);
		os_memcpy(ctx->non_p1905_neighbor_dev[i - 1].local_mac_addr, ctx->non_p1905_neighbor_dev[i].local_mac_addr, ETH_ALEN);
	}

	LIST_INIT(&ctx->non_p1905_neighbor_dev[ctx->itf_number - 1].non_p1905nbr_head);
	os_memset(ctx->non_p1905_neighbor_dev[ctx->itf_number - 1].local_mac_addr, 0, ETH_ALEN);


	/* update radio info */
	if (ctx->itf[index].is_wifi_ap) {
		del_radio_info_by_intf(ctx, &ctx->itf[index]);
		delete_exist_operational_bss_by_mac(ctx, ctx->itf[index].identifier, ctx->itf[index].mac_addr);
	}

    /* update ctx->br_cap[0].itf_mac_list */
	if (ctx->br_cap[0].interface_num) {
		if (ctx->br_cap[0].interface_num == 1) {
			os_free(ctx->br_cap[0].itf_mac_list);
			ctx->br_cap[0].itf_mac_list = NULL;
			ctx->br_cap[0].interface_num = 0;
		} else {
			new_list = os_zalloc(ETH_ALEN * (ctx->br_cap[0].interface_num - 1));
			if (new_list == NULL) {
				warn(DEBUG_CAT_INIT, DYN_INTF_PREX"os_zalloc fail\n");
				return;
			}

			for (i = 0; i < ctx->br_cap[0].interface_num; i++) {
				tmp_mac = ctx->br_cap[0].itf_mac_list + (i * ETH_ALEN);
				if (os_memcmp(tmp_mac, ctx->itf[index].mac_addr, ETH_ALEN)) {
					os_memcpy(new_list + (j * ETH_ALEN), tmp_mac, ETH_ALEN);
					j++;
				}
			}

			os_free(ctx->br_cap[0].itf_mac_list);
			ctx->br_cap[0].itf_mac_list = new_list;
			ctx->br_cap[0].interface_num = j;
			info(DEBUG_CAT_INIT, DYN_INTF_PREX" ctx->br_cap[0].interface_num=%d\n", ctx->br_cap[0].interface_num);
		}
	} else {
		info(DEBUG_CAT_INIT, DYN_INTF_PREX"ctx->br_cap[0].interface_num=%d, invalid\n", ctx->br_cap[0].interface_num);
		return;
	}

	/* update ctx->itf[] */
	for (i = index + 1; i < ctx->itf_number; i++) {
		if (ctx->itf[i - 1].vs_info)
			os_free(ctx->itf[i - 1].vs_info);
		ctx->itf[i - 1].vs_info = NULL;
		os_memcpy(ctx->itf[i - 1].mac_addr, ctx->itf[i].mac_addr, ETH_ALEN);
		os_memcpy(ctx->itf[i - 1].if_name, ctx->itf[i].if_name, IFNAMSIZ);
		ctx->itf[i - 1].if_name[IFNAMSIZ - 1] = '\0';
		ctx->itf[i - 1].media_type = ctx->itf[i].media_type;
		ctx->itf[i - 1].is_wifi_ap = ctx->itf[i].is_wifi_ap;
		ctx->itf[i - 1].is_wifi_sta = ctx->itf[i].is_wifi_sta;
		os_memcpy(ctx->itf[i - 1].identifier, ctx->itf[i].identifier, ETH_ALEN);
		ctx->itf[i - 1].vs_info_length = ctx->itf[i].vs_info_length;
		ctx->itf[i - 1].vs_info = os_zalloc(ctx->itf[i - 1].vs_info_length);
		if (!ctx->itf[i - 1].vs_info) {
			warn(DEBUG_CAT_INIT, DYN_INTF_PREX"cannot alloc vs_info for %s\n", ctx->itf[i - 1].if_name);
			return;
		}
		os_memcpy(ctx->itf[i - 1].vs_info, ctx->itf[i].vs_info, ctx->itf[i].vs_info_length);
		ctx->itf[i - 1].config_priority = ctx->itf[i].config_priority;
		ctx->itf[i - 1].trx_config = ctx->itf[i].trx_config;
		ctx->itf[i - 1].is_wan = ctx->itf[i].is_wan;
		ctx->itf[i - 1].is_veth = ctx->itf[i].is_veth;
		ctx->itf[i - 1].channel_freq = ctx->itf[i].channel_freq;
		ctx->itf[i - 1].channel_bw = ctx->itf[i].channel_bw;
		ctx->itf[i - 1].if_index = ctx->itf[i].if_index;
#ifdef EM_PLUS_SUPPORT
		ctx->itf[i - 1].update_vlan_tag = ctx->itf[i].update_vlan_tag;
#endif
		ctx->sock_lldp[i - 1] = ctx->sock_lldp[i];
		ctx->sock_inf_recv_1905[i - 1] = ctx->sock_inf_recv_1905[i];
	}

	if (ctx->itf[ctx->itf_number - 1].vs_info)
		os_free(ctx->itf[ctx->itf_number - 1].vs_info);
	ctx->itf[ctx->itf_number - 1].vs_info = NULL;
	os_memset(&ctx->itf[ctx->itf_number - 1], 0, sizeof(struct p1905_interface));

	ctx->itf_number--;

	for (i = 0 ; i < ctx->itf_number; i++)
		debug(DEBUG_CAT_INIT, DYN_INTF_PREX"after del ctx->itf[%d]=%s mac "MACSTR")\n", i,
			ctx->itf[i].if_name, PRINT_MAC(ctx->itf[i].mac_addr));
}

