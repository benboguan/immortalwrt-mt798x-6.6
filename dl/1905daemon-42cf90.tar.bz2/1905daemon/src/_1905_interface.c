/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

/*this file include some function to test 1905 deamon*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <errno.h>
#include <assert.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/ipc.h>
#include <sys/types.h>
#include <sys/sem.h>
#include <stddef.h>
#include "_1905_interface.h"
#include "p1905_managerd.h"
#include "multi_ap.h"
#include "debug.h"
#include "_1905_interface_ctrl.h"
#include "_1905_lib_io.h"

char *get_1905_notify_event_str(unsigned short event_type)
{
	switch (event_type) {
	case _1905_SET_WIRELESS_SETTING_EVENT:
		return "_1905_SET_WIRELESS_SETTING_EVENT";
	case _1905_RECV_CHANNEL_PREFERENCE_QUERY_EVENT:
		return "_1905_RECV_CHANNEL_PREFERENCE_QUERY_EVENT";
	case _1905_RECV_CHANNEL_SELECTION_REQ_EVENT:
		return "_1905_RECV_CHANNEL_SELECTION_REQ_EVENT";
	case _1905_RECV_STEERING_REQUEST_EVENT:
		return "_1905_RECV_STEERING_REQUEST_EVENT";
	case _1905_RECV_CLIENT_ASSOC_CNTRL_SETTING_EVENT:
		return "_1905_RECV_CLIENT_ASSOC_CNTRL_SETTING_EVENT";
	case _1905_RECV_POLICY_CONFIG_REQUEST_EVENT:
		return "_1905_RECV_POLICY_CONFIG_REQUEST_EVENT";
	case _1905_RECV_AP_METRICS_QUERY_EVENT:
		return "_1905_RECV_AP_METRICS_QUERY_EVENT";
	case _1905_RECV_BACKHAUL_STEER_REQ_EVENT:
		return "_1905_RECV_BACKHAUL_STEER_REQ_EVENT";
	case _1905_RECV_ASSOC_STA_LINK_METRICS_QUERY_EVENT:
		return "_1905_RECV_ASSOC_STA_LINK_METRICS_QUERY_EVENT";
	case _1905_RECV_LINK_METRICS_QUERY:
		return "_1905_RECV_LINK_METRICS_QUERY";
	case _1905_RECV_UNASSOC_STA_LINK_METRICS_QUERY_EVENT:
		return "_1905_RECV_UNASSOC_STA_LINK_METRICS_QUERY_EVENT";
	case _1905_SET_RADIO_TEARED_DOWN_EVENT:
		return "_1905_SET_RADIO_TEARED_DOWN_EVENT";
	case _1905_RECV_BEACON_METRICS_QUERY_EVENT:
		return "_1905_RECV_BEACON_METRICS_QUERY_EVENT";
	case _1905_MAP_CONTROLLER_FOUND_EVENT:
		return "_1905_MAP_CONTROLLER_FOUND_EVENT";
	case _1905_AUTOCONFIG_RENEW_EVENT:
		return "_1905_AUTOCONFIG_RENEW_EVENT";
	case _1905_AUTOCONFIG_SEARCH_EVENT:
		return "_1905_AUTOCONFIG_SEARCH_EVENT";
	case _1905_AUTOCONFIG_RSP_EVENT:
		return "_1905_AUTOCONFIG_RSP_EVENT";
	case _1905_RECV_TOPOLOGY_RSP_EVENT:
		return "_1905_RECV_TOPOLOGY_RSP_EVENT";
	case _1905_RECV_TOPOLOGY_NOTIFICATION_EVENT:
		return "_1905_RECV_TOPOLOGY_NOTIFICATION_EVENT";
	case _1905_RECV_CHANNEL_PREFERENCE_REPORT_EVENT:
		return "_1905_RECV_CHANNEL_PREFERENCE_REPORT_EVENT";
	case _1905_RECV_CLI_STEER_BTM_REPORT_EVENT:
		return "_1905_RECV_CLI_STEER_BTM_REPORT_EVENT";
	case _1905_RECV_STEER_COMPLETE_EVENT:
		return "_1905_RECV_STEER_COMPLETE_EVENT";
	case _1905_RECV_LINK_METRICS_RSP_EVENT:
		return "_1905_RECV_LINK_METRICS_RSP_EVENT";
	case _1905_RECV_AP_METRICS_RSP_EVENT:
		return "_1905_RECV_ASSOC_STA_LINK_METRICS_RSP_EVENT";
	case _1905_RECV_ASSOC_STA_LINK_METRICS_RSP_EVENT:
		return "_1905_RECV_UNASSOC_STA_LINK_METRICS_QUERY_EVENT";
	case _1905_RECV_UNASSOC_STA_LINK_METRICS_RSP_EVENT:
		return "_1905_RECV_UNASSOC_STA_LINK_METRICS_RSP_EVENT";
	case _1905_RECV_BCN_METRICS_RSP_EVENT:
		return "_1905_RECV_BCN_METRICS_RSP_EVENT";
	case _1905_RECV_BACKHAUL_STEER_RSP_EVENT:
		return "_1905_RECV_BACKHAUL_STEER_RSP_EVENT";
	case _1905_RECV_COMBINED_INFRASTRUCTURE_METRICS_EVENT:
		return "_1905_RECV_COMBINED_INFRASTRUCTURE_METRICS_EVENT";
	case _1905_RECV_VENDOR_SPECIFIC_MESSAGE_EVENT:
		return "_1905_RECV_VENDOR_SPECIFIC_MESSAGE_EVENT";
	case _1905_RECV_AP_CAPABILITY_REPORT_EVENT:
		return "_1905_RECV_AP_CAPABILITY_REPORT_EVENT";
	case _1905_RECV_CH_SELECTION_RSP_EVENT:
		return "_1905_RECV_CH_SELECTION_RSP_EVENT";
	case _1905_RECV_OPERATING_CH_REPORT_EVENT:
		return "_1905_RECV_OPERATING_CH_REPORT_EVENT";
	case _1905_RECV_CLIENT_CAPABILITY_REPORT_EVENT:
		return "_1905_RECV_CLIENT_CAPABILITY_REPORT_EVENT";
	case _1905_RECV_HIGHER_LAYER_DATA_EVENT:
		return "_1905_RECV_HIGHER_LAYER_DATA_EVENT";
	case _1905_RECV_COMBINED_INFRASTRUCTURE_METRICS_QUERY_EVENT:
		return "_1905_RECV_COMBINED_INFRASTRUCTURE_METRICS_QUERY_EVENT";
	case _1905_SWITCH_STATUS:
		return "_1905_SWITCH_STATUS";
	case _1905_SYNC_RECV_BUF_SIZE_RSP_EVENT:
		return "_1905_SYNC_RECV_BUF_SIZE_RSP_EVENT";
	case _1905_SYNC_RECV_BUF_SIZE_EVENT:
		return "_1905_SYNC_RECV_BUF_SIZE_EVENT";
	case _1905_RECV_ERROR_CODE_EVENT:
		return "_1905_RECV_ERROR_CODE_EVENT";
#ifdef MAP_R2
	case _1905_RECV_CHANNEL_SCAN_REQ_EVENT:
		return "_1905_RECV_CHANNEL_SCAN_REQ_EVENT";
	case _1905_RECV_CHANNEL_SCAN_REP_EVENT:
		return "_1905_RECV_CHANNEL_SCAN_REP_EVENT";
	case _1905_RECV_TUNNELED_MESSAGE_EVENT:
		return "_1905_RECV_TUNNELED_MESSAGE_EVENT";
	case _1905_RECV_ASSOCIATION_STATUS_NOTIFICATION_EVENT:
		return "_1905_RECV_ASSOCIATION_STATUS_NOTIFICATION_EVENT";
	case _1905_RECV_CAC_REQUEST_EVENT:
		return "_1905_RECV_CAC_REQUEST_EVENT";
	case _1905_RECV_CAC_TERMINATE_EVENT:
		return "_1905_RECV_CAC_TERMINATE_EVENT";
	case _1905_RECV_CLIENT_DISASSOCIATION_STATS_EVENT:
		return "_1905_RECV_CLIENT_DISASSOCIATION_STATS_EVENT";
	case _1905_RECV_BACKHAUL_STA_CAP_REPORT_EVENT:
		return "_1905_RECV_BACKHAUL_STA_CAP_REPORT_EVENT";
	case _1905_SET_TRAFFIC_SEPARATION_SETTING_EVENT:
		return "_1905_SET_TRAFFIC_SEPARATION_SETTING_EVENT";
	case _1905_SET_TRANSPARENT_VLAN_SETTING_EVENT:
		return "_1905_SET_TRANSPARENT_VLAN_SETTING_EVENT";
	case _1905_RECV_FAILED_CONNECTION_EVENT:
		return "_1905_RECV_FAILED_CONNECTION_EVENT";
	case _1905_SET_AP_RADIO_ADVANCED_CAPABILITIES_EVENT:
		return "_1905_SET_AP_RADIO_ADVANCED_CAPABILITIES_EVENT";
#endif
#if defined(MAP_R2) || defined(CENT_STR)
	case _1905_RECV_AP_METRICS_QUERY_PERIODIC_EVENT:
		return "_1905_RECV_AP_METRICS_QUERY_PERIODIC_EVENT";
#endif
#ifdef MAP_R3
	case _1905_SET_AKM_SUIT_CAP_EVENT:
		return "_1905_SET_1905_SECURE_CAP_EVENT";
	case _1905_SET_1905_SECURE_CAP_EVENT:
		return "_1905_RECV_BCN_METRICS_RSP_EVENT";
	case _1905_SET_SP_STANDARD_RULE:
		return "_1905_SET_SP_STANDARD_RULE";
	case _1905_RECV_DIRECT_ENCAP_DPP_EVENT:
		return "_1905_RECV_DIRECT_ENCAP_DPP_EVENT";
	case _1905_RECV_PROXIED_ENCAP_DPP_EVENT:
		return "_1905_RECV_PROXIED_ENCAP_DPP_EVENT";
	case _1905_RECV_ETH_ONBOARDING_EVENT:
		return "_1905_RECV_ETH_ONBOARDING_EVENT";
	case _1905_RECV_DPP_BOOTSTRAP_URI_QUERY_EVENT:
		return "_1905_RECV_DPP_BOOTSTRAP_URI_QUERY_EVENT";
	case _1905_RECV_DPP_BOOTSTRAP_URI_NOTIFY_EVENT:
		return "_1905_RECV_DPP_BOOTSTRAP_URI_NOTIFY_EVENT";
	case _1905_RECV_DPP_CCE_INDICATION_EVENT:
		return "_1905_RECV_DPP_CCE_INDICATION_EVENT";
	case _1905_RECV_CHIRP_NOTIFICATION_EVENT:
		return "_1905_RECV_CHIRP_NOTIFICATION_EVENT";
	case _1905_RECV_DPP_RECONFIG_TRIGGER_EVENT:
		return "_1905_RECV_DPP_RECONFIG_TRIGGER_EVENT";
	case _1905_RECV_BH_BSS_CONFIG_EVENT:
		return "_1905_RECV_BH_BSS_CONFIG_EVENT";
	case _1905_RECV_BSS_CONFIG_RESPONSE_EVENT:
		return "_1905_RECV_BSS_CONFIG_RESPONSE_EVENT";
	case _1905_RECV_1905_SECURITY:
		return "_1905_RECV_1905_SECURITY";
	case _1905_SET_ONBOARDING_RESULT_EVENT:
		return "_1905_SET_ONBOARDING_RESULT_EVENT";
#endif
#ifdef MAP_R5
	case _1905_SET_QOS_MANAGEMENT_POLICY:
		return "_1905_SET_QOS_MANAGEMENT_POLICY";
	case _1905_SET_QOS_MANAGEMENT_DESCRIPTOR:
		return "_1905_SET_QOS_MANAGEMENT_DESCRIPTOR";
	case _1905_SET_QOS_DSCP_TABLE:
		return "_1905_SET_QOS_DSCP_TABLE";
#endif
	case _1905_SET_MLO_AGENT_BSS_CONFIG:
		return "_1905_SET_MLO_AGENT_BSS_CONFIG";
	case _1905_RECV_EHT_OPERATION_CONFIG:
		return "_1905_RECV_EHT_OPERATION_CONFIG";
#ifdef MAP_R6
	case _1905_SET_MLO_BH_STA_CONFIG:
		return "_1905_SET_MLO_BH_STA_CONFIG";
	case _1905_SET_WSC_CREDENTIAL_RECONFIG:
		return "_1905_SET_WSC_CREDENTIAL_RECONFIG";
	case _1905_SET_EARLY_APCAP_REPORT:
		return "_1905_SET_EARLY_APCAP_REPORT";
	case _1905_RECV_AFC_SPECTRUM_MSG:
		return "_1905_RECV_AFC_SPECTRUM_MSG";
#endif
	case _1905_RECV_TID_TO_TID_LINK_MAPPING:
		return "_1905_RECV_TID_TO_TID_LINK_MAPPING";
	case _1905_SET_RADIO_WIFI_OFF_EVENT:
		return "_1905_SET_RADIO_WIFI_OFF_EVENT";
	default:
		return "UNKNOWN 1905 EVENT";
	}
}

int _1905_interface_open_sock(struct p1905_managerd_ctx *ctx, char* socket_patch)
{
	int sock_len = 0;
	int flags;
	struct _1905_interface_ctrl* cli_ctrl = NULL;
	int nSndBufLen = 0,nRcvBufLen = 0;
	socklen_t optlen = sizeof(int);

	cli_ctrl = &ctx->_1905_ctrl;
	errno = 0;
	cli_ctrl->sock = socket(PF_UNIX, SOCK_DGRAM, 0);
	if (cli_ctrl->sock < 0) {
		err(DEBUG_CAT_MISC, "fail to create socket; errno=%d(%s)\n",
			errno, strerror(errno));
		goto fail;
	}

	if (getsockopt(cli_ctrl->sock, SOL_SOCKET, SO_SNDBUF, (void *)&nSndBufLen, &optlen) < 0)
		nSndBufLen = 1024*1024;
	else
		nSndBufLen = nSndBufLen * 2;

	if (getsockopt(cli_ctrl->sock, SOL_SOCKET, SO_RCVBUF, (void *)&nRcvBufLen, &optlen) < 0)
		nRcvBufLen = 1024*1024;
	else
		nRcvBufLen = nRcvBufLen * 2;

	notice(DEBUG_CAT_MISC, "cli_ctrl->sock: SO_SNDBUF=%d SO_RCVBUF=%d\n", nSndBufLen, nRcvBufLen);
	errno = 0;
	if (setsockopt(cli_ctrl->sock, SOL_SOCKET, SO_SNDBUF, (const char *)&nSndBufLen, sizeof(int)) < 0)
		warn(DEBUG_CAT_MISC, "fail to reset SO_SNDBUF; errno=%d(%s)\n", errno, strerror(errno));
	errno = 0;
	if (setsockopt(cli_ctrl->sock, SOL_SOCKET, SO_RCVBUF, (const char *)&nRcvBufLen, sizeof(int)) < 0)
		warn(DEBUG_CAT_MISC, "fail to reset SO_RCVBUF; errno=%d(%s)\n", errno, strerror(errno));

	memset(&cli_ctrl->addr, 0, sizeof(cli_ctrl->addr));
	cli_ctrl->addr.sun_family = AF_UNIX;
	/*abstract path*/
	cli_ctrl->addr.sun_path[0] = '\0';
	sock_len = snprintf(cli_ctrl->addr.sun_path + 1, sizeof(cli_ctrl->addr.sun_path) - 1, "%s", socket_patch);
	sock_len += 1 + offsetof(struct sockaddr_un, sun_path);
	errno = 0;
	if (bind(cli_ctrl->sock, (struct sockaddr *) &cli_ctrl->addr, sock_len) < 0) {
		err(DEBUG_CAT_MISC, "fail to bind socket; errno=%d(%s)\n",
			errno, strerror(errno));
		goto fail;
	}

	/*
	 * Make socket non-blocking so that we don't hang forever if
	 * target dies unexpectedly.
	 */
	flags = fcntl(cli_ctrl->sock, F_GETFL);
	if (flags >= 0) {
		flags |= O_NONBLOCK;
		/* Not fatal, continue on.*/
		errno = 0;
		if (fcntl(cli_ctrl->sock, F_SETFL, flags) < 0)
			warn(DEBUG_CAT_MISC, "fcntl O_NONBLOCK failed, errno=%d(%s)\n",
				errno, strerror(errno));
	}

	return 0;

fail:
	if (cli_ctrl->sock >= 0) {
		close(cli_ctrl->sock);
		cli_ctrl->sock = -1;
	}

	return -1;
}

int _1905_send_sync_recv_buf_size(struct p1905_managerd_ctx* ctx, unsigned short change_len, unsigned short own_len)
{
	unsigned char buf[50] = {0};
	struct msg *recv_event = (struct msg *)buf;
	int len = 0;
	int ret = 0;

	/*type*/
	recv_event->type = _1905_SYNC_RECV_BUF_SIZE_EVENT;
	len += 2;

	/*mid*/
	len += 2;

	/*len*/
	recv_event->length = sizeof(change_len) + sizeof(own_len);
	len += 2;

	/*buf*/
	memcpy(recv_event->buffer, &change_len, sizeof(change_len));
	len += sizeof(change_len);
	memcpy(recv_event->buffer + sizeof(change_len), &own_len, sizeof(own_len));
	len += sizeof(own_len);
	ret = _1905_interface_send_int(ctx, buf, (size_t)len, NULL);

	if (ret > 0)
		return wapp_utils_success;
	else
		return wapp_utils_error;
}

int _1905_interface_init(void *in_ctx)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx *)in_ctx;
	struct _1905_interface_ctrl* cli_ctrl = NULL;
	struct _config_buf_ctrl *buf_ctr = NULL;

	cli_ctrl = &ctx->_1905_ctrl;
	dl_list_init(&cli_ctrl->daemon_cli_list);

	if (_1905_interface_open_sock(ctx, "1905_daemon") < 0)
		return -1;

	buf_ctr = &ctx->config_buffer;
	dl_list_init(&buf_ctr->list);
	ctx->_1905_ctrl.default_own_recv_len = MAX_PKT_LEN;
	ctx->_1905_ctrl.own_recv_buf_len = ctx->_1905_ctrl.default_own_recv_len;
	ctx->_1905_ctrl.sock_buf = NULL;
	ctx->_1905_ctrl.peer_recv_buf_len = 0;
	ctx->_1905_ctrl.default_peer_recv_len = 0;
	if(_1905_interface_set_sock_buf(ctx, ctx->_1905_ctrl.own_recv_buf_len)  != 0) {
		_1905_interface_deinit(ctx);
		return -1;
	}

	return 0;
}


int _1905_interface_reinit(struct p1905_managerd_ctx *ctx)
{
	int res;
	struct _1905_interface_ctrl* cli_ctrl = NULL;

	cli_ctrl = &ctx->_1905_ctrl;
	if (cli_ctrl->sock <= 0)
		return -1;

	close(cli_ctrl->sock);
	cli_ctrl->sock = -1;

	res = _1905_interface_open_sock(ctx, "1905_daemon");
	if (res < 0)
		return -1;
	return cli_ctrl->sock;
}


void _1905_interface_deinit(void *in_ctx)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx *)in_ctx;
	struct _1905_interface_ctrl* cli_ctrl = NULL;
	struct _1905_interface_cli *dst, *prev;

	cli_ctrl = &ctx->_1905_ctrl;

	if (cli_ctrl->sock > -1) {
		if (!dl_list_empty(&cli_ctrl->daemon_cli_list)) {
			/*
			 * Wait before closing the control socket if
			 * there are any attached monitors in order to allow
			 * them to receive any pending messages.
			 */
			notice(DEBUG_CAT_MISC, "CTRL_IFACE(%s) wait for attached "
				   "monitors to receive messages", cli_ctrl->addr.sun_path);
			os_sleep(0, 100000);
		}
		close(cli_ctrl->sock);
		cli_ctrl->sock = -1;
		unlink(cli_ctrl->addr.sun_path);
	}

	dl_list_for_each_safe(dst, prev, &cli_ctrl->daemon_cli_list, struct _1905_interface_cli,
			      list)
	{
		free(dst);
	}

	ctx->_1905_ctrl.default_own_recv_len = 0;
	ctx->_1905_ctrl.own_recv_buf_len = 0;
	ctx->_1905_ctrl.peer_recv_buf_len = 0;
	ctx->_1905_ctrl.default_peer_recv_len = 0;
	if(ctx->_1905_ctrl.sock_buf) {
		free(ctx->_1905_ctrl.sock_buf);
		ctx->_1905_ctrl.sock_buf = NULL;
	}
}

int _1905_interface_attach(struct dl_list *ctrl_dst,
					    struct sockaddr_un *from,
					    socklen_t fromlen, char* daemon_name)
{
	struct _1905_interface_cli* dst, *dst_n;
	char addr_txt[200];

	/*firstly delete the previous same attached daemon*/
	dl_list_for_each_safe(dst, dst_n, ctrl_dst, struct _1905_interface_cli, list) {
		if (!memcmp(dst->daemon_name, daemon_name, strlen(daemon_name))) {
			notice(DEBUG_CAT_EVENT, "delete the previous daemon(%s)\n", daemon_name);
			dl_list_del(&dst->list);
			free(dst);
		}
	}
	/*alloc an new client structure and add to the linklist*/
	dst = (struct _1905_interface_cli* )malloc(sizeof(*dst));
	if (dst == NULL)
		return -1;
	if (strlen(daemon_name) > sizeof(dst->daemon_name)) {
		os_free(dst);
		return -1;
	}

	memset(dst, 0, sizeof(*dst));
	memcpy(&dst->addr, from, sizeof(struct sockaddr_un));
	strncpy(dst->daemon_name, daemon_name, strlen(daemon_name));
	dst->addrlen = fromlen;
	dl_list_add(ctrl_dst, &dst->list);
	printf_encode(addr_txt, sizeof(addr_txt),
		      (unsigned char *) from->sun_path,
		      fromlen - offsetof(struct sockaddr_un, sun_path));
	notice(DEBUG_CAT_EVENT, "daemon %s attached; addr=%s\n", daemon_name, addr_txt);
	return 0;
}

int _1905_interface_detach(struct dl_list *ctrl_dst,
					    struct sockaddr_un *from,
					    socklen_t fromlen)
{
	struct _1905_interface_cli* dst, *dst_n;

	dl_list_for_each_safe(dst, dst_n, ctrl_dst, struct _1905_interface_cli, list) {
		if (fromlen == dst->addrlen &&
		    memcmp(from->sun_path, dst->addr.sun_path,
			      fromlen - offsetof(struct sockaddr_un, sun_path))
		    == 0) {
			char addr_txt[200];
			printf_encode(addr_txt, sizeof(addr_txt),
				      (unsigned char *) from->sun_path,
				      fromlen -
				      offsetof(struct sockaddr_un, sun_path));
			notice(DEBUG_CAT_EVENT, "daemon %s monitor detached; addr=%s\n",
				   dst->daemon_name, addr_txt);
			dl_list_del(&dst->list);
			free(dst);
			return 0;
		}
	}
	return -1;
}

int _1905_interface_process(struct p1905_managerd_ctx *ctx, struct sockaddr_un* from,
					socklen_t fromlen, char *buf, size_t buf_len, char** reply, size_t *resp_len)
{

	int reply_len = 0;
	char* reply_buf = NULL;
	int ret = 0;
	reply_buf = (char*)os_zalloc(MAX_PKT_LEN);

	if (reply_buf == NULL) {
		err(DEBUG_CAT_MISC, "alloc relay_buf fail!\n");
		goto error3;
	}
	/*it is not essential to check peer device, because 1905libary user is safe enough*/
	/*add command handler here, now just add map handler*/
	/*if the command handler want to reply event, please fill the reply_buf and reply_len*/
	/*reply_len here represents the buffer size of reply_buf*/
	reply_len = MAX_PKT_LEN;
	ret = map_event_handler(ctx, buf, buf_len, 0, (unsigned char *)reply_buf, &reply_len);
	/*check reply len is changed or not*/
	reply_len = reply_len == MAX_PKT_LEN ? 0 : reply_len;

	*reply = reply_buf;
	*resp_len = reply_len;
	return ret;

error3:
	*reply = reply_buf;
	*resp_len = reply_len;
	return -1;
}

void socket_send(struct p1905_managerd_ctx *ctx, char* buf, size_t buf_len, struct _1905_interface_cli* dst)
{
	int _errno = 0;
	unsigned short type = *(unsigned short *)buf;

retry_send:
	if (sendto(ctx->_1905_ctrl.sock, buf, buf_len, 0, (struct sockaddr *) &dst->addr,
	   dst->addrlen) >= 0) {
		dst->errors = 0;
		debug(DEBUG_CAT_EVENT, "notify event success to %s; type=%04x(%s)\n",
			dst->daemon_name, type, get_1905_notify_event_str(type));
		debug_hexdump(DEBUG_CAT_EVENT, "event header dump", buf, 12);
		return;
	}

	_errno = errno;
	if (_errno == ENOBUFS || _errno == EAGAIN) {
		/*
		 * The socket send buffer could be full. This
		 * may happen if client programs are not
		 * receiving their pending messages. Close and
		 * reopen the socket as a workaround to avoid
		 * getting stuck being unable to send any new
		 * responses.
		 */
		 dst->errors++;
		 if (dst->errors < 3) {
			notice(DEBUG_CAT_EVENT, "retry %d times to notify event to %s; errno=%d(%s)\n",
				dst->errors, dst->daemon_name, _errno, strerror(_errno));
			os_sleep(1, 0);
			goto retry_send;
		}
		err(DEBUG_CAT_EVENT, "retry notify event fail to %s; type=%04x(%s); errno=%d(%s)\n",
			dst->daemon_name, type, get_1905_notify_event_str(type),
			 _errno, strerror(_errno));
		err_hexdump(DEBUG_CAT_EVENT, "event header dump", buf, 12);
	} else {
		err(DEBUG_CAT_EVENT, "notify event fail to %s; type=%04x(%s); errno=%d(%s)\n",
			dst->daemon_name, type, get_1905_notify_event_str(type),
			 _errno, strerror(_errno));
		err_hexdump(DEBUG_CAT_EVENT, "event header dump", buf, 12);
	}
}

int send_event_dispatch(struct p1905_managerd_ctx *ctx, struct msg* event, size_t event_len, char* dst_daemon)
{
	struct _1905_interface_cli* dst, *dst_n;
	unsigned char daemon_cnt = 0;

	dl_list_for_each_safe(dst, dst_n,  &ctx->_1905_ctrl.daemon_cli_list, struct _1905_interface_cli, list)
	{
		socket_send(ctx, (char *)event, event_len, dst);
		daemon_cnt++;
	}

	return daemon_cnt;
}

int _1905_interface_send_int(void *in_ctx, unsigned char* buf, size_t buf_len, char *dst_dameon)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx *)in_ctx;
	unsigned char daemon_cnt = 0;

	daemon_cnt = send_event_dispatch(ctx, (struct msg*)buf, buf_len, dst_dameon);

	return daemon_cnt;
}

int _1905_interface_send(void *in_ctx, unsigned char* buf, size_t buf_len, char *dst_dameon)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx *)in_ctx;
	unsigned char daemon_cnt = 0;
	unsigned short peer_buf_len = 0;
	unsigned short change_buf_len = 0;
	unsigned char recv_buf[50] = {0};
	struct msg *send_event = NULL;

	if(!ctx || !buf || !buf_len) {
		err(DEBUG_CAT_EVENT, "invalid input parameters; ctx=%p, buf=%p, buf_len=%zu\n",
			ctx, buf, buf_len);
		return -1;
	}
	peer_buf_len = ctx->_1905_ctrl.peer_recv_buf_len;
	if (buf_len > peer_buf_len)
		change_buf_len = buf_len;
	else if (ctx->_1905_ctrl.default_peer_recv_len < peer_buf_len && buf_len <= ctx->_1905_ctrl.default_peer_recv_len)
		change_buf_len = ctx->_1905_ctrl.default_peer_recv_len;

	send_event = (struct msg *)buf;
	if (send_event->type == _1905_SYNC_RECV_BUF_SIZE_RSP_EVENT)
		change_buf_len = 0;

	if (change_buf_len == 0) {
		daemon_cnt = _1905_interface_send_int(ctx, buf, buf_len, dst_dameon);
	} else {
		notice(DEBUG_CAT_EVENT, "event buffer change; change_buf_len=%d; event_buf_len=%zu;"
			" peer_recv_buf_len=%d; default_peer_recv_len=%d\n",
			change_buf_len, buf_len, ctx->_1905_ctrl.peer_recv_buf_len,
			ctx->_1905_ctrl.default_peer_recv_len);
		if (_1905_send_sync_recv_buf_size(ctx, change_buf_len, ctx->_1905_ctrl.own_recv_buf_len)) {
			err(DEBUG_CAT_EVENT, "event buffer change fail, drop event; type=%04x\n", send_event->type);
			return -1;
		}
		if (_1905_wait_parse_spec_event(ctx, recv_buf, sizeof(recv_buf),
		LIB_SYNC_RECV_BUF_SIZE_RSP, 3, 0) < 0) {
			err(DEBUG_CAT_EVENT, "event buffer change fail, no rsp; drop msg; change_buf_len=%d; type=%04x\n",
				change_buf_len, send_event->type);
			return -1;
		} else {
			daemon_cnt = _1905_interface_send_int(ctx, buf, buf_len, dst_dameon);
		}
	}

	return daemon_cnt;
}


int _1905_interface_recv(void *in_ctx, unsigned char* buf, int buf_len)
{
	int res;
	struct sockaddr_un from;
	socklen_t fromlen = sizeof(from);
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx *)in_ctx;

	res = recvfrom(ctx->_1905_ctrl.sock, buf, buf_len, 0,
		       (struct sockaddr *) &from, &fromlen);
	if (res < 0)
		err(DEBUG_CAT_EVENT, "recvfrom fail; errno=%d(%s)\n",
			errno, strerror(errno));

	return res;
}

void _1905_interface_receive_process(int sock, void *eloop_ctx,
	void *sock_ctx)
{
#define RETRY_COUNT 3
	struct p1905_managerd_ctx *ctx = eloop_ctx;
	struct _1905_interface_ctrl* cli_ctrl = NULL;
	char *buf = ctx->_1905_ctrl.sock_buf;
	unsigned short buf_len = ctx->_1905_ctrl.own_recv_buf_len;
	char* daemon_name = NULL;
	int res;
	struct sockaddr_un from;
	socklen_t fromlen = sizeof(from);
	char *reply = NULL, *reply_buf = NULL;
	size_t reply_len = 0;
	int new_attached = 0;
	int retry = 0;

	cli_ctrl = &ctx->_1905_ctrl;
	if (buf == NULL) {
		err(DEBUG_CAT_EVENT, "recv sock buf is null !\n");
		return;
	}
	memset(buf, 0, buf_len);

retry:
	res = recvfrom(sock, buf, buf_len - 1, 0,
		       (struct sockaddr *) &from, &fromlen);
	if (res < 0) {
		if (retry++ <= RETRY_COUNT) {
			err(DEBUG_CAT_EVENT, "recvfrom fail, retry %d times; errno=%d(%s)\n",
				retry, errno, strerror(errno));
			os_sleep(0, 200000);
			goto retry;
		}
		else {
			err(DEBUG_CAT_EVENT, "recvfrom fail; errno=%d(%s)\n",
				errno, strerror(errno));
			return;
		}
	}
	buf[res] = '\0';

	if (strncmp(buf, "ATTACH:", strlen("ATTACH:")) == 0) {
		daemon_name = strchr(buf, ':');
		if (daemon_name != NULL) {
			daemon_name++;
			if (_1905_interface_attach(&cli_ctrl->daemon_cli_list, &from,
							     fromlen, daemon_name)) {
				reply = "FAIL\n";
				reply_len = 5;
			} else {
				new_attached = 1;
				reply = "OK\n";
				reply_len = 3;
			}
		}
	} else if (strncmp(buf, "DETACH", strlen("DETACH")) == 0) {
		if (_1905_interface_detach(&cli_ctrl->daemon_cli_list, &from,
						     fromlen)) {
			reply = "FAIL\n";
			reply_len = 5;
		}else {
			reply = "OK\n";
			reply_len = 3;
		}
	} else {
		_1905_interface_process(ctx, &from, fromlen, buf, res,
							      &reply_buf, &reply_len);
		reply = reply_buf;
	}

	if (reply_len) {
		if (sendto(sock, reply, reply_len, 0, (struct sockaddr *) &from,
			   fromlen) < 0) {
			int _errno = errno;
			if (_errno == ENOBUFS || _errno == EAGAIN) {
				/*
				 * The socket send buffer could be full. This
				 * may happen if client programs are not
				 * receiving their pending messages. Close and
				 * reopen the socket as a workaround to avoid
				 * getting stuck being unable to send any new
				 * responses.
				 */
				sock = _1905_interface_reinit(ctx);
				if (sock < 0)
					err(DEBUG_CAT_EVENT, "fail to reinit _1905_ctrl socket; errno=%d(%s)",
						errno, strerror(errno));
			}
			if (new_attached) {
				err(DEBUG_CAT_EVENT, "Failed to send response to ATTACH - detaching; errno=%d(%s)",
					errno, strerror(errno));
				_1905_interface_detach(&cli_ctrl->daemon_cli_list, &from, fromlen);
			}
		}
	}
	if(reply_buf != NULL)
		free(reply_buf);
}

int _1905_interface_pending(void *in_ctx, struct timeval *tv)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx *)in_ctx;

	fd_set rfds;
	FD_ZERO(&rfds);
	FD_SET(ctx->_1905_ctrl.sock, &rfds);
	select(ctx->_1905_ctrl.sock + 1, &rfds, NULL, NULL, tv);

	return FD_ISSET(ctx->_1905_ctrl.sock, &rfds);
}

int _1905_interface_set_sock_buf(void *in_ctx, unsigned short len)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx *)in_ctx;
	char *buf = NULL;

	if(ctx == NULL || len == 0)
		return -1;

	buf = (char*)malloc(len);
	if (buf == NULL) {
		err(DEBUG_CAT_MISC, "fail to alloc buf\n");
		return -1;
	}
	memset(buf, 0, len);
	if(ctx->_1905_ctrl.sock_buf) {
		free(ctx->_1905_ctrl.sock_buf);
		ctx->_1905_ctrl.sock_buf = NULL;
	}
	ctx->_1905_ctrl.sock_buf = buf;

	return 0;
}
