// SPDX-License-Identifier: MediaTekProprietary

/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 */
/* BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 */
/* The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */
#include <stdlib.h>
#include <stddef.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#ifndef _WIN32_WCE
#include <signal.h>
#include <sys/types.h>
#include <errno.h>
#endif /* _WIN32_WCE */
#include <ctype.h>

#ifndef _MSC_VER
#include <unistd.h>
#endif /* _MSC_VER */
#include <netlink/attr.h>
#include <netlink/route/link.h>
#include <netlink/route/link/vlan.h>

#ifndef CONFIG_NATIVE_WINDOWS
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#ifndef __vxworks
#include <sys/uio.h>
#include <sys/time.h>
#endif /* __vxworks */
#endif /* CONFIG_NATIVE_WINDOWS */

#include <fcntl.h>
#include <openssl/opensslv.h>
#include <openssl/err.h>
#include <openssl/asn1.h>
#include <openssl/asn1t.h>

#include "common.h"
#include "os.h"
#include "base64.h"
#include "json.h"
#include "ip_addr.h"
#include "eloop.h"
#include "ieee802_11_common.h"
#include "ieee802_11_defs.h"
#include "debug.h"
#include "wpabuf.h"
#include "wpa_debug.h"
#include "wifi_utils.h"

#include "wpa_debug.h"

#include <net/if.h>
#include <sys/ioctl.h>
#include "vlan_util.h"

int ifconfig_helper(const char *if_name, int up)
{
	int fd;
	struct ifreq ifr;

	fd = socket(AF_INET, SOCK_STREAM, 0);

	if (fd  < 0) {
		notice(DEBUG_CAT_EMPLUS, "[VLAN] socket(AF_INET,SOCK_STREAM) failed: %s",
			strerror(errno));
		return -1;
	}

	os_memset(&ifr, 0, sizeof(ifr));
	os_strlcpy(ifr.ifr_name, if_name, IFNAMSIZ);

	if (ioctl(fd, SIOCGIFFLAGS, &ifr) != 0) {
		notice(DEBUG_CAT_EMPLUS, "[VLAN] ioctl(SIOCGIFFLAGS) failed for interface %s: %s",
			if_name, strerror(errno));
		close(fd);
		return -1;
	}

	if (up)
		ifr.ifr_flags |= IFF_UP;
	else
		ifr.ifr_flags &= ~IFF_UP;

	if (ioctl(fd, SIOCSIFFLAGS, &ifr) != 0) {
		notice(DEBUG_CAT_EMPLUS, "[VLAN] ioctl(SIOCSIFFLAGS) failed for interface %s (up=%d): %s",
			if_name, up, strerror(errno));
		close(fd);
		return -1;
	}

	close(fd);
	return 0;
}

int ifconfig_up(const char *if_name)
{
	info(DEBUG_CAT_EMPLUS, "[VLAN] Set interface %s up", if_name);
	return ifconfig_helper(if_name, 1);
}

int iface_exists(const char *ifname)
{
	return if_nametoindex(ifname);
}

int ifconfig_down(const char *if_name)
{
	info(DEBUG_CAT_EMPLUS, "[VLAN] Set interface %s down", if_name);
	return ifconfig_helper(if_name, 0);
}


/*
 * Add a vlan interface with name 'vlan_if_name', VLAN ID 'vid' and
 * tagged interface 'if_name'.
 *
 * returns -1 on error
 * returns 1 if the interface already exists
 * returns 0 otherwise
 */
int vlan_add(const char *if_name, int vid, const char *vlan_if_name)
{
	int err, ret = -1;
	struct nl_sock *handle = NULL;
	struct rtnl_link *rlink = NULL;
	int if_idx = 0;

	notice(DEBUG_CAT_EMPLUS, "[VLAN] (if_name=%s, vid=%d, vlan_if_name=%s)",
			if_name, vid, vlan_if_name);

	if ((os_strlen(if_name) + 1) > IFNAMSIZ) {
		notice(DEBUG_CAT_EMPLUS, "[VLAN] Interface name too long: '%s'",
			   if_name);
		return -1;
	}

	if ((os_strlen(vlan_if_name) + 1) > IFNAMSIZ) {
		notice(DEBUG_CAT_EMPLUS, "[VLAN] Interface name too long: '%s'",
			   vlan_if_name);
		return -1;
	}

	handle = nl_socket_alloc();
	if (!handle) {
		notice(DEBUG_CAT_EMPLUS, "[VLAN] failed to open netlink socket");
		goto vlan_add_error;
	}

	err = nl_connect(handle, NETLINK_ROUTE);
	if (err < 0) {
		notice(DEBUG_CAT_EMPLUS, "[VLAN] failed to connect to netlink: %s",
			   nl_geterror(err));
		goto vlan_add_error;
	}

	err = rtnl_link_get_kernel(handle, 0, if_name, &rlink);
	if (err < 0) {
		/* link does not exist */
		notice(DEBUG_CAT_EMPLUS, "[VLAN] interface %s does not exist",
			   if_name);
		goto vlan_add_error;
	}
	if_idx = rtnl_link_get_ifindex(rlink);
	rtnl_link_put(rlink);
	rlink = NULL;

	err = rtnl_link_get_kernel(handle, 0, vlan_if_name, &rlink);
	if (err >= 0) {
		/* link does exist */
		rtnl_link_put(rlink);
		rlink = NULL;
		notice(DEBUG_CAT_EMPLUS, "[VLAN] interface %s already exists",
			   vlan_if_name);
		ret = 1;
		goto vlan_add_error;
	}

	rlink = rtnl_link_alloc();
	if (!rlink) {
		notice(DEBUG_CAT_EMPLUS, "[VLAN] failed to allocate new link");
		goto vlan_add_error;
	}

	err = rtnl_link_set_type(rlink, "vlan");
	if (err < 0) {
		notice(DEBUG_CAT_EMPLUS, "[VLAN] failed to set link type: %s",
			   nl_geterror(err));
		goto vlan_add_error;
	}

	rtnl_link_set_link(rlink, if_idx);
	rtnl_link_set_name(rlink, vlan_if_name);

	err = rtnl_link_vlan_set_id(rlink, vid);
	if (err < 0) {
		notice(DEBUG_CAT_EMPLUS, "[VLAN] failed to set link vlan id: %s",
			   nl_geterror(err));
		goto vlan_add_error;
	}

	err = rtnl_link_add(handle, rlink, NLM_F_CREATE);
	if (err < 0) {
		notice(DEBUG_CAT_EMPLUS, "[VLAN] failed to create link %s for vlan %d on %s (%d): %s",
			   vlan_if_name, vid, if_name, if_idx,
			   nl_geterror(err));
		goto vlan_add_error;
	}

	ret = 0;

vlan_add_error:
	if (rlink)
		rtnl_link_put(rlink);
	if (handle)
		nl_socket_free(handle);
	return ret;
}


int vlan_rem(const char *if_name)
{
	int err, ret = -1;
	struct nl_sock *handle = NULL;
	struct rtnl_link *rlink = NULL;

	notice(DEBUG_CAT_EMPLUS, "[VLAN] (if_name=%s)", if_name);

	handle = nl_socket_alloc();
	if (!handle) {
		notice(DEBUG_CAT_EMPLUS, "[VLAN] failed to open netlink socket");
		goto vlan_rem_error;
	}

	err = nl_connect(handle, NETLINK_ROUTE);
	if (err < 0) {
		notice(DEBUG_CAT_EMPLUS, "[VLAN] failed to connect to netlink: %s",
			   nl_geterror(err));
		goto vlan_rem_error;
	}

	err = rtnl_link_get_kernel(handle, 0, if_name, &rlink);
	if (err < 0) {
		/* link does not exist */
		notice(DEBUG_CAT_EMPLUS, "[VLAN] interface %s does not exists",
			   if_name);
		goto vlan_rem_error;
	}

	err = rtnl_link_delete(handle, rlink);
	if (err < 0) {
		notice(DEBUG_CAT_EMPLUS, "[VLAN] failed to remove link %s: %s",
			   if_name, nl_geterror(err));
		goto vlan_rem_error;
	}

	ret = 0;

vlan_rem_error:
	if (rlink)
		rtnl_link_put(rlink);
	if (handle)
		nl_socket_free(handle);
	return ret;
}


int vlan_set_name_type(unsigned int name_type)
{
	return 0;
}
