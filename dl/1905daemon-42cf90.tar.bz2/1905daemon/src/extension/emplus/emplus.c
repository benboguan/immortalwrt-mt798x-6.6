// SPDX-License-Identifier: MediaTekProprietary
/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */
#ifdef EM_PLUS_SUPPORT
#include <stdio.h>
#include <string.h>
#include <syslog.h>
#include <assert.h>
#include <linux/if_ether.h>
#include <asm/byteorder.h>
#include <stdlib.h>
#include <pthread.h>
#include "multi_ap.h"
#include "cmdu_message.h"
#include "cmdu.h"
#include "os.h"
#include "common.h"
#include "debug.h"
#include "_1905_lib_io.h"
#include "file_io.h"
#include "message_wait_queue.h"
#include "topology.h"
#include "mapfilter_if.h"
#include "ethernet_layer.h"
#include "emplus.h"
#include "cmdu_tlv.h"
#include <ctype.h>
#include <sys/sysinfo.h>
u8 EMPLUS_OUI[OUI_LEN] = {0x88, 0x41, 0xFC};

#define _PATH_PROCNET_DEV "/proc/net/dev"

unsigned short get_msg_hdr(unsigned char *buf)
{
	unsigned short mtype = 0;

	mtype = *(unsigned short *)(buf);
	mtype = be_to_host16(mtype);

	return mtype;
}

void variable64_to_buf48(u8 *buf, u64 variable)
{
	if (buf == NULL) {
		err(DEBUG_CAT_EMPLUS, "buf is null\n");
		return;
	}
	*(buf) = (u8)(variable >> 40);
	*(buf + 1) = (u8)(variable >> 32);
	*(buf + 2) = (u8)(variable >> 24);
	*(buf + 3) = (u8)(variable >> 16);
	*(buf + 4) = (u8)(variable >> 8);
	*(buf + 5) = (u8)(variable);
}
const char *getFeatureName(int featureID)
{
	static const char * const featureNames[] = {
		[EMPLUS_DEV_METRICES_ID] = "DEV_METRICES_ID",
		[EMPLUS_SUPPORT_1905_2014] = "SUPPORT_1905_2014",
		[EMPLUS_DEV_INFO_ID] = "DEV_INFO_ID",
		[EMPLUS_ETH_STATS_ID] = "ETH_STATS_ID",
		[EMPLUS_REBOOT_REQ_ID] = "REBOOT_REQ_ID",
		[EMPLUS_SUPPORT_WIFI6] = "SUPPORT_WIFI6",
		[EMPLUS_SUPPORT_DPP] = "SUPPORT_DPP",
		[EMPLUS_SUPPORT_STP] = "SUPPORT_STP",
		[EMPLUS_SUPPORT_LED_ID] = "SUPPORT_LED_ID",
		[EMPLUS_SUPPORT_WIFI_SWTICH] = "SUPPORT_WIFI_SWTICH",
		[EMPLUS_SUPPORT_HIDDEN_SSID] = "SUPPORT_HIDDEN_SSID",
		[EMPLUS_SUPPORT_RADIO_MODE_SHARING] = "SUPPORT_RADIO_MODE_SHARING"
	};

	if (featureID >= 1 && featureID <= 16 && featureNames[featureID] != NULL)
		return featureNames[featureID];
	else
		return "Unknown Feature ID";
}

unsigned short append_emplus_message_vendor_specific_type_tlv(unsigned char *pkt, unsigned short type)
{
	/*
	 * 1905 emplus vendor specific tlv format
	 * type			1 byte			0x0b
	 * length		2 bytes			n
	 * oui			3 bytes			0x88, 0x41, 0xFC
	 * function type	2 byte			0xxxxx
	 * sub func type	2 byte			0xxxxx
	 */
	unsigned char *temp_buf = pkt;
	unsigned char *old_p = NULL;
	unsigned char len = 0;
	unsigned short total_length = 0;

	/*vendor specific tlv type*/
	*temp_buf++ = VENDOR_SPECIFIC_TLV_TYPE;

	/*shift to OUI field*/
	old_p = temp_buf;
	temp_buf += 2;

	/*emplus oui*/
	os_memcpy(temp_buf, EMPLUS_OUI, sizeof(EMPLUS_OUI));
	temp_buf += 3;

	/*function type*/
	*((unsigned short *)temp_buf) = host_to_be16(EMPLUS_MESG_TYPE);
	temp_buf += 2;

	/*emplus subtype*/
	*((unsigned short *)temp_buf) = host_to_be16(type);
	temp_buf += 2;

	len = (unsigned short) (temp_buf - old_p - 2);
	*((unsigned short *)old_p) = host_to_be16(len);

	total_length = len + 3;

	return total_length;
}

int delete_emplus_feature_list(struct p1905_managerd_ctx *ctx)
{

	struct emplus_feature_list *p_tmp_feature = NULL, *p_next_feature = NULL;

	if (!SLIST_EMPTY(&ctx->feature_prof.feature_list_head)) {
		p_tmp_feature = SLIST_FIRST(&ctx->feature_prof.feature_list_head);
		while (p_tmp_feature) {
			p_next_feature = SLIST_NEXT(p_tmp_feature, next);
			SLIST_REMOVE(&ctx->feature_prof.feature_list_head, p_tmp_feature, emplus_feature_list, next);
			free(p_tmp_feature);
			p_tmp_feature = p_next_feature;
		}
	}

	return 0;
}

int insert_emplus_feature_list(struct p1905_managerd_ctx *ctx,
		unsigned short feature_id,
		unsigned short feature_ver)
{
	struct emplus_feature_prof *feature_prof = &ctx->feature_prof;
	struct emplus_feature_list *feat_list = NULL;

	feat_list = os_malloc(sizeof(struct emplus_feature_list));
	if (feat_list == NULL) {
		err(DEBUG_CAT_EMPLUS, "feat_list os_malloc fail\n");
		return -1;
	}
	feat_list->feature_id = feature_id;
	feat_list->feature_ver = feature_ver;

	SLIST_INSERT_HEAD(&feature_prof->feature_list_head, feat_list, next);
	return 0;
}


unsigned short append_emplus_feature_prof_tlv(unsigned char *pkt,
						struct emplus_feature_prof *feat_prof)
{
	unsigned short total_length = 0;
	unsigned char *temp_buf;
	unsigned short len = 0, *feature_num, num = 0;
	unsigned char *old_p = NULL;
	struct emplus_feature_list *feat_list;

	temp_buf = pkt;
	*temp_buf = VENDOR_SPECIFIC_TLV_TYPE;
	temp_buf += 1;

	/*skip tlv length*/
	old_p = temp_buf;
	temp_buf += 2;

	/*emplus oui*/
	os_memcpy(temp_buf, EMPLUS_OUI, sizeof(EMPLUS_OUI));
	temp_buf += 3;

	/*emplus tlv ID*/
	*((unsigned short *)temp_buf) = host_to_be16(EMPLUS_FEATURE_PROFILE);
	temp_buf += 2;

	/*version*/
	*((unsigned short *)temp_buf) = host_to_be16(feat_prof->master_ver);
	temp_buf += 2;
	*((unsigned short *)temp_buf) = host_to_be16(feat_prof->sub_ver);
	temp_buf += 2;

	/*skip the num of feature announced*/
	feature_num = (unsigned short *)temp_buf;
	temp_buf += 2;

	if (!SLIST_EMPTY(&feat_prof->feature_list_head)) {
		SLIST_FOREACH(feat_list, &feat_prof->feature_list_head, next) {
			*((unsigned short *)temp_buf) = host_to_be16(feat_list->feature_id);
			temp_buf += 2;
			*((unsigned short *)temp_buf) = host_to_be16(feat_list->feature_ver);
			temp_buf += 2;
			num++;
		}
	}

	len = (unsigned short)(temp_buf - old_p - 2);
	*((unsigned short *)old_p) = host_to_be16(len);

	*feature_num = host_to_be16(num);

	*(unsigned short *)(temp_buf) = host_to_be16(SEARCHED_SERVICE_LENGTH);

	total_length = len + 3;
	return total_length;
}

unsigned short append_emplus_dev_info_tlv(unsigned char *pkt, struct p1905_managerd_ctx *ctx)
{
	unsigned short total_length = 0;
	unsigned char *temp_buf;
	unsigned short len = 0;
	unsigned int boot_id = 0;
	unsigned char *old_p = NULL;

	temp_buf = pkt;
	*temp_buf = VENDOR_SPECIFIC_TLV_TYPE;
	temp_buf += 1;

	/*skip tlv length*/
	old_p = temp_buf;
	temp_buf += 2;

	/*emplus oui*/
	os_memcpy(temp_buf, EMPLUS_OUI, sizeof(EMPLUS_OUI));
	temp_buf += 3;

	/*emplus tlv ID*/
	*((unsigned short *)temp_buf) = host_to_be16(EMPLUS_DEV_INFO);
	temp_buf += 2;


	/* emplus bootid*/
	boot_id = ctx->boot_id;
	*((unsigned int *)temp_buf) = host_to_be32(boot_id);
	temp_buf += 4;

	/* emplus client_id and secret */
	*temp_buf = ctx->client_id_len;
	temp_buf +=  1;

	os_memcpy(temp_buf, ctx->client_id, ctx->client_id_len);
	temp_buf += ctx->client_id_len;

	*temp_buf = ctx->client_secret_len;
	temp_buf += 1;

	os_memcpy(temp_buf, ctx->client_secret, ctx->client_secret_len);
	temp_buf += ctx->client_secret_len;

	/* emplus product class*/
	*temp_buf |= ctx->emplus_product_class;
	temp_buf += 1;

	/* emplus dev role */
	*temp_buf |= ctx->emplus_role;
	temp_buf += 1;

	len = (unsigned short)(temp_buf - old_p - 2);
	*((unsigned short *)old_p) = host_to_be16(len);

	total_length = len + 3;

	return total_length;

}

void emplus_off_interface(struct p1905_managerd_ctx *ctx, unsigned char idex)
{
	unsigned char bss_idx = 0;

	notice(DEBUG_CAT_EMPLUS, "current radio("MACSTR") will wifi off\n",
		PRINT_MAC(ctx->rinfo[idex].identifier));

	ctx->rinfo[idex].teared_down = 1;

	for (bss_idx = 0; bss_idx < ctx->rinfo[idex].bss_number; bss_idx++)
		ctx->rinfo[idex].bss[bss_idx].config_status = 0;

	/* delete_exist_operational_bss(ctx, ctx->rinfo[idex].identifier); */

	/*to do wifi off this radio */
	_1905_set_radio_wifi_off(ctx, ctx->rinfo[idex].identifier);

}

int emplus_cntlr_interface(struct p1905_managerd_ctx *ctx, unsigned char type)
{
	unsigned char vendor_extension = 0;
	signed char radio_index = 0;
	int i = 0;

	for (i = 0; i < ctx->current_autoconfig_info.config_number; i++)
		vendor_extension |= ctx->current_autoconfig_info.config_data[i].map_vendor_extension;

	radio_index = (unsigned char)ctx->current_autoconfig_info.radio_index;

	if ((vendor_extension & BIT_FH_BSS) &&
		(ctx->current_autoconfig_info.radio_index != -1)) {
		if (!type) {
			emplus_off_interface(ctx, radio_index);
		} else if (type &&
				wifi_utils_success != set_wsc_config((void *)ctx)) {
			err(DEBUG_CAT_EMPLUS, "set wsc config error for radio("MACSTR")\n",
					PRINT_MAC(ctx->rinfo[radio_index].identifier));
			return -1;
		}
	}

	return 0;
}

int reboot_and_reset(u8 reboot_type, u8 reset_type)
{
	notice(DEBUG_CAT_EMPLUS,
		"emplus reboot is implemented by odm, reboot_type=%d, reset_type =%d(0:reset 1:reset+reboot)\n",
		(int)reboot_type, (int)reset_type);
	return 0;
}

void emplus_reboot_reset(u8 reboot_type, u8 reset_type)
{

	reboot_and_reset(reboot_type, reset_type);

}

int led_turn_off(void)
{
	notice(DEBUG_CAT_EMPLUS,
		"emplus led turn off function is implemented by odm\n");
	return 0;
}

void emplus_led_turn_off(void)
{
	led_turn_off();
}
int parse_emplus_vs_tlv(struct p1905_managerd_ctx *ctx,
						unsigned short len, unsigned char *value)
{
	int left;
	unsigned char *temp_buf = NULL;
	unsigned short func_type;
	unsigned char service_status = 0, status_reason = 0;
	unsigned short backhaul_on_time = 0, backhaul_off_time = 0;

	if (len == 0)
		return -1;
	if (value == NULL)
		return -1;

	left = len;
	temp_buf = value;

	if (left < sizeof(EMPLUS_OUI) + 1) {
		err(DEBUG_CAT_EMPLUS, "left=%d less than %d\n",
			left, (unsigned int)(sizeof(EMPLUS_OUI) + 1));
		goto error;
	}

	if (os_memcmp(temp_buf, EMPLUS_OUI, 3)) {
		info(DEBUG_CAT_EMPLUS, "it isn`t EMPLUS OUI; do not handle!\n");
		return 0;
	}

	left -= sizeof(EMPLUS_OUI);
	temp_buf += 3;

	if (left < 2)
		return -1;

	func_type = get_msg_hdr(temp_buf);
	if (!(func_type >= EMPLUS_MESG_TYPE && func_type <= EMPLUS_REBOOT_REQ) &&
		!(func_type >= EMPLUS_LED_STATS && func_type <= EMPLUS_ETH_NON_1905_NEIG_DEV_LIST)) {
		notice(DEBUG_CAT_EMPLUS, "func_type 0x%04x not support\n", func_type);
		return -1;
	}
	left -= 2;
	temp_buf += 2;

	switch (func_type) {
	case EMPLUS_SERVICE_STATS:
		if (left < EMPLUS_SERVICE_INFO_LEN) {
			err(DEBUG_CAT_EMPLUS, "emplus service tlv len=%d!\n", len);
			goto error;
		}
		service_status = *temp_buf++;
		left -= 1;
		temp_buf += 1;

		if (service_status & EMPLUS_BIT_FH_BSS) {
			info(DEBUG_CAT_EMPLUS, "emplus let front bss tear down.\n");
			emplus_cntlr_interface(ctx, EMPLUS_OFF);
		} else {
			emplus_cntlr_interface(ctx, EMPLUS_ON);
		}

		if (service_status & EMPLUS_BIT_BH_BSS) {
			info(DEBUG_CAT_EMPLUS, "emplus let backhual bss tear down.\n");
			/*TBD*/
		}
		if (service_status & EMPLUS_BIT_BH_STA) {
			info(DEBUG_CAT_EMPLUS, "emplus let backhaul sta tear down.\n");
			/*TBD*/
		}
		if (service_status & EMPLUS_BIT_ETH) {
			info(DEBUG_CAT_EMPLUS, "emplus let ETH tear down.\n");
			/*TBD*/
		}
		if (service_status & EMPLUS_BIT_NON_1905) {
			info(DEBUG_CAT_EMPLUS, "emplus let non_1905 tear down.\n");
			/*TBD*/
		}
		if (left < 5)
			return -1;
		status_reason = *temp_buf++;
		if (status_reason > UNKNOWN_REASON) {
			warn(DEBUG_CAT_EMPLUS, "The status reason for the '%d', service is missing", status_reason);
			return 0;
		}
		left -= 1;
		temp_buf += 1;

		if (left < 4)
			return -1;

		backhaul_on_time = *temp_buf;
		left -= 2;
		temp_buf += 2;

		if (left < 2)
			return -1;
		backhaul_off_time = *temp_buf;
		left -= 2;
		temp_buf += 2;

		info(DEBUG_CAT_EMPLUS,
			"Controller status_reason %d, backhaul_on_time = %d, backhaul_off_time %d\n",
			status_reason, backhaul_on_time, backhaul_off_time);

		break;
	case EMPLUS_REBOOT_REQ:
	{
		u8 reboot_type = 0, reset_type = 0;
		u8 reboot = 0, factory_reset = 0;

		if (left < 1) {
			err(DEBUG_CAT_EMPLUS, "emplus reboot tlv len=%d, left=%d\n", len, left);
			goto error;
		}
		/* reboot action request */
		reboot_type = *temp_buf;
		left -= 1;

		if (reboot_type == EMPLUS_REBOOT_REQ_REBOOT_ONLY) {
			reboot = 1;
			factory_reset = 0;
		} else if ((reboot_type == EMPLUS_REBOOT_REQ_REBOOT_RESET) && (left > 0)) {
			temp_buf += 1;
			reset_type = *temp_buf;
			/* -optional- byte is for reset type */
			if (reset_type == EMPLUS_REBOOT_REQ_RESET_ONLY)
				factory_reset = 0;
			else if (reset_type == EMPLUS_REBOOT_REQ_FACTORY_RESET)
				factory_reset = 1;
		}
		emplus_reboot_reset(reboot, factory_reset);
	}
		break;
	case EMPLUS_LED_STATS:
	{
		u8 led_status = 0;

		if (left < 1) {
			err(DEBUG_CAT_EMPLUS, "emplus led status tlv len=%d, left=%d\n", len, left);
			goto error;
		}
		led_status = *temp_buf;
		if (led_status & EMPLUS_LED_OFF)
			emplus_led_turn_off();/*the function is not implemented*/
	}
		break;
	default:
		break;
	}

	return 0;
error:
	err_hexdump(DEBUG_CAT_EMPLUS, "dump emplus vs tlv", value, len);
	return -1;

}

static int proc_netdev_ver(char *buf)
{
	if (strstr(buf, "compressed"))
		return 2;
	if (strstr(buf, "bytes"))
		return 1;
	return 0;
}

char *os_rm_space(const char *s)
{
/* In POSIX/C locale (the only locale we care about: do we REALLY want
 * to allow Unicode whitespace in, say, .conf files? nuts!)
 * isspace is only these chars: "\t\n\v\f\r" and space.
 * "\t\n\v\f\r" happen to have ASCII codes 9,10,11,12,13.
 * Use that.
 */
	while (*s == ' ' || (unsigned char)(*s - 9) <= (13 - 9))
		s++;

	return (char *) s;
}
/* Extract <name> from nul-terminated p where p matches
 * <name>: after leading whitespace.
 * If match is not made, set name empty and return unchanged p
 */
static char *netdev_proc_get_name(char *name, char *p)
{
	char *nameend = NULL;
	char *namestart = os_rm_space(p);

	nameend = namestart;
	while (*nameend && *nameend != ':' && !isspace(*nameend))
		nameend++;
	if (*nameend == ':') {
		if ((nameend - namestart) < IFNAMSIZ) {
			memcpy(name, namestart, nameend - namestart);
			name[nameend - namestart] = '\0';
			p = nameend;
		} else {
			/* Interface name too large */
			name[0] = '\0';
		}
	} else {
		/* trailing ':' not found - return empty */
		name[0] = '\0';
	}
	return p + 1;
}


static void netdev_proc_get_dev_fields(char *bp, struct net_proc_inf *ife, int procnetdev_vsn)
{
	int scf;
	static const char *const ss_fmt[] = {"%n%llu%lu%lu%lu%lu%n%n%n%llu%lu%lu%lu%lu%lu",
					"%llu%llu%lu%lu%lu%lu%n%n%llu%llu%lu%lu%lu%lu%lu",
					"%llu%llu%lu%lu%lu%lu%lu%lu%llu%llu%lu%lu%lu%lu%lu%lu"};

	memset(&ife->stats, 0, sizeof(struct user_net_device_stats));

	scf = sscanf(bp, ss_fmt[procnetdev_vsn], &ife->stats.rx_bytes, /* missing for 0 */
	       &ife->stats.rx_packets, &ife->stats.rx_errors, &ife->stats.rx_dropped, &ife->stats.rx_fifo_errors,
	       &ife->stats.rx_frame_errors, &ife->stats.rx_compressed, /* missing for <= 1 */
	       &ife->stats.rx_multicast,			       /* missing for <= 1 */
	       &ife->stats.tx_bytes,				       /* missing for 0 */
	       &ife->stats.tx_packets, &ife->stats.tx_errors, &ife->stats.tx_dropped, &ife->stats.tx_fifo_errors,
	       &ife->stats.collisions, &ife->stats.tx_carrier_errors, &ife->stats.tx_compressed /* missing for <= 1 */
	);

	if (scf <= 0)
		err(DEBUG_CAT_EMPLUS, "sscanf err, scf: %d\n", scf);

	if (procnetdev_vsn <= 1) {
		if (procnetdev_vsn == 0) {
			ife->stats.rx_bytes = 0;
			ife->stats.tx_bytes = 0;
		}
		ife->stats.rx_multicast = 0;
		ife->stats.rx_compressed = 0;
		ife->stats.tx_compressed = 0;
	}
}

static int get_net_stat_proc(char *if_name, struct itf_stats *itf_stat_info)
{
	FILE *fh = NULL;
	char buf[512] = {0}, *s = NULL;
	struct net_proc_inf *ife = NULL, *ife_entry = NULL;
	int proc_netdev_vsn = 0, idx = 0, inf_cnt = 0;

	if (if_name == NULL) {
		err(DEBUG_CAT_EMPLUS, "if_name is null.\n");
		return -1;
	}

	if (itf_stat_info == NULL) {
		err(DEBUG_CAT_EMPLUS, "itf_stat_info is null.\n");
		return -1;
	}

	ife = os_zalloc(sizeof(struct net_proc_inf) * ITF_NUM);
	if (!ife) {
		err(DEBUG_CAT_EMPLUS, "os_zalloc fail\n");
		return -1;
	}

	fh = fopen(_PATH_PROCNET_DEV, "r");
	if (!fh) {
		err(DEBUG_CAT_EMPLUS, "open %s fail.\n", _PATH_PROCNET_DEV);
		/*free memory*/
		if (ife)
			os_free(ife);
		return -1;
	}

	(void)fgets(buf, sizeof(buf), fh); /* eat line */
	(void)fgets(buf, sizeof(buf), fh); /* eat line */

	proc_netdev_vsn = proc_netdev_ver(buf);
	os_memset(buf, 0, sizeof(buf));
	while (fgets(buf, sizeof(buf), fh) && inf_cnt < ITF_NUM) {
		char name[15] = {0};

		if (os_strlen(buf) >= 512) {
			err(DEBUG_CAT_EMPLUS, "fget buf len %ld invalid\n", os_strlen(buf));
			continue;
		}
		s = netdev_proc_get_name(name, buf);
		os_memset(ife[inf_cnt].name, 0, IFNAMSIZ);
		(void)os_snprintf(ife[inf_cnt].name, IFNAMSIZ, "%s", name);
		netdev_proc_get_dev_fields(s, &ife[inf_cnt], proc_netdev_vsn);
		ife[inf_cnt].statistics_valid = 1;
		inf_cnt++;
		os_memset(buf, 0, sizeof(buf));
	}

	for (idx = 0; idx < ITF_NUM; idx++) {
		ife_entry = &ife[idx];
		if (ife_entry && !os_strcmp(if_name, ife_entry->name)) {
			itf_stat_info->tx_err_pkts = ife_entry->stats.tx_errors;
			itf_stat_info->rx_err_pkts = ife_entry->stats.rx_errors;
			if (fh)
				(void)fclose(fh);
			os_free(ife);
			return 0;
		}
	}
	/*close file*/
	if (fh)
		(void)fclose(fh);
	os_free(ife);
	return -1;
}
unsigned short append_emplus_eth_host_stats_tlv(struct p1905_managerd_ctx *ctx, unsigned char *pkt)
{
	u8 *temp_buf = NULL, *old_p = NULL, *port_num_p = NULL;
	u16 len = 0, total_length = 0;
	int port_num = 0;
	u8 port_id = 0;
	int i = 0, ret = 0;
	struct port_stat port_stats = { 0 };
	u8 buf[6] = { 0 };
	struct itf_stats itf_stat_info = { 0 };

	temp_buf = pkt;
	*temp_buf = VENDOR_SPECIFIC_TLV_TYPE;
	temp_buf += 1;
	/*skip tlv length*/
	old_p = temp_buf;
	temp_buf += 2;
	/*emplus oui*/
	os_memcpy(temp_buf, EMPLUS_OUI, sizeof(EMPLUS_OUI));
	temp_buf += 3;
	/*emplus tlv ID*/
	*((unsigned short *)temp_buf) = host_to_be16(EMPLUS_ETH_STATS);
	temp_buf += 2;
	/*support extra stats*/
	*((unsigned short *)temp_buf) = 0;
	temp_buf += 2;
	/*number of operational Ethernet PHYs/ports*/
	port_num_p = temp_buf;
	temp_buf += 1;
	for (i = 0; i < ctx->itf_number; i++) {
		if (ctx->itf[i].media_type <= IEEE802_3_AB_GROUP) {
			/*Unique Ethernet port identifier on a network node*/
			ret = eth_layer_get_eth_port_id_by_mac(ctx->itf[i].mac_addr, &port_id);
			if (ret < 0) {
				err(DEBUG_CAT_EMPLUS, "eth_layer_get_eth_port_id_by_mac fail\n");
				continue;
			}
			*temp_buf = (u8)port_id;
			temp_buf += 1;
			ret = eth_layer_get_eth_port_statics(port_id, &port_stats);
			if (ret < 0) {
				err(DEBUG_CAT_EMPLUS, "eth_layer_get_eth_port_statics fail\n");
				continue;
			}
			/*ByteSent*/
			variable64_to_buf48(buf, port_stats.bytes_sent);
			os_memcpy(temp_buf, buf, 6);
			temp_buf += 6;
			/*ByteReceived*/
			variable64_to_buf48(buf, port_stats.bytes_received);
			os_memcpy(temp_buf, buf, 6);
			temp_buf += 6;
			/*PacketSent*/
			variable64_to_buf48(buf, (u64)port_stats.packets_sent);
			os_memcpy(temp_buf, buf, 6);
			temp_buf += 6;
			/*PacketReceived*/
			variable64_to_buf48(buf, (u64)port_stats.packets_received);
			os_memcpy(temp_buf, buf, 6);
			temp_buf += 6;
			ret = get_net_stat_proc((char *)ctx->itf[i].if_name, &itf_stat_info);
			if (ret < 0) {
				err(DEBUG_CAT_EMPLUS, "get_net_stat_proc fail\n");
				return -1;
			}
			/*TxPacketsErrors*/
			variable64_to_buf48(buf, (u64)itf_stat_info.tx_err_pkts);
			os_memcpy(temp_buf, buf, 6);
			temp_buf += 6;
			/*RxPacketsErrors*/
			variable64_to_buf48(buf, (u64)itf_stat_info.rx_err_pkts);
			os_memcpy(temp_buf, buf, 6);
			temp_buf += 6;
			port_num++;
			info(DEBUG_CAT_EMPLUS,
				"port_id=%d, bytes_sent=%lld, bytes_received=%lld, packets_sent=%d,packets_received=%d\n",
				port_id, port_stats.bytes_sent, port_stats.bytes_received, port_stats.packets_sent,
				port_stats.packets_received);
		}
	}
	*port_num_p = (u8)port_num;
	len = (unsigned short)(temp_buf - old_p - 2);
	*((unsigned short *)old_p) = host_to_be16(len);
	total_length = len + 3;
	return total_length;
}

unsigned short append_emplus_eth_interface_tlv(struct p1905_managerd_ctx *ctx, unsigned char *pkt)
{
	u8 *temp_buf = NULL, *old_p = NULL, *port_num_p = NULL;
	u16 len = 0, total_length = 0;
	u8 port_num = 0, i = 0;
	size_t name_len = 0;
	int duplexMode = 0, link_status = 0, link_rate = 0, ret = 0;
	u8 port_id = 0;
	int admin_tatus = 0;

	temp_buf = pkt;
	*temp_buf = VENDOR_SPECIFIC_TLV_TYPE;
	temp_buf += 1;
	/*skip tlv length*/
	old_p = temp_buf;
	temp_buf += 2;
	/*emplus oui*/
	os_memcpy(temp_buf, EMPLUS_OUI, sizeof(EMPLUS_OUI));
	temp_buf += 3;
	/*emplus tlv ID*/
	*((unsigned short *)temp_buf) = host_to_be16(EMPLUS_ETH_INTERFACE);
	temp_buf += 2;
	/*number of operational Ethernet PHYs/ports*/
	port_num_p = temp_buf;
	temp_buf += 1;
	for (i = 0; i < ctx->itf_number; i++) {
		if (ctx->itf[i].media_type <= IEEE802_3_AB_GROUP) {
			/*Unique Ethernet port identifier on a network node*/
			ret = eth_layer_get_eth_port_id_by_mac(ctx->itf[i].mac_addr, &port_id);
			if (ret < 0) {
				err(DEBUG_CAT_EMPLUS, "eth_layer_get_eth_port_id_by_mac fail\n");
				continue;
			}
			*temp_buf = (u8)port_id;
			temp_buf++;
			/*thernet port’s EUI-48 MAC address*/
			os_memcpy(temp_buf, ctx->itf[i].mac_addr, ETH_ALEN);
			temp_buf += ETH_ALEN;
			/*Length of the Ethernet interface name*/
			name_len = os_strlen((char *)ctx->itf[i].if_name);
			*temp_buf = (u8)name_len;
			temp_buf++;
			/*Ethernet interface name*/
			os_memcpy(temp_buf, ctx->itf[i].if_name, name_len);
			temp_buf += name_len;
			/*Admin state of the Ethernet port*/
			*temp_buf = 0;
			admin_tatus = eth_layer_get_eth_port_admin_status(port_id);
			/*AdminStatus, 1:up, 0:down*/
			if (admin_tatus == 1)
				*temp_buf |= BIT(7);
			/*Link state of the Ethernet port, link_status :"0:down, 1:up,2:disconnect"*/
			link_status = eth_layer_update_eth_port_status(port_id);
			if (link_status == 1)
				*temp_buf |= BIT(6);
			/*Duplex mode of the Ethernet port, DuplexMode :"0:auto, 1:half,2:full"*/
			duplexMode = eth_layer_get_eth_port_duplex_mode(port_id);
			if (duplexMode == 2)
				*temp_buf |= BIT(5);
			temp_buf++;
			*temp_buf = 0;
			link_rate = eth_layer_get_eth_port_linkrate(port_id);
			if (link_rate != -1) {
				/*Supported Link Type*/
				*temp_buf |= link_rate << 4;
				/*Current Link Type*/
				*temp_buf |= link_rate;
			} else
				*temp_buf = 0;
			info(DEBUG_CAT_EMPLUS, "name_len = %d,link_status=%d, duplexMode=%d, admin_tatus=%d, link_rate=%d\n",
					(int)name_len, link_status, duplexMode, admin_tatus, link_rate);
			temp_buf++;
			port_num++;
		}
	}
	*port_num_p = port_num;
	len = (unsigned short)(temp_buf - old_p - 2);
	*((unsigned short *)old_p) = host_to_be16(len);
	total_length = len + 3;
	return total_length;
}

unsigned short append_emplus_non_1905_neighbor_device_type_tlv(struct p1905_managerd_ctx *ctx, unsigned char *pkt,
	struct non_p1905_neighbor *devlist)
{
	unsigned short total_length = 0, len = 0;
	unsigned char *temp_buf = NULL, *non_1905_buf = NULL;
	unsigned char *old_p = NULL, *port_num_p = NULL, *non_1905dev_num_p = NULL;
	unsigned char port_id = 0;
	int num = 0, port_num = 0, non_1905dev_num = 0, ret = 0;
	struct non_p1905_neighbor_info *info = NULL;

	temp_buf = pkt;
	*temp_buf = VENDOR_SPECIFIC_TLV_TYPE;
	temp_buf += 1;
	/*skip tlv length*/
	old_p = temp_buf;
	temp_buf += 2;
	/*emplus oui*/
	os_memcpy(temp_buf, EMPLUS_OUI, sizeof(EMPLUS_OUI));
	temp_buf += 3;
	/*emplus tlv ID*/
	*((unsigned short *)temp_buf) = host_to_be16(EMPLUS_ETH_NON_1905_NEIG_DEV_LIST);
	temp_buf += 2;
	/*Number of operational Ethernet PHYs/Ports*/
	port_num_p = temp_buf;
	temp_buf += 1;
	non_1905_buf = temp_buf;
	for (num = 0; num < ctx->itf_number; num++) {
		if (!LIST_EMPTY(&(devlist[num].non_p1905nbr_head))) {
			/*Unique Ethernet port index on a network node*/
			ret = eth_layer_get_eth_port_id_by_mac(devlist[num].local_mac_addr, &port_id);
			if (ret < 0) {
				err(DEBUG_CAT_EMPLUS, "eth_layer_get_eth_port_id_by_mac fail\n");
				continue;
			}
			port_num++;
			*temp_buf = (u8)port_id;
			temp_buf += 1;
			/*Number of non 1905 neighbor MACs*/
			non_1905dev_num_p = temp_buf;
			temp_buf += 1;
			LIST_FOREACH(info, &(devlist[num].non_p1905nbr_head), non_p1905nbr_entry)
			{
				/*Non 1905 neighbor EUI-48 MAC Address*/
				os_memcpy(temp_buf, info->itf_mac_addr, ETH_ALEN);
				temp_buf += ETH_ALEN;
				port_id = info->port_index;
				non_1905dev_num++;
			}
			*non_1905dev_num_p = non_1905dev_num;
			non_1905dev_num = 0;
		}
	}
	if ((port_num == 0) ||
		((temp_buf - non_1905_buf) == 0))
		debug(DEBUG_INFO, "No non-1905 devices in list!\n");

	*port_num_p = port_num;
	len = (unsigned short)(temp_buf - old_p - 2);
	*((unsigned short *)old_p) = host_to_be16(len);
	total_length = len + 3;


	return total_length;
}

unsigned short append_emplus_1905_neighbor_device_type_tlv(struct p1905_managerd_ctx *ctx, unsigned char *pkt,
	struct p1905_neighbor *devlist)
{
	unsigned short total_length = 0, len = 0;
	unsigned char *old_p = NULL, *port_num_p = NULL, *neigh_1905dev_p = NULL, *temp_buf = NULL;
	unsigned char port_num = 0, port_id = 0;
	int num = 0, neigh_1905dev_num = 0, ret = 0;
	struct p1905_neighbor_info *info = NULL;

	temp_buf = pkt;
	*temp_buf = VENDOR_SPECIFIC_TLV_TYPE;
	temp_buf += 1;
	/*skip tlv length*/
	old_p = temp_buf;
	temp_buf += 2;
	/*emplus oui*/
	os_memcpy(temp_buf, EMPLUS_OUI, sizeof(EMPLUS_OUI));
	temp_buf += 3;
	/*emplus tlv ID*/
	*((unsigned short *)temp_buf) = host_to_be16(EMPLUS_ETH_1905_NEIG_DEV_LIST);
	temp_buf += 2;
	/*Number of operational Ethernet PHYs/Ports*/
	port_num_p = temp_buf;
	temp_buf += 1;
	for (num = 0; num < ctx->itf_number; num++) {
		if (ctx->itf[num].media_type > IEEE802_3_AB_GROUP)
			continue;
		if (!LIST_EMPTY(&(devlist[num].p1905nbr_head))) {
			/*Unique Ethernet port index on a network node*/
			ret = eth_layer_get_eth_port_id_by_mac(devlist[num].local_mac_addr, &port_id);
			if (ret < 0) {
				err(DEBUG_CAT_EMPLUS, "eth_layer_get_eth_port_id_by_mac fail\n");
				continue;
			}
			port_num++;
			*temp_buf = (u8)port_id;
			temp_buf++;
			/*Number of non 1905 neighbor MACs*/
			neigh_1905dev_p = temp_buf;
			temp_buf++;
			LIST_FOREACH(info, &(devlist[num].p1905nbr_head), p1905nbr_entry)
			{
				neigh_1905dev_num++;
				/*1905 neighbor EUI-48 MAC Address*/
				os_memcpy(temp_buf, info->al_mac_addr, ETH_ALEN);
				temp_buf += ETH_ALEN;
			}
			*neigh_1905dev_p = neigh_1905dev_num;
			neigh_1905dev_num = 0;
		}
	}
	/*Number of operational Ethernet PHYs/Ports*/

	*port_num_p = port_num;
	len = (unsigned short)(temp_buf - old_p - 2);
	*((unsigned short *)old_p) = host_to_be16(len);
	total_length = len + 3;

	return total_length;
}

static int _mtk_os_read_cpu_stat(struct stat_cpu *stat)
{
	FILE *fp;
	char buf[128];
	int scf;
	int ret = 0;

	fp = fopen("/proc/stat", "r");
	if (fp == NULL) {
		err(DEBUG_CAT_EMPLUS, "open /proc/stat error\n");
		return -1;
	}
	if (fgets(buf, 128, fp) && buf[0] == 'c' && buf[1] == 'p' && buf[2] == 'u' && buf[3] == ' ') {
		/* user nice system idle iowait irq softirq steal guest */
		scf = sscanf(&buf[4], "%u %u %u %u %u %u %u %u %u", &stat->user, &stat->nice, &stat->system, &stat->idle,
		       &stat->iowait, &stat->steal, &stat->irq, &stat->softirq, &stat->guest);
		if (scf < 9) {
			err(DEBUG_CAT_EMPLUS, "scanf fail\n");
			ret = -1;
			goto exit;
		}
	} else {
		err(DEBUG_CAT_EMPLUS, "fgets error\n");
		ret = -1;
		goto exit;
	}
exit:
	(void)fclose(fp);
	return ret;
}
static void mtk_os_get_cpu_load(u8 *cpu_load_rate)
{
	struct stat_cpu stat = { 0 };
	double total1 = 0, total2 = 0, idle1 = 0, idle2 = 0, diff = 0;
	double occupancy = 0;
	/* first read */
	if (_mtk_os_read_cpu_stat(&stat) < 0) {
		err(DEBUG_CAT_EMPLUS, "read cpu stat fail\n");
		return;
	}
	total1 = stat.user + stat.nice + stat.system + stat.idle + stat.iowait + stat.steal + stat.irq + stat.softirq +
		 stat.guest;
	idle1 = stat.idle;
	usleep(100000);
	/* second read */
	if (_mtk_os_read_cpu_stat(&stat) < 0) {
		err(DEBUG_CAT_EMPLUS, "read cpu stat error\n");
		return;
	}
	total2 = stat.user + stat.nice + stat.system + stat.idle + stat.iowait + stat.steal + stat.irq + stat.softirq +
		 stat.guest;
	idle2 = stat.idle;
	diff = total2 - total1;
	if (diff == 0) {
		err(DEBUG_CAT_EMPLUS, "cpu_load_rate = 0\n");
		*cpu_load_rate = 0;
		return;
	}
	occupancy = (total2 - total1 - (idle2 - idle1)) * 100 / diff;
	*cpu_load_rate = (u8)occupancy;
	info(DEBUG_CAT_EMPLUS, "cpu_load: %d\n", (int)*cpu_load_rate);
}

void get_dev_boot_id(struct p1905_managerd_ctx *ctx)
{
	char buffer[64];
	char boot_id[ID_LENGTH + 1] = {0};
	int ret = 0;

	FILE *file = fopen(BOOT_ID_PATH, "r");

	if (file == NULL) {
		err(DEBUG_CAT_EMPLUS, "Failed to open file %s and status %s\n", BOOT_ID_PATH, strerror(errno));
		return;
	}

	if (fgets(buffer, sizeof(buffer), file) != NULL) {
		os_strncpy(boot_id, buffer, ID_LENGTH);
		boot_id[ID_LENGTH] = '\0';
	}

	if (fclose(file) < 0) {
		err(DEBUG_CAT_EMPLUS, "fclose fail\n");
		return;
	}

	ret = strtoul(boot_id, NULL, 16);
	if (ret == ERANGE) {
		err(DEBUG_CAT_EMPLUS, "strtoul boot_id fail\n");
		return;
	}
	ctx->boot_id = (unsigned int)ret;
}

static void get_memory_size(unsigned int *total_mem_size, unsigned int *free_mem_size, unsigned int *cached_mem_size)
{
	FILE *fp;
	char *ptr = NULL;
	char buf[64] = { 0 };
	char *token = NULL;

	fp = fopen("/proc/meminfo", "r");
	if (fp == NULL) {
		err(DEBUG_CAT_EMPLUS, "open error: %s\n", strerror(errno));
		return;
	}
	while (fgets(buf, 64, fp)) {
		ptr = buf;
		token = strtok(ptr, ":");
		if (token != NULL) {
			if (os_strcmp(token, "MemTotal") == 0) {
				token = strtok(NULL, "kB");
				if (!token) {
					err(DEBUG_CAT_EMPLUS, "Fail to get MemTotal info\n");
					goto end;
				}
				*total_mem_size = (unsigned int)strtol(token, (char **)NULL, 10);
				os_memset(buf, 0, 64);
				continue;
			} else if (os_strcmp(token, "MemFree") == 0) {
				token = strtok(NULL, "kB");
				if (!token) {
					err(DEBUG_CAT_EMPLUS, "Fail to get MemFree info\n");
					goto end;
				}
				*free_mem_size = (unsigned int)strtol(token, (char **)NULL, 10);
				os_memset(buf, 0, 64);
				continue;
			} else if (os_strcmp(token, "Cached") == 0) {
				token = strtok(NULL, "kB");
				if (!token) {
					err(DEBUG_CAT_EMPLUS, "Fail to get Cached info\n");
					goto end;
				}
				*cached_mem_size = (unsigned int)strtol(token, (char **)NULL, 10);
				os_memset(buf, 0, 64);
				continue;
			}
		}
	}

end:
	(void)fclose(fp);
}
static void get_uptime(unsigned int *uptime)
{
	struct sysinfo info;
	int ret = 0;

	ret = sysinfo(&info);
	if (ret < 0) {
		err(DEBUG_CAT_EMPLUS, "sysinfo failed\n");
		return;
	}
	*uptime = info.uptime;
}
static void get_cpu_temparature(u8 *temparature)
{
	FILE *fp;
	char *ptr = NULL;
	char buf[64] = { 0 };
	int temp = 0;

	fp = fopen("/sys/class/thermal/thermal_zone0/temp", "r");
	if (fp == NULL) {
		err(DEBUG_CAT_EMPLUS, "open error:%s\n", strerror(errno));
		return;
	}
	if (!fgets(buf, 64, fp)) {
		err(DEBUG_CAT_EMPLUS, "read error: %s\n", strerror(errno));
		(void)fclose(fp);
		return;
	}
	ptr = buf;
	temp = strtol(ptr, (char **)NULL, 10);
	temp = temp / 1000;
	*temparature = (u8)temp;
	(void)fclose(fp);
}
void get_emplus_dev_metrics(struct emplus_dev_metrics *dev_metrics)
{
	if (dev_metrics == NULL) {
		err(DEBUG_CAT_EMPLUS, "dev_metrics NULL pointer\n");
		return;
	}
	get_cpu_temparature(&dev_metrics->cpu_temparature);
	mtk_os_get_cpu_load(&dev_metrics->cpu_load_rate);
	get_memory_size(&dev_metrics->total_memory, &dev_metrics->free_memory, &dev_metrics->cached_memory);
	get_uptime(&dev_metrics->uptime);
	info(DEBUG_CAT_EMPLUS,
		"cpu temparature=%d, cpu load rate:%d, total memory=%d, free memory=%d, cached memory=%d, uptime=%d\n",
		(int)dev_metrics->cpu_temparature, (int)dev_metrics->cpu_load_rate, dev_metrics->total_memory,
		dev_metrics->free_memory, dev_metrics->cached_memory, dev_metrics->uptime);
}
unsigned short append_emplus_dev_metircs(struct p1905_managerd_ctx *ctx, unsigned char *pkt)
{
	struct emplus_dev_metrics dev_metrics = { 0 };
	u8 *temp_buf = NULL, *old_p = NULL, *radio_num_p = NULL;
	u16 len = 0, total_length = 0;
	u8 radio_num = 0;
	int i = 0;

	/*get device metrics info*/
	get_emplus_dev_metrics(&dev_metrics);
	temp_buf = pkt;
	*temp_buf = VENDOR_SPECIFIC_TLV_TYPE;
	temp_buf += 1;
	/*skip tlv length*/
	old_p = temp_buf;
	temp_buf += 2;
	/*emplus oui*/
	os_memcpy(temp_buf, EMPLUS_OUI, sizeof(EMPLUS_OUI));
	temp_buf += 3;
	/*emplus tlv ID*/
	*((unsigned short *)temp_buf) = host_to_be16(EMPLUS_DEV_METRICES);
	temp_buf += 2;
	/*uptime*/
	*((unsigned int *)temp_buf) = host_to_be32(dev_metrics.uptime);
	temp_buf += 4;
	/*cpu load*/
	*temp_buf = dev_metrics.cpu_load_rate;
	temp_buf += 1;
	/*cpu temperature*/
	*temp_buf = dev_metrics.cpu_temparature;
	temp_buf += 1;
	/*total memory*/
	*((unsigned int *)temp_buf) = host_to_be32(dev_metrics.total_memory);
	temp_buf += 4;
	/*free memory*/
	*((unsigned int *)temp_buf) = host_to_be32(dev_metrics.free_memory);
	temp_buf += 4;
	/*cached memory*/
	*((unsigned int *)temp_buf) = host_to_be32(dev_metrics.cached_memory);
	temp_buf += 4;
	/*Number of radios */
	radio_num_p = temp_buf;
	temp_buf += 1;
	for (i = 0; i < ctx->radio_number; i++) {
		os_memcpy(temp_buf, ctx->rinfo[i].identifier, ETH_ALEN);
		temp_buf += ETH_ALEN;
		/*Radio temperature*/
		*temp_buf = (unsigned char)ctx->rinfo[i].temperature;
		temp_buf += 1;
		radio_num++;
	}
	*radio_num_p = radio_num;
	len = (unsigned short)(temp_buf - old_p - 2);
	*((unsigned short *)old_p) = host_to_be16(len);
	total_length = len + 3;
	return total_length;
}

unsigned short append_emplus_ap_radio_capability_tlv(struct p1905_managerd_ctx *ctx, unsigned char *pkt,
	struct radio_info *r)
{
	unsigned short total_length = 0, itf_idx = 0, len = 0;
	unsigned char *temp_buf, *old_p;
	unsigned short wireles_mode = 0, reserved = 0, mediatype = 0;

	temp_buf = pkt;
	*temp_buf = VENDOR_SPECIFIC_TLV_TYPE;
	temp_buf += 1;

	/*skip tlv length*/
	old_p = temp_buf;
	temp_buf += 2;

	/*emplus oui*/
	os_memcpy(temp_buf, EMPLUS_OUI, sizeof(EMPLUS_OUI));
	temp_buf += 3;

	/*emplus tlv ID*/
	*((unsigned short *)temp_buf) = host_to_be16(EMPLUS_RADIO_CAPABILITY_TLV);
	temp_buf += 2;

	memcpy(temp_buf, r->identifier, ETH_ALEN);
	temp_buf += ETH_ALEN;

	/*fill radio operating woreless mode */
	for (itf_idx = 0; itf_idx < ctx->itf_number; itf_idx++) {
		if (os_memcmp(ctx->itf[itf_idx].identifier, r->identifier, ETH_ALEN) == 0) {
			mediatype = ctx->itf[itf_idx].media_type;
			break;
		}
	}
	/*Bit 15 802.11a standard Bit 14 802.11b standard Bit 13 802.11g standard Bit 12 802.11n standard */
	/*Bit 11 802.11ac standard Bit 10 802.11ax standard Bit 09 802.11be standard Bit 08 . 00 reserved */

	/*wireless_mode value fill as per AT spec feature 0x0015*/
	if (r->band == BAND_6G_CAP) {
		switch (mediatype) {
		case IEEE802_11BE_GROUP:
			wireles_mode = 0x600;
			break;
		case IEEE802_11AX_GROUP:
			wireles_mode = 0x400;
			break;
		default:
			break;
		}
	}

	if (r->band == BAND_5G_CAP) {
		switch (mediatype) {
		case IEEE802_11BE_GROUP:
			wireles_mode = 0x9e00;
			break;
		case IEEE802_11AX_GROUP:
			wireles_mode = 0x9c00;
			break;
		case IEEE802_11AC_5G_GROUP:
			wireles_mode = 0x9800;
			break;
		case IEEE802_11N_5G_GROUP:
			wireles_mode = 0x9000;
			break;
		case IEEE802_11A_5G_GROUP:
			wireles_mode = 0x8000;
			break;
		default:
			break;
		}
	}

	if (r->band == BAND_2G_CAP) {
		switch (mediatype) {
		case IEEE802_11BE_GROUP:
			wireles_mode = 0x7e00;
			break;
		case IEEE802_11AX_GROUP:
			wireles_mode = 0x7c00;
			break;
		case IEEE802_11N_24G_GROUP:
			wireles_mode = 0x7000;
			break;
		case IEEE802_11B_24G_GROUP:
			wireles_mode = 0x6000;
			break;
		case IEEE802_11G_24G_GROUP:
			wireles_mode = 0x4000;
			break;
		default:
			break;
		}
	}

	*((unsigned short *)temp_buf) = host_to_be16(wireles_mode);
	temp_buf += 2;

	*((unsigned short *)temp_buf) = host_to_be16(reserved);
	temp_buf += 2;

	len = (unsigned short)(temp_buf - old_p - 2);
	*((unsigned short *)old_p) = host_to_be16(len);

	total_length = len + 3;

	return total_length;
}
#endif /*EM_PLUS_SUPPORT*/

