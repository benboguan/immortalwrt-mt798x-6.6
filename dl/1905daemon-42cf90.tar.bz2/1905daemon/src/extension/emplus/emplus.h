/* SPDX-License-Identifier: MediaTekProprietary*/
/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */
#ifndef __EMPLUS_H__
#define __EMPLUS_H__

#ifdef EM_PLUS_SUPPORT

#include <sys/queue.h>
#include <string.h>
#include <syslog.h>
#include <assert.h>
#include <linux/if_ether.h>
#include <asm/byteorder.h>
#include <stdlib.h>
#include <sys/un.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>

#include "data_def.h"
#include "multi_ap.h"
#include "interface.h"
#include "debug.h"
#include "p1905_managerd.h"
#include "common.h"
#include "os.h"
#include "_1905_lib_io.h"
#include "_1905_interface_ctrl.h"
#include "wifi_utils.h"

/*EMPLUS_FEATURE_ID*/
#define EMPLUS_DEV_METRICES_ID				1
#define EMPLUS_SUPPORT_1905_2014			2
#define EMPLUS_DEV_INFO_ID				3
#define EMPLUS_ETH_STATS_ID				4
#define EMPLUS_REBOOT_REQ_ID				6
#define EMPLUS_SUPPORT_WIFI6				7
#define EMPLUS_SUPPORT_DPP				8
#define EMPLUS_SUPPORT_STP				9
#define EMPLUS_SUPPORT_LED_ID				11
#define EMPLUS_SUPPORT_WIFI_SWTICH			12
#define EMPLUS_SUPPORT_HIDDEN_SSID			14
#define EMPLUS_SUPPORT_RADIO_MODE_SHARING		16
#define EMPLUS_SUPPORT_AFC				17

/* EMPLUS_FEATURE Reference */
#define EMPLUS_MESG_TYPE				0x0001
#define EMPLUS_FEATURE_PROFILE				0x0002
#define EMPLUS_DEV_INFO					0x0003
#define EMPLUS_DEV_METRICES				0x0004
#define EMPLUS_REBOOT_REQ				0x0005
#define EMPLUS_LED_STATS				0x000D
#define EMPLUS_SERVICE_STATS				0x000E
#define EMPLUS_ETH_INTERFACE				0x000F
#define EMPLUS_ETH_STATS				0x0010
#define EMPLUS_ETH_NON_1905_NEIG_DEV_LIST		0x0011
#define EMPLUS_ETH_1905_NEIG_DEV_LIST			0x0012
#define EMPLUS_RADIO_CAPABILITY_TLV			0x0013

/* EMPLUS MESSAGE Reference */
#define EMPLUS_REBOOT_REQ_MESG				0x0001
#define EMPLUS_DEV_MANAGEMENT_REQ			0x0007
#define EMPLUS_DPP_CCE_INDICATION_MESG			0x801D
#define EMPLUS_DPP_PROXIED_ENCAP			0x8029
#define EMPLUS_DPP_RECONFIGURATION_TRIGGER_MESG		0x802B
#define EMPLUS_DPP_CHIP_NOTIF_MSG			0x802F

#define SERVICE_EMPLUS_CONTROLLER 0xA0
#define SERVICE_EMPLUS_AGENT 0xA1


#define EMPLUS_SERVICE_INFO_LEN 6

#define EMPLUS_ON 1
#define EMPLUS_OFF 0

#define EMPLUS_GATEWAY BIT(7)
#define EMPLUS_EXTENDER BIT(6)
#define EMPLUS_STB BIT(5)

#define EMPLUS_DEV_ROLE BIT(7)
#define EMPLUS_LED_OFF BIT(7)

#define EMPLUS_BACKHAUL_ON_TIME 30
#define EMPLUS_BACKHAUL_OFF_TIME 180
#define EMPLUS_WAIT_TIME 300

#define EMPLUS_BIT_FH_BSS BIT(7)
#define EMPLUS_BIT_BH_BSS  BIT(6)
#define EMPLUS_BIT_BH_STA BIT(5)
#define EMPLUS_BIT_ETH      BIT(4)
#define EMPLUS_BIT_NON_1905 BIT(3)

#define EMPLUS_REBOOT_REQ_REBOOT_ONLY   0x00
#define EMPLUS_REBOOT_REQ_REBOOT_RESET  0x01
#define EMPLUS_REBOOT_REQ_RESET_ONLY    0x00
#define EMPLUS_REBOOT_REQ_FACTORY_RESET 0x01

#define BOOT_ID_PATH "/proc/sys/kernel/random/boot_id"
#define ID_LENGTH 8

enum service_status_reason {
	NOT_APPLICABLE  =  0,
	WIFI_OFF,
	SERVICE_DEACTIVATED,
	UNKNOWN_REASON,
};

enum dut_mode {
	CONTROLLER_MODE,
	AGENT_MDOE,
	OTHER,
};

struct emplus_dev_info {
	unsigned int boot_id;
	unsigned char client_id_length;
	unsigned char client_secret_length;
	unsigned char product_class;
	unsigned char dev_role_info;
	unsigned char *client_secret;
	unsigned char *client_id;
};

struct user_net_device_stats {
	unsigned long long rx_packets; /* total packets received       */
	unsigned long long tx_packets; /* total packets transmitted    */
	unsigned long long rx_bytes;   /* total bytes received         */
	unsigned long long tx_bytes;   /* total bytes transmitted      */
	unsigned long rx_errors;       /* bad packets received         */
	unsigned long tx_errors;       /* packet transmit problems     */
	unsigned long rx_dropped;      /* no space in linux buffers    */
	unsigned long tx_dropped;      /* no space available in linux  */
	unsigned long rx_multicast;    /* multicast packets received   */
	unsigned long rx_compressed;
	unsigned long tx_compressed;
	unsigned long collisions;

	/* detailed rx_errors: */
	unsigned long rx_length_errors;
	unsigned long rx_over_errors;	/* receiver ring buff overflow  */
	unsigned long rx_crc_errors;	/* recved pkt with crc error    */
	unsigned long rx_frame_errors;	/* recv'd frame alignment error */
	unsigned long rx_fifo_errors;	/* recv'r fifo overrun          */
	unsigned long rx_missed_errors; /* receiver missed packet     */
	/* detailed tx_errors */
	unsigned long tx_aborted_errors;
	unsigned long tx_carrier_errors;
	unsigned long tx_fifo_errors;
	unsigned long tx_heartbeat_errors;
	unsigned long tx_window_errors;
};

struct net_proc_inf {
	struct interface *next, *prev;
	char name[IFNAMSIZ];	   /* interface name        */
	short type;		   /* if type               */
	short flags;		   /* various flags         */
	int metric;		   /* routing metric        */
	int mtu;		   /* MTU value             */
	int tx_queue_len;	   /* transmit queue length */
	struct ifmap map;	   /* hardware setup        */
	struct sockaddr addr;	   /* IP address            */
	struct sockaddr dstaddr;   /* P-P IP address        */
	struct sockaddr broadaddr; /* IP broadcast address  */
	struct sockaddr netmask;   /* IP network mask       */
	int has_ip;
	char hwaddr[32]; /* HW address            */
	int statistics_valid;
	struct user_net_device_stats stats; /* statistics            */
	int keepalive;			    /* keepalive value for SLIP */
	int outfill;			    /* outfill value for SLIP */
};

struct itf_stats {
	unsigned long tx_err_pkts;
	unsigned long rx_err_pkts;
};

struct emplus_dev_metrics {
	u8 cpu_temparature;
	u8 cpu_load_rate;
	u32 total_memory;
	u32 free_memory;
	u32 cached_memory;
	u32 uptime;
};

struct stat_cpu {
	unsigned int user;
	unsigned int nice;
	unsigned int system;
	unsigned int idle;
	unsigned int iowait;
	unsigned int steal;
	unsigned int irq;
	unsigned int softirq;
	unsigned int guest;
};

unsigned short append_emplus_eth_host_stats_tlv(struct p1905_managerd_ctx *ctx, unsigned char *pkt);
unsigned short append_emplus_eth_interface_tlv(struct p1905_managerd_ctx *ctx, unsigned char *pkt);
unsigned short append_emplus_non_1905_neighbor_device_type_tlv(struct p1905_managerd_ctx *ctx, unsigned char *pkt,
	struct non_p1905_neighbor *devlist);
unsigned short append_emplus_1905_neighbor_device_type_tlv(struct p1905_managerd_ctx *ctx, unsigned char *pkt,
	struct p1905_neighbor *devlist);
unsigned short append_emplus_dev_metircs(struct p1905_managerd_ctx *ctx, unsigned char *pkt);
int insert_emplus_feature_list(struct p1905_managerd_ctx *ctx, unsigned short feature_id, unsigned short feature_ver);
int delete_emplus_feature_list(struct p1905_managerd_ctx *ctx);

unsigned short append_emplus_feature_prof_tlv(unsigned char *pkt, struct emplus_feature_prof *feat_prof);
unsigned short append_emplus_message_vendor_specific_type_tlv(unsigned char *pkt, unsigned short type);
unsigned short append_emplus_dev_info_tlv(unsigned char *pkt, struct p1905_managerd_ctx *ctx);
unsigned short append_emplus_service_status_tlv(unsigned char *pkt, int status_reason);
int parse_emplus_vs_tlv(struct p1905_managerd_ctx *ctx, unsigned short len, unsigned char *value);

void emplus_off_interface(struct p1905_managerd_ctx *ctx, unsigned char idex);
int emplus_cntlr_interface(struct p1905_managerd_ctx *ctx, unsigned char type);
int parse_emplus_message_tlv(struct p1905_managerd_ctx *ctx,
		unsigned int left_tlv_len, unsigned char *buf);
unsigned short append_emplus_ap_radio_capability_tlv(struct p1905_managerd_ctx *ctx, unsigned char *pkt,
	struct radio_info *r);

unsigned short get_msg_hdr(unsigned char *buf);
void get_emplus_dev_metrics(struct emplus_dev_metrics *dev_metrics);
const char *getFeatureName(int featureID);


#endif /* EM_PLUS_SUPPORT*/

#endif /*__EMPLUS_H__*/

