/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#include <stddef.h>
#include <assert.h>
#include <string.h>
#ifdef SUPPORT_COREDUMP
#include <sys/resource.h>
#endif
#ifdef SUPPORT_BACKTRACE
#define UNW_LOCAL_ONLY
#include <libunwind.h>
#endif
#ifdef DISABLE_SWITCH_POLLING
#include <netlink/genl/genl.h>
#endif

#include "p1905_managerd.h"
#include "debug.h"
#include "eloop.h"
#include "cmdu_message.h"
#include "ethernet_layer.h"
#include "cmdu.h"
#include "cmdu_fragment.h"
#include "lldp_message_parse.h"
#include "cmdu_retry_message.h"
#include "mapfilter_if.h"
#include "worker_task.h"
#include "netlink_event.h"
#include "lldp.h"
#include "topology.h"
#include "multi_ap.h"
#include "file_io.h"
#ifdef DISABLE_SWITCH_POLLING
#include "genl_netlink.h"
#endif
#ifdef MAP_R3
#include "wpa_extern.h"
#include "security_engine.h"
#endif
#ifdef MAP_R5
#include "qos.h"
#endif
#ifdef BR_IP_TLV_SUPPORT
#include <sys/ioctl.h>
#include <linux/in.h>
#endif /* BR_IP_TLV_SUPPORT */
#ifdef EM_PLUS_SUPPORT
#include "emplus.h"
#include "vlan_util.h"
#endif

#define ETH_MODE_CHANGE_TIME 5
#define ONE_SECOND_CNT 60
#define DROP_FRAGMENT_CNT 15
extern int debug_level;
volatile sig_atomic_t timer_expired = 0;
volatile sig_atomic_t exit_signal = 0;
volatile sig_atomic_t hpav_info_has_changed = 0;

#ifdef MAP_R2
extern void map_rm_hnat_session();
#endif

#ifdef SUPPORT_BACKTRACE
void show_backtrace(void)
{
	unw_cursor_t cursor;
	unw_context_t context;
	unw_word_t offset, ip;
	char sym[256] = {0};

	unw_getcontext(&context);
	unw_init_local(&cursor, &context);
	while (unw_step(&cursor) > 0) {
		unw_get_reg(&cursor, UNW_REG_IP, &ip);
		printf("ip = 0x%lx:", (long)ip);
		sym[0] = '\0';
		unw_get_proc_name(&cursor, sym, sizeof(sym), &offset);
		printf("(%s+0x%lx)\n", sym, offset);
	}
}
#endif

#ifdef SUPPORT_COREDUMP
void _1905_enable_core_dump(void)
{
	struct rlimit limit;

	notice(DEBUG_CAT_INIT, "enabling core dump");
	limit.rlim_cur = 1024 * 1024 * 500;
	limit.rlim_max = 1024 * 1024 * 500;
	setrlimit(RLIMIT_CORE, &limit);
}
#else
void _1905_enable_core_dump(void) { }
#endif

int makeAddr(const char *name, struct sockaddr_un *pAddr, socklen_t *pSockLen)
{
	int ret;
    int nameLen = strlen(name);
    if (nameLen >= (int) sizeof(pAddr->sun_path) -1)  /* too long? */
        return -1;
    pAddr->sun_path[0] = '\0';  /* abstract namespace */
	ret = snprintf(pAddr->sun_path+1, sizeof(pAddr->sun_path) - 1, "%s", name);
	if (ret < 0 || ret >= (sizeof(pAddr->sun_path) - 1)) {
		err(DEBUG_CAT_INIT, "snprintf fail!\n");
		return -1;
	}
    pAddr->sun_family = AF_UNIX;
    *pSockLen = 1 + nameLen + offsetof(struct sockaddr_un, sun_path);
    return 0;
}

#ifdef SUPPORT_CONTROL_SOCKET
int _1905_ctrl_sock_init(struct p1905_managerd_ctx *ctx)
{
	struct sockaddr_un addr;
	socklen_t server_len = 0;

	os_memset(&addr, 0, sizeof(struct sockaddr_un));
	/* Initialize control interface */
	errno = 0;
	ctx->ctrl_sock = socket(AF_UNIX, SOCK_STREAM, 0);
	if (ctx->ctrl_sock < 0) {
		err(DEBUG_CAT_INIT, "fail to create ctrl_sock; errno=%d(%s)\n",
			errno, strerror(errno));
		return -1;
	}

	makeAddr("/tmp/1905ctrl", &addr, &server_len);
	errno = 0;
	if (bind(ctx->ctrl_sock, (struct sockaddr *)&addr, server_len) < 0) {
		err(DEBUG_CAT_INIT, "fail to bind addr for ctrl_sock; errno=%d(%s)\n",
			errno, strerror(errno));
		unlink(addr.sun_path);
		close(ctx->ctrl_sock);
		return -1;
	}

	errno = 0;
	if (listen(ctx->ctrl_sock, 1) < 0) {
		unlink(addr.sun_path);
		close(ctx->ctrl_sock);
		err(DEBUG_CAT_INIT, "fail to listen ctrl_sock; errno=%d(%s)\n",
			errno, strerror(errno));
		return -1;
	}

	return 0;
}
void _1905_ctrl_interface_recv_and_parse(struct p1905_managerd_ctx *ctx,
		char *buf, int len)
{
	struct sockaddr_un from;
	int lenfrom = sizeof(from);
	int recv_fd = 0;
	char *file = NULL;
	int total_len = 0, reply_len = 0;

	errno = 0;
	recv_fd = accept(ctx->ctrl_sock, (struct sockaddr *)&from, (socklen_t *)&lenfrom);
	if (recv_fd < 0) {
		err(DEBUG_CAT_EVENT, "accept ctrl_sock fail; errno=%d(%s)\n", errno, strerror(errno));
		return;
	}

	total_len = recv(recv_fd, buf, len - 1, 0);
	if (total_len <= 0) {
		err(DEBUG_CAT_EVENT, "recv ctrl_sock fail; errno=%d(%s)\n", errno, strerror(errno));
		close(recv_fd);
		return;
	}

	buf[total_len] = '\0';

	if (os_strncmp(buf, "version", strlen("version")) == 0) {
		show_1905_mapfilter_version(ctx);
	} else if (os_strncmp(buf, "dev_send_1905", os_strlen("dev_send_1905")) == 0) {
		file = buf + os_strlen("dev_send_1905") + 1;
		send_1905_raw_data(ctx, file);
	} else if (os_strncmp(buf, "dev_set_config", os_strlen("dev_set_config")) == 0) {
		if (ctx->role == CONTROLLER) {
			file = buf + os_strlen("dev_set_config") + 1;
			read_1905_bss_config(ctx, file);
		} else {
			notice(DEBUG_CAT_EVENT, "agent mode, no need hanle dev_set_config\n");
		}
	} else if (os_strncmp(buf, "dump_topology_info", os_strlen("dump_topology_info")) == 0) {
		reply_len = dump_topology_info(ctx, buf, len);
	} else if (os_strncmp(buf, "dump_topology_tree", os_strlen("dump_topology_tree")) == 0) {
		dump_topology_tree(ctx);
		eth_layer_port_clients_dump();
	} else if (os_strncmp(buf, "dump_autoconfig_info", os_strlen("dump_autoconfig_info")) == 0) {
		reply_len = dump_autoconfig_info(ctx, buf, len);
	} else if (os_strncmp(buf, "dump_radio_info", os_strlen("dump_radio_info")) == 0) {
		dump_radio_info(ctx);
	} else if (os_strncmp(buf, "log_level", os_strlen("log_level")) == 0) {
		int level = 0;
		char *p = buf + os_strlen("log_level") + 1;
		level = atoi(p);
		set_debug_level(level);
	} else if (os_strncmp(buf, "get_switch_mode", os_strlen("get_switch_mode")) == 0) {
		reply_len = test_eth_layer_get_switch_mode(buf, len);
	} else if (os_strncmp(buf, "get_eth_port_type", os_strlen("get_eth_port_type")) == 0) {
		reply_len = test_eth_layer_get_port_type(buf, len);
	}  else if (os_strncmp(buf, "get_eth_entry", os_strlen("get_eth_entry")) == 0) {
		reply_len = test_eth_layer_get_client_entry(buf, len);
	}  else if (os_strncmp(buf, "find_eth_entry", os_strlen("find_eth_entry")) == 0) {
		unsigned char mac[ETH_ALEN];

		if (!hwaddr_aton(buf + os_strlen("find_eth_entry"), mac))
			reply_len = test_eth_layer_search_table_entry(mac, buf, len);
	} else if (os_strncmp(buf, "get_eth_port_status", os_strlen("get_eth_port_status")) == 0) {
		int port_index = 0;
		char *p = buf + os_strlen("get_eth_port_status");
		port_index = atoi(p);
		reply_len = test_eth_layer_get_port_status(port_index, buf, len);
	} else if (os_strncmp(buf, "get_eth_port_speed", os_strlen("get_eth_port_speed")) == 0) {
		int port_index = 0;
		char *p = buf + os_strlen("get_eth_port_speed");

		port_index = atoi(p);
		reply_len = test_eth_layer_get_port_speed(port_index, buf, len);
	} else if (os_strncmp(buf, "set_eth_port_block", os_strlen("set_eth_port_block")) == 0) {
		int port_index = 0;
		int enable = 0;
		char *endptr = NULL;
		char *p = buf + os_strlen("set_eth_port_block");

		port_index = (int)strtol(p, &endptr, 10);
		if ((errno == ERANGE && (port_index == LONG_MAX || port_index == LONG_MIN))
			|| (errno != 0 && port_index == 0) || (endptr == p)) {
			err(DEBUG_CAT_MISC, "strtol log port_index fail!\n");
			goto out;
		}
		p += 2;
		enable = atoi(p);
		reply_len = test_eth_layer_set_port_block(port_index, enable, buf, len);
	} else if (os_strncmp(buf, "set_eth_ts_vlan_id", os_strlen("set_eth_ts_vlan_id")) == 0) {
		char *p = buf + os_strlen("set_eth_ts_vlan_id") + 1;
		char *str_vlan = NULL;
		unsigned short vids[256];
		unsigned char vid_num = 0;

		while(1) {
			str_vlan = strsep(&p, ",;");
			if (!str_vlan)
				break;
			if (*str_vlan == '\0')
				continue;

			vids[vid_num++] = atoi(str_vlan);
		}

		test_eth_layer_set_vlan(vids, vid_num, 0);
#ifdef MAP_R2
		map_rm_hnat_session();
#endif
	}  else if (os_strncmp(buf, "set_eth_trans_vlan_id", os_strlen("set_eth_trans_vlan_id")) == 0) {
		char *p = buf + os_strlen("set_eth_trans_vlan_id") + 1;
		char *str_vlan = NULL;
		unsigned short vids[256];
		unsigned char vid_num = 0;

		while(1) {
			str_vlan = strsep(&p, ",;");
			if (!str_vlan)
				break;
			if (*str_vlan == '\0')
				continue;

			vids[vid_num++] = atoi(str_vlan);
		}

		test_eth_layer_set_vlan(vids, vid_num, 1);
	} else if (os_strncmp(buf, "clear_switch_table", os_strlen("clear_switch_table")) == 0) {
		test_eth_layer_clear_switch_table();
	} else if (os_strncmp(buf, "mapfilter_debug", os_strlen("mapfilter_debug")) == 0) {
		mapfilter_dump_debug_info();
	} else if (os_strncmp(buf, "mapfilter_set_primary", os_strlen("mapfilter_set_primary")) == 0) {
		unsigned char mac[ETH_ALEN] = {0};

		if(!hwaddr_aton(buf + os_strlen("mapfilter_set_primary") + 1, mac)) {
			struct local_interface itf;
			int primary = INF_UNKNOWN;
			char *p = NULL;

			os_memset(&itf, 0, sizeof(struct local_interface));
			os_memcpy(itf.mac, mac, ETH_ALEN);
			itf.dev_type = APCLI;
			p = buf + os_strlen("mapfilter_set_primary") + 1 + 18;
			primary = atoi(p);
			mapfilter_set_primary_interface(&itf, primary);
		}
	} else if (os_strncmp(buf, "mapfilter_set_up_path", os_strlen("mapfilter_set_up_path")) == 0) {
		unsigned char mac[ETH_ALEN] = {0}, mac2[ETH_ALEN] = {0};

		if(!hwaddr_aton(buf + os_strlen("mapfilter_set_up_path") + 1, mac)) {
			struct local_interface in, out;
			char *p = NULL;

			os_memset(&in, 0, sizeof(struct local_interface));
			os_memset(&out, 0, sizeof(struct local_interface));
			os_memcpy(in.mac, mac, ETH_ALEN);

			p = buf + os_strlen("mapfilter_set_up_path") + 1 + 18;
			if (!hwaddr_aton(p, mac2)) {
				os_memcpy(out.mac, mac2, ETH_ALEN);
				mapfilter_set_uplink_path(&in, &out);
			}
		}
	} else if (os_strncmp(buf, "show_PON_dev", os_strlen("show_PON_dev")) == 0) {
		show_PON_dev(ctx);
	} else if (strncmp(buf, "set_debug_level", strlen("set_debug_level")) == 0) {
		debug_level = atoi(buf + strlen("set_debug_level") + 1);
	} else if (strncmp(buf, "set_log_option", strlen("set_log_option")) == 0) {
		char *pos = buf + strlen("set_log_option") + 1;

		set_log_option_str(pos);
	} else if (strncmp(buf, "set_log_category", strlen("set_log_category")) == 0) {
		char *pos = buf + strlen("set_log_category") + 1;

		set_log_category_str(pos);
	} else if (strncmp(buf, "get_log_info", strlen("get_log_info")) == 0) {
		reply_len = get_log_info(buf, len);
	} else if (strncmp(buf, "dump_init_info", strlen("dump_init_info")) == 0) {
		reply_len = dump_init_info(ctx, buf, len);
	}
#ifdef MAP_R2
	else if (os_strncmp(buf, "set_ts_config", strlen("set_ts_config")) == 0){
		char *tmp = buf + os_strlen("set_ts_config") + 1;

		if (strncmp(tmp, "pvlan", strlen("pvlan")) == 0) {
			cmd_set_ts_pvlan(ctx, tmp + os_strlen("pvlan") + 1);
		} else if (strncmp(tmp, "policy", strlen("policy")) == 0) {
			tmp = tmp + os_strlen("policy") + 1;
			if (strncmp(tmp, "clean", strlen("clean")) == 0)
				cmd_set_ts_policy_clear(ctx);
			else if (strncmp(tmp, "done", strlen("done")) == 0)
				cmd_set_ts_policy_done(ctx);
			else
				cmd_set_ts_policy(ctx, tmp);
		} else {
			err(DEBUG_CAT_TS, "no such ts command; cmd=%s\n", tmp);
		}
	} else if (os_strncmp(buf, "show_ts_info", strlen("show_ts_info")) == 0) {
		show_all_assoc_clients(ctx);
		show_all_operational_bss(ctx);
	} else if (os_strncmp(buf, "ts_onoff", strlen("ts_onoff")) == 0) {
		char onoff = atoi(buf + os_strlen("ts_onoff") + 1);

		mapfilter_ts_onoff(onoff);
	}
#endif// #ifdef MAP_R2
#ifdef MAP_R3_SP
	else if (os_strncmp(buf, "show_sp", strlen("show_sp")) == 0){
		notice(DEBUG_CAT_SP, "[static rule list]\n");
		show_rule_list_dptbl(&ctx->sp_rule_static_list, NULL);
		notice(DEBUG_CAT_SP, "[dynamic rule list]\n");
		show_rule_list_dptbl(&ctx->sp_rule_dynamic_list, NULL);
		notice(DEBUG_CAT_SP, "[dscp mapping table]\n");
		show_rule_list_dptbl(NULL, &ctx->sp_dp_table);
		notice(DEBUG_CAT_SP, "[learn complete rule list]\n");
		show_rule_list_dptbl(&ctx->sp_rule_learn_complete_list, NULL);
	}
#endif
#ifdef MAP_R3
	else if (strncmp(buf, "dump_security_info", strlen("dump_security_info")) == 0)
		reply_len = dump_security_info(buf, len);
	else if (strncmp(buf, "set_key", strlen("set_key")) == 0) {
		cmd_set_key(buf + os_strlen("set_key") + 1);
	} else if (strncmp(buf, "set_sec_log_level", strlen("set_sec_log_level")) == 0) {
		int level = 0;
		char *p = buf + os_strlen("set_sec_log_level") + 1;
		level = atoi(p);
		set_security_log_level(level);
	} else if (strncmp(buf, "set_sec_config", strlen("set_sec_config")) == 0) {
		cmd_set_security_config(buf + os_strlen("set_sec_config") + 1);
	}
    else if (strncmp(buf, "dev_start_buffer", strlen("dev_start_buffer")) == 0) {
        if ((ctx->map_version == MAP_PROFILE_R3) && ctx->MAP_Cer)
		    cmd_dev_start_buffer(ctx, buf + os_strlen("dev_start_buffer") + 1);
	} else if (strncmp(buf, "dev_stop_buffer", strlen("dev_stop_buffer")) == 0) {
	    if ((ctx->map_version == MAP_PROFILE_R3) && ctx->MAP_Cer)
		    cmd_dev_stop_buffer(ctx);
	} else if (strncmp(buf, "dev_get_frame_info", strlen("dev_get_frame_info")) == 0) {
	    if ((ctx->map_version == MAP_PROFILE_R3) && ctx->MAP_Cer)
		    cmd_dev_get_frame_info(ctx, buf + os_strlen("dev_get_frame_info") + 1);
	} else if (strncmp(buf, "send_bss_reconfig_trigger", strlen("send_bss_reconfig_trigger")) == 0) {
		if ((ctx->map_version == MAP_PROFILE_R3) && (ctx->role == CONTROLLER))
			cmd_send_bss_reconfiguration_trigger(ctx, buf + os_strlen("send_bss_reconfig_trigger") + 1);
	}
#endif // MAP_R3
#ifdef BR_IP_TLV_SUPPORT
	else if (strncmp(buf, "br_info_tlv", strlen("br_info_tlv")) == 0) {
		file = buf + os_strlen("br_info_tlv") + 1;
		if (atoi(file) > 0)
			ctx->include_brinfo_tlv = 1;
		else
			ctx->include_brinfo_tlv = 0;
	}
#endif
#ifdef MAP_R6
	else if (strncmp(buf, "ap_mlo_link_chg", strlen("ap_mlo_link_chg")) == 0)
		cmd_send_ap_mld_config_request(ctx);
	else if (strncmp(buf, "bsta_mlo_link_chg", strlen("bsta_mlo_link_chg")) == 0)
		cmd_send_bsta_mld_config_request(ctx);
#endif
	else if (os_strncmp(buf, "show_r6_support", os_strlen("show_r6_support")) == 0)
		reply_len = cmd_show_map_r6_support(ctx, buf, len);
	else if (os_strncmp(buf, "dump_bss_config_info", os_strlen("dump_bss_config_info")) == 0)
		reply_len = dump_bss_config_info(ctx, buf, len);
	else if (os_strncmp(buf, "dump_eth_controller_num", os_strlen("dump_eth_controller_num")) == 0)
		reply_len = dump_controller_num_in_topo(ctx, buf, len);
#ifdef MAP_R5
	else if (os_strncmp(buf, "set_qos_config", os_strlen("set_qos_config")) == 0)
		set_qos_config((void *)ctx, buf + os_strlen("set_qos_config") + 1);
	else if (os_strncmp(buf, "show_qos_config", os_strlen("show_qos_config")) == 0)
		show_qos_config((void *)ctx);
#endif
#ifdef EM_PLUS_SUPPORT
	else if (os_strncmp(buf, "add_vlan_tag", os_strlen("add_vlan_tag")) == 0) {
		vlan_add("rai0", 10, "rai0.10");
		ifconfig_up("rai0.10");
	} else if (os_strncmp(buf, "rem_vlan_tag", os_strlen("rem_vlan_tag")) == 0) {
		ifconfig_down("rai0.10");
		vlan_rem("rai0.10");
	} else if (os_strncmp(buf, "ignore_renew", strlen("ignore_renew")) == 0) {
		char flag = atoi(buf + os_strlen("ignore_renew") + 1);
		unsigned int delay_t = 5;

		if (flag == 1) {
			eloop_cancel_timeout(reset_ignore_renew_flag, (void *)ctx, NULL);
			ctx->ignore_renew = flag;
			debug(DEBUG_CAT_EVENT, "change ignore_renew flag to %d\n", flag);
		} else if (flag == 0) {
			eloop_cancel_timeout(reset_ignore_renew_flag, (void *)ctx, NULL);
			debug(DEBUG_CAT_EVENT, "change ignore_renew flag to %d after %ds\n", flag, delay_t);
			eloop_register_timeout(delay_t, 0, reset_ignore_renew_flag, (void *)ctx, NULL);
		}
	}
#endif
	else {
		err(DEBUG_CAT_EVENT, "no such command; cmd=%s\n", buf);
	}

	if (reply_len > 0) {
		int ret = 0;

		errno = 0;
		ret = send(recv_fd, buf, reply_len, 0);
		if (ret < 0)
			err(DEBUG_CAT_EVENT, "send fail; errno=%d(%s)\n", errno, strerror(errno));
	}
out:
	close(recv_fd);
}

void  _1905_ctrl_sock_deinit(struct p1905_managerd_ctx *ctx)
{
	close(ctx->ctrl_sock);
}
#endif

#define ETHERNET_PREFIX "eth0"

void ethernet_plug_in_handler(void *context, void *data)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx*)context;
	struct port_status_info *port_info = (struct port_status_info *)data;
#ifdef EM_PLUS_SUPPORT
	unsigned char ifname[IFNAMSIZ] = {0};
	int ret;
#endif

	if (port_info->status == 0)
		return;

	notice(DEBUG_CAT_ONBOARD, "clear switch and bridge mac tables\n");
	eth_layer_clear_switch_table();

	usleep(20000);

	/*
	 *for scenario almac is setting as brlan mac,
	 *default will set eth port in block mode(only 1905 pkt can be received),
	 *so after some secs later when eth plug in, eth port will changed as
	 *forword mode(all data pkt can be received)
	 */

	if (ctx->swtich_rule_set == 1) {
		struct ethernet_port *pport = NULL;

		pport = eth_layer_get_eth_data_by_port_index(port_info->port);
		if (pport) {
			eloop_cancel_timeout(eth_layer_set_port_block, (void *)ctx, (void *)pport);
			eloop_register_timeout(ETH_MODE_CHANGE_TIME, 0, eth_layer_set_port_block, (void *)ctx, (void *)pport);
		}
	}

	notice(DEBUG_CAT_ONBOARD, "eth link up; send topo discovery_with_vendor_ie and notification\n");
	ctx->mid++;
	multicast_cmdu_tx_eth(ctx, e_topology_discovery_with_vendor_ie, ctx->mid, 0);
	ctx->mid++;
	multicast_cmdu_tx_eth(ctx, e_topology_notification, ctx->mid, 1);

#ifdef EM_PLUS_SUPPORT
	if (ctx->map_policy.setting.primary_vid != INVALID_VLAN_ID) {
		ret = snprintf((char *)ifname, sizeof(ifname), "%s.%d", ETHERNET_PREFIX,
				port_info->port+1);
		if (os_snprintf_error(sizeof(ifname), ret)) {
			notice(DEBUG_CAT_ONBOARD, "snprintf fail!\n");
			return;
		}
		update_vlan_tag_inf(ctx, ifname, 2);
	}
#endif

	eloop_register_timeout(1, 0, discovery_at_boot_up, (void *)ctx, NULL);
}

void ethernet_pull_out_handler(void *context, void *data)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx*)context;
	struct port_status_info *port_info = (struct port_status_info *)data;
	int cnt = 0;
#ifdef EM_PLUS_SUPPORT
	unsigned char ifname[IFNAMSIZ] = {0};
	int ret;
#endif

	if (port_info->status == 1)
		return;
	notice(DEBUG_CAT_ONBOARD, "clear switch and bridge mac tables\n");
	eth_layer_clear_switch_table();
	/*
	 *for scenario almac is setting as brlan mac,
	 *eth plug in case will set eth port as forward mode(all data pkt can be received),
	 *so when eth plug out, so should change as block mode(only 1905 pkt can be received)
	 */

	if (ctx->swtich_rule_set == 1) {
		struct ethernet_port *pport = NULL;

		pport = eth_layer_get_eth_data_by_port_index(port_info->port);
		if (pport)
			eloop_cancel_timeout(eth_layer_set_port_block, (void *)ctx, (void *)pport);

		eth_layer_set_eth_port_block(port_info->port, 1);
	}

	cnt = delete_topo_disc_db_by_port(ctx, port_info->port, NULL);
	if (cnt > 0) {
		report_own_topology_rsp(ctx, ctx->p1905_al_mac_addr, ctx->br_cap,
			ctx->p1905_neighbor_dev, ctx->non_p1905_neighbor_dev,
			ctx->service, &ctx->ap_cap_entry.oper_bss_head,
			&ctx->ap_cap_entry.assoc_clients_head, ctx->cnt);
		notice(DEBUG_CAT_ONBOARD, "eth link down; send topo notification");
		ctx->mid++;
		multicast_cmdu_tx_eth(ctx, e_topology_notification, ctx->mid, 1);
		/*vlan case to clear switch table of upper ap device*/
		notice(DEBUG_CAT_ONBOARD, "clear switch table port %d\n", port_info->port);
		eth_layer_clear_switch_table();
	}
	unmask_control_conn_port(ctx, port_info->port);
	delete_topo_response_db_by_port_interface(ctx, port_info->port);
	update_topology_tree(ctx);
#ifdef EM_PLUS_SUPPORT
	if (ctx->map_policy.setting.primary_vid != INVALID_VLAN_ID) {
		ret = snprintf((char *)ifname, sizeof(ifname), "%s.%d", ETHERNET_PREFIX,
				port_info->port+1);
		if (os_snprintf_error(sizeof(ifname), ret)) {
			notice(DEBUG_CAT_ONBOARD, "snprintf fail!\n");
			return;
		}
	}
	update_vlan_tag_inf(ctx, ifname, 0);
#endif
}

int update_mapfilter_all_eth_interfaces(struct p1905_managerd_ctx *ctx)
{
	int i = 0, ret = 0;
	unsigned char *buf = NULL;
	struct local_itfs *itf = NULL;
	int buf_len = 0;

	buf_len = sizeof(struct local_itfs) + ctx->itf_number * sizeof(struct local_interface);
	buf = os_zalloc(buf_len);

	if (!buf)
		return -1;

	itf = (struct local_itfs*)buf;

	for (i = 0; i < ctx->itf_number; i++) {
		if (ctx->itf[i].media_type <= IEEE802_3_AB_GROUP && ctx->itf[i].is_veth != 1) {
			itf->num++;
			os_memcpy(itf->inf[i].name, ctx->itf[i].if_name, IFNAMSIZ);
			os_memcpy(itf->inf[i].mac, ctx->itf[i].mac_addr, ETH_ALEN);
			itf->inf[i].dev_type = ETH;
		}
	}

	if (itf->num)
		ret = mapfilter_set_all_interface(itf);

	os_free(buf);

	return ret;
}

void library_cmd_process(int sock, void *eloop_ctx, void *sock_ctx)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx*)eloop_ctx;

	_1905_interface_receive_process(sock, ctx, 0);

	common_process(ctx, &ctx->trx_buf);
}

void mapfilter_event_process(int sock, void *eloop_ctx, void *sock_ctx)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx*)eloop_ctx;
	unsigned char *buf = ctx->trx_buf.buf;
	int recv_len = 0;

	buf = mapfilter_read_nlmsg(buf, MAX_PKT_LEN, &recv_len);

#ifdef MAP_R3_SP
	if (buf) {
		sp_process_learn_complete_event(ctx->role, buf, &ctx->sp_rule_learn_complete_list, ctx->send_tlv,
			&ctx->send_tlv_len);
		if (ctx->role == AGENT) {
			insert_cmdu_txq(ctx->cinfo.almac, ctx->p1905_al_mac_addr,
				e_vendor_specific, ++ctx->mid, ctx->cinfo.local_ifname, 0);
			process_cmdu_txq(ctx, ctx->trx_buf.buf);
		}
	}
#endif
}

void ctrl_cmd_process(int sock, void *eloop_ctx, void *sock_ctx)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx*)eloop_ctx;
	struct buf_info *buf = &ctx->trx_buf;

	_1905_ctrl_interface_recv_and_parse(ctx, (char *)buf->buf, MAX_PKT_LEN);

	common_process(ctx, buf);
}

void netlink_event_process(int sock, void *eloop_ctx, void *sock_ctx)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx*)eloop_ctx;
	struct buf_info *buf = &ctx->trx_buf;
	int length = 0;

	length = netlink_event_recv(ctx->sock_netlink, buf->buf, MAX_PKT_LEN);
	if (length < 0) {
		err(DEBUG_CAT_EVENT, "netlink_event_recv fail\n");
		return;
	}
	buf->buf = get_netlink_data(buf->buf, &length);
	/*add netlink event handler here*/
	netlink_event_handler(eloop_ctx, (struct _1905_netlink_message *)buf->buf, length);

	common_process(ctx, buf);
	return;
}

#ifdef DISABLE_SWITCH_POLLING
void genl_netlink_event_process(int sock, void *eloop_ctx, void *sock_ctx)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx*)eloop_ctx;
	char buf[32] = {0xff};
	struct port_status_info *status = NULL;
	int ret = 0;

	ret = genl_netlink_recv(ctx->genl_sock, buf);
	if (!ret) {
		 status = (struct port_status_info *)buf;
		 if (status->port != 0xff && status->status != 0xff)
			eth_layer_port_data_update_and_notify(eloop_ctx, (void *)status);
	}
}
#endif

void worker_task_event_process(int sock, void *eloop_ctx, void *sock_ctx)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx*)eloop_ctx;
	struct buf_info *buf = &ctx->trx_buf;
	int length = 0;

	length = worker_task_receiver_recv(ctx->sock_internal, buf->buf, MAX_PKT_LEN);
	if (length < 0) {
		err(DEBUG_CAT_EVENT, "worker_task_receiver_recv fail\n");
		return;
	}
	worker_task_receiver_event_handler(eloop_ctx, (struct worker_task_message *)buf->buf, length);

	common_process(ctx, buf);
	return;
}

void lldp_process(int sock, void *eloop_ctx, void *sock_ctx)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx*)eloop_ctx;
	struct buf_info *buf = &ctx->trx_buf;
	int length = 0;

	/*reveive LLDPDU, process here*/
	length = receive_802_1_bridge_discovery_msg(ctx, sock, buf->buf, MAX_PKT_LEN);
	if (length < 0) {
		err(DEBUG_CAT_MSG, "receive 802.1 bridge discovery fail\n");
		return;
	}

	if (parse_802_1_bridge_discovery_msg(ctx, sock, buf->buf, length) < 0) {
		err(DEBUG_CAT_MSG, "parse 802.1 bridge discovery fail\n");
		return;
	}

	common_process(ctx, buf);
}

#ifdef MAP_R2
int update_mapfilter_wan_tag(struct p1905_managerd_ctx *ctx, unsigned char status)
{
	int i = 0, ret = 0;

	if (ctx->map_version == DEV_TYPE_R1)
		return ret;

	for (i = 0; i < ctx->itf_number; i++) {
		if (ctx->itf[i].is_wan == 1) {
			ret = mapfilter_set_wan_tag(ctx->itf[i].mac_addr, status);
			break;
		}
	}

	return ret;
}
#endif


void p1905_manage_terminate(int signum, void *signal_ctx)
{
	eloop_terminate();
}

/*1905 one sec timer*/
void p1905_managerd_periodic(void *eloop_data, void *user_ctx)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx *)eloop_data;
	static unsigned int cnt = 0;
	struct buf_info *buf = &ctx->trx_buf;

	cnt += PERIODIC_TIMER_SEC;
    /*1. update LLDP database, if exceed time to live , delete*/
    update_lldp_queue_ttl(PERIODIC_TIMER_SEC);

    /*2. delete 1905.1 neighbor if not receiving new topology discovery*/
    if (delete_not_exist_p1905_neighbor_device(ctx, PERIODIC_TIMER_SEC)) {
    	ctx->mid++;
		notice(DEBUG_CAT_TOPO, "topo change! send topo notification\n");
		multicast_cmdu_tx(ctx, e_topology_notification, ctx->mid, 1);
    }
	/*3 delete 1905 topology device*/
	delete_not_exist_p1905_topology_device(ctx, PERIODIC_TIMER_SEC);
	check_topology_rsp_expired(ctx);
	/*update topology tree*/
	update_topology_tree(ctx);

	/*phase out agent structure*/
	check_and_delete_expired_agent(ctx, PERIODIC_TIMER_SEC);

	/*block bss autoconfigration mechanism*/
	if (ctx->role == CONTROLLER && ctx->block_bss_info.block_bss_autoconfig)
		controller_block_bss_configuration_mechanism(ctx);

	/*config sync error handling*/
	if (ctx->role == CONTROLLER && !ctx->MAP_Cer)
		trace_topology_tree_cb(ctx, ctx->root_leaf, (topology_tree_cb_func)config_sync_error_handler, NULL);

#ifdef MAP_R3_SP
	if (ctx->role == CONTROLLER && !ctx->MAP_Cer) {
		trace_topology_tree_cb(ctx, ctx->root_leaf, (topology_tree_cb_func)sp_rule_sync_handler, NULL);
		if ((cnt % ONE_SECOND_CNT) == 0) {
			sp_sync_learn_complete_rule((void*)ctx);
		}
	}
#endif

	if ((cnt % DROP_FRAGMENT_CNT) == 0) {
		/*increment fragment timeout counter*/
		add_fragment_cnt();
		if (get_fragment_cnt() >= 2)
			delete_fragment_queue_all();
	}
	clear_expired_dm_buffer(ctx);
	/*check if any message need resend*/
	handle_retry_message_queue(ctx);
	common_process(ctx, buf);
	eloop_cancel_timeout(p1905_managerd_periodic, (void *)ctx, NULL);
	eloop_register_timeout(PERIODIC_TIMER_SEC, 0, p1905_managerd_periodic, (void *)ctx, NULL);
}

void p1905_database_init(struct p1905_managerd_ctx *ctx)
{
	ctx->service = ctx->role;
	ctx->mid = (unsigned short)os_random();
	LIST_INIT(&ctx->topology_entry.tpddb_head);
	SLIST_INIT(&ctx->topology_entry.tprdb_head);
	SLIST_INIT(&ctx->topodev_entry.tpdevdb_head);
	SLIST_INIT(&ctx->ap_cap_entry.ap_ht_cap_head);
	SLIST_INIT(&ctx->ap_cap_entry.ap_vht_cap_head);
	SLIST_INIT(&ctx->ap_cap_entry.oper_bss_head);
	SLIST_INIT(&ctx->ap_cap_entry.assoc_clients_head);
	SLIST_INIT(&ctx->ap_cap_entry.ch_prefer_head);
	SLIST_INIT(&ctx->ap_cap_entry.oper_restrict_head);
	SLIST_INIT(&ctx->map_policy.spolicy.local_disallow_head);
	SLIST_INIT(&ctx->map_policy.spolicy.btm_disallow_head);
	SLIST_INIT(&ctx->map_policy.spolicy.radio_policy_head);
	SLIST_INIT(&ctx->map_policy.mpolicy.policy_head);
	SLIST_INIT(&ctx->metric_entry.metrics_query_head);
	SLIST_INIT(&ctx->metric_entry.metrics_rsp_head);
	SLIST_INIT(&ctx->metric_entry.traffic_stats_head);
	SLIST_INIT(&ctx->metric_entry.link_metrics_head);
	SLIST_INIT(&ctx->metric_entry.unlink_info.unlink_metrics_head);
	SLIST_INIT(&ctx->agent_head);
	SLIST_INIT(&ctx->query_neighbor_head);
	SLIST_INIT(&ctx->steer_cntrl.policy_head);
#ifdef MAP_R2
	SLIST_INIT(&ctx->ap_cap_entry.ch_scan_cap_head);
	SLIST_INIT(&ctx->ap_cap_entry.radio_cac_cap.radio_cac_capab_head);
	SLIST_INIT(&ctx->metric_entry.radio_metrics_head);
	SLIST_INIT(&ctx->metric_entry.assoc_sta_extended_link_metrics_head);
	SLIST_INIT(&ctx->metric_entry.radio_identifier_head);
	SLIST_INIT(&ctx->map_policy.tpolicy.policy_head);
	SLIST_INIT(&ctx->map_policy.epolicy.policy_head);
	SLIST_INIT(&ctx->map_policy.fpolicy.bssid_head);
#endif
#ifdef MAP_R5
	memset(&ctx->map_policy.qos_mgmt_policy, 0, sizeof(struct qos_management_policy));
#endif
	/* init list of opclass to mld cfg */
	dl_list_init(&ctx->opcls_mld_cfg.mlo_cfg_list);
	/* init list of wts to controller mld cfg */
	dl_list_init(&ctx->wts_ctrl_mld_cfg.mlo_cfg_list);
	/* init list of wts to agent mld cfg */
	dl_list_init(&ctx->agent_ap_mld_list);

	/* init list of agent ap mld config on agent */
	dl_list_init(&ctx->mld_bss.mlo_cfg_list);
	for (int idx = 0; idx < MAX_RADIO_NUM; idx++) {
		/* eht operations db from driver */
		dl_list_init(&ctx->ap_cap_entry.eht_op[idx].eht_op_list);
		/* eht operations db from wsc */
		dl_list_init(&ctx->eht_op[idx].eht_op_list);
	}
#if defined(MAP_R6) || defined(EM_PLUS_SUPPORT)
	/* init list of wifi7 cap for each band */
	dl_list_init(&ctx->ap_cap_entry.wifi7_mlo_cap_list);
#endif
#ifdef MAP_R6
	/* init list of bsta info from wts */
	dl_list_init(&ctx->agent_bsta_list);

	/* init list of bsta mld config on agent */
	dl_list_init(&ctx->mld_bsta.affiliated_sta_list);

	dl_list_init(&ctx->mlo_t2lm_db.t2lm_cfg_list);

	_1905_read_mlo_max_links(ctx);
#endif

}

/*
 *When a process terminates, all of its memory is returned to the system,
 *including heap memory allocated by functions in the malloc package.
 *In programs that allocate memory and continue using it until program termination,
 *it is common to omit calls to free(), relying on this behavior to automatically free the memory.
 *This can be especially useful in programs that allocate many blocks of memory,
 *since adding multiple calls to free() could be expensive in terms of CPU time,
 *as well as perhaps being complicated to code
*/
void p1905_database_deinit(struct p1905_managerd_ctx *ctx)
{
	clear_topology_db(&ctx->topology_entry);
	/*free neighbor dev info*/
	clear_topology_neighbor_db(ctx->p1905_neighbor_dev, ctx->itf_number);
	clear_topology_device_db(&ctx->topodev_entry);
	clear_all_exist_radio_basic_capability(ctx);
	clear_ap_capability_db(&ctx->ap_cap_entry);
	/*free map cpnfiguration info*/
	delete_exist_metrics_policy(ctx, &ctx->map_policy.mpolicy);
		/*free buffer*/
	if (ctx->ch_set) {
		free(ctx->ch_set);
		ctx->ch_set = NULL;
	}
	if (ctx->ch_stat) {
		free(ctx->ch_stat);
		ctx->ch_stat = NULL;
	}
	if (ctx->ch_rep) {
		free(ctx->ch_rep);
		ctx->ch_rep = NULL;
	}
#ifdef MAP_R4_SPT
	if (ctx->spt_report) {
		free(ctx->spt_report);
		ctx->spt_report = NULL;
	}
#endif
#ifdef EM_PLUS_SUPPORT
	delete_emplus_feature_list(ctx);

	if (ctx->client_id) {
		free(ctx->client_id);
		ctx->client_id = NULL;
	}
	if (ctx->client_secret) {
		free(ctx->client_secret);
		ctx->client_secret = NULL;
	}
#endif /*EM_PLUS_SUPPORT*/
	/*free all the agents info*/
	free_all_the_agents_info(&ctx->agent_head);

#ifdef EM_PLUS_SUPPORT
	if (ctx->product.ser_num) {
		os_free(ctx->product.ser_num);
		ctx->product.ser_num = NULL;
	}
#endif /*EM_PLUS_SUPPORT*/

	delete_exist_mlo_cap(ctx);

	delete_eht_operations(ctx->eht_op);
	delete_eht_operations(ctx->ap_cap_entry.eht_op);
	delete_ap_mld_conf(&ctx->wts_ctrl_mld_cfg);
	delete_agent_ap_mld_list(&ctx->agent_ap_mld_list);
	delete_ap_mld_conf(&ctx->opcls_mld_cfg);
	delete_ap_mld_conf(&ctx->mld_bss);
#ifdef MAP_R6
	delete_agent_bsta_cfg(&ctx->agent_bsta_list);
	/* bsta mld conf already deleted after notify */
	delete_bsta_mld_conf(&ctx->mld_bsta);
#endif
#if defined(MAP_R6) || defined(EM_PLUS_SUPPORT)
	/* free wifi7 agent mlo cap list */
	delete_exist_wifi7_mlo_cap(&ctx->ap_cap_entry.wifi7_mlo_cap_list);
#endif
#ifdef MAP_R2
	/* clear assoc client table */
	clear_assoc_client_table(ctx);
#endif
}


void p1905_interface_uninit(struct p1905_managerd_ctx *ctx)
{
    int i = 0;

    for(i=0;i<ITF_NUM;i++)
    {
        if(ctx->itf[i].vs_info_length > 0)
            free(ctx->itf[i].vs_info);
    }

    for(i=0;i<BRIDGE_NUM;i++)
    {
        free(ctx->br_cap[i].itf_mac_list);
    }
}

void signal_handler(int sig, void *signal_ctx)
{
	notice(DEBUG_CAT_MISC, "caught signal %d\n", sig);
#ifdef SUPPORT_BACKTRACE
	show_backtrace();
#endif
	eloop_terminate();
}

int p1905_managerd_init(struct p1905_managerd_ctx *ctx)
{
	struct ethernet_port_notifier noti;
	int sock = 0;

    assert(ctx != NULL);

	ctx->trx_buf.buf = (unsigned char *)os_malloc(MAX_PKT_LEN);
	if (!ctx->trx_buf.buf) {
		err(DEBUG_CAT_INIT, "alloc trx_buf fail\n");
		return -1;
	}
	ctx->trx_buf.buf_len = MAX_PKT_LEN;

	ctx->tlv_buf.buf = (unsigned char *)os_zalloc(MAX_PKT_LEN);
	if (!ctx->tlv_buf.buf) {
		err(DEBUG_CAT_INIT, "alloc tlv_buf fail\n");
		goto fail;
	}
	ctx->tlv_buf.buf_len = MAX_PKT_LEN;

	ctx->reassemble_buf.buf = (unsigned char *)os_zalloc(MAX_PKT_LEN);
	if (!ctx->reassemble_buf.buf) {
		err(DEBUG_CAT_INIT, "alloc reassemble_buf fail\n");
		goto fail;
	}
	ctx->reassemble_buf.buf_len = MAX_PKT_LEN;

	ctx->revd_tlv.buf  = (unsigned char *)os_malloc(MAX_PKT_LEN);
	if (!ctx->revd_tlv.buf) {
		err(DEBUG_CAT_INIT, "allocate revd_tlv fail\n");
		goto fail;
	}
	ctx->revd_tlv.buf_len = MAX_PKT_LEN;

	if (cmdu_init(ctx) == -1) {
		err(DEBUG_CAT_INIT, "cmdu_init fail\n");
		goto fail;
	}

#ifdef SUPPORT_CONTROL_SOCKET
	if (_1905_ctrl_sock_init(ctx) == -1) {
		err(DEBUG_CAT_INIT, "_1905_ctrl_sock_init fail\n");
		goto fail;
	}
#endif
	p1905_database_init(ctx);

	if (_1905_interface_init(ctx) < 0) {
		err(DEBUG_CAT_INIT, "_1905_interface_init fail\n");
		goto fail;
	}

	sock = mapfilter_netlink_init(getpid());
	if (sock < 0) {
		err(DEBUG_CAT_INIT, "mapfilter_netlink_init init fail\n");
		goto fail;
	}

    if (ap_autoconfig_init(ctx)) {
		err(DEBUG_CAT_INIT, "fail to ap_autoconfig_init\n");
		goto fail;
    }

	noti.down_handler = ethernet_pull_out_handler;
	noti.up_handler = ethernet_plug_in_handler;

	if (eth_layer_init((void *)ctx, &noti) < 0)
		goto fail;

#ifdef EM_PLUS_SUPPORT
	get_dev_boot_id(ctx);
#endif /* EM_PLUS_SUPPORT */

#ifdef DISABLE_SWITCH_POLLING
	ctx->genl_sock = gen_netlink_init();
	ctx->switch_polling = 0;
	if (!ctx->genl_sock) {
		err(DEBUG_CAT_INIT, "gen_netlink_init fail; using polling mechanism\n");
		/*init switch port status polling thread*/
		ctx->sock_internal = worker_task_receiver_sock_init("internal_server");
		if (ctx->sock_internal < 0) {
			err(DEBUG_CAT_INIT, "worker task receiver sock init fail\n");
			goto fail;
		} else {
			if (worker_task_init() < 0) {
				err(DEBUG_CAT_INIT, "worker_task_init init fail\n");
				goto fail;
			}
		}
		ctx->switch_polling = 1;
	}
	notice(DEBUG_CAT_INIT, "switch_polling=%d\n", ctx->switch_polling);
#else
	ctx->sock_internal = worker_task_receiver_sock_init("internal_server");
	if (ctx->sock_internal < 0) {
		err(DEBUG_CAT_INIT, "worker task receiver sock init fail\n");
		goto fail;
	} else {
		if (worker_task_init() < 0) {
			err(DEBUG_CAT_INIT, "worker_task_init init fail\n");
			goto fail;
		}
	}
#endif

	if (eloop_init()) {
		err(DEBUG_CAT_INIT, "Failed to initialize event loop");
		goto fail;
	}

	update_mapfilter_all_eth_interfaces(ctx);

	mapfilter_ts_onoff(0);

#ifdef MAP_R2
	assoc_client_table_init(ctx);
	traffic_separation_init(ctx);
#ifdef MAP_R3_SP
	if(service_prioritization_init((void*)ctx))
		goto fail;
#endif
#endif
#ifdef MAP_R5
	qos_mgmt_init((void *)ctx);
#endif

#ifdef MAP_R3
	ctx->encr_buf.buf = (unsigned char *)os_zalloc(MAX_PKT_LEN);
	if (!ctx->encr_buf.buf) {
		warn(DEBUG_CAT_INIT, "allocate encryption buffer fail\n");
		goto fail;
	}
	ctx->encr_buf.buf_len = MAX_PKT_LEN;
	init_akm_capability(ctx);
#ifdef EM_PLUS_EXT_SUPPORT
		security_engine_init(ctx->encr_buf.buf, ctx->encr_buf.buf_len, ctx->security_enabled);
#else
	security_engine_init(ctx->encr_buf.buf, ctx->encr_buf.buf_len);
#endif
	map_dpp_init(ctx);
	if (ctx->MAP_Cer)
		dev_get_frame_info_init(ctx);

    /* init wpa, according to local device role */
	if ((ctx->wpa = wpa_init((void *)ctx, ctx->role)) == NULL) {
		warn(DEBUG_CAT_INIT, "wpa_init failed\n");
		goto fail;
	}
#endif

	if (ctx->role == CONTROLLER)
		if (_1905_read_set_config(ctx, ctx->wts_bss_cfg_file,
			ctx->bss_config, MAX_SET_BSS_INFO_NUM, &ctx->bss_config_num) < 0)
			warn(DEBUG_CAT_INIT, "_1905_read_set_config fail\n");

	dm_init(ctx);

#ifdef BR_IP_TLV_SUPPORT
	get_inf_ip(ctx->br_name, &ctx->br_ip);
	eloop_register_timeout(60, 0, get_br_ip_proc, (void *)ctx, NULL);
#endif /* BR_IP_TLV_SUPPORT */
	eloop_register_signal_terminate(signal_handler, ctx);
	/*set all socket to eloop*/

	if (!ctx->rx_from_all)
		eloop_register_read_sock(ctx->sock_br, cmdu_process, (void *)ctx, NULL);
	eloop_register_read_sock(ctx->_1905_ctrl.sock, library_cmd_process, (void *)ctx, NULL);
	eloop_register_read_sock(ctx->ctrl_sock, ctrl_cmd_process, (void *)ctx, NULL);
	if (ctx->sock_netlink > 0)
		eloop_register_read_sock(ctx->sock_netlink, netlink_event_process, (void *)ctx, NULL);
	if (!ctx->MAP_Cer) {
		eloop_register_timeout(SWITCH_TABLE_DUMP_TIME, 0, non_1905_neighbor_update, (void *)ctx, NULL);
	}
	eloop_register_timeout(PERIODIC_TIMER_SEC, 0, p1905_managerd_periodic, (void *)ctx, NULL);
	eloop_register_timeout(PERIODIC_TIMER_SEC, 0, send_discovery_periodic, (void *)ctx, NULL);
#ifdef DISABLE_SWITCH_POLLING
	if (ctx->switch_polling) {
		eloop_register_read_sock(ctx->sock_internal, worker_task_event_process, (void *)ctx, NULL);
	} else {
		eloop_register_read_sock(ctx->genl_sock->s_fd, genl_netlink_event_process, (void *)ctx, NULL);
		eloop_register_timeout(1, 0, update_ethenet_port_status_at_bootup, (void *)ctx, NULL);
	}
#else
	eloop_register_read_sock(ctx->sock_internal, worker_task_event_process, (void *)ctx, NULL);
#endif
	if (!ctx->MAP_Cer)
		eloop_register_read_sock(sock, mapfilter_event_process, (void *)ctx, NULL);

    return 0;

fail:
	if (ctx->trx_buf.buf) {
		os_free(ctx->trx_buf.buf);
		ctx->trx_buf.buf = NULL;
		ctx->trx_buf.buf_len = 0;
	}
	if (ctx->tlv_buf.buf) {
		os_free(ctx->tlv_buf.buf);
		ctx->tlv_buf.buf = NULL;
		ctx->tlv_buf.buf_len = 0;
	}
	if (ctx->reassemble_buf.buf) {
		os_free(ctx->reassemble_buf.buf);
		ctx->reassemble_buf.buf = NULL;
		ctx->reassemble_buf.buf_len = 0;
	}
#ifdef MAP_R3
	if (ctx->encr_buf.buf) {
		os_free(ctx->encr_buf.buf);
		ctx->encr_buf.buf = NULL;
		ctx->encr_buf.buf_len = 0;
	}
#endif
	if (ctx->revd_tlv.buf) {
		os_free(ctx->revd_tlv.buf);
		ctx->revd_tlv.buf = NULL;
		ctx->revd_tlv.buf_len = 0;
	}
	return -1;
}

#define RECV_FROM_BR      0x01
#define RECV_FROM_VIRTUAL 0x02

int p1905_managerd_run(struct p1905_managerd_ctx *ctx)
{
	eloop_run();
	return 0;
}

void p1905_managerd_uninit(struct p1905_managerd_ctx *ctx)
{
	int i = 0;

	assert(ctx != NULL);

#ifdef DISABLE_SWITCH_POLLING
	if (ctx->switch_polling) {
		worker_task_deinit();
		worker_task_receiver_sock_deinit(ctx->sock_internal);
	} else {
		eloop_unregister_read_sock(ctx->genl_sock->s_fd);
	}
#else
	worker_task_deinit();
	worker_task_receiver_sock_deinit(ctx->sock_internal);
#endif
	dm_deinit(ctx);

#ifdef SUPPORT_CONTROL_SOCKET
	_1905_ctrl_sock_deinit(ctx);
#endif
	delete_exist_steer_cntrl_db(ctx);

#ifdef MAP_R2
	ts_traffic_separation_deinit(ctx);
	update_mapfilter_wan_tag(ctx, 0);
#ifdef MAP_R3_SP
	service_prioritization_deinit((void*)ctx);
#endif
#endif
#ifdef MAP_R5
	qos_mgmt_deinit((void *)ctx);
#endif
	eth_layer_fini();
#ifdef MAP_R3
	if (ctx->MAP_Cer)
		dev_get_frame_info_deinit(ctx);
	eloop_cancel_timeout(tm_reset_buf_size, (void *)ctx, NULL);
	eloop_cancel_timeout(r3_wait_for_dpp_auth_req, (void *)ctx, NULL);
	eloop_cancel_timeout(periodic_send_autoconfig_search, (void *)ctx, NULL);
	eloop_cancel_timeout(r3_config_sm_step, (void *)ctx, NULL);
	eloop_cancel_timeout(r3_set_config, (void *)ctx, NULL);
	eloop_cancel_timeout(map_r2_notify_ts_config, (void *)ctx, NULL);
	eloop_cancel_timeout(map_notify_transparent_vlan_setting, (void *)ctx, NULL);
	eloop_cancel_timeout(cmd_dev_stop_buffer_timeout, (void *)ctx, NULL);
	deinit_akm_capability(ctx);
	security_engine_deinit(ctx);
	if (ctx->encr_buf.buf != NULL) {
		os_free(ctx->encr_buf.buf);
		ctx->encr_buf.buf = NULL;
	}
	map_dpp_deinit(ctx);
	wpa_deinit();
#endif // MAP_R3
	/*deinit all socket from eloop*/
	if (!ctx->rx_from_all)
		eloop_unregister_read_sock(ctx->sock_br);

	for (i = 0; i < ctx->itf_number; i++) {
		eloop_unregister_read_sock(ctx->sock_lldp[i]);

		if (ctx->rx_from_all)
			eloop_unregister_read_sock(ctx->sock_inf_recv_1905[i]);
	}
	eloop_unregister_read_sock(ctx->_1905_ctrl.sock);
	eloop_unregister_read_sock(ctx->ctrl_sock);
	eloop_unregister_read_sock(ctx->sock_netlink);
#ifdef DISABLE_SWITCH_POLLING
	if (ctx->switch_polling)
		eloop_unregister_read_sock(ctx->sock_internal);
	else
		eloop_unregister_read_sock(ctx->genl_sock->s_fd);
#else
	eloop_unregister_read_sock(ctx->sock_internal);
#endif
	eloop_cancel_timeout(ap_controller_search_step, (void *)ctx, NULL);
	eloop_cancel_timeout(ap_autoconfig_enrolle_step, (void *)ctx, NULL);
	eloop_cancel_timeout(metrics_report_timeout, (void *)ctx, NULL);
	eloop_cancel_timeout(p1905_managerd_periodic, (void *)ctx, NULL);

	eloop_destroy();

	p1905_interface_uninit(ctx);
	cmdu_uninit(ctx);
	lldpdu_uninit(ctx);
	p1905_database_deinit(ctx);
	/*deinit topology tree*/
	clear_topology_tree(ctx);
	_1905_interface_deinit(ctx);

	if (ctx->trx_buf.buf != NULL) {
		os_free(ctx->trx_buf.buf);
		ctx->trx_buf.buf = NULL;
	}
	if (ctx->revd_tlv.buf != NULL) {
		os_free(ctx->revd_tlv.buf);
		ctx->revd_tlv.buf = NULL;
	}
	if (ctx->reassemble_buf.buf != NULL) {
		os_free(ctx->reassemble_buf.buf);
		ctx->reassemble_buf.buf = NULL;
	}
	if (ctx->tlv_buf.buf != NULL) {
		os_free(ctx->tlv_buf.buf);
		ctx->tlv_buf.buf = NULL;
	}
	if (ctx->last_tx_data) {
		os_free(ctx->last_tx_data);
		ctx->last_tx_data = NULL;
	}
	if (ctx->last_rx_data) {
		os_free(ctx->last_rx_data);
		ctx->last_rx_data = NULL;
	}
}

#ifdef BR_IP_TLV_SUPPORT
int get_inf_ip(unsigned char *inf_name, unsigned int *ip)
{
	struct ifreq temp;
	struct sockaddr_in *myaddr;
	int fd = 0;
	int ret;

	if (inf_name == NULL) {
		err(DEBUG_CAT_MISC, "inf_name is null\n");
		return -1;
	}

	if (snprintf(temp.ifr_name, IFNAMSIZ, "%s", inf_name) < 0) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	fd = socket(AF_INET, SOCK_STREAM, 0);
	if (fd < 0) {
		err(DEBUG_CAT_MISC, "create socket fail\n");
		return -1;
	}
	ret = ioctl(fd, SIOCGIFADDR, &temp);
	if (close(fd) < 0)
		err(DEBUG_CAT_MISC, "close fd fail\n");
	if (ret < 0) {
		err(DEBUG_CAT_MISC, "can't get ip for %s!\n", inf_name);
		return -1;
	}
	myaddr = (struct sockaddr_in *)&(temp.ifr_addr);
	*ip = myaddr->sin_addr.s_addr;

	return 0;
}

void get_br_ip_proc(void *eloop_ctx, void *timeout_ctx)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx *)eloop_ctx;
	unsigned long t = 0;

	eloop_cancel_timeout(get_br_ip_proc, (void *)ctx, ELOOP_ALL_CTX);

	if (timeout_ctx == NULL)
		eloop_register_timeout(60, 0, get_br_ip_proc, (void *)ctx, NULL);
	else {
		t = (unsigned long)timeout_ctx;
		if (t < 60)
			eloop_register_timeout(t, 0, get_br_ip_proc, (void *)ctx, (void *)(t * 2));
		else
			eloop_register_timeout(60, 0, get_br_ip_proc, (void *)ctx, NULL);
	}

	get_inf_ip(ctx->br_name, &ctx->br_ip);
}
#endif /* BR_IP_TLV_SUPPORT */

char log_cat_str[16][32] = {
	{"MISC"},
	{"INIT"},
	{"EVENT"},
	{"MSG"},
	{"TOPO"},
	{"ONBOARD"},
	{"AUTOCONF"},
	{"RENEW"},
	{"GPON"},
	{"DPP"},
	{"SECURE"},
	{"TS"},
	{"SP"},
	{"MLO"},
	{"ETH"},
	{"QOS"}
};

/**
 * Main function
 *
 * \param  argc  number of arguments.
 * \param  argv  arguments pointer.
 * \return  error code.
 */
int main(int argc, char *argv[])
{
	struct p1905_managerd_ctx *ctx = NULL;
	unsigned int ctx_len = 0;
    int result = 0;
	int c = 0;
	int ret = 0;
	int category = debug_category;
	int timestamp = debug_timestamp;
	int syslog = debug_syslog;
	int funcline = debug_funcline;
	int lvl = debug_level;

	ret = log_init("1905D", log_cat_str, ARRAY_SIZE(log_cat_str));
	if (ret)
		goto error;

	ctx_len = sizeof(*ctx);
	ctx = os_zalloc(ctx_len);
	if (!ctx) {
		err(DEBUG_CAT_INIT, "alloc ctx fail; size=%u\n", ctx_len);
		return -1;
	}

	while ((c = getopt(argc, argv, "d:i:r:GMf:F:stlc:")) != -1) {
		switch (c) {
		case 'd':
			lvl = optarg[0] - '0';
			break;
		case 'r':
		{
			unsigned char role;

			role = optarg[0] - '0';
			ctx->role = role > 0 ? 1 : 0;
			break;
		}
			break;
		case 'G':
			ctx->core_dump = 1;
			break;
		case 'f':
			ret = snprintf(ctx->map_cfg_file, sizeof(ctx->map_cfg_file), "%s", optarg);
			if (os_snprintf_error(sizeof(ctx->map_cfg_file), ret)) {
				err(DEBUG_CAT_INIT, "snprintf map_cfg_file fail!\n");
				result = -1;
				goto error;
			}
			break;

		case 'F':
			ret = snprintf(ctx->wts_bss_cfg_file, sizeof(ctx->wts_bss_cfg_file), "%s", optarg);
			if (os_snprintf_error(sizeof(ctx->wts_bss_cfg_file), ret)) {
				err(DEBUG_CAT_INIT, "snprintf wts_bss_cfg_file fail!\n");
				result = -1;
				goto error;
			}
			break;
		case 'M':
			ctx->MAP_Cer = 1;
			break;
		case 'c':
		{
			char *end_ptr = NULL;
			long value = 0;

			errno = 0;
			value = strtol(optarg, &end_ptr, 16);
			if ((errno == ERANGE && (value == LONG_MAX || value == LONG_MIN))
				|| (errno != 0 && value == 0) || (end_ptr == optarg)) {
				err(DEBUG_CAT_INIT, "strtol debug category fail!\n");
				category = -1;
			} else {
				category = (int)value;
			}
			break;
		}
		case 'l':
			funcline = 1;
			break;
		case 't':
			timestamp = 1;
			break;
		case 's':
			syslog = 1;
			break;
		default:
			break;
		}
	}

	set_debug_level(lvl);
	set_debug_category(category);
	set_debug_syslog(syslog);
	set_debug_timestamp(timestamp);
	set_debug_funcline(funcline);

	if (ctx->core_dump)
		_1905_enable_core_dump();

	if (0 == os_strlen(ctx->map_cfg_file)) {
		ret = os_snprintf(ctx->map_cfg_file, sizeof(ctx->map_cfg_file), MAP_CFG_FILE);
		if (os_snprintf_error(sizeof(ctx->map_cfg_file), ret)) {
			err(DEBUG_CAT_INIT, "snprintf map_cfg_file fail!\n");
			result = -1;
			goto error;
		}
	}
	if (0 == os_strlen(ctx->wts_bss_cfg_file)) {
		ret = os_snprintf(ctx->wts_bss_cfg_file, sizeof(ctx->wts_bss_cfg_file), MAP_WTS_BSS_CFG_FILE);
		if (os_snprintf_error(sizeof(ctx->wts_bss_cfg_file), ret)) {
			err(DEBUG_CAT_INIT, "snprintf wts_bss_cfg_file fail!\n");
			result = -1;
			goto error;
		}
	}

	if (map_read_config_file(ctx) != 0) {
		err(DEBUG_CAT_INIT, "map_read_config_file fail\n");
		result = -1;
		goto error;
	}

	if (p1905_managerd_init(ctx)) {
		err(DEBUG_CAT_INIT, "p1905_managerd_init fail!\n");
        result = -1;
        goto error;
    }
	notice(DEBUG_CAT_INIT, "p1905_Manager Daemon Running\n");

    p1905_managerd_run(ctx);
	notice(DEBUG_CAT_MISC, "p1905_Manager Daemon exiting\n");

    p1905_managerd_uninit(ctx);

error:
	if (result == -1)
		err(DEBUG_CAT_INIT, "1905d abnormal exit at init stadge!\n");
	log_deinit();
	if (ctx)
		free(ctx);

    return result;
}

char *get_trx_config_str(unsigned char trx_conf, char *buf, int max_len)
{
	int ret = 0, len = 0;
	unsigned short conf = 0;
	unsigned char i = 0;

	while (trx_conf) {
		if ((trx_conf & BIT(i)) == 0) {
			i++;
			if (i == 8)
				break;
			continue;
		}
		conf = BIT(i);
		switch (conf) {
		case TX_MUL:
			ret = snprintf(buf + len, max_len - len, "|%s", "TX_MUL");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_AUTOCONF, "snprintf error\n");
				return "INVALID_TRX_CONFIG";
			}
			len += ret;
			break;
		case RX_MUL:
			ret = snprintf(buf + len, max_len - len, "|%s", "RX_MUL");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_AUTOCONF, "snprintf error\n");
				return "INVALID_TRX_CONFIG";
			}
			len += ret;
			break;
		case TX_UNI:
			ret = snprintf(buf + len, max_len - len, "|%s", "TX_UNI");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_AUTOCONF, "snprintf error\n");
				return "INVALID_TRX_CONFIG";
			}
			len += ret;
			break;
		case RX_UNI:
			ret = snprintf(buf + len, max_len - len, "|%s", "RX_UNI");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_AUTOCONF, "snprintf error\n");
				return "INVALID_TRX_CONFIG";
			}
			len += ret;
			break;
		default:
			return "INVALID_TRX_CONFIG";
		}
		i++;
		if (i == 8)
			break;
	}

	return buf;
}

char *get_media_type_str(unsigned short type)
{
	switch (type) {
	case IEEE802_3_GROUP:
		return "IEEE802_3_GROUP";
	case IEEE802_3_AB_GROUP:
		return "IEEE802_3_AB_GROUP";
	case IEEE802_11B_24G_GROUP:
		return "IEEE802_11B_24G_GROUP";
	case IEEE802_11G_24G_GROUP:
		return "IEEE802_11G_24G_GROUP";
	case IEEE802_11A_5G_GROUP:
		return "IEEE802_11A_5G_GROUP";
	case IEEE802_11N_24G_GROUP:
		return "IEEE802_11N_24G_GROUP";
	case IEEE802_11N_5G_GROUP:
		return "IEEE802_11N_5G_GROUP";
	case IEEE802_11AC_5G_GROUP:
		return "IEEE802_11AC_5G_GROUP";
	case IEEE802_11AX_GROUP:
		return "IEEE802_11AX_GROUP";
	case IEEE802_11BE_GROUP:
		return "IEEE802_11BE_GROUP";
	case IEEE1901_GROUP:
		return "IEEE1901_GROUP";
	case MOCA_GROUP:
		return "MOCA_GROUP";
	default:
		return "UNKNOWN_GROUP";
	}
}

int dump_intf_info(struct p1905_managerd_ctx *ctx, char *buf, int max_len)
{
	int ret = 0, len = 0;
	unsigned int i = 0;
	char buf1[256] = {0};

	ret = snprintf(buf, max_len, "\nintf info:\n");
	if (os_snprintf_error(max_len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	ret = snprintf(buf + len, max_len - len,
		"\tbr_addr=%02x:%02x:%02x:%02x:%02x:%02x; br_name=%s\n",
		MAC2STR(ctx->br_addr), ctx->br_name);
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	for (i = 0; i < ctx->itf_number; i++) {
		ret = snprintf(buf + len, max_len - len,
			"\t%d: mac=%02x:%02x:%02x:%02x:%02x:%02x; name=%s; media_type=%02x(%s); ",
			i + 1, MAC2STR(ctx->itf[i].mac_addr), ctx->itf[i].if_name, ctx->itf[i].media_type,
			get_media_type_str(ctx->itf[i].media_type));
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;
		ret = snprintf(buf + len, max_len - len,
			"is_ap=%d; is_sta=%d; is_veth=%d; is_wan=%d; raid=%02x:%02x:%02x:%02x:%02x:%02x; ",
			ctx->itf[i].is_wifi_ap, ctx->itf[i].is_wifi_sta,
			ctx->itf[i].is_veth, ctx->itf[i].is_wan,
			MAC2STR(ctx->itf[i].identifier));
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;
		ret = snprintf(buf + len, max_len - len,
			"config_priority=%d; trx_config=%d(%s);\n\t channel_freq=%d; channel_bw=%d\n",
			ctx->itf[i].config_priority, ctx->itf[i].trx_config,
			get_trx_config_str(ctx->itf[i].trx_config, buf1, 256),
			ctx->itf[i].channel_freq, ctx->itf[i].channel_bw);
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;
	}

	return len;
}

int dump_map_cfg_params(struct p1905_managerd_ctx *ctx, char *buf, int max_len)
{
	int ret = 0, len = 0;

	ret = snprintf(buf, max_len, "\nmap_cfg_file(%s) params:\n",
		ctx->map_cfg_file);
	if (os_snprintf_error(max_len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	ret = snprintf(buf + len, max_len - len,
		"\talmac=%02x:%02x:%02x:%02x:%02x:%02x; restrict_wan_onboarding=%d; "
		"map_ver=%d; al_inf=%s; discovery_cnt=%d; "
		"DisableTearDown=%d; block_bss_autoconfig=%d\n",
		MAC2STR(ctx->p1905_al_mac_addr), ctx->restrict_wan_onboarding,
		ctx->map_version, ctx->al_inf, ctx->discovery_cnt,
		ctx->disable_tear_down, ctx->block_bss_info.block_bss_autoconfig);
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	ret = snprintf(buf + len, max_len - len,
		"\tbss_config_priority=%s\n",
		ctx->bss_priority_str);
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	return len;
}

char *get_dev_type_str(int dev_type)
{
	switch (dev_type) {
	case AP:
		return "AP";
	case APCLI:
		return "APCLI";
	case ETH:
		return "ETH";
	default:
		return "UNKNOWN_TYPE";
	}
}

int dump_radio_bss_info(struct p1905_managerd_ctx *ctx, char *buf, int max_len)
{
	struct operating_class *opc = NULL;
	int ret = 0, len = 0;
	unsigned int i = 0, j = 0;
#ifdef MAP_R2
	char buf1[256] = {0};
	char buf2[256] = {0};
#endif

	ret = snprintf(buf, max_len, "\nradio bss info:\n");
	if (os_snprintf_error(max_len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	for (i = 0; i < ctx->radio_number; i++) {
		ret = snprintf(buf + len, max_len - len,
			"\t%d: raid="MACSTR"; band=%d(%s); dev_type=%02x(%s); "
			"trrigerd_autoconf=%d; teared_down=%d; config_status=%d; bss_number=%d\n",
			i + 1, MAC2STR(ctx->rinfo[i].identifier), ctx->rinfo[i].band,
			get_band_cap_str(ctx->rinfo[i].band),
			ctx->rinfo[i].dev_type, get_dev_type_str(ctx->rinfo[i].dev_type),
			ctx->rinfo[i].trrigerd_autoconf, ctx->rinfo[i].teared_down,
			ctx->rinfo[i].config_status, ctx->rinfo[i].bss_number);
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;

		j = 0;
		for (j = 0; j < ctx->rinfo[i].bss_number; j++) {
			ret = snprintf(buf + len, max_len - len,
					"\t\tbss%d: mac="MACSTR"; ifname=%s; config_status=%d; priority=%d",
				j + 1, MAC2STR(ctx->rinfo[i].bss[j].mac),
				ctx->rinfo[i].bss[j].ifname, ctx->rinfo[i].bss[j].config_status,
				ctx->rinfo[i].bss[j].priority);
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf fail\n");
				return -1;
			}
			len += ret;
#ifdef MAP_R2
			ret = snprintf(buf + len, max_len - len,
					"; ssid=%s; authmode=0x%04x(%s); encryptype=0x%04x(%s);\n\t\t key=%s; "
					"map_vendor_extension=0x%02x(%s); hidden_ssid=%d",
				ctx->rinfo[i].bss[j].config.Ssid,
				ctx->rinfo[i].bss[j].config.AuthMode,
				get_authmode_str(ctx->rinfo[i].bss[j].config.AuthMode, buf1, 256),
				ctx->rinfo[i].bss[j].config.EncrypType,
				get_encryption_str(ctx->rinfo[i].bss[j].config.EncrypType),
				ctx->rinfo[i].bss[j].config.WPAKey,
				ctx->rinfo[i].bss[j].config.map_vendor_extension,
				get_map_vendor_extension_str(ctx->rinfo[i].bss[j].config.map_vendor_extension, buf2, 256),
				ctx->rinfo[i].bss[j].config.hidden_ssid);
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf fail\n");
				return -1;
			}
			len += ret;
#endif
			ret = snprintf(buf + len, max_len - len, "\n");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf fail\n");
				return -1;
			}
			len += ret;
		}

		j = 0;
		ret = snprintf(buf + len, max_len - len, "\t\tradio opclass info(cnt=%d):\n",
				ctx->rinfo[i].basic_cap.op_class_num);
		if (os_snprintf_error(max_len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;
		dl_list_for_each(opc, &ctx->rinfo[i].basic_cap.op_class_list, struct operating_class, entry) {
			ret = snprintf(buf + len, max_len - len,
			"\t\t\topclass=%d; max_tx_pwr=%d; non_operch_num=%d; non_operch_list=",
			opc->class_number, opc->max_tx_pwr, opc->non_operch_num);
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf fail\n");
				return -1;
			}
			len += ret;
			for (j = 0; j < opc->non_operch_num; j++) {
				ret = snprintf(buf + len, max_len - len,
					"%d ", opc->non_operch_list[j]);
				if (os_snprintf_error(max_len - len, ret)) {
					err(DEBUG_CAT_MISC, "snprintf fail\n");
					return -1;
				}
				len += ret;
			}
			ret = snprintf(buf + len, max_len - len, "\n");
				if (os_snprintf_error(max_len - len, ret)) {
					err(DEBUG_CAT_MISC, "snprintf fail\n");
					return -1;
				}
				len += ret;
		}
	}

	return len;
}

int dump_init_params(struct p1905_managerd_ctx *ctx, char *buf, int max_len)
{
	int ret = 0, len = 0;

	ret = snprintf(buf, max_len, "\ninit params info:\n");
	if (os_snprintf_error(max_len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	ret = snprintf(buf + len, max_len - len,
		"\tversion_1905=%s; role/service=%d(%s); cert_mode=%d; core_dump=%d\n",
		VERSION_1905, ctx->role, (ctx->role == 0 ? "controller" : "agent"),
		ctx->MAP_Cer, ctx->core_dump);
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	return len;
}

int dump_bss_cfg_info(struct p1905_managerd_ctx *ctx, char *buf, int max_len)
{
	int ret = 0, len = 0;
	unsigned int i = 0;
	char buf1[256] = {0};

	ret = snprintf(buf, max_len, "\nbss config(%s) info:\n",
		ctx->wts_bss_cfg_file);
	if (os_snprintf_error(max_len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	for (i = 0; i < ctx->bss_config_num; i++) {
		ret = snprintf(buf + len, max_len - len,
			"\t%d: almac=%02x:%02x:%02x:%02x:%02x:%02x; oper_class=%s; band_support=%d(%s); ",
			i + 1, MAC2STR(ctx->bss_config[i].mac), ctx->bss_config[i].oper_class,
			ctx->bss_config[i].band_support, get_band_cap_str(ctx->bss_config[i].band_support));
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;
		ret = snprintf(buf + len, max_len - len,
			"ssid=%s; authmode=0x%04x(%s); encryptype=0x%04x(%s);\n\t key=%s; ",
			ctx->bss_config[i].ssid,
			ctx->bss_config[i].authmode, get_authmode_str(ctx->bss_config[i].authmode, buf1, 256),
			ctx->bss_config[i].encryptype, get_encryption_str(ctx->bss_config[i].encryptype),
			ctx->bss_config[i].key);
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;
		ret = snprintf(buf + len, max_len - len,
			"wfa_vextension=%02x(%s); hidden_ssid=%d; pvid=%d; pcp=%d; vid=%d; mlo_grp_id=%d\n",
			ctx->bss_config[i].wfa_vendor_extension,
			get_map_vendor_extension_str(ctx->bss_config[i].wfa_vendor_extension, buf1, 256),
			ctx->bss_config[i].hidden_ssid,
			ctx->bss_config[i].pvid, ctx->bss_config[i].pcp, ctx->bss_config[i].vid,
			ctx->bss_config[i].mlo_grp_id);
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;
	}

	return len;
}

int dump_alloc_buf_info(struct p1905_managerd_ctx *ctx, char *buf, int max_len)
{
	int ret = 0, len = 0;

	ret = snprintf(buf, max_len, "\nalloc buf info:\n");
	if (os_snprintf_error(max_len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	ret = snprintf(buf + len, max_len - len,
		"\tctx_size=%zu; trx_buf_size=%u; tlv_buf_size=%u; ",
		sizeof(*ctx), ctx->trx_buf.buf_len, ctx->tlv_buf.buf_len);
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;
	ret = snprintf(buf + len, max_len - len,
		"reassemble_buf_size=%u; revd_tlv_size=%u; ",
		ctx->reassemble_buf.buf_len, ctx->revd_tlv.buf_len);
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;
	ret = snprintf(buf + len, max_len - len,
		"last_rx_data_size=%u; last_tx_data_size=%u\n",
		ctx->last_rx_buf_len, ctx->last_tx_buf_len);
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	return len;
}

int dump_sock_info(struct p1905_managerd_ctx *ctx, char *buf, int max_len)
{
	struct _1905_interface_cli *dst;
	int ret = 0, len = 0;
	unsigned int i = 0;
	char addr_txt[200] = {0};

	ret = snprintf(buf, max_len, "\nsock info:\n");
	if (os_snprintf_error(max_len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	ret = snprintf(buf + len, max_len - len,
		"\tbr_addr=%02x:%02x:%02x:%02x:%02x:%02x; br_ifid=%d; br_name=%s; sock_br=%d\n",
		MAC2STR(ctx->br_addr), ctx->br_ifid, ctx->br_name, ctx->sock_br);
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	for (i = 0; i < ctx->itf_number; i++) {
		ret = snprintf(buf + len, max_len - len,
			"\t%d: mac=%02x:%02x:%02x:%02x:%02x:%02x; name=%s; ifid=%d; sock=%d;"
			" lldp_sock=%d\n",
			i + 1, MAC2STR(ctx->itf[i].mac_addr), ctx->itf[i].if_name,
			ctx->itf[i].if_index, ctx->sock_inf_recv_1905[i],
			ctx->sock_lldp[i]);
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;
	}

	ret = snprintf(buf + len, max_len - len, "\tctrl_sock=%d\n", ctx->ctrl_sock);
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	ret = snprintf(buf + len, max_len - len, "\t_1905_ctrl:\n");
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	ret = snprintf(buf + len, max_len - len, "\t\tsock=%d; addr=%s; ",
		ctx->_1905_ctrl.sock, ctx->_1905_ctrl.addr.sun_path + 1);
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;
	ret = snprintf(buf + len, max_len - len, "own_recv_buf_len=%d; "
		"default_own_recv_len=%d; peer_recv_buf_len=%d; default_peer_recv_len=%d\n",
		ctx->_1905_ctrl.own_recv_buf_len, ctx->_1905_ctrl.default_own_recv_len,
		ctx->_1905_ctrl.peer_recv_buf_len, ctx->_1905_ctrl.default_peer_recv_len);
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	i = 0;
	dl_list_for_each(dst,  &ctx->_1905_ctrl.daemon_cli_list, struct _1905_interface_cli, list)
	{
		i++;
		printf_encode(addr_txt, sizeof(addr_txt),
		      (unsigned char *)dst->addr.sun_path,
		      dst->addrlen - offsetof(struct sockaddr_un, sun_path));
		ret = snprintf(buf + len, max_len - len, "\t\tattach_daemon(%d): %s; addr=%s; proto=%d\n",
			i, dst->daemon_name, addr_txt, dst->addr.sun_family);
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;
	}

	return len;
}

int dump_mlo_init_info(struct p1905_managerd_ctx *ctx, char *buf, int max_len)
{
	int ret = 0, len = 0;
	struct mlo_config_db *mlo_cfg = NULL;
	struct affiliated_ap_db *aff_ap = NULL;
	struct mld_bss_config_db *bss_mld = &ctx->wts_ctrl_mld_cfg;
#ifdef MAP_R6
	struct mld_bsta_config_db *sta_db = NULL;
	struct affiliated_sta_db *aff_sta = NULL;
#endif
	if (ctx->role == AGENT)
		return 0;

	ret = snprintf(buf, max_len, "\nMLO info:\n");
	if (os_snprintf_error(max_len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	/* AP MLD info */
	ret = snprintf(buf + len, max_len - len, "AP MLO config:");
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	dl_list_for_each(mlo_cfg, &bss_mld->mlo_cfg_list, struct mlo_config_db, list) {
		ret = snprintf(buf + len, max_len - len, "\n\tmld grp id %d, ssid %s, affiliated ap cnt %d, ruid:",
			mlo_cfg->mld_grp_id,  mlo_cfg->ssid, mlo_cfg->num_affiliated_ap);
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;

		dl_list_for_each(aff_ap, &mlo_cfg->aff_ap_list, struct affiliated_ap_db, list) {
			ret = snprintf(buf + len, max_len - len, " "MACSTR"",
				MAC2STR(aff_ap->ruid));
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf fail\n");
				return -1;
			}
			len += ret;
		}
	}

#ifdef MAP_R6
	/* bSTA MLD info */
	ret = snprintf(buf + len, max_len - len, "\n\nbSTA MLO config:\n");
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	dl_list_for_each(sta_db, &ctx->agent_bsta_list, struct mld_bsta_config_db, list) {
		ret = snprintf(buf + len, max_len - len, "\talmac "MACSTR", affiliated bsta cnt %d, band:",
			MAC2STR(sta_db->al_mac), sta_db->num_affiliated_sta);
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;

		dl_list_for_each(aff_sta, &sta_db->affiliated_sta_list, struct affiliated_sta_db, list) {
			if (aff_sta->band) {
				ret = snprintf(buf + len, max_len - len, " %s", band_2_string(aff_sta->band));
				if (os_snprintf_error(max_len - len, ret)) {
					err(DEBUG_CAT_MISC, "snprintf fail\n");
					return -1;
				}
				len += ret;
			} else {
				ret = snprintf(buf + len, max_len - len, " "MACSTR"", MAC2STR(aff_sta->ruid));
				if (os_snprintf_error(max_len - len, ret)) {
					err(DEBUG_CAT_MISC, "snprintf fail\n");
					return -1;
				}
				len += ret;
			}
		}
		ret = snprintf(buf + len, max_len - len, "\n");
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;
	}
#endif
	return len;
}

#ifdef EM_PLUS_SUPPORT
int dump_emplus_init_info(struct p1905_managerd_ctx *ctx, char *buf, int max_len)
{
	int ret = 0, len = 0;
	int i = 0;
	struct emplus_dev_metrics dev_metrics = { 0 };
	struct emplus_feature_list *feat_list;
	struct emplus_feature_prof *feat_prof = &ctx->feature_prof;

	ret = snprintf(buf, max_len, "\nEmplus info:\n");
	if (os_snprintf_error(max_len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	/* get device boot_id */
	get_dev_boot_id(ctx);
	ret = snprintf(buf + len, max_len - len, "\templus boot_id: %d\n", ctx->boot_id);
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	ret = snprintf(buf + len, max_len - len, "\templus version:%d sub_version:%d\n",
		feat_prof->master_ver, feat_prof->sub_ver);
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	if (!SLIST_EMPTY(&feat_prof->feature_list_head)) {
		SLIST_FOREACH(feat_list, &feat_prof->feature_list_head, next) {
			ret = snprintf(buf + len, max_len - len, "\templus support feature_id = %d, feautre_name = %s\n",
				feat_list->feature_id, getFeatureName(feat_list->feature_id));
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf fail\n");
				return -1;
			}
			len += ret;
		}
	}
	ret = snprintf(buf + len, max_len - len, "\templus client_id=%s\n",
		ctx->client_id);
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	ret = snprintf(buf + len, max_len - len, "\templus client_secret=%s\n",
		ctx->client_secret);
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	ret = snprintf(buf + len, max_len - len, "\templus product_class=%d\n",
		ctx->emplus_product_class);
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;


	ret = snprintf(buf + len, max_len - len, "\templus bh_bss_number = %d\n",
		ctx->bh_bss_number);
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	ret = snprintf(buf + len, max_len - len, "\templus bh_bss_name=");
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	for (i = 0; i < ctx->bh_bss_number; i++) {
		if (i > 0) {
			ret = snprintf(buf + len, max_len - len, "; ");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf fail\n");
				return -1;
			}
			len += ret;
		}
		ret = snprintf(buf + len, max_len - len, "%s", ctx->bh_bss_name[i]);
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;
	}
	ret = snprintf(buf + len, max_len - len, "\n");
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	ret = snprintf(buf + len, max_len - len, "\templus guest_bss_number = %d\n",
		ctx->guest_bss_number);
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	ret = snprintf(buf + len, max_len - len, "\templus guest_bss_name=");
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	for (i = 0; i < ctx->guest_bss_number; i++) {
		if (i > 0) {
			ret = snprintf(buf + len, max_len - len, "; ");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf fail\n");
				return -1;
			}
			len += ret;
		}
		ret = snprintf(buf + len, max_len - len, "%s", ctx->guest_bss_name[i]);
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;
	}

	ret = snprintf(buf + len, max_len - len, "\n");
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	/*get device metrics info*/
	get_emplus_dev_metrics(&dev_metrics);
	ret = snprintf(buf + len, max_len - len, "Emplus Dev Metrics:\n");
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	ret = snprintf(buf + len, max_len - len, "\templus dev cpu temparature=%d\n", dev_metrics.cpu_temparature);
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	ret = snprintf(buf + len, max_len - len, "\templus devcpu load rate=%d\n", dev_metrics.cpu_load_rate);
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	ret = snprintf(buf + len, max_len - len, "\templus dev total memory=%d\n", dev_metrics.total_memory);
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	ret = snprintf(buf + len, max_len - len, "\templus dev free memory=%d\n", dev_metrics.free_memory);
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	ret = snprintf(buf + len, max_len - len, "\templus dev cached memory=%d\n", dev_metrics.cached_memory);
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	ret = snprintf(buf + len, max_len - len, "\templus dev uptime=%d\n", dev_metrics.uptime);
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;



	return len;
}
#endif

int dump_init_info(struct p1905_managerd_ctx *ctx, char *buf, int max_len)
{
	int ret = 0, len = 0;

	ret = get_log_info(buf + len, max_len - len);
	if (ret < 0) {
		err(DEBUG_CAT_MISC, "get_log_info fail\n");
		return -1;
	}
	len += ret;

	ret = dump_init_params(ctx, buf + len, max_len - len);
	if (ret < 0) {
		err(DEBUG_CAT_MISC, "dump_init_params fail\n");
		return -1;
	}
	len += ret;

	ret = dump_map_cfg_params(ctx, buf + len, max_len - len);
	if (ret < 0) {
		err(DEBUG_CAT_MISC, "dump_map_cfg_params fail\n");
		return -1;
	}
	len += ret;

	ret = dump_intf_info(ctx, buf + len, max_len - len);
	if (ret < 0) {
		err(DEBUG_CAT_MISC, "dump_intf_info fail\n");
		return -1;
	}
	len += ret;

	ret = dump_bss_cfg_info(ctx, buf + len, max_len - len);
	if (ret < 0) {
		err(DEBUG_CAT_MISC, "dump_bss_cfg_info fail\n");
		return -1;
	}
	len += ret;

	ret = dump_alloc_buf_info(ctx, buf + len, max_len - len);
	if (ret < 0) {
		err(DEBUG_CAT_MISC, "dump_alloc_buf_info fail\n");
		return -1;
	}
	len += ret;

	ret = dump_sock_info(ctx, buf + len, max_len - len);
	if (ret < 0) {
		err(DEBUG_CAT_MISC, "dump_sock_info fail\n");
		return -1;
	}
	len += ret;

	ret = dump_mlo_init_info(ctx, buf + len, max_len - len);
	if (ret < 0) {
		err(DEBUG_CAT_MISC, "dump_mlo_init_info fail\n");
		return -1;
	}
	len += ret;

#ifdef EM_PLUS_SUPPORT
	ret = dump_emplus_init_info(ctx, buf + len, max_len - len);
	if (ret  < 0) {
		err(DEBUG_CAT_MISC, "dump_emplus_init_info fail\n");
		return -1;
	}
	len += ret;
#endif /* EM_PLUS_SUPPORT */
	return len;

}
#ifdef MAP_R2
int dump_bss_table(struct p1905_managerd_ctx *ctx, char *buf, int max_len)
{
	struct operational_bss *bss = NULL;
	int ret = 0, len = 0;
	unsigned int i = 0;

	ret = snprintf(buf, max_len, "\nbss table:\n");
	if (os_snprintf_error(max_len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	dl_list_for_each(bss, &ctx->bss_head, struct operational_bss, entry) {
		ret = snprintf(buf + len, max_len - len,
			"\t%d: mac="MACSTR"; almac="MACSTR"; ssid=%s; vid=%d\n",
			++i, MAC2STR(bss->mac), MAC2STR(bss->almac), bss->ssid,
			bss->vid);
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;
	}

	return len;
}

int dump_clients_table(struct p1905_managerd_ctx *ctx, char *buf, int max_len)
{
	struct assoc_client *client = NULL;
	int ret = 0, len = 0;
	unsigned int i = 0, j = 0;

	ret = snprintf(buf, max_len, "\nclients table:\n");
	if (os_snprintf_error(max_len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	for (i = 0; i < HASH_TABLE_SIZE; i++) {
		dl_list_for_each(client, &ctx->clients_table[i], struct assoc_client, entry) {
			ret = snprintf(buf + len, max_len - len,
					"\t%d: hash_id=%d; mac="MACSTR"; bssid="MACSTR"; al_mac="MACSTR
					"disassoc=%d; ssid=%s; vid=%d; apply_2_mapfilter=%d\n",
				++j, i, MAC2STR(client->mac), MAC2STR(client->bssid), MAC2STR(client->al_mac),
				client->disassoc, client->ssid, client->vlan_id, client->apply_2_mapfilter);
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf fail\n");
				return -1;
			}
			len += ret;
		}
	}

	return len;
}
#endif

int dump_autoconfig_info(struct p1905_managerd_ctx *ctx, char *buf, int max_len)
{
	int ret = 0, len = 0;

	ret = dump_intf_info(ctx, buf + len, max_len - len);
	if (ret < 0) {
		err(DEBUG_CAT_MISC, "dump_intf_info fail\n");
		return -1;
	}
	len += ret;

	ret = dump_radio_bss_info(ctx, buf + len, max_len - len);
	if (ret < 0) {
		err(DEBUG_CAT_MISC, "dump_radio_info fail\n");
		return -1;
	}
	len += ret;
#ifdef MAP_R2
	ret = dump_bss_table(ctx, buf + len, max_len - len);
	if (ret < 0) {
		err(DEBUG_CAT_MISC, "dump_bss_table fail\n");
		return -1;
	}
	len += ret;

	ret = dump_clients_table(ctx, buf + len, max_len - len);
	if (ret < 0) {
		err(DEBUG_CAT_MISC, "dump_clients_table fail\n");
		return -1;
	}
	len += ret;
#endif
	if (ctx->role == AGENT) {
		ret = dump_sm_state_info(ctx, buf + len, max_len - len);
		if (ret < 0) {
			err(DEBUG_CAT_MISC, "dump_sm_state_info fail\n");
			return -1;
		}
		len += ret;

		ret = dump_controller_info(ctx, buf + len, max_len - len);
		if (ret < 0) {
			err(DEBUG_CAT_MISC, "dump_controller_info fail\n");
			return -1;
		}
		len += ret;
	}

	if (ctx->role == CONTROLLER) {
		ret = dump_bss_config_info(ctx, buf + len, max_len - len);
		if (ret < 0) {
			err(DEBUG_CAT_MISC, "dump_bss_config_info fail\n");
			return -1;
		}
		len += ret;
	}

	return len;

}
