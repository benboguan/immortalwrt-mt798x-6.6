/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *
 * switch_layer.c: switch layer for MAP
 * Author: Sirui Zhao <Sirui.Zhao@mediatek.com>
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <linux/if.h>
#include <pthread.h>
#include <stdbool.h>

#include "ethernet_layer.h"
#include "debug.h"
#include "netlink_event.h"

#include "common.h"
#include "switch_nl.h"
#include "switch_legacy_ioctl.h"
#include "switch_layer.h"
#include "switch_layer_mt7628.h"
#include "bridge_parse.h"


#if defined(CONFIG_RALINK_MT7628)
/*Function name:	mt7628_get_lan_wan_portmaps()
 *Description:		input the vid , return it's portmaps
 *	exp:	vid		fid		portmap
 *			1		0		1111-111
 *	vid:	1 portmap: should conert to uint.
 *Parameter	:
 *	@vid:		input the lan_vid or wan_vid (user_cfg)
 *	@port_map:	output the portmap (unsigned int)
 *Return:
 *	0: Success, Other fail
 *other:
 *	for 7628 switch use
 */

int mt7628_get_lan_wan_portmaps(int vid, unsigned int *port_map)
{
	int i = 0, j = 0, vid_val = 0, tmp_vid = 0, portmap_val = 0;
	unsigned int bit_offset1 = 1;
	unsigned int bit_offset2 = 1;

	notice(DEBUG_CAT_ETH, "idx   vid  portmap\n");
	for (i = 0; i < 8; i++) {
		(void)switch_reg_read(REG_ESW_VLAN_ID_BASE + 4*i, &vid_val);
		(void)switch_reg_read(REG_ESW_VLAN_MEMB_BASE + 4*(i/2), &portmap_val);
		notice(DEBUG_CAT_ETH, " %2d  %4d  ", 2*i, vid_val & 0xfff);

		if (i%2 == 0) {
			notice(DEBUG_CAT_ETH, "%c", (portmap_val & 0x00000001) ? '1' : '-');//p0
			notice(DEBUG_CAT_ETH, "%c", (portmap_val & 0x00000002) ? '1' : '-');//p1
			notice(DEBUG_CAT_ETH, "%c", (portmap_val & 0x00000004) ? '1' : '-');//p2
			notice(DEBUG_CAT_ETH, "%c", (portmap_val & 0x00000008) ? '1' : '-');//p3
			notice(DEBUG_CAT_ETH, "%c", (portmap_val & 0x00000010) ? '1' : '-');//p4
			notice(DEBUG_CAT_ETH, "%c", (portmap_val & 0x00000020) ? '1' : '-');//p5
			notice(DEBUG_CAT_ETH, "%c\n", (portmap_val & 0x00000040) ? '1' : '-');//p6
			bit_offset1 = 0;
		} else {
			notice(DEBUG_CAT_ETH, "%c", (portmap_val & 0x00010000) ? '1' : '-');
			notice(DEBUG_CAT_ETH, "%c", (portmap_val & 0x00020000) ? '1' : '-');
			notice(DEBUG_CAT_ETH, "%c", (portmap_val & 0x00040000) ? '1' : '-');
			notice(DEBUG_CAT_ETH, "%c", (portmap_val & 0x00080000) ? '1' : '-');
			notice(DEBUG_CAT_ETH, "%c", (portmap_val & 0x00100000) ? '1' : '-');
			notice(DEBUG_CAT_ETH, "%c", (portmap_val & 0x00200000) ? '1' : '-');
			notice(DEBUG_CAT_ETH, "%c\n", (portmap_val & 0x00400000) ? '1' : '-');
			bit_offset1 = 16;
		}
		notice(DEBUG_CAT_ETH, " %2d  %4d  ", 2*i+1, ((vid_val & 0xfff000) >> 12));
		if (i%2 == 0) {
			notice(DEBUG_CAT_ETH, "%c", (portmap_val & 0x00000100) ? '1' : '-');
			notice(DEBUG_CAT_ETH, "%c", (portmap_val & 0x00000200) ? '1' : '-');
			notice(DEBUG_CAT_ETH, "%c", (portmap_val & 0x00000400) ? '1' : '-');
			notice(DEBUG_CAT_ETH, "%c", (portmap_val & 0x00000800) ? '1' : '-');
			notice(DEBUG_CAT_ETH, "%c", (portmap_val & 0x00001000) ? '1' : '-');
			notice(DEBUG_CAT_ETH, "%c", (portmap_val & 0x00002000) ? '1' : '-');
			notice(DEBUG_CAT_ETH, "%c\n", (portmap_val & 0x00004000) ? '1' : '-');
			bit_offset2 = 8;
		} else {
			notice(DEBUG_CAT_ETH, "%c", (portmap_val & 0x01000000) ? '1' : '-');
			notice(DEBUG_CAT_ETH, "%c", (portmap_val & 0x02000000) ? '1' : '-');
			notice(DEBUG_CAT_ETH, "%c", (portmap_val & 0x04000000) ? '1' : '-');
			notice(DEBUG_CAT_ETH, "%c", (portmap_val & 0x08000000) ? '1' : '-');
			notice(DEBUG_CAT_ETH, "%c", (portmap_val & 0x10000000) ? '1' : '-');
			notice(DEBUG_CAT_ETH, "%c", (portmap_val & 0x20000000) ? '1' : '-');
			notice(DEBUG_CAT_ETH, "%c\n", (portmap_val & 0x40000000) ? '1' : '-');
			bit_offset2 = 24;
		}

		tmp_vid = vid_val & 0xfff;
		debug(DEBUG_CAT_ETH, "tmp_vid=%#x, vid=%#x, portmap_val=%#x\n",
			tmp_vid, vid, portmap_val);

		if (vid == tmp_vid && (portmap_val & 0x01) != 0) {
			for (j = 0; j < SWITCH_MAX_PORT; j++) {
				if (portmap_val & (BIT(j + bit_offset1)))
					*port_map |= (0x00000001 << j);
			}
			debug(DEBUG_CAT_ETH, "port_map=%#x, portmap_val=%#x\n",
				*port_map, portmap_val);
			break;
		}

		tmp_vid = ((vid_val & 0xfff000) >> 12);
		debug(DEBUG_CAT_ETH, "tmp_vid=%#x, vid=%#x, portmap_val=%#x\n",
			tmp_vid, vid, portmap_val);

		if ((vid == tmp_vid) && ((portmap_val & 0x01) != 0)) {
			for (j = 0; j < SWITCH_MAX_PORT; j++) {
				if (portmap_val & (BIT(j + bit_offset2)))
					*port_map |= (0x00000001 << j);
			}
			debug(DEBUG_CAT_ETH, "port_map=%#x, portmap_val=%#x\n",
				*port_map, portmap_val);
			break;
		}

		usleep(1000);
	}

	if (j >= 8) {
		warn(DEBUG_CAT_ETH, "get switch vlan info timeout\n");
		return -1;
	}
	debug(DEBUG_CAT_ETH, "port_map=%#x\n", *port_map);
	return 0;
}

/*
 *Function name:	switch_layer_get_7628_table_entry()
 *Description:		register write for old switch chip like 7628 switch
 *						to get sta mac entry.
 *Parameter	:
 *	@entry_list: output the sta mac entry to entry_list
 *Return:
 *	0: Success, Other fail
 *other:
 *	for 7628 switch use
 */
int switch_layer_get_7628_table_entry(struct dl_list *entry_list)
{
	int i, k, value, mac;
	int port_index = 0;
	unsigned char temp_mac[ETH_ALEN] = {0};
	int tmp_port_idx = 0;
	unsigned int tmp_age = 0;
	int vid[16] = {0};
	int err_cnt = 0;
	struct ethernet_client_entry *entry = NULL;

	if (entry_list == NULL) {
		warn(DEBUG_CAT_ETH, "ERROR! input entry_list is null.");
		return -1;
	}

	for (i = 0; i < 8; i++) {
		(void)switch_reg_read(REG_ESW_VLAN_ID_BASE + 4*i, &value);
		vid[2 * i] = value & 0xfff;
		vid[2 * i + 1] = (value & 0xfff000) >> 12;
	}
	/*Init Dlist*/
	dl_list_init(entry_list);

	(void)switch_reg_write(REG_ESW_TABLE_SEARCH, 0x1);
	for (i = 0; i < 0x400; i++) {
		while (1) {
			(void)switch_reg_read(REG_ESW_TABLE_STATUS0, &value);
			if (value & 0x1) {
				/*search_rdy*/
				if ((value & 0x70) == 0) {
					err_cnt++;
					warn(DEBUG_CAT_ETH, "found an unused entry (age = 3'b000), err_count(%d),please check!\n", err_cnt);
					break;
				}
				tmp_port_idx = (value >> 12) & 0x7f; //r_port_map
				tmp_age = (value >> 4) & 0x7;//age_time

				(void)switch_reg_read(REG_ESW_TABLE_STATUS2, &mac);
				/*int to mac addr array 0-3*/
				temp_mac[0] = (unsigned char) ((mac>>(3 * 8)) & 0xff);
				temp_mac[1] = (unsigned char) ((mac>>(2 * 8)) & 0xff);
				temp_mac[2] = (unsigned char) ((mac>>(1 * 8)) & 0xff);
				temp_mac[3] = (unsigned char) ((mac>>(0 * 8)) & 0xff);

				(void)switch_reg_read(REG_ESW_TABLE_STATUS1, &mac);
				/*int to mac addr array 4-5  */
				temp_mac[4] = (unsigned char) ((mac>>(1 * 8)) & 0xff);
				temp_mac[5] = (unsigned char) ((mac>>(0 * 8)) & 0xff);

				/*check the mac vid infos*/
				/*port_map infos*/
				for (k = 0; k < MAX_PHY_PORT; k++) {
					if (tmp_port_idx & (0x01 << k))
						break;
				}

				if (k >= MAX_PHY_PORT)
					break;

				if (k < MAX_PHY_PORT) {
					port_index = k;
					/*create the switch*/
					debug(DEBUG_CAT_ETH, "port_index(%x):%d, age:%d, mac: "MACSTR"\n",
					tmp_port_idx, port_index, tmp_age, temp_mac[0], temp_mac[1], temp_mac[2],
					temp_mac[3], temp_mac[4], temp_mac[5]);

					entry = switch_create_table_entry(port_index, tmp_age, temp_mac, 0);
					if (entry == NULL) {
						warn(DEBUG_CAT_ETH, "allocate switch client entry fail\n");
						break;
					}
					/*add entry to the dl*/
					dl_list_add(entry_list, &entry->entry);

				} else {
					notice(DEBUG_CAT_ETH, "Can't find the port index!\n");
					break;
				}

				if (value & 0x2) {
					debug(DEBUG_CAT_ETH, "end of table %d\n", i);
					goto succ;
				}
				break;
			} else if (value & 0x2) { //at_table_end
				debug(DEBUG_CAT_ETH, "found the last entry %d (not ready)\n", i);
				goto succ;
			}
			usleep(5000);
		}
		if (err_cnt > SWITCH_ERROR_COUNTER) {
			warn(DEBUG_CAT_ETH, "abnormal case, ERR COUNT is over %d\n", SWITCH_ERROR_COUNTER);
			goto fail;
		}
		/* search for next address */
		(void)switch_reg_write(REG_ESW_TABLE_SEARCH, 0x2);
	}

fail:
	switch_clear_entry_list(entry_list);
	return -1;

succ:
	return 0;
}

/*
 *
 *Function name:	switch_port_find_by_mac()
 *Description:		find the sepical mac vid of ageout time
 *						in switch dump table.
 *Parameter	:
 *	@mac_addr:	input mac_addr
 *	@vid:		input vid of want to know
 *	@age:		output age out time of this mac
 *Return:
 *	-1: fail, other success return the port_map
 *other:
 */

int mt7628_port_find_by_mac(unsigned char *mac_addr, int in_vid, unsigned char *age)
{
	int i = 0, j = 0, k = 0, value = 0, mac = 0;
	unsigned char temp_mac[ETH_ALEN] = {0};
	unsigned int temp_vid = 0;
	unsigned int temp_age = 0;
	int vid[16];

	for (i = 0; i < 8; i++) {
		(void)switch_reg_read(REG_ESW_VLAN_ID_BASE + 4*i, &value);
		vid[2 * i] = value & 0xfff;
		vid[2 * i + 1] = (value & 0xfff000) >> 12;
	}

	(void)switch_reg_write(REG_ESW_TABLE_SEARCH, 0x1);

	for (i = 0; i < 0x400; i++) {
		while (1) {
			(void)switch_reg_read(REG_ESW_TABLE_STATUS0, &value);
			if (value & 0x1) { //search_rdy
				if ((value & 0x70) == 0) {
					warn(DEBUG_CAT_ETH, "found an unused entry (age = 3'b000), please check!\n");
					return -1;
				}
				j = (value >> 12) & 0x7f; //r_port_map
				temp_vid = vid[(value >> 7) & 0xf];//vid value
				temp_age = (value >> 4) & 0x7;

				(void)switch_reg_read(REG_ESW_TABLE_STATUS2, &mac);
				/*int to mac addr array 0-3*/
				temp_mac[0] = (unsigned char) ((mac>>(3 * 8)) & 0xff);
				temp_mac[1] = (unsigned char) ((mac>>(2 * 8)) & 0xff);
				temp_mac[2] = (unsigned char) ((mac>>(1 * 8)) & 0xff);
				temp_mac[3] = (unsigned char) ((mac>>(0 * 8)) & 0xff);

				(void)switch_reg_read(REG_ESW_TABLE_STATUS1, &mac);
				/*int to mac addr array 4-5  */
				temp_mac[4] = (unsigned char) ((mac>>(1 * 8)) & 0xff);
				temp_mac[5] = (unsigned char) ((mac>>(0 * 8)) & 0xff);
				/*check the mac vid infos*/
				if (!os_memcmp(temp_mac, mac_addr, ETH_ALEN)) {
					if (temp_vid == in_vid) {
						/*age time*/
						*age = temp_age;
						/*port_map infos*/
						for (k = 0; k < SWITCH_MAX_PORT; k++) {
							if (j & (0x01 << k)) {
								debug(DEBUG_CAT_ETH,
									"find the mac_add: age: %d , port map(%#x): %d\n",
									*age, j, k);
								return j;
							}
						}
						if (k >= SWITCH_MAX_PORT) {
							info(DEBUG_CAT_ETH, "Can't find the port map!");
							return -1;
						}
					}
				}

				if (value & 0x2) {
					info(DEBUG_CAT_ETH, "end of table %d\n", i);
					return -1;
				}
				break;
			} else if (value & 0x2) { //at_table_end
				info(DEBUG_CAT_ETH, "found the last entry %d (not ready)\n", i);
				return -1;
			}
			usleep(5000);
		}
		/* search for next address */
		(void)switch_reg_write(REG_ESW_TABLE_SEARCH, 0x2);
	}
	return -1;
}

#endif

