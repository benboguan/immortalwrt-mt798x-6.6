/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

/*
 * switch_layer.h: switch layer for MAP
 *
 * Author: Sirui Zhao <Sirui.Zhao@mediatek.com>
 */
#ifndef SWITCH_LAYER_AN8855_H
#define SWITCH_LAYER_AN8855_H
#include <sys/queue.h>
#include "switch_layer.h"


#define AN8855_GENL_NAME "an8855"
#define AN8855_DSA_GENL_NAME "an8855_dsa"

#define CHIP_AN8855								0x8855

#define AN8855_L2_MAC_SET_NUM					4
#define AN8855_L2_MAX_ADDR_NUM					512
#define AN8855_SWITCH_BUSY_TIME					200

#define PMSR(p)									(0x10210010 + (p) * 0x200)
#define AN8855_SWITCH_MAX_PORT					6
#define AN8855_BIT_OFFSET						26

#define AN8855_REG_ESW_WT_MAC_ATA1				0x10200304
#define AN8855_REG_ESW_WT_MAC_ATA2				0x10200308
#define AN8855_REG_ESW_WT_MAC_ATWD				0x10200324
#define AN8855_REG_ESW_WT_MAC_ATWD2				0x10200324
#define AN8855_REG_ESW_WT_MAC_ATC				0x10200300
#define AN8855_ATC_ENTRY_HIT_OFFSET				12
#define AN8855_ATC_ENTRY_HIT_MASK				(BIT(4)-1)
#define AN8855_ATC_ADDR_OFFSET					16
#define AN8855_ATC_ADDR_MASK					(BIT(9)-1)
#define AN8855_REG_ESW_TABLE_ATRDS				0x10200330
#define AN8855_REG_ESW_TABLE_ATRD0				0x10200334
#define AN8855_REG_ESW_TABLE_ATRD1				0x10200338
#define AN8855_ATRD1_MAC_AGETIME_OFFSET			3
#define AN8855_ATRD1_MAC_AGETIME_MASK			(BIT(9)-1)
#define AN8855_REG_ESW_TABLE_ATRD2				0x1020033c
#define AN8855_REG_ESW_TABLE_ATRD3				0x10200340
#define AN8855_ATRD3_MAC_PORT_OFFSET			0
#define AN8855_ATRD3_MAC_PORT_LENGTH			(BIT(8)-1)
#define AN8855_REG_ESW_MAC_AAC					0x102000a0
#define AN8855_REG_ESW_MAC_ATRDS				0x10200330

#define AN8855_REG_ESW_VLAN_VTCR				0x10200600
#define AN8855_REG_ESW_VLAN_VLNRDATA0			0x10200618
#define AN8855_REG_ESW_VLAN_VLNRDATA1			0x1020061c
#define AN8855_REG_ESW_VLAN_VLNRDATA2			0x10200620
#define AN8855_REG_ESW_VLAN_VLNRDATA3			0x10200624
#define AN8855_REG_ESW_VLAN_VLNRDATA4			0x10200628
#define AN8855_REG_ESW_VLAN_VLNWDATA0			0x10200604
#define AN8855_REG_ESW_VLAN_VLNWDATA1			0x10200608
#define AN8855_REG_ESW_VLAN_VLNWDATA2			0x1020060c
#define AN8855_REG_ESW_VLAN_VLNWDATA3			0x10200610
#define AN8855_REG_ESW_VLAN_VLNWDATA4			0x10200614


#define L2_AGING_MS_CONSTANT    (1024)
#define L2_AGING_1000MS         (1000)
#define L2_AGING_TIME(__cnt__, __unit__)   \
		(((__cnt__) + 1) * ((__unit__) + 1) * L2_AGING_MS_CONSTANT / L2_AGING_1000MS)

int an8855_netlink_init(void);
int an8855_get_switch_mode(unsigned int *mode);
int an8855_get_port_status(unsigned char port, int *status);
int an8855_get_port_speed(unsigned char port, int *speed);
int an8855_get_phy_speed(unsigned char port);
int an8855_defalut_setting(void);
int an8855_set_port_block(unsigned char port, int enable);
void an8855_acl_enable(void);
int an8855_set_wan_rule(void);
int an8855_set_lan_rule(unsigned char mac_addr[], void *data);
int an8855_port_find_by_mac(unsigned char *mac_addr, int vid, unsigned char *age);
int an8855_port_find_by_mac_fid(unsigned char *mac_addr, int fid, unsigned char *age);
int an8855_get_port_type(unsigned int *lport_map, unsigned int *wport_map);
int an8855_get_table_entry(struct dl_list *entry_list);
int an8855_clear_table(void);
int an8855_clear_port_table(unsigned char port);
int an8855_vlan_set(unsigned short vid[], unsigned short vid_cnt, unsigned char active, enum vlan_type type);
int an8855_get_lan_wan_portmaps(int vid, unsigned int *port_map);
void an8855_switch_deinit(void);
#endif
