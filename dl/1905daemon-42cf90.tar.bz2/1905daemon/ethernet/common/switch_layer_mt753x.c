/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *
 * switch_layer.c: switch layer for MAP
 * Author: Sirui Zhao <Sirui.Zhao@mediatek.com>
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <linux/if.h>
#include <pthread.h>
#include <stdbool.h>

#include "ethernet_layer.h"
#include "debug.h"
#include "netlink_event.h"

#include "common.h"
#include "switch_nl.h"
#include "switch_legacy_ioctl.h"
#include "switch_layer.h"
#include "switch_layer_mt753x.h"
#include "bridge_parse.h"


int mt753x_netlink_init(void)
{
	notice(DEBUG_CAT_INIT, "regiester MT753x Netlink\n");
	/* netlink init need chip(AX753x) name */
	if (switch_netlink_init(MT753X_GENL_NAME, MT7530_DSA_GENL_NAME)) {
		nl_init_flag = false;
		return -1;
	}

	return 0;
}

int mt753x_get_switch_mode(unsigned int *mode)
{
	int value = 0;

	(void)switch_reg_read(0x2610, &value);
	*mode = (value & 0x20);

	return 0;
}

int mt753x_get_port_status(unsigned char port, int *status)
{
	int ret = 0;
	int value = 0;
	struct switch_attr attr;

	memset(&attr, 0, sizeof(attr));
	attr.dev_id = -1;
	attr.port_num = -1;
	attr.phy_dev = -1;

	if (port < 5) {
		if (nl_init_flag == true)
			ret = netlink_cl22_read_phy(&attr, port, 1, &value);
		else
			ret = mii_cl22_read_phy(port, 1, &value);
		if (ret < 0) {
			warn(DEBUG_CAT_ETH, "Get switch port phy error\n");
			return 0;
		}
		*status = (value & 0x00000004) ? 1 : 0;
	}

	return ret;
}

int mt753x_get_port_speed(unsigned char port, int *speed)
{
	int value = 0;
	int status = 0;
	int ret = 0;
	int addr = 0;
	unsigned int phy_speed = 0;

	ret = mt753x_get_port_status(port, &status);
	if ((ret == 0) && (!status)) {
		*speed = 0;
		return 0;
	}

	if ((port == 5) || (port == 6)) {
		*speed = bridge_get_wan_speed(port);
		return 0;
	}

	if (port < 5)
		addr = 0x7020;
	else
		addr = 0x7024;

	(void)switch_reg_read(addr, &value);
	phy_speed = value >> ((port % 4) * 8 + 1) & 3;

	switch (phy_speed) {
	case 0:
		*speed = 10;
		break;
	case 1:
		*speed = 100;
		break;
	case 2:
		*speed = 1000;
		break;
	case 3:
		warn(DEBUG_CAT_ETH, "phy speed status error\n");
		return -1;
	}
	return 0;
}

int mt753x_get_phy_speed(unsigned char port)
{
	int value = 0, value1 = 0;
	int ret = 0;
	int speed = 0;

	ret = mii_cl22_read_phy(port, 0xa, &value);
	if (ret < 0) {
		warn(DEBUG_CAT_ETH, "read phy error\n");
		return -1;
	}

	ret = mii_cl22_read_phy(port, 0x5, &value1);
	if (ret < 0) {
		warn(DEBUG_CAT_ETH, "read phy error\n");
		return -1;
	}

	if ((value & 0x400) || (value & 0x800))
		speed = 1000;
	else if ((value1 & 0x200) || (value1 & 0x100) || (value1 & 0x80))
		speed = 100;
	else if ((value1 & 0x40) || (value1 & 0x20))
		speed = 10;
	else
		speed = 0;

	return speed;
}


int mt753x_defalut_setting(void)
{
	int i = 0, value = 0;

	if (is_chip_mt7530()) {
		if (arl.cpu_port_num > 1) {
			warn(DEBUG_CAT_ETH, "mt7530 only supports one cpu port(5/6)\n");
			return -1;
		}
		(void)switch_reg_read(0x10, &value);
		value |= (1 << 7);
		if (arl.cpu_port[0] == 5) {
			value |= (5 << 4);
			(void)switch_reg_write(0x10, value);
		} else if (arl.cpu_port[0] == 6) {
			value |= (6 << 4);
			(void)switch_reg_write(0x10, value);
		} else {
			warn(DEBUG_CAT_ETH, "invalid cpu port(%d)\n", arl.cpu_port[0]);
			return -1;
		}
	} else if (is_chip_mt7531()) {
		(void)switch_reg_read(0x4, &value);
		if (arl.cpu_port_num > 2) {
			warn(DEBUG_CAT_ETH, "mt7531 only supports two cpu port(5/6) at most\n");
			return -1;
		}
		for (i = 0; i < arl.cpu_port_num; i++) {
			if (arl.cpu_port[i] != 5 && arl.cpu_port[i] != 6) {
				warn(DEBUG_CAT_ETH, "invalid cpu port(%d)\n", arl.cpu_port[i]);
				return -1;
			}
			value |= (1 << arl.cpu_port[i]);
		}
		(void)switch_reg_write(0x4, value);
		notice(DEBUG_CAT_ETH, "cpu forward control:0x%x\n", value);
	}

	(void)switch_reg_write(0x34, 0x8160816);
	(void)switch_reg_write(0x2c, 0x8160810);
	(void)switch_reg_write(0xc, 0x7181d);

	return 0;
}


int mt753x_set_port_block(unsigned char port, int enable)
{
	int value = 0;

	if (port > 4)
		return 0;

	(void)switch_reg_read(0x2004 + port * 0x100, &value);
	value &= (~(7<<4));
	value |= (enable == 1) ? (7 << 4) : 0;
	(void)switch_reg_write(0x2004 + port * 0x100, value);

	return 0;
}

void mt753x_acl_enable(void)
{
	int port, offset, value = 0;

	for (port = 0; port <= 6; port++) {
		offset = 0x2004 + port * 0x100;
		(void)switch_reg_read(offset, &value);
		(void)switch_reg_write(offset, value | (1 << 10));
	}

}

int mt753x_set_wan_rule(void)
{
#if defined(CONFIG_MEDIATEK_NETSYS_V2) || defined(CONFIG_MEDIATEK_NETSYS_V3)
	char cmd[128] = {0};
	int length = 0;

	/* P4 1905 multicast forwarding to P5 port */
	/* switch reg w 94 ffff0180;switch reg w 98 81000;switch reg w 90 80005000*/
	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 94 ffff0180");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 98 81000");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 90 80005000");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	/* switch reg w 94 ffffc200;switch reg w 98 81002;switch reg w 90 80005001 */
	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 94 ffffc200");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 98 81002");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 90 80005001");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	/* switch reg w 94 ffff0013;switch reg w 98 81004;switch reg w 90 80005002 */
	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 94 ffff0013");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 98 81004");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 90 80005002");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	/* switch reg w 94 7;switch reg w 98 0;switch reg w 90 80009000 */
	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 94 7");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 98 0");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 90 80009000");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	/* switch reg w 94 18002084;switch reg w 98 0;switch reg w 90 8000B000 */
	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 94 18002084");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 98 0");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 90 8000B000");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	/* P5 1905 multicast forwarding to WAN port P4 */
	/* switch reg w 94 ffff0180;switch reg w 98 82000;switch reg w 90 80005004 */
	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 94 ffff0180");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 98 82000");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 90 80005004");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	/* switch reg w 94 ffffc200;switch reg w 98 82002;switch reg w 90 80005005 */
	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 94 ffffc200");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 98 82002");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 90 80005005");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	/* switch reg w 94 ffff0013;switch reg w 98 82004;switch reg w 90 80005006 */
	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 94 ffff0013");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 98 82004");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 90 80005006");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	/* switch reg w 94 ffff893A;switch reg w 98 8200c;switch reg w 90 80005007 */
	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 94 ffff893A");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 98 8200c");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 90 80005007");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	/* switch reg w 94 f0;switch reg w 98 0;switch reg w 90 80009001 */
	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 94 f0");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 98 0");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 90 80009001");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	/* switch reg w 94 18004080;switch reg w 98 0;switch reg w 90 8000B001 */
	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 94 18004080");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 98 0");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 90 8000B001");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	/* P0-P3 1905 relayed multicast forwarding to flooding */
	/* switch reg w 94 ffff0180;switch reg w 98 80f00;switch reg w 90 80005008 */
	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 94 ffff0180");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 98 80f00");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 90 80005008");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	/* switch reg w 94 ffffc200;switch reg w 98 80f02;switch reg w 90 80005009 */
	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 94 ffffc200");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 98 80f02");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 90 80005009");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	/* switch reg w 94 ffff0013;switch reg w 98 80f04;switch reg w 90 8000500a */
	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 94 ffff0013");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 98 80f04");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 90 8000500a");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	/* switch reg w 94 00400040;switch reg w 98 90f06;switch reg w 90 8000500b */
	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 94 00400040");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 98 90f06");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 90 8000500b");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	/* switch reg w 94 f00;switch reg w 98 0;switch reg w 90 80009002 */
	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 94 f00");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 98 0");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 90 80009002");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	/* switch reg w 94 18004f85;switch reg w 98 0;switch reg w 90 8000B002 */
	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 94 18004f85");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 98 0");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 90 8000B002");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);
#endif

	return 0;
}

int mt753x_set_lan_rule(unsigned char mac_addr[], void *data)
{
#if defined(CONFIG_MEDIATEK_NETSYS_V2) || defined(CONFIG_MEDIATEK_NETSYS_V3)
	char cmd[128] = {0};
	int length = 0;

	/* 1905 P0-3 --> P6 */
	/*switch reg w 94 ffff0180;switch reg w 98 80f00;switch reg w 90 80005008 */
	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 94 ffff0180");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 98 80f00");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 90 80005008");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	/* switch reg w 94 ffffc200;switch reg w 98 80f02;switch reg w 90 80005009 */
	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 94 ffffc200");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 98 80f02");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 90 80005009");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	/* switch reg w 94 ffff0013;switch reg w 98 80f04;switch reg w 90 8000500a */
	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 94 ffff0013");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 98 80f04");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 90 8000500a");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	/* switch reg w 94 ffff893A;switch reg w 98 80f0c;switch reg w 90 8000500b */
	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 94 ffff893A");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 98 80f0c");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 90 8000500b");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	/* switch reg w 94 f00;switch reg w 98 0;switch reg w 90 80009002 */
	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 94 f00");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 98 0");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 90 80009002");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	/* switch reg w 94 18004080;switch reg w 98 0;switch reg w 90 8000B002 */
	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 94 18004080");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 98 0");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 90 8000B002");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	/* 1905 al-mac P0-3 --> P6 */
	/* switch reg w 94 ffff%2x%2x;switch reg w 98 80f00;switch reg w 90 8000500c */
	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 94 ffff%2x%2x",
		mac_addr[0], mac_addr[1]);
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 98 80f00");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 90 8000500c");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	/* switch reg w 94 ffff%2x%2x;switch reg w 98 80f02;switch reg w 90 8000500d */
	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 94 ffff%2x%2x",
		mac_addr[2], mac_addr[3]);
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 98 80f02");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 90 8000500d");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	/* switch reg w 94 ffff%2x%2x;switch reg w 98 80f04;switch reg w 90 8000500e */
	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 94 ffff%2x%2x",
		mac_addr[4], mac_addr[5]);
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 98 80f04");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 90 8000500e");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	/* switch reg w 94 ffff893A;switch reg w 98 80f0c;switch reg w 90 8000500f */
	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 94 ffff893A",
		mac_addr[4], mac_addr[5]);
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 98 80f0c");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 90 8000500f");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	/* switch reg w 94 0xf000;switch reg w 98 0;switch reg w 90 80009003 */
	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 94 0xf000",
		mac_addr[4], mac_addr[5]);
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 98 0");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 90 80009003");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	/* switch reg w 94 18004080;switch reg w 98 0;switch reg w 90 8000B003 */
	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 94 18004080",
		mac_addr[4], mac_addr[5]);
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 98 0");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 90 8000B003");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	 /* 1905 broadcast P0-3 --> P6 */
	/* switch reg w 94 ffffffff;switch reg w 98 80f00;switch reg w 90 80005010 */
	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 94 ffffffff",
		mac_addr[4], mac_addr[5]);
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 98 80f00");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 90 80005010");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	/* switch reg w 94 ffffffff;switch reg w 98 80f02;switch reg w 90 80005011 */
	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 94 ffffffff",
		mac_addr[4], mac_addr[5]);
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 98 80f02");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 90 80005011");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	/* switch reg w 94 ffffffff;switch reg w 98 80f04;switch reg w 90 80005012 */
	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 94 ffffffff",
		mac_addr[4], mac_addr[5]);
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 98 80f04");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 90 80005012");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	/* switch reg w 94 ffff893A;switch reg w 98 80f0c;switch reg w 90 80005013 */
	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 94 ffff893A",
		mac_addr[4], mac_addr[5]);
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 98 80f0c");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 90 80005013");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	/* switch reg w 94 0xf0000;switch reg w 98 0;switch reg w 90 80009004 */
	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 94 0xf0000",
		mac_addr[4], mac_addr[5]);
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 98 0");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 90 80009004");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	/* switch reg w 94 18004080;switch reg w 98 0;switch reg w 90 8000B004 */
	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 94 18004080",
		mac_addr[4], mac_addr[5]);
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 98 0");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch reg w 90 8000B004");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);
#endif

	return 0;
}

int mt753x_port_find_by_mac(unsigned char *mac_addr, int vid, unsigned char *age)
{
	int value = 0, port = 0;
	int i = 0;
	char tmpstr[9];

	(void)snprintf(tmpstr, sizeof(tmpstr), "%02x%02x%02x%02x",
			mac_addr[0], mac_addr[1], mac_addr[2], mac_addr[3]);
	value = strtoul(tmpstr, NULL, 16);
	if (value == ERANGE) {
		debug(DEBUG_CAT_ETH, "strtoul fail!\n");
		return -1;
	}
	(void)switch_reg_write(REG_ESW_WT_MAC_ATA1, value);
	debug(DEBUG_CAT_ETH, "REG_ESW_WT_MAC_ATA1 is 0x%x\n\r", value);

	(void)snprintf(tmpstr, sizeof(tmpstr), "%02x%02x", mac_addr[4], mac_addr[5]);
	value = strtoul(tmpstr, NULL, 16);
	value = (value << 16);
	value |= (1 << 15);//IVL=1

	value |= vid; //vid
	(void)switch_reg_write(REG_ESW_WT_MAC_ATA2, value);
	debug(DEBUG_CAT_ETH, "REG_ESW_WT_MAC_ATA2 is 0x%x\n\r", value);

	value = 0x8000;  //w_mac_cmd
	(void)switch_reg_write(REG_ESW_WT_MAC_ATC, value);
	debug(DEBUG_CAT_ETH, "REG_ESW_WT_MAC_ATC is 0x%x\n\r", value);
	usleep(1000);

	for (i = 0; i < 20; i++) {
		(void)switch_reg_read(REG_ESW_WT_MAC_ATC, &value);
		debug(DEBUG_CAT_ETH, "REG_ESW_WT_MAC_ATC is 0x%x\n\r", value);
		if ((value & 0x8000) == 0) {
			/* mac address busy */
			break;
		}
		usleep(1000);
	}
	if (i == 20) {
		notice(DEBUG_CAT_ETH, "search timeout.\n");
		return -1;
	}

	if (value & 0x1000) {
		info(DEBUG_CAT_ETH, "Address Entry is not valid:0x%x, and search no entry by vid=%d.\n", value, vid);
		return -1;
	}

	debug(DEBUG_CAT_ETH, "search done.\n");

	(void)switch_reg_read(REG_ESW_TABLE_ATRD, &value);
	/* r_port_map */
	port = (value >> 4) & 0xff;
	/* r_age_field */
	*age = (value >> 24) & 0xff;

	return port;
}

int mt753x_port_find_by_mac_fid(unsigned char *mac_addr, int fid, unsigned char *age)
{
	int value = 0, port = 0;
	int i = 0;
	char tmpstr[9];

	(void)snprintf(tmpstr, sizeof(tmpstr), "%02x%02x%02x%02x",
			mac_addr[0], mac_addr[1], mac_addr[2], mac_addr[3]);
	value = strtoul(tmpstr, NULL, 16);
	if (value == ERANGE) {
		warn(DEBUG_CAT_ETH, "strtoul tmpstr fail\n");
		return -1;
	}
	(void)switch_reg_write(REG_ESW_WT_MAC_ATA1, value);
	debug(DEBUG_CAT_ETH, "REG_ESW_WT_MAC_ATA1 is 0x%x\n\r", value);

	(void)snprintf(tmpstr, sizeof(tmpstr), "%02x%02x", mac_addr[4], mac_addr[5]);
	value = strtoul(tmpstr, NULL, 16);
	value = (value << 16);
	value &= ~(1 << 15);//IVL=0

	value |= (fid << 12); //vid
	(void)switch_reg_write(REG_ESW_WT_MAC_ATA2, value);
	debug(DEBUG_CAT_ETH, "REG_ESW_WT_MAC_ATA2 is 0x%x\n\r", value);

	value = 0x8000;  //w_mac_cmd
	(void)switch_reg_write(REG_ESW_WT_MAC_ATC, value);
	debug(DEBUG_CAT_ETH, "REG_ESW_WT_MAC_ATC is 0x%x\n\r", value);
	usleep(1000);

	for (i = 0; i < 20; i++) {
		(void)switch_reg_read(REG_ESW_WT_MAC_ATC, &value);
		debug(DEBUG_CAT_ETH, "REG_ESW_WT_MAC_ATC is 0x%x\n\r", value);
		if ((value & 0x8000) == 0) {
			/* mac address busy */
			break;
		}
		usleep(1000);
	}
	if (i == 20) {
		info(DEBUG_CAT_ETH, "search timeout.\n");
		return -1;
	}

	if (value & 0x1000) {
		info(DEBUG_CAT_ETH, "Address Entry is not valid:0x%x, and search no entry by fid=%d.\n", value, fid);
		return -1;
	}

	debug(DEBUG_CAT_ETH, "search done.\n");

	(void)switch_reg_read(REG_ESW_TABLE_ATRD, &value);
	port = (value >> 4) & 0xff; //r_port_map

	*age = (value >> 24) & 0xff;//r_age_field

	return port;
}

int mt753x_get_port_type(unsigned int *lport_map, unsigned int *wport_map)
{
	lan_port_bitmap = 0x1f;
	wan_port_bitmap = 0x60;

	return 0;
}

int mt753x_get_table_entry(struct dl_list *entry_list)
{
	int value = 0;
	int i = 0, j = 0, k = 0;
	struct ethernet_client_entry *entry = NULL;

	int mac = 0, mac2 = 0, value2 = 0, counter = 0;
	int temp, table_size = 0, table_end = 0;

	if (entry_list == NULL)
		return -1;
	dl_list_init(entry_list);

	/* switch disabled, got entry from bridge */
	if (!is_chip_valid())
		goto suc;

	for (i = 0; i < 8; i++)
		(void)switch_reg_read(REG_ESW_VLAN_ID_BASE + 4*i, &value);

	(void)switch_reg_read((0x7ffc), &temp);
	temp = temp >> 16;
	if (temp == 0x7530) {
		table_size = 0x400;
		table_end = 0x3FF;
	} else {
		table_size = 0x800;
		table_end = 0x7FF;
	}


	(void)switch_reg_write(REG_ESW_WT_MAC_ATC, 0x8004);
	usleep(5);

	for (i = 0; i < table_size; i++) {
		while (1) {
			(void)switch_reg_read(REG_ESW_WT_MAC_ATC, &value);
			/* printf("ATC =  0x%x\n", value); */

			/* search_rdy and Address Table is not busy */
			if ((value & (0x1 << 13)) && (((value >> 15) & 0x1) == 0)) {
				usleep(5);
				counter = 0;
				(void)switch_reg_read(REG_ESW_TABLE_ATRD, &value2);
				/* r_port_map */
				j = (value2 >> 4) & 0xff;
				for (k = 0; k < MAX_SWITCH_FRONT_PORT; k++) {
					if (j & (0x01 << k))
						break;
				}
				if (k >= MAX_SWITCH_FRONT_PORT)
					break;

				if (k < MAX_SWITCH_FRONT_PORT) {
					entry = switch_create_table_entry(k, 0, NULL, 0);
					if (entry == NULL) {
						warn(DEBUG_CAT_ETH, "allocate switch client entry fail\n");
						break;
					}
				}
				usleep(5);

				(void)switch_reg_read(REG_ESW_TABLE_TSRA2, &mac2);
				if (k < MAX_SWITCH_FRONT_PORT)
					entry->age = (value2 >> 24) & 0xff;
				usleep(5);
				(void)switch_reg_read(REG_ESW_TABLE_TSRA1, &mac);
				if ((k < MAX_SWITCH_FRONT_PORT) && (mac || (mac2 & 0xffff0000))) {
					entry->mac[0] = (mac & 0xff000000) >> 24;
					entry->mac[1] = (mac & 0x00ff0000) >> 16;
					entry->mac[2] = (mac & 0x0000ff00) >> 8;
					entry->mac[3] = mac & 0x000000ff;
					entry->mac[4] = (((mac2 >> 16) & 0xffff) & 0x0000ff00) >> 8;
					entry->mac[5] = ((mac2 >> 16) & 0xffff) & 0x000000ff;

					dl_list_add(entry_list, &entry->entry);
				} else
					os_free(entry);

				if ((value & 0x4000) && (((value >> 16) & 0xfff) == table_end))
					goto suc;
				break;
			} else if ((value & 0x4000) && (((value >> 15) & 0x1) == 0)
				&& (((value >> 16) & 0xfff) == table_end)) {
				goto suc;
			} else {
				usleep(5);
				counter++;
				if (counter >= SWITCH_ERROR_COUNTER) {
					warn(DEBUG_CAT_ETH, "abnormal case, exit%d\n", __LINE__);
					goto fail;
				}
			}
		}
		/* search for next address */
		(void)switch_reg_write(REG_ESW_WT_MAC_ATC, 0x8005);
		usleep(5);
	}

fail:
	warn(DEBUG_CAT_ETH, "######fail\n");
	switch_clear_entry_list(entry_list);
	return -1;
suc:
	bridge_get_table_entry(entry_list);
	return 0;
}


int mt753x_clear_table(void)
{
	int ret = 0;
	int cnt = 100;

#ifndef CONFIG_RALINK_MT7628
	/* switch clear */
	ret = switch_reg_write(REG_ESW_WT_MAC_ATC, 0x8002);
	while (ret && cnt) {
		usleep(5000);
		ret = switch_reg_write(REG_ESW_WT_MAC_ATC, 0x8002);
		cnt--;
	}

	if (cnt)
		notice(DEBUG_CAT_ETH, "clear switch table success! retry remain(%d)\n", cnt);
	else
		notice(DEBUG_CAT_ETH, "clear switch table fail! retry %d times\n", cnt);
#else
	notice(DEBUG_CAT_ETH, "for 7628 switch, do not support\n");
	ret = -2;
#endif

	ret = bridge_clear_table();

	return ret;
}

int mt753x_clear_port_table(unsigned char port)
{
	if (port > 4)
		return 0;

	(void)switch_reg_write(REG_ESW_WT_MAC_ATA1, 1 << port);
	(void)switch_reg_write(REG_ESW_WT_MAC_ATC, 0x8c02);

	return 0;
}

int mt753x_vlan_set(unsigned short vid[], unsigned short vid_cnt, unsigned char active, enum vlan_type type)
{
	unsigned char ivl_en = 1;
	unsigned char fid = 0;
	unsigned short stag = 0;
	unsigned char portMap = 0;
	unsigned char tagPortMap = 0;
	struct switch_vlan_list *vlan_entry = NULL;
	struct switch_vlan_list *entry_temp = NULL;

	int value = 0;
	int value2 = 0;
	int reg = 0;
	int i;
	int max_port = 0;

	portMap = lan_port_bitmap;

	max_port = SWITCH_MAX_PORT;

	if (e_transparent_vlan == type) {
		for (i = 0; i <= max_port; i++) {
			if (is_chip_an8855()) {
				if (wan_port_bitmap & BIT(i)) {
					/* but why wan port include 4,5 */
					portMap |= (0x01 << i);
				}
			} else {
				if ((wan_port_bitmap & BIT(i)) && (i < 5)) {
					/* but why wan port include 4,5 */
					portMap |= (0x01 << i);
				}
			}
		}
	}

	tagPortMap = portMap;

	if (!vid_cnt)
		active = 0;

	value = (portMap << 16);
	value |= (stag << 4);
	value |= (ivl_en << 30);
	value |= (fid << 1);
	value |= (active ? 1 : 0);

	/* total 7 ports */
	for (i = 0; i < 7; i++) {
		if (tagPortMap & (1 << i))
			value2 |= 0x2 << (i * 2);
	}

	if (value2) {
		/* eg_tag */
		value |= (1 << 28);
	}
	/* VAWD2 */
	reg = 0x98;
	(void)switch_reg_write(reg, value2);

	/* VAWD1 */
	reg = 0x94;
	(void)switch_reg_write(reg, value);

	/* vid_cnt != 0, activate or inactivate switch vlan table according to active flag*/
	if (vid_cnt) {
		for (i = 0; i < vid_cnt; i++) {
			/* VTCR */
			reg = 0x90;
			value = (0x80001000 + vid[i]);
			(void)switch_reg_write(reg, value);
			usleep(5000);

			vlan_entry = malloc(sizeof(struct switch_vlan_list));
			if (vlan_entry) {
				notice(DEBUG_CAT_ETH, "%s vlan id %d added\n",
					(type == e_traffic_separation_vlan) ?
					"traffic separation" : "transparent vlan", vid[i]);
				dl_list_add_tail(&switch_vlan_head, &vlan_entry->entry);

				vlan_entry->vid = vid[i];
				vlan_entry->vid_type = type;
				vlan_entry->port_bitmap = portMap;
				vlan_entry->cpu_port = tagPortMap;
			} else {
				notice(DEBUG_CAT_ETH, "malloc vlan entry fail\n");
				return -1;
			}
		}

		/* cnt of any vlan type is bigger than 0, set to user mode */
		if (!ts_vlan_cnt && !transparent_vlan_cnt) {
			value = 0x81000000;
			notice(DEBUG_CAT_ETH, "2n10 set to user mode 0x%0x\n", value);
			for (i = 0; i < 7; i++) {
				reg = 0x2010 + i * 0x100;
				(void)switch_reg_write(reg, value);
				usleep(5000);
			}
		}

		if (e_traffic_separation_vlan == type)
			ts_vlan_cnt = vid_cnt;
		else
			transparent_vlan_cnt = vid_cnt;
	}
	/* vid_cnt = 0, inactivate switch vlan talbe in switch */
	else {
		/* look up all the vlan entry from list and delete them */
		dl_list_for_each_safe(vlan_entry, entry_temp, &switch_vlan_head, struct switch_vlan_list, entry) {
			if (vlan_entry->vid_type == type) {
				/* disable vlan in switch first */
				/* VTCR */
				reg = 0x90;
				value = (0x80001000 + vlan_entry->vid);
				(void)switch_reg_write(reg, value);
				usleep(5000);

				notice(DEBUG_CAT_ETH, "%s vlan id %d removed\n",
					(type == e_traffic_separation_vlan) ?
					"traffic separation" : "transparent vlan", vlan_entry->vid);

				/* rm entry from list */
				dl_list_del(&vlan_entry->entry);
				os_free(vlan_entry);
			}
			vlan_entry = entry_temp;
		}

		if (e_traffic_separation_vlan == type)
			ts_vlan_cnt = 0;
		else
			transparent_vlan_cnt = 0;

		/* if cnt of each type of vlan is 0, reset to transparent mode as golden branch  */
		if (!ts_vlan_cnt && !transparent_vlan_cnt) {
			value = 0x810000c0;
			notice(DEBUG_CAT_ETH, "2n10 set to transparent mode 0x%0x\n", value);
			for (i = 0; i < 7; i++) {
				reg = 0x2010 + i * 0x100;
				(void)switch_reg_write(reg, value);
				usleep(5000);
			}
		}
	}

	/* VTCR */
	reg = 0x90;
	while (1) {
		(void)switch_reg_read(reg, &value);
		if ((value & 0x80000000) == 0) {
			/* table busy */
			break;
		}
	}

	/* switch clear */
	reg = 0x80;
	(void)switch_reg_write(reg, 0x8002);
	usleep(5000);
	(void)switch_reg_read(reg, &value);

	return 0;
}

int mt753x_get_lan_wan_portmaps(int vid, unsigned int *port_map)
{
	int j, value, value2;
	int vlan_vtcr = 0;

	vlan_vtcr = REG_ESW_VLAN_VTCR;

	notice(DEBUG_CAT_ETH, "  vid  fid	portmap    s-tag\n");
	value = (0x80000000 + vid);  //r_vid_cmd
	(void)switch_reg_write(vlan_vtcr, value);

	for (j = 0; j < 20; j++) {
		(void)switch_reg_read(vlan_vtcr, &value);
		if ((value & 0x80000000) == 0) {
			//vlan table is busy
			break;
		}
		usleep(1000);
	}
	if (j == 20) {
		warn(DEBUG_CAT_ETH, "vlan dump timeout.\n");
		return -1;
	}

	(void)switch_reg_read(REG_ESW_VLAN_VAWD1, &value);
	(void)switch_reg_read(REG_ESW_VLAN_VAWD2, &value2);

	if ((value & 0x01) != 0) {
		notice(DEBUG_CAT_ETH, " %4d  ", vid);
		notice(DEBUG_CAT_ETH, " %2d ", ((value & 0xe) >> 1));
		notice(DEBUG_CAT_ETH, " %c", (value & 0x00010000) ? '1':'-');	//p0
		notice(DEBUG_CAT_ETH, "%c", (value & 0x00020000) ? '1':'-');	//p1
		notice(DEBUG_CAT_ETH, "%c", (value & 0x00040000) ? '1':'-');	//p2
		notice(DEBUG_CAT_ETH, "%c", (value & 0x00080000) ? '1':'-');	//p3
		notice(DEBUG_CAT_ETH, "%c", (value & 0x00100000) ? '1':'-');	//p4
		notice(DEBUG_CAT_ETH, "%c", (value & 0x00200000) ? '1':'-');	//p5
		notice(DEBUG_CAT_ETH, "%c", (value & 0x00400000) ? '1':'-');	//p6
		notice(DEBUG_CAT_ETH, "%c", (value & 0x00800000) ? '1':'-');	//p7
		notice(DEBUG_CAT_ETH, " %4d\n", ((value & 0xfff0)>>4)) ; //service Tag

		for (j = 0; j < SWITCH_MAX_PORT; j++) {
			if (value & (BIT(j + BIT_OFFSET)))
				*port_map |= (0x00000001 << j);
		}
	} else	{
		/*print 16 vid for reference information*/
		if (vid <= 16) {
			notice(DEBUG_CAT_ETH, " %4d  ", vid);
			notice(DEBUG_CAT_ETH, " %2d ", ((value & 0xe) >> 1));
			notice(DEBUG_CAT_ETH, " invalid\n");
		}
	}
	return 0;
}


void mt753x_switch_deinit(void)
{
	(void)switch_ioctl_deinit(NULL);
	if (nl_init_flag == true) {
		free(attres);
		attres = NULL;
		(void)switch_nl_deinit();
	}
	if (arl.lan_vid)
		os_free(arl.lan_vid);
	if (arl.wan_vid)
		os_free(arl.wan_vid);
	if (arl.cpu_port)
		os_free(arl.cpu_port);
}

