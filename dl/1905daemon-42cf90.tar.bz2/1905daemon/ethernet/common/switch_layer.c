/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *
 * switch_layer.c: switch layer for MAP
 * Author: Sirui Zhao <Sirui.Zhao@mediatek.com>
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <linux/if.h>
#include <pthread.h>
#include <stdbool.h>

#include "ethernet_layer.h"
#include "debug.h"
#include "netlink_event.h"

#include "common.h"
#include "switch_nl.h"
#include "switch_legacy_ioctl.h"
#include "switch_layer.h"
#include "switch_layer_mt7628.h"
#include "switch_layer_mt753x.h"
#include "switch_layer_an8855.h"
#include "bridge_parse.h"

#define MT7622_7530_KT 1

int chip = 0xffffffff;
bool nl_init_flag;
struct switch_attr *attres;
char *cfg_file = "/etc/ethernet_cfg.txt";

struct arl_setting arl;
static char eth_dev_name[IFNAMSIZ] = {0x00};
unsigned int lan_port_bitmap = 0;
unsigned int wan_port_bitmap = 0;
unsigned int ts_vlan_cnt = 0;
unsigned int transparent_vlan_cnt = 0;
struct dl_list switch_vlan_head;

int (*func_get_switch_mode)(unsigned int *mode);
int (*func_get_port_status)(unsigned char port, int *status);
int (*func_get_port_speed)(unsigned char port, int *speed);
int (*func_get_phy_speed)(unsigned char port);
int (*func_defalut_setting)(void);
void (*func_acl_enable)(void);
int (*func_set_port_block)(unsigned char port, int enable);
int (*func_set_wan_rule)(void);
int (*func_set_lan_rule)(unsigned char mac_addr[], void *data);
int (*func_port_find_by_mac)(unsigned char *mac_addr, int vid, unsigned char *age);
int (*func_port_find_by_mac_fid)(unsigned char *mac_addr, int fid, unsigned char *age);
int (*func_get_port_type)(unsigned int *lport_map, unsigned int *wport_map);
int (*func_get_table_entry)(struct dl_list *entry_list);
int (*func_clear_table)(void);
int (*func_clear_port_table)(unsigned char port);
int (*func_vlan_set)(unsigned short vid[], unsigned short vid_cnt, unsigned char active, enum vlan_type type);
int (*func_get_lan_wan_portmaps)(int vid, unsigned int *port_map);
int (*func_netlink_init)(void);
void (*func_switch_deinit)(void);



int is_chip_valid(void)
{
	if (chip != 0xffffffff)
		return 1;

	return 0;
}

int is_chip_mt7628(void)
{
	if (chip == CHIP_MT7628)
		return 1;

	return 0;
}

int is_chip_mt7531(void)
{
	if (chip == CHIP_MT7531)
		return 1;

	return 0;
}

int is_chip_mt7530(void)
{
	if (chip == CHIP_MT7530)
		return 1;

	return 0;
}

int is_chip_an8855(void)
{
	if (chip == CHIP_AN8855)
		return 1;

	return 0;
}


char * config_get_line(char *s,
	int size, FILE *stream, int *line, char **_pos)
{
	char *pos, *end, *sstart;

    while (fgets(s, size, stream)) {
        (*line)++;
        s[size - 1] = '\0';
        pos = s;

        /* Skip white space from the beginning of line. */
        while (*pos == ' ' || *pos == '\t' || *pos == '\r')
            pos++;

        /* Skip comment lines and empty lines */
        if (*pos == '#' || *pos == '\n' || *pos == '\0')
            continue;

        /*
         * Remove # comments unless they are within a double quoted
         * string.
		 */
        sstart = os_strchr(pos, '"');
        if (sstart)
            sstart = os_strrchr(sstart + 1, '"');
        if (!sstart)
            sstart = pos;
        end = os_strchr(sstart, '#');
        if (end)
            *end-- = '\0';
        else
            end = pos + os_strlen(pos) - 1;

        /* Remove trailing white space. */
        while (end > pos &&
               (*end == '\n' || *end == ' ' || *end == '\t' ||
            *end == '\r'))
            *end-- = '\0';

        if (*pos == '\0')
            continue;

		if (_pos)
            *_pos = pos;
        return pos;
    }

    if (_pos)
        *_pos = NULL;
    return NULL;
}

int switch_parse_arl_setting(struct arl_setting *arl, char *lan_vid_str,
				char *wan_vid_str, char *cpu_port_str)
{
	char *token = NULL;
	int vid = 0, cpu = 0, num = 0;
	unsigned short *tmp = NULL;

	if (lan_vid_str) {
		token = strtok(lan_vid_str, ";");

		while (token != NULL) {
			vid = strtol(token, NULL, 10);
			if (vid > 0 && vid < 4095) {
				num++;
				tmp = (num == 1) ? os_malloc(sizeof(unsigned short)) :
					os_realloc(arl->lan_vid, sizeof(unsigned short) * num);
				if (!tmp) {
					err(DEBUG_CAT_INIT, "alloc lan vid fail, num(%d)\n", num);
					free(arl->lan_vid);
					arl->lan_vid_num = 0;
					return -1;
				}
				arl->lan_vid = tmp;
				arl->lan_vid[num - 1] = vid;
				arl->lan_vid_num = num;
			} else
				warn(DEBUG_CAT_INIT, "invalid vid(%d)\n", vid);

			token = strtok(NULL, ";");
		}
	}

	if (wan_vid_str) {
		token = strtok(wan_vid_str, ";");

		num = 0;
		while (token != NULL) {
			vid = strtol(token, NULL, 10);
			if (vid > 0 && vid < 4095) {
				num++;
				tmp = (num == 1) ? os_malloc(sizeof(unsigned short)) :
					os_realloc(arl->wan_vid, sizeof(unsigned short) * num);
				if (!tmp) {
					err(DEBUG_CAT_INIT, "alloc wan vid fail, num(%d)\n", num);
					free(arl->wan_vid);
					arl->wan_vid_num = 0;
					return -1;
				}
				arl->wan_vid = tmp;
				arl->wan_vid[num - 1] = vid;
				arl->wan_vid_num = num;
			} else
				warn(DEBUG_CAT_INIT, "invalid vid(%d)\n", vid);

			token = strtok(NULL, ";");
		}
	}

	if (cpu_port_str) {
		token = strtok(cpu_port_str, ";");
		num = 0;
		while (token != NULL) {
			cpu = strtol(token, NULL, 10);
			if (cpu == 5 || cpu == 6) {
				num++;
				tmp = (num == 1) ? os_malloc(sizeof(unsigned short)) :
					os_realloc(arl->cpu_port, sizeof(unsigned short) * num);
				if (!tmp) {
					err(DEBUG_CAT_INIT, "alloc cpu vid fail, num(%d)\n", num);
					free(arl->cpu_port);
					arl->cpu_port_num = 0;
					return -1;
				}
				arl->cpu_port = tmp;
				arl->cpu_port[num - 1] = cpu;
				arl->cpu_port_num = num;
			} else
				warn(DEBUG_CAT_INIT, "invalid cpu port(%d)\n", cpu);

			token = strtok(NULL, ";");
		}
	}

	return 0;
}

int switch_read_config_file(char *file_path)
{
	FILE *file;
	char buf[256], *pos, *token;
	char tmpbuf[256];
	int line = 0;

	file = fopen(file_path, "r");

	if (!file) {
		notice(DEBUG_CAT_INIT, "open ehternet cfg file (%s) fail, use default setting\n", file_path);
		return 0;
	}
	os_memset(buf, 0, 256);
	os_memset(tmpbuf, 0, 256);

	while (config_get_line(buf, sizeof(buf), file, &line, &pos)) {
		if (os_strlen(pos) >= sizeof(tmpbuf)) {
			warn(DEBUG_CAT_INIT, "line(%s) too long! excced %d\n", pos, (int)sizeof(tmpbuf));
			continue;
		}
		(void)snprintf(tmpbuf, sizeof(tmpbuf), "%s", pos);
		token = strtok(pos, "=");

		if (token != NULL) {
			if (os_strcmp(token, "ethernet_dev_name") == 0) {
				token = strtok(NULL, "");
				if (token == NULL)
					continue;
				if (os_strlen(token) >= IFNAMSIZ) {
					warn(DEBUG_CAT_INIT, "length of ethernet_deve_name exceeds IFNAMSIZ, use default value\n");
					continue;
				}

				os_strncpy(eth_dev_name, token, os_strlen(token));
			} else if (os_strcmp(token, "lan_vid") == 0) {
				token = strtok(NULL, "");
				if (token == NULL)
					continue;

				switch_parse_arl_setting(&arl, token, NULL, NULL);
			} else if (os_strcmp(token, "wan_vid") == 0) {
				token = strtok(NULL, "");
				if (token == NULL)
					continue;

				switch_parse_arl_setting(&arl, NULL, token, NULL);
			} else if (os_strcmp(token, "cpu_port") == 0) {
				token = strtok(NULL, "");
				if (token == NULL)
					continue;

				switch_parse_arl_setting(&arl, NULL, NULL, token);
			}
		}
	}

	(void)fclose(file);

	return 0;
}

int switch_reg_read(int offset, int *value)
{
	int ret = 0;
	struct switch_attr attr;

	memset(&attr, 0, sizeof(attr));
	attr.dev_id = -1;
	attr.port_num = -1;
	attr.phy_dev = -1;

	if (nl_init_flag == true)
		ret = reg_read_nl(&attr, offset, value);
	else
		ret = reg_read_ioctl(offset, value);
	if (ret < 0)
		warn(DEBUG_CAT_ETH, "switch read fail\n");

	return ret;
}

int switch_reg_write(int offset, int value)
{
	int ret = 0;
	struct switch_attr attr;

	memset(&attr, 0, sizeof(attr));
	attr.dev_id = -1;
	attr.port_num = -1;
	attr.phy_dev = -1;

	if (nl_init_flag == true)
		ret = reg_write_nl(&attr, offset, value);
	else
		ret = reg_write_ioctl(offset, value);
	if (ret < 0)
		warn(DEBUG_CAT_ETH, "switch write fail\n");

	return ret;
}

void switch_get_chip_name_by_reg(void)
{
	int temp = 0xffffffff;

	/*judge 7530*/
	(void)switch_reg_read((0x7ffc), &temp);
	temp = temp >> 16;
	if (temp == CHIP_MT7530) {
		chip = temp;
		notice(DEBUG_CAT_ETH, "switch chip name: 0x%04x!\n", chip);
		return;
	}

	/*judge 7531*/
	(void)switch_reg_read(0x781c, &temp);
	temp = temp >> 16;
	if (temp == CHIP_MT7531) {
		chip = temp;
		notice(DEBUG_CAT_ETH, "switch chip name: 0x%04x!\n", chip);
		return;
	}
}


void switch_get_chip_name_by_file(void)
{
	FILE *fp = NULL;
	char buff[255];
	int *temp = &chip;

#if defined(CONFIG_RALINK_MT7628)
	*temp = CHIP_MT7628;
	notice(DEBUG_CAT_ETH, "switch chip name: 0x%04x!\n", *temp);
	return;
#endif

	fp = fopen(CHIP_FILE_AN8855, "r");
	if (fp) {
		/* AN8855 switch */
		if (fgets(buff, 255, (FILE *)fp) && strstr(buff, "an8855"))
			*temp = CHIP_AN8855;

		notice(DEBUG_CAT_ETH, "switch chip name: 0x%04x!\n", *temp);

		(void)fclose(fp);
		return;
	}

	fp = fopen(CHIP_FILE_AX7988, "r");
	if (fp) {
		/*judge jaguar embedded switch*/
		if (fgets(buff, 255, (FILE *)fp) && strstr(buff, "mt7988"))
			*temp = CHIP_MT7531;

		notice(DEBUG_CAT_ETH, "switch chip name: 0x%04x!\n", *temp);

		(void)fclose(fp);
		return;
	}
}

struct ethernet_client_entry *switch_create_table_entry(unsigned char port_index, unsigned char age,
	unsigned char *mac, unsigned char vid)
{
	struct ethernet_client_entry *entry = NULL;

	entry = (struct ethernet_client_entry *)os_malloc(sizeof(struct ethernet_client_entry));
	if (entry == NULL)
		return NULL;

	entry->port_index = port_index;
	entry->age = age;
	if (mac != NULL)
		os_memcpy(entry->mac, mac, ETH_ALEN);

	return entry;
}

int switch_clear_entry_list(struct dl_list *entry_list)
{
	struct ethernet_client_entry *entry, *entry_next;

	dl_list_for_each_safe(entry, entry_next, entry_list, struct ethernet_client_entry, entry) {
		dl_list_del(&entry->entry);
		os_free(entry);
	}
	return 0;
}



void switch_hooks_register(void)
{
	switch (chip) {
	case CHIP_AN8855:
		func_netlink_init			= an8855_netlink_init;
		func_get_switch_mode		= an8855_get_switch_mode;
		func_get_port_status		= an8855_get_port_status;
		func_get_port_speed			= an8855_get_port_speed;
		func_get_phy_speed			= an8855_get_phy_speed;
		func_set_port_block			= an8855_set_port_block;
		func_defalut_setting		= an8855_defalut_setting;
		func_acl_enable				= an8855_acl_enable;
		func_set_wan_rule			= an8855_set_wan_rule;
		func_set_lan_rule			= an8855_set_lan_rule;
		func_port_find_by_mac		= an8855_port_find_by_mac;
		func_port_find_by_mac_fid	= an8855_port_find_by_mac_fid;
		func_get_port_type			= an8855_get_port_type;
		func_get_table_entry		= an8855_get_table_entry;
		func_clear_table			= an8855_clear_table;
		func_clear_port_table		= an8855_clear_port_table;
		func_vlan_set				= an8855_vlan_set;
		func_get_lan_wan_portmaps	= an8855_get_lan_wan_portmaps;
		func_switch_deinit			= an8855_switch_deinit;
		notice(DEBUG_CAT_ETH, "register an8855 switch hooks\n");
		break;

	default:
		func_netlink_init			= mt753x_netlink_init;
		func_get_switch_mode		= mt753x_get_switch_mode;
		func_get_port_status		= mt753x_get_port_status;
		func_get_port_speed			= mt753x_get_port_speed;
		func_get_phy_speed			= mt753x_get_phy_speed;
		func_set_port_block			= mt753x_set_port_block;
		func_defalut_setting		= mt753x_defalut_setting;
		func_acl_enable				= mt753x_acl_enable;
		func_set_wan_rule			= mt753x_set_wan_rule;
		func_set_lan_rule			= mt753x_set_lan_rule;
		func_port_find_by_mac		= mt753x_port_find_by_mac;
		func_port_find_by_mac_fid	= mt753x_port_find_by_mac_fid;
		func_get_port_type			= mt753x_get_port_type;
		func_get_table_entry		= mt753x_get_table_entry;
		func_clear_table			= mt753x_clear_table;
		func_clear_port_table		= mt753x_clear_port_table;
		func_vlan_set				= mt753x_vlan_set;
		func_get_lan_wan_portmaps	= mt753x_get_lan_wan_portmaps;
		func_switch_deinit			= mt753x_switch_deinit;
		notice(DEBUG_CAT_ETH, "register mt753x switch hooks\n");
		break;
	}

#if defined(CONFIG_RALINK_MT7628)
	func_port_find_by_mac		= mt7628_port_find_by_mac;
	notice(DEBUG_CAT_ETH, "register MT7628 switch hook\n");
#endif
}


int switch_get_phy_speed(unsigned char port)
{
	int ret = 0;

	if (func_get_phy_speed)
		ret = func_get_phy_speed(port);

	return ret;
}

static int switch_defalut_setting(void)
{
	int ret = 0;

	if (func_defalut_setting)
		ret = func_defalut_setting();

	return ret;
}


int switch_layer_get_switch_mode(unsigned int *mode)
{
	int ret = 0;

	if (func_get_switch_mode)
		ret = func_get_switch_mode(mode);

	return ret;
}

void switch_layer_acl_enable(void)
{
	if (func_acl_enable)
		func_acl_enable();
}

int switch_layer_set_wan_rule(void)
{
	int ret = 0;

	if (func_set_wan_rule)
		ret = func_set_wan_rule();

	return ret;
}

int switch_layer_set_lan_rule(unsigned char mac_addr[], void *data)
{
	int ret = 0;

	if (func_set_lan_rule)
		ret = func_set_lan_rule(mac_addr, data);

	return ret;
}

int switch_layer_netlink_init(void)
{
	int ret = 0;

	if (func_netlink_init)
		ret = func_netlink_init();

	return ret;
}

int switch_layer_init(void)
{
	int err = 0, err2 = 0;
	int num = 0;

	nl_init_flag = true;

	os_memset(&arl, 0, sizeof(struct arl_setting));

	dl_list_init(&switch_vlan_head);

	bridge_init();

	err = switch_read_config_file(cfg_file);
	if (err)
		goto fail;

	err = switch_ioctl_init(os_strlen(eth_dev_name) > 0 ? (void *)eth_dev_name : NULL);

	/* chip name got by file: AN8855, MT7988 */
	switch_get_chip_name_by_file();

	/* hook func register:
	 *		an8855_functions if CHIP_AN8855 detected
	 *		mt753x_functions default(other chips);
	 */
	switch_hooks_register();

	err2 = switch_layer_netlink_init();
	if (err && err2) {
		err(DEBUG_CAT_INIT, "switch layer init fail\n");
		goto fail;
	}

	/* chip got by reg after netlink init: MT7530, MT7531 */
	if (!is_chip_valid()) {
		switch_get_chip_name_by_reg();
		if (!is_chip_valid()) {
			warn(DEBUG_CAT_INIT, "no chip unsupport or chip id is invalid!\n");
			goto fail;
		}
	}

	attres = (struct switch_attr *)os_malloc(sizeof(struct switch_attr));
	if (!attres)
		goto fail;

	attres->dev_id = -1;
	attres->port_num = -1;
	attres->phy_dev = -1;

	/*set the defaut vid setting, lan_vid=1, wan_vid=2, cpu_port=6*/
	if (arl.lan_vid_num == 0 && arl.wan_vid_num == 0) {

		arl.lan_vid_num = 1;
		arl.lan_vid = os_malloc(sizeof(unsigned short));
		if (!arl.lan_vid)
			goto fail;
		arl.lan_vid[0] = 1;

		arl.wan_vid_num = 1;
		arl.wan_vid = os_malloc(sizeof(unsigned short));
		if (!arl.wan_vid)
			goto fail;
		arl.wan_vid[0] = 2;
		notice(DEBUG_CAT_INIT, "use default vlan setting:lan_vid=1, wan_vid=2\n");
	}
	if (arl.cpu_port_num == 0) {

		arl.cpu_port_num = 2;
		arl.cpu_port = os_malloc(arl.cpu_port_num * sizeof(unsigned short));
		if (!arl.cpu_port)
			goto fail;

		arl.cpu_port[0] = 5;
		arl.cpu_port[1] = 6;

		notice(DEBUG_CAT_INIT, "use default cpu port %d and %d\n",
			arl.cpu_port[0], arl.cpu_port[1]);
	}

	notice(DEBUG_CAT_INIT, "lan vid: ");
	for (num = 0; num < arl.lan_vid_num; num++)
		notice_np(DEBUG_CAT_INIT, "%d ", arl.lan_vid[num]);
	notice_np(DEBUG_CAT_INIT, "\n");
	notice(DEBUG_CAT_INIT, "wan vid: ");
	for (num = 0; num < arl.wan_vid_num; num++)
		notice_np(DEBUG_CAT_INIT, "%d ", arl.wan_vid[num]);
	notice_np(DEBUG_CAT_INIT, "\n");
	notice(DEBUG_CAT_INIT, "cpu_port: ");
	for (num = 0; num < arl.cpu_port_num; num++)
		notice_np(DEBUG_CAT_INIT, "%d ", arl.cpu_port[num]);
	notice_np(DEBUG_CAT_INIT, "\n");

	if (switch_defalut_setting() < 0)
		goto fail;

	return err;
fail:
	if (arl.lan_vid)
		os_free(arl.lan_vid);
	if (arl.wan_vid)
		os_free(arl.wan_vid);
	if (arl.cpu_port)
		os_free(arl.cpu_port);
	return -1;
}

int switch_layer_deinit()
{
	int ret = 0;

	if (func_switch_deinit)
		func_switch_deinit();

	return ret;
}


/*According to the mac address, searching the switch mac table*/
int switch_port_find_by_mac(unsigned char *mac_addr, int vid, unsigned char *age)
{
	int ret = 0;

	if (func_port_find_by_mac)
		ret = func_port_find_by_mac(mac_addr, vid, age);

	return ret;
}

int switch_port_find_by_mac_fid(unsigned char *mac_addr, int fid, unsigned char *age)
{
	int ret = 0;

	if (func_port_find_by_mac_fid)
		ret = func_port_find_by_mac_fid(mac_addr, fid, age);

	return ret;
}

int switch_get_lan_wan_portmaps(int vid, unsigned int *port_map)
{
	int ret = 0;

	if (func_get_lan_wan_portmaps)
		ret = func_get_lan_wan_portmaps(vid, port_map);

	return ret;
}

int switch_layer_get_port_type(unsigned int *lport_map, unsigned int *wport_map)
{
	int ret = 0;

	if (func_get_port_type)
		ret = func_get_port_type(lport_map, wport_map);
	return ret;
}

int switch_layer_get_table_entry(struct dl_list *entry_list)
{
	int ret = 0;

	if (func_get_table_entry)
		ret = func_get_table_entry(entry_list);

	return ret;
}

int switch_layer_table_search(unsigned char *mac, struct ethernet_client_entry *entry)
{
	int port_map = 0, port_map_max = -1, i=0;
	unsigned char max_age = 0, age = 0;
	int port_map_cpu = 1 << 6;
	if (entry == NULL)
		return -1;

	/* switch disabled, got entry from bridge */
	if (!is_chip_valid())
		return bridge_search_table(mac, entry);

	/*get the client with largest age*/
	for (i = 0; i < arl.lan_vid_num; i++) {
		port_map = switch_port_find_by_mac(mac, (int)(arl.lan_vid[i]), &age);

		/*only get lan port, don't get cpu port*/
		if (port_map < port_map_cpu && age > max_age) {
			max_age = age;
			port_map_max = port_map;
		}
	}

	for (i = 0; i < arl.wan_vid_num; i++) {
		port_map = switch_port_find_by_mac(mac, (int)(arl.wan_vid[i]), &age);

		/*only get wan port, don't get cpu port*/
		if (port_map < port_map_cpu && age > max_age) {
			max_age = age;
			port_map_max = port_map;
		}
	}
#if defined(CONFIG_RALINK_MT7628)
#else
	/*if vlan is not configed, use fid to search table*/
	port_map = switch_port_find_by_mac_fid(mac, 0, &age);
	if (port_map < port_map_cpu && age > max_age) {
		max_age = age;
		port_map_max = port_map;
	}
#endif
	/*not find this entry*/
	if (port_map_max == -1)
		return bridge_search_table(mac, entry);

	for (i = 0; i < MAX_PHY_PORT; i++) {
		if (port_map_max & (0x00000001 << i))
			break;
	}

	entry->age = max_age;
	entry->port_index = i;
	info(DEBUG_CAT_ETH, "port_index=%d age=%d\n", entry->port_index, entry->age);

	return 0;
}


int switch_layer_get_ext_phy_status(unsigned char port, int *status)
{
	int ret = 0;
	int value = 0;
	int phy = 0, is_cl45 = 0;

	if (bridge_get_phy_id(port, &phy, &is_cl45))
		return 0;

	if (is_cl45) {
		ret = mii_cl45_read_phy(phy, 7, 1, &value);
		if (ret < 0) {
			info(DEBUG_CAT_ETH, "Get externel phy port %d status error\n", port);
			return 0;
		}
	} else {
		/*Add your code according to third party phy*/
		ret = mii_cl22_read_phy(phy, 1, &value);
		if (ret < 0) {
			info(DEBUG_CAT_ETH, "Get externel phy port %d status error\n", port);
			return 0;
		}
	}
	*status = (value & 0x00000004) ? 1 : 0;
	return 0;
}


/*Get port phy link status*/
int switch_layer_get_port_status(unsigned char port, int *status)
{
	int ret = 0;

	if (func_get_port_status && port < 5)
		ret = func_get_port_status(port, status);

	/* external phy port status */
	if (port >= 5)
		ret = switch_layer_get_ext_phy_status(port, status);

	return ret;
}


int switch_layer_get_port_speed(unsigned char port, int *speed)
{
	int ret = 0;

	if (func_get_port_speed && port < 5)
		ret = func_get_port_speed(port, speed);

	/* external phy port speed */
	if (port >= 5) {
		*speed = bridge_get_wan_speed(port);
		ret = 0;
	}

	return ret;
}

int switch_layer_set_port_block(unsigned char port, int enable)
{
	int ret = 0;

	/* block and unblock only for switch ports */
	if (func_set_port_block && port < 5)
		ret = func_set_port_block(port, enable);

	return ret;
}

int switch_layer_clear_table(void)
{
	int ret = 0;

	/* clear both switch ports and bridge table */
	if (func_clear_table)
		ret = func_clear_table();

	return ret;
}

int switch_layer_clear_port_table(unsigned char port)
{
	int ret = 0;

	/* clear port table only for switch ports */
	if (func_clear_port_table && port < 5)
		ret = func_clear_port_table(port);

	return ret;
}

/*
**	set ts vlan on wan port, wan cpu port, each lan port
**	vid[]:		vlan ids
**	vid_cnt:	num of vids
**	active:		1-active; 2-inactive
*/
int switch_vlan_set(unsigned short vid[], unsigned short vid_cnt, unsigned char active, enum vlan_type type)
{
	int ret = 0;

	if (func_vlan_set)
		ret = func_vlan_set(vid, vid_cnt, active, type);

	return ret;
}

/*
**	set ts vlan on wan port, wan cpu port, each lan port
**	vid[]:		vlan ids
**	vid_cnt:	num of vids
**	active:		1-active; 2-inactive
*/
int switch_ts_vlan_set(unsigned short vid[], unsigned short vid_cnt, unsigned char active)
{
	return switch_vlan_set(vid, vid_cnt, active, e_traffic_separation_vlan);
}

/*
**	set transparent vlan on wan port, lan cpu port, each lan port
**	vid[]:		vlan ids
**	vid_cnt:	num of vids
**	active:		1-active; 2-inactive
*/
int switch_transparent_vlan_set(unsigned short vid[], unsigned short vid_cnt, unsigned char active)
{
	return switch_vlan_set(vid, vid_cnt, active, e_transparent_vlan);
}



