/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

/*
 * switch_layer.h: switch layer for MAP
 *
 * Author: Sirui Zhao <Sirui.Zhao@mediatek.com>
 */
#ifndef SWITCH_LAYER_H
#define SWITCH_LAYER_H
#include <sys/queue.h>
#include <stdbool.h>
#include "../inc/list.h"


#define SWITCH_MAX_PORT							7
#define BIT_OFFSET								16


#define CHIP_FILE_AX7988						"/proc/device-tree/compatible"
#define CHIP_FILE_AN8855						"/proc/air_sw/device"


enum vlan_type {
	e_traffic_separation_vlan = 1,
	e_transparent_vlan,
};

struct switch_vlan_list {
	struct dl_list entry;
	unsigned short vid;
	unsigned char port_bitmap;
	unsigned char cpu_port;
	enum vlan_type vid_type;
};


extern struct switch_attr *attres;
extern struct eth_ops switch_layer_ops;
extern bool nl_init_flag;
extern unsigned int lan_port_bitmap;
extern unsigned int wan_port_bitmap;
extern unsigned int ts_vlan_cnt;
extern unsigned int transparent_vlan_cnt;
extern struct arl_setting arl;
extern struct dl_list switch_vlan_head;

int is_chip_valid(void);
int is_chip_mt7628(void);
int is_chip_mt7531(void);
int is_chip_mt7530(void);
int is_chip_an8855(void);
int switch_reg_read(int offset, int *value);
int switch_reg_write(int offset, int value);
struct ethernet_client_entry *switch_create_table_entry(unsigned char port_index, unsigned char age,
	unsigned char *mac, unsigned char vid);

int switch_clear_entry_list(struct dl_list *entry_list);

#endif
