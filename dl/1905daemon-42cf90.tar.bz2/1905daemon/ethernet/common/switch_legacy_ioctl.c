/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

/*
 * switch_legacy_ioctl.c, it's used for <7530 + raeth>
 *
 * Author: Sirui Zhao <Sirui.Zhao@mediatek.com>
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <linux/if.h>
#include <pthread.h>
#include <linux/mdio.h>

#include "ra_ioctl.h"
#include "ethernet_layer.h"
#include "debug.h"
#include "netlink_event.h"
#include "common.h"

#ifndef CONFIG_SUPPORT_OPENWRT
#include <linux/autoconf.h>
#endif

static int esw_fd;
static char eth_dev_name[IFNAMSIZ] = {0x00};

#if defined (CONFIG_RALINK_MT7628)
/****************************************************
*
*Function name : reg_read_ioctl()
*Description   : register read for old switch chip like
				 7628 switch and so on
*Parameter	:
*		@offset : register address offset, see chip CR
*		@value  : output the register value
*Return:
*		0: Success, Other fail
*other:
*		for 7628 switch use
***************************************************/

int reg_read_ioctl(int offset, int *value) {
	struct ifreq ifr;
	struct esw_reg reg;

	if (value == NULL)
		return -1;
	reg.off = offset;
	os_strncpy(ifr.ifr_name, eth_dev_name, sizeof(ifr.ifr_name));
	ifr.ifr_name[sizeof(ifr.ifr_name) - 1] = '\0';
	ifr.ifr_data = &reg;
	if (-1 == ioctl(esw_fd, RAETH_ESW_REG_READ, &ifr)) {
		info(DEBUG_CAT_ETH, "ioctl error, errno %d(%s)\n", errno, strerror(errno));
		return -1;
	}
	*value = reg.val;
	return 0;
}

/****************************************************
*
*Function name : reg_write_ioctl()
*Description   : register write for old switch chip like
				 7628 switch and so on
*Parameter	:
*		@offset : register address offset, see chip CR
*		@value  : input the register value
*Return:
*		0: Success, Other fail
*other:
*		for 7628 switch use
***************************************************/

int reg_write_ioctl(int offset, int value)
{
	struct ifreq ifr;
	struct esw_reg reg;

	reg.off = offset;
	reg.val = value;
	os_strncpy(ifr.ifr_name, eth_dev_name, sizeof(ifr.ifr_name));
	ifr.ifr_name[sizeof(ifr.ifr_name) - 1] = '\0';
	ifr.ifr_data = &reg;
	if (-1 == ioctl(esw_fd, RAETH_ESW_REG_WRITE, &ifr)) {
		info(DEBUG_CAT_ETH, "ioctl error, errno %d(%s)\n", errno, strerror(errno));
		return -1;
	}

	return 0;
}

#elif defined(CONFIG_MT753X_GSW)
int reg_read_ioctl(int offset, int *value)
{
	struct ifreq ifr;
	struct ra_mii_ioctl_data mii;

	os_strncpy(ifr.ifr_name, eth_dev_name, sizeof(ifr.ifr_name));
	ifr.ifr_name[sizeof(ifr.ifr_name) - 1] = '\0';
	ifr.ifr_data = &mii;

	mii.phy_id = 0x1f;
	mii.reg_num = offset;

	if (-1 == ioctl(esw_fd, RAETH_MII_READ, &ifr)) {
		info(DEBUG_CAT_ETH, "ioctl error, errno %d(%s)\n", errno, strerror(errno));
		return -1;
	}
	*value = mii.val_out;
	return 0;
}

int reg_write_ioctl(int offset, int value)
{
	struct ifreq ifr;
	struct ra_mii_ioctl_data mii;

	os_strncpy(ifr.ifr_name, eth_dev_name, sizeof(ifr.ifr_name));
	ifr.ifr_name[sizeof(ifr.ifr_name) - 1] = '\0';
	ifr.ifr_data = &mii;

	mii.phy_id = 0x1f;
	mii.reg_num = offset;
	mii.val_in = value;

	if (-1 == ioctl(esw_fd, RAETH_MII_WRITE, &ifr)) {
		info(DEBUG_CAT_ETH, "ioctl error, errno %d(%s)\n", errno, strerror(errno));
		return -1;
	}
	return 0;
}
#else
int reg_read_ioctl(unsigned int offset, unsigned int *value)
{
	struct ifreq ifr;
	struct esw_reg reg;

	os_strncpy(ifr.ifr_name, eth_dev_name, sizeof(ifr.ifr_name));
	ifr.ifr_name[sizeof(ifr.ifr_name) - 1] = '\0';
	ifr.ifr_data = &reg;

	reg.off = offset + 0x1fb58000;

	if (-1 == ioctl(esw_fd, RAETH_MII_READ, &ifr)) {
		info(DEBUG_CAT_ETH, "ioctl error, errno %d(%s)\n", errno, strerror(errno));
		return -1;
	}
	*value = reg.val;
	return 0;
}

int reg_write_ioctl(unsigned int offset, unsigned int value)
{
	struct ifreq ifr;
	struct esw_reg reg;

	os_strncpy(ifr.ifr_name, eth_dev_name, sizeof(ifr.ifr_name));
	ifr.ifr_name[sizeof(ifr.ifr_name) - 1] = '\0';
	ifr.ifr_data = &reg;

	reg.off = offset + 0x1fb58000;
	reg.val = value;

	if (-1 == ioctl(esw_fd, RAETH_MII_WRITE, &ifr)) {
		info(DEBUG_CAT_ETH, "ioctl error, errno %d(%s)\n", errno, strerror(errno));
		return -1;
	}
	return 0;
}

#endif

#if defined(CONFIG_MT753X_GSW)

/*host_bus access internal phy*/
int mii_cl22_read_phy(int phy_num, int phy_reg, int *status)
{
	int method = 0, ret = 0;
	struct ifreq ifr;
	struct ra_mii_ioctl_data mii;

	os_strncpy(ifr.ifr_name, eth_dev_name, sizeof(ifr.ifr_name));
	ifr.ifr_name[sizeof(ifr.ifr_name) - 1] = '\0';
	ifr.ifr_data = &mii;

	mii.phy_id = phy_num;
	mii.reg_num = phy_reg;		/*default value*/
	method = RAETH_MII_READ;	/*read*/

	ret = ioctl(esw_fd, method, &ifr);
	if (ret < 0) {
		info(DEBUG_CAT_ETH, "mii_mgr_x ioctl error, errno %d(%s)\n", errno, strerror(errno));
		return -1;
	}
	*status = mii.val_out;

	return 0;
}

/*host_bus access external phy*/
int mii_cl45_read_phy(int phy_num, int dev, int phy_reg, int *status)
{
	int method = 0, ret = 0;
	struct ifreq ifr;
	struct ra_mii_ioctl_data mii;

	os_strncpy(ifr.ifr_name, eth_dev_name, sizeof(ifr.ifr_name));
	ifr.ifr_name[sizeof(ifr.ifr_name) - 1] = '\0';
	ifr.ifr_data = &mii;

	mii.phy_id = mdio_phy_id_c45(phy_num, dev);
	mii.reg_num = phy_reg;
	/*mii.port_num = phy_num;*/
	/*mii.dev_addr = dev;*/
	/*mii.reg_addr = phy_reg;*/
	method = RAETH_MII_READ_CL45;
	ret = ioctl(esw_fd, method, &ifr);
	if (ret < 0) {
		info(DEBUG_CAT_ETH, "mii_mgr_cl45 ioctl error, errno %d(%s)\n", errno, strerror(errno));
		return -1;
	}
	*status = mii.val_out;

	return 0;
}

#else
int mii_cl22_read_phy(unsigned int port_num, unsigned int reg, unsigned int *value)
{
	struct ifreq ifr;
	struct ra_mii_ioctl_data mii;

	os_strncpy(ifr.ifr_name, eth_dev_name, sizeof(ifr.ifr_name));
	ifr.ifr_name[sizeof(ifr.ifr_name) - 1] = '\0';
	ifr.ifr_data = &mii;

	mii.phy_id = port_num + 8;
	mii.reg_num = reg;

	if (-1 == ioctl(esw_fd, RAETH_ESW_PHY_READ, &ifr)) {
		info(DEBUG_CAT_ETH, "ioctl error, errno %d(%s)\n", errno, strerror(errno));
		return -1;
	}
	*value = mii.val_out;
	return 0;
}
int mii_cl22_write_phy(unsigned int port_num, unsigned int reg, unsigned int value)
{
	struct ifreq ifr;
	struct ra_mii_ioctl_data mii;

	os_strncpy(ifr.ifr_name, eth_dev_name, sizeof(ifr.ifr_name));
	ifr.ifr_name[sizeof(ifr.ifr_name) - 1] = '\0';
	ifr.ifr_data = &mii;

	mii.phy_id = port_num + 8;
	mii.reg_num = reg;
	mii.val_in = value;

	if (-1 == ioctl(esw_fd, RAETH_ESW_PHY_WRITE, &ifr)) {
		info(DEBUG_CAT_ETH, "ioctl error, errno %d(%s)\n", errno, strerror(errno));
		return -1;
	}

	return 0;
}

int mii_cl45_read_phy(unsigned int port_num, unsigned int dev,
			       unsigned int reg, unsigned int *value)
{
	const unsigned int MMD_Control_register = 0xD; // 0xd=13
	const unsigned int MMD_addr_data_register = 0xE; // 0xe=14
	const unsigned int page_reg = 31;

	mii_cl22_write_phy(port_num, page_reg, 0x00); //switch to main page
	mii_cl22_write_phy(port_num, MMD_Control_register, (0<<14)+dev);
	mii_cl22_write_phy(port_num, MMD_addr_data_register, reg);
	mii_cl22_write_phy(port_num, MMD_Control_register, (1<<14)+dev);
	mii_cl22_read_phy(port_num, MMD_addr_data_register, value);

	return 0;
}
#endif

int switch_ioctl_init(void *context)
{
	char *eth_name = (char*)context;
	os_memset(eth_dev_name, 0, sizeof(eth_dev_name));

	esw_fd = socket(AF_INET, SOCK_DGRAM, 0);
	if (esw_fd < 0) {
		err(DEBUG_CAT_INIT, "create socket error, errno %d(%s)\n", errno, strerror(errno));
		return -1;
	}

	os_memset(eth_dev_name, 0, sizeof(eth_dev_name));

	if (eth_name) {
		if (os_strlen(eth_name) >= IFNAMSIZ) {
			err(DEBUG_CAT_INIT, "error, eth_name character length larger than IFNAMSIZ\n");
			return -1;
		}
		(void)snprintf(eth_dev_name, sizeof(eth_dev_name), "%s", eth_name);
		eth_dev_name[IFNAMSIZ - 1] = '\0';
	} else {
#ifndef CONFIG_SUPPORT_OPENWRT
		(void)snprintf(eth_dev_name, sizeof(eth_dev_name), "%s", "eth2");
#else
		(void)snprintf(eth_dev_name, sizeof(eth_dev_name), "%s", "eth0");
#endif
		eth_dev_name[IFNAMSIZ - 1] = '\0';
	}

	err(DEBUG_CAT_INIT, "ethernet device name %s\n", eth_dev_name);

	return 0;
}

int switch_ioctl_deinit(void *context)
{
	os_memset(eth_dev_name, 0, sizeof(eth_dev_name));
	close(esw_fd);
	return 0;
}
