/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

/*
 * switch_layer.h: switch layer for MAP
 *
 * Author: Sirui Zhao <Sirui.Zhao@mediatek.com>
 */
#ifndef SWITCH_LAYER_MT753x_H
#define SWITCH_LAYER_MT753x_H
#include <sys/queue.h>

#define MT753X_GENL_NAME "mt753x"
#define MT7530_DSA_GENL_NAME "mt753x_dsa"

/* valid vid is 1-4094 */
#define MAX_VLAN								4094

#define CHIP_MT7530								0x7530
#define CHIP_MT7531								0x7531

#define SWITCH_ERROR_COUNTER					10

#define REG_ESW_WT_MAC_ATA1						0x74
#define REG_ESW_WT_MAC_ATA2						0x78
#define REG_ESW_WT_MAC_ATWD						0x7C
#define REG_ESW_WT_MAC_ATC						0x80
#define REG_ESW_TABLE_TSRA1						0x84
#define REG_ESW_TABLE_TSRA2						0x88
#define REG_ESW_TABLE_ATRD						0x8C

#define REG_ESW_VLAN_VTCR						0x90
#define REG_ESW_VLAN_VAWD1						0x94
#define REG_ESW_VLAN_VAWD2						0x98

#if defined(CONFIG_RALINK_MT7628)
#define REG_ESW_VLAN_ID_BASE					0x50
#else
#define REG_ESW_VLAN_ID_BASE					0x100
#endif
#define REG_ESW_VLAN_MEMB_BASE					0x70
#define REG_ESW_TABLE_SEARCH					0x24
#define REG_ESW_TABLE_STATUS0					0x28
#define REG_ESW_TABLE_STATUS1					0x2C
#define REG_ESW_TABLE_STATUS2					0x30

int mt753x_netlink_init(void);
int mt753x_get_switch_mode(unsigned int *mode);
int mt753x_get_port_status(unsigned char port, int *status);
int mt753x_get_port_speed(unsigned char port, int *speed);
int mt753x_get_phy_speed(unsigned char port);
int mt753x_defalut_setting(void);
int mt753x_set_port_block(unsigned char port, int enable);
void mt753x_acl_enable(void);
int mt753x_set_wan_rule(void);
int mt753x_set_lan_rule(unsigned char mac_addr[], void *data);
int mt753x_port_find_by_mac(unsigned char *mac_addr, int vid, unsigned char *age);
int mt753x_port_find_by_mac_fid(unsigned char *mac_addr, int fid, unsigned char *age);
int mt753x_get_port_type(unsigned int *lport_map, unsigned int *wport_map);
int mt753x_get_table_entry(struct dl_list *entry_list);
int mt753x_clear_table(void);
int mt753x_clear_port_table(unsigned char port);
int mt753x_clear_table(void);
int mt753x_clear_port_table(unsigned char port);
int mt753x_vlan_set(unsigned short vid[], unsigned short vid_cnt, unsigned char active, enum vlan_type type);
int mt753x_get_lan_wan_portmaps(int vid, unsigned int *port_map);
void mt753x_switch_deinit(void);
#endif
