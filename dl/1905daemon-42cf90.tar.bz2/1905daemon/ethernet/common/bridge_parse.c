/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *
 * bridge_parse.c: bridge fdb parse
 * Author: Zheng Zhou<zheng.zhou@mediatek.com>
 */

#include <errno.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <linux/if.h>
#include <pthread.h>
#include <stdbool.h>
#include <sys/wait.h>
#include <linux/mii.h>
#include "common.h"
#include "libbridge.h"
#include "ethernet_layer.h"
#include "debug.h"
#include "os.h"
#include "bridge_parse.h"


struct dsa_inf inf[MAX_INF_NUM];
struct externel_phy_info phy_info[MAX_EXT_PHY_PORT_NUM];

int sk_fd;
int sk_fd_ext_phy;
unsigned char lan_cnt;


int execl_sh(char *file)
{
	pid_t pid = 0;
	pid_t ret = 0;
	int status = 0;

	if (file == NULL) {
		err(DEBUG_CAT_ETH, "error, no file specified");
		return -1;
	}

	pid = fork();
	if (pid == -1) {
		/* handle error */
		status = -1;
		err(DEBUG_CAT_ETH, "error fork");
	} else if (pid != 0) {
		while ((ret = waitpid(pid, &status, 0)) == -1) {
			if (errno != EINTR) {
				/* handle error */
				status = -1;
				err(DEBUG_CAT_ETH, "error waitpid");
				break;
			}
		}
	} else {
		info(DEBUG_CAT_ETH, "run /bin/sh %s", file);
		if (execl("/bin/sh", "sh", file, NULL) == -1) {
			/* handle error */
			err(DEBUG_CAT_ETH, "error execle");
			exit(127);
		}
	}

	return status;
}


char *dsa_config_get_line(char *s, int size, FILE *stream, int *line, char **_pos)
{
	char *pos, *end, *sstart;

	while (fgets(s, size, stream)) {
	(*line)++;
	s[size - 1] = '\0';
	pos = s;

	/* Skip white space from the beginning of line. */
	while (*pos == ' ' || *pos == '\t' || *pos == '\r')
		pos++;

	/* Skip comment lines and empty lines */
	if (*pos == '#' || *pos == '\n' || *pos == '\0')
		continue;

	/*
	* Remove # comments unless they are within a double quoted
	* string.
	*/
	sstart = os_strchr(pos, '"');
	if (sstart)
		sstart = os_strrchr(sstart + 1, '"');
	if (!sstart)
		sstart = pos;
	end = os_strchr(sstart, '#');
	if (end)
		*end-- = '\0';
	else
		end = pos + os_strlen(pos) - 1;

	/* Remove trailing white space. */
	while (end > pos &&
	(*end == '\n' || *end == ' ' || *end == '\t' ||
	*end == '\r'))
	*end-- = '\0';

	if (*pos == '\0')
		continue;

	if (_pos)
		*_pos = pos;

	return pos;
	}

	if (_pos)
	*_pos = NULL;
	return NULL;
}

/*
 * lan[]=/etc/config/network | grep 'list ports'
 * lan[last] is PHY WAN
 * lan[last-1] is PHY LAN
 */
int parse_eth_lan_interface(char *str)
{
	unsigned char idx = 0;
	char *token = NULL;
	unsigned char tmp_len = 0;

	lan_cnt = 0;

	token = strtok(str, " ");

	if (!token) {
		tmp_len = sizeof(inf[lan_cnt].if_name);
		os_strncpy(inf[lan_cnt++].if_name, str, tmp_len - 1);
		inf[lan_cnt - 1].if_name[tmp_len - 1] = '\0';
		goto end;
	}

	while (token) {
		if (lan_cnt >= MAX_INF_NUM) {
			warn(DEBUG_CAT_INIT, "lan interface count exceeds MAX ETH INTERFACE count(5)\n");
			goto end;
		}
		if (os_strlen(token) >= IFNAMSIZ)
			goto end;
		os_strncpy(inf[lan_cnt].if_name, token, os_strlen(token));
		inf[lan_cnt].if_name[IFNAMSIZ - 1] = '\0';
		token = strtok(NULL, " ");
		lan_cnt++;
	}

end:
	notice(DEBUG_CAT_INIT, "lan interfaces:");
	for (idx = 0; idx < lan_cnt; idx++)
		notice_np(DEBUG_CAT_INIT, "%s ", inf[idx].if_name);
	notice_np(DEBUG_CAT_INIT, "\n");

	return 0;
}


int parse_ext_phy_port(char *str)
{
	unsigned char idx = 0, phy_port_cnt = 0;
	char *token = NULL;
	int phy_id = 0;

	token = strtok(str, " ");
	if (!token) {
		phy_id = strtol(str, NULL, 10);
		if (phy_id >= MAX_INF_NUM) {
			notice(DEBUG_CAT_INIT, "port no[%d] bigger than %d\n", phy_id, MAX_INF_NUM);
			goto end;
		}
		phy_info[phy_port_cnt].phy_id = phy_id;

		phy_port_cnt++;
		goto end;
	}

	while (token) {
		if (phy_port_cnt >= MAX_EXT_PHY_PORT_NUM) {
			notice(DEBUG_CAT_INIT, "ext phy port exceeds MAX count(2)\n");
			goto end;
		}
		/* port no should be less than 10 */
		phy_id = strtol(token, NULL, 10);
		if (phy_id >= MAX_INF_NUM) {
			notice(DEBUG_CAT_INIT, "port no[%s] bigger than %d\n", token, MAX_INF_NUM);
			goto end;
		}

		phy_info[phy_port_cnt].phy_id = phy_id;
		token = strtok(NULL, " ");

		phy_port_cnt++;
	}

end:
	notice(DEBUG_CAT_INIT, "external phy ports:");
	for (idx = 0; idx < phy_port_cnt; idx++)
		notice_np(DEBUG_CAT_INIT, "%d ", phy_info[idx].phy_id);
	notice_np(DEBUG_CAT_INIT, "\n");
	return 0;
}


int read_config_file(char *file_path)
{
	FILE *file;
	char buf[256], *pos, *token;
	char tmpbuf[256];
	int line = 0;
	int res = 0;

	file = fopen(file_path, "r");

	if (!file) {
		err(DEBUG_CAT_INIT, "open ehternet cfg file (%s) fail, use default setting\n", file_path);
		return 0;
	}
	os_memset(buf, 0, 256);
	os_memset(tmpbuf, 0, 256);

	while (dsa_config_get_line(buf, sizeof(buf), file, &line, &pos)) {
		if (os_strlen(pos) >= sizeof(tmpbuf)) {
			warn(DEBUG_CAT_INIT, "line(%s) too long! excced %d\n", pos, (int)sizeof(tmpbuf));
			continue;
		}
		res = snprintf(tmpbuf, sizeof(tmpbuf), "%s", pos);
		if (os_snprintf_error(sizeof(tmpbuf), res))
			warn(DEBUG_CAT_INIT, "snprintf fail!\n");
		token = strtok(pos, "=");

		if (token != NULL) {
			if (os_strcmp(token, "lan") == 0) {
				token = strtok(NULL, "");
				if (token == NULL)
					continue;
				parse_eth_lan_interface(token);
			} else if (os_strcmp(token, "br_lan") == 0) {
				token = strtok(NULL, "");
				if (token == NULL)
					continue;
				if (os_strlen(token) >= IFNAMSIZ) {
					warn(DEBUG_CAT_INIT, "br_lan name size error %s\n", token);
					continue;
				}
				os_strncpy(br_lan, token, os_strlen(token));
				br_lan[IFNAMSIZ - 1] = '\0';
			}  else if (os_strcmp(token, "ext_phy_port") == 0) {
				token = strtok(NULL, "");
				if (token == NULL)
					continue;
				parse_ext_phy_port(token);
			} else if ((os_strcmp(token, "lan_vid") == 0) ||
				(os_strcmp(token, "wan_vid") == 0))
				continue;
			else
				warn(DEBUG_CAT_INIT, "unknown config line %s\n", token);
		}
	}

	if (fclose(file) < 0)
		err(DEBUG_CAT_INIT, "fclose fail!\n");

	notice(DEBUG_CAT_INIT, "bridge interface:%s\n", br_lan);

	return 0;
}

char *dsa_cfg_file = "/etc/ethernet_cfg.txt";
char br_lan[IFNAMSIZ];


int get_phy_id(struct dsa_inf *intf)
{
	int ret = ETH_SUCCESS;
	struct ifreq ifr = {0};
	struct mii_ioctl_data *mii = NULL;
	int sock = 0;

	sock = socket(AF_INET, SOCK_DGRAM, 0);
	if (sock < 0) {
		notice(DEBUG_CAT_INIT, "fail to create socket\n");
		ret = ETH_ERROR_FAIL;
		goto fail;
	}

	mii = (struct mii_ioctl_data *)&ifr.ifr_data;

	os_strncpy(ifr.ifr_name, intf->if_name, IFNAMSIZ);
	ifr.ifr_name[IFNAMSIZ - 1] = '\0';

	if (ioctl(sock, SIOCGMIIPHY, &ifr) < 0) {
		notice(DEBUG_CAT_INIT, "fail to get SIOCGMIIPHY\n");
		ret = ETH_ERROR_FAIL;
		goto fail;
	}
	intf->real_index = mii->phy_id;

fail:
	if (sock >= 0)
		close(sock);
	return ret;
}

static int get_port_no(const char *br, const char *p,  void *arg)
{
	struct port_info pinfo;
	struct dsa_inf *intf = (struct dsa_inf *)arg;

	if (br_get_port_info(br, p, &pinfo)) {
		warn(DEBUG_CAT_INIT, "Can't get info for %p", p);
		return 0;
	}

	if (os_strlen(p) != os_strlen(intf->if_name))
		return 0;

	if (os_strncmp(p, intf->if_name, os_strlen(intf->if_name)))
		return 0;

	intf->port_no = pinfo.port_no;

	return 0;
}

unsigned int get_inf_portno_on_bridge(struct dsa_inf *interface)
{
	int err = 0;

	err = br_foreach_port(br_lan, get_port_no, (void *)interface);
	if (err < 0)
		notice(DEBUG_CAT_INIT, "can't get ports: %s\n", strerror(-err));

	return err;
}

int sockets_open(void)
{
	int fd = 0;

	fd = socket(PF_PACKET, SOCK_RAW, htobe16(ETH_P_ALL));
	if (fd > 0)
		;
	else
		warn(DEBUG_CAT_INIT, "create socket error, error %d(%s)\n", errno, strerror(errno));

	return fd;
}

int bridge_set_externel_phy_info(unsigned char index, int phy_id)
{
	int ret = ETH_SUCCESS;
	char cmd[STR_LEN_S] = {0};
	FILE *stream = NULL;
	int phy_flag = 0;

	memset(cmd, 0, sizeof(cmd));
	(void)os_snprintf(cmd, sizeof(cmd), "/sys/firmware/devicetree/base/ethernet@15100000/mdio-bus/ethernet-phy@%d/compatible", phy_id);

	if (!access(cmd, 0))
		phy_flag = 0;
	else {
		memset(cmd, 0, sizeof(cmd));
		(void) os_snprintf(cmd, sizeof(cmd), "/sys/firmware/devicetree/base/ethernet@15100000/mdio-bus/phy@%d/compatible", phy_id);
		if (!access(cmd, 0))
			phy_flag = 1;
	}

	memset(cmd, 0, sizeof(cmd));
	if (phy_flag)
		(void)os_snprintf(cmd, STR_LEN_S, "cat /sys/firmware/devicetree/base/ethernet@15100000/mdio-bus/phy@%d/compatible", phy_id);
	else
		(void)os_snprintf(cmd, STR_LEN_S, "cat /sys/firmware/devicetree/base/ethernet@15100000/mdio-bus/"
			"ethernet-phy@%d/compatible", phy_id);

	stream = popen(cmd, "r");
	if (stream == NULL) {
		warn(DEBUG_CAT_INIT, "popen fail command: %s, errno %d(%s)\n\n", cmd, errno, strerror(errno));
		return -1;
	}
	memset(cmd, 0, sizeof(cmd));
	ret = fread(cmd, sizeof(char), sizeof(cmd), stream);
	cmd[STR_LEN_S-1] = 0;/*null terminated*/
	if (ret)
		;

	(void)pclose(stream);

	if (os_strcmp(cmd, "ethernet-phy-ieee802.3-c45") == 0)
		phy_info[index].cl45 = 1;

	return ret;
}

int bridge_get_phy_id(int index, int *phy, int *cl45)
{
	int ret = ETH_SUCCESS;

	if (index == 5) {
		if (phy_info[0].phy_id != 0xff) {
			*phy =  phy_info[0].phy_id;
			*cl45 =  phy_info[0].cl45;
		} else
			ret = ETH_ERROR_FAIL;
	}

	if (index == 6) {
		if (phy_info[1].phy_id != 0xff) {
			*phy =  phy_info[1].phy_id;
			*cl45 =  phy_info[1].cl45;
		} else
			ret = ETH_ERROR_FAIL;
	}

	return ret;
}


int init_phy_by_ioctl(void)
{
	int i = 0, phy_idx = 0;
	int ret = ETH_SUCCESS;

	/* loop from last to first */
	for (i = MAX_INF_NUM - 1, phy_idx = 0;
		i  >= 0 && phy_idx >= 0 && phy_idx < MAX_EXT_PHY_PORT_NUM; i--) {

		if (os_strlen(inf[i].if_name) == 0)
			continue;

		/* phy port index in 1905 start from 5 */
		inf[i].port_index = phy_idx + BASE_PHY_PORT_INDEX;

		/* get real phy id */
		ret = get_phy_id(&inf[i]);
		if (ret != ETH_SUCCESS)
			return ret;

		phy_info[phy_idx].phy_id = inf[i].real_index;
		(void)get_inf_portno_on_bridge(&inf[i]);
		if (inf[i].port_no)
			inf[i].valid = 1;

		(void)bridge_set_externel_phy_info(phy_idx, inf[i].real_index);

		phy_idx += 1;
	}

	return ETH_SUCCESS;
}


void init_phy_by_ext_phy_port(void)
{
	int i = 0, phy_idx = 0;

	/* loop from last to first */
	for (i = MAX_INF_NUM - 1, phy_idx = 0;
		i  >= 0 && phy_idx >= 0 && phy_idx < MAX_EXT_PHY_PORT_NUM; i--) {
		if (os_strlen(inf[i].if_name) == 0)
			continue;

		/* phy port index in 1905 start from 5 */
		inf[i].port_index = phy_idx + BASE_PHY_PORT_INDEX;
		/* get real phy id from ext_phy_port */
		inf[i].real_index = phy_info[phy_idx].phy_id;

		(void)get_inf_portno_on_bridge(&inf[i]);
		if (inf[i].port_no)
			inf[i].valid = 1;

		(void)bridge_set_externel_phy_info(phy_idx, phy_info[phy_idx].phy_id);

		phy_idx += 1;
	}
}


int bridge_init(void)
{
	int ret = ETH_SUCCESS;
	int i = 0, phy_idx = 0;

	os_memset(inf, 0, sizeof(inf));
	for (i = 0; i < MAX_EXT_PHY_PORT_NUM; i++) {
		phy_info[i].phy_id = 0xff;
		phy_info[i].cl45 = 0;
	}

	read_config_file(dsa_cfg_file);
	sk_fd = sockets_open();
	if (sk_fd < 0) {
		err(DEBUG_CAT_INIT, "sockets open failure, errno %d(%s)\n", errno, strerror(errno));
		ret = ETH_ERROR_FAIL;
		goto fail;
	}

	sk_fd_ext_phy = socket(AF_INET, SOCK_DGRAM, 0);
	if (sk_fd_ext_phy < 0) {
		err(DEBUG_CAT_INIT, "fail to create socket for mii_mgr, errno %d(%s)\n", errno, strerror(errno));
		ret = ETH_ERROR_FAIL;
		goto fail;
	}

#ifndef RDKB_SUPPORT
	/* get phy id by socket first */
	ret = init_phy_by_ioctl();

	/*
	 * get phy id from ext_phy_port in /etc/ethernet_cfg.txt
	 * once fail to get phy id by socket(SIOCGMIIPHY)
	 */
	if (ret != ETH_SUCCESS)
#endif
		init_phy_by_ext_phy_port();

	notice(DEBUG_CAT_INIT, "external phy info:\n");
	for (i = MAX_INF_NUM - 1, phy_idx = 0;
		i  >= 0 && phy_idx >= 0 && phy_idx < MAX_EXT_PHY_PORT_NUM; i--) {
		if (os_strlen(inf[i].if_name) == 0)
			continue;
		notice(DEBUG_CAT_INIT,
			"intf name %s, port idx %d, real idx %d, bridge port %d, cl45 %d\n",
			inf[i].if_name, inf[i].port_index, inf[i].real_index, inf[i].port_no,
			phy_info[phy_idx].cl45);

		phy_idx += 1;
	}

	if (br_init()) {
		err(DEBUG_CAT_INIT, "sockets open failure, errno %d(%s)\n", errno, strerror(errno));
		ret = ETH_ERROR_FAIL;
	}

	return ret;
fail:
	if (sk_fd > 0)
		close(sk_fd);
	if (sk_fd_ext_phy > 0)
		close(sk_fd_ext_phy);
	return ret;
}

int get_port_type(OUT unsigned int *lport_map, OUT unsigned int *wport_map)
{
	int ret = ETH_SUCCESS;

	*lport_map = 0x0000000F;
	*wport_map = 0x00000010;

	return ret;
}

struct dsa_inf *get_dsa_inf_by_portno(unsigned int portno)
{
	int i = 0;

	for (i = 0; i < MAX_INF_NUM; i++) {
		if (!inf[i].valid)
			continue;

		if (inf[i].port_no == portno)
			return &inf[i];
	}

	return NULL;
}

struct fdb_entry *get_all_fdb_entry(OUT int *num)
{
#define CHUNK 128
	struct fdb_entry *fdb = NULL;
	int offset = 0, n = 0;

	for (;;) {
		struct fdb_entry *fdb_tmp;

		fdb_tmp = os_realloc(fdb, (offset + CHUNK) * sizeof(struct fdb_entry));

		if (!fdb_tmp) {
			warn(DEBUG_CAT_INIT, "Out of memory\n");
			os_free(fdb);
			return NULL;
		}

		fdb = fdb_tmp;
		if (offset == 0)
			os_memset(fdb, 0, CHUNK * sizeof(struct fdb_entry));
		else if (offset > 0)
			os_memset(fdb + CHUNK + offset - n, 0, n * sizeof(struct fdb_entry));
		n = br_read_fdb(br_lan, fdb+offset, offset, CHUNK);
		if (n == 0)
			break;

		if (n < 0) {
			warn(DEBUG_CAT_INIT, "read of forward table failed: %s\n",
				strerror(errno));
			os_free(fdb);
			return NULL;
		}

		offset += n;
	}

	*num = offset;
	return fdb;
}


struct ethernet_client_entry *get_existed_entry(struct dl_list *entry_list, unsigned char *mac)
{
	struct ethernet_client_entry *entry = NULL;

	dl_list_for_each(entry, entry_list, struct ethernet_client_entry, entry) {
		if (os_memcmp(entry->mac, mac, ETH_ALEN) == 0)
			return entry;
	}

	return NULL;
}


int bridge_get_table_entry(OUT struct dl_list *entry_list)
{
#define CHUNK 128
	int ret = ETH_SUCCESS, i = 0;
	struct ethernet_client_entry *entry = NULL;
	struct fdb_entry *fdb = NULL;
	int offset = 0;
	struct dsa_inf *pinf = NULL;

	/*dl_list_init(entry_list);*/

	fdb = get_all_fdb_entry(&offset);
	for (i = 0; i < offset; i++) {
		const struct fdb_entry *f = fdb + i;

		if (f->is_local)
			continue;

		pinf = get_dsa_inf_by_portno(f->port_no);
		if (!pinf)
			continue;

		entry = get_existed_entry(entry_list, (unsigned char *)f->mac_addr);
		if (!entry) {
			entry = (struct ethernet_client_entry *) os_zalloc(sizeof(struct ethernet_client_entry));
			if (!entry)
				continue;

			entry->port_index = pinf->port_index;
			os_memcpy(entry->mac, f->mac_addr, ETH_ALEN);
			entry->age = 150 - f->ageing_timer_value.tv_sec / 2;
			dl_list_add(entry_list, &entry->entry);
		}
	}

	if (fdb)
		os_free(fdb);

	return ret;
}

int bridge_search_table(IN unsigned char *mac, OUT struct ethernet_client_entry *entry)
{
	int i = 0;
	struct fdb_entry *fdb = NULL;
	int offset = 0;
	struct dsa_inf *pinf = NULL;

	fdb = get_all_fdb_entry(&offset);
	for (i = 0; i < offset; i++) {
		const struct fdb_entry *f = fdb + i;

		if (!os_memcmp(mac, f->mac_addr, ETH_ALEN)) {
			pinf = get_dsa_inf_by_portno(f->port_no);
			if (pinf) {
				entry->port_index = pinf->port_index;
				os_memcpy(entry->mac, f->mac_addr, ETH_ALEN);
				entry->age = 150 - f->ageing_timer_value.tv_sec / 2;
				os_free(fdb);
				return ETH_SUCCESS;
			}
		}
	}

	os_free(fdb);

	return ETH_ERROR_FAIL;
}


static void fill_mtk_mii_ioctl(
	struct mtk_mii_ioctl_data *mtk_mii, unsigned short phy_id,
	unsigned short reg_num, unsigned int *val)
{
	mtk_mii->phy_id  = phy_id;
	mtk_mii->reg_num = reg_num;
	mtk_mii->val_in  = *val;
	mtk_mii->val_out = 0;
}

static int get_phy_status_by_index(
	unsigned short index,
	unsigned int reg_num,
	unsigned int *val,

	unsigned short cmd)
{
	struct ifreq ifr;
	struct mtk_mii_ioctl_data mtk_mii;
	int err;

	strncpy(ifr.ifr_name, "eth0", sizeof(ifr.ifr_name));

	fill_mtk_mii_ioctl(&mtk_mii, index, reg_num, val);
	ifr.ifr_data = (char *)&mtk_mii;

	err = ioctl(sk_fd_ext_phy, cmd, &ifr);
	if (err)
		return -1;

	*val = (mtk_mii.val_out & 0x00000004) ? 1 : 0;
	return 0;
}

int _get_ae_wan_status(void)
{
	char line[STR_LEN_S] = {0};
	FILE *stream = NULL;
	int read_ret = 0;

	memset(line, 0, sizeof(line));
	(void)os_snprintf(line, STR_LEN_S, "cat /proc/tc3162/en8811_link_st");

	stream = popen(line, "r");
	if (stream == NULL) {
		warn(DEBUG_CAT_INIT, "popen fail command, error %d(%s)\n", errno, strerror(errno));
		return -1;
	}
	memset(line, 0, sizeof(line));

	read_ret = fread(line, sizeof(char), sizeof(line), stream);
	line[STR_LEN_S-1] = 0;/*null terminated*/
	if (read_ret && strstr(line, "Down")) {
		(void)pclose(stream);
		return 0;
	}

	(void)pclose(stream);
	return 1;
}

int _get_ae_wan_speed(void)
{
	char line[STR_LEN_S] = {0};
	FILE *stream = NULL;
	int read_ret = 0, ret = 0;

	memset(line, 0, sizeof(line));
	(void)os_snprintf(line, STR_LEN_S, "cat /proc/tc3162/en8811_link_st");

	stream = popen(line, "r");
	if (stream == NULL) {
		warn(DEBUG_CAT_INIT, "popen fail command, error %d(%s)\n", errno, strerror(errno));
		return -1;
	}
	memset(line, 0, sizeof(line));

	read_ret = fread(line, sizeof(char), sizeof(line), stream);
	line[STR_LEN_S-1] = 0;/*null terminated*/
	if (read_ret && strstr(line, "2.5Gbps/Full"))
		ret = 2500;
	else if (read_ret && strstr(line, "1000Mbps/Full"))
		ret = 1000;
	else if (read_ret && strstr(line, "100Mbps/Full"))
		ret = 100;
	else
		ret = 0;

	(void)pclose(stream);
	return ret;
}

int bridge_get_port_status(IN unsigned char index, OUT int *status)
{
	int ret = ETH_SUCCESS, i = 0;
	struct ifreq ifr;
	unsigned int tmp_stat = 0;

	if (!access("/sys/class/net/ae_wan", 0)) {
		*status =  _get_ae_wan_status();
		return 0;
	}

	if (sk_fd <= 0)
		return ETH_ERROR_FAIL;

	for (i = 0; i < MAX_INF_NUM; i++) {
		if (inf[i].valid && inf[i].real_index == index) {
			os_memset(&ifr, 0, sizeof(ifr));
			os_strncpy(ifr.ifr_name, inf[i].if_name, os_strlen(inf[i].if_name));
			ifr.ifr_name[IFNAMSIZ - 1] = '\0';
			if (ioctl(sk_fd, SIOCGIFFLAGS, &ifr) < 0) {
				warn(DEBUG_CAT_INIT, "ioctl error %d(%s) on %s\n", errno, strerror(errno), ifr.ifr_name);
				return ETH_ERROR_FAIL;
			}
			if (ifr.ifr_flags & IFF_RUNNING)
				*status = 1;
			else
				*status = 0;

			break;
		}
	}
	for (i = 0; i < MAX_EXT_PHY_PORT_NUM; i++) {
		if (phy_info[i].phy_id == index) {
			ret = get_phy_status_by_index(index, REG_NUM, &tmp_stat, MTKETH_MII_READ);
			if (!ret)
				*status = (int)tmp_stat;
			break;
		}
	}

	return ret;
}

int bridge_get_wan_speed(IN unsigned char index)
{
	char line[STR_LEN_S] = {0};
	FILE *stream = NULL;
	int read_ret = 0;
	int i = 0;
	int flag = 0;

	for (i = 0; i < MAX_INF_NUM; i++) {
		if (inf[i].valid && inf[i].port_index == index) {
			flag = 1;
			break;
		}
	}
	if (!flag)
		return 0;

	if (!access("/sys/class/net/ae_wan", 0))
		return _get_ae_wan_speed();

	memset(line, 0, sizeof(line));
	(void)os_snprintf(line, STR_LEN_S, "ethtool %s |grep Speed", inf[i].if_name);

	stream = popen(line, "r");
	if (stream == NULL) {
		warn(DEBUG_CAT_INIT, "popen fail command, error %d(%s)\n", errno, strerror(errno));
		return -1;
	}
	memset(line, 0, sizeof(line));

	read_ret = fread(line, sizeof(char), sizeof(line), stream);
	line[STR_LEN_S-1] = 0;/*null terminated*/
	if (read_ret && strstr(line, "10000"))
		read_ret = 10000;
	else if (read_ret && strstr(line, "2500"))
		read_ret = 2500;
	else if (read_ret && strstr(line, "1000"))
		read_ret = 1000;
	else if (read_ret && strstr(line, "100"))
		read_ret = 100;
	else
		;
	(void)pclose(stream);

	return read_ret;
}

int bridge_clear_table(void)
{
#define CLEAR_BRIDGE_FDB_SCRIPT "/tmp/clear_bridge_fdb_script.sh"
	int ret = ETH_SUCCESS;
	int i = 0;
	char cmd[1024] = {0};
	int res = 0;
	FILE *f = NULL;

	for (i = 0; i < MAX_INF_NUM; i++) {
		if (!inf[i].valid)
			continue;

		debug(DEBUG_CAT_INIT, "[%d], i = %d, inf[i].if_name = %s\n", __LINE__, i, inf[i].if_name);

		memset(cmd, 0, sizeof(cmd));
		res = snprintf(cmd, sizeof(cmd), "bridge fdb show dev %s"
			" | while read mac master br_name; do echo $mac; "
			"bridge fdb delete $mac dev %s master; done;", inf[i].if_name, inf[i].if_name);
		if (os_snprintf_error(sizeof(cmd), res))
			warn(DEBUG_CAT_INIT, "snprintf fail!\n");

		/* mode: w, overwriting each time */
		f = fopen(CLEAR_BRIDGE_FDB_SCRIPT, "w");
		if (f == NULL) {
			warn(DEBUG_CAT_INIT, "open file %s fail, errno %d(%s)\n", CLEAR_BRIDGE_FDB_SCRIPT,
				errno, strerror(errno));
			return -1;
		}

		ret = fputs(cmd, f);
		if (ret == -1)
			warn(DEBUG_CAT_INIT, "error fputs, errno %d(%s)\n", errno, strerror(errno));
		ret = fflush(f);
		if (ret == -1)
			warn(DEBUG_CAT_INIT, "error fflush, errno %d(%s)\n", errno, strerror(errno));

		/* run shell by execl */
		ret = execl_sh(CLEAR_BRIDGE_FDB_SCRIPT);
		if (ret == -1)
			warn(DEBUG_CAT_INIT, "error execl \"sh\" %s\n", CLEAR_BRIDGE_FDB_SCRIPT);
		ret = fclose(f);
		if (ret == -1)
			warn(DEBUG_CAT_INIT, "error fclose %s\n", CLEAR_BRIDGE_FDB_SCRIPT);
		ret = remove(CLEAR_BRIDGE_FDB_SCRIPT);
		if (ret == -1)
			warn(DEBUG_CAT_INIT, "error remove %s\n", CLEAR_BRIDGE_FDB_SCRIPT);
	}

	ret = ETH_SUCCESS;
	return ret;
}

int switch_bridge_add_intf(const char *bridge, const char *ifname)
{
	return br_add_interface(bridge, ifname);
}

int switch_bridge_del_intf(const char *bridge, const char *ifname)
{
	return br_del_interface(bridge, ifname);
}

int deinit(void)
{
	close(sk_fd);
	close(sk_fd_ext_phy);
	br_shutdown();

	return ETH_SUCCESS;
}
