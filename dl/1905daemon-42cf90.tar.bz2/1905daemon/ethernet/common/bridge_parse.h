/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

/*
 * bridge_parse.h: reserve for parse bridge layer
 *
 * Author: Sirui Zhao <Sirui.Zhao@mediatek.com>
 */
#ifndef _BRIDGE_PARSE_H
#define _BRIDGE_PARSE_H

#define MAX_INF_NUM	16
#define MAX_EXT_PHY_PORT_NUM 2
#define BASE_PHY_PORT_INDEX 5
#define MTKETH_MII_READ 0x89F3
#define REG_NUM	1
#define STR_LEN_S 128
#define MAX_PHY_NUM 10
#define SIOCGMIIPHY 0x8947

struct dsa_inf {
	char if_name[IFNAMSIZ];
	unsigned int port_no;
	unsigned char port_index;
	unsigned char real_index;
	unsigned char valid;
	int sock;
};

struct externel_phy_info {
	int phy_id;
	int cl45;
};


struct mtk_mii_ioctl_data {
	unsigned short phy_id;
	unsigned short reg_num;
	unsigned int val_in;
	unsigned int val_out;
};


#define IN
#define OUT

extern char br_lan[IFNAMSIZ];
extern char *dsa_cfg_file;


extern struct dsa_inf inf[MAX_INF_NUM];
extern struct externel_phy_info phy_info[MAX_EXT_PHY_PORT_NUM];
extern int sk_fd;
extern int sk_fd_ext_phy;


int bridge_init(void);
int bridge_get_port_status(IN unsigned char index, OUT int *status);
int bridge_get_wan_speed(IN unsigned char index);
int bridge_get_table_entry(OUT struct dl_list *entry_list);
int bridge_clear_table(void);
int bridge_search_table(IN unsigned char *mac, OUT struct ethernet_client_entry *entry);
int bridge_get_phy_id(int index, int *phy, int *cl45);
int read_config_file(char *file_path);
int sockets_open(void);
unsigned int get_inf_portno_on_bridge(struct dsa_inf *interface);
int bridge_set_externel_phy_info(unsigned char index, int phy_id);




#endif
