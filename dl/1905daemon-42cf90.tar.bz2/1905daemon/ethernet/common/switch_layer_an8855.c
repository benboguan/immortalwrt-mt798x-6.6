/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *
 * switch_layer.c: switch layer for MAP
 * Author: Sirui Zhao <Sirui.Zhao@mediatek.com>
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <linux/if.h>
#include <pthread.h>
#include <stdbool.h>

#include "ethernet_layer.h"
#include "debug.h"
#include "netlink_event.h"

#include "common.h"
#include "switch_nl.h"
#include "switch_legacy_ioctl.h"
#include "switch_layer.h"
#include "switch_layer_an8855.h"
#include "bridge_parse.h"

int an8855_block_port_bitmap;

int phy_cl22_read(unsigned int port_num, unsigned int phy_reg, int *value)
{
	int ret = 0;
	struct switch_attr attr;

	memset(&attr, 0, sizeof(attr));
	attr.dev_id = -1;
	attr.port_num = -1;
	attr.phy_dev = -1;

	if (nl_init_flag == true)
		ret = netlink_cl22_read_phy(&attr, port_num, phy_reg, value);
	else
		ret = mii_cl22_read_phy(port_num, phy_reg, value);
	if (ret < 0)
		warn(DEBUG_CAT_ETH, "phy cl22 read fail\n");

	return ret;
}

int an8855_netlink_init(void)
{
	notice(DEBUG_CAT_INIT, "regiester AN8855 Netlink\n");
	/* netlink init need chip(AN8855) name */
	if (switch_netlink_init(AN8855_GENL_NAME, AN8855_DSA_GENL_NAME)) {
		nl_init_flag = false;
		err(DEBUG_CAT_INIT, "switch layer init fail\n");
		return -1;
	}

	return 0;
}



static int an8855_check_l2_busy(void)
{
	int value = 0;
	int i = 0;

	for (i = 0 ; i < AN8855_SWITCH_BUSY_TIME ; i++) {
		(void)switch_reg_read(AN8855_REG_ESW_WT_MAC_ATC, &value);
		debug(DEBUG_CAT_ETH, "AN8855_REG_ESW_WT_MAC_ATC is 0x%x\n\r", value);
		if ((value & 0x80000000) == 0)
			break;

		usleep(1000);
	}
	if (i >= AN8855_SWITCH_BUSY_TIME)
		return -1;

	return 0;
}


int an8855_get_switch_mode(unsigned int *mode)
{
	int value = 0;

	(void)switch_reg_read(0x10208a10, &value);
	debug(DEBUG_CAT_ETH, "switch_reg_read 0x10208a10 0x%04x\n", value);
	*mode = (value & 0x20);

	debug(DEBUG_CAT_ETH, "switch mode 0x%0x\n", *mode);

	return 0;
}


int an8855_get_port_status(unsigned char port, int *status)
{
	int value = 0;

	if (port < 5) {
		(void)switch_reg_read(PMSR(port), &value);
		*status = (value & 0x01000000) ? 1 : 0;
	}

	return 0;
}


int an8855_get_port_speed(unsigned char port, int *speed)
{
	int value = 0;
	int reg_speed = 0;
	int status = 0;
	int ret = 0;

	ret = an8855_get_port_status(port, &status);
	if ((ret == 0) && (!status)) {
		*speed = 0;
		return 0;
	}

	(void)switch_reg_read(PMSR(port), &value);
	reg_speed = (value >> 28) & 0x3;

	switch (reg_speed) {
	case 0:
		*speed = 10;
		break;
	case 1:
		*speed = 100;
		break;
	case 2:
		*speed = 1000;
		break;
	case 3:
		*speed = 2500;
		break;
	default:
		warn(DEBUG_CAT_ETH, "phy speed status error\n");
		return -1;
	}
	return 0;
}

int an8855_get_phy_speed(unsigned char port)
{
	int value = 0, value1 = 0;
	int ret = 0;
	int speed = 0;

	ret = phy_cl22_read(port, 0xa, &value);
	if (ret < 0) {
		warn(DEBUG_CAT_ETH, "read phy error\n");
		return -1;
	}

	ret = phy_cl22_read(port, 0x5, &value1);
	if (ret < 0) {
		warn(DEBUG_CAT_ETH, "read phy error\n");
		return -1;
	}

	if ((value & 0x400) || (value & 0x800))
		speed = 1000;
	else if ((value1 & 0x200) || (value1 & 0x100) || (value1 & 0x80))
		speed = 100;
	else if ((value1 & 0x40) || (value1 & 0x20))
		speed = 10;
	else
		speed = 0;

	return speed;
}

int an8855_defalut_setting(void)
{
	int value = 0;

	(void)switch_reg_read(0x10200010, &value);
	if (arl.cpu_port[0] == 5) {
		value |= ((arl.cpu_port[0]) << 8);
		value |= (1 << 15);
		(void)switch_reg_write(0x10200010, value);
	} else {
		warn(DEBUG_CAT_ETH, "invalid cpu port(%d)\n", arl.cpu_port[0]);
		return -1;
	}

	(void)switch_reg_write(0x10200034, 0x40864086);
	(void)switch_reg_write(0x1020002c, 0x40864080);
	(void)switch_reg_write(0x1020000c, 0x1E0F1819);

	return 0;
}


int an8855_set_port_block(unsigned char port, int enable)
{
	int ret = 0;
	int length = 0;
	char cmd[128] = {0};

	if (port > 4)
		return -1;

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd),
		"switch an8855 acl set portEn %d %d", port, enable);
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);
	notice(DEBUG_CAT_ETH, "cmd:%s\n", cmd);

	if (enable) {
		an8855_block_port_bitmap |= (1<<(4*port));
		notice(DEBUG_CAT_ETH, "an8855_block_port_bitmap:%08x\n", an8855_block_port_bitmap);

		os_memset(cmd, 0, sizeof(cmd));
		length = snprintf(cmd, sizeof(cmd),
			"switch an8855 acl set rule 3 1 0 1 %08x 2 0", an8855_block_port_bitmap);
		if (os_snprintf_error(sizeof(cmd), length))
			debug(DEBUG_CAT_ETH, "snprintf fail!\n");
		(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);
		notice(DEBUG_CAT_ETH, "cmd:%s\n", cmd);

		os_memset(cmd, 0, sizeof(cmd));
		length = snprintf(cmd, sizeof(cmd),
			"switch an8855 acl set action 3 forward 7");
		if (os_snprintf_error(sizeof(cmd), length))
			debug(DEBUG_CAT_ETH, "snprintf fail!\n");
		(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);
		notice(DEBUG_CAT_ETH, "cmd:%s\n", cmd);
	} else {
		if (an8855_block_port_bitmap & (1<<(4*port)))
			an8855_block_port_bitmap ^= (1<<(4*port));
		notice(DEBUG_CAT_ETH, "an8855_block_port_bitmap:%08x\n", an8855_block_port_bitmap);

		if (!an8855_block_port_bitmap) {
			os_memset(cmd, 0, sizeof(cmd));
			length = snprintf(cmd, sizeof(cmd),
				"switch an8855 acl del rule 3");
			if (os_snprintf_error(sizeof(cmd), length))
				debug(DEBUG_CAT_ETH, "snprintf fail!\n");
			(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);
			notice(DEBUG_CAT_ETH, "cmd:%s\n", cmd);

			os_memset(cmd, 0, sizeof(cmd));
			length = snprintf(cmd, sizeof(cmd),
				"switch an8855 acl del action 3");
			if (os_snprintf_error(sizeof(cmd), length))
				debug(DEBUG_CAT_ETH, "snprintf fail!\n");
			(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);
			notice(DEBUG_CAT_ETH, "cmd:%s\n", cmd);
		}
	}

	return ret;
}

void an8855_acl_enable(void)
{
	char cmd[128] = {0};
	int length = 0;

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd), "switch an8855 acl set en 1");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");

	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);
	notice(DEBUG_CAT_ETH, "cmd:%s\n", cmd);
}

int an8855_set_wan_rule(void)
{
	char cmd[128] = {0};
	int length = 0;

	/* P0-P3 1905 relayed multicast forwarding to flooding */
	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd),
		"switch an8855 acl set rule 0 1 0 1 001111 0 dmac 0180c2000013 ffffffffffff udf 0001 0001");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd),
		"switch an8855 acl set action 0 redirect 0 001111");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd),
		"switch an8855 acl set udfRule 0 0 0040 0040 1 3 001111");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	return 0;
}

int an8855_set_lan_rule(unsigned char mac_addr[], void *data)
{
	char cmd[128] = {0};
	int length = 0;

	/* 1905 P0-3 --> P5 */
	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd),
		"switch an8855 acl set rule 0 1 0 1 001111 0 dmac 0180c2000013 ffffffffffff etype 893a ffff");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd),
		"switch an8855 acl set action 0 redirect 0 100000");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	/* 1905 al-mac P0-3 --> P5 */
	length = snprintf(cmd, sizeof(cmd),
		"switch an8855 acl set rule 1 1 0 1 001111 0 dmac %2x%2x%2x%2x%2x%2x ffffffffffff etype 893a ffff",
	mac_addr[0], mac_addr[1], mac_addr[2], mac_addr[3], mac_addr[4], mac_addr[5]);
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd),
		"switch an8855 acl set action 1 redirect 0 100000");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	/* 1905 broadcast P0-3 --> P5 */
	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd),
		"switch an8855 acl set rule 0 1 0 1 001111 0 dmac ffffffffffff ffffffffffff etype 893a ffff");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	os_memset(cmd, 0, sizeof(cmd));
	length = snprintf(cmd, sizeof(cmd),
		"switch an8855 acl set action 1 redirect 0 100000");
	if (os_snprintf_error(sizeof(cmd), length))
		debug(DEBUG_CAT_ETH, "snprintf fail!\n");
	(void)os_execute("/usr/sh", 3, "sh", "-c", cmd);

	return 0;
}

int an8855_port_find_by_mac(unsigned char *mac_addr, int vid, unsigned char *age)
{
	int value = 0;
	int i = 0, bank = 0, age_unit = 0, age_cnt = 0;
	int port_bitmap = 0;

	/* Fill ATA1 */
	value = 0;
	for (i = 0; i < 4; i++)
		value |= ((unsigned int)(mac_addr[i] & 0xff)) << ((3-i) * 8);

	(void)switch_reg_write(AN8855_REG_ESW_WT_MAC_ATA1, value);
	debug(DEBUG_CAT_ETH, "AN8855_REG_ESW_WT_MAC_ATA1 is 0x%x\n\r", value);

	value = 0;
	for (i = 4 ; i < 6 ; i++)
		value |= ((unsigned int)(mac_addr[i] & 0xff)) << ((7-i) * 8);

	(void)switch_reg_write(AN8855_REG_ESW_WT_MAC_ATA2, value);
	debug(DEBUG_CAT_ETH, "AN8855_REG_ESW_WT_MAC_ATA2 is 0x%x\n\r", value);

	/* Fill ATWD */
	value = 0;
	/* set valid bit */
	value |= 1;
	/* set IVL=1 */
	value |= (1 << 15);
	/* set VID */
	value |= (vid << 16);

	(void)switch_reg_write(AN8855_REG_ESW_WT_MAC_ATWD, value);
	debug(DEBUG_CAT_ETH, "AN8855_REG_ESW_WT_MAC_ATWD is 0x%x\n\r", value);
	usleep(1000);

	/* start search */
	value = 0x80000504;
	(void)switch_reg_write(AN8855_REG_ESW_WT_MAC_ATC, value);
	debug(DEBUG_CAT_ETH, "AN8855_REG_ESW_WT_MAC_ATC is 0x%x\n\r", value);
	if (an8855_check_l2_busy() != 0) {
		notice(DEBUG_CAT_ETH, "search timeout.\n");
		return -1;
	}
	(void)switch_reg_read(AN8855_REG_ESW_WT_MAC_ATC, &value);
	bank = (value >> AN8855_ATC_ENTRY_HIT_OFFSET) & AN8855_ATC_ENTRY_HIT_MASK;
	if (bank == 0) {
		debug(DEBUG_CAT_ETH, "entry not found\n");
		return -1;
	}
	for (i = 0 ; i < AN8855_L2_MAC_SET_NUM ; i++) {
		if (!!((bank >> i)&1)) {
			/* select bank */
			(void)switch_reg_write(AN8855_REG_ESW_MAC_ATRDS, i);

			/* Get the L2 MAC aging unit */
			(void)switch_reg_read(AN8855_REG_ESW_MAC_AAC, &value);
			age_unit = value & 0x7ff;
			/* Read MAC entry */
			(void)switch_reg_read(AN8855_REG_ESW_TABLE_ATRD1, &value);
			age_cnt = (value >> AN8855_ATRD1_MAC_AGETIME_OFFSET) & AN8855_ATRD1_MAC_AGETIME_MASK;
			*age = L2_AGING_TIME(age_cnt, age_unit);
			(void)switch_reg_read(AN8855_REG_ESW_TABLE_ATRD3, &value);
			port_bitmap = (value >> AN8855_ATRD3_MAC_PORT_OFFSET) & AN8855_ATRD3_MAC_PORT_LENGTH;
			break;
		}
	}

	return port_bitmap;
}

int an8855_port_find_by_mac_fid(unsigned char *mac_addr, int fid, unsigned char *age)
{
	int value = 0;
	int i = 0, j = 0, k = 0;
	unsigned int port_bitmap = 0, age_unit = 0, age_cnt = 0, bank = 0, addr = 0;
	unsigned char entry_mac[6] = {0};

	/* search the 1st MAC entry */
	value = 0x80000084;
	(void)switch_reg_write(AN8855_REG_ESW_WT_MAC_ATC, value);
	debug(DEBUG_CAT_ETH, "AN8855_REG_ESW_WT_MAC_ATC is 0x%x\n", value);
	if (an8855_check_l2_busy() != 0) {
		debug(DEBUG_CAT_ETH, "search timeout.\n");
		goto fail;
	}
	(void)switch_reg_read(AN8855_REG_ESW_WT_MAC_ATC, &value);
	addr = (value >> AN8855_ATC_ADDR_OFFSET) & AN8855_ATC_ADDR_MASK;
	bank = (value >> AN8855_ATC_ENTRY_HIT_OFFSET) & AN8855_ATC_ENTRY_HIT_MASK;
	debug(DEBUG_CAT_ETH, "AN8855_REG_ESW_WT_MAC_ATC is 0x%x, bank is %d, addr %d\n\r",
		value, bank, addr);
	if (bank == 0)
		goto fail;

	for (i = 0; i < AN8855_L2_MAC_SET_NUM; i++) {
		if (!!((bank >> i)&1)) {
			/* select bank */
			(void)switch_reg_write(AN8855_REG_ESW_MAC_ATRDS, i);

			/* Get the L2 MAC aging unit */
			(void)switch_reg_read(AN8855_REG_ESW_MAC_AAC, &value);
			age_unit = value & 0x7ff;
			/* Read MAC entry */
			(void)switch_reg_read(AN8855_REG_ESW_TABLE_ATRD3, &value);
			port_bitmap = (value >> AN8855_ATRD3_MAC_PORT_OFFSET) & AN8855_ATRD3_MAC_PORT_LENGTH;
			debug(DEBUG_CAT_ETH, "ATRD3 0x%x, port bit 0x%x\n", value, port_bitmap);
			for (k = 0; k < MAX_SWITCH_FRONT_PORT; k++) {
				if (port_bitmap & (0x1 << k))
					break;
			}
			if (k >= MAX_SWITCH_FRONT_PORT)
				break;

			debug(DEBUG_CAT_ETH, "port %d\n", k);

			if (k < MAX_SWITCH_FRONT_PORT) {
				(void)switch_reg_read(AN8855_REG_ESW_TABLE_ATRD1, &value);
				age_cnt = (value >> AN8855_ATRD1_MAC_AGETIME_OFFSET) & AN8855_ATRD1_MAC_AGETIME_MASK;

				*age = L2_AGING_TIME(age_cnt, age_unit);
				for (j = 4; j < 6; j++)
					entry_mac[j] = (value >> (7-j)*8) & 0xff;

				(void)switch_reg_read(AN8855_REG_ESW_TABLE_ATRD2, &value);
				for (j = 0; j < 4; j++)
					entry_mac[j] = (value >> (3-j)*8) & 0xff;

				if (!os_memcmp(mac_addr, entry_mac, 6)) {
					debug(DEBUG_CAT_ETH, "return port bit 0x%x\n", port_bitmap);
					goto suc;
				}
			}
		}
	}

	if (addr == AN8855_L2_MAX_ADDR_NUM-1) {
		debug(DEBUG_CAT_ETH, "goto suc\n\r");
		goto suc;
	}

	while (1) {
		value = 0x80000085;
		(void)switch_reg_write(AN8855_REG_ESW_WT_MAC_ATC, value);
		debug(DEBUG_CAT_ETH, "AN8855_REG_ESW_WT_MAC_ATC is 0x%x\n\r", value);
		if (an8855_check_l2_busy() != 0) {
			debug(DEBUG_CAT_ETH, "search timeout.\n");
			goto fail;
		}
		(void)switch_reg_read(AN8855_REG_ESW_WT_MAC_ATC, &value);
		bank = (value >> AN8855_ATC_ENTRY_HIT_OFFSET) & AN8855_ATC_ENTRY_HIT_MASK;
		addr = (value >> AN8855_ATC_ADDR_OFFSET) & AN8855_ATC_ADDR_MASK;
		debug(DEBUG_CAT_ETH, "AN8855_REG_ESW_WT_MAC_ATC is 0x%x, bank is %d, addr %d\n\r",
			value, bank, addr);
		if (bank == 0)
			goto fail;

		for (i = 0 ; i < AN8855_L2_MAC_SET_NUM ; i++) {
			if (!!((bank >> i)&1)) {
				/* select bank */
				(void)switch_reg_write(AN8855_REG_ESW_MAC_ATRDS, i);

				/* Get the L2 MAC aging unit */
				(void)switch_reg_read(AN8855_REG_ESW_MAC_AAC, &value);
				age_unit = value & 0x7ff;
				/* Read MAC entry */
				(void)switch_reg_read(AN8855_REG_ESW_TABLE_ATRD3, &value);
				port_bitmap = (value >> AN8855_ATRD3_MAC_PORT_OFFSET) & AN8855_ATRD3_MAC_PORT_LENGTH;
				debug(DEBUG_CAT_ETH, "ATRD3 0x%x, port bit 0x%x\n", value, port_bitmap);
				for (k = 0; k < MAX_SWITCH_FRONT_PORT; k++) {
					if (port_bitmap & (0x1 << k))
						break;
				}

				debug(DEBUG_CAT_ETH, "port %d\n", k);
				if (k >= MAX_SWITCH_FRONT_PORT)
					break;

				if (k < MAX_SWITCH_FRONT_PORT) {
					(void)switch_reg_read(AN8855_REG_ESW_TABLE_ATRD1, &value);
					age_cnt = (value >> AN8855_ATRD1_MAC_AGETIME_OFFSET) & AN8855_ATRD1_MAC_AGETIME_MASK;

					*age = L2_AGING_TIME(age_cnt, age_unit);
					for (j = 4; j < 6; j++)
						entry_mac[j] = (value >> (7-j)*8) & 0xff;

					(void)switch_reg_read(AN8855_REG_ESW_TABLE_ATRD2, &value);
					for (j = 0; j < 4; j++)
						entry_mac[j] = (value >> (3-j)*8) & 0xff;

					if (!os_memcmp(mac_addr, entry_mac, 6)) {
						debug(DEBUG_CAT_ETH, "return port bit 0x%x\n", port_bitmap);
						goto suc;
					}
				}
			}
		}

		if (addr == AN8855_L2_MAX_ADDR_NUM-1) {
			debug(DEBUG_CAT_ETH, "goto suc\n\r");
			goto suc;
		}
	}

fail:
	return -1;
suc:
	return port_bitmap;
}

int an8855_get_port_type(unsigned int *lport_map, unsigned int *wport_map)
{
	lan_port_bitmap = 0xf;
	wan_port_bitmap = 0x20;

	return 0;
}

int an8855_get_table_entry(struct dl_list *entry_list)
{
	int value = 0;
	int i = 0, j = 0, k = 0;
	struct ethernet_client_entry *entry = NULL;
	unsigned int port_bitmap = 0, age_unit = 0, age_cnt = 0, bank = 0, addr = 0;

	if (entry_list == NULL)
		return -1;

	dl_list_init(entry_list);

	/* switch disabled, got entry from bridge */
	if (!is_chip_valid())
		goto suc;

	/* search the 1st MAC entry */
	value = 0x80000084;
	(void)switch_reg_write(AN8855_REG_ESW_WT_MAC_ATC, value);
	debug(DEBUG_CAT_ETH, "AN8855_REG_ESW_WT_MAC_ATC is 0x%x\n", value);
	if (an8855_check_l2_busy() != 0) {
		notice(DEBUG_CAT_ETH, "search timeout.\n");
		goto fail;
	}
	(void)switch_reg_read(AN8855_REG_ESW_WT_MAC_ATC, &value);
	addr = (value >> AN8855_ATC_ADDR_OFFSET) & AN8855_ATC_ADDR_MASK;
	bank = (value >> AN8855_ATC_ENTRY_HIT_OFFSET) & AN8855_ATC_ENTRY_HIT_MASK;
	debug(DEBUG_CAT_ETH, "AN8855_REG_ESW_WT_MAC_ATC is 0x%x, bank is %d, addr %d\n\r", value, bank, addr);
	if (bank == 0) {
		debug(DEBUG_CAT_ETH, "goto suc\n\r");
		goto suc;
	}

	for (i = 0; i < AN8855_L2_MAC_SET_NUM; i++) {
		if (!!((bank >> i)&1)) {
			/* select bank */
			(void)switch_reg_write(AN8855_REG_ESW_MAC_ATRDS, i);

			/* Get the L2 MAC aging unit */
			(void)switch_reg_read(AN8855_REG_ESW_MAC_AAC, &value);
			age_unit = value & 0x7ff;
			/* Read MAC entry */
			(void)switch_reg_read(AN8855_REG_ESW_TABLE_ATRD3, &value);
			port_bitmap = (value >> AN8855_ATRD3_MAC_PORT_OFFSET) & AN8855_ATRD3_MAC_PORT_LENGTH;
			for (k = 0; k < MAX_SWITCH_FRONT_PORT; k++) {
				if (port_bitmap & (0x1 << k))
					break;
			}
			if (k >= MAX_SWITCH_FRONT_PORT)
				break;

			if (k < MAX_SWITCH_FRONT_PORT) {
				entry = switch_create_table_entry(k, 0, NULL, 0);
				if (entry == NULL) {
					warn(DEBUG_CAT_ETH, "allocate switch client entry fail\n");
					break;
				}

				(void)switch_reg_read(AN8855_REG_ESW_TABLE_ATRD1, &value);
				age_cnt = (value >> AN8855_ATRD1_MAC_AGETIME_OFFSET) & AN8855_ATRD1_MAC_AGETIME_MASK;

				entry->age = L2_AGING_TIME(age_cnt, age_unit);
				for (j = 4; j < 6; j++)
					entry->mac[j] = (value >> (7-j)*8) & 0xff;

				(void)switch_reg_read(AN8855_REG_ESW_TABLE_ATRD2, &value);
				for (j = 0; j < 4; j++)
					entry->mac[j] = (value >> (3-j)*8) & 0xff;

				dl_list_add(entry_list, &entry->entry);
			}
		}
	}

	if (addr == AN8855_L2_MAX_ADDR_NUM-1) {
		debug(DEBUG_CAT_ETH, "goto suc\n\r");
		goto suc;
	}


	while (1) {
		value = 0x80000085;
		(void)switch_reg_write(AN8855_REG_ESW_WT_MAC_ATC, value);
		debug(DEBUG_CAT_ETH, "AN8855_REG_ESW_WT_MAC_ATC is 0x%x\n\r", value);
		if (an8855_check_l2_busy() != 0) {
			notice(DEBUG_CAT_ETH, "search timeout.\n");
			goto fail;
		}
		(void)switch_reg_read(AN8855_REG_ESW_WT_MAC_ATC, &value);
		bank = (value >> AN8855_ATC_ENTRY_HIT_OFFSET) & AN8855_ATC_ENTRY_HIT_MASK;
		addr = (value >> AN8855_ATC_ADDR_OFFSET) & AN8855_ATC_ADDR_MASK;
		debug(DEBUG_CAT_ETH, "AN8855_REG_ESW_WT_MAC_ATC is 0x%x, bank is %d, addr %d\n\r", value, bank, addr);
		if (bank == 0) {
			debug(DEBUG_CAT_ETH, "goto suc\n\r");
			goto suc;
		}

		for (i = 0 ; i < AN8855_L2_MAC_SET_NUM ; i++) {
			if (!!((bank >> i)&1)) {
				/* select bank */
				(void)switch_reg_write(AN8855_REG_ESW_MAC_ATRDS, i);

				/* Get the L2 MAC aging unit */
				(void)switch_reg_read(AN8855_REG_ESW_MAC_AAC, &value);
				age_unit = value & 0x7ff;
				/* Read MAC entry */
				(void)switch_reg_read(AN8855_REG_ESW_TABLE_ATRD3, &value);
				port_bitmap = (value >> AN8855_ATRD3_MAC_PORT_OFFSET) & AN8855_ATRD3_MAC_PORT_LENGTH;
				for (k = 0; k < MAX_SWITCH_FRONT_PORT; k++) {
					if (port_bitmap & (0x1 << k))
						break;
				}
				if (k >= MAX_SWITCH_FRONT_PORT)
					break;

				if (k < MAX_SWITCH_FRONT_PORT) {
					entry = switch_create_table_entry(k, 0, NULL, 0);
					if (entry == NULL) {
						warn(DEBUG_CAT_ETH, "allocate switch client entry fail\n");
						break;
					}

					(void)switch_reg_read(AN8855_REG_ESW_TABLE_ATRD1, &value);
					age_cnt = (value >> AN8855_ATRD1_MAC_AGETIME_OFFSET) & AN8855_ATRD1_MAC_AGETIME_MASK;

					entry->age = L2_AGING_TIME(age_cnt, age_unit);
					for (j = 4; j < 6; j++)
						entry->mac[j] = (value >> (7-j)*8) & 0xff;

					(void)switch_reg_read(AN8855_REG_ESW_TABLE_ATRD2, &value);
					for (j = 0; j < 4; j++)
						entry->mac[j] = (value >> (3-j)*8) & 0xff;

					dl_list_add(entry_list, &entry->entry);
				}
			}
		}
		if (addr == AN8855_L2_MAX_ADDR_NUM-1) {
			debug(DEBUG_CAT_ETH, "goto suc\n\r");
			goto suc;
		}
	}

fail:
	warn(DEBUG_CAT_ETH, "######fail\n");
	switch_clear_entry_list(entry_list);
	return -1;
suc:
	bridge_get_table_entry(entry_list);
	return 0;
}



int an8855_clear_table(void)
{
	int ret = 0;
	unsigned int u32dat = 0;

	u32dat = 0x80000002;
	(void)switch_reg_write(AN8855_REG_ESW_WT_MAC_ATC, u32dat);
	if (an8855_check_l2_busy() != 0)
		return -1;

	ret = bridge_clear_table();

	return ret;
}

int an8855_clear_port_table(unsigned char port)
{
	if (port > 4)
		return 0;

	(void)switch_reg_write(AN8855_REG_ESW_WT_MAC_ATWD2, 1 << port);
	(void)switch_reg_write(AN8855_REG_ESW_WT_MAC_ATC, 0x80000602);

	return 0;
}

int an8855_vlan_set(unsigned short vid[], unsigned short vid_cnt, unsigned char active, enum vlan_type type)
{
	unsigned char ivl_en = 1;
	unsigned char fid = 0;
	unsigned short stag = 0;
	unsigned char portMap = 0;
	unsigned char tagPortMap = 0;
	struct switch_vlan_list *vlan_entry = NULL;
	struct switch_vlan_list *entry_temp = NULL;

	int value = 0;
	int value2 = 0;
	int reg = 0;
	int i;
	int max_port = 0;
	int vlan_vtcr = 0;


	vlan_vtcr = AN8855_REG_ESW_VLAN_VTCR;

	portMap = lan_port_bitmap;

	max_port = AN8855_SWITCH_MAX_PORT;


	if (e_transparent_vlan == type) {
		for (i = 0; i <= max_port; i++) {
			if (is_chip_an8855()) {
				if (wan_port_bitmap & BIT(i)) {
					/* but why wan port include 4,5 */
					portMap |= (0x01 << i);
				}
			} else {
				if ((wan_port_bitmap & BIT(i)) && (i < 5)) {
					/* but why wan port include 4,5 */
					portMap |= (0x01 << i);
				}
			}
		}
	}

	tagPortMap = portMap;

	if (!vid_cnt)
		active = 0;

	value = ((portMap & 0x3f) << 26);
	value2 |= (stag << 2);
	value |= (ivl_en << 5);
	value |= (fid << 1);
	value |= (active ? 1 : 0);

	for (i = 0; i < AN8855_SWITCH_MAX_PORT; i++) {
		if (tagPortMap & (1 << i))
			value |= 0x2 << ((i * 2)+12);
	}

	if (value & 0x3fff000)
		value |= (1 << 10); // eg_tag

	(void)switch_reg_write(AN8855_REG_ESW_VLAN_VLNWDATA1, value2);

	(void)switch_reg_write(AN8855_REG_ESW_VLAN_VLNWDATA0, value);

	/* vid_cnt != 0, activate or inactivate switch vlan table according to active flag*/
	if (vid_cnt) {
		for (i = 0; i < vid_cnt; i++) {
			reg = vlan_vtcr; // VTCR
			value = (0x80001000 + vid[i]);
			(void)switch_reg_write(reg, value);
			usleep(5000);

			vlan_entry = malloc(sizeof(struct switch_vlan_list));
			if (vlan_entry) {
				notice(DEBUG_CAT_ETH, "%s vlan id %d added\n",
					type == e_traffic_separation_vlan ?
					"traffic separation":"transparent vlan", vid[i]);
				dl_list_add_tail(&switch_vlan_head, &vlan_entry->entry);

				vlan_entry->vid = vid[i];
				vlan_entry->vid_type = type;
				vlan_entry->port_bitmap = portMap;
				vlan_entry->cpu_port = tagPortMap;
			} else {
				notice(DEBUG_CAT_ETH, "malloc vlan entry fail\n");
				return -1;
			}
		}

		/* cnt of any vlan type is bigger than 0, set to user mode */
		if (!ts_vlan_cnt && !transparent_vlan_cnt) {
			value = 0x91000000;
			notice(DEBUG_CAT_ETH, "2n10 set to user mode 0x%0x\n", value);
			for (i = 0; i < 7; i++) {
				reg = 0x10208010 + i * 0x200;
				(void)switch_reg_write(reg, value);
				usleep(5000);
			}
		}

		if (e_traffic_separation_vlan == type)
			ts_vlan_cnt = vid_cnt;
		else
			transparent_vlan_cnt = vid_cnt;

	}
	/* vid_cnt = 0, inactivate switch vlan talbe in switch */
	else {
		/* look up all the vlan entry from list and delete them */
		dl_list_for_each_safe(vlan_entry, entry_temp, &switch_vlan_head, struct switch_vlan_list, entry) {
			if (vlan_entry->vid_type == type) {
				/* disable vlan in switch first */
				/* VTCR */
				reg = vlan_vtcr;
				value = (0x80001000 + vlan_entry->vid);
				(void)switch_reg_write(reg, value);
				usleep(5000);

				notice(DEBUG_CAT_ETH, "%s vlan id %d removed\n",
					type == e_traffic_separation_vlan ?
					"traffic separation":"transparent vlan", vlan_entry->vid);

				/* rm entry from list */
				dl_list_del(&vlan_entry->entry);
				os_free(vlan_entry);
			}
		}

		if (e_traffic_separation_vlan == type)
			ts_vlan_cnt = 0;
		else
			transparent_vlan_cnt = 0;

		/* if cnt of each type of vlan is 0, reset to transparent mode as golden branch  */
		if (!ts_vlan_cnt && !transparent_vlan_cnt) {
			value = 0x910000c0;
			notice(DEBUG_CAT_ETH, "2n10 set to transparent mode 0x%0x\n", value);
			for (i = 0; i < 7; i++) {
				reg = 0x10208010 + i * 0x200;
				(void)switch_reg_write(reg, value);
				usleep(5000);
			}
		}
	}

	/* VTCR */
	reg = vlan_vtcr;
	while (1) {
		(void)switch_reg_read(reg, &value);

		if ((value & 0x80000000) == 0) {
			/* table busy */
			break;
		}
	}

	/* switch clear */
	reg = AN8855_REG_ESW_WT_MAC_ATC;
	(void)switch_reg_write(reg, 0x80000002);
	usleep(5000);
	(void)switch_reg_read(reg, &value);

	return 0;
}

int an8855_get_lan_wan_portmaps(int vid, unsigned int *port_map)
{
	int j = 0, value = 0;
	int vlan_vtcr = 0;

	vlan_vtcr = AN8855_REG_ESW_VLAN_VTCR;

	notice(DEBUG_CAT_ETH, "  vid  fid	portmap    s-tag\n");
	value = (0x80000000 + vid);  //r_vid_cmd
	(void)switch_reg_write(vlan_vtcr, value);

	for (j = 0; j < 20; j++) {
		(void)switch_reg_read(vlan_vtcr, &value);
		if ((value & 0x80000000) == 0) {
			//vlan table is busy
			break;
		}
		usleep(1000);
	}
	if (j == 20) {
		warn(DEBUG_CAT_ETH, "vlan dump timeout.\n");
		return -1;
	}

	(void)switch_reg_read(AN8855_REG_ESW_VLAN_VLNRDATA0, &value);

	if ((value & 0x01) != 0) {
		notice(DEBUG_CAT_ETH, " %4d  ", vid);
		notice(DEBUG_CAT_ETH, " %2d ", ((value & 0x1e) >> 1));
		notice(DEBUG_CAT_ETH, " %c", (value & 0x04000000) ? '1':'-');	//p0
		notice(DEBUG_CAT_ETH, "%c", (value & 0x08000000) ? '1':'-');	//p1
		notice(DEBUG_CAT_ETH, "%c", (value & 0x10000000) ? '1':'-');	//p2
		notice(DEBUG_CAT_ETH, "%c", (value & 0x20000000) ? '1':'-');	//p3
		notice(DEBUG_CAT_ETH, "%c", (value & 0x40000000) ? '1':'-');	//p4
		notice(DEBUG_CAT_ETH, "%c", (value & 0x80000000) ? '1':'-');	//p5

		for (j = 0; j < AN8855_SWITCH_MAX_PORT; j++) {
			if ((j + AN8855_BIT_OFFSET) < 32) {
				if (value & (BIT(j + AN8855_BIT_OFFSET)))
					*port_map |= (0x00000001 << j);
			}
		}
	} else	{
		/* print 16 vid for reference information */
		if (vid <= 16) {
			notice(DEBUG_CAT_ETH, " %4d  ", vid);
			notice(DEBUG_CAT_ETH, " %2d ", ((value & 0xe) >> 1));
			notice(DEBUG_CAT_ETH, " invalid\n");
		}
	}
	return 0;
}

void an8855_switch_deinit(void)
{
	int port = 0;

	notice(DEBUG_CAT_MISC, "\n");

	for (port = 0; port < MAX_SWITCH_FRONT_PORT; port++)
		an8855_set_port_block(port, 0);

	(void)switch_ioctl_deinit(NULL);
	if (nl_init_flag == true) {
		free(attres);
		attres = NULL;
		(void)switch_nl_deinit();
	}
	if (arl.lan_vid)
		os_free(arl.lan_vid);
	if (arl.wan_vid)
		os_free(arl.wan_vid);
	if (arl.cpu_port)
		os_free(arl.cpu_port);
}
