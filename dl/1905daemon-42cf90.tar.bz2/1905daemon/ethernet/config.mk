ifeq ($(CONFIG_RDKB_SUPPORT),y)
SDK_TYPE=rdkb
else
SDK_TYPE=openwrt
endif
