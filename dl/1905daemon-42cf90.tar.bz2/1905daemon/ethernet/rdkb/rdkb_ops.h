/* SPDX-License-Identifier: MediaTekProprietary*/
/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */
#ifndef __RDKB_ETH_H__
#define __RDKB_ETH_H__

struct eth_ops switch_layer_ops;


int switch_layer_init(void);
void switch_layer_acl_enable(void);
int switch_layer_set_lan_rule(unsigned char *mac, void *data);
int switch_layer_set_wan_rule(void);

int switch_layer_get_switch_mode(unsigned int *mode);
int switch_layer_get_port_type(unsigned int *lport_map, unsigned int *wport_map);
#if defined(CONFIG_RALINK_MT7628)
	int switch_layer_get_7628_table_entry(struct dl_list *entry_list);
#else
	int switch_layer_get_table_entry(struct dl_list *entry_list);
#endif
int switch_layer_table_search(unsigned char *mac, struct ethernet_client_entry *entry);
int switch_layer_get_port_status(unsigned char index, int *status);
int switch_layer_get_port_speed(unsigned char port, int *speed);
int switch_layer_set_port_block(unsigned char port, int enable);
int switch_ts_vlan_set(unsigned short vid[], unsigned short vid_cnt, unsigned char active);
int switch_transparent_vlan_set(unsigned short vid[], unsigned short vid_cnt, unsigned char active);
int switch_layer_clear_table(void);
int switch_layer_clear_port_table(unsigned char port);
int switch_layer_deinit(void);
int switch_bridge_add_intf(const char *bridge, const char *ifname);
int switch_bridge_del_intf(const char *bridge, const char *ifname);
#endif /*__RDKB_ETH_H__*/
