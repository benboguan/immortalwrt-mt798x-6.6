// SPDX-License-Identifier: MediaTekProprietary
/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *
 * switch_layer.c: switch layer for MAP
 * Author: Sirui Zhao <Sirui.Zhao@mediatek.com>
 */


#include <stdio.h>
#include <string.h>
#include <syslog.h>
#include "debug.h"
#include "ccsp_hal_ethsw.h"
#include "common/switch_layer.h"

#include "ethernet_layer.h"
#include "rdkb_ops.h"
#include "common.h"

static int rdkb_eth_init(void)
{
	int ret = 0;

	ret = switch_layer_init();
	if (ret < 0) {
		warn(DEBUG_CAT_ETH, "switch_layer_init fail\n");
		return -1;
	}
	ret = CcspHalEthSwInit();
	if (ret < 0) {
		warn(DEBUG_CAT_ETH, "CcspHalEthSwInit fail\n");
		return -1;
	}
	return 0;
}
static int get_rdkb_port_id_by_mac(unsigned char *mac, unsigned char *port_id)
{
	int ret = 0;
	int port = 0;

	if (mac == NULL) {
		warn(DEBUG_CAT_ETH, "error:mac is null\n");
		return -1;
	}
	ret = CcspHalEthSwLocatePortByMacAddress(mac, &port);
	*port_id = port;
	if (ret < 0) {
		warn(DEBUG_CAT_ETH, "CcspHalEthSwLocatePortByMacAddress fail\n");
		*port_id = 0;
		return -1;
	}
	return 0;
}

static int get_rdkb_eth_port_stat(unsigned char port_id, struct port_stat *port_stats)
{
	CCSP_HAL_ETH_STATS stats;
	CCSP_HAL_ETHSW_PORT port_index = port_id;
	int ret = 0;

	if (port_stats == NULL) {
		warn(DEBUG_CAT_ETH, "error:port_stats is NULL\n");
		return -1;
	}
	ret = CcspHalEthSwGetEthPortStats(port_index, &stats);
	if (ret < 0) {
		warn(DEBUG_CAT_ETH, "CcspHalEthSwGetEthPortStats fail\n");
		return -1;
	}
	port_stats->bytes_received = stats.BytesReceived;
	port_stats->bytes_sent = stats.BytesSent;
	port_stats->packets_received = stats.PacketsReceived;
	port_stats->packets_sent = stats.PacketsSent;
	port_stats->errors_received = stats.ErrorsReceived;
	port_stats->errors_sent = stats.ErrorsSent;
	return 0;
}
static int get_rdkb_port_admin_status(unsigned char port_id, int *status)
{
	CCSP_HAL_ETHSW_ADMIN_STATUS port_status;
	int ret = 0;

	if (status == NULL) {
		warn(DEBUG_CAT_ETH, "error:port_stats is NULL\n");
		return -1;
	}
	ret = CcspHalEthSwGetPortAdminStatus((CCSP_HAL_ETHSW_PORT)port_id, &port_status);
	if (ret < 0) {
		warn(DEBUG_CAT_ETH, "CcspHalEthSwGetPortAdminStatus fail\n");
		return -1;
	}
	if (port_status == 0)
		*status = 1;
	else if (port_status == 1)
		*status = 0;
	else
		*status = 2;
	return 0;
}

static int get_rdkb_port_link_rate(unsigned char port_id, int *link_rate)
{
	CCSP_HAL_ETHSW_DUPLEX_MODE duplexmode;
	CCSP_HAL_ETHSW_LINK_STATUS status;
	CCSP_HAL_ETHSW_LINK_RATE rate;
	int ret = 0;

	if (link_rate == NULL) {
		warn(DEBUG_CAT_ETH, "error:link_rate is NULL\n");
		return -1;
	}
	ret = CcspHalEthSwGetPortStatus((CCSP_HAL_ETHSW_PORT)port_id, &rate, &duplexmode, &status);
	if (ret < 0) {
		warn(DEBUG_CAT_ETH, "CcspHalEthSwGetPortStatus fail\n");
		return -1;
	}
	*link_rate = rate;
	return 0;
}
static int get_rdkb_port_duplex_mode(unsigned char port_id, int *duplex_mode)
{
	CCSP_HAL_ETHSW_LINK_RATE link_rate;
	CCSP_HAL_ETHSW_LINK_STATUS status;
	CCSP_HAL_ETHSW_DUPLEX_MODE mode;
	int ret = 0;

	if (duplex_mode == NULL) {
		warn(DEBUG_CAT_ETH, "error:duplex_mode is NULL\n");
		return -1;
	}
	ret = CcspHalEthSwGetPortStatus((CCSP_HAL_ETHSW_PORT)port_id, &link_rate, &mode, &status);
	if (ret < 0) {
		warn(DEBUG_CAT_ETH, "CcspHalEthSwGetPortStatus fail\n");
		return -1;
	}
	*duplex_mode = mode;
	return 0;
}


struct eth_ops switch_layer_ops = {
	.init = rdkb_eth_init,
	.get_switch_mode = switch_layer_get_switch_mode,
	.get_port_type = switch_layer_get_port_type,
#if defined(CONFIG_RALINK_MT7628)
	.get_table_entry = switch_layer_get_7628_table_entry,
#else
	.get_table_entry = switch_layer_get_table_entry,
#endif
	.search_table = switch_layer_table_search,
	.get_port_status = switch_layer_get_port_status,
	.get_port_speed = switch_layer_get_port_speed,
	.set_port_block = switch_layer_set_port_block,
	.set_switch_ts_vlan = switch_ts_vlan_set,
	.set_switch_transparent_vlan = switch_transparent_vlan_set,
	.clear_table = switch_layer_clear_table,
	.clear_port_table = switch_layer_clear_port_table,
	.deinit = switch_layer_deinit,
	.get_port_id_by_mac = get_rdkb_port_id_by_mac,
	.get_port_statics = get_rdkb_eth_port_stat,
	.get_port_admin_status = get_rdkb_port_admin_status,
	.get_port_duplex_mode = get_rdkb_port_duplex_mode,
	.get_port_link_rate = get_rdkb_port_link_rate,
	.set_acl_enable = switch_layer_acl_enable,
	.set_lan_rule = switch_layer_set_lan_rule,
	.set_wan_rule = switch_layer_set_wan_rule,
	.bridge_add_intf = switch_bridge_add_intf,
	.bridge_del_intf = switch_bridge_del_intf,
};
