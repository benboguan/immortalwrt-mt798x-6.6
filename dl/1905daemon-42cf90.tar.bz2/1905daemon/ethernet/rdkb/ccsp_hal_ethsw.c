// SPDX-License-Identifier: MediaTekProprietary
/*
 * If not stated otherwise in this file or this component's LICENSE file the
 * following copyright and licenses apply:
 *
 * Copyright 2016 RDK Management
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**********************************************************************
 * File: ccsp_hal_ethsw.c

	For CCSP Component:  Ccsp Provisioning & Management

    ---------------------------------------------------------------

    description:

	This is the stub implementation of Ethernet Switch control.

    ---------------------------------------------------------------

    environment:

	platform dependent

    ---------------------------------------------------------------

    author:

	MeidaTek

**********************************************************************/

#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <stdbool.h>
#include <pthread.h>

#include <linux/sockios.h>
#include <linux/ethtool.h>

#include "ccsp_hal_ethsw.h"
#include "common/switch_layer.h"
#include "inc/os.h"

/**********************************************************************
 * CONSTANT DEFINITIONS
 **********************************************************************/

#define dbg_info(...) eth_dbg_info(__func__, ##__VA_ARGS__)

#define ETH_LAN_IFNAME "eth1"
#define ETH_LAN_IFNAME0 "lan0"
#define ETH_LAN_IFNAME1 "lan1"
#define ETH_LAN_IFNAME2 "lan2"
#define ETH_LAN_IFNAME3 "lan3"
#define ETH_LAN_IFNAME4 "lan4"
#define ETH_LAN_IFNAME5 "lan5"
#define ETH_LAN_IFNAME6 "lan6"

#define ETH_LAN_INTERFACE "brlan0"
#define ETH_WAN_IFNAME "erouter0"
#define ETH_WAN_INTERFACE "erouter0"

#define MAX_CMD_SIZE 128
#define MAX_BUF_SIZE 256

/* link event task */
#define ETH_POLL_TIME 5
#define ETH_INITIALIZE "/tmp/ethagent_initialized"

/* associate devices */
#define ETH_CONN_MAC "/tmp/connected_mac.txt"
#define ETH_CONN_WIFI "/tmp/connected_wifi_mac.txt"
#define ETH_CONN_ETH "/tmp/connected_eth_mac.txt"
#define ETH_ARP "/tmp/arp_cache"
#define ETH_REACH_ETH "/tmp/reachable_eth_mac.txt"

#define LM_ARP_ENTRY_FORMAT "%63s %63s %63s %63s %17s %63s"

/**********************************************************************
 * MAIN ROUTINES
 **********************************************************************/

typedef struct ethsw_port_s {
	CCSP_HAL_ETHSW_LINK_RATE linkRate;
	CCSP_HAL_ETHSW_DUPLEX_MODE duplexMode;
	CCSP_HAL_ETHSW_ADMIN_STATUS admin_status;
	int valid;
} ethsw_port_t;

typedef struct ethsw_db_s {
	int init_done;
	ethsw_port_t port[CCSP_HAL_ETHSW_PortMax];

	BOOLEAN wan_enable;
	UINT wan_port;

	pthread_t task;
	int prevLanLink;
	int prevWanLink;

	CcspHalExtSw_ethAssociatedDevice_callback associating_cb;
	appCallBack wan_cb;
#ifdef _HUB4_PRODUCT_REQ_
	ethsw_ethLinkEventCallback link_cb;
#endif

	int log_num;

} ethsw_db_t;

static ethsw_db_t ethsw_db = {0};

static const char *ethsw_ifname_str_gsw[] = {
	NULL,	    ETH_LAN_IFNAME, /* CCSP_HAL_ETHSW_EthPort1 */
	ETH_LAN_IFNAME,		    /* CCSP_HAL_ETHSW_EthPort2 */
	ETH_LAN_IFNAME,		    /* CCSP_HAL_ETHSW_EthPort3 */
	ETH_LAN_IFNAME,		    /* CCSP_HAL_ETHSW_EthPort4 */
	ETH_LAN_IFNAME,		    /* CCSP_HAL_ETHSW_EthPort5 */
	ETH_LAN_IFNAME,		    /* CCSP_HAL_ETHSW_EthPort6 */
	ETH_LAN_IFNAME,		    /* CCSP_HAL_ETHSW_EthPort7 */
	ETH_LAN_IFNAME,		    /* CCSP_HAL_ETHSW_EthPort8 */
	NULL,			    /* CCSP_HAL_ETHSW_Moca1 */
	NULL,			    /* CCSP_HAL_ETHSW_Moca2 */
	ETH_WAN_IFNAME,		    /* CCSP_HAL_ETHSW_Wlan1 */
	ETH_WAN_IFNAME,		    /* CCSP_HAL_ETHSW_Wlan2 */
	ETH_WAN_IFNAME,		    /* CCSP_HAL_ETHSW_Wlan3 */
	ETH_WAN_IFNAME,		    /* CCSP_HAL_ETHSW_Wlan4 */
	NULL,			    /* CCSP_HAL_ETHSW_Processor1 */
	NULL,			    /* CCSP_HAL_ETHSW_Processor2 */
	NULL,			    /* CCSP_HAL_ETHSW_InterconnectPort1 */
	NULL,			    /* CCSP_HAL_ETHSW_InterconnectPort2 */
	NULL,			    /* CCSP_HAL_ETHSW_MgmtPort */
};

static const char *ethsw_ifname_str_dsa[] = {
	NULL,	    ETH_LAN_IFNAME0, /* CCSP_HAL_ETHSW_EthPort1 */
	ETH_LAN_IFNAME1,		    /* CCSP_HAL_ETHSW_EthPort2 */
	ETH_LAN_IFNAME2,		    /* CCSP_HAL_ETHSW_EthPort3 */
	ETH_LAN_IFNAME3,		    /* CCSP_HAL_ETHSW_EthPort4 */
	ETH_LAN_IFNAME,		    /* CCSP_HAL_ETHSW_EthPort5 */
	ETH_LAN_IFNAME,		    /* CCSP_HAL_ETHSW_EthPort6 */
	ETH_LAN_IFNAME,		    /* CCSP_HAL_ETHSW_EthPort7 */
	ETH_LAN_IFNAME,		    /* CCSP_HAL_ETHSW_EthPort8 */
	NULL,			    /* CCSP_HAL_ETHSW_Moca1 */
	NULL,			    /* CCSP_HAL_ETHSW_Moca2 */
	ETH_WAN_IFNAME,		    /* CCSP_HAL_ETHSW_Wlan1 */
	ETH_WAN_IFNAME,		    /* CCSP_HAL_ETHSW_Wlan2 */
	ETH_WAN_IFNAME,		    /* CCSP_HAL_ETHSW_Wlan3 */
	ETH_WAN_IFNAME,		    /* CCSP_HAL_ETHSW_Wlan4 */
	NULL,			    /* CCSP_HAL_ETHSW_Processor1 */
	NULL,			    /* CCSP_HAL_ETHSW_Processor2 */
	NULL,			    /* CCSP_HAL_ETHSW_InterconnectPort1 */
	NULL,			    /* CCSP_HAL_ETHSW_InterconnectPort2 */
	NULL,			    /* CCSP_HAL_ETHSW_MgmtPort */
};

static void eth_dbg_info(const char *func, const char *format, ...)
{
	FILE *fp;
	va_list arg_ptr;
	int len = 0;
	int ret = 0;
	char str[MAX_BUF_SIZE];

	memset(str, 0, sizeof(str));

	ret = os_snprintf(str + strlen(str), MAX_BUF_SIZE - strlen(str), "%d: ", ethsw_db.log_num++);
	if (os_snprintf_error(MAX_BUF_SIZE - strlen(str), ret))
		return;

	ret = os_snprintf(str + strlen(str), MAX_BUF_SIZE - strlen(str), "%s: ", func);
	if (os_snprintf_error(MAX_BUF_SIZE - strlen(str), ret))
		return;

	va_start(arg_ptr, format);
	len = vsnprintf(str + strlen(str), MAX_BUF_SIZE - strlen(str), format, arg_ptr);
	if (len < 0) {
		dbg_info("vsnprintf fail!\n");
		return;
	}
	va_end(arg_ptr);

	fp = fopen("/rdklogs/logs/ETHHAL.log", "a+");
	if (fp == NULL) {
		dbg_info("Error: Failed to open file\n");
		return;
	}

	len = fwrite(str, 1, strlen(str), fp);
	if (strlen(str) != len)
		dbg_info("write error");

	len = fclose(fp);
	if (len != 0)
		dbg_info("fclose %s fail\n");
}

static int getWifiName(const char *fname, char *wifi_name)
{
	FILE *fp = NULL;
	char cmd[MAX_CMD_SIZE];
	char buf[MAX_BUF_SIZE];
	char str[MAX_BUF_SIZE];
	int str_count = 0;
	char *ifname = NULL;
	int ret;

	memset(cmd, 0, sizeof(cmd));
	memset(buf, 0, sizeof(buf));
	memset(str, 0, sizeof(str));

	ret = os_snprintf(cmd, MAX_CMD_SIZE, "%s%s%s", "cat ", fname, " | grep interface=");
	if (os_snprintf_error(MAX_CMD_SIZE, ret))
		return -1;

	if (access(fname, F_OK) == -1) {
		strlcpy(wifi_name, "NA", sizeof("NA"));
		return 1;
	}

	fp = popen(cmd, "r");
	if (fp == NULL) {
		dbg_info("Error: Failed to run command\n    %s\n", cmd);
		strlcpy(wifi_name, "NA", sizeof("NA"));
		return 1;
	}

	if (fgets(buf, MAX_BUF_SIZE, fp) != NULL) {
		ifname = strchr(buf, '=');
		if (ifname)
			strlcpy(str, ifname + 1, sizeof(ifname + 1));
	}

	for (str_count = 0; str[str_count] != '\n'; str_count++)
		wifi_name[str_count] = str[str_count];
	wifi_name[str_count] = '\0';

	pclose(fp);

	return 0;
}

static int getEthInfo(const char *ifname, char *param, char *keword, char *buf)
{
	FILE *fp = NULL;
	char cmd[MAX_CMD_SIZE];
	char *token;

	memset(cmd, 0, sizeof(cmd));

	int ret = os_snprintf(cmd, MAX_CMD_SIZE, "ethtool %s %s | grep \"%s\" | cut -d ':' -f2 | cut -d ' ' -f2",
												param, ifname, keword);
	if (os_snprintf_error(MAX_CMD_SIZE, ret))
		return -1;

	fp = popen(cmd, "r");
	if (fp == NULL) {
		dbg_info("Error: Failed to run command\n    %s\n", cmd);
		return 1;
	}

	while (fgets(buf, MAX_BUF_SIZE, fp) != NULL) {
		token = strchr(buf, '\n');
		if (token)
			*token = '\0';
	}
	pclose(fp);

	return 0;
}

static int isInterfaceExists(const char *ifname)
{
	char cmd[MAX_CMD_SIZE];
	int ret = 0;

	if (ifname == NULL)
		return 0;

	memset(cmd, 0, sizeof(cmd));

	ret = os_snprintf(cmd, MAX_CMD_SIZE, "/sys/class/net/%s", ifname);
	if (os_snprintf_error(MAX_CMD_SIZE, ret))
		return -1;

	if (access(cmd, F_OK) == -1)
		return 0;

	return 1;
}

static int isInterfaceLinkUp(const char *ifname)
{
	int sk;
	struct ifreq ifr;
	int isUp = 0;

	if (ifname == NULL)
		return 0;

	sk = socket(AF_INET, SOCK_DGRAM, 0);
	if (sk < 0) {
		dbg_info("ERROR: Socket error\n");
		return 0;
	}

	memset(&ifr, 0x0, sizeof(ifr));
	strlcpy(ifr.ifr_name, ifname, IFNAMSIZ);

	if (ioctl(sk, SIOCGIFFLAGS, &ifr) < 0) {
		dbg_info("ERROR: IOCTL fail\n");
		goto done;
	}

	isUp = (ifr.ifr_flags & IFF_RUNNING) ? 1 : 0;

done:
	close(sk);

	return isUp;
}

static int isInterfaceFixedLink(const char *ifname)
{
	FILE *fp = NULL;
	char cmd[MAX_CMD_SIZE];
	int isFixed = 0;
	int ret = 0;

	if (ifname == NULL)
		return 0;

	memset(cmd, 0, sizeof(cmd));

	ret = os_snprintf(cmd, MAX_CMD_SIZE, "cat /sys/kernel/debug/mtketh/phy_regs");
	if (os_snprintf_error(MAX_CMD_SIZE, ret))
		return -1;

	fp = popen(cmd, "r");
	if (fp == NULL) {
		dbg_info("Error: Failed to run command\n");
		return 0;
	}

	pclose(fp);

	isFixed = 1;

	return isFixed;
}

static void setInterfaceLink(const char *ifname, const char *act)
{
	CHAR cmd[MAX_CMD_SIZE];
	int ret = 0;

	memset(cmd, 0, sizeof(cmd));

	ret = os_snprintf(cmd, MAX_CMD_SIZE, "ip link set %s %s", ifname, act);
	if (os_snprintf_error(MAX_CMD_SIZE, ret))
		return;
	system(cmd);
}

static void ethsw_associating_handler(void)
{
	// eth_device_t eth_dev;
	// dbg_info("send associating event\n");
	// ethsw_db.associating_cb(&eth_dev);

#ifdef _HUB4_PRODUCT_REQ_
	// dbg_info("send link event\n");
	// if (ethsw_db.link_cb)
	//    ethsw_db.link_cb(ETH_WAN_INTERFACE, DISCONNECTED);
#endif
}

static void ethsw_linkLan_handler(void)
{
	int cur_link = isInterfaceLinkUp(ETH_LAN_INTERFACE);

	if (ethsw_db.prevLanLink != cur_link) {
#ifdef _HUB4_PRODUCT_REQ_
		if (cur_link) {
			dbg_info("send link event\n");
			if (ethsw_db.link_cb)
				ethsw_db.link_cb(ETH_LAN_INTERFACE, UP);
		} else {
			dbg_info("send link event\n");
			if (ethsw_db.link_cb)
				ethsw_db.link_cb(ETH_LAN_INTERFACE, DOWN);
		}
#endif

		ethsw_db.prevLanLink = cur_link;
	}
}

static void ethsw_linkWan_handler(void)
{
	int cur_link = isInterfaceLinkUp(ETH_WAN_INTERFACE);

	if (ethsw_db.prevWanLink != cur_link) {
#if defined(FEATURE_RDKB_WAN_MANAGER)
		if (cur_link) {
			dbg_info("send wan link up event\n");
			if (ethsw_db.wan_cb.pGWP_act_EthWanLinkUP)
				ethsw_db.wan_cb.pGWP_act_EthWanLinkUP();
		} else {
			dbg_info("send wan link down event\n");
			if (ethsw_db.wan_cb.pGWP_act_EthWanLinkDown)
				ethsw_db.wan_cb.pGWP_act_EthWanLinkDown();
		}
#endif

#ifdef _HUB4_PRODUCT_REQ_
		if (cur_link) {
			dbg_info("send link event\n");
			if (ethsw_db.link_cb)
				ethsw_db.link_cb(ETH_WAN_INTERFACE, UP);
		} else {
			dbg_info("send link event\n");
			if (ethsw_db.link_cb)
				ethsw_db.link_cb(ETH_WAN_INTERFACE, DOWN);
		}
#endif

		ethsw_db.prevWanLink = cur_link;
	}
}

static void *ethsw_event_handler(void *data)
{
	int timeout = 0;
	int file = 0;

	while (timeout != 180) {
		if (file == access(ETH_INITIALIZE, R_OK)) {
			dbg_info("Eth agent initialized\n");
			break;
		}

		timeout++;
		sleep(1);
	}

	while (1) {
		ethsw_associating_handler();
		ethsw_linkLan_handler();
		ethsw_linkWan_handler();

		sleep(ETH_POLL_TIME);
	}

	pthread_exit(NULL);
}

/* CcspHalEthSwInit :  */
/**
 * @description Do what needed to initialize the Eth hal.
 *
 * @param None
 *
 * @return The status of the operation.
 * @retval RETURN_OK if successful.
 * @retval RETURN_ERR if any error is detected
 *
 * @execution Synchronous.
 * @sideeffect None.
 *
 * @note This function must not suspend and must not invoke any blocking system
 * calls. It should probably just send a message to a driver event handler task.
 *
 */
INT CcspHalEthSwInit(void)
{
	dbg_info("init\n");

	CCSP_HAL_ETHSW_PORT PortId;
	INT ret;
	unsigned int switch_mode = 0;
	const char **ethsw_ifname_str;

	if (ethsw_db.init_done) {
		dbg_info("inited\n");
		return RETURN_OK;
	}

	switch_layer_get_switch_mode(&switch_mode);
	ethsw_ifname_str = switch_mode ? ethsw_ifname_str_dsa : ethsw_ifname_str_gsw;

	/* init database */
	for (PortId = 1; PortId < CCSP_HAL_ETHSW_PortMax; PortId++) {
		if (!isInterfaceExists(ethsw_ifname_str[PortId]))
			continue;

		ethsw_db.port[PortId].linkRate = CCSP_HAL_ETHSW_LINK_2_5Gbps;
		ethsw_db.port[PortId].duplexMode = CCSP_HAL_ETHSW_DUPLEX_Full;
		ethsw_db.port[PortId].admin_status = CCSP_HAL_ETHSW_AdminUp;
		ethsw_db.port[PortId].valid = 1;
	}

	ethsw_db.prevLanLink = isInterfaceLinkUp(ETH_LAN_INTERFACE);
	ethsw_db.prevWanLink = isInterfaceLinkUp(ETH_WAN_INTERFACE);

	ret = pthread_create(&ethsw_db.task, NULL, ethsw_event_handler, "CcspHalEthSw");
	if (ret) {
		dbg_info("ERROR: Init error\n");
		return RETURN_ERR;
	}

	ethsw_db.init_done = 1;

	return RETURN_OK;
}

/* CcspHalEthSwGetPortStatus :  */
/**
 * @description Retrieve the current port status -- link speed, duplex mode, etc.

 * @param PortId      -- Port ID as defined in CCSP_HAL_ETHSW_PORT
 * @param pLinkRate   -- Receives the current link rate, as in CCSP_HAL_ETHSW_LINK_RATE
 * @param pDuplexMode -- Receives the current duplex mode, as in CCSP_HAL_ETHSW_DUPLEX_MODE
 * @param pStatus     -- Receives the current link status, as in CCSP_HAL_ETHSW_LINK_STATUS

 *
 * @return The status of the operation.
 * @retval RETURN_OK if successful.
 * @retval RETURN_ERR if any error is detected
 *
 * @execution Synchronous.
 * @sideeffect None.

 *
 * @note This function must not suspend and must not invoke any blocking system
 * calls. It should probably just send a message to a driver event handler task.
 *
 */
INT CcspHalEthSwGetPortStatus(CCSP_HAL_ETHSW_PORT PortId, PCCSP_HAL_ETHSW_LINK_RATE pLinkRate,
			      PCCSP_HAL_ETHSW_DUPLEX_MODE pDuplexMode, PCCSP_HAL_ETHSW_LINK_STATUS pStatus)
{
	dbg_info("get port %d status\n", PortId);

	INT sk, ret;
	struct ifreq ifr;
	struct ethtool_cmd ecmd;
	struct ethtool_value eval;
	unsigned int switch_mode = 0;
	const char **ethsw_ifname_str;

	if (pLinkRate == NULL || pDuplexMode == NULL || pStatus == NULL) {
		dbg_info("Error: Input is NULL\n");
		return RETURN_ERR;
	}

	switch_layer_get_switch_mode(&switch_mode);
	ethsw_ifname_str = switch_mode ? ethsw_ifname_str_dsa : ethsw_ifname_str_gsw;

	if (!isInterfaceExists(ethsw_ifname_str[PortId])) {
		dbg_info("Error: Port %d doesn't exist\n", PortId);
		return RETURN_ERR;
	}

	sk = socket(PF_INET, SOCK_DGRAM, 0);
	if (sk < 0) {
		dbg_info("ERROR: Socket error\n");
		return RETURN_ERR;
	}

	memset(&ifr, 0x0, sizeof(ifr));
	strlcpy(ifr.ifr_name, ethsw_ifname_str[PortId], IFNAMSIZ);

	/* ethtool */
	ecmd.cmd = ETHTOOL_GSET;
	ifr.ifr_data = (char *)&ecmd;

	if (ioctl(sk, SIOCETHTOOL, &ifr) < 0) {
		dbg_info("ERROR: Ethtool cmd %d fail\n", ecmd.cmd);
		ret = RETURN_ERR;
		goto done;
	}

	/* parse result */
	if (ecmd.autoneg) {
		*pLinkRate = CCSP_HAL_ETHSW_LINK_Auto;
	} else {
		switch (ecmd.speed) {
		case SPEED_10:
			*pLinkRate = CCSP_HAL_ETHSW_LINK_10Mbps;
			break;
		case SPEED_100:
			*pLinkRate = CCSP_HAL_ETHSW_LINK_100Mbps;
			break;
		case SPEED_1000:
			*pLinkRate = CCSP_HAL_ETHSW_LINK_1Gbps;
			break;
		case SPEED_2500:
			*pLinkRate = CCSP_HAL_ETHSW_LINK_2_5Gbps;
			break;
		default:
			dbg_info("ERROR: Invalid link rate %d\n", ecmd.speed);
			ret = RETURN_ERR;
			goto done;
		}
	}

	switch (ecmd.duplex) {
	case DUPLEX_HALF:
		*pDuplexMode = CCSP_HAL_ETHSW_DUPLEX_Half;
		break;
	case DUPLEX_FULL:
		*pDuplexMode = CCSP_HAL_ETHSW_DUPLEX_Full;
		break;
	default:
		dbg_info("ERROR: Invalid duplex mode %d\n", ecmd.duplex);
		ret = RETURN_ERR;
		goto done;
	}

	/* ethtool */
	eval.cmd = ETHTOOL_GLINK;
	ifr.ifr_data = (char *)&eval;

	if (ioctl(sk, SIOCETHTOOL, &ifr) < 0) {
		dbg_info("ERROR: Ethtool cmd %d fail\n", eval.cmd);
		ret = RETURN_ERR;
		goto done;
	}

	/* parse result */
	if (eval.data && ethsw_db.port[PortId].admin_status == CCSP_HAL_ETHSW_AdminUp)
		*pStatus = CCSP_HAL_ETHSW_LINK_Up;
	else
		*pStatus = CCSP_HAL_ETHSW_LINK_Down;

	ret = RETURN_OK;

done:
	close(sk);

	return ret;
}

/* CcspHalEthSwGetPortCfg :  */
/**
 * @description Retrieve the current port config -- link speed, duplex mode, etc.

 * @param PortId      -- Port ID as defined in CCSP_HAL_ETHSW_PORT
 * @param pLinkRate   -- Receives the current link rate, as in CCSP_HAL_ETHSW_LINK_RATE
 * @param pDuplexMode -- Receives the current duplex mode, as in CCSP_HAL_ETHSW_DUPLEX_MODE

 *
 * @return The status of the operation.
 * @retval RETURN_OK if successful.
 * @retval RETURN_ERR if any error is detected
 *
 * @execution Synchronous.
 * @sideeffect None.

 *
 * @note This function must not suspend and must not invoke any blocking system
 * calls. It should probably just send a message to a driver event handler task.
 *
 */
INT CcspHalEthSwGetPortCfg(CCSP_HAL_ETHSW_PORT PortId, PCCSP_HAL_ETHSW_LINK_RATE pLinkRate,
			   PCCSP_HAL_ETHSW_DUPLEX_MODE pDuplexMode)
{
	dbg_info("get port %d config\n", PortId);

	unsigned int switch_mode = 0;
	const char **ethsw_ifname_str;

	if (pLinkRate == NULL || pDuplexMode == NULL) {
		dbg_info("Error: Input is NULL\n");
		return RETURN_ERR;
	}

	switch_layer_get_switch_mode(&switch_mode);
	ethsw_ifname_str = switch_mode ? ethsw_ifname_str_dsa : ethsw_ifname_str_gsw;

	if (!isInterfaceExists(ethsw_ifname_str[PortId])) {
		dbg_info("Error: Port %d doesn't exist\n", PortId);
		return RETURN_ERR;
	}

	if (!ethsw_db.port[PortId].valid) {
		dbg_info("ERROR: Invalid port %d\n", PortId);
		return RETURN_ERR;
	}

	*pLinkRate = ethsw_db.port[PortId].linkRate;
	*pDuplexMode = ethsw_db.port[PortId].duplexMode;

	return RETURN_OK;
}

/* CcspHalEthSwSetPortCfg :  */
/**
 * @description Set the port configuration -- link speed, duplex mode

 * @param PortId      -- Port ID as defined in CCSP_HAL_ETHSW_PORT
 * @param LinkRate    -- Set the link rate, as in CCSP_HAL_ETHSW_LINK_RATE
 * @param DuplexMode  -- Set the duplex mode, as in CCSP_HAL_ETHSW_DUPLEX_MODE

 *
 * @return The status of the operation.
 * @retval RETURN_OK if successful.
 * @retval RETURN_ERR if any error is detected
 *
 * @execution Synchronous.
 * @sideeffect None.

 *
 * @note This function must not suspend and must not invoke any blocking system
 * calls. It should probably just send a message to a driver event handler task.
 *
 */
INT CcspHalEthSwSetPortCfg(CCSP_HAL_ETHSW_PORT PortId, CCSP_HAL_ETHSW_LINK_RATE LinkRate,
			   CCSP_HAL_ETHSW_DUPLEX_MODE DuplexMode)
{
	dbg_info("set port %d LinkRate=%d DuplexMode=%d\n", PortId, LinkRate, DuplexMode);

	INT sk = 0, ret;
	struct ifreq ifr;
	struct ethtool_cmd ecmd;
	unsigned int switch_mode = 0;
	const char **ethsw_ifname_str;

	switch_layer_get_switch_mode(&switch_mode);
	ethsw_ifname_str = switch_mode ? ethsw_ifname_str_dsa : ethsw_ifname_str_gsw;

	if (!isInterfaceExists(ethsw_ifname_str[PortId])) {
		dbg_info("Error: Port %d doesn't exist\n", PortId);
		return RETURN_ERR;
	}

	if (!isInterfaceFixedLink(ethsw_ifname_str[PortId])) {
		sk = socket(PF_INET, SOCK_DGRAM, 0);
		if (sk < 0) {
			dbg_info("ERROR: Socket error\n");
			return RETURN_ERR;
		}

		memset(&ifr, 0x0, sizeof(ifr));
		strlcpy(ifr.ifr_name, ethsw_ifname_str[PortId], IFNAMSIZ);

		switch (LinkRate) {
		case CCSP_HAL_ETHSW_LINK_10Mbps:
			ecmd.speed = SPEED_10;
			break;
		case CCSP_HAL_ETHSW_LINK_100Mbps:
			ecmd.speed = SPEED_100;
			break;
		case CCSP_HAL_ETHSW_LINK_1Gbps:
			ecmd.speed = SPEED_1000;
			break;
		case CCSP_HAL_ETHSW_LINK_2_5Gbps:
			ecmd.speed = SPEED_2500;
			break;
		case CCSP_HAL_ETHSW_LINK_Auto:
			ecmd.speed = SPEED_UNKNOWN;
			ecmd.autoneg = 1;
			break;
		case CCSP_HAL_ETHSW_LINK_5Gbps:
		case CCSP_HAL_ETHSW_LINK_10Gbps:
		case CCSP_HAL_ETHSW_LINK_NULL:
		default:
			dbg_info("ERROR: Unsupported link rate %d\n", LinkRate);
			ret = RETURN_ERR;
			goto done;
		}

		switch (DuplexMode) {
		case CCSP_HAL_ETHSW_DUPLEX_Half:
			ecmd.duplex = DUPLEX_HALF;
			break;
		case CCSP_HAL_ETHSW_DUPLEX_Full:
			ecmd.duplex = DUPLEX_FULL;
			break;
		case CCSP_HAL_ETHSW_DUPLEX_Auto:
		default:
			dbg_info("ERROR: Unsupported duplex mode %d\n", DuplexMode);
			ret = RETURN_ERR;
			goto done;
		}

		/* ethtool */
		ecmd.cmd = ETHTOOL_SSET;
		ifr.ifr_data = (char *)&ecmd;

		if (ioctl(sk, SIOCETHTOOL, &ifr) < 0) {
			dbg_info("ERROR: Ethtool cmd %d fail\n", ecmd.cmd);
			ret = RETURN_ERR;
			goto done;
		}
	}

	/* save db */
	ethsw_db.port[PortId].linkRate = LinkRate;
	ethsw_db.port[PortId].duplexMode = DuplexMode;
	ethsw_db.port[PortId].valid = 1;

	ret = RETURN_OK;

done:
	close(sk);

	return ret;
}

/* CcspHalEthSwGetPortAdminStatus :  */
/**
 * @description Retrieve the current port admin status.

 * @param PortId      -- Port ID as defined in CCSP_HAL_ETHSW_PORT
 * @param pAdminStatus -- Receives the current admin status

 *
 * @return The status of the operation.
 * @retval RETURN_OK if successful.
 * @retval RETURN_ERR if any error is detected
 *
 * @execution Synchronous.
 * @sideeffect None.
 *
 * @note This function must not suspend and must not invoke any blocking system
 * calls. It should probably just send a message to a driver event handler task.
 *
 */
INT CcspHalEthSwGetPortAdminStatus(CCSP_HAL_ETHSW_PORT PortId, PCCSP_HAL_ETHSW_ADMIN_STATUS pAdminStatus)
{
	dbg_info("get port %d AdminStatus\n", PortId);

	unsigned int switch_mode = 0;
	const char **ethsw_ifname_str;

	switch_layer_get_switch_mode(&switch_mode);
	ethsw_ifname_str = switch_mode ? ethsw_ifname_str_dsa : ethsw_ifname_str_gsw;

	if (pAdminStatus == NULL) {
		dbg_info("Error: Input is NULL\n");
		return RETURN_ERR;
	}

	if (!isInterfaceExists(ethsw_ifname_str[PortId])) {
		dbg_info("Error: Port %d doesn't exist\n", PortId);
		return RETURN_ERR;
	}

	*pAdminStatus = ethsw_db.port[PortId].admin_status;

	return RETURN_OK;
}

/* CcspHalEthSwSetPortAdminStatus :  */
/**
 * @description Set the ethernet port admin status

 * @param AdminStatus -- Set the admin status, as defined in CCSP_HAL_ETHSW_ADMIN_STATUS
 *
 * @return The status of the operation.
 * @retval RETURN_OK if successful.
 * @retval RETURN_ERR if any error is detected
 *
 * @execution Synchronous.
 * @sideeffect None.

 *
 * @note This function must not suspend and must not invoke any blocking system
 * calls. It should probably just send a message to a driver event handler task.
 *
 */
INT CcspHalEthSwSetPortAdminStatus(CCSP_HAL_ETHSW_PORT PortId, CCSP_HAL_ETHSW_ADMIN_STATUS AdminStatus)
{
	dbg_info("set port %d AdminStatus=%d\n", PortId, AdminStatus);

	unsigned int switch_mode = 0;
	const char **ethsw_ifname_str;

	switch_layer_get_switch_mode(&switch_mode);
	ethsw_ifname_str = switch_mode ? ethsw_ifname_str_dsa : ethsw_ifname_str_gsw;

	if (!isInterfaceExists(ethsw_ifname_str[PortId])) {
		dbg_info("Error: Port %d doesn't exist\n", PortId);
		return RETURN_ERR;
	}

	switch (AdminStatus) {
	case CCSP_HAL_ETHSW_AdminUp:
		setInterfaceLink(ethsw_ifname_str[PortId], UP);
		break;
	case CCSP_HAL_ETHSW_AdminDown:
		setInterfaceLink(ethsw_ifname_str[PortId], DOWN);
		break;
	case CCSP_HAL_ETHSW_AdminTest:
	default:
		dbg_info("ERROR: Unsupported admin status %d\n", AdminStatus);
		return RETURN_ERR;
	}

	ethsw_db.port[PortId].admin_status = AdminStatus;

	return RETURN_OK;
}

/* CcspHalEthSwSetAgingSpeed :  */
/**
 * @description Set the ethernet port configuration -- admin up/down, link speed, duplex mode

 * @param PortId      -- Port ID as defined in CCSP_HAL_ETHSW_PORT
 * @param AgingSpeed  -- Integer value of aging speed
 *
 * @return The status of the operation.
 * @retval RETURN_OK if successful.
 * @retval RETURN_ERR if any error is detected
 *
 * @execution Synchronous.
 * @sideeffect None.

 *
 * @note This function must not suspend and must not invoke any blocking system
 * calls. It should probably just send a message to a driver event handler task.
 *
 */
INT CcspHalEthSwSetAgingSpeed(CCSP_HAL_ETHSW_PORT PortId, INT AgingSpeed)
{
	dbg_info("set port %d aging speed=%d\n", PortId, AgingSpeed);

	/* NOT support */

	return RETURN_OK;
}

/* CcspHalEthSwLocatePortByMacAddress  :  */
/**
 * @description Query Moca and External switch port for the given MAC address

 * @param mac      -- MAC address to search for
 * @param port     -- The return values are: 0: MoCA, 1-4: Ethernet port
 *
 * @return The status of the operation.
 * @retval RETURN_OK if successful.
 * @retval RETURN_ERR if any error is detected or MAC address is not found
 *
 * @execution Synchronous.
 * @sideeffect None.
 *
 * @note This function must not suspend and must not invoke any blocking system
 * calls. It should probably just send a message to a driver event handler task.
 *
 */
INT CcspHalEthSwLocatePortByMacAddress(unsigned char *mac, INT *port)
{
	dbg_info("search for MAC address %02x:%02x:%02x:%02x:%02x:%02x\n", mac[0], mac[1], mac[2], mac[3], mac[4],
		 mac[5]);

	FILE *fp = NULL;
	CHAR cmd[MAX_CMD_SIZE];
	CHAR buf[MAX_BUF_SIZE];
	CHAR str[MAX_BUF_SIZE];
	CHAR *token;
	CCSP_HAL_ETHSW_PORT PortId;
	INT ret = RETURN_ERR; /* default not found */
	unsigned int switch_mode = 0;
	const char **ethsw_ifname_str;

	memset(cmd, 0, sizeof(cmd));
	memset(buf, 0, sizeof(buf));
	memset(str, 0, sizeof(str));

	if (mac == NULL || port == NULL) {
		dbg_info("Error: Input is NULL\n");
		return RETURN_ERR;
	}

	switch_layer_get_switch_mode(&switch_mode);
	ethsw_ifname_str = switch_mode ? ethsw_ifname_str_dsa : ethsw_ifname_str_gsw;

	ret = os_snprintf(str, MAX_CMD_SIZE, "%02x:%02x:%02x:%02x:%02x:%02x",
											mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
	if (os_snprintf_error(MAX_CMD_SIZE, ret))
		return -1;

	for (PortId = 1; PortId < CCSP_HAL_ETHSW_PortMax; PortId++) {
		if (!isInterfaceExists(ethsw_ifname_str[PortId])) {
			dbg_info("ethsw_ifname_str %s\n", ethsw_ifname_str[PortId]);
			continue;
		}

		ret = os_snprintf(cmd, MAX_CMD_SIZE, "cat /sys/class/net/%s/address", ethsw_ifname_str[PortId]);
		if (os_snprintf_error(MAX_CMD_SIZE, ret))
			return -1;

		fp = popen(cmd, "r");
		if (fp == NULL) {
			dbg_info("Error: Failed to run command\n");
			break;
		}

		if (fgets(buf, MAX_BUF_SIZE, fp) != NULL) {
			token = strchr(buf, '\n');
			if (token)
				*token = '\0';
		}
		pclose(fp);

		if (strncmp(buf, str, strlen(str)) == 0) {
			*port = (INT)PortId;
			ret = RETURN_OK;
			break;
		}
	}

	return ret;
}

/* CcspHalExtSw_getAssociatedDevice :  */
/**
 * @description Collected the active wired clients information

 * @param output_array_size -- Size of the active wired connected clients
 * @param output_struct     -- Structure of  wired clients informations
 *
 * @return The status of the operation.
 * @retval RETURN_OK if successful.
 * @retval RETURN_ERR if any error is detected
 *
 */
INT CcspHalExtSw_getAssociatedDevice(ULONG *output_array_size, eth_device_t **output_struct)
{
	dbg_info("get associated device\n");

	FILE *fp = NULL, *fp1 = NULL;
	CHAR cmd[MAX_CMD_SIZE];
	CHAR buf[MAX_BUF_SIZE];
	CHAR str[MAX_BUF_SIZE];
	CHAR macAddr[50] = {0};
	CHAR ifname[ETHWAN_INTERFACE_NAME_MAX_LENGTH] = {0};
	INT count = 0, str_count = 0;
	ULONG mac_count = 0, eth_count = 0;
	eth_device_t *eth_dev = NULL;
	CHAR ipAddr[50], stub[50], phyAddr[50], ifName[32], status[32];
	INT ret = 0;

	if (output_struct == NULL) {
		dbg_info("Error: Not enough memory\n");
		return RETURN_ERR;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(buf, 0, sizeof(buf));
	memset(str, 0, sizeof(str));

	/* store the all associated devices */
	system("cat /nvram/dnsmasq.leases | cut -d ' ' -f2 > /tmp/connected_mac.txt");

	/* store the wifi associated devices */
	system("> /tmp/connected_wifi_mac.txt");

	getWifiName("/nvram/hostapd0.conf", ifname);
	if (isInterfaceExists(ifname)) {
		sprintf(cmd, "iw dev %s station dump | grep Station | cut -d ' ' -f2 >> /tmp/connected_wifi_mac.txt",
			ifname);
		system(cmd);
	}

	getWifiName("/nvram/hostapd1.conf", ifname);
	if (isInterfaceExists(ifname)) {
		sprintf(cmd, "iw dev %s station dump | grep Station | cut -d ' ' -f2 >> /tmp/connected_wifi_mac.txt",
			ifname);
		system(cmd);
	}

	/* separate the eth associated devices */
	system("comm -1 -3 /tmp/connected_wifi_mac.txt /tmp/connected_mac.txt > /tmp/connected_eth_mac.txt");

	/* get the eth associated devices count */
	fp = popen("cat /tmp/connected_eth_mac.txt | wc -l", "r");
	if (fp == NULL) {
		dbg_info("Error: Failed to run command\n");
		ret = RETURN_ERR;
		goto clean;
	} else {
		fgets(buf, MAX_BUF_SIZE, fp);
		mac_count = atol(buf);
	}
	pclose(fp);

	/* read the eth associated devices information */
	fp = fopen("/tmp/connected_eth_mac.txt", "r");
	if (fp == NULL) {
		dbg_info("Error: Failed to run command\n");
		ret = RETURN_ERR;
		goto clean;
	} else {
		for (count = 0; count < mac_count; count++) {
			fgets(str, MAX_BUF_SIZE, fp);
			for (str_count = 0; str[str_count] != '\n'; str_count++)
				macAddr[str_count] = str[str_count];
			macAddr[str_count] = '\0';

			/* Sample:
			 * 10.0.0.208 dev brlan0 lladdr d4:be:d9:99:7f:47 STALE
			 * 10.0.0.107 dev brlan0 lladdr 64:a2:f9:d2:f5:67 REACHABLE
			 */
			system("ip nei show | grep brlan0 > /tmp/arp_cache");
			fp1 = fopen("/tmp/arp_cache", "r");
			if (fp1 == NULL) {
				dbg_info("Error: Failed to run command\n");
				ret = RETURN_ERR;
				goto clean;
			}

			while (fgets(buf, sizeof(buf), fp1) != NULL) {
				if (strstr(buf, "FAILED") != 0)
					continue;

				if (sscanf(buf, LM_ARP_ENTRY_FORMAT, ipAddr, stub, ifName, stub, phyAddr, status) != 6)
					continue;

				/* check neighbor and nvram information are sync */
				if (strcmp(phyAddr, macAddr) == 0) {
					memset(buf, 0, sizeof(buf));
					if (strcmp(status, "REACHABLE") == 0) {
						sprintf(buf, "echo %s >> /tmp/reachable_eth_mac.txt", macAddr);
						system(buf);
						eth_count++;
						break;
					} else if ((strcmp(status, "STALE") == 0) || (strcmp(status, "DELAY"))) {
						/* try again */
						sprintf(buf, "ping -q -c 1 -W 1  \"%s\"  > /dev/null 2>&1", ipAddr);
						dbg_info("%s and MACADRRESS is %s\n", buf, macAddr);

						if (WEXITSTATUS(system(buf)) == 0) {
							dbg_info("Inside STALE SUCCESS\n");
							memset(buf, 0, sizeof(buf));
							sprintf(buf, "echo %s >> /tmp/reachable_eth_mac.txt", macAddr);
							system(buf);
							eth_count++;
							break;
						}
					} else {
						dbg_info("Error: Running in state %s\n", status);
						break;
					}
				} else {
					dbg_info("MacAddress is not valid\n");
				}
			}
			fclose(fp1);
		}
		fclose(fp);
	}

	/* reachable eth associated devices */
	fp = fopen("/tmp/reachable_eth_mac.txt", "r");
	if (fp == NULL) {
		dbg_info("no reachable mac\n");

		eth_dev = NULL;
		eth_count = 0;
		goto clean;
	} else {
		dbg_info("reachable mac number: %d\n", eth_count);

		eth_dev = (eth_device_t *)calloc(1, sizeof(eth_device_t) * eth_count);
		if (eth_dev == NULL) {
			dbg_info("Error: Not enough memory\n");
			ret = RETURN_ERR;
			goto clean;
		}

		memset(buf, 0, sizeof(buf));
		for (count = 0; count < eth_count; count++) {
			fgets(buf, sizeof(buf), fp);

			if (sscanf(buf, "%hhX:%hhX:%hhX:%hhX:%hhX:%hhX", &eth_dev[count].eth_devMacAddress[0],
					&eth_dev[count].eth_devMacAddress[1], &eth_dev[count].eth_devMacAddress[2],
					&eth_dev[count].eth_devMacAddress[3], &eth_dev[count].eth_devMacAddress[4],
					&eth_dev[count].eth_devMacAddress[5]) != 6) {
				dbg_info("Error: sscanf fail\n");
				fclose(fp);
				goto clean;
			}

			eth_dev[count].eth_port = 1;
			eth_dev[count].eth_vlanid = 10;
			eth_dev[count].eth_devTxRate = 100;
			eth_dev[count].eth_devRxRate = 100;
			eth_dev[count].eth_Active = 1;
		}
		fclose(fp);
	}

	ret = RETURN_OK;

clean:

	if (access("/tmp/connected_mac.txt", F_OK) != -1)
		remove("/tmp/connected_mac.txt");

	if (access("/tmp/connected_wifi_mac.txt", F_OK) != -1)
		remove("/tmp/connected_wifi_mac.txt");

	if (access("/tmp/connected_eth_mac.txt", F_OK) != -1)
		remove("/tmp/connected_eth_mac.txt");

	if (access("/tmp/arp_cache", F_OK) != -1)
		remove("/tmp/arp_cache");

	if (access("/tmp/reachable_eth_mac.txt", F_OK) != -1)
		remove("/tmp/reachable_eth_mac.txt");

	if (ret == RETURN_OK) {
		*output_struct = eth_dev;
		*output_array_size = eth_count;
	} else {
		*output_struct = NULL;
		*output_array_size = 0;
	}

	return ret;
}

void CcspHalExtSw_ethAssociatedDevice_callback_register(CcspHalExtSw_ethAssociatedDevice_callback callback_proc)
{
	dbg_info("register associating event\n");

	/* This call back will be invoked when new Ethernet client come to associate to AP,
	 * or existing Ethernet client left.
	 */
	if (callback_proc)
		ethsw_db.associating_cb = callback_proc;
}

/* CcspHalExtSw_getEthWanEnable() function */
/**
 * @description Get EthernetWAN enable status.
 *
 * @param pFlag - Pointer to BOOLEAN to store current EthernetWAN enable value
 *
 * @return The status of the operation
 * @retval RETURN_OK if successful
 * @retval RETURN_ERR if any error is detected
 *
 * @sideeffect None
 */
INT CcspHalExtSw_getEthWanEnable(BOOLEAN *pFlag)
{
	dbg_info("get wan enable\n");

	if (pFlag == NULL) {
		dbg_info("Error: Input is NULL\n");
		return RETURN_ERR;
	}

	*pFlag = ethsw_db.wan_enable;

	return RETURN_OK;
}

/* CcspHalExtSw_setEthWanEnable() function */
/**
 * @description Enable/Disable EthernetWAN functionality.
 *
 * @param Flag - EthernetWAN enable value
 *
 * @return The status of the operation
 * @retval RETURN_OK if successful
 * @retval RETURN_ERR if any error is detected
 *
 * @sideeffect None
 */
INT CcspHalExtSw_setEthWanEnable(BOOLEAN Flag)
{
	dbg_info("set wan enable %d\n", Flag);

	setInterfaceLink(ETH_WAN_INTERFACE, (Flag == TRUE) ? UP : DOWN);

	ethsw_db.wan_enable = Flag;

	return RETURN_OK;
}

/* CcspHalExtSw_getEthWanPort() function */
/**
 * @description Get EthernetWAN port number value.
 *
 * @param pPort - Pointer to UINT value to store current setting
 *
 * @return The status of the operation
 * @retval RETURN_OK if successful
 * @retval RETURN_ERR if any error is detected
 *
 * @sideeffect None
 */
INT CcspHalExtSw_getEthWanPort(UINT *pPort)
{
	dbg_info("get wan port\n");

	if (pPort == NULL) {
		dbg_info("Error: Input is NULL\n");
		return RETURN_ERR;
	}

	*pPort = ethsw_db.wan_port;

	return RETURN_OK;
}

/* CcspHalExtSw_setEthWanPort() function */
/**
 * @description Set EthernetWAN interface/port number.
 *
 * @param Port - UINT value to set the setting
 *
 * @return The status of the operation
 * @retval RETURN_OK if successful
 * @retval RETURN_ERR if any error is detected
 *
 * @sideeffect None
 */
INT CcspHalExtSw_setEthWanPort(UINT Port)
{
	dbg_info("set wan port %d\n", Port);

	ethsw_db.wan_port = Port;

	return RETURN_OK;
}

/* CcspHalEthSwGetEthPortStats :  */
/**
 * Description: Retrieve the current port's statistics.

 * Parameters :
     PortId    -- Port ID as defined in CCSP_HAL_ETHSW_PORT
     pStats    -- Receives port statistics

 *
 * @return The status of the operation.
 * @retval RETURN_OK if successful.
 * @retval RETURN_ERR if any error is detected
 *
 * @execution Synchronous.
 * @sideeffect None.

 *
 * @note This function must not suspend and must not invoke any blocking system 
 * calls. It should probably just send a message to a driver event handler task.
 *
 */
INT CcspHalEthSwGetEthPortStats(CCSP_HAL_ETHSW_PORT PortId, PCCSP_HAL_ETH_STATS pStats)
{
	dbg_info("get port %d stats\n", PortId);

	CHAR buf[MAX_BUF_SIZE] = {0};
	unsigned int switch_mode = 0;
	const char **ethsw_ifname_str;

	if (pStats == NULL) {
		dbg_info("Error: Input is NULL\n");
		return RETURN_ERR;
	}
	switch_layer_get_switch_mode(&switch_mode);
	ethsw_ifname_str = switch_mode ? ethsw_ifname_str_dsa : ethsw_ifname_str_gsw;

	if (!isInterfaceExists(ethsw_ifname_str[PortId])) {
		dbg_info("Error: Port %d doesn't exist\n", PortId);
		return RETURN_ERR;
	}

	/* Sample:
	 * tx_bytes: 1381768
	 * tx_packets: 1382
	 * tx_skip: 0
	 * tx_collisions: 0
	 * rx_bytes: 124517
	 * rx_packets: 1118
	 * rx_overflow: 0
	 * rx_fcs_errors: 0
	 * rx_short_errors: 0
	 * rx_long_errors: 0
	 * rx_checksum_errors: 0
	 * rx_flow_control_packets: 27
	 */

	getEthInfo(ethsw_ifname_str[PortId], "-S", "tx_bytes", buf);
	pStats->BytesSent = atol(buf);
	getEthInfo(ethsw_ifname_str[PortId], "-S", "rx_bytes", buf);
	pStats->BytesReceived = atol(buf);
	getEthInfo(ethsw_ifname_str[PortId], "-S", "tx_packets", buf);
	pStats->PacketsSent = atol(buf);
	getEthInfo(ethsw_ifname_str[PortId], "-S", "rx_packets", buf);
	pStats->PacketsReceived = atol(buf);

	/* Not support */
	pStats->ErrorsSent = 0;
	pStats->ErrorsReceived = 0;
	pStats->UnicastPacketsSent = 0;
	pStats->UnicastPacketsReceived = 0;
	pStats->DiscardPacketsSent = 0;
	pStats->DiscardPacketsReceived = 0;
	pStats->MulticastPacketsSent = 0;
	pStats->MulticastPacketsReceived = 0;
	pStats->BroadcastPacketsSent = 0;
	pStats->BroadcastPacketsReceived = 0;
	pStats->UnknownProtoPacketsReceived = 0;

	return RETURN_OK;
}

void GWP_RegisterEthWan_Callback(appCallBack *obj)
{
	dbg_info("register wan event\n");

	if (obj) {
		ethsw_db.wan_cb.pGWP_act_EthWanLinkUP = obj->pGWP_act_EthWanLinkUP;
		ethsw_db.wan_cb.pGWP_act_EthWanLinkDown = obj->pGWP_act_EthWanLinkDown;
	}
}

INT GWP_GetEthWanLinkStatus(void)
{
	dbg_info("get wan status\n");

	return isInterfaceLinkUp(ETH_WAN_INTERFACE);
}

INT GWP_GetEthWanInterfaceName(unsigned char *Interface, ULONG maxSize)
{
	dbg_info("get wan ifname\n");

	if ((Interface == NULL) || (maxSize < strlen(ETH_WAN_IFNAME) + 1) ||
	    (maxSize > ETHWAN_INTERFACE_NAME_MAX_LENGTH)) {
		dbg_info("ERROR: Invalid argument.\n");
		return RETURN_ERR;
	}

	snprintf((char *)Interface, maxSize, "%s", ETH_WAN_IFNAME);

	return RETURN_OK;
}

#ifdef _HUB4_PRODUCT_REQ_
void CcspHalEthSw_RegisterLinkEventCallback(ethsw_ethLinkEventCallback callback_proc)
{
	dbg_info("register link event\n");

	if (callback_proc)
		ethsw_db.link_cb = callback_proc;
}
#endif
