/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2023-2024  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */
#include "util.h"
#ifdef EPCS_SUPPORT

#include <stdlib.h>
#include <stdio.h>
/*#include <linux/netlink.h>*/

#include "wapp_cmm.h"
#include "epcs.h"
/*#include "driver_wext.h"*/
#include "mtk_vendor_nl80211.h"

#ifndef QOS_R1
#define CATEGORY_EHT_PROT_ACT           37

int wapp_drv_send_action_frame(unsigned short sub_cmd_id, struct wifi_app *wapp, struct wapp_dev *wdev, unsigned int chan,
			       unsigned int wait, const u8 *dst, const u8 *data, size_t len)
{
	return 0;
}

int convert_mac_addr(char *strmac, unsigned char *mac_addr)
{
	return 0;
}
#endif

#define LEN_IDX 1

#define SEND_BUF_LEN 1024
#define FILE_CONTENT_BUF_LEN 10240

#define GET_ACT_FRAME_CATEGORY(frmbuf) frmbuf[0]
#define GET_ACT_FRAME_ACTION(frmbuf) frmbuf[1]
#define GET_ACT_FRAME_TOKEN(frmbuf) frmbuf[2]
#define GET_ACT_FRAME_STATUS(frmbuf) frmbuf[3]

unsigned char epcs_sta_cnt;
struct dl_list epcs_sta_list;
unsigned char epcs_req_tx_token;
struct wmm_parameter g_wmmpe[WMM_AC_NUM] = {
	/* ECWin, ECWMax, AIFSN, TXOP*/
	{4, 9, 3, 0},	/*AC_BE*/
	{4, 9, 7, 0},	/*AC_BK*/
	{3, 4, 2, 188},	/*AC_VI*/
	{2, 3, 2, 102}	/*AC_VO*/
};

unsigned char act_frm_buf[SEND_BUF_LEN] = {0};
unsigned char multi_link_fixed_ie[] = {0xFF, 0x0a, 0x6b, 0x04, 0x00, 0x07, 0x00, 0x0c, 0x43, 0x44, 0x55, 0x66};

unsigned char per_sta_profile_fixed_ie[] = {0, 2, 0, 0};
unsigned char wmm_ie[] = {
	0xdd, 0x18, 0x00, 0x50, 0xf2, 0x02, 0x01, 0x01, 0x80, 0x00, 0x03, 0x94, 0x00, 0x00, 0x27, 0x94,
	0x00, 0x00, 0x42, 0x43, 0x5e, 0x00, 0x62, 0x32, 0x2f, 0x00
};

void wapp_epcs_init(struct wifi_app *wapp)
{
	epcs_sta_cnt = 0;
	dl_list_init(&epcs_sta_list);
	epcs_req_tx_token = 0;
}

void wapp_epcs_deinit(struct wifi_app *wapp)
{
	clean_epcs_list();
}

char *get_raw_data_end(char *content)
{
	char flag_ch[5] = {'_', 0x0a, 0x0d, '\0', ' '};
	int i = 0;
	char *temp = NULL;
	char *temp_min = NULL;

	for (i = 0; i < 5; i++) {
		temp = strchr(content, flag_ch[i]);
		if (temp == NULL)
			continue;
		if ((temp_min != NULL && temp_min > temp) || temp_min == NULL)
			temp_min = temp;
	}
	return temp_min;
}

char *str_locate(char *org_string, char *t_string)
{
	int i = 0;
	int org_len = 0, t_len = 0;

	org_len = strlen(org_string);
	t_len = strlen(t_string);

	for (i = 0; i <= org_len - t_len; i++) {
		if (!strncmp(org_string + i, t_string, t_len))
			return (char *)(org_string + i);
	}
	return NULL;
}

int _read_raw_data(char *file, unsigned char *peer_mac, unsigned char *frmbuf, unsigned short buflen)
{
	int i = 0;
	FILE *f = NULL;
	int ch;
	char *p = NULL, filepath[256] = {0};
	char *content = NULL, *pos1 = NULL, *pos2 = NULL;
	unsigned short payload_len = 0;
	unsigned int value, mac_int[ETH_ALEN] = {0};
	unsigned char byte_value[3] = {0};

	if (!file || !peer_mac || !frmbuf) {
		err(DEBUG_CAT_EPCS, "got NULL pointer, file:%p, peer_mac: %p, frmbuf:%p\n", file, peer_mac, frmbuf);
		return -1;
	}

	if (strlen(file) && (strlen(file) < 255)) {
		p = strchr(file, ' ');
		if (p)
			*p = '\0';
		os_memcpy(filepath, file, strlen(file));
	} else {
		err(DEBUG_CAT_EPCS, "invalid file %s\n", file);
	}

	f = fopen(filepath, "r");
	if (f == NULL) {
		err(DEBUG_CAT_EPCS, "open file %s fail, %s\n", filepath, strerror(errno));
		return -1;
	}

	/*alloc more memory to support parse jumbo TLV from file.*/
	content = os_malloc(FILE_CONTENT_BUF_LEN);
	if (!content) {
		err(DEBUG_CAT_EPCS, "alloc memory for fail\n");
		goto error;
	}
	os_memset(content, 0, FILE_CONTENT_BUF_LEN);

	do {
		ch = fgetc(f);
		if (ferror(f) != 0) {
			err(DEBUG_CAT_EPCS, "fgetc error\n");
			clearerr(f);
			goto error;
		}
		if (ch != EOF)
			content[i++] = ch;
	} while (ch != EOF);

	pos1 = content;
	/*peer mac*/
	pos2 = strchr(pos1, '\n');
	if (pos2 == NULL) {
		err(DEBUG_CAT_EPCS, "peer mac not found.\n");
		goto error;
	}

	*pos2 = '\0';
	if (sscanf(pos1, "%02x:%02x:%02x:%02x:%02x:%02x", mac_int, mac_int + 1,
		mac_int + 2, mac_int + 3, mac_int + 4, mac_int + 5) < 0) {
		err(DEBUG_CAT_EPCS, "sscanf fail!\n");
		goto error;
	}

	for (i = 0; i < 6; i++)
		peer_mac[i] = (unsigned char)mac_int[i];

	notice(DEBUG_CAT_EPCS, "peer mac:"MACSTR"\n", PRINT_MAC(peer_mac));

	pos2++;
	pos1 = pos2;
	while (1) {
		pos1 = str_locate(pos1, "0x");

		/*end of data*/
		if (pos1 == NULL)
			break;

		/*skip '0x'*/
		pos1 += 2;
		pos2 = get_raw_data_end(pos1);

		if (pos2 == NULL) {
			err(DEBUG_CAT_EPCS, "error find raw data end\n");
			goto error;
		}
		if (pos2 < pos1) {
			err(DEBUG_CAT_EPCS, "pos2 must larger than pos1\n");
			goto error;
		}
		if (((int)(pos2 - pos1)) % 2 != 0) {
			pos1--;
			*pos1 = '0';
		}
		while (1) {
			memset(byte_value, 0, sizeof(byte_value));
			memcpy(byte_value, pos1, 2);
			if (sscanf((char *)byte_value, "%02x", &value) < 0) {
				err(DEBUG_CAT_EPCS, "sscanf fail!\n");
				goto error;
			}
			frmbuf[payload_len++] = (unsigned char)value;
			pos1 += 2;
			if ((pos1 >= pos2) || (payload_len >= buflen))
				break;
		}
	}
	hex_dump("send_act_frame", frmbuf, payload_len);

	if (fclose(f) < 0)
		err(DEBUG_CAT_EPCS, "fclose fail!\n");

	os_free(content);
	return payload_len;
error:
	if (fclose(f) < 0)
		err(DEBUG_CAT_EPCS, "fclose fail!\n");
	if (content)
		os_free(content);

	return -1;
}

/*
 * compare if two wmm setting is the same.
 * parameters, wmmpe1 & wmmpe2 is a array pointer to struct wmm_parameter, num is the size of array.
 * return value, 1: the setting is different, 0: the setting is the same.
 */
static inline u8 compare_wmm_setting(struct wmm_parameter *wmmpe1, struct wmm_parameter *wmmpe2, u8 num)
{
	u8 i = 0;

	for (i = 0; i < num; i++) {
		if (wmmpe1[i].cwmin != wmmpe2[i].cwmin ||
			wmmpe1[i].cwmax != wmmpe2[i].cwmax ||
			wmmpe1[i].aifsn != wmmpe2[i].aifsn ||
			wmmpe1[i].txop != wmmpe2[i].txop)
			return 1;
	}
	return 0;
}

u8 update_epcs_list(struct epcs_sta *sta)
{
	u8 updated = 0, existed = 0;
	struct epcs_entry *pos = NULL, *tmp = NULL;

	dl_list_for_each_safe(pos, tmp, &epcs_sta_list, struct epcs_entry, list) {
		if (MAC_ADDR_EQUAL(pos->sta.mac, sta->mac)) {
			existed = 1;
			if (pos->sta.state != sta->state ||
				compare_wmm_setting(pos->sta.wmmpe, sta->wmmpe, WMM_AC_NUM)) {
				pos->sta.state = sta->state;
				memcpy(pos->sta.wmmpe, sta->wmmpe, sizeof(sta->wmmpe));
				updated = 1;
			}
			break;
		}
	}

	if (!existed) {
		if (epcs_sta_cnt >= MAX_AUTHORIZED_STA_NUMBER) {
			warn(DEBUG_CAT_EPCS, "Note: authorized STA reach maximum:%d\n", epcs_sta_cnt);
			return 0;
		}

		pos = (struct epcs_entry *)os_zalloc(sizeof(struct epcs_entry));
		if (pos) {
			memcpy(&pos->sta, sta, sizeof(*sta));
			/*add setting*/
			dl_list_add_tail(&epcs_sta_list, &pos->list);
			epcs_sta_cnt++;
			updated = 1;

			notice(DEBUG_CAT_EPCS, "add new authorized STA: " MACSTR "\n", MAC2STR(sta->mac));
		} else {
			err(DEBUG_CAT_EPCS, "Memory Alloc Fail\n");
		}
	}

	return updated;
}

struct epcs_sta *lookup_epcs_sta(u8 *stamac)
{
	struct epcs_entry *pos = NULL;

	if (stamac == NULL)
		return NULL;

	dl_list_for_each(pos, &epcs_sta_list, struct epcs_entry, list) {
		if (MAC_ADDR_EQUAL(pos->sta.mac, stamac))
			return &pos->sta;
	}
	return NULL;
}

void remove_epcs_sta(u8 *stamac)
{
	struct epcs_entry *pos = NULL, *tmp = NULL;

	if (epcs_sta_cnt > 0) {
		dl_list_for_each_safe(pos, tmp, &epcs_sta_list, struct epcs_entry, list) {
			if (MAC_ADDR_EQUAL(pos->sta.mac, stamac)) {
				dl_list_del(&pos->list);
				os_free(pos);
				epcs_sta_cnt--;
				notice(DEBUG_CAT_EPCS, "remove authorized STA: " MACSTR "\n", MAC2STR(stamac));
			}
		}
	}
}

void clean_epcs_list(void)
{
	struct epcs_entry *pos = NULL, *tmp = NULL;

	if (epcs_sta_cnt > 0) {
		dl_list_for_each_safe(pos, tmp, &epcs_sta_list, struct epcs_entry, list) {
			dl_list_del(&pos->list);
			os_free(pos);
		}
		epcs_sta_cnt = 0;
	}
}

void wapp_ctrl_show_epcs_list(void)
{
	char *buf = NULL;
	int buflen = 10240, ret = 0, offset = 0, i = 0, j = 0;
	struct epcs_entry *pos = NULL;

	buf = os_malloc(buflen);
	if (!buf) {
		err(DEBUG_CAT_EPCS, "alloc memory fail\n");
		return;
	}

	memset(buf, 0, buflen);

	ret = snprintf(buf + offset, buflen - offset, "\n[wappd]---------Current EPCS EDCA Setting---------\n");
	if (os_snprintf_error(buflen - offset, ret))
		goto exit;
	offset += ret;

	ret = snprintf(buf + offset, buflen - offset, "ECWin   ECWMAX   AIFSN   TXOP\n");
	if (os_snprintf_error(buflen - offset, ret))
		goto exit;
	offset += ret;

	for (j = 0; j < WMM_AC_NUM; j++) {
		ret = snprintf(buf + offset, buflen - offset, "  %d       %d        %d      %d\n",
			g_wmmpe[j].cwmin, g_wmmpe[j].cwmax, g_wmmpe[j].aifsn, g_wmmpe[j].txop);
		if (os_snprintf_error(buflen - offset, ret))
			goto exit;
		offset += ret;
	}

	if (epcs_sta_cnt > 0) {
		ret = snprintf(buf + offset, buflen - offset, "\n[wappd]---------epcs sta list---------\n");
		if (os_snprintf_error(buflen - offset, ret))
			goto exit;
		offset += ret;

		dl_list_for_each(pos, &epcs_sta_list, struct epcs_entry, list) {
			ret = snprintf(buf + offset, buflen - offset,
				"%d.  "MACSTR", state:%s\n", i++, MAC2STR(pos->sta.mac),
				(pos->sta.state == STATE_EPCS_ENABLED) ? "Enabled" : "Disabled");
			if (os_snprintf_error(buflen - offset, ret))
				goto exit;
			offset += ret;

			ret = snprintf(buf + offset, buflen - offset, "ECWin   ECWMAX   AIFSN   TXOP\n");
			if (os_snprintf_error(buflen - offset, ret))
				goto exit;
			offset += ret;

			for (j = 0; j < WMM_AC_NUM; j++) {
				ret = snprintf(buf + offset, buflen - offset, "  %d       %d        %d      %d\n",
					pos->sta.wmmpe[j].cwmin, pos->sta.wmmpe[j].cwmax, pos->sta.wmmpe[j].aifsn, pos->sta.wmmpe[j].txop);
				if (os_snprintf_error(buflen - offset, ret))
					goto exit;
				offset += ret;
			}
		}
	} else {
		ret = snprintf(buf + offset, buflen - offset, "[wappd]---------no authorized epcs sta---------\n");
		if (os_snprintf_error(buflen - offset, ret))
			goto exit;
		offset += ret;
	}

exit:
	if (os_snprintf_error(buflen - offset, ret))
		err(DEBUG_CAT_EPCS, "error happen, ret = %d\n", ret);

	if (strlen(buf))
		printf("%s\n", buf);

	if (buf)
		os_free(buf);
}

/*append Priority Access Multi-Link element*/
static inline u8 append_multi_link_ie(u8 *frmbuf)
{
	u8 i = 0, multi_ie_len = 0, persta_ie_len = 0, append_len = 0;

	/*fill AC_BE/AC_BK/AC_VI/AC_VO Parameter Record*/
	for (i = WMM_AC_BE; i < WMM_AC_NUM; i++) {
		wmm_ie[10 + (i * WMM_AC_NUM)] = (i << 5) | (g_wmmpe[i].aifsn & 0x0F);
		wmm_ie[11 + (i * WMM_AC_NUM)] = ((g_wmmpe[i].cwmax & 0x0F) << 4) | (g_wmmpe[i].cwmin & 0x0F);
		wmm_ie[12 + (i * WMM_AC_NUM)] = g_wmmpe[i].txop;
	}

	/*compose muti link IE: multi_link_fixed_ie + per_sta_profile_fixed_ie + wmm_ie*/
	/*1. change length field*/
	persta_ie_len = sizeof(per_sta_profile_fixed_ie) + sizeof(wmm_ie);
	multi_ie_len = sizeof(multi_link_fixed_ie) + persta_ie_len;
	multi_link_fixed_ie[LEN_IDX] = multi_ie_len - 2;
	per_sta_profile_fixed_ie[LEN_IDX] = persta_ie_len - 2;

	/*2. compose contents field*/
	memcpy(frmbuf, multi_link_fixed_ie, sizeof(multi_link_fixed_ie));
	append_len = sizeof(multi_link_fixed_ie);
	memcpy(frmbuf + append_len, per_sta_profile_fixed_ie, sizeof(per_sta_profile_fixed_ie));
	append_len += sizeof(per_sta_profile_fixed_ie);
	memcpy(frmbuf + append_len, wmm_ie, sizeof(wmm_ie));
	append_len += sizeof(wmm_ie);

	return append_len;
}

static inline u8 build_epcs_request(u8 token, u8 *frmbuf, u16 buflen)
{
	u8 frmlen = 0, tmp_len = 0;

	if (!frmbuf || !buflen)
		return 0;

	memset(frmbuf, 0, buflen);
	frmlen = 0;
	frmbuf[frmlen] = CATEGORY_EHT_PROT_ACT;
	frmlen++;
	frmbuf[frmlen] = EPCS_REQUEST;
	frmlen++;
	frmbuf[frmlen] = token;
	frmlen++;

	/*append Priority Access Multi-Link element*/
	tmp_len = append_multi_link_ie(&frmbuf[frmlen]);
	frmlen += tmp_len;

	return frmlen;
}

static inline u8 build_epcs_response(u8 token, u16 statuscode, u8 *frmbuf, u16 buflen)
{
	u8 frmlen = 0, tmp_len = 0;

	if (!frmbuf || !buflen)
		return 0;

	memset(frmbuf, 0, buflen);
	frmlen = 0;
	frmbuf[frmlen] = CATEGORY_EHT_PROT_ACT;
	frmlen++;
	frmbuf[frmlen] = EPCS_RESPONSE;
	frmlen++;
	frmbuf[frmlen] = token;
	frmlen++;
	memcpy(&frmbuf[frmlen], &statuscode, 2);
	frmlen += 2;

	if (statuscode == EPCS_STATUS_SUCCESS) {
		/*append Priority Access Multi-Link element*/
		tmp_len = append_multi_link_ie(&frmbuf[frmlen]);
		frmlen += tmp_len;
	}

	return frmlen;
}

static inline u8 build_epcs_teardown(u8 *frmbuf, u16 buflen)
{
	u8 frmlen = 0;

	if (!frmbuf || !buflen)
		return 0;

	memset(frmbuf, 0, buflen);
	frmlen = 0;
	frmbuf[frmlen] = CATEGORY_EHT_PROT_ACT;
	frmlen++;
	frmbuf[frmlen] = EPCS_TEARDOWN;
	frmlen++;

	return frmlen;
}

int wapp_ctrl_send_act_frame(struct wifi_app *wapp, const char *iface, char *file, char *reply, size_t *reply_len)
{
	int ret = 0, data_len = 0;
	unsigned char peer_mac[ETH_ALEN] = {0};
	struct wapp_dev *wdev = NULL;

	wdev = wapp_dev_list_lookup_by_ifname(wapp, iface);
	if (wdev == NULL) {
		err(DEBUG_CAT_EPCS, "can not find configuration for interface(%s)\n", iface);
		return -1;
	}

	data_len = _read_raw_data(file, peer_mac, act_frm_buf, sizeof(act_frm_buf));
	if (data_len < 0) {
		err(DEBUG_CAT_EPCS, "no data available for sending\n");
		return -1;
	}

	epcs_req_tx_token = GET_ACT_FRAME_TOKEN(act_frm_buf);

	ret = wapp_drv_send_action_frame(MTK_NL80211_VENDOR_ATTR_SET_ACTION_QOS_ACTION_FRAME,
		wapp, wdev, 0, 0, peer_mac, act_frm_buf, data_len);

	return ret;
}

int wapp_drv_sync_epcs_state(struct wifi_app *wapp, const char *ifname, char *buf, u32 buflen)
{
	if (!wapp->drv_ops || !wapp->drv_ops->drv_sync_epcs_state)
		return 0;

	return wapp->drv_ops->drv_sync_epcs_state(wapp->drv_data, ifname, buf, buflen);
}

int wapp_ctrl_epcs_setup(struct wifi_app *wapp, const char *iface, char *cmd, char *reply, size_t *reply_len)
{
	u8 len = 0, updated = 0;
	int ret = 0;
	char *macstr = NULL;
	struct wapp_dev *wdev = NULL;
	u8 sta_mac[MAC_ADDR_LEN] = {0};
	u8 zero_mac[MAC_ADDR_LEN] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
	struct epcs_sta peersta, *authorized_sta = NULL;

	wdev = wapp_dev_list_lookup_by_ifname(wapp, iface);
	if (wdev == NULL) {
		err(DEBUG_CAT_EPCS, "can not find configuration for interface(%s)\n", iface);
		return -1;
	}

	macstr = strtok(cmd, " ");
	if (!macstr || !iface || !cmd) {
		err(DEBUG_CAT_EPCS, "NULL pointer happen, iface:%p, cmd:%p, macstr:%p\n",
			iface, cmd, macstr);
		return -1;
	}

	notice(DEBUG_CAT_EPCS, "iface:%s, cmd:%s\n", iface, cmd);

	macstr = strtok(NULL, " ");
	if (!macstr) {
		err(DEBUG_CAT_EPCS, "no mac address in parameters\n");
		return -1;
	}

	ret = convert_mac_addr(macstr, sta_mac);
	if (ret < 0) {
		err(DEBUG_CAT_EPCS, "invliad mac address:%s\n", macstr);
		return -1;
	}

	if (MAC_ADDR_EQUAL(sta_mac, zero_mac)) {
		err(DEBUG_CAT_EPCS, "epcs request with zero client mac!\n");
		return -1;
	}

	memset(&peersta, 0, sizeof(peersta));
	memcpy(peersta.ifname, wdev->ifname, IFNAMSIZ);
	memcpy(peersta.mac, sta_mac, MAC_ADDR_LEN);

	authorized_sta = lookup_epcs_sta(sta_mac);
	if (authorized_sta && os_strncmp(cmd, "request", 7) == 0) {
		len = build_epcs_request(++epcs_req_tx_token, act_frm_buf, SEND_BUF_LEN);
		ret = wapp_drv_send_action_frame(
			MTK_NL80211_VENDOR_ATTR_SET_ACTION_QOS_ACTION_FRAME,
			wapp, wdev, 0, 0, sta_mac, act_frm_buf, len);
	} else if (authorized_sta && os_strncmp(cmd, "unsolicitedauthorize", 20) == 0) {
		peersta.state = STATE_EPCS_ENABLED;
		memcpy(peersta.wmmpe, g_wmmpe, sizeof(g_wmmpe));
		updated = update_epcs_list(&peersta);
		len = build_epcs_response(epcs_req_tx_token++, EPCS_STATUS_SUCCESS, act_frm_buf, SEND_BUF_LEN);
		wapp_drv_send_action_frame(MTK_NL80211_VENDOR_ATTR_SET_ACTION_QOS_ACTION_FRAME,
				wapp, wdev, 0, 0, sta_mac, act_frm_buf, len);
	} else if (authorized_sta && os_strncmp(cmd, "teardown", 8) == 0) {
		peersta.state = STATE_EPCS_TORNDOWN;
		updated = update_epcs_list(&peersta);

		len = build_epcs_teardown(act_frm_buf, SEND_BUF_LEN);
		ret = wapp_drv_send_action_frame(
			MTK_NL80211_VENDOR_ATTR_SET_ACTION_QOS_ACTION_FRAME,
			wapp, wdev, 0, 0, sta_mac, act_frm_buf, len);
	} else if (authorized_sta && os_strncmp(cmd, "remove", 5) == 0) {
		/* if the state is enabled send teardown frame first */
		if (authorized_sta->state == STATE_EPCS_ENABLED) {
			peersta.state = STATE_EPCS_TORNDOWN;
			updated = update_epcs_list(&peersta);

			len = build_epcs_teardown(act_frm_buf, SEND_BUF_LEN);
			ret = wapp_drv_send_action_frame(
				MTK_NL80211_VENDOR_ATTR_SET_ACTION_QOS_ACTION_FRAME,
				wapp, wdev, 0, 0, sta_mac, act_frm_buf, len);
		}
		remove_epcs_sta(sta_mac);
	} else if (!authorized_sta && os_strncmp(cmd, "authorize", 9) == 0) {
		peersta.state = STATE_EPCS_TORNDOWN;
		updated = update_epcs_list(&peersta);
		updated = 0; /* no need to sync state to driver here */
	} else
		err(DEBUG_CAT_EPCS, "invalid cmd:%s on %s STA:" MACSTR "\n",
			cmd, authorized_sta ? "authorized" : "not authorized", MAC2STR(sta_mac));

	if (updated)
		wapp_drv_sync_epcs_state(wapp, wdev->ifname, (char *)&peersta, sizeof(peersta));

	return ret;
}

int wapp_ctrl_epcs_wmmpe(struct wifi_app *wapp, const char *iface, char *cmd, char *reply, size_t *reply_len)
{
	int i = 0, ret = 0;
	char value[WMM_AC_NUM] = {0};
	char *keyword = NULL, *str_values = NULL;

	if (!iface || !cmd) {
		err(DEBUG_CAT_EPCS, "got NULL pointer, iface:%p, cmd:%p\n", iface, cmd);
		return -1;
	}

	keyword = strtok(cmd, "=");
	if (!keyword) {
		err(DEBUG_CAT_EPCS, "invalid cmd:%p\n", cmd);
		return -1;
	}

	str_values = strtok(NULL, "=");
	if (!str_values) {
		err(DEBUG_CAT_EPCS, "invalid values in cmd: %s\n", cmd);
		return -1;
	}

	str_values = strtok(str_values, ":");
	for (i = 0; (i < WMM_AC_NUM) && (str_values != NULL); i++) {
		value[i] = strtol(str_values, 0, 10);
		str_values = strtok(NULL, ":");
		if (str_values == NULL)
			break;
	}

	notice(DEBUG_CAT_EPCS, "%s, BE:%d, BK:%d, VI:%d, VO:%d\n",
		keyword, value[WMM_AC_BE], value[WMM_AC_BK], value[WMM_AC_VI], value[WMM_AC_VO]);

	if (os_strncmp(keyword, "ECWmin", 6) == 0) {
		g_wmmpe[WMM_AC_BE].cwmin = value[WMM_AC_BE];
		g_wmmpe[WMM_AC_BK].cwmin = value[WMM_AC_BK];
		g_wmmpe[WMM_AC_VI].cwmin = value[WMM_AC_VI];
		g_wmmpe[WMM_AC_VO].cwmin = value[WMM_AC_VO];
	} else if (os_strncmp(keyword, "ECWmax", 6) == 0) {
		g_wmmpe[WMM_AC_BE].cwmax = value[WMM_AC_BE];
		g_wmmpe[WMM_AC_BK].cwmax = value[WMM_AC_BK];
		g_wmmpe[WMM_AC_VI].cwmax = value[WMM_AC_VI];
		g_wmmpe[WMM_AC_VO].cwmax = value[WMM_AC_VO];
	} else if (os_strncmp(keyword, "AIFSN", 5) == 0) {
		g_wmmpe[WMM_AC_BE].aifsn = value[WMM_AC_BE];
		g_wmmpe[WMM_AC_BK].aifsn = value[WMM_AC_BK];
		g_wmmpe[WMM_AC_VI].aifsn = value[WMM_AC_VI];
		g_wmmpe[WMM_AC_VO].aifsn = value[WMM_AC_VO];
	} else if (os_strncmp(keyword, "TXOP", 4) == 0) {
		g_wmmpe[WMM_AC_BE].txop = value[WMM_AC_BE];
		g_wmmpe[WMM_AC_BK].txop = value[WMM_AC_BK];
		g_wmmpe[WMM_AC_VI].txop = value[WMM_AC_VI];
		g_wmmpe[WMM_AC_VO].txop = value[WMM_AC_VO];
	} else
		err(DEBUG_CAT_EPCS, "unknown wmm parameter:%s\n", keyword);

	return ret;
}

void wapp_eht_action_frame_receive(struct wifi_app *wapp,
	struct wapp_dev *wdev, u8 channel, u8 *peermac, u8 *frmbuf, u32 frmlen)
{
	struct epcs_sta peersta, *authorized_sta = NULL;
	u8 len = 0, *buf = NULL, category = 0, action = 0, token = 0, updated = 0;
	u16 status = 0;

	if (!wapp || !wdev || !peermac || !frmbuf)
		return;

	buf = frmbuf;

	category = GET_ACT_FRAME_CATEGORY(buf);
	action = GET_ACT_FRAME_ACTION(buf);
	if (category != CATEGORY_EHT_PROT_ACT ||
		((action != EPCS_REQUEST) && (action != EPCS_RESPONSE) && (action != EPCS_TEARDOWN))) {
		err(DEBUG_CAT_EPCS, "unknown action type, cat:%d, action:%d\n", category, action);
		return;
	}
	notice(DEBUG_CAT_EPCS,
		"EPCS: Received EPCS Action frame from "MACSTR" category=%u, action=%u, chan=%u, frmlen=%d\n",
		MAC2STR(peermac), category, action, channel, frmlen);

	token = GET_ACT_FRAME_TOKEN(buf);
	authorized_sta = lookup_epcs_sta(peermac);
	if (authorized_sta == NULL) {
		warn(DEBUG_CAT_EPCS, "not authorized sta: " MACSTR "\n", MAC2STR(peermac));
		if (action == EPCS_REQUEST) {
			len = build_epcs_response(token, EPCS_STATUS_DENIED_UNAUTHORIZED, act_frm_buf, SEND_BUF_LEN);
			wapp_drv_send_action_frame(MTK_NL80211_VENDOR_ATTR_SET_ACTION_QOS_ACTION_FRAME,
				wapp, wdev, 0, 0, peermac, act_frm_buf, len);
		} else {
			err(DEBUG_CAT_EPCS, "unexpected EPCS frame type: %d\n", action);
		}

		return;
	}

	memset(&peersta, 0, sizeof(peersta));
	memcpy(peersta.ifname, wdev->ifname, IFNAMSIZ);
	memcpy(peersta.mac, peermac, MAC_ADDR_LEN);
	if (action == EPCS_REQUEST) {
		peersta.state = STATE_EPCS_ENABLED;
		memcpy(peersta.wmmpe, g_wmmpe, sizeof(g_wmmpe));
		updated = update_epcs_list(&peersta);
		len = build_epcs_response(token, EPCS_STATUS_SUCCESS, act_frm_buf, SEND_BUF_LEN);
		wapp_drv_send_action_frame(MTK_NL80211_VENDOR_ATTR_SET_ACTION_QOS_ACTION_FRAME,
				wapp, wdev, 0, 0, peermac, act_frm_buf, len);
	} else if (action == EPCS_RESPONSE) {
		status = *((u16 *)&GET_ACT_FRAME_STATUS(buf));
		if (token == epcs_req_tx_token && status == EPCS_STATUS_SUCCESS) {
			peersta.state = STATE_EPCS_ENABLED;
			memcpy(peersta.wmmpe, g_wmmpe, sizeof(g_wmmpe));
			updated = update_epcs_list(&peersta);
		}
	} else if (action == EPCS_TEARDOWN) {
		peersta.state = STATE_EPCS_TORNDOWN;
		updated = update_epcs_list(&peersta);
	}
	if (updated)
		wapp_drv_sync_epcs_state(wapp, wdev->ifname, (char *)&peersta, sizeof(peersta));
}

void wapp_epcs_sta_leave_action(struct wifi_app *wapp, struct wapp_dev *wdev, u8 *stamac)
{
	u8 updated = 0;
	struct epcs_sta peersta, *authorized_sta = NULL;

	if (!wapp || !wdev || !stamac) {
		err(DEBUG_CAT_EPCS, "invalid pointer:wapp=%p, wdev=%p, stamac=%p\n", wapp, wdev, stamac);
		return;
	}

	authorized_sta = lookup_epcs_sta(stamac);
	if (authorized_sta == NULL)
		return;

	notice(DEBUG_CAT_EPCS, "epcs sta leave" MACSTR "\n", MAC2STR(stamac));

	if (authorized_sta->state == STATE_EPCS_ENABLED) {
		memset(&peersta, 0, sizeof(peersta));
		memcpy(peersta.ifname, wdev->ifname, IFNAMSIZ);
		memcpy(peersta.mac, stamac, MAC_ADDR_LEN);
		peersta.state = STATE_EPCS_TORNDOWN;
		updated = update_epcs_list(&peersta);
		if (updated)
			wapp_drv_sync_epcs_state(wapp, wdev->ifname, (char *)&peersta, sizeof(peersta));
	}
}

#endif /* EPCS_SUPPORT */
