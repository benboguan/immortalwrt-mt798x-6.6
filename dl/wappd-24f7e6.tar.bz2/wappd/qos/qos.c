/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2020-2021  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#include <stdlib.h>
#include <stdio.h>
#include <linux/netlink.h>

#include "os.h"
#include "debug.h"
#include "types.h"
#include "util.h"
#include "wapp_cmm.h"
#include "qos.h"
#include "driver_wext.h"
#include "mtk_vendor_nl80211.h"

#ifdef EPCS_SUPPORT
#include "epcs.h"
#endif

#ifdef QOS_R1

#ifndef MAC_ADDR_LEN
#define MAC_ADDR_LEN 6
#endif

#define QOS_MAP_RESET 0xFF

#define CMD_BUF_LEN 1024
#define SEND_BUF_LEN 1024

#define MIN(a, b) ((a < b) ? (a) : (b))

#define MAX_PAYLOAD 1562

static int netlink_sock = -1;
static int netlink_pid = 0;
struct nlmsghdr *g_nlmsghdr = NULL;

unsigned char cmd_buf[CMD_BUF_LEN] = {0};
unsigned char sendbuf[SEND_BUF_LEN] = {0};
unsigned char max_mscs_cfg_count = MAX_MSCS_CFG_CNT;
unsigned char max_scs_cfg_count = MAX_SCS_CFG_CNT;

struct qos_wifi_config qos_config;

unsigned char mscs_active_sta_cnt = 0;
struct dl_list mscs_cfg_list;

u8 ra_onoff = RADIO_ON;

#ifdef QOS_R2
u8 WFA_OUI[] = {0x50, 0x6F, 0x9A};

#define str_equal(s1, s2) ((strlen(s1) == strlen(s2)) && (strncmp(s1, s2, strlen(s2)) == 0))

unsigned char scs_active_sta_cnt = 0;
struct dl_list scs_cfg_list;

unsigned char dscp_policy_cnt = 0;
struct dl_list dscp_policy_list;

#define QOS_CONF_PATH "/etc/wapp_qos.cfg"

#define IPV4STR "%d.%d.%d.%d"
#define IPV6STR "%04x:%04x:%04x:%04x:%04x:%04x:%04x:%04x"

#define NIP4(addr) addr[0], addr[1], addr[2], addr[3]

#define NIP6(addr) \
	ntohs(addr[0]), \
	ntohs(addr[1]), \
	ntohs(addr[2]), \
	ntohs(addr[3]), \
	ntohs(addr[4]), \
	ntohs(addr[5]), \
	ntohs(addr[6]), \
	ntohs(addr[7])

#define IPV6_ADDR_LEN	16
#define IPV6_ADDR_EQUAL(Addr1, Addr2) (!memcmp((void *)(Addr1), (void *)(Addr2), IPV6_ADDR_LEN))

#endif

u8 zero_mac[] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
char g_bitmap[9] = {0};
unsigned char assoc_sta_cnt;
struct dl_list assoc_sta_list;

#ifdef MAP_R5

struct qos_management_descriptor_tlv qos_mgmt_desc_tlv;
struct qos_management_policy qos_black_list;

unsigned char qos_mgmt_descriptor_cnt;
struct dl_list qos_mgmt_descriptor_list;

struct dscp2pcp_mapping_table dscp2pcp;
#endif

unsigned int perflow_tuple_cnt;
struct dl_list perflow_tuple_list;

unsigned char pribss_list_cnt;
struct dl_list pribss_list;

unsigned char prista_list_cnt;
struct dl_list prista_list;

struct wapp_ctrl_cmd qos_cmd[] = {{"reset_default", qos_cmd_reset_default, "reset default (unconf)"},
				  {"qos_ap_set_config", qos_cmd_set_config, "set ap configuration"},
				  {"qos_ap_commit_config", qos_cmd_commit_config, "commit ap configuration"},
				  {"show_qos_config", qos_cmd_show_config, "show qos configuration"},
				  {"help", qos_cmd_show_help, "show this help"},
				  {NULL, qos_cmd_show_help, NULL}};

/* default qosmap sets for QoS R1/R2 certification. */
struct qos_map dft_qosmap_set[] = {
	{
		2, /* num */
		{[0] = {53, 2}, [1] = {22, 6}}, /* dscp exception */
		{{8, 15}, {0, 7}, {255, 255}, {16, 31}, {32, 39}, {255, 255}, {40, 47}, {255, 255}}, /* dscp range */
		{0, 0, 0, 0, 0, 0} /* STA Mac Address */
	},
	{
		0, /* num */
		{{0}}, /* dscp exception */
		{{8, 15}, {0, 7}, {255, 255}, {16, 31}, {32, 39}, {255, 255}, {40, 47}, {48, 63}}, /* dscp range */
		{0, 0, 0, 0, 0, 0} /* STA Mac Address */
	}
};

/* current applied qosmap setting */
u8 g_qosmap_up;
struct qos_map g_qosmap = {0};
int g_status_code = STATUS_SUCCESS;

struct index_string_tbl err_code_tbl[] = {
	{STATUS_SUCCESS,		"success"},
	{STATUS_INVALID_POINTER,	"invalid pointer"},
	{STATUS_INVALID_PARAM,		"invalid parameter"},
	{STATUS_INVALID_CMD_TYPE,	"invalid cmd type"},
	{STATUS_INVALID_ALMAC,		"invalid almac address"},
	{STATUS_INVALID_STAMAC,		"invalid stamac address"},
	{STATUS_INVALID_BSSID,		"invalid bssid address"},
	{STATUS_INVALID_ACTION,		"invalid action type"},
	{STATUS_INVALID_BITMAP,		"invalid bitmap"},
	{STATUS_INVALID_UP,		"invalid up"},
	{STATUS_INVALID_VERSION,	"invalid ip version"},
	{STATUS_INVALID_IP,		"invalid ip address"},
	{STATUS_INVALID_PORT,		"invalid port"},
	{STATUS_INVALID_PROTOCOL,	"invalid protocol"},
	{STATUS_INVALID_DIR,		"invalid direction"},
	{STATUS_INVALID_QOSCHAR,	"invalid qos characteristics parameter"},
	{STATUS_INVALID_DSCP_EXCEPTION, "invalid dscp exception"},
	{STATUS_INVALID_DSCP_RANGE,	"invalid dscp range"},
	{STATUS_INVALID_BUFLEN,		"invalid buffer length"},
	{STATUS_CFG_EXISTED,		"configuration is existed"},
	{STATUS_CFG_NOT_EXISTED,	"configuration is not existed"},
	{STATUS_CFG_IS_THE_SAME,	"configuration is the same"},
	{STATUS_ALLOC_MEM_FAIL,		"allocate memory fail"},
	{STATUS_INSUFFICIENT_PARAM,	"insufficient parameters"},
	{STATUS_NO_CLIENT_FOUND,	"no client found"},
	{STATUS_CMD_NOT_SUPPORT,	"command not support on this device"},
	{STATUS_INSUFFICIENT_RESOURCE,	"insufficient resource for request"},
	{STATUS_MEMORY_OVERFLOW,	"memory overflow"},
	{STATUS_INVALID_INDEX,		"invalid index"},
	{STATUS_INVALID_QOS_INDEX,	"invalid qos index"},
	{STATUS_INVALID_IP_TUPLE,	"invalid ip tuple"},
	{STATUS_NL_CMD_FAIL,		"send NL command fail"},
	{STATUS_INVALID_SSID_OR_BSSID,		"invalid ssid or bssid"},

	/*MSCS/SCS status code*/
	{STA_REQUEST_DECLINED,		"request declined"},
	{STA_INSUFFICIENT_RESOURCES,	"insufficient resources"},
	{STA_REQUESTED_NOT_SUPPORTED,	"request not supported"},
	{STA_RESOURCES_EXHAUSTED,	"resources exhausted"},
	{STA_TERMINATED,		"terminated"},
	{STA_TERMINATED_INSUFFICIENT_QOS, "terminated as insufficient resources"},
	{STA_TERMINATED_POLICY_CONFLICT,  "terminated as policy conflict"},

	{STATUS_UNKNOWN,		"unknown status"}
};

struct index_string_tbl ip_protocol_tbl[] = {
	{IP_TYPE_ICMP,		"ICMP"},
	{IP_TYPE_IGMP,		"IGMP"},
	{IP_TYPE_TCP,		"TCP"},
	{IP_TYPE_UDP,		"UDP"},
	{IP_TYPE_ESP,		"ESP"},
	{IP_TYPE_IGRP,		"IGRP"},
	{IP_TYPE_OSPF,		"OSPF"},
	{IP_TYPE_UNKNOWN,	"unknown type"}
};

struct qosidx_mapping qosidx_mapping_tbl[] = {
	/* qosidx,			service type,		priority,	up */
	{QOS_INDEX_VOICE,		"Voice",		"VO_1",		UP_6},
	{QOS_INDEX_GAME,		"Game",			"VO_2",		UP_6},
	{QOS_INDEX_VR,			"VR",			"VO_3",		UP_6},
	{QOS_INDEX_WFH_VIDEO,	"WFH_Video",	"VI_1",		UP_4},
	{QOS_INDEX_IPTV,		"IPTV",			"VI_1",		UP_4},
	{QOS_INDEX_VIDEO,		"Video",		"VI_2",		UP_4},
	{QOS_INDEX_BROWSE,		"Browse",		"BE",		UP_0},
	{QOS_INDEX_DOWNLOAD,	"Download",		"BK",		UP_1},
	{QOS_INDEX_MAX,			"unknown",		"",			0}
};

static int wapp_drv_send_netlink_msg(const unsigned char *message, unsigned int len, unsigned int dst_group);
static int set_qosmap_ie(struct wifi_app *wapp, const char *ifname, struct qos_map *qmap);
static int wapp_drv_send_event(unsigned char event, unsigned char *buf, unsigned int len);
static void qos_teardown_client(struct wifi_app *wapp, const char *ifname, u8 *climac);
static void clean_mscs_configuration(void);
#ifdef QOS_R2
static void clean_scs_configuration(void);
static void clean_dscp_policy(void);
static void parse_dscp_policy(char *str);
static void parse_scs_response(struct wifi_app *wapp, const char *ifname, char *str);
static int get_pmk_by_peer_mac(struct wifi_app *wapp, const char *ifname, u8 *peermac);
#endif

#ifdef MAP_R5
static int disallow_qos_check(unsigned char act_type, unsigned char *clientmac);
static void add_qos_mgmt_descriptor(struct qos_management_descriptor_db *qos_desc);
static void clean_qos_mgmt_descriptor(void);
static void map_send_tunnel_dscp_policy_action_frm(
	struct wifi_app *wapp, u8 *clientaddr, u8 *frmbuf, u32 frmlen, u8 frmtype);
#endif

char *err2str(int errcode)
{
	int i = 0, tblsize = 0;

	tblsize = ARRAY_SIZE(err_code_tbl);
	for (i = 0; i < tblsize; i++) {
		if (errcode == err_code_tbl[i].idx)
			return err_code_tbl[i].str;
	}

	return err_code_tbl[tblsize-1].str;
}

#ifdef MAP_6E_SUPPORT
unsigned char get_band_6E(struct wifi_app *wapp, unsigned char chan, unsigned char op)
{
	u8 radio_num = 0;
	int i = 0, is_6G = 0;

	for (i = 0; i < MAX_NUM_OF_RADIO; i++) {
		if (wapp->radio[i].adpt_id) {
			radio_num++;
			if (IS_MAP_CH_6G(wapp->radio[i].op_ch) &&
						IS_OP_CLASS_6G(wapp->radio[i].opclass))
				is_6G = 1;
		}
	}

	if (radio_num == 3 && is_6G == 1) {
		if (IS_MAP_CH_24G(chan) && IS_OP_CLASS_24G(op))
			return WPS_BAND_24G;
		else if (IS_MAP_CH_5G(chan) && IS_OP_CLASS_5G(op))
			return WPS_BAND_5GL;
		else if (IS_MAP_CH_6G(chan) && IS_OP_CLASS_6G(op))
			return WPS_BAND_6G;
	} else if (radio_num == 3 && is_6G == 0) {
		if (IS_MAP_CH_24G(chan) && IS_OP_CLASS_24G(op))
			return WPS_BAND_24G;
		else if (IS_MAP_CH_5GL(chan) && IS_OP_CLASS_5GL(op))
			return WPS_BAND_5GL;
		else if (IS_MAP_CH_5GH(chan) && IS_OP_CLASS_5GH(op))
			return WPS_BAND_5GH;
	} else {
		if (IS_MAP_CH_24G(chan) && IS_OP_CLASS_24G(op))
			return WPS_BAND_24G;
		else if (IS_MAP_CH_5G(chan) && IS_OP_CLASS_5G(op))
			return WPS_BAND_5GL;
		else if (IS_MAP_CH_6G(chan) && IS_OP_CLASS_6G(op))
			return WPS_BAND_6G;
	}

	return 0;
}
#endif

#ifdef MAP_R5
void map_reset_dscp2up_tbl(struct wifi_app *wapp, const char *iface)
{
	int ret = 0;

	ret = wapp->drv_ops->drv_reset_dscp2up_table(wapp->drv_data, iface, 1);
	if (ret < 0)
		err(DEBUG_CAT_QOS, "set reset_dscp2up_table failed.\n");
}
#endif

int qos_cmd_reset_default(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	struct wapp_dev *wdev = NULL;
	struct dl_list *dev_list = NULL;

	dev_list = &wapp->dev_list;
	dl_list_for_each(wdev, dev_list, struct wapp_dev, list) {
		if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
			set_qosmap_ie(wapp, wdev->ifname, NULL);
#ifdef MAP_R5
			map_reset_dscp2up_tbl(wapp, wdev->ifname);
#endif
		}
	}

	wapp_drv_send_event(NL_SET_QOS_MAP, NULL, 0);
	wapp_drv_send_event(NL_RESET_QOS_CONFIG, NULL, 0);
	memset(&qos_config, 0, sizeof(qos_config));

	clean_mscs_configuration();
#ifdef QOS_R2
	clean_scs_configuration();
	clean_dscp_policy();
#endif

	return 0;
}

u8 get_wireless_mode(char *strMode)
{
	if (os_strncmp(strMode, "11ng", 4) == 0)
		return PHY_11BGN_MIXED;
	else if (os_strncmp(strMode, "11bng", 5) == 0)
		return PHY_11BGN_MIXED;
	else if (os_strncmp(strMode, "11na", 4) == 0)
		return PHY_11AN_MIXED;

	return PHY_MODE_MAX;
}

static inline int str2num(char *str, int base)
{
	int num = 0;
	char *endptr = NULL;

	if (!str) {
		err(DEBUG_CAT_QOS, "str is NULL.\n");
		return -1;
	}

	errno = 0;
	num = strtol(str, &endptr, base);
	if (errno == ERANGE) {
		err(DEBUG_CAT_QOS, "%s is out of range.\n", str);
		return -2;
	} else if (*endptr != '\0' && *endptr != ' ') {
		warn(DEBUG_CAT_QOS, "it attempt to convert %s to number.*endptr:%c\n", str, *endptr);
		return -3;
	}

	return num;
}

static int set_qosmap_ie(struct wifi_app *wapp, const char *ifname, struct qos_map *qmap)
{
	struct qosmap_element *ie = NULL;
	char *buf, *pos;
	int ie_len = 0, varlen = 0, i = 0;
	int ret = 0, exc_cnt = 0;
	struct dscp_exception *pdscp_ex = NULL;
	struct dscp_range *pdscp_rg = NULL;

	if (qmap) {
		exc_cnt = qmap->num;
		pdscp_ex = qmap->dscp_ex;
		pdscp_rg = qmap->dscp_rg;

		debug(DEBUG_CAT_QOS, "exc_cnt:%d\n", exc_cnt);

		varlen = exc_cnt * 2;
		buf = os_zalloc(sizeof(*ie) + varlen);
		if (!buf) {
			err(DEBUG_CAT_QOS, ("memory is not available"));
			return -1;
		}

		ie = (struct qosmap_element *)buf;

		ie->eid = IE_QOS_R1_MAP_SET;
		ie_len += 1;

		pos = (char *)ie->dscp_range;

		/* dscp exception */
		for (i = 0; i < exc_cnt && i < MAX_EXCEPT_CNT; i++) {
			*pos = pdscp_ex[i].dscp;
			*(pos+1) = pdscp_ex[i].up;
			pos += 2;
			ie_len += 2;
		}

		/* dscp range */
		for (i = 0; i < UP_MAX; i++) {
			*pos = pdscp_rg[i].low;
			*(pos + 1) = pdscp_rg[i].high;
			pos += 2;
			ie_len += 2;
		}

		ie->length = ie_len - 1;
		ie_len += 1;
	} else {
		/*reset QoS Map setting.*/
		buf = os_zalloc(sizeof(*ie));
		if (!buf) {
			err(DEBUG_CAT_QOS, ("memory is not available"));
			return -1;
		}
		ie = (struct qosmap_element *)buf;

		ie->eid = IE_QOS_R1_MAP_SET;
		ie->length = 0;
		ie_len = 2;
	}

	ret = wapp_set_ie(wapp, ifname, buf, ie_len);
	os_free(buf);

	return ret;
}
#ifdef QOS_R2

/*
 * set radio on/off.
 * Channel: set the specified radio on/off by channel,
 * if channel=0, set all radio on/off.
 */
static inline void radio_on_off(struct wifi_app *wapp, u8 Channel, u8 onoff)
{
	struct wapp_dev *wdev = NULL, *wdev_temp = NULL;
	struct dl_list *dev_list = NULL;

	if (!wapp)
		return;

	dev_list = &wapp->dev_list;
	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
		if (wdev->radio) {
			if (Channel && (wdev->radio->op_ch != Channel))
				continue;

			wdev_set_radio_onoff(wapp, wdev, onoff);
		}
	}
}
#endif

/*
 * this function will parse commands from UCC script.
 */
int qos_cmd_set_config(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	/*	struct evt *wapp_event;*/
	char *keyword, *value/*, wirelessmode*/;
	int exc_cnt = 0, num = 0;
	struct dscp_exception *pdscp_ex = NULL;
	struct dscp_range *pdscp_rg = NULL;
	u8 mac[MAC_ADDR_LEN] = {0};
	u8 dft_qos_map_idx = 0;
#ifdef QOS_R2
	int ret = 0;
#endif

	if (!argv[1]) {
		err(DEBUG_CAT_QOS, "Invalid argument\n");
		return WAPP_INVALID_ARG;
	}

	debug(DEBUG_CAT_QOS, "%s, %s\n", iface, argv[1]);

	if (!iface || !strlen(iface)) {
		err(DEBUG_CAT_QOS, "Invalid iface\n");
		return WAPP_INVALID_ARG;
	}

	keyword = strtok(argv[1], "=");
	if (!keyword) {
		err(DEBUG_CAT_QOS, "keyword got NULL.\n");
		return WAPP_UNEXP;
	}
	value = strtok(NULL, "=");
	if (!value) {
		err(DEBUG_CAT_QOS, "value got NULL.\n");
		return WAPP_UNEXP;
	}
	if (os_strncmp(keyword, "radio", 5) == 0) {
		debug(DEBUG_CAT_QOS, "set radio: %s\n", value);
#ifdef QOS_R2
		if (os_strncmp(value, "off", 3) == 0) {
			ra_onoff = RADIO_OFF;
			radio_on_off(wapp, 0, RADIO_OFF);
		} else
			qos_cmd_commit_config(wapp, iface, 0, 0);
#endif
	} else if (os_strncmp(keyword, "channel", 7) == 0) {
		num = str2num(value, 10);
		if (num <= 0 || num > 0xFF)
			warn(DEBUG_CAT_QOS, "invalid channel:%s\n", value);
		else
			qos_config.channel = num;
	} else if (os_strncmp(keyword, "sta_mac", 7) == 0) {
		ret = convert_mac_addr(value, qos_config.stamac);
		if (ret != STATUS_SUCCESS)
			warn(DEBUG_CAT_QOS, "invalid stamac:%s\n", value);

		if (qos_config.qosmap_set == 1 || qos_config.qosmap_set == 2)
			dft_qos_map_idx = qos_config.qosmap_set - 1;
		else
			dft_qos_map_idx = 0;
		exc_cnt = dft_qosmap_set[dft_qos_map_idx].num;
		pdscp_ex = dft_qosmap_set[dft_qos_map_idx].dscp_ex;
		pdscp_rg = dft_qosmap_set[dft_qos_map_idx].dscp_rg;
		wapp_send_qos_map_configure_frame(wapp, iface, qos_config.channel, qos_config.stamac, pdscp_ex, exc_cnt, pdscp_rg);
	} else if (os_strncmp(keyword, "qos_map_set", 11) == 0) {
		num = str2num(value, 10);
		if (num < 0)
			warn(DEBUG_CAT_QOS, "invalid qos_map_set:%s\n", value);
		else
			qos_config.qosmap_set = num;

		if (ra_onoff == RADIO_OFF) {
			notice(DEBUG_CAT_QOS, "radio is off, postpond to set qos_map_set.\n");
		} else if (qos_config.qosmap_set == 1 || qos_config.qosmap_set == 2) {
			dft_qos_map_idx = qos_config.qosmap_set - 1;
			set_qosmap_ie(wapp, iface, &dft_qosmap_set[dft_qos_map_idx]);
			wapp_drv_send_event(NL_SET_QOS_MAP,
				(unsigned char *)&dft_qosmap_set[dft_qos_map_idx], sizeof(struct qos_map));
		}
	} else if (os_strncmp(keyword, "teardownclient", 14) == 0) {
		debug(DEBUG_CAT_QOS, "%s:%s\n", keyword, value);
		ret = convert_mac_addr(value, mac);
		if (ret != STATUS_SUCCESS)
			warn(DEBUG_CAT_QOS, "invalid teardownclient:%s\n", value);

		qos_teardown_client(wapp, iface, mac);
#ifdef QOS_R2
	} else if (os_strncmp(keyword, "dscppolicycapa", 14) == 0) {
		num = str2num(value, 10);
		if (num < 0)
			warn(DEBUG_CAT_QOS, "invalid dscppolicycapa:%s\n", value);
		else
			qos_config.dscppolicycapa = num;

		if (ra_onoff == RADIO_OFF) {
			notice(DEBUG_CAT_QOS, "radio is off, postpond to set dscppolicycapa.\n");
		} else {
			ret = wapp->drv_ops->drv_set_DSCPPolicyEnable(wapp->drv_data, iface, qos_config.dscppolicycapa);
			if (ret < 0)
				warn(DEBUG_CAT_QOS, "set DSCPPolicyEnable, command failed.\n");
			debug(DEBUG_CAT_QOS, "set DSCPPolicyEnable = %d\n", qos_config.dscppolicycapa);
		}
	} else if (os_strncmp(keyword, "qosmapcapa", 10) == 0) {
		num = str2num(value, 10);
		if (num < 0)
			warn(DEBUG_CAT_QOS, "invalid qosmapcapa:%s\n", value);
		else
			qos_config.qosmapcapa = num;

		if (ra_onoff == RADIO_OFF) {
			notice(DEBUG_CAT_QOS, "radio is off, postpond to set qosmapcapa.\n");
		} else {
			ret = wapp->drv_ops->drv_set_QosMapCapa(wapp->drv_data, iface, qos_config.qosmapcapa);
			if (ret < 0)
				warn(DEBUG_CAT_QOS, "set QosMapCapa, command failed.\n");
			debug(DEBUG_CAT_QOS, "set QosMapCapa = %d\n", qos_config.qosmapcapa);
		}
	} else if (os_strncmp(keyword, "DSCPPolicies", 12) == 0) {
		parse_dscp_policy(value);
	} else if (os_strcasecmp(keyword, "DSCPPolicyReq") == 0) {
		parse_dscp_policy_req(wapp, iface, value);
	} else if (os_strcasecmp(keyword, "SCSResp") == 0) {
		parse_scs_response(wapp, iface, value);
	} else if (os_strncmp(keyword, "PMK", 3) == 0) {
		ret = convert_mac_addr(value, mac);
		if (ret != STATUS_SUCCESS)
			warn(DEBUG_CAT_QOS, "invalid mac:%s\n", value);

		get_pmk_by_peer_mac(wapp, iface, mac);
	} else if (os_strncmp(keyword, "ReqCtrlReset", 12) == 0) {
		num = str2num(value, 10);
		if (num < 0) {
			warn(DEBUG_CAT_QOS, "invalid ReqCtrlReset:%s\n", value);
		} else
			qos_config.RequestCtrlReset = num;
#endif
	} else {
		err(DEBUG_CAT_QOS, "unknown param:%s\n", value);
	}

	return WAPP_SUCCESS;
}

int qos_cmd_commit_config(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	int ret = 0;

	debug(DEBUG_CAT_QOS, "%s, %s\n", iface, argv[1]);
	if (!iface || !strlen(iface)) {
		err(DEBUG_CAT_QOS, "Invalid iface\n");
		return WAPP_INVALID_ARG;
	}

#ifdef QOS_R2
	if (ra_onoff == RADIO_OFF) {
		radio_on_off(wapp, qos_config.channel, RADIO_ON);
		ra_onoff = RADIO_ON;
		sleep(5);
	}
#endif

	if (qos_config.dscppolicycapa) {
		ret = wapp->drv_ops->drv_set_DSCPPolicyEnable(wapp->drv_data, iface, qos_config.dscppolicycapa);
		if (ret < 0)
			warn(DEBUG_CAT_QOS, "set DSCPPolicyEnable, command failed.\n");
		debug(DEBUG_CAT_QOS, "set DSCPPolicyEnable = %d\n", qos_config.dscppolicycapa);
	}

	if (qos_config.qosmapcapa) {
		ret = wapp->drv_ops->drv_set_QosMapCapa(wapp->drv_data, iface, qos_config.qosmapcapa);
		if (ret < 0)
			warn(DEBUG_CAT_QOS, "set QosMapCapa, command failed.\n");
		debug(DEBUG_CAT_QOS, "set QosMapCapa = %d\n", qos_config.qosmapcapa);
	}
	if (qos_config.qosmap_set == 1 || qos_config.qosmap_set == 2) {
		set_qosmap_ie(wapp, iface, &dft_qosmap_set[qos_config.qosmap_set - 1]);
		wapp_drv_send_event(NL_SET_QOS_MAP,
			(unsigned char *)&dft_qosmap_set[qos_config.qosmap_set - 1], sizeof(struct qos_map));
	}

	return WAPP_SUCCESS;
}

char *dir2str(unsigned char dir)
{
	if (dir == DIR_UPLINK)
		return "UL";
	else if (dir == DIR_DOWNLINK)
		return "DL";
	else
		return "unknown";
}

char *protocol2str(int proto)
{
	int i = 0, tblsize = 0;

	tblsize = ARRAY_SIZE(ip_protocol_tbl);
	for (i = 0; i < tblsize; i++) {
		if (proto == ip_protocol_tbl[i].idx)
			return ip_protocol_tbl[i].str;
	}

	return ip_protocol_tbl[tblsize-1].str;
}

int fill_mscs_config(char *buf, int buflen)
{
	u8 i = 0;
	int offset = 0, ret = 0;
	struct mscs_configuration *mscscfg = NULL, *mscscfg_tmp = NULL;
	struct classifier_parameter *pConf = NULL;

	/*fill mscs configuration*/
	if (mscs_active_sta_cnt) {
		ret = snprintf(buf + offset, buflen - offset, "[wappd]---------MSCS Configuration---------\n");
		if (os_snprintf_error(buflen - offset, ret))
			goto exit;
		offset += ret;
		ret = snprintf(buf + offset, buflen - offset, "mscs active sta cnt: %d\n", mscs_active_sta_cnt);
		if (os_snprintf_error(buflen - offset, ret))
			goto exit;
		offset += ret;
		ret = snprintf(buf + offset, buflen - offset, " NO.        sta_mac	 request_type up_bitmap up_limit");
		if (os_snprintf_error(buflen - offset, ret))
			goto exit;
		offset += ret;
		ret = snprintf(buf + offset, buflen - offset, " timeout cs_type cs_mask\n");
		if (os_snprintf_error(buflen - offset, ret))
			goto exit;
		offset += ret;
		dl_list_for_each_safe(mscscfg, mscscfg_tmp, &mscs_cfg_list, struct mscs_configuration, list) {
			pConf = &mscscfg->csparam;
			ret = snprintf(buf + offset, buflen - offset, " %2d   " MACSTR " %7d	      0x%x %8d %8d  %5d      0x%x\n", i++,
				       MAC2STR(pConf->sta_mac), pConf->request_type, pConf->up_bitmap, pConf->up_limit, pConf->timeout,
				       pConf->cs.header.cs_type, pConf->cs.header.cs_mask);
			if (os_snprintf_error(buflen - offset, ret))
				goto exit;
			offset += ret;
		}
	}

exit:
	if (os_snprintf_error(buflen - offset, ret))
		err(DEBUG_CAT_QOS, "error happen, ret = %d\n", ret);

	return offset;
}

#ifdef QOS_R2
int fill_scs_config(char *buf, int buflen)
{
	u8 j = 0, k;
	int offset = 0, ret = 0;
	ptclas_element ptclas = NULL;
	struct scs_configuration *scscfg = NULL, *scscfg_tmp = NULL;
	struct scs_classifier_parameter *pScsTuple = NULL;
	char *srcIP = NULL, *dstIP = NULL;

	if (scs_active_sta_cnt) {
		ret = snprintf(buf + offset, buflen - offset, "[wappd]---------SCS Configuration---------\n");
		if (os_snprintf_error(buflen - offset, ret))
			goto exit;
		offset += ret;
		ret = snprintf(buf + offset, buflen - offset, "scs active sta cnt: %d\n", scs_active_sta_cnt);
		if (os_snprintf_error(buflen - offset, ret))
			goto exit;
		offset += ret;
		ret = snprintf(buf + offset, buflen - offset, " scsid	    sta_mac	   up alt_queue drop_elig processing\n");
		if (os_snprintf_error(buflen - offset, ret))
			goto exit;
		offset += ret;
		dl_list_for_each_safe(scscfg, scscfg_tmp, &scs_cfg_list, struct scs_configuration, list) {
			pScsTuple = &scscfg->scsparam;
			ret = snprintf(buf + offset, buflen - offset, " %3d   " MACSTR " %3d %5d %8d %10d", pScsTuple->scsid,
				       MAC2STR(pScsTuple->sta_mac), pScsTuple->up, pScsTuple->alt_queue, pScsTuple->drop_elig,
				       pScsTuple->processing);
			if (os_snprintf_error(buflen - offset, ret))
				goto exit;
			offset += ret;

			for (j = 0; (j < pScsTuple->tclas_num) && (j < MAX_TCLAS_NUM); j++) {
				ptclas = &pScsTuple->tclas_elem[j];
				if (ptclas->header.cs_type == CLASSIFIER_TYPE4) {
					ret = snprintf(buf + offset, buflen - offset,
						       " {type4, mask:0x%x, version:%d, srcP:%d, dstP:%d, dscp:%d,", ptclas->type4.cs_mask,
						       ptclas->type4.version, ntohs(ptclas->type4.srcPort), ntohs(ptclas->type4.destPort),
						       ptclas->type4.DSCP);
					if (os_snprintf_error(buflen - offset, ret))
						goto exit;
					offset += ret;

					if (ptclas->type4.version == VER_IPV4) {
						srcIP = (char *)&ptclas->type4.srcIp.ipv4;
						dstIP = (char *)&ptclas->type4.destIp.ipv4;
						ret = snprintf(buf + offset, buflen - offset,
							       "srcIP:" IPV4STR ", dstIP:" IPV4STR " protocol:%s},",
							       NIP4(srcIP), NIP4(dstIP),
							       protocol2str(ptclas->type4.u.protocol));
						if (os_snprintf_error(buflen - offset, ret))
							goto exit;
						offset += ret;
					} else {
						ret = snprintf(buf + offset, buflen - offset,
							       "srcIP:" IPV6STR ", dstIP:" IPV6STR ", proto/nxthd:%d,",
							       NIP6(ptclas->type4.srcIp.ipv6), NIP6(ptclas->type4.destIp.ipv6),
							       ptclas->type4.u.nextheader);
						if (os_snprintf_error(buflen - offset, ret))
							goto exit;
						offset += ret;
						ret = snprintf(buf + offset, buflen - offset, " flabel:0x%02x%02x%02x},",
							       ptclas->type4.flowLabel[0], ptclas->type4.flowLabel[1],
							       ptclas->type4.flowLabel[2]);
						if (os_snprintf_error(buflen - offset, ret))
							goto exit;
						offset += ret;
					}
				} else if (ptclas->header.cs_type == CLASSIFIER_TYPE10) {
					ret = snprintf(buf + offset, buflen - offset, " {type10, protoInst:%d, proto/nxthd:%d,",
						       ptclas->type10.protocolInstance, ptclas->type10.u.protocol);
					if (os_snprintf_error(buflen - offset, ret))
						goto exit;
					offset += ret;
					ret = snprintf(buf + offset, buflen - offset, " filterlen:%d, filterValue:0x",
						       ptclas->type10.filterlen);
					if (os_snprintf_error(buflen - offset, ret))
						goto exit;
					offset += ret;
					for (k = 0; (k < ptclas->type10.filterlen) && (k < MAX_FILTER_LEN); k++) {
						ret = snprintf(buf + offset, buflen - offset, "%02x", ptclas->type10.filterValue[k]);
						if (os_snprintf_error(buflen - offset, ret))
							goto exit;
						offset += ret;
					}
					ret = snprintf(buf + offset, buflen - offset, ", filterMask:0x");
					if (os_snprintf_error(buflen - offset, ret))
						goto exit;
					offset += ret;
					for (k = 0; (k < ptclas->type10.filterlen) && (k < MAX_FILTER_LEN); k++) {
						ret = snprintf(buf + offset, buflen - offset, "%02x", ptclas->type10.filterMask[k]);
						if (os_snprintf_error(buflen - offset, ret))
							goto exit;
						offset += ret;
					}
					ret = snprintf(buf + offset, buflen - offset, "},");
					if (os_snprintf_error(buflen - offset, ret))
						goto exit;
					offset += ret;
				}
			}

			/*show qos characteristics IE*/
			if (scscfg->qcharconfig.qchar_mask & QCHAR_MASK_DIR) {
				ret = snprintf(buf + offset, buflen - offset,
				       " {qoschar_dir,%s,", dir2str(scscfg->qcharconfig.dir));
				if (os_snprintf_error(buflen - offset, ret))
					goto exit;
				offset += ret;
			}
			if (scscfg->qcharconfig.qchar_mask & QCHAR_MASK_MIN_INTERVAL) {
				ret = snprintf(buf + offset, buflen - offset,
				       "qoschar_min_interval,%d,", scscfg->qcharconfig.min_interval);
				if (os_snprintf_error(buflen - offset, ret))
					goto exit;
				offset += ret;
			}
			if (scscfg->qcharconfig.qchar_mask & QCHAR_MASK_MAX_INTERVAL) {
				ret = snprintf(buf + offset, buflen - offset,
				       "qoschar_max_interval,%d,", scscfg->qcharconfig.max_interval);
				if (os_snprintf_error(buflen - offset, ret))
					goto exit;
				offset += ret;
			}
			if (scscfg->qcharconfig.qchar_mask & QCHAR_MASK_MIN_DATA_RATE) {
				ret = snprintf(buf + offset, buflen - offset,
				       "qoschar_min_datarate,%d,", scscfg->qcharconfig.min_datarate);
				if (os_snprintf_error(buflen - offset, ret))
					goto exit;
				offset += ret;
			}
			if (scscfg->qcharconfig.qchar_mask & QCHAR_MASK_DELAY_BOUND) {
				ret = snprintf(buf + offset, buflen - offset,
				       "qoschar_delaybound,%d},", scscfg->qcharconfig.delaybound);
				if (os_snprintf_error(buflen - offset, ret))
					goto exit;
				offset += ret;
			}

			ret = snprintf(buf + offset, buflen - offset, "\n");
			if (os_snprintf_error(buflen - offset, ret))
				goto exit;
			offset += ret;
		}
	}

exit:
	if (os_snprintf_error(buflen - offset, ret))
		err(DEBUG_CAT_QOS, "error happen, ret = %d\n", ret);

	return offset;
}

int fill_dscp_policy_config(char *buf, int buflen)
{
	int offset = 0, ret = 0;
	struct dscp_policy_db *dpolicy = NULL, *dpolicy_tmp = NULL;
	char *srcIP = NULL, *dstIP = NULL;

	if (dscp_policy_cnt) {
		ret = snprintf(buf + offset, buflen - offset, "[wappd]---------dscp policy---------\n");
		if (os_snprintf_error(buflen - offset, ret))
			goto exit;
		offset += ret;
		ret = snprintf(buf + offset, buflen - offset, " DSCP Policy cnt: %d\n", dscp_policy_cnt);
		if (os_snprintf_error(buflen - offset, ret))
			goto exit;
		offset += ret;
		ret = snprintf(buf + offset, buflen - offset, " PolicyID RequestType DSCP AttrID cs_type cs_mask version srcPort destPort");
		if (os_snprintf_error(buflen - offset, ret))
			goto exit;
		offset += ret;
		ret = snprintf(buf + offset, buflen - offset, " protocol     srcIp           destIp\n");
		if (os_snprintf_error(buflen - offset, ret))
			goto exit;
		offset += ret;
		dl_list_for_each_safe(dpolicy, dpolicy_tmp, &dscp_policy_list, struct dscp_policy_db, list) {
			ret = snprintf(buf + offset, buflen - offset, " %4d %8d %10d ", dpolicy->policyattri.policyid,
				       dpolicy->policyattri.request_type, dpolicy->policyattri.dscp);
			if (os_snprintf_error(buflen - offset, ret))
				goto exit;
			offset += ret;
			if (dpolicy->tclasattri.header.attrid == ATTR_ID_TCLAS) {
				ret = snprintf(buf + offset, buflen - offset, " %5d %6d     0x%x  %5d", dpolicy->tclasattri.header.attrid,
					       dpolicy->tclasattri.ipv4.cs_type, dpolicy->tclasattri.ipv4.cs_mask,
					       dpolicy->tclasattri.ipv4.version);
				if (os_snprintf_error(buflen - offset, ret))
					goto exit;
				offset += ret;
				if (dpolicy->tclasattri.ipv4.version == VER_IPV4) {
					srcIP = (char *)&dpolicy->tclasattri.ipv4.srcIp;
					dstIP = (char *)&dpolicy->tclasattri.ipv4.dstIp;
					ret = snprintf(buf + offset, buflen - offset, "  %6d %8d %7d       " IPV4STR "       " IPV4STR "",
						       ntohs(dpolicy->tclasattri.ipv4.srcPort), ntohs(dpolicy->tclasattri.ipv4.dstPort),
						       dpolicy->tclasattri.ipv4.protocol, NIP4(srcIP), NIP4(dstIP));
					if (os_snprintf_error(buflen - offset, ret))
						goto exit;
					offset += ret;
				} else if (dpolicy->tclasattri.ipv4.version == VER_IPV6) {
					ret = snprintf(buf + offset, buflen - offset, "  %6d %8d %7d   " IPV6STR "    " IPV6STR " ",
						       ntohs(dpolicy->tclasattri.ipv6.srcPort), ntohs(dpolicy->tclasattri.ipv6.dstPort),
						       dpolicy->tclasattri.ipv6.nextheader, NIP6(dpolicy->tclasattri.ipv6.srcIp),
						       NIP6(dpolicy->tclasattri.ipv6.dstIp));
					if (os_snprintf_error(buflen - offset, ret))
						goto exit;
					offset += ret;
				}
			} else if (dpolicy->domainattri.attrid == ATTR_ID_DOMAIN_NAME) {
				ret = snprintf(buf + offset, buflen - offset, " %5d    %s ", dpolicy->domainattri.attrid,
					       dpolicy->domainattri.domainname);
				if (os_snprintf_error(buflen - offset, ret))
					goto exit;
				offset += ret;
			} else if (dpolicy->portrange.attrid == ATTR_ID_PORT_RANGE && dpolicy->portrange.length == 4) {
				ret = snprintf(buf + offset, buflen - offset, " %5d    port_rg:[%d, %d] ", dpolicy->portrange.attrid,
					       ntohs(dpolicy->portrange.startp), ntohs(dpolicy->portrange.endp));
				if (os_snprintf_error(buflen - offset, ret))
					goto exit;
				offset += ret;
			}
			ret = snprintf(buf + offset, buflen - offset, "\n");
			if (os_snprintf_error(buflen - offset, ret))
				goto exit;
			offset += ret;
		}
	}

exit:
	if (os_snprintf_error(buflen - offset, ret))
		err(DEBUG_CAT_QOS, "error happen, ret = %d\n", ret);

	return offset;
}
#endif

#ifdef MAP_R5
int fill_mscs_scs_black_list(char *buf, int buflen)
{
	u8 i = 0;
	int offset = 0, ret = 0;

	if (qos_black_list.numMSCSDisallowed) {
		ret = snprintf(buf + offset, buflen - offset, "[wappd]---------MSCS Black List---------\n");
		if (os_snprintf_error(buflen - offset, ret))
			goto exit;
		offset += ret;
		ret = snprintf(buf + offset, buflen - offset, "NO.  \tSTA Mac Address\n");
		if (os_snprintf_error(buflen - offset, ret))
			goto exit;
		offset += ret;
		for (i = 0; i < qos_black_list.numMSCSDisallowed; i++) {
			ret = snprintf(buf + offset, buflen - offset, "%2d \t"MACSTR"\n",
				i, MAC2STR(qos_black_list.MSCSDisallowed[i]));
			if (os_snprintf_error(buflen - offset, ret))
				goto exit;
			offset += ret;
		}
	}

	if (qos_black_list.numSCSDisallowed) {
		ret = snprintf(buf + offset, buflen - offset, "[wappd]---------SCS Black List---------\n");
		if (os_snprintf_error(buflen - offset, ret))
			goto exit;
		offset += ret;
		ret = snprintf(buf + offset, buflen - offset, "NO.  \tSTA Mac Address\n");
		if (os_snprintf_error(buflen - offset, ret))
			goto exit;
		offset += ret;
		for (i = 0; i < qos_black_list.numSCSDisallowed; i++) {
			ret = snprintf(buf + offset, buflen - offset, "%2d \t"MACSTR"\n",
				i, MAC2STR(qos_black_list.SCSDisallowed[i]));
			if (os_snprintf_error(buflen - offset, ret))
				goto exit;
			offset += ret;
		}
	}

	if (qos_black_list.numMSCSDisallowed || qos_black_list.numSCSDisallowed) {
		ret = snprintf(buf + offset, buflen - offset,
			"[wappd] dscp_policy_en:%d\n", qos_black_list.dscp_policy_en);
		if (os_snprintf_error(buflen - offset, ret))
			goto exit;
		offset += ret;
		ret = snprintf(buf + offset, buflen - offset,
			"[wappd] dscp_to_up_en:%d\n", qos_black_list.dscp_to_up_en);
		if (os_snprintf_error(buflen - offset, ret))
			goto exit;
		offset += ret;
	}

exit:
	if (os_snprintf_error(buflen - offset, ret))
		err(DEBUG_CAT_QOS, "error happen, ret = %d\n", ret);

	return offset;
}
#endif

int fill_qosmap_config(char *buf, int buflen)
{
	u8 i = 0;
	int offset = 0, ret = 0;

	if (g_qosmap_up) {
		ret = snprintf(buf + offset, buflen - offset, "---------current applied qosmap setting---------\n");
		if (os_snprintf_error(buflen - offset, ret))
			goto exit;
		offset += ret;

		if (g_qosmap.num) {
			ret = snprintf(buf + offset, buflen - offset, "dscp_exception,");
			if (os_snprintf_error(buflen - offset, ret))
				goto exit;
			offset += ret;
		}
		for (i = 0; i < g_qosmap.num && i < MAX_EXCEPT_CNT; i++) {
			ret = snprintf(buf + offset, buflen - offset, "%d,%d,",
				g_qosmap.dscp_ex[i].dscp, g_qosmap.dscp_ex[i].up);
			if (os_snprintf_error(buflen - offset, ret))
				goto exit;
			offset += ret;
		}
		ret = snprintf(buf + offset, buflen - offset, "dscp_range,");
		if (os_snprintf_error(buflen - offset, ret))
			goto exit;
		offset += ret;

		for (i = 0; i < UP_MAX; i++) {
			ret = snprintf(buf + offset, buflen - offset, "%d,%d,",
				g_qosmap.dscp_rg[i].low, g_qosmap.dscp_rg[i].high);
			if (os_snprintf_error(buflen - offset, ret))
				goto exit;
			offset += ret;
		}

		ret = snprintf(buf + offset, buflen - offset, "\n");
		if (os_snprintf_error(buflen - offset, ret))
			goto exit;
		offset += ret;
	}

exit:
	if (os_snprintf_error(buflen - offset, ret))
		err(DEBUG_CAT_QOS, "error happen, ret = %d\n", ret);

	return offset;
}

int fill_ip_tuple_config(char *buf, int buflen)
{
	int offset = 0, ret = 0, i = 0;
	struct ip_tuple_db *pos = NULL, *pos_tmp = NULL;
	struct ip_tuple *ptuple = NULL;
	char *srcIP = NULL, *dstIP = NULL;

	if (perflow_tuple_cnt) {
		ret = snprintf(buf + offset, buflen - offset, "[wappd]---------ip tuple Configuration---------\n");
		if (os_snprintf_error(buflen - offset, ret))
			goto exit;
		offset += ret;
		ret = snprintf(buf + offset, buflen - offset, "ip tuple cnt: %d\n", perflow_tuple_cnt);
		if (os_snprintf_error(buflen - offset, ret))
			goto exit;
		offset += ret;

		dl_list_for_each_safe(pos, pos_tmp, &perflow_tuple_list, struct ip_tuple_db, list) {
			ptuple = &pos->node;
			ret = snprintf(buf + offset, buflen - offset, "%2d,cs_mask,0x%04x,qosidx,%d,up,%dsta_mac,"MACSTR",ipver,%d,",
					i++, ptuple->cs_mask, ptuple->qosidx, ptuple->up, MAC2STR(ptuple->sta_mac), ptuple->version);
			if (os_snprintf_error(buflen - offset, ret))
				goto exit;
			offset += ret;

			if (ptuple->version == VER_IPV4) {
				srcIP = (char *)&ptuple->srcIp.ipv4;
				dstIP = (char *)&ptuple->destIp.ipv4;
				ret = snprintf(buf + offset, buflen - offset,
					"srcip,"IPV4STR",dstip,"IPV4STR",srcport,%d,dstport,%d,protocol,%s",
					NIP4(srcIP), NIP4(dstIP), ntohs(ptuple->srcPort), ntohs(ptuple->destPort),
					protocol2str(ptuple->protocol));
				if (os_snprintf_error(buflen - offset, ret))
					goto exit;
				offset += ret;
			} else {
				ret = snprintf(buf + offset, buflen - offset,
					"srcip,"IPV6STR",dstip,"IPV6STR",srcport,%d,dstport,%d,protocol,%s",
					NIP6(ptuple->srcIp.ipv6), NIP6(ptuple->destIp.ipv6),
					ntohs(ptuple->srcPort), ntohs(ptuple->destPort), protocol2str(ptuple->protocol));
				if (os_snprintf_error(buflen - offset, ret))
					goto exit;
				offset += ret;
			}
			ret = snprintf(buf + offset, buflen - offset, "\n");
			if (os_snprintf_error(buflen - offset, ret))
				goto exit;
			offset += ret;
		}
	}

exit:
	if (os_snprintf_error(buflen - offset, ret))
		err(DEBUG_CAT_QOS, "error happen, ret = %d\n", ret);

	return offset;
}

int fill_bss_priority_config(char *buf, int buflen)
{
	int offset = 0, ret = 0, i = 0;
	struct priority_bss_db *pribss = NULL;

	if (pribss_list_cnt > 0) {
		ret = snprintf(buf + offset, buflen - offset,
			"\n--------priority bss configuration count:%u-------\n", pribss_list_cnt);
		if (os_snprintf_error(buflen - offset, ret))
			goto exit;
		offset += ret;

		dl_list_for_each(pribss, &pribss_list, struct priority_bss_db, list) {
			ret = snprintf(buf + offset, buflen - offset, "%2d.  ifname:%s, ssid:%s, bssid:" MACSTR " up:%u\n",
					i++, pribss->node.ifname, pribss->node.ssid, MAC2STR(pribss->node.bssid), pribss->node.up);
			if (os_snprintf_error(buflen - offset, ret))
				goto exit;
			offset += ret;
		}
	}

exit:
	if (os_snprintf_error(buflen - offset, ret))
		err(DEBUG_CAT_QOS, "error happen, ret = %d\n", ret);

	return offset;
}

int fill_sta_priority_config(char *buf, int buflen)
{
	int offset = 0, ret = 0, i = 0;
	struct priority_sta_db *prista = NULL;

	if (prista_list_cnt > 0) {
		ret = snprintf(buf + offset, buflen - offset,
			"\n--------priority sta configuration count:%u-------\n", prista_list_cnt);
		if (os_snprintf_error(buflen - offset, ret))
			goto exit;
		offset += ret;

		dl_list_for_each(prista, &prista_list, struct priority_sta_db, list) {
			ret = snprintf(buf + offset, buflen - offset, "%2d.  sta_mac:"MACSTR", qosidx:%u, up:%u\n",
					i++, MAC2STR(prista->node.sta_mac), prista->node.qosidx, prista->node.up);
			if (os_snprintf_error(buflen - offset, ret))
				goto exit;
			offset += ret;
		}
	}

exit:
	if (os_snprintf_error(buflen - offset, ret))
		err(DEBUG_CAT_QOS, "error happen, ret = %d\n", ret);

	return offset;
}

int fill_misc_info(char *buf, int buflen)
{
	u8 i = 0;
	int offset = 0, ret = 0;
	struct associated_sta_info_db *pos = NULL;

	if (assoc_sta_cnt > 0) {
		ret = snprintf(buf + offset, buflen - offset, "\n--------associated sta list count:%u-------\n", assoc_sta_cnt);
		if (os_snprintf_error(buflen - offset, ret))
			goto exit;
		offset += ret;

		i = 0;
		dl_list_for_each(pos, &assoc_sta_list, struct associated_sta_info_db, list) {
			ret = snprintf(buf + offset, buflen - offset, "%2d \t"MACSTR"\n", ++i, MAC2STR(pos->src));
			if (os_snprintf_error(buflen - offset, ret))
				goto exit;
			offset += ret;
		}
	}

	ret = snprintf(buf + offset, buflen - offset, "\n--------max_mscs_cfg_count:%u, max_scs_cfg_count:%u-------\n",
		max_mscs_cfg_count, max_scs_cfg_count);
	if (os_snprintf_error(buflen - offset, ret))
		goto exit;
	offset += ret;

exit:
	if (os_snprintf_error(buflen - offset, ret))
		err(DEBUG_CAT_QOS, "error happen, ret = %d\n", ret);

	return offset;
}

int qos_cmd_show_config(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	char *buf = NULL, *output = NULL;
	int buflen = 10240, ret = 0, len = 0;
	FILE *f = NULL;

	buf = os_malloc(buflen);
	if (!buf) {
		err(DEBUG_CAT_QOS, "memory alloc fail.\n");
		return -1;
	}

	memset(buf, 0, buflen);
	output = buf;

	/*fill mscs configuration*/
	len = fill_mscs_config(output, buflen);
	output += len;
	buflen -= len;

#ifdef QOS_R2
	/*fill scs configuration*/
	len = fill_scs_config(output, buflen);
	output += len;
	buflen -= len;

	/*fill dscp policy configuration*/
	len = fill_dscp_policy_config(output, buflen);
	output += len;
	buflen -= len;
#endif

#ifdef MAP_R5
	/*fill mscs/scs black list*/
	len = fill_mscs_scs_black_list(output, buflen);
	output += len;
	buflen -= len;
#endif

	/*fill configured qosmap setting*/
	len = fill_qosmap_config(output, buflen);
	output += len;
	buflen -= len;

	/* fill ip tuple config */
	len = fill_ip_tuple_config(output, buflen);
	output += len;
	buflen -= len;

	/* fill priority bss configuration*/
	len = fill_bss_priority_config(output, buflen);
	output += len;
	buflen -= len;

	/* fill priority sta configuration*/
	len = fill_sta_priority_config(output, buflen);
	output += len;
	buflen -= len;

	/* fill other misc information, such as associated STAs, max mscs/scs count*/
	len = fill_misc_info(output, buflen);
	output += len;
	buflen -= len;

	if (strlen(buf)) {
		printf("\n%s\n", buf);

		/* write log file to temp file*/
		f = fopen("/tmp/wappqoscfg.log", "w");
		if (f == NULL)
			goto exit1;
		ret = fwrite(buf, 1, strlen(buf), f);
		if (strlen(buf) != ret)
			err(DEBUG_CAT_QOS, "write error");

		ret = fclose(f);
		if (ret != 0)
			err(DEBUG_CAT_QOS, "fclose fail.\n");
	} else {
		err(DEBUG_CAT_QOS, "no qos configuration.\n");
	}

exit1:
	if (buf)
		os_free(buf);

	return 0;
}

int qos_ctrl_interface_cmd_handle(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	int i, ret;

	if (!argv[0]) {
		err(DEBUG_CAT_QOS, "Invalid argument\n");
		return WAPP_INVALID_ARG;
	}

	for (i = 0; i < ARRAY_SIZE(qos_cmd) && qos_cmd[i].cmd != NULL; i++) {
		if (os_strncmp(qos_cmd[i].cmd, argv[0], os_strlen(argv[0])) == 0) {
			ret = qos_cmd[i].cmd_proc(wapp, iface, argc, argv);
			if (ret != WAPP_SUCCESS)
				err(DEBUG_CAT_QOS, "cmd [%s] failed. ret = %d\n", qos_cmd[i].cmd, ret);
			break;
		}
	}

	return WAPP_SUCCESS;
}

int qos_cmd_show_help(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	u8 i = 0;

	printf("\033[1;36m available cmds: \033[0m\n");
	for (i = 0; (qos_cmd[i].cmd != NULL); i++) {
		printf("\033[1;36m %20s  \t -  %s\033[0m\n", qos_cmd[i].cmd, qos_cmd[i].help);
	}

	return WAPP_SUCCESS;
}

int wapp_ctrl_iface_cmd_qos(struct wifi_app *wapp, const char *iface, char *param_value_pair, char *reply, size_t *reply_len)
{
	int ret = 0; //, i = 0;
	struct wapp_conf *conf;
	int is_found = 0;
	char *token;
	u8 argc = 0;
	char *argv[10] = {0};

	dl_list_for_each(conf, &wapp->conf_list, struct wapp_conf, list) {
		if (os_strcmp(conf->iface, iface) == 0) {
			is_found = 1;
			break;
		}
	}

	if (!is_found) {
		if (wapp_dev_list_lookup_by_ifname(wapp, iface) == NULL) {
			err(DEBUG_CAT_QOS, "can not find configuration for interface(%s)\n", iface);
			return -1;
		}
	}

	/* for now, it always has 4 argc, due to the format of the source msg */
	token = strtok(param_value_pair, " ");
	while (token != NULL && argc < 10) {
		argv[argc] = token;
		argc++;
		token = strtok(NULL, " ");
	}

	qos_ctrl_interface_cmd_handle(wapp, iface, argc, argv);

	return ret;
}

int wapp_drv_qos_init(struct wifi_app *wapp)
{
	struct sockaddr_nl addr;

	g_qosmap_up = 0;

	mscs_active_sta_cnt = 0;
	dl_list_init(&mscs_cfg_list);
#ifdef QOS_R2
	scs_active_sta_cnt = 0;
	dl_list_init(&scs_cfg_list);

	dscp_policy_cnt = 0;
	dl_list_init(&dscp_policy_list);
#endif

#ifdef MAP_R5
	memset(&qos_black_list, 0, sizeof(qos_black_list));
	memset(&dscp2pcp, 0, sizeof(dscp2pcp));

	qos_mgmt_descriptor_cnt = 0;
	dl_list_init(&qos_mgmt_descriptor_list);

#endif
	assoc_sta_cnt = 0;
	dl_list_init(&assoc_sta_list);

	perflow_tuple_cnt = 0;
	dl_list_init(&perflow_tuple_list);

	pribss_list_cnt = 0;
	dl_list_init(&pribss_list);

	prista_list_cnt = 0;
	dl_list_init(&prista_list);

	netlink_sock = socket(AF_NETLINK, SOCK_RAW, QOS_NETLINK_EXT);
	if (netlink_sock < 0) {
		err(DEBUG_CAT_QOS, "create sock failed.\n");
		return -1;
	}
	netlink_pid = getpid();

	/*1. initial nlmsg structure for sending*/
	memset((void *)&addr, 0, sizeof(addr));
	addr.nl_family = AF_NETLINK;
	addr.nl_pid = netlink_pid;
	addr.nl_groups = 0;

	if (bind(netlink_sock, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
		err(DEBUG_CAT_QOS, "bind netlink_sock failed.\n");
		close(netlink_sock);
		return -1;
	}

	/*2. initial nlmsg structure for recieving*/
	g_nlmsghdr = (struct nlmsghdr *)malloc(NLMSG_SPACE(MAX_PAYLOAD));
	if (!g_nlmsghdr) {
		err(DEBUG_CAT_QOS, "malloc nlmsghdr error!\n");
		close(netlink_sock);
		return -1;
	}

	memset(g_nlmsghdr, 0, NLMSG_SPACE(MAX_PAYLOAD));
	g_nlmsghdr->nlmsg_len = NLMSG_SPACE(MAX_PAYLOAD);
	g_nlmsghdr->nlmsg_pid = netlink_pid;
	g_nlmsghdr->nlmsg_flags = 0;

	eloop_register_read_sock(netlink_sock, mtqos_event_handler, wapp, NULL);

	load_qos_config(wapp);

	return 0;
}

int wapp_drv_qos_deinit(struct wifi_app *wapp)
{
	memset(&qos_config, 0, sizeof(qos_config));
	wapp_drv_send_event(NL_SET_QOS_MAP, NULL, 0);
	wapp_drv_send_event(NL_RESET_QOS_CONFIG, NULL, 0);
	clean_mscs_configuration();
#ifdef QOS_R2
	clean_scs_configuration();
	clean_dscp_policy();
#endif

#ifdef MAP_R5
	clean_qos_mgmt_descriptor();
	clean_assoc_sta_list();
#endif

	clean_iptuple_list();
	clean_bss_priority_list();
	clean_sta_priority_list();

	eloop_unregister_read_sock(netlink_sock);
	close(netlink_sock);
	if (g_nlmsghdr)
		free(g_nlmsghdr);

	return 0;
}

/*
 * send netlink msg to mtqos module
 */
static int wapp_drv_send_netlink_msg(const unsigned char *message, unsigned int len, unsigned int dst_group)
{
	struct nlmsghdr *nlh = NULL;
	struct sockaddr_nl dest_addr;
	struct iovec iov;
	struct msghdr msg;

	if (!message) {
		err(DEBUG_CAT_QOS, "ntlink message is null.\n");
		return -1;
	}

	// create message
	nlh = (struct nlmsghdr *)os_malloc(NLMSG_SPACE(len));
	if (!nlh) {
		err(DEBUG_CAT_QOS, "allocate nlmsghdr fail\n");
		return -1;
	}
	nlh->nlmsg_len = NLMSG_SPACE(len);
	nlh->nlmsg_pid = netlink_pid;
	nlh->nlmsg_flags = 0;
	os_memcpy(NLMSG_DATA(nlh), message, len);

	iov.iov_base = (void *)nlh;
	iov.iov_len = nlh->nlmsg_len;
	os_memset(&dest_addr, 0, sizeof(struct sockaddr_nl));
	dest_addr.nl_family = AF_NETLINK;
	dest_addr.nl_pid = 0;
	dest_addr.nl_groups = dst_group;

	os_memset(&msg, 0, sizeof(struct msghdr));
	msg.msg_name = (void *)&dest_addr;
	msg.msg_namelen = sizeof(struct sockaddr_nl);
	msg.msg_iov = &iov;
	msg.msg_iovlen = 1;

	// send message
	if (sendmsg(netlink_sock, &msg, 0) < 0) {
		err(DEBUG_CAT_QOS, "netlink msg send fail\n");
		os_free(nlh);
		return -3;
	}

	os_free(nlh);
	return 0;
}

static int wapp_drv_send_event(unsigned char event, unsigned char *buf, unsigned int len)
{
	int ret = 0;
	struct qos_netlink_message *msg = (struct qos_netlink_message *)cmd_buf;

	if ((sizeof(struct qos_netlink_message) + len) > CMD_BUF_LEN) {
		err(DEBUG_CAT_QOS, "fail to send event, len=%d\n", len);
		return -1;
	}

	msg->type = event;
	msg->len = len;
	if (buf)
		os_memcpy(&msg->data[0], buf, len);

	ret = wapp_drv_send_netlink_msg(cmd_buf, sizeof(struct qos_netlink_message) + len, 0);
	return ret;
}

int wapp_drv_send_action_frame(unsigned short sub_cmd_id, struct wifi_app *wapp, struct wapp_dev *wdev, unsigned int chan,
			       unsigned int wait, const u8 *dst, const u8 *data, size_t len)
{
	static u16 seq_no = 0;

	if (!wdev) {
		err(DEBUG_CAT_QOS, "wdev is null\n");
		return -1;
	}

	if (chan == 0) {
		chan = wdev->radio->op_ch;
	}
	if (!wapp->drv_ops || !wapp->drv_ops->send_action)
		return 0;

	notice(DEBUG_CAT_QOS, "send action frame to " MACSTR " seq_no =%u, chan=%u\n", MAC2STR(dst), seq_no++, chan);

	return wapp->drv_ops->send_action(sub_cmd_id, wapp->drv_data, wdev->ifname, chan, wait, dst, wdev->mac_addr, wdev->mac_addr, data,
					  len, seq_no, 0);
}

u8 update_mscs_configuration(struct wifi_app *wapp, struct classifier_parameter *cs_param)
{
	u8 sta_code = STA_SUCCESS, existed = 0, delete_idx = 0;
	struct mscs_configuration *mscscfg = NULL, *mscscfg_tmp = NULL;

	dl_list_for_each_safe(mscscfg, mscscfg_tmp, &mscs_cfg_list, struct mscs_configuration, list) {
		if (MAC_ADDR_EQUAL(mscscfg->csparam.sta_mac, cs_param->sta_mac)) {
			existed = 1;
			if (cs_param->request_type == REQUEST_TYPE_ADD) {
				sta_code = STA_REQUEST_DECLINED;
				warn(DEBUG_CAT_QOS, "MSCS config was existed for "MACSTR"\n", MAC2STR(cs_param->sta_mac));
			} else if (cs_param->request_type == REQUEST_TYPE_CHANGE) {
				/*overwrite setting*/
				memcpy(&mscscfg->csparam, cs_param, sizeof(*cs_param));
				sta_code = STA_SUCCESS;
			} else if (cs_param->request_type == REQUEST_TYPE_REMOVE) {
				delete_idx = mscscfg->index;

				/*remove setting*/
				dl_list_del(&mscscfg->list);
				os_free(mscscfg);
				if (mscs_active_sta_cnt)
					mscs_active_sta_cnt--;
				sta_code = STA_TERMINATED;
			} else {
				sta_code = STA_REQUEST_DECLINED;
				err(DEBUG_CAT_QOS, "unknown MSCS request type: %u\n", cs_param->request_type);
			}
			break;
		}
	}

	if (!existed) {
		if (cs_param->request_type == REQUEST_TYPE_ADD) {
			if (mscs_active_sta_cnt < max_mscs_cfg_count) {
				mscscfg = (struct mscs_configuration *)os_zalloc(sizeof(struct mscs_configuration));
				if (mscscfg) {
					mscscfg->index = mscs_active_sta_cnt + 1;
					memcpy(&mscscfg->csparam, cs_param, sizeof(*cs_param));
					/*add setting*/
					dl_list_add_tail(&mscs_cfg_list, &mscscfg->list);
					mscs_active_sta_cnt++;
					sta_code = STA_SUCCESS;
				} else {
					err(DEBUG_CAT_QOS, "Memory Alloc Fail.\n");
					sta_code = STA_INSUFFICIENT_RESOURCES;
				}
			} else {
				sta_code = STA_INSUFFICIENT_RESOURCES;
				warn(DEBUG_CAT_QOS, "The SCS STA Count arrived max %u.\n", max_mscs_cfg_count);
			}
		} else {
			sta_code = STA_REQUEST_DECLINED;
			warn(DEBUG_CAT_QOS, "unknown MSCS request type: %u\n", cs_param->request_type);
		}
	}

	if (delete_idx) {
		/*re-arrange the index of list*/
		dl_list_for_each_safe(mscscfg, mscscfg_tmp, &mscs_cfg_list, struct mscs_configuration, list) {
			if (mscscfg->index > delete_idx)
				mscscfg->index--;
		}
	}

	return sta_code;
}

static void clean_mscs_configuration(void)
{
	struct mscs_configuration *mscscfg, *mscscfg_tmp;

	if (mscs_active_sta_cnt > 0) {
		dl_list_for_each_safe(mscscfg, mscscfg_tmp, &mscs_cfg_list, struct mscs_configuration, list) {
			dl_list_del(&mscscfg->list);
			os_free(mscscfg);
		}
		mscs_active_sta_cnt = 0;
	}
}

#ifdef QOS_R3
int wapp_drv_set_qos_characteristics_ie(struct wifi_app *wapp, const char *ifname, char *buf, u32 buflen)
{
	if (!wapp->drv_ops || !wapp->drv_ops->drv_set_qos_characteristics_ie)
		return 0;

	return wapp->drv_ops->drv_set_qos_characteristics_ie(wapp->drv_data, ifname, buf, buflen);
}
#endif

#ifdef QOS_R2
u8 update_scs_configuration(struct wifi_app *wapp, struct scs_configuration *pscs)
{
	u8 sta_code = STA_SUCCESS, existed = 0;
	struct scs_configuration *scscfg = NULL, *scscfg_tmp = NULL;
	struct scs_classifier_parameter *pscsparam = NULL;

	if (!wapp || !pscs)
		return STA_REQUEST_DECLINED;

	pscsparam = &pscs->scsparam;

	dl_list_for_each_safe(scscfg, scscfg_tmp, &scs_cfg_list, struct scs_configuration, list) {
		if (MAC_ADDR_EQUAL(scscfg->scsparam.sta_mac, pscsparam->sta_mac) &&
			(scscfg->scsparam.scsid == pscsparam->scsid)) {
			existed = 1;
			if (pscsparam->request_type == REQUEST_TYPE_ADD) {
				sta_code = STA_REQUEST_DECLINED;
				warn(DEBUG_CAT_QOS, "SCS config was existed,"MACSTR",scsid:%u\n",
					MAC2STR(pscsparam->sta_mac), pscsparam->scsid);
			} else if (pscsparam->request_type == REQUEST_TYPE_CHANGE) {
				/*overwrite setting*/
				memcpy(&scscfg->scsparam, &pscs->scsparam, sizeof(pscs->scsparam));
				memcpy(&scscfg->qchar, &pscs->qchar, sizeof(pscs->qchar));
				memcpy(&scscfg->qcharconfig, &pscs->qcharconfig, sizeof(pscs->qcharconfig));

				sta_code = STA_SUCCESS;
			} else if (pscsparam->request_type == REQUEST_TYPE_REMOVE) {
				/*remove setting*/
				dl_list_del(&scscfg->list);
				os_free(scscfg);
				if (scs_active_sta_cnt)
					scs_active_sta_cnt--;
				sta_code = STA_TERMINATED;
			} else {
				sta_code = STA_REQUEST_DECLINED;
				err(DEBUG_CAT_QOS, "unknown SCS request type: %u\n", pscsparam->request_type);
			}
			break;
		}
	}

	if (!existed) {
		if (pscsparam->request_type == REQUEST_TYPE_ADD) {
			if (scs_active_sta_cnt < max_scs_cfg_count) {
				scscfg = (struct scs_configuration *)os_zalloc(sizeof(struct scs_configuration));
				if (scscfg) {
					scscfg->index = scs_active_sta_cnt + 1;

					memcpy(&scscfg->scsparam, &pscs->scsparam, sizeof(pscs->scsparam));
					memcpy(&scscfg->qchar, &pscs->qchar, sizeof(pscs->qchar));
					memcpy(&scscfg->qcharconfig, &pscs->qcharconfig, sizeof(pscs->qcharconfig));

					/*add setting*/
					dl_list_add_tail(&scs_cfg_list, &scscfg->list);
					scs_active_sta_cnt++;
					sta_code = STA_SUCCESS;
				} else {
					err(DEBUG_CAT_QOS, "Memory Alloc Fail.\n");
					sta_code = STA_INSUFFICIENT_RESOURCES;
				}
			} else {
				sta_code = STA_INSUFFICIENT_RESOURCES;
				warn(DEBUG_CAT_QOS, "The SCS STA Count arrived max %u.\n", max_scs_cfg_count);
			}
		} else {
			sta_code = STA_REQUEST_DECLINED;
			err(DEBUG_CAT_QOS, "unknown SCS request type: %u\n", pscsparam->request_type);
		}
	}

	return sta_code;
}

static inline int compare_classifier_type4(struct classifier_type4 *ptype4_1, struct classifier_type4 *ptype4_2)
{
	unsigned char mask;

	if (!ptype4_1 || !ptype4_2)
		return -1;

	mask = ptype4_1->cs_mask;
	if ((mask & TYPE4_CS_MASK_VERSION) && (ptype4_1->version != ptype4_2->version))
		return 0;

	if (ptype4_1->version == VER_IPV4) {
		if (mask & TYPE4_CS_MASK_SRC_IP) {
			if (ptype4_1->srcIp.ipv4 != ptype4_2->srcIp.ipv4)
				return 0;
		}
		if (mask & TYPE4_CS_MASK_DST_IP) {
			if (ptype4_1->destIp.ipv4 != ptype4_2->destIp.ipv4)
				return 0;
		}
		if (mask & TYPE4_CS_MASK_PROTOCOL) {
			if (ptype4_1->u.protocol != ptype4_2->u.protocol)
				return 0;
		}
	}

	if (ptype4_1->version == VER_IPV6) {
		if (mask & TYPE4_CS_MASK_SRC_IP) {
			if (!IPV6_ADDR_EQUAL(ptype4_1->srcIp.ipv6, ptype4_2->srcIp.ipv6))
				return 0;
		}
		if (mask & TYPE4_CS_MASK_DST_IP) {
			if (!IPV6_ADDR_EQUAL(ptype4_1->destIp.ipv6, ptype4_2->destIp.ipv6))
				return 0;
		}
		if (mask & TYPE4_CS_MASK_NXT_HEAD) {
			if (ptype4_1->u.nextheader != ptype4_2->u.nextheader)
				return 0;
		}
		if (mask & TYPE4_CS_MASK_FLOW_LABEL) {
			if (memcmp(ptype4_1->flowLabel, ptype4_2->flowLabel, 3))
				return 0;
		}
	}
	if (mask & TYPE4_CS_MASK_SRC_PORT) {
		if (ptype4_1->srcPort != ptype4_2->srcPort)
			return 0;
	}
	if (mask & TYPE4_CS_MASK_DST_PORT) {
		if (ptype4_1->destPort != ptype4_2->destPort)
			return 0;
	}
	if (mask & TYPE4_CS_MASK_DSCP) {
		if (ptype4_1->DSCP != ptype4_2->DSCP)
			return 0;
	}

	/*all parameters are matched*/
	return 1;
}

static inline int compare_qoschar_config(struct qoschar_user_setting *pqchar_1, struct qoschar_user_setting *pqchar_2)
{
	unsigned char mask;

	if (!pqchar_1 || !pqchar_2)
		return -1;

	mask = pqchar_1->qchar_mask;
	if ((mask & QCHAR_MASK_DIR) && (pqchar_1->dir != pqchar_2->dir))
		return 0;

	if ((mask & QCHAR_MASK_MIN_INTERVAL) && (pqchar_1->min_interval != pqchar_2->min_interval))
		return 0;

	if ((mask & QCHAR_MASK_MAX_INTERVAL) && (pqchar_1->max_interval != pqchar_2->max_interval))
		return 0;

	if ((mask & QCHAR_MASK_MIN_DATA_RATE) && (pqchar_1->min_datarate != pqchar_2->min_datarate))
		return 0;

	if ((mask & QCHAR_MASK_DELAY_BOUND) && (pqchar_1->delaybound != pqchar_2->delaybound))
		return 0;

	/*all parameters are matched*/
	return 1;
}

int allow_mscs_request_check(struct mscs_configuration *pmscs)
{
	u8 existed = 0;
	struct mscs_configuration *pos = NULL;
	struct classifier_parameter *pcsparam = NULL;

	if (!pmscs)
		return STATUS_INVALID_POINTER;

	pcsparam = &pmscs->csparam;
	if (pcsparam->request_type == REQUEST_TYPE_ADD) {
		dl_list_for_each(pos, &mscs_cfg_list, struct mscs_configuration, list) {
			if (MAC_ADDR_EQUAL(pos->csparam.sta_mac, pcsparam->sta_mac))
				return STATUS_CFG_EXISTED;
		}
	} else if (pcsparam->request_type == REQUEST_TYPE_CHANGE) {
		dl_list_for_each(pos, &mscs_cfg_list, struct mscs_configuration, list) {
			if (pos->index == pmscs->index &&
				MAC_ADDR_EQUAL(pos->csparam.sta_mac, pcsparam->sta_mac)) {
				existed = 1;
				if ((pos->csparam.up_bitmap == pcsparam->up_bitmap) &&
					(pos->csparam.cs.header.cs_mask == pcsparam->cs.header.cs_mask))
					return STATUS_CFG_IS_THE_SAME;
			}
		}
		if (!existed)
			return STATUS_CFG_NOT_EXISTED;
	} else if (pcsparam->request_type == REQUEST_TYPE_REMOVE) {
		dl_list_for_each(pos, &mscs_cfg_list, struct mscs_configuration, list) {
			if (pos->index == pmscs->index &&
				MAC_ADDR_EQUAL(pos->csparam.sta_mac, pcsparam->sta_mac)) {
				existed = 1;
			}
		}
		if (!existed)
			return STATUS_CFG_NOT_EXISTED;
	} else
		return STATUS_INVALID_CMD_TYPE;

	return STATUS_SUCCESS;
}

int allow_scs_request_check(struct scs_configuration *pscs)
{
	struct scs_configuration *pos = NULL;
	struct scs_classifier_parameter *pscsparam = NULL;
	struct classifier_type4 *ptype4 = NULL, *tmptype4 = NULL;
	struct qoschar_user_setting *pqcharcfg = NULL, *tmppqcharcfg = NULL;

	if (!pscs)
		return STATUS_INVALID_POINTER;

	pscsparam = &pscs->scsparam;
	ptype4 = &pscs->scsparam.tclas_elem[0].type4;
	pqcharcfg = &pscs->qcharconfig;

	if (pscsparam->request_type == REQUEST_TYPE_ADD) {
		dl_list_for_each(pos, &scs_cfg_list, struct scs_configuration, list) {
			if (MAC_ADDR_EQUAL(pos->scsparam.sta_mac, pscsparam->sta_mac)) {
				tmptype4 = &pos->scsparam.tclas_elem[0].type4;
				tmppqcharcfg = &pos->qcharconfig;

				if (pos->scsparam.up == pscsparam->up &&
					ptype4->cs_mask && (ptype4->cs_mask == tmptype4->cs_mask &&
					(compare_classifier_type4(ptype4, tmptype4) == 1)))
					return STATUS_CFG_EXISTED;

				if (pos->scsparam.up == pscsparam->up &&
					pqcharcfg->qchar_mask && (pqcharcfg->qchar_mask == tmppqcharcfg->qchar_mask &&
					(compare_qoschar_config(pqcharcfg, tmppqcharcfg) == 1))) {
					return STATUS_CFG_EXISTED;
				}
			}
		}
		/* config is not existed, allowed to add*/
		return STATUS_SUCCESS;
	} else if (pscsparam->request_type == REQUEST_TYPE_CHANGE) {
		dl_list_for_each(pos, &scs_cfg_list, struct scs_configuration, list) {
			if (pos->index == pscs->index &&
				MAC_ADDR_EQUAL(pos->scsparam.sta_mac, pscsparam->sta_mac)) {

				tmptype4 = &pos->scsparam.tclas_elem[0].type4;
				tmppqcharcfg = &pos->qcharconfig;

				if (pos->scsparam.up != pscsparam->up)
					return STATUS_SUCCESS;

				if (ptype4->cs_mask && (ptype4->cs_mask != tmptype4->cs_mask ||
					(compare_classifier_type4(ptype4, tmptype4) != 1)))
					return STATUS_SUCCESS;

				if (pqcharcfg->qchar_mask && (pqcharcfg->qchar_mask != tmppqcharcfg->qchar_mask ||
					(compare_qoschar_config(pqcharcfg, tmppqcharcfg) != 1)))
					return STATUS_SUCCESS;

				/* config is existed, not allowed to change*/
				return STATUS_CFG_IS_THE_SAME;
			}
		}
		/* config is not existed, not allowed to change*/
		return STATUS_CFG_NOT_EXISTED;
	} else if (pscsparam->request_type == REQUEST_TYPE_REMOVE) {
		dl_list_for_each(pos, &scs_cfg_list, struct scs_configuration, list) {
			if (pos->index == pscs->index &&
				MAC_ADDR_EQUAL(pos->scsparam.sta_mac, pscsparam->sta_mac)) {
				return STATUS_SUCCESS;
			}
		}
		/* config is not existed, not allowed to remove*/
		return STATUS_CFG_NOT_EXISTED;
	} else
		return STATUS_INVALID_CMD_TYPE;
}

static void clean_scs_configuration(void)
{
	struct scs_configuration *scscfg, *scscfg_tmp;

	dl_list_for_each_safe(scscfg, scscfg_tmp, &scs_cfg_list, struct scs_configuration, list) {
		dl_list_del(&scscfg->list);
		os_free(scscfg);
	}
	scs_active_sta_cnt = 0;
}

u8 update_dscp_policy(struct dscp_policy_db *newpolicy)
{
	u8 sta_code = STA_SUCCESS, existed = 0;
	struct dscp_policy_db *pos = NULL, *pos_tmp = NULL;

	dl_list_for_each_safe(pos, pos_tmp, &dscp_policy_list, struct dscp_policy_db, list) {
		if (pos->policyattri.policyid == newpolicy->policyattri.policyid) {
			existed = 1;
			if (newpolicy->policyattri.request_type == REQUEST_TYPE_ADD) {
				sta_code = STA_SUCCESS;
				memcpy(&pos->policyattri, &newpolicy->policyattri, sizeof(newpolicy->policyattri));
				memcpy(&pos->tclasattri, &newpolicy->tclasattri, sizeof(newpolicy->tclasattri));
				memcpy(&pos->domainattri, &newpolicy->domainattri, sizeof(newpolicy->domainattri));
				memcpy(&pos->portrange, &newpolicy->portrange, sizeof(newpolicy->portrange));
			} else if (newpolicy->policyattri.request_type == REQUEST_TYPE_REMOVE &&
				   pos->policyattri.request_type == REQUEST_TYPE_ADD) {
				pos->policyattri.request_type = REQUEST_TYPE_REMOVE;
				pos->policyattri.dscp = 0xFF;
				sta_code = STA_SUCCESS;
				/*not remove setting from list, just change request type*/
				/*dl_list_del(&pos->list);
				os_free(pos);
				dscp_policy_cnt--;
				sta_code = STA_SUCCESS;*/
			}
			break;
		}
	}

	if (!existed && dscp_policy_cnt < 0xFF) {
		if (newpolicy->policyattri.request_type == REQUEST_TYPE_ADD || newpolicy->policyattri.request_type == REQUEST_TYPE_REMOVE) {
			pos = (struct dscp_policy_db *)os_zalloc(sizeof(struct dscp_policy_db));
			if (pos) {
				memcpy(pos, newpolicy, sizeof(*newpolicy));
				/*add setting*/
				dl_list_add_tail(&dscp_policy_list, &pos->list);
				dscp_policy_cnt++;
				sta_code = STA_SUCCESS;
			} else {
				err(DEBUG_CAT_QOS, "Memory Alloc Fail.\n");
				sta_code = STA_INSUFFICIENT_RESOURCES;
			}
		} else
			sta_code = STA_REQUEST_DECLINED;
	}

	return sta_code;
}

struct dscp_policy_db *get_dscp_policy_byid(u8 id)
{
	struct dscp_policy_db *pos = NULL, *pos_tmp = NULL;

	dl_list_for_each_safe(pos, pos_tmp, &dscp_policy_list, struct dscp_policy_db, list) {
		if (pos->policyattri.policyid == id)
			return pos;
	}

	return NULL;
}

static void clean_dscp_policy(void)
{
	struct dscp_policy_db *dscppolicy, *dscppolicy_tmp;

	dl_list_for_each_safe(dscppolicy, dscppolicy_tmp, &dscp_policy_list, struct dscp_policy_db, list) {
		dl_list_del(&dscppolicy->list);
		os_free(dscppolicy);
	}
	dscp_policy_cnt = 0;
}

void parse_ip_address(u8 type, char *strip, char *buf, int buflen)
{
	u8 i = 0;
	char *value = NULL;
	int num = 0;

	if (!strip || !buf || !buflen)
		return;

	if (type == VER_IPV4) {
		if (buflen < 4)
			return;

		value = strtok(strip, ".");
		for (i = 0; (i < 4) && value; i++) {
			num = str2num(value, 10);
			if (num < 0)
				err(DEBUG_CAT_QOS, "invalid ip:%s\n", value);
			else
				buf[i] = num;

			value = strtok(NULL, ".");
			if (value == NULL)
				break;
		}
	} else if (type == VER_IPV6) {
		if (buflen < 16)
			return;
		if (inet_pton(AF_INET6, strip, (void *)buf) != 1)
			err(DEBUG_CAT_QOS, "inet_pton got error\n");
	}
}

/*
* will parse dscp policy from string.
* example
* 1. DSCPPolicy_PolicyID,1,DSCPPolicy_RequestType,Add,DSCPPolicy_DSCP,0x2E,TCLAS_ClassifierType,4,
     TCLAS_ClassifierMask,0x55,TCLAS_ClassifierParams_Version,4,TCLAS_ClassifierParams_DestIPAddr,192.165.100.36,
     TCLAS_ClassifierParams_DestPort,5201,TCLAS_ClassifierParams_Protocol,17
* 2. DSCPPolicy_PolicyID,4,DSCPPolicy_RequestType,Add,DSCPPolicy_DSCP,0x18, DSCPPolicy_DomainName,video.wifitest.org
*/
static void parse_dscp_policy(char *str)
{
	char *type = NULL, *value = NULL;
	char srcIP[64] = {0}, dstIP[64] = {0};
	struct dscp_policy_db policy;
	u8 ipver = 0;
	int num = 0;

	if (!str) {
		err(DEBUG_CAT_QOS, "Invalid argument\n");
		return;
	}

	memset(srcIP, 0, sizeof(srcIP));
	memset(dstIP, 0, sizeof(dstIP));
	memset(&policy, 0, sizeof(policy));

	type = strtok(str, ",");
	if (!type) {
		err(DEBUG_CAT_QOS, "type got NULL.\n");
		return;
	}
	value = strtok(NULL, ",");
	if (!value) {
		err(DEBUG_CAT_QOS, "value got NULL.\n");
		return;
	}

	do {
		if (str_equal(type, "DSCPPolicy_PolicyID")) {
			num = str2num(value, 10);
			if (num < 0 || num > 0xFF)
				warn(DEBUG_CAT_QOS, "invalid DSCPPolicy_PolicyID:%s\n", value);
			else
				policy.policyattri.policyid = num;
		} else if (str_equal(type, "DSCPPolicy_RequestType")) {
			if (str_equal(value, "Add"))
				policy.policyattri.request_type = REQUEST_TYPE_ADD;
			else {
				policy.policyattri.request_type = REQUEST_TYPE_REMOVE;
				policy.policyattri.dscp = 0xFF;
			}
		} else if (str_equal(type, "DSCPPolicy_DSCP")) {
			num = str2num(value, 10);
			if (num < 0 || num > 63)
				warn(DEBUG_CAT_QOS, "invalid DSCPPolicy_DSCP:%s\n", value);
			else
				policy.policyattri.dscp = num;
		} else if (str_equal(type, "DomainName_Domain")) {
			policy.domainattri.attrid = ATTR_ID_DOMAIN_NAME;
			memcpy(policy.domainattri.domainname, value, MIN(strlen(value), MAX_DOMAIN_NAME_LEN));
		} else if (str_equal(type, "TCLAS_ClassifierType")) {
			policy.tclasattri.header.attrid = ATTR_ID_TCLAS;
			num = str2num(value, 10);
			if (num < 0 || num > 10)
				warn(DEBUG_CAT_QOS, "invalid TCLAS_ClassifierType:%s\n", value);
			else
				policy.tclasattri.ipv4.cs_type = num;
		} else if (str_equal(type, "TCLAS_ClassifierMask")) {
			num = str2num(value, 16);
			if (num < 0 || num > 0xFF)
				warn(DEBUG_CAT_QOS, "invalid TCLAS_ClassifierMask:%s\n", value);
			else
				policy.tclasattri.ipv4.cs_mask = num;

		} else if (str_equal(type, "TCLAS_ClassifierParams_Version")) {
			num = str2num(value, 10);
			if (num != VER_IPV4 && num != VER_IPV6)
				warn(DEBUG_CAT_QOS, "invalid TCLAS_ClassifierParams_Version:%s\n", value);
			else
				policy.tclasattri.ipv4.version = num;
		} else if (str_equal(type, "TCLAS_ClassifierParams_SrcIPAddr")) {
			memcpy(srcIP, value, MIN(strlen(value), sizeof(srcIP)));
		} else if (str_equal(type, "TCLAS_ClassifierParams_DestIPAddr")) {
			memcpy(dstIP, value, MIN(strlen(value), sizeof(dstIP)));
		} else if (str_equal(type, "TCLAS_ClassifierParams_SrcPort")) {
			ipver = policy.tclasattri.ipv4.version;
			if (ipver == VER_IPV4) {
				num = str2num(value, 10);
				if (num < 0)
					warn(DEBUG_CAT_QOS, "invalid TCLAS_ClassifierParams_SrcPort:%s\n", value);
				else
					policy.tclasattri.ipv4.srcPort = num;
				policy.tclasattri.ipv4.srcPort = htons(policy.tclasattri.ipv4.srcPort);
			} else if (ipver == VER_IPV6) {
				num = str2num(value, 10);
				if (num < 0)
					warn(DEBUG_CAT_QOS, "invalid TCLAS_ClassifierParams_SrcPort:%s\n", value);
				else
					policy.tclasattri.ipv6.srcPort = num;
				policy.tclasattri.ipv6.srcPort = htons(policy.tclasattri.ipv6.srcPort);
			}
		} else if (str_equal(type, "TCLAS_ClassifierParams_DestPort")) {
			ipver = policy.tclasattri.ipv4.version;
			if (ipver == VER_IPV4) {
				num = str2num(value, 10);
				if (num < 0)
					warn(DEBUG_CAT_QOS, "invalid TCLAS_ClassifierParams_DestPort:%s\n", value);
				else
					policy.tclasattri.ipv4.dstPort = num;
				policy.tclasattri.ipv4.dstPort = htons(policy.tclasattri.ipv4.dstPort);
			} else if (ipver == VER_IPV6) {
				num = str2num(value, 10);
				if (num < 0)
					warn(DEBUG_CAT_QOS, "invalid TCLAS_ClassifierParams_DestPort:%s\n", value);
				else
					policy.tclasattri.ipv6.dstPort = num;
				policy.tclasattri.ipv6.dstPort = htons(policy.tclasattri.ipv6.dstPort);
			}
		} else if (str_equal(type, "TCLAS_ClassifierParams_Protocol")) {
			ipver = policy.tclasattri.ipv4.version;
			if (ipver == VER_IPV4) {
				num = str2num(value, 10);
				if (num < 0)
					warn(DEBUG_CAT_QOS, "invalid TCLAS_ClassifierParams_Protocol:%s\n", value);
				else
					policy.tclasattri.ipv4.protocol = num;
			} else if (ipver == VER_IPV6) {
				num = str2num(value, 10);
				if (num < 0)
					warn(DEBUG_CAT_QOS, "invalid TCLAS_ClassifierParams_Protocol:%s\n", value);
				else
					policy.tclasattri.ipv6.nextheader = num;
			}
		} else if (str_equal(type, "PortRange_StartPort")) {
			policy.portrange.attrid = ATTR_ID_PORT_RANGE;
			policy.portrange.length = 4;
			num = str2num(value, 10);
			if (num < 0)
				warn(DEBUG_CAT_QOS, "invalid PortRange_StartPort:%s\n", value);
			else
				policy.portrange.startp = num;
			policy.portrange.startp = htons(policy.portrange.startp);
		} else if (str_equal(type, "PortRange_EndPort")) {
			num = str2num(value, 10);
			if (num < 0)
				warn(DEBUG_CAT_QOS, "invalid PortRange_EndPort:%s\n", value);
			else
				policy.portrange.endp = num;
			policy.portrange.endp = htons(policy.portrange.endp);
		} else {
			err(DEBUG_CAT_QOS, "unknown parameters %s.\n", type);
		}
		type = strtok(NULL, ",");
		if (type == NULL)
			break;
		value = strtok(NULL, ",");
		if (value == NULL)
			break;
	} while (type != NULL && value != NULL);

	ipver = policy.tclasattri.ipv4.version;
	if (ipver == VER_IPV4) {
		if (strlen(srcIP))
			parse_ip_address(ipver, srcIP, (char *)&policy.tclasattri.ipv4.srcIp, sizeof(policy.tclasattri.ipv4.srcIp));
		if (strlen(dstIP))
			parse_ip_address(ipver, dstIP, (char *)&policy.tclasattri.ipv4.dstIp, sizeof(policy.tclasattri.ipv4.dstIp));
	}
	if (ipver == VER_IPV6) {
		if (strlen(srcIP))
			parse_ip_address(ipver, srcIP, (char *)&policy.tclasattri.ipv6.srcIp, sizeof(policy.tclasattri.ipv6.srcIp));
		if (strlen(dstIP))
			parse_ip_address(ipver, dstIP, (char *)&policy.tclasattri.ipv6.dstIp, sizeof(policy.tclasattri.ipv6.dstIp));
	}

	update_dscp_policy(&policy);
}

u8 parse_policyid_list(char *str, u8 *buf, u8 buflen)
{
	char *value = NULL;
	u8 i = 0;
	int num = 0;

	if (!str || !buf || !buflen) {
		err(DEBUG_CAT_QOS, "Invalid argument\n");
		return 0;
	}

	value = strtok(str, "_");
	while (value != NULL) {
		num = str2num(value, 10);
		if (num < 0) {
			err(DEBUG_CAT_QOS, "invalid policyid:%s\n", value);
			break;
		} else if (i >= buflen) {
			err(DEBUG_CAT_QOS, "offset(i:%u) exceed buflen:%u\n", i, buflen);
			break;
		}

		buf[i++] = num;
		value = strtok(NULL, "_");
	}
	return i;
}

static inline u8 build_dscp_policy_req_frame(struct dscp_policy_req *policyreq, u8 *frmbuf, u16 buflen)
{
	static u8 token = 1;
	u8 i = 0, frmlen = 0;
	struct qos_management_element *qos_mgmt_elem = NULL;
	struct dscp_policy_attribute *policyattr = NULL;
	struct tclas_attribute_ipv4 *tclasattr_ipv4 = NULL;
	struct tclas_attribute_ipv6 *tclasattr_ipv6 = NULL;
	struct domain_name_attribute *domianattr = NULL;
	struct port_range_attribute *portattr = NULL;
	struct dscp_policy_db *policy = NULL;

	if (!frmbuf || !buflen || !policyreq)
		return 0;

	memset(frmbuf, 0, buflen);
	frmlen = 0;

	/*build QOS Policy Request Frame Header*/
	frmbuf[frmlen] = CATEGORY_VEND_SPECIFIC_PROTECTED;
	frmlen++;
	memcpy(&frmbuf[frmlen], WFA_OUI, sizeof(WFA_OUI));
	frmlen += sizeof(WFA_OUI);
	frmbuf[frmlen] = QOS_ACT_FRM_OUI_TYPE;
	frmlen++;
	frmbuf[frmlen] = DSCP_POLICY_REQ;
	frmlen++;
	frmbuf[frmlen] = (policyreq->token) ? (policyreq->token) : (token++);
	frmlen++;
	frmbuf[frmlen] = 0; /*Request Control field*/
	if (policyreq->moreflag == 1)
		frmbuf[frmlen] |= 1;
	if (policyreq->resetflag == 1)
		frmbuf[frmlen] |= 2;
	frmlen++;

	/*build QoS Management elements*/
	for (i = 0; i < policyreq->id_num; i++) {
		policy = get_dscp_policy_byid(policyreq->policyids[i]);
		if (!policy)
			continue;

		/*QoS Management element*/
		qos_mgmt_elem = (struct qos_management_element *)&frmbuf[frmlen];
		qos_mgmt_elem->elementid = QOS_MGMT_ELEMENT_ID;
		qos_mgmt_elem->length = 4;
		memcpy(qos_mgmt_elem->oui, WFA_OUI, sizeof(WFA_OUI));
		qos_mgmt_elem->ouitype = QOS_MGMT_IE_OUI_TYPE;
		if ((frmlen + sizeof(*qos_mgmt_elem)) >= 0xFF)
			break;
		frmlen += sizeof(*qos_mgmt_elem);

		/*dscp policy attribute*/
		policyattr = (struct dscp_policy_attribute *)&frmbuf[frmlen];
		memcpy(policyattr, &policy->policyattri, sizeof(policy->policyattri));
		policyattr->attrid = ATTR_ID_DSCP_POLICY;
		policyattr->length = sizeof(*policyattr) - 2;
		if ((frmlen + sizeof(*policyattr)) >= 0xFF)
			break;
		frmlen += sizeof(*policyattr);
		qos_mgmt_elem->length += sizeof(*policyattr);

		if (policyattr->request_type == REQUEST_TYPE_REMOVE)
			continue;

		/*tclas attribute*/
		if (policy->tclasattri.header.attrid == ATTR_ID_TCLAS) {
			if (policy->tclasattri.ipv4.version == VER_IPV4) {
				tclasattr_ipv4 = (struct tclas_attribute_ipv4 *)&frmbuf[frmlen];
				memcpy(tclasattr_ipv4, &policy->tclasattri.ipv4, sizeof(policy->tclasattri.ipv4));
				tclasattr_ipv4->length = sizeof(*tclasattr_ipv4) - 2;
				if ((frmlen + sizeof(*tclasattr_ipv4)) >= 0xFF)
					break;
				frmlen += sizeof(*tclasattr_ipv4);
				qos_mgmt_elem->length += sizeof(*tclasattr_ipv4);
			} else if (policy->tclasattri.ipv4.version == VER_IPV6) {
				tclasattr_ipv6 = (struct tclas_attribute_ipv6 *)&frmbuf[frmlen];
				memcpy(tclasattr_ipv6, &policy->tclasattri.ipv6, sizeof(policy->tclasattri.ipv6));
				tclasattr_ipv6->length = sizeof(*tclasattr_ipv6) - 2;
				if ((frmlen + sizeof(*tclasattr_ipv6)) >= 0xFF)
					break;
				frmlen += sizeof(*tclasattr_ipv6);
				qos_mgmt_elem->length += sizeof(*tclasattr_ipv6);
			} else {
				err(DEBUG_CAT_QOS, "unknown type4.version: %d.\n", policy->tclasattri.ipv4.version);
			}
		}

		/*domain name attribute*/
		if (policy->domainattri.attrid == ATTR_ID_DOMAIN_NAME) {
			domianattr = (struct domain_name_attribute *)&frmbuf[frmlen];
			domianattr->attrid = ATTR_ID_DOMAIN_NAME;
			domianattr->length = MIN(strlen(policy->domainattri.domainname), MAX_DOMAIN_NAME_LEN);
			memcpy(&domianattr->domainname, policy->domainattri.domainname, domianattr->length);
			if ((frmlen + domianattr->length + 2) >= 0xFF)
				break;
			frmlen += domianattr->length + 2;
			qos_mgmt_elem->length += domianattr->length + 2;
		}

		/*port range attribute*/
		if (policy->portrange.attrid == ATTR_ID_PORT_RANGE) {
			portattr = (struct port_range_attribute *)&frmbuf[frmlen];
			portattr->attrid = ATTR_ID_PORT_RANGE;
			portattr->length = 4;
			portattr->startp = policy->portrange.startp;
			portattr->endp = policy->portrange.endp;
			if ((frmlen + portattr->length + 2) >= 0xFF)
				break;
			frmlen += portattr->length + 2;
			qos_mgmt_elem->length += portattr->length + 2;
		}
	}

	return frmlen;
}

void wapp_send_dscp_policy_req(struct wifi_app *wapp, const char *ifname, u8 *dstmac, struct dscp_policy_req *policyreq)
{
	u32 len = 0;
	struct wapp_dev *wdev = NULL;

	wdev = wapp_dev_list_lookup_by_ifname(wapp, ifname);
	if (!wdev) {
		err(DEBUG_CAT_QOS, "invalid wdev:%p\n", wdev);
		return;
	}

	len = build_dscp_policy_req_frame(policyreq, sendbuf, sizeof(sendbuf));
	wapp_drv_send_action_frame(MTK_NL80211_VENDOR_ATTR_SET_ACTION_QOS_ACTION_FRAME, wapp, wdev, qos_config.channel, 0, dstmac, sendbuf,
				   len);
}

void wapp_dscp_policy_action_frame_process(struct wifi_app *wapp, struct wapp_dev *wdev, u8 channel, u8 *peermac, u8 *frmbuf, u32 frmlen)
{
	u32 len = 0;
	u8 *buf = NULL;
	u8 token = 0, type = 0;
	struct dscp_policy_req policyreq;
	struct dscp_policy_db *pos = NULL, *pos_tmp = NULL;

	if (!wapp || !wdev || !peermac || !frmbuf)
		return;

	buf = frmbuf;
	len = frmlen;
	if ((buf[0] != CATEGORY_VEND_SPECIFIC_PROTECTED && buf[0] != CATEGORY_VEND_SPECIFIC) ||
	    ((buf[5] != DSCP_POLICY_QRY) && (buf[5] != DSCP_POLICY_RSP))) {
		err(DEBUG_CAT_QOS, "unknown action type, cat:%d, action:%d\n", buf[0], buf[5]);
		return;
	}
#ifdef MAP_R5
	map_send_tunnel_dscp_policy_action_frm(wapp, peermac, frmbuf, frmlen, buf[5]);
#endif
	type = buf[5];
	token = buf[6];

	/*buf += 7;*/
	/*len -= 7;*/

	notice(DEBUG_CAT_QOS, "Received DSCP Policy Action frame from " MACSTR " type=%u, token=%u, chan=%u, len=%d\n",
		MAC2STR(peermac), type, token, channel, len);

	if (type == DSCP_POLICY_QRY) {
		memset(&policyreq, 0, sizeof(policyreq));
		policyreq.resetflag = qos_config.RequestCtrlReset;
		policyreq.token = token;

		if (frmlen < 7) {
			err(DEBUG_CAT_QOS, "invalid DSCP_POLICY_QRY frame.\n");
		} else if (frmlen == 7) { /* wildcard DSCP Policy Query*/
			dl_list_for_each_safe(pos, pos_tmp, &dscp_policy_list, struct dscp_policy_db, list) {
				if (policyreq.id_num < MAX_POLICY_NUM)
					policyreq.policyids[policyreq.id_num++] = pos->policyattri.policyid;
				else
					warn(DEBUG_CAT_QOS, "reach max policy number.\n");
			}
		} else {
			dl_list_for_each_safe(pos, pos_tmp, &dscp_policy_list, struct dscp_policy_db, list) {
				if (policyreq.id_num < MAX_POLICY_NUM)
					policyreq.policyids[policyreq.id_num++] = pos->policyattri.policyid;
				else
					warn(DEBUG_CAT_QOS, "reach max policy number.\n");
			}
			notice(DEBUG_CAT_QOS, "dscp policy query with QoS Management Element.\n");
		}
		wapp_send_dscp_policy_req(wapp, wdev->ifname, peermac, &policyreq);
	} else if (type == DSCP_POLICY_RSP) {
		notice(DEBUG_CAT_QOS, "DSCP_POLICY_RSP was received, do nothing.\n");
	} else {
		warn(DEBUG_CAT_QOS, "unexpected DSCP Policy Action Frame, type:%d.\n", type);
	}

	return;
}

/*
 * will parse dscp policy req cmd string.
 * example
 * Dest_MAC,11:22:33:44:55:66,PolicyID_List,1_2_3
 */
void parse_dscp_policy_req(struct wifi_app *wapp, const char *ifname, char *str)
{
	char *type = NULL, *value = NULL;
	u8 dstmac[MAC_ADDR_LEN] = {0};
	char str_mac[64] = {0}, str_id_list[32] = {0};
	struct dscp_policy_req policyrep;
	int num = 0, ret = 0;

	if (!str) {
		err(DEBUG_CAT_QOS, "Invalid argument\n");
		return;
	}

	debug(DEBUG_CAT_QOS, "%s\n", str);

	memset(dstmac, 0, sizeof(dstmac));
	memset(str_mac, 0, sizeof(str_mac));
	memset(str_id_list, 0, sizeof(str_id_list));
	memset(&policyrep, 0, sizeof(policyrep));

	type = strtok(str, ",");
	if (!type) {
		err(DEBUG_CAT_QOS, "type got NULL.\n");
		return;
	}
	value = strtok(NULL, ",");
	if (!value) {
		err(DEBUG_CAT_QOS, "value got NULL.\n");
		return;
	}
	do {
		if (!os_strcasecmp(type, "Dest_MAC")) {
			memcpy(str_mac, value, MIN(strlen(value), sizeof(str_mac)));
		} else if (!os_strcasecmp(type, "PolicyID_List")) {
			memcpy(str_id_list, value, MIN(strlen(value), sizeof(str_id_list)));
		} else if (!os_strcasecmp(type, "RequestControl_Reset")) {
			num = str2num(value, 10);
			if (num < 0)
				warn(DEBUG_CAT_QOS, "invalid RequestControl_Reset:%s\n", value);
			else
				policyrep.resetflag = num;
		} else {
			err(DEBUG_CAT_QOS, "unknown parameters %s.\n", type);
		}
		type = strtok(NULL, ",");
		if (type == NULL)
			break;
		value = strtok(NULL, ",");
		if (value == NULL)
			break;
	} while (type != NULL && value != NULL);
	if (strlen(str_mac)) {
		ret = convert_mac_addr(str_mac, dstmac);
		if (ret != STATUS_SUCCESS)
			err(DEBUG_CAT_QOS, "invalid dstmac:%s\n", value);
	}
	if (strlen(str_id_list))
		policyrep.id_num = parse_policyid_list(str_id_list, policyrep.policyids, sizeof(policyrep.policyids));

	debug(DEBUG_CAT_QOS, "" MACSTR "\n", MAC2STR(dstmac));

	if (policyrep.id_num)
		wapp_send_dscp_policy_req(wapp, ifname, dstmac, &policyrep);
}

static inline u8 build_scs_resp_frame(u8 token, struct scs_status *scssta, u8 scsnum, u8 *frmbuf, u16 buflen)
{
	u8 i = 0, frmlen = 0;

	if (!frmbuf || !buflen)
		return 0;

	memset(frmbuf, 0, buflen);
	frmlen = 0;
	frmbuf[frmlen] = CATEGORY_RAVS;
	frmlen++;
	frmbuf[frmlen] = ACT_SCS_RSP;
	frmlen++;
	frmbuf[frmlen] = token;
	frmlen++;

	/*count field*/
	frmbuf[frmlen] = scsnum;
	frmlen++;

	for (i = 0; i < scsnum && scssta; i++) {
		memcpy(&frmbuf[frmlen], &scssta[i].scsid, 1);
		frmlen++;
		memcpy(&frmbuf[frmlen], &scssta[i].stacode, 2);
		frmlen += 2;
		if ((frmlen + 3) >= 0xFF)
			break;
	}

	return frmlen;
}

/*
 * will parse unsolicted SCS Response cmd string from UCC.
 * example
 * SCSRsp,Dest_MAC,11:22:33:44:55:66,SCSID,1,Status,Remove
 */
static void parse_scs_response(struct wifi_app *wapp, const char *ifname, char *str)
{
	int num = 0, ret = 0;
	u32 len = 0;
	char *type = NULL, *value = NULL;
	u8 dstmac[MAC_ADDR_LEN] = {0};
	char str_mac[64] = {0};
	struct scs_status sta_code;
	struct wapp_dev *wdev = NULL;
	struct scs_configuration scscfg = {0};
	struct scs_classifier_parameter *pscsparam = NULL;

	wdev = wapp_dev_list_lookup_by_ifname(wapp, ifname);
	if (!wdev)
		return;

	if (!str) {
		err(DEBUG_CAT_QOS, "Invalid argument\n");
		return;
	}

	debug(DEBUG_CAT_QOS, "%s\n", str);

	pscsparam = &scscfg.scsparam;
	memset(dstmac, 0, sizeof(dstmac));
	memset(str_mac, 0, sizeof(str_mac));
	memset(&sta_code, 0, sizeof(sta_code));
	memset(&scscfg, 0, sizeof(scscfg));

	type = strtok(str, ",");
	if (!type) {
		err(DEBUG_CAT_QOS, "type got NULL.\n");
		return;
	}
	value = strtok(NULL, ",");
	if (!value) {
		err(DEBUG_CAT_QOS, "value got NULL.\n");
		return;
	}

	do {
		if (!os_strcasecmp(type, "Dest_MAC")) {
			memcpy(str_mac, value, MIN(strlen(value), sizeof(str_mac)));
		} else if (!os_strcasecmp(type, "SCSDescrElem_SCSID_1")) {
			num = str2num(value, 10);
			if (num < 0) {
				err(DEBUG_CAT_QOS, "invalid SCSDescrElem_SCSID_1:%s\n", value);
			} else
				sta_code.scsid = num;
		} else if (!os_strcasecmp(type, "SCSDescrElem_RequestType_1")) {
			if (!os_strcasecmp(value, "Remove")) {
				sta_code.stacode = STA_TERMINATED;
				notice(DEBUG_CAT_QOS, "SCS request %s\n", value);
			} else
				sta_code.stacode = STA_SUCCESS;
		} else {
			err(DEBUG_CAT_QOS, "unknown parameters %s.\n", type);
		}
		type = strtok(NULL, ",");
		if (type == NULL)
			break;
		value = strtok(NULL, ",");
		if (value == NULL)
			break;
	} while (type != NULL && value != NULL);

	if (strlen(str_mac)) {
		ret = convert_mac_addr(str_mac, dstmac);
		if (ret != STATUS_SUCCESS)
			err(DEBUG_CAT_QOS, "invalid dstmac:%s\n", value);
	}

	/*Update SCS Configuration*/
	if (sta_code.stacode != STA_SUCCESS) {
		memcpy(pscsparam->sta_mac, dstmac, MAC_ADDR_LEN);
		pscsparam->scsid = sta_code.scsid;
		pscsparam->request_type = REQUEST_TYPE_REMOVE;

		wapp_drv_send_event(NL_SET_SCS_CONFIG, (unsigned char *)pscsparam, sizeof(*pscsparam));
		update_scs_configuration(wapp, &scscfg);
	}

	/*build scs response action frame and send to peer.*/
	len = build_scs_resp_frame(0, &sta_code, 1, sendbuf, sizeof(sendbuf));
	wapp_drv_send_action_frame(MTK_NL80211_VENDOR_ATTR_SET_ACTION_QOS_ACTION_FRAME, wapp, wdev, qos_config.channel, 0, dstmac, sendbuf,
				   len);
}

int wapp_write_pmk(char *filename, char *buf, u8 len)
{
	FILE *f = NULL;
	int fd = 0, i = 0;

	if (!buf || !len)
		return -1;

	f = fopen(filename, "w");
	if (f == NULL) {
		err(DEBUG_CAT_QOS, "Failed to open '%s' for writing\n", filename);
		return -1;
	}

	for (i = 0; i < len; i++) {
		if (fprintf(f, "%02x", buf[i]) < 0) {
			err(DEBUG_CAT_QOS, "fprintf got error.\n");
			break;
		}
	}
	fd = fileno(f);
	fsync(fd);
	if (!fclose(f))
		err(DEBUG_CAT_QOS, "fclose get error %s\n", strerror(errno));

	return 0;
}

static int get_pmk_by_peer_mac(struct wifi_app *wapp, const char *ifname, u8 *peermac)
{
	int buflen = 64;
	char buf[64] = {0};
	struct wapp_dev *wdev = NULL;

	if (!wapp || !peermac) {
		err(DEBUG_CAT_QOS, "invalid is parameter\n");
		return -1;
	}

	wdev = wapp_dev_list_lookup_by_ifname(wapp, ifname);
	if (!wdev)
		return -1;

	if (!wapp->drv_ops || !wapp->drv_ops->send_action)
		return 0;

	memcpy(buf, peermac, MAC_ADDR_LEN);
	wapp->drv_ops->drv_get_pmk_by_peermac(wapp->drv_data, wdev->ifname, buf, &buflen);
	wapp_write_pmk("/tmp/pmk.txt", buf, buflen);

	return 0;
}

#endif

static inline u8 build_mscs_resp_frame(u8 token, u16 statuscode, u8 *frmbuf, u16 buflen)
{
	u8 frmlen = 0;

	if (!frmbuf || !buflen)
		return 0;

	memset(frmbuf, 0, buflen);
	frmlen = 0;
	frmbuf[frmlen] = CATEGORY_RAVS;
	frmlen++;
	frmbuf[frmlen] = ACT_MSCS_RSP;
	frmlen++;
	frmbuf[frmlen] = token;
	frmlen++;

	memcpy(&frmbuf[frmlen], &statuscode, 2);
	frmlen += 2;

	return frmlen;
}

void wapp_mscs_action_frame_process(struct wifi_app *wapp, struct wapp_dev *wdev, u8 channel, u8 *peermac, u8 *frmbuf, u32 frmlen)
{
	u32 len = 0;
	u8 *buf = NULL;
	u8 token = 0, type = 0, subielen = 0;
	struct classifier_parameter cs_param;
	u16 sta_code = STA_SUCCESS;

	if (!wapp || !wdev || !peermac || !frmbuf || frmlen < 7)
		return;

	buf = frmbuf;
	len = frmlen;
	if (buf[0] != CATEGORY_RAVS || ((buf[1] != ACT_MSCS_REQ) && (buf[1] != ACT_MSCS_RSP))) {
		err(DEBUG_CAT_QOS, "unknown action type, cat:%d, action:%d\n", buf[0], buf[1]);
		sta_code = STA_REQUEST_DECLINED;
		goto exit1;
	}
	type = buf[1];
	token = buf[2];
	buf += 3;
	len -= 3;

	notice(DEBUG_CAT_QOS, "MSCS: Received MSCS Action frame from " MACSTR " type=%u, token=%u, chan=%u, len=%d\n",
		MAC2STR(peermac), type, token, channel, len);

	if (type == ACT_MSCS_RSP)
		goto exit2;

	/*MSCS Descriptor TLV Header Check*/
	if ((*buf) == IE_WLAN_EXTENSION && (*(buf + 2)) == IE_EXTENSION_ID_MSCS_DESC) {
#ifdef MAP_R5
		/*length = QMID(2) + BSSID(6) + Client MAC(6) + Descriptor Len*/
		qos_mgmt_desc_tlv.length = 2 + (2*MAC_ADDR_LEN) + 2 + (*(buf+1));
		memcpy(qos_mgmt_desc_tlv.descriptor, buf, (*(buf+1)));
#endif
		buf += 3;
		len -= 3;
	} else {
		sta_code = STA_REQUESTED_NOT_SUPPORTED;
		err(DEBUG_CAT_QOS, "invalid mscs descriptor header, ID:%u, len:%u, extID:%u.\n", *buf, *(buf + 1),
			 *(buf + 2));
		goto exit1;
	}

	memset(&cs_param, 0, sizeof(cs_param));
	COPY_MAC_ADDR(cs_param.sta_mac, peermac);

	if ((*buf) >= REQUEST_TYPE_UNKNOWN) {
		sta_code = STA_REQUEST_DECLINED;
		err(DEBUG_CAT_QOS, "unknown mscs request type:%u\n", *buf);
		goto exit1;
	}

	if ((((*buf) == REQUEST_TYPE_ADD || (*buf) == REQUEST_TYPE_CHANGE) && len < 13) || (((*buf) == REQUEST_TYPE_REMOVE) && len < 7)) {
		err(DEBUG_CAT_QOS, "invalid mscs descriptor element.\n");
		sta_code = STA_REQUEST_DECLINED;
		goto exit1;
	}

	cs_param.request_type = *buf;
	cs_param.up_bitmap = *(buf + 1);
	cs_param.up_limit = (*(buf + 2)) & 0x07;
	cs_param.timeout = ((*((UINT32 *)(buf + 3))) * 1024) / 1000000;
	buf += 7;
	len -= 7;

	if (cs_param.request_type == REQUEST_TYPE_REMOVE) {
		sta_code = update_mscs_configuration(wapp, &cs_param);
		wapp_drv_send_event(NL_SET_MSCS_CONFIG, (unsigned char *)&cs_param, sizeof(cs_param));
		goto exit1;
	}

#ifdef MAP_R5
	if (cs_param.request_type == REQUEST_TYPE_ADD && disallow_qos_check(ACT_MSCS_REQ, cs_param.sta_mac)) {
		sta_code = STA_REQUEST_DECLINED;
		goto exit1;
	}
#endif
	while ((*buf) == IE_WLAN_EXTENSION && (*(buf + 2)) == IE_EXTENSION_ID_TCLAS_MASK) {
		subielen = *(buf + 1);
		buf += 2;
		len -= 2;
		if (subielen > len || sta_code != STA_SUCCESS) {
			notice(DEBUG_CAT_QOS, "len:%u, leftlen:%d, sta_code:%d.\n", subielen, len, sta_code);
			break;
		}

		if ((*(buf + 1)) == CLASSIFIER_TYPE4) {
			cs_param.cs.header.cs_type = *(buf + 1);
			cs_param.cs.header.cs_mask = *(buf + 2);
			sta_code = update_mscs_configuration(wapp, &cs_param);
			wapp_drv_send_event(NL_SET_MSCS_CONFIG, (unsigned char *)&cs_param, sizeof(cs_param));
		} else
			err(DEBUG_CAT_QOS, "not support mscs classifier type= %d.\n", (*buf));

		buf += subielen;
		len -= subielen;
	}

exit1:
	/*build mscs response action frame and send to peer.*/
	len = build_mscs_resp_frame(token, sta_code, sendbuf, sizeof(sendbuf));
	wapp_drv_send_action_frame(MTK_NL80211_VENDOR_ATTR_SET_ACTION_QOS_ACTION_FRAME, wapp, wdev, channel, 0, peermac, sendbuf, len);

#ifdef MAP_R5
	wapp_send_1905_msg(wapp, WAPP_SEND_QOS_TLV_MSG, sizeof(qos_mgmt_desc_tlv), (char *)&qos_mgmt_desc_tlv);

	notice(DEBUG_CAT_QOS, "Send QoS MSCS Descriptor TLV bssid:"MACSTR" stamac:"MACSTR", tlv_len=%d\n",
		MAC2STR(qos_mgmt_desc_tlv.bssid), MAC2STR(qos_mgmt_desc_tlv.sta_mac), qos_mgmt_desc_tlv.length);

#endif
	return;
exit2:
	notice(DEBUG_CAT_QOS, "ACT_MSCS_RSP was received, do nothing.\n");
	return;
}

#ifdef QOS_R2
u8 apply_scs_to_ap(struct wifi_app *wapp, const char *ifname, struct scs_configuration *pscs)
{
	u8 stat_code;

	if (!wapp || !pscs) {
		err(DEBUG_CAT_QOS, "invalid pointer, wapp:%p, pscs:%p\n", wapp, pscs);
		return STA_REQUEST_DECLINED;
	}

	stat_code = update_scs_configuration(wapp, pscs);
	if (stat_code != STA_SUCCESS && stat_code != STA_TERMINATED)
		err(DEBUG_CAT_QOS, "update scs to list failed, %s\n", err2str(stat_code));

	wapp_drv_send_event(NL_SET_SCS_CONFIG, (unsigned char *)&pscs->scsparam, sizeof(pscs->scsparam));

#ifdef QOS_R3
	if (!MAC_ADDR_EQUAL(pscs->qchar.sta_mac, zero_mac) && ifname)
		wapp_drv_set_qos_characteristics_ie(wapp, ifname, (char *)&pscs->qchar, sizeof(pscs->qchar));
#endif

	return stat_code;
}


void wapp_scs_action_frame_process(struct wifi_app *wapp, struct wapp_dev *wdev, u8 channel, u8 *peermac, u8 *frmbuf, u32 frmlen)
{
	int leftlen = 0, len = 0;
	u8 filterlen = 0, i = 0, valid_len = 0;
	u8 *filtervalue = NULL, *filtermask = NULL;
	u8 *buf = NULL, scs_num = 0;
	u8 token = 0, type = 0, subielen = 0;
	struct scs_status sta_code[10];
	ptclas_element ptclas = NULL;
	struct scs_configuration scs = {0};
	struct scs_classifier_parameter *pscsparam = NULL;
	struct qos_characteristics *pqchar = NULL;

	if (!wapp || !wdev || !peermac || !frmbuf)
		return;

	buf = frmbuf;
	leftlen = frmlen;
	if (buf[0] != CATEGORY_RAVS || ((buf[1] != ACT_SCS_REQ) && (buf[1] != ACT_SCS_RSP))) {
		err(DEBUG_CAT_QOS, "unknown action type, cat:%d, action:%d\n", buf[0], buf[1]);
		return;
	}

	type = buf[1];
	token = buf[2];
	buf += 3;
	leftlen -= 3;

	notice(DEBUG_CAT_QOS, "SCS: Received SCS Action frame from "MACSTR" type=%u, token=%u, chan=%u, leftlen=%d\n",
		MAC2STR(peermac), type, token, channel, leftlen);

	if (type == ACT_MSCS_RSP) {
		warn(DEBUG_CAT_QOS, "ACT_SCS_RSP was received, do nothing.\n");
		return;
	}

	/*Parsing SCS Descriptor list*/
	while ((*buf) == IE_SCS_DESCRIPTOR_ELEMENT_ID && leftlen > 0) {
		len = *(buf+1);
		buf += 2;
		leftlen -= 2;
		if (len > leftlen) {
			err(DEBUG_CAT_QOS, "Parsing SCS Descriptor, len(%d) > leftlen(%u)\n", len, leftlen);
			break;
		}
		if (scs_num >= 10) {
			err(DEBUG_CAT_QOS, "SCS Descriptor number exceed 10 in SCS Request.\n");
			break;
		}

#ifdef MAP_R5
		if ((2 + len) < MAX_DESCRIPTOR_LEN) {
			memcpy(&qos_mgmt_desc_tlv.descriptor[0], (buf-2), 2 + len);

			/* Report SCS Descriptor to 1905daemon one by one.
			* length = QMID(2) + BSSID(6) + Client MAC(6) + Descriptor Len
			*/
			qos_mgmt_desc_tlv.length = 2 + (2 * MAC_ADDR_LEN) + (2 + len);
			wapp_send_1905_msg(wapp, WAPP_SEND_QOS_TLV_MSG, sizeof(qos_mgmt_desc_tlv), (char *)&qos_mgmt_desc_tlv);

			notice(DEBUG_CAT_QOS, "Send QoS SCS Descriptor TLV bssid:"MACSTR" stamac:"MACSTR", tlv_len=%d\n",
				MAC2STR(qos_mgmt_desc_tlv.bssid), MAC2STR(qos_mgmt_desc_tlv.sta_mac), qos_mgmt_desc_tlv.length);
		} else {
			warn(DEBUG_CAT_QOS,
				"SCS Descriptor TLV len=%d is too long, skip to notify 1905d.\n", len);
		}
#endif

		memset(&scs, 0, sizeof(scs));
		pscsparam = &scs.scsparam;
		pqchar = &scs.qchar;

		COPY_MAC_ADDR(pscsparam->sta_mac, peermac);
		pscsparam->scsid = *buf;
		pscsparam->request_type = *(buf + 1);
		buf += 2;
		leftlen -= 2;
		len -= 2;

		sta_code[scs_num].scsid = pscsparam->scsid;
		while (len > 0 && leftlen > 0) {
			if ((*buf) == IE_INTRA_ACCESS_CATE_PRI_ID) {
				subielen = *(buf + 1);
				buf += 2;
				leftlen -= 2;
				pscsparam->up = (*buf) & 0x07;
				pscsparam->alt_queue = (*buf) & 0x08;
				pscsparam->drop_elig = (*buf) & 0x10;
			} else if ((*buf) == IE_TCLAS_PROCESSING_ID) {
				subielen = *(buf + 1);
				buf += 2;
				leftlen -= 2;
				pscsparam->processing = *buf;
			} else if ((*buf) == IE_TCLAS_ELEMENT_ID) {
				subielen = *(buf + 1);
				buf += 2;
				leftlen -= 2;
				if (pscsparam->tclas_num >= MAX_TCLAS_NUM) {
					err(DEBUG_CAT_QOS, "warning, tclas element num(%d) exceed %d.\n", pscsparam->tclas_num,
						 MAX_TCLAS_NUM);
					buf += subielen;
					leftlen -= subielen;
					len -= (subielen + 2);
					break;
				}

				ptclas = &pscsparam->tclas_elem[pscsparam->tclas_num];

				if (*buf != 0xFF)
					err(DEBUG_CAT_QOS, "incorrect tclas element with up:%d .\n", *buf);

				if ((*(buf + 1)) == CLASSIFIER_TYPE4) {
					ptclas->type4.cs_type = *(buf + 1);
					ptclas->type4.cs_mask = *(buf + 2);
					ptclas->type4.version = *(buf + 3);
					if (ptclas->type4.version == VER_IPV4) {
						ptclas->type4.srcIp.ipv4 = *((u32 *)(buf + 4));
						ptclas->type4.destIp.ipv4 = *((u32 *)(buf + 8));
						ptclas->type4.srcPort = *((u16 *)(buf + 12));
						ptclas->type4.destPort = *((u16 *)(buf + 14));
						ptclas->type4.DSCP = *(buf + 16);
						ptclas->type4.u.protocol = *(buf + 17);
					} else if (ptclas->type4.version == VER_IPV6) {
						memcpy(ptclas->type4.srcIp.ipv6, (buf + 4), 16);
						memcpy(ptclas->type4.destIp.ipv6, (buf + 20), 16);
						ptclas->type4.srcPort = *((u16 *)(buf + 36));
						ptclas->type4.destPort = *((u16 *)(buf + 38));
						ptclas->type4.DSCP = *(buf + 40);
						ptclas->type4.u.nextheader = *(buf + 41);
						memcpy(ptclas->type4.flowLabel, (buf + 42), 3);
					}
					pscsparam->tclas_num++;
				} else if ((*(buf + 1)) == CLASSIFIER_TYPE10) {
					ptclas->type10.cs_type = *(buf + 1);
					ptclas->type10.protocolInstance = *(buf + 2);
					ptclas->type10.u.protocol = *(buf + 3);
					filterlen = (subielen - 4) / 2;
					if (filterlen <= MAX_FILTER_LEN) {
						filtervalue = (buf + 4);
						filtermask = (filtervalue + filterlen);

						valid_len = 0;
						for (i = 0; i < filterlen; i++) {
							if (filtermask[i]) {
								ptclas->type10.filterValue[valid_len] = filtervalue[i];
								ptclas->type10.filterMask[valid_len] = filtermask[i];
								valid_len++;
							}
						}
						ptclas->type10.filterlen = valid_len;
					} else {
						err(DEBUG_CAT_QOS, "filter value is too large, filterlen = %d.\n", filterlen);
						ptclas->type10.filterlen = 0;
					}
					pscsparam->tclas_num++;
				} else {
					sta_code[scs_num].stacode = STA_REQUESTED_NOT_SUPPORTED;
					err(DEBUG_CAT_QOS, "not support scs classifier type = %d.\n", (*(buf + 1)));
				}
#ifdef QOS_R3
			} else if ((*buf) == IE_WLAN_EXTENSION &&
				(*(buf+2)) == IE_QOS_CHARACTERISTICS_ID) {
				subielen = *(buf + 1);

				if (subielen >= MIN_QOS_CHARACTERISTICS_IE_LEN &&
					subielen <= MAX_QOS_CHARACTERISTICS_IE_LEN) {

					COPY_MAC_ADDR(pqchar->sta_mac, peermac);
					pqchar->scsid = pscsparam->scsid;
					pqchar->request_type = pscsparam->request_type;
					pqchar->dir = *(buf+3) & 0x03;
					memcpy(pqchar->QosCharIE, buf, (subielen + 2));
				} else
					err(DEBUG_CAT_QOS, "invalid qos characteristics IE len:%d.\n", subielen);
				buf += 2;
				leftlen -= 2;
#endif
			} else {
				err(DEBUG_CAT_QOS, "unknown subelement, ID:%d, len:%d.\n", *buf, (*(buf + 1)));
				subielen = *(buf + 1);
				buf += 2;
				leftlen -= 2;
			}
			buf += subielen;
			leftlen -= subielen;
			len -= (subielen + 2);
		}
#ifdef MAP_R5
		if (pscsparam->request_type == REQUEST_TYPE_ADD && disallow_qos_check(ACT_SCS_REQ, pscsparam->sta_mac))
			sta_code[scs_num].stacode = STA_REQUEST_DECLINED;
		else
#endif
			sta_code[scs_num].stacode = apply_scs_to_ap(wapp, wdev->ifname, &scs);

		scs_num++;
	}

	/*build scs response action frame and send to peer.*/
	len = build_scs_resp_frame(token, sta_code, scs_num, sendbuf, sizeof(sendbuf));
	wapp_drv_send_action_frame(MTK_NL80211_VENDOR_ATTR_SET_ACTION_QOS_ACTION_FRAME, wapp, wdev, channel, 0, peermac, sendbuf, len);

	return;
}
#endif

void wapp_send_qos_map_configure_frame(struct wifi_app *wapp, const char *ifname, unsigned int channel, const u8 *dst,
				       struct dscp_exception *dscp_ex, u8 ex_cnt, struct dscp_range *dscp_rg)
{
	u32 len = 0;
	u8 buf[64] = {0}, *pos, i = 0;
	struct wapp_dev *wdev = NULL;

	if (!ifname) {
		err(DEBUG_CAT_QOS, "Invalid argument\n");
		return;
	}
	wdev = wapp_dev_list_lookup_by_ifname(wapp, ifname);

	if (!dscp_ex || !dscp_rg || !wdev)
		return;

	memset(buf, 0, sizeof(buf));
	len = 0;
	buf[0] = CATEGORY_QOS;
	buf[1] = ACT_QOSMAP_CONFIG;
	len += 2;

	buf[2] = IE_QOS_MAP_SET;
	buf[3] = ex_cnt * 2 + 16;
	len += 2;

	pos = &buf[4];
	/* dscp exception */
	for (i = 0; i < ex_cnt && i < MAX_EXCEPT_CNT; i++) {
		*pos = dscp_ex[i].dscp;
		*(pos + 1) = dscp_ex[i].up;
		;
		pos += 2;
		len += 2;
	}

	/* dscp range */
	for (i = 0; i < UP_MAX; i++) {
		*pos = dscp_rg[i].low;
		*(pos + 1) = dscp_rg[i].high;
		pos += 2;
		len += 2;
	}

	wapp_drv_send_action_frame(MTK_NL80211_VENDOR_ATTR_SET_ACTION_QOS_ACTION_FRAME, wapp, wdev, channel, 0, dst, buf, len);
}

static int wapp_drv_send_up_tuple_expired_notify(struct wifi_app *wapp, const char *ifname, char *buf, u32 buflen)
{
	if (!wapp->drv_ops || !wapp->drv_ops->drv_send_up_tuple_expired)
		return 0;

	return wapp->drv_ops->drv_send_up_tuple_expired(wapp->drv_data, ifname, buf, buflen);
}

void wapp_handle_qos_action_frame(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	u32 len = 0;
	u8 *buf = NULL, *frmbuf = NULL;
	u8 channel = 0;
	u8 peermac[MAC_ADDR_LEN] = {0};
	struct wapp_dev *wdev = NULL;
	struct wapp_qos_action_frame *act_frm = NULL;

	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev || !event_data)
		return;

	act_frm = (struct wapp_qos_action_frame *)&event_data->qos_frm;
	if (!act_frm) {
		err(DEBUG_CAT_QOS, "qos action frame pointer is NULL.\n");
		return;
	}

	if (!act_frm->frm_len || act_frm->frm_len > (sizeof(*event_data) - offsetof(struct wapp_qos_action_frame, frm))) {
		err(DEBUG_CAT_QOS, "qos action frame frm_len:%d is invalid.\n", act_frm->frm_len);
		return;
	}

	len = act_frm->frm_len;
	channel = act_frm->chan;
	frmbuf = (u8 *)os_zalloc(len);
	if (!frmbuf) {
		err(DEBUG_CAT_QOS, "alloc memory fail.\n");
		return;
	}
	memcpy(frmbuf, act_frm->frm, len);
	memcpy(peermac, act_frm->src, MAC_ADDR_LEN);
	buf = frmbuf;

#ifdef MAP_R5
	memset(&qos_mgmt_desc_tlv, 0, sizeof(qos_mgmt_desc_tlv));
	memcpy(qos_mgmt_desc_tlv.bssid, (u8 *)(buf+16), MAC_ADDR_LEN);
	memcpy(qos_mgmt_desc_tlv.sta_mac, peermac, MAC_ADDR_LEN);
	qos_mgmt_desc_tlv.type = QOS_MGMT_DESCRIPTOR_TLV;
#endif
	/* skipping the wlan header part */
	buf += _802_11_HEADER;
	len -= _802_11_HEADER;
	if (buf[0] == CATEGORY_RAVS) {
		if ((buf[1] == ACT_MSCS_REQ) || (buf[1] == ACT_MSCS_RSP))
			wapp_mscs_action_frame_process(wapp, wdev, channel, peermac, buf, len);
#ifdef QOS_R2
		else if ((buf[1] == ACT_SCS_REQ) || (buf[1] == ACT_SCS_RSP))
			wapp_scs_action_frame_process(wapp, wdev, channel, peermac, buf, len);
#endif
		else
			err(DEBUG_CAT_QOS, "unknown action frame, action:%d\n", buf[1]);
#ifdef QOS_R2
	} else if ((buf[0] == CATEGORY_VEND_SPECIFIC_PROTECTED || buf[0] == CATEGORY_VEND_SPECIFIC)) {
		if ((memcmp(&buf[1], WFA_OUI, 3) == 0) && (buf[4] == QOS_ACT_FRM_OUI_TYPE)) {
			if (buf[5] == DSCP_POLICY_QRY || buf[5] == DSCP_POLICY_RSP) {
				wapp_dscp_policy_action_frame_process(wapp, wdev, channel, peermac, buf, len);
			} else if (buf[5] == DSCP_POLICY_REQ) {
				notice(DEBUG_CAT_QOS, "Received DSCP Policy Request Frame\n");
			} else {
				warn(DEBUG_CAT_QOS, "unknown DSCP Policy Frame, Type:%d\n", buf[1]);
			}
		} else {
			err(DEBUG_CAT_QOS, "unknown WFA_OUI:0x%02x%02x%02x, OUIType:0x%x\n", buf[1], buf[2], buf[3], buf[4]);
		}
#endif
#ifdef EPCS_SUPPORT
	} else if (buf[0] == CATEGORY_EHT_PROT_ACT) {
		wapp_eht_action_frame_receive(wapp, wdev, channel, peermac, buf, len);
#endif
	} else {
		err(DEBUG_CAT_QOS, "unknown action frame, category:%d\n", buf[0]);
	}

	os_free(frmbuf);
}

void wapp_handle_mscs_descriptor_element(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL;
	struct classifier_parameter *cs_elem = NULL;
	u16 sta_code = STA_SUCCESS;
	u32 len = 0;

	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);

	if (!wdev || !event_data)
		return;

	cs_elem = (struct classifier_parameter *)&event_data->qos_frm;

	if (cs_elem->request_type == REQUEST_TYPE_REMOVE) {
		sta_code = update_mscs_configuration(wapp, cs_elem);
		wapp_drv_send_event(NL_SET_MSCS_CONFIG, (unsigned char *)cs_elem, sizeof(*cs_elem));
	} else if ((cs_elem->request_type == REQUEST_TYPE_ADD || cs_elem->request_type == REQUEST_TYPE_CHANGE)) {
		sta_code = update_mscs_configuration(wapp, cs_elem);
		wapp_drv_send_event(NL_SET_MSCS_CONFIG, (unsigned char *)cs_elem, sizeof(*cs_elem));
	} else
		sta_code = STA_TERMINATED;

	if (sta_code != STA_SUCCESS) {
		/*build mscs response action frame and send to peer.*/
		len = build_mscs_resp_frame(0, sta_code, sendbuf, sizeof(sendbuf));
		wapp_drv_send_action_frame(MTK_NL80211_VENDOR_ATTR_SET_ACTION_QOS_ACTION_FRAME, wapp, wdev, 0, 0, cs_elem->sta_mac, sendbuf,
					   len);
	}
	return;
}

void wdev_handle_vend_spec_up_tuple_event(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL;
	struct wapp_vend_spec_classifier_para_report *cs_elem = NULL;

	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev || !event_data)
		return;

	cs_elem = (struct wapp_vend_spec_classifier_para_report *)&event_data->qos_frm;

	memcpy(cs_elem->ifname, wdev->ifname, IFNAMSIZ);
	wapp_drv_send_event(NL_SET_VEND_SPECIFIC_CONFIG, (unsigned char *)cs_elem, sizeof(*cs_elem));

	return;
}

static void qos_teardown_client(struct wifi_app *wapp, const char *ifname, u8 *climac)
{
	u32 len = 0;
	struct wapp_dev *wdev = NULL;
	struct classifier_parameter cs_elem;

	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifname(wapp, ifname);
	if (!wdev || !climac)
		return;

	len = build_mscs_resp_frame(0, STA_TERMINATED, sendbuf, sizeof(sendbuf));
	wapp_drv_send_action_frame(MTK_NL80211_VENDOR_ATTR_SET_ACTION_QOS_ACTION_FRAME, wapp, wdev, 0, 0, climac, sendbuf, len);

	memset(sendbuf, 0, sizeof(sendbuf));
	memset(&cs_elem, 0, sizeof(cs_elem));
	memcpy(cs_elem.sta_mac, climac, MAC_ADDR_LEN);
	cs_elem.request_type = REQUEST_TYPE_REMOVE;

	update_mscs_configuration(wapp, &cs_elem);

	wapp_drv_send_event(NL_SET_MSCS_CONFIG, (unsigned char *)&cs_elem, sizeof(cs_elem));
}

#ifdef MAP_R5
#ifdef STANDARD_NL_CMD
void map_update_device_info_sd_nl(struct wifi_app *wapp, struct dev_info *wapp_devinfo)
{
	struct device_info devinfo = {0};

	if (!wapp || !wapp_devinfo)
		return;

	notice(DEBUG_CAT_QOS, "dev_type = %u, mac:"MACSTR", ifname: %s\n",
		wapp_devinfo->iftype, MAC2STR(wapp_devinfo->mac), wapp_devinfo->ifname);

	if (MAC_ADDR_EQUAL(wapp_devinfo->mac, zero_mac) ||
		strlen((char *)wapp_devinfo->ifname) == 0)
		return;

	switch (wapp_devinfo->iftype) {
	case NL80211_IFTYPE_AP:
		devinfo.type = WAPP_DEV_TYPE_AP;
		break;
	case NL80211_IFTYPE_STATION:
		devinfo.type = WAPP_DEV_TYPE_STA;
		break;
	default:
		err(DEBUG_CAT_QOS, "dev_type = %u incorrect for %s\n", wapp_devinfo->iftype,
			wapp_devinfo->ifname);
		return;
	}
	memcpy(devinfo.ifname, wapp_devinfo->ifname, MIN(strlen(wapp_devinfo->ifname), IFNAMSIZ-1));
	memcpy(devinfo.macaddr, wapp_devinfo->mac, MAC_ADDR_LEN);

	wapp_drv_send_event(NL_MAP_UPDATE_DEV_INFO, (unsigned char *)&devinfo, sizeof(devinfo));
}
#endif

void map_update_device_info(struct wifi_app *wapp, wapp_dev_info *wapp_devinfo)
{
	struct device_info devinfo = {0};

	if (!wapp || !wapp_devinfo)
		return;

	notice(DEBUG_CAT_QOS, "dev_type = %u, mac:"MACSTR", ifname: %s\n",
		wapp_devinfo->dev_type, MAC2STR(wapp_devinfo->mac_addr), wapp_devinfo->ifname);

	if (MAC_ADDR_EQUAL(wapp_devinfo->mac_addr, zero_mac) ||
		strlen((char *)wapp_devinfo->ifname) == 0)
		return;

	devinfo.type = wapp_devinfo->dev_type;
	memcpy(devinfo.ifname, wapp_devinfo->ifname, IFNAMSIZ);
	memcpy(devinfo.macaddr, wapp_devinfo->mac_addr, MAC_ADDR_LEN);

	wapp_drv_send_event(NL_MAP_UPDATE_DEV_INFO, (unsigned char *)&devinfo, sizeof(devinfo));
}

int map_qos_management_policy(struct wifi_app *wapp, char *msg_buf, unsigned short msg_len)
{
	struct qos_management_policy *msg = (struct qos_management_policy *)msg_buf;

	if (!msg_buf || (msg_len != sizeof(qos_black_list))) {
		err(DEBUG_CAT_QOS, "invalid msg_buf=%p or msg_len=%d\n", msg_buf, msg_len);
		return -1;
	}

	memset(&qos_black_list, 0, sizeof(qos_black_list));

	if (msg->numMSCSDisallowed <= MAX_NUM_DISALLOWED) {
		qos_black_list.numMSCSDisallowed = msg->numMSCSDisallowed;
		memcpy(qos_black_list.MSCSDisallowed, msg->MSCSDisallowed,
			qos_black_list.numMSCSDisallowed * MAC_ADDR_LEN);
	} else
		warn(DEBUG_CAT_QOS, "number of MSCSDisallowed=%d exceed max=%d\n",
			msg->numMSCSDisallowed, MAX_NUM_DISALLOWED);

	if (msg->numSCSDisallowed <= MAX_NUM_DISALLOWED) {
		qos_black_list.numSCSDisallowed = msg->numSCSDisallowed;
		memcpy(qos_black_list.SCSDisallowed, msg->SCSDisallowed,
			qos_black_list.numSCSDisallowed * MAC_ADDR_LEN);
	} else
		warn(DEBUG_CAT_QOS, "number of SCSDisallowed=%d exceed max=%d\n",
			msg->numSCSDisallowed, MAX_NUM_DISALLOWED);

	return 0;
}

int map_parse_mscs_descriptor_tlv(u8 *buf_tlv, u32 length, struct classifier_parameter *cs_param)
{
	u32 len = 0;
	u8 subielen = 0;
	u8 *buf = buf_tlv;

	/*MSCS Descriptor TLV sanity check*/
	if (!buf || !length || !cs_param) {
		err(DEBUG_CAT_QOS, "sanity check failed. buf:%p, len:%d, cs_param:%p\n", buf, length, cs_param);
		return -1;
	}

	len = length;
	if ((((*buf) == REQUEST_TYPE_ADD || (*buf) == REQUEST_TYPE_CHANGE) && len < 13) ||
		(((*buf) == REQUEST_TYPE_REMOVE) && len < 7) ||
		((*buf) >= REQUEST_TYPE_UNKNOWN)) {
		err(DEBUG_CAT_QOS, "invalid mscs descriptor element, type:%d, len:%d.\n", *buf, len);
		return -1;
	}

	cs_param->request_type = *buf;
	cs_param->up_bitmap = *(buf+1);
	cs_param->up_limit = (*(buf+2)) & 0x07;
	cs_param->timeout = ((*((UINT32 *)(buf+3)))*1024)/1000000;
	buf += 7;
	len -= 7;

	if (len < 4)
		return 0;

	if ((*buf) == IE_WLAN_EXTENSION && (*(buf+2)) == IE_EXTENSION_ID_TCLAS_MASK) {
		subielen = *(buf+1);
		buf += 2;
		len -= 2;
		if (subielen > len) {
			err(DEBUG_CAT_QOS, "parse MSCS decriptor fail, subielen(%u) > len(%d).\n", subielen, len);
			return -1;
		}

		if ((*(buf+1)) == CLASSIFIER_TYPE4) {
			cs_param->cs.header.cs_type = *(buf+1);
			cs_param->cs.header.cs_mask = *(buf+2);
		} else {
			err(DEBUG_CAT_QOS, "not support mscs classifier type=%d.\n", (*buf));
			return -1;
		}
	}

	return 0;
}

int map_parse_scs_descriptor_tlv(u8 *buf_tlv, u32 length, struct qos_management_descriptor_db *qosdesc)
{
	int leftlen = 0;
	u8 filterlen = 0, i = 0, valid_len = 0;
	u8 *filtervalue = NULL, *filtermask = NULL;
	u8 *buf = buf_tlv;
	u8 subielen = 0;
	union _tclas_element *ptclas = NULL;
	struct scs_classifier_parameter *scs_param = NULL;

	if (!buf_tlv || !length || !qosdesc) {
		err(DEBUG_CAT_QOS, "invalid paramenters, buf_tlv:%p, len:%u, qosdesc:%p.\n", buf_tlv, length, qosdesc);
		return -1;
	}

	scs_param = &qosdesc->descElem.scs;

	leftlen = length;
	scs_param->scsid = *buf;
	scs_param->request_type = *(buf+1);
	buf += 2;
	leftlen -= 2;

	while (leftlen > 0) {
		if ((*buf) == IE_INTRA_ACCESS_CATE_PRI_ID) {
			subielen = *(buf+1);
			buf += 2;
			scs_param->up = (*buf) & 0x07;
			scs_param->alt_queue = (*buf) & 0x08;
			scs_param->drop_elig = (*buf) & 0x10;
		} else if ((*buf) == IE_TCLAS_PROCESSING_ID) {
			subielen = *(buf+1);
			buf += 2;
			scs_param->processing = *buf;
		} else if ((*buf) == IE_TCLAS_ELEMENT_ID) {
			subielen = *(buf+1);
			buf += 2;
			if (scs_param->tclas_num >= MAX_TCLAS_NUM) {
				warn(DEBUG_CAT_QOS, "tclas element num(%d) exceed %d.\n", scs_param->tclas_num,	MAX_TCLAS_NUM);
				buf += subielen;
				leftlen -= (subielen + 2);
				break;
			}

			ptclas = &scs_param->tclas_elem[scs_param->tclas_num];

			if (*buf != 0xFF)
				warn(DEBUG_CAT_QOS, "incorrect tclas element with up:%d.\n", *buf);

			if ((*(buf+1)) == CLASSIFIER_TYPE4) {
				ptclas->type4.cs_type = *(buf+1);
				ptclas->type4.cs_mask = *(buf+2);
				ptclas->type4.version = *(buf+3);
				if (ptclas->type4.version == VER_IPV4) {
					ptclas->type4.srcIp.ipv4 = *((u32 *)(buf+4));
					ptclas->type4.destIp.ipv4 = *((u32 *)(buf+8));
					ptclas->type4.srcPort = *((u16 *)(buf+12));
					ptclas->type4.destPort = *((u16 *)(buf+14));
					ptclas->type4.DSCP = *(buf+16);
					ptclas->type4.u.protocol = *(buf+17);
				} else if (ptclas->type4.version == VER_IPV6) {
					memcpy(ptclas->type4.srcIp.ipv6, (buf+4), 16);
					memcpy(ptclas->type4.destIp.ipv6, (buf+20), 16);
					ptclas->type4.srcPort = *((u16 *)(buf+36));
					ptclas->type4.destPort = *((u16 *)(buf+38));
					ptclas->type4.DSCP = *(buf+40);
					ptclas->type4.u.nextheader = *(buf+41);
					memcpy(ptclas->type4.flowLabel, (buf+42), 3);
				}
				scs_param->tclas_num++;
			} else if ((*(buf+1)) == CLASSIFIER_TYPE10) {
				ptclas->type10.cs_type = *(buf+1);
				ptclas->type10.protocolInstance = *(buf+2);
				ptclas->type10.u.protocol = *(buf+3);
				filterlen = (subielen - 4) / 2;
				if (filterlen <= MAX_FILTER_LEN) {
					filtervalue = (buf + 4);
					filtermask = (filtervalue + filterlen);

					valid_len = 0;
					for (i = 0; i < filterlen; i++) {
						if (filtermask[i]) {
							ptclas->type10.filterValue[valid_len] = filtervalue[i];
							ptclas->type10.filterMask[valid_len] = filtermask[i];
							valid_len++;
						}
					}
					ptclas->type10.filterlen = valid_len;
				} else {
					err(DEBUG_CAT_QOS, "filter value is too large, filterlen = %d.\n",	filterlen);
					ptclas->type10.filterlen = 0;
				}
				scs_param->tclas_num++;
			} else {
				err(DEBUG_CAT_QOS, "not support scs classifier type = %d.\n", (*(buf+1)));
			}

#ifdef MAP_R6
		} else if ((*buf) == IE_WLAN_EXTENSION && (*(buf+2)) == IE_QOS_CHARACTERISTICS_ID) {
			subielen = *(buf + 1);
			if (subielen >= MIN_QOS_CHARACTERISTICS_IE_LEN &&
				subielen <= MAX_QOS_CHARACTERISTICS_IE_LEN) {
				qosdesc->qchar.scsid = scs_param->scsid;
				qosdesc->qchar.request_type = scs_param->request_type;
				qosdesc->qchar.dir = *(buf+3) & 0x03;
				memcpy(qosdesc->qchar.QosCharIE, buf, (subielen + 2));

			} else
				err(DEBUG_CAT_QOS, "invalid qos characteristics IE len:%d.\n", subielen);
			buf += 2;
#endif
		} else {
			err(DEBUG_CAT_QOS, "unknown subelement, ID:%d, len:%d.\n", *buf, (*(buf+1)));
			subielen = *(buf+1);
			buf += 2;
		}
		buf += subielen;
		leftlen -= (subielen + 2);
	}

	return 0;
}

int map_parse_qos_management_elem(u8 *buf_tlv, u32 length, struct qos_management_element_attri *qos_mgmt_elem)
{
	int leftlen = 0;
	u8 *buf = buf_tlv, *classifier;
	u8 elemid, elemlen = 0;
	struct tclas_attribute_ipv4 *ipv4 = NULL;
	struct tclas_attribute_ipv6 *ipv6 = NULL;

	if (!buf_tlv || !length || !qos_mgmt_elem) {
		err(DEBUG_CAT_QOS, "invalid paramenters, buf_tlv:%p, len:%u, qos_mgmt_elem:%p.\n",
			buf_tlv, length, qos_mgmt_elem);
		return -1;
	}

	leftlen = length;
	do {
		elemid = *buf;
		elemlen = *(buf + 1);
		if (elemlen > leftlen)
			break;

		switch (elemid) {
		case ATTR_ID_PORT_RANGE:
			qos_mgmt_elem->portrange.attrid = ATTR_ID_PORT_RANGE;
			qos_mgmt_elem->portrange.length = 4;
			qos_mgmt_elem->portrange.startp = ntohs((*(u16 *)(buf + 2)));
			qos_mgmt_elem->portrange.endp = ntohs((*(u16 *)(buf + 4)));
			break;

		case ATTR_ID_DSCP_POLICY:
			qos_mgmt_elem->policyattri.attrid = ATTR_ID_DSCP_POLICY;
			qos_mgmt_elem->policyattri.length = 3;
			qos_mgmt_elem->policyattri.policyid = *(buf + 2);
			qos_mgmt_elem->policyattri.request_type = *(buf + 3);
			qos_mgmt_elem->policyattri.dscp = *(buf + 4);
			break;
		case ATTR_ID_DOMAIN_NAME:
			qos_mgmt_elem->domainattri.attrid = ATTR_ID_DOMAIN_NAME;
			if (elemlen < MAX_DOMAIN_NAME_LEN)
				qos_mgmt_elem->domainattri.length = elemlen;
			else
				qos_mgmt_elem->domainattri.length = MAX_DOMAIN_NAME_LEN - 1;
			memcpy(qos_mgmt_elem->domainattri.domainname, (buf + 2), qos_mgmt_elem->domainattri.length);
			break;
		case ATTR_ID_TCLAS:
			classifier = buf + 2;
			if ((*classifier) == CLASSIFIER_TYPE4) {
				ipv4 = &qos_mgmt_elem->tclasattri.ipv4;
				ipv6 = &qos_mgmt_elem->tclasattri.ipv6;

				ipv4->attrid = ATTR_ID_TCLAS;
				ipv4->length = elemlen;
				ipv4->cs_type = *classifier;
				ipv4->cs_mask = *(classifier + 1);
				ipv4->version = *(classifier + 2);
				if (ipv4->version == VER_IPV4) {
					ipv4->srcIp = *((u32 *)(classifier + 3));
					ipv4->dstIp = *((u32 *)(classifier + 7));
					ipv4->srcPort = *((u16 *)(classifier + 11));
					ipv4->dstPort = *((u16 *)(classifier + 13));
					ipv4->DSCP = *(classifier + 15);
					ipv4->protocol = *(classifier + 16);
				} else if (ipv4->version == VER_IPV6) {
					memcpy(ipv6->srcIp, (classifier + 3), 16);
					memcpy(ipv6->dstIp, (classifier + 19), 16);
					ipv6->srcPort = *((u16 *)(classifier + 35));
					ipv6->dstPort = *((u16 *)(classifier + 37));
					ipv6->DSCP = *(classifier + 39);
					ipv6->nextheader = *(classifier + 40);
					memcpy(ipv6->flowLabel, (classifier + 41), 3);
				}
			} else {
				warn(DEBUG_CAT_QOS, "unknown tclas classifier type:%d\n", *classifier);
			}
			break;
		default:
			warn(DEBUG_CAT_QOS, "unknown dscp policy attri, elemid:%d, elemlen:%d.\n", elemid, elemlen);
			break;
		}
		buf += (elemlen + 2);
		leftlen -= (elemlen + 2);
	} while (elemlen > 0 && leftlen > 0);

	return 0;
}

static inline u8 build_dscp_policy_req_frame_with_IE(u8 *frmbuf, u16 buflen, u8 *qosIE, u8 IElen)
{
	static u8 token = 1;
	u8 frmlen = 0;

	if (!frmbuf || !buflen || !qosIE || !IElen)
		return 0;

	memset(frmbuf, 0, buflen);
	frmlen = 0;

	/*build QOS Policy Request Frame Header*/
	frmbuf[frmlen] = CATEGORY_VEND_SPECIFIC_PROTECTED;
	frmlen++;
	memcpy(&frmbuf[frmlen], WFA_OUI, sizeof(WFA_OUI));
	frmlen += sizeof(WFA_OUI);
	frmbuf[frmlen] = QOS_ACT_FRM_OUI_TYPE;
	frmlen++;
	frmbuf[frmlen] = DSCP_POLICY_REQ;
	frmlen++;
	frmbuf[frmlen] = token++;
	frmlen++;
	frmbuf[frmlen] = 0; /*Request Control field*/
	frmlen++;

	if ((frmlen + IElen) <= 0xFF) {
		/*copy QoS Management elements*/
		memcpy(&frmbuf[frmlen], qosIE, IElen);
		frmlen += IElen;
	}

	return frmlen;
}

int map_qos_management_descriptor(struct wifi_app *wapp, char *msg_buf, unsigned short msg_len)
{
	int ret = 0;
	u8 *buf = NULL, *ies_buf = NULL;
	u32 length = 0, leftlength = 0, frmlen = 0, ies_len = 0;
	struct wapp_dev *wdev = NULL;
	struct qos_management_descriptor_db qosDesc;
	struct qos_management_descriptor_tlv *msg = (struct qos_management_descriptor_tlv *)msg_buf;
#ifdef MAP_R6
	struct qos_characteristics *qoschar = NULL;
#endif

	if (!msg_buf || (msg_len != sizeof(*msg))) {
		err(DEBUG_CAT_QOS, "invalid msg_buf=%p or msg_len=%d\n", msg_buf, msg_len);
		return -1;
	}

	msg->length = ntohs(msg->length);
	if (msg->type != QOS_MGMT_DESCRIPTOR_TLV ||
		msg->length > (2 + MAC_ADDR_LEN*2 + MAX_DESCRIPTOR_LEN) ||
		msg->length < (2 + MAC_ADDR_LEN*2)) {
		err(DEBUG_CAT_QOS, "invalid msg type=0x%x or length=%d\n", msg->type, msg->length);
		return -1;
	}

	memset(&qosDesc, 0, sizeof(qosDesc));
	qosDesc.qmid = msg->qmid;
	memcpy(qosDesc.bssid, msg->bssid, MAC_ADDR_LEN);
	memcpy(qosDesc.sta_mac, msg->sta_mac, MAC_ADDR_LEN);

	buf = &msg->descriptor[0];
	leftlength =  msg_len - offsetof(struct qos_management_descriptor_tlv, descriptor);

	while (leftlength) {
		length = *(buf+1);
		if (!length || (leftlength < length))
			break;

		memset(&qosDesc.descElem, 0, sizeof(qosDesc.descElem));
		if ((*buf) == IE_WLAN_EXTENSION && (*(buf+2)) == IE_EXTENSION_ID_MSCS_DESC) { /*MSCS Descriptor TLV*/
			debug(DEBUG_CAT_QOS, "MSCS Descriptor TLV, length=%d\n", msg->length);
			ret = map_parse_mscs_descriptor_tlv((buf+3), length-1, &qosDesc.descElem.mscs);
			if (ret != -1) {
				COPY_MAC_ADDR(qosDesc.descElem.mscs.sta_mac, qosDesc.sta_mac);
				qosDesc.desctype = DESCRIPTOR_TYPE_MSCS;

				wapp_drv_send_event(NL_MAP_SET_MSCS_CONFIG,
					(unsigned char *)&qosDesc.descElem.mscs, sizeof(qosDesc.descElem.mscs));
			}
		} else if ((*buf) == IE_SCS_DESCRIPTOR_ELEMENT_ID) { /*SCS Descriptor list*/
			debug(DEBUG_CAT_QOS, "SCS Descriptor TLV, length=%d\n", msg->length);
			ret = map_parse_scs_descriptor_tlv((buf+2), length, &qosDesc);
			if (ret != -1) {
				COPY_MAC_ADDR(qosDesc.descElem.scs.sta_mac, qosDesc.sta_mac);
				qosDesc.desctype = DESCRIPTOR_TYPE_SCS;

				wapp_drv_send_event(NL_MAP_SET_SCS_CONFIG,
					(unsigned char *)&qosDesc.descElem.scs, sizeof(qosDesc.descElem.scs));

#ifdef MAP_R6
				qoschar = &qosDesc.qchar;
				if (qoschar->QosCharIE[0] == IE_WLAN_EXTENSION &&
					qoschar->QosCharIE[2] == IE_QOS_CHARACTERISTICS_ID) {
					COPY_MAC_ADDR(qoschar->sta_mac, qosDesc.sta_mac);
					wdev = wapp_dev_list_lookup_by_mac_and_type(wapp, qosDesc.bssid, WAPP_DEV_TYPE_AP);
					if (wdev != NULL)
						wapp_drv_set_qos_characteristics_ie(wapp, wdev->ifname,
							(char *)qoschar, sizeof(*qoschar));
				}
#endif
			}
		} else if ((*buf) == QOS_MGMT_ELEMENT_ID && /*QoS Management element*/
			(memcmp(&buf[2], WFA_OUI, 3) == 0) && buf[5] == QOS_MGMT_IE_OUI_TYPE) {
			ret = map_parse_qos_management_elem(&buf[6], length-4, &qosDesc.descElem.qosmgmtelem);
			if (ret != -1)
				qosDesc.desctype = DESCRIPTOR_TYPE_QOS_ELEMENT;

			if (!ies_buf)
				ies_buf = (u8 *)os_zalloc(SEND_BUF_LEN);

			if (!ies_buf) {
				err(DEBUG_CAT_QOS, "dscp ie buf allocate failed.\n");
				continue;
			}
			if ((ies_len + length + 2) > SEND_BUF_LEN) {
				err(DEBUG_CAT_QOS, "dscp ie buf is full.\n");
				continue;
			}

			memcpy(ies_buf + ies_len, buf, (length + 2));
			ies_len += (length + 2);
		} else {
			err(DEBUG_CAT_QOS, "unknown descriptor type, buf[0]:0x%x, buf[1]:0x%x, buf[2]:0x%x\n",
				buf[0], buf[1], buf[2]);
		}

		add_qos_mgmt_descriptor(&qosDesc);

		buf += (length + 2);
		leftlength -= (length + 2);
	}


	if (ies_len) {
		frmlen = build_dscp_policy_req_frame_with_IE(sendbuf, sizeof(sendbuf), ies_buf, ies_len);
		wdev = wapp_dev_list_lookup_by_mac_and_type(wapp, qosDesc.bssid, WAPP_DEV_TYPE_AP);
		if (frmlen && wdev && wdev->radio) {
			wapp_drv_send_action_frame(MTK_NL80211_VENDOR_ATTR_SET_ACTION_QOS_ACTION_FRAME,
				wapp, wdev, wdev->radio->op_ch, 0, qosDesc.sta_mac, sendbuf, frmlen);
		}
	}

	if (ies_buf)
		os_free(ies_buf);

	return 0;
}

int map_qos_convert_dscp_tbl_to_qos_map(struct wifi_app *wapp, unsigned char *dptbl)
{
	u8 i = 0, start = 0;
	struct qos_map qmap;

	if (!wapp || !dptbl)
		return -1;

	memset(&qmap, 0, sizeof(qmap));
	memset(&qmap.dscp_rg, 0xFF, sizeof(qmap.dscp_rg));

	for (i = 0; i < DSCP_TBL_SIZE; i++) {
		if ((i == 0 && dptbl[i] != dptbl[i+1]) ||
			(i == (DSCP_TBL_SIZE - 1) && dptbl[i-1] != dptbl[i]) ||
			((i > 0 && i < (DSCP_TBL_SIZE - 1)) && (dptbl[i-1] != dptbl[i] && dptbl[i] != dptbl[i+1]))) {
			if (qmap.num >= MAX_EXCEPT_CNT) {
				err(DEBUG_CAT_QOS, "convert dscp tbl fail, qmap.num:%d\n", qmap.num);
				return -1;
			}
			qmap.dscp_ex[qmap.num].dscp = i;
			qmap.dscp_ex[qmap.num].up = dptbl[i];

			debug(DEBUG_CAT_QOS, "i=%d, dscp_ex[%d].(dscp=%d, up=%d)\n", i, qmap.num, i, dptbl[i]);
			qmap.num++;
		}

		if (dptbl[start] != dptbl[i]) {
			if (i == start + 1) {
				start = i;
			} else if (i > start+1) {
				if (qmap.dscp_rg[dptbl[start]].low == 0xFF &&
					qmap.dscp_rg[dptbl[start]].high == 0xFF) {
					qmap.dscp_rg[dptbl[start]].low = start;
					qmap.dscp_rg[dptbl[start]].high = i - 1;

					debug(DEBUG_CAT_QOS, "start=%d, dscp_rg[%d].(low=%d, hight=%d)\n",
						start, dptbl[start], start, i - 1);

					start = i;
				} else {
					err(DEBUG_CAT_QOS, "convert dscp tbl fail, dscp_rg[%d] already used.\n", dptbl[start]);
					return -1;
				}
			}
		} else if ((i == DSCP_TBL_SIZE - 1) && (i > start+1)) {
			if (qmap.dscp_rg[dptbl[start]].low == 0xFF &&
				qmap.dscp_rg[dptbl[start]].high == 0xFF) {
				qmap.dscp_rg[dptbl[start]].low = start;
				qmap.dscp_rg[dptbl[start]].high = i;

				debug(DEBUG_CAT_QOS, "start=%d, dscp_rg[%d].(low=%d, hight=%d)\n", start, dptbl[start], start, i);

				start = i;
			} else {
				err(DEBUG_CAT_QOS, "convert dscp tbl fail, dscp_rg[%d] already used.\n", dptbl[start]);
				return -1;
			}
		}
	}

	send_qosmap_to_peer_sta(wapp, NULL, &qmap);
	apply_qosmap_to_ap_local(wapp, NULL, &qmap);

	return 0;
}

int map_qos_dscp_mapping_table_update(struct wifi_app *wapp, char *msg_buf, unsigned short msg_len)
{
	u8 i = 0;
	unsigned char *dptbl = (unsigned char *)msg_buf;

	if (!msg_buf || (msg_len != DSCP_TBL_SIZE)) {
		err(DEBUG_CAT_QOS, "invalid msg_buf=%p or msg_len=%d\n", msg_buf, msg_len);
		return -1;
	}

	for (i = 0; i < DSCP_TBL_SIZE; i++) {
		if ((dscp2pcp.dptbl[i] != dptbl[i]) && (dptbl[i] < UP_MAX)) {
			dscp2pcp.dptbl[i] = dptbl[i];
			dscp2pcp.update = 1;
		}
	}

	if (dscp2pcp.update == 1)
		map_qos_convert_dscp_tbl_to_qos_map(wapp, dscp2pcp.dptbl);

	return 0;
}

static void add_qos_mgmt_descriptor(struct qos_management_descriptor_db *qos_desc)
{
	struct qos_management_descriptor_db *tmp;

	if (!qos_desc)
		return;

	/* Sanity check*/
	if (MAC_ADDR_EQUAL(qos_desc->bssid, zero_mac) ||
		MAC_ADDR_EQUAL(qos_desc->sta_mac, zero_mac) ||
		((qos_desc->desctype != DESCRIPTOR_TYPE_MSCS) &&
		(qos_desc->desctype != DESCRIPTOR_TYPE_SCS) &&
		(qos_desc->desctype != DESCRIPTOR_TYPE_QOS_ELEMENT))) {
		err(DEBUG_CAT_QOS, "sanity check fail. bssid: "MACSTR", sta_mac: "MACSTR", desctype:%d.\n",
			MAC2STR(qos_desc->bssid), MAC2STR(qos_desc->sta_mac), qos_desc->desctype);
		return;
	}

	if (qos_mgmt_descriptor_cnt >= 0xFF) {
		err(DEBUG_CAT_QOS, "qos mgmt descripter excced list size:%u.\n", qos_mgmt_descriptor_cnt);
		return;
	}

	tmp = (struct qos_management_descriptor_db *)os_zalloc(sizeof(struct qos_management_descriptor_db));
	if (tmp) {
		memcpy(tmp, qos_desc, sizeof(*qos_desc));
		dl_list_add_tail(&qos_mgmt_descriptor_list, &tmp->list);
		qos_mgmt_descriptor_cnt++;
	} else {
		err(DEBUG_CAT_QOS, "Memory Alloc Fail\n");
	}
}
/*
*
static void del_qos_mgmt_descriptor(struct qos_management_descriptor_db *qos_desc)
{
	struct qos_management_descriptor_db *pos, *tmp;

	if (!qos_desc)
		return;

	dl_list_for_each_safe(pos, tmp, &qos_mgmt_descriptor_list, struct qos_management_descriptor_db, list) {
		if (pos->qmid == qos_desc->qmid) {
			dl_list_del(&pos->list);
			os_free(pos);
		}
	}
}
*
*/
static void clean_qos_mgmt_descriptor(void)
{
	struct qos_management_descriptor_db *pos, *pos_tmp;

	dl_list_for_each_safe(pos, pos_tmp, &qos_mgmt_descriptor_list, struct qos_management_descriptor_db, list) {
		dl_list_del(&pos->list);
		os_free(pos);
	}
	qos_mgmt_descriptor_cnt = 0;
}

static int disallow_qos_check(unsigned char act_type, unsigned char *clientmac)
{
	unsigned char i = 0;

	if (!clientmac || MAC_ADDR_EQUAL(clientmac, zero_mac))
		return 1;

	if (act_type == ACT_MSCS_REQ) {
		for (i = 0; (i < qos_black_list.numMSCSDisallowed) && (i < MAX_NUM_DISALLOWED); i++) {
			if (MAC_ADDR_EQUAL(clientmac, qos_black_list.MSCSDisallowed[i]))
				return 1;
		}
	}

	if (act_type == ACT_SCS_REQ) {
		for (i = 0; (i < qos_black_list.numSCSDisallowed) && (i < MAX_NUM_DISALLOWED); i++) {
			if (MAC_ADDR_EQUAL(clientmac, qos_black_list.SCSDisallowed[i]))
				return 1;
		}
	}

	return 0;
}

static void map_send_tunnel_dscp_policy_action_frm(
	struct wifi_app *wapp, u8 *clientaddr, u8 *frmbuf, u32 frmlen, u8 frmtype)
{
	int send_pkt_len = 0;
	struct tunneled_msg_tlv *tunelled_tlv = NULL;
	u8 proto_type = 0;

	if (!wapp || !clientaddr || !frmbuf || !frmlen)
		return;

	if (frmtype == DSCP_POLICY_QRY)
		proto_type = TUNNELLED_DSCP_QUERY;
	else if (frmtype == DSCP_POLICY_RSP)
		proto_type = TUNNELLED_DSCP_RESPONSE;
	else
		proto_type = 0xFF;

	send_pkt_len = sizeof(struct tunneled_msg_tlv) + frmlen;
	tunelled_tlv = os_zalloc(send_pkt_len);
	if (tunelled_tlv == NULL) {
		err(DEBUG_CAT_QOS, "memory alloc fail.\n");
		return;
	}

	tunelled_tlv->payload_len = frmlen;
	os_memcpy(&tunelled_tlv->payload[0], frmbuf, frmlen);

	map_build_and_send_tunneled_message(wapp, clientaddr, proto_type, 1, tunelled_tlv);
}

int map_set_device_role(u8 devrole)
{
	int ret = 0;

	memcpy(&sendbuf[0], &devrole, 1);
	ret = wapp_drv_send_event(NL_MAP_SET_DEV_ROLE, sendbuf, 1);
	return ret;
}
#endif

void wdev_handle_assoc_sta_info(struct wifi_app *wapp, u32 ifindex, u8 *sta_mac)
{
	struct wapp_dev *wdev = NULL;
	struct associated_sta_info_db *stainfo = NULL, *pos = NULL;

	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev || !wdev->radio || !sta_mac)
		return;

	dl_list_for_each(pos, &assoc_sta_list, struct associated_sta_info_db, list) {
		if (MAC_ADDR_EQUAL(pos->src, sta_mac)) {
			err(DEBUG_CAT_QOS, "STA "MACSTR" already in the list.\n", MAC2STR(pos->src));
			return;
		}
	}

	if (assoc_sta_cnt >= 0xFF) {
		warn(DEBUG_CAT_QOS, "sta list arrived max size.\n");
		return;
	}

	stainfo = (struct associated_sta_info_db *)os_zalloc(sizeof(struct associated_sta_info_db));
	if (!stainfo)
		return;

	memcpy(stainfo->src, sta_mac, MAC_ADDR_LEN);
	memset(stainfo->ifname, 0, IFNAMSIZ);
	memcpy(stainfo->ifname, wdev->ifname, (IFNAMSIZ-1));
	stainfo->channel = wdev->radio->op_ch;

	dl_list_add_tail(&assoc_sta_list, &stainfo->list);
	assoc_sta_cnt++;

	notice(DEBUG_CAT_QOS, "STA "MACSTR" connected to %s, on channel:%d.\n",
			MAC2STR(stainfo->src), stainfo->ifname, stainfo->channel);

}

void clean_assoc_sta_list(void)
{
	struct associated_sta_info_db *pos = NULL, *pos_tmp = NULL;

	dl_list_for_each_safe(pos, pos_tmp, &assoc_sta_list, struct associated_sta_info_db, list) {
		dl_list_del(&pos->list);
		os_free(pos);
	}
	assoc_sta_cnt = 0;
}

void clean_iptuple_list(void)
{
	struct ip_tuple_db *pos = NULL, *pos_tmp = NULL;

	dl_list_for_each_safe(pos, pos_tmp, &perflow_tuple_list, struct ip_tuple_db, list) {
		dl_list_del(&pos->list);
		os_free(pos);
	}
	perflow_tuple_cnt = 0;
}

int build_qos_characteristics_ie(struct scs_configuration *pscs)
{
	int ret = STATUS_SUCCESS;
	unsigned int u4value = 0;
	unsigned char *buf = NULL, len = 0;
	struct qos_characteristics *pqchar = NULL;
	struct qoschar_user_setting *pqcharcfg = NULL;
	struct qchar_control_info ctrlinfo = {0};

	if (!pscs)
		return STATUS_INVALID_POINTER;

	pqcharcfg = &pscs->qcharconfig;
	pqchar = &pscs->qchar;

	if (MAC_ADDR_EQUAL(pscs->scsparam.sta_mac, zero_mac))
		return STATUS_INVALID_STAMAC;
	else if (pscs->scsparam.request_type != REQUEST_TYPE_ADD &&
		pscs->scsparam.request_type != REQUEST_TYPE_REMOVE)
		return STATUS_INVALID_CMD_TYPE;
	else if (pqcharcfg->qchar_mask == 0)
		return STATUS_INSUFFICIENT_PARAM;
	else if (pqcharcfg->dir != DIR_UPLINK && pqcharcfg->dir != DIR_DOWNLINK)
		return STATUS_INVALID_DIR;

	os_memcpy(pqchar->sta_mac, pscs->scsparam.sta_mac, MAC_ADDR_LEN);
	pqchar->scsid = pscs->scsparam.scsid;
	pqchar->request_type = pscs->scsparam.request_type;
	pqchar->dir = pqcharcfg->dir;

	buf = pqchar->QosCharIE;

	/*Element ID*/
	buf[len] = IE_WLAN_EXTENSION;
	len += 1;

	/*Length*/
	buf[len] = 19;
	len += 1;

	/*Element ID Extension*/
	buf[len] = IE_QOS_CHARACTERISTICS_ID;
	len += 1;

	/*Control Info*/
	os_memset(&ctrlinfo, 0, sizeof(ctrlinfo));
	ctrlinfo.dir = pqcharcfg->dir;
	ctrlinfo.tid = pscs->scsparam.up;
	ctrlinfo.up = pscs->scsparam.up;
	os_memcpy(&buf[len], (unsigned int *)&ctrlinfo, 4);
	len += 4;

	/*Minimum Service Interval*/
	if (pqcharcfg->qchar_mask & QCHAR_MASK_MIN_INTERVAL)
		*((u32 *)&buf[len]) = pqcharcfg->min_interval;
	else
		*((u32 *)&buf[len]) = 0;
	len += 4;

	/*Maximum Service Interval*/
	if (pqcharcfg->qchar_mask & QCHAR_MASK_MAX_INTERVAL)
		*((u32 *)&buf[len]) = pqcharcfg->max_interval;
	else
		*((u32 *)&buf[len]) = 0;
	len += 4;

	/*Minimum Data Rate*/
	if (pqcharcfg->qchar_mask & QCHAR_MASK_MIN_DATA_RATE)
		u4value = pqcharcfg->min_datarate;
	else
		u4value = 0;
	os_memcpy(&buf[len], &u4value, 3);
	len += 3;

	/*Delay Bound*/
	if (pqcharcfg->qchar_mask & QCHAR_MASK_DELAY_BOUND)
		u4value = pqcharcfg->delaybound;
	else
		u4value = 0;
	os_memcpy(&buf[len], &u4value, 3);
	len += 3;

	return ret;
}

int str2protocol(char *strp)
{
	int i = 0, tblsize = 0;

	if (!strp)
		return IP_TYPE_UNKNOWN;

	tblsize = ARRAY_SIZE(ip_protocol_tbl);
	for (i = 0; i < tblsize; i++) {
		if (os_strncmp(strp, ip_protocol_tbl[i].str, os_strlen(ip_protocol_tbl[i].str)) == 0)
			return ip_protocol_tbl[i].idx;
	}

	return IP_TYPE_UNKNOWN;
}

int convert_mac_addr(char *strmac, unsigned char *mac_addr)
{
	int ret = STATUS_SUCCESS;
	unsigned char i = 0;
	char *token = NULL, *pos = NULL;

	if (!strmac || !mac_addr) {
		err(DEBUG_CAT_QOS, "invalid parameters, strmac:%p, mac_addr:%p\n", strmac, mac_addr);
		return STATUS_INVALID_POINTER;
	}

	if (!strlen(strmac)) {
		err(DEBUG_CAT_QOS, "strmac len is 0.\n");
		return STATUS_INVALID_PARAM;
	}

	token = strtok_r(strmac, ":", &pos);
	while (token != NULL) {
		AtoH(token, (char *) &mac_addr[i], 1);
		i++;
		if (i >= MAC_ADDR_LEN)
			break;
		token = strtok_r(NULL, ":", &pos);
	}

	if (i != MAC_ADDR_LEN) {
		os_memset(mac_addr, 0, MAC_ADDR_LEN);
		ret = STATUS_INVALID_STAMAC;
	}
	return ret;
}

unsigned char convert_action(char *strop)
{
	unsigned char optype = REQUEST_TYPE_UNKNOWN;

	if (os_strncmp(strop, "add", os_strlen("add")) == 0)
		optype = REQUEST_TYPE_ADD;
	else if (os_strncmp(strop, "remove", os_strlen("remove")) == 0)
		optype = REQUEST_TYPE_REMOVE;
	else if (os_strncmp(strop, "change", os_strlen("change")) == 0)
		optype = REQUEST_TYPE_CHANGE;
	else
		err(DEBUG_CAT_QOS, "invalid op:%s\n", strop);

	return optype;
}

unsigned char convert_strbitmap2i(char *strbitmap)
{
	char *p = NULL;
	unsigned char i = 0, ret = 0;

	if (!strbitmap || !strlen(strbitmap))
		return ret;

	p = strbitmap;
	for (i = 0; i < strlen(strbitmap) && i < 8; i++) {
		if (*p++ == '1')
			ret |= (1 << i);
	}

	return ret;
}

char *convert_i2strbitmap(unsigned char value)
{
	unsigned char i = 0;

	memset(g_bitmap, 0, sizeof(g_bitmap));
	for (i = 0; i < 8; i++) {
		if (value & (1 << i))
			g_bitmap[i] = '1';
		else
			g_bitmap[i] = '0';
	}
	g_bitmap[8] = '\0';

	return g_bitmap;
}

int convert_ip_address(u8 type, char *strip, char *buf, int buflen)
{
	if (!strip || !buf || !buflen)
		return STATUS_INVALID_POINTER;

	if (type == VER_IPV4) {
		if (buflen < 4) {
			err(DEBUG_CAT_QOS, "invalid buflen: %d\n", buflen);
			return STATUS_INVALID_BUFLEN;
		}

		/* convert IPv4 address*/
		if (inet_pton(AF_INET, strip, buf) <= 0) {
			err(DEBUG_CAT_QOS, "ipv4 inet_pton got error when converting :%s\n", strip);
			return STATUS_INVALID_IP;
		}
	} else if (type == VER_IPV6) {
		if (buflen < 16) {
			err(DEBUG_CAT_QOS, "invalid buflen: %d\n", buflen);
			return STATUS_INVALID_BUFLEN;
		}

		/*convert IPv6 address*/
		if (inet_pton(AF_INET6, strip, buf) <= 0) {
			err(DEBUG_CAT_QOS, "ipv6 inet_pton got error when converting :%s\n", strip);
			return STATUS_INVALID_IP;
		}
	} else {
		err(DEBUG_CAT_QOS, "invalid type: %d\n", type);
		return STATUS_INVALID_CMD_TYPE;
	}
	return STATUS_SUCCESS;
}

unsigned char convert_direction(char *strdir)
{
	unsigned char dir = DIR_UNKNOWN;

	if (os_strncmp(strdir, "UL", os_strlen("UL")) == 0)
		dir = DIR_UPLINK;
	else if (os_strncmp(strdir, "DL", os_strlen("DL")) == 0)
		dir = DIR_DOWNLINK;
	else
		err(DEBUG_CAT_QOS, "invalid dir:%s\n", strdir);

	return dir;
}

static int get_scsid_by_index(unsigned char index)
{
	struct scs_configuration *pos = NULL;

	if (index == 0)
		return STATUS_INVALID_INDEX;

	dl_list_for_each(pos, &scs_cfg_list, struct scs_configuration, list) {
		if (pos->index == index)
			return pos->scsparam.scsid;
	}
	return STATUS_CFG_NOT_EXISTED;
}

/*
 * This function will parse mscs command.
 * Example:
 *  - MSCSReq,action,add,sta_mac,01:02:03:45:67:89,up_bitmap, 00001111,cs_mask,11111010
 */
int parse_mscs_cmd(char *buf, struct mscs_configuration *pmscs)
{
	int ret = STATUS_SUCCESS, num = 0;
	char *token = NULL, *value = NULL, *pos = NULL;

	if (!buf || !pmscs) {
		err(DEBUG_CAT_QOS, "invalid pointer, buf:%p, pmscs:%p.\n", buf, pmscs);
		return STATUS_INVALID_POINTER;
	}
	if (!os_strlen(buf)) {
		err(DEBUG_CAT_QOS, "invalid parameters, buf is empty.\n");
		return STATUS_INVALID_PARAM;
	}

	token = strtok_r(buf, ",", &pos);
	if (token == NULL || os_strncmp(token, "MSCSReq", os_strlen("MSCSReq")) != 0) {
		err(DEBUG_CAT_QOS, "invalid pmscs command.\n");
		return STATUS_INVALID_CMD_TYPE;
	}

	token = strtok_r(NULL, ",", &pos);
	while (token != NULL) {
		value = strtok_r(NULL, ",", &pos);
		if (value == NULL)
			break;

		if (os_strncmp(token, "index", os_strlen("index")) == 0) {
			num = str2num(value, 10);
			if (num > 0 && num < 0xFF)
				pmscs->index = num;
			else
				pmscs->index = 1;
		} else if (os_strncmp(token, "sta_mac", os_strlen("sta_mac")) == 0) {
			if (convert_mac_addr(value, pmscs->csparam.sta_mac) != STATUS_SUCCESS) {
				ret = STATUS_INVALID_STAMAC;
				break;
			}
		} else if (os_strncmp(token, "action", os_strlen("action")) == 0) {
			pmscs->csparam.request_type = convert_action(value);

			if (pmscs->csparam.request_type == REQUEST_TYPE_UNKNOWN) {
				ret = STATUS_INVALID_ACTION;
				break;
			}
		} else if (os_strncmp(token, "up_bitmap", os_strlen("up_bitmap")) == 0) {
			pmscs->csparam.up_bitmap = convert_strbitmap2i(value);
			if (pmscs->csparam.up_bitmap == 0) {
				ret = STATUS_INVALID_BITMAP;
				break;
			}
		} else if (os_strncmp(token, "cs_mask", os_strlen("cs_mask")) == 0) {
			pmscs->csparam.cs.header.cs_mask = convert_strbitmap2i(value);
			if (pmscs->csparam.cs.header.cs_mask == 0) {
				ret = STATUS_INVALID_BITMAP;
				break;
			}
		} else {
			err(DEBUG_CAT_QOS, "unknown parameter:%s.\n", token);
		}
		token = strtok_r(NULL, ",", &pos);
	}

	if (ret == STATUS_SUCCESS) {
		/*set default values*/
		if (pmscs->csparam.up_bitmap == 0)
			pmscs->csparam.up_bitmap = 0xF0;
		if (pmscs->csparam.cs.header.cs_mask == 0)
			pmscs->csparam.cs.header.cs_mask = 0x5F;
		if (pmscs->csparam.cs.header.cs_type == 0)
			pmscs->csparam.cs.header.cs_type = 4;
		if (pmscs->csparam.timeout == 0)
			pmscs->csparam.timeout = 60;
		if (pmscs->csparam.up_limit == 0)
			pmscs->csparam.up_limit = 7;
	}

	return ret;
}

/*
 * This function will parse scs command.
 * Example:
 *  - SCSReq,action,add,sta_mac,01:02:03:45:67:89,up,6,ipver,4,srcip,192.165.100.101,dstip,192.165.100.70,
 *    srcport,5002,dstport,10002,protocol,UDP
 *  - SCSReq,action,add,al_mac,00:0c:43:11:22:33,sta_mac,01:02:03:45:67:89,qoschar_dir,UL,qoschar_min_interval,40000,
 *    qoschar_max_interval,40000,qoschar_min_datarate,5000,qoschar_delaybound,40000,qoschar_userpriority,4
 */
int parse_scs_cmd(char *buf, struct scs_configuration *pscs)
{
	int ret = STATUS_SUCCESS;
	char *token = NULL, *value = NULL, *pos = NULL;
	int num = 0;
	struct classifier_type4 *ptyp4 = NULL;
	struct qoschar_user_setting *pqcharcfg = NULL;

	if (!buf || !pscs) {
		err(DEBUG_CAT_QOS, "invalid pointer, buf:%p, pscs:%p.\n", buf, pscs);
		return STATUS_INVALID_POINTER;
	}
	if (!os_strlen(buf)) {
		err(DEBUG_CAT_QOS, "invalid parameters, buf is empty.\n");
		return STATUS_INVALID_PARAM;
	}

	token = strtok_r(buf, ",", &pos);
	if (token == NULL || os_strncmp(token, "SCSReq", os_strlen("SCSReq")) != 0) {
		err(DEBUG_CAT_QOS, "invalid pscs command.\n");
		return STATUS_INVALID_CMD_TYPE;
	}

	ptyp4 = &pscs->scsparam.tclas_elem[0].type4;
	pqcharcfg = &pscs->qcharconfig;

	token = strtok_r(NULL, ",", &pos);
	while (token != NULL) {
		value = strtok_r(NULL, ",", &pos);
		if (value == NULL)
			break;

		if (os_strncmp(token, "index", os_strlen("index")) == 0) {
			num = str2num(value, 10);
			if (num > 0 && num < 0xFF)
				pscs->index = num;
			else
				pscs->index = 1;
		} else if (os_strncmp(token, "sta_mac", os_strlen("sta_mac")) == 0) {
			if (convert_mac_addr(value, pscs->scsparam.sta_mac) != STATUS_SUCCESS) {
				ret = STATUS_INVALID_STAMAC;
				break;
			}
		} else if (os_strncmp(token, "scsid", os_strlen("scsid")) == 0) {
			num = str2num(value, 10);
			if (num >= 0 && num < 255)
				pscs->scsparam.scsid = num;
		} else if (os_strncmp(token, "action", os_strlen("action")) == 0) {
			pscs->scsparam.request_type = convert_action(value);
			if (pscs->scsparam.request_type == REQUEST_TYPE_UNKNOWN) {
				ret = STATUS_INVALID_ACTION;
				break;
			}
		} else if (os_strncmp(token, "up", os_strlen("up")) == 0) {
			num = str2num(value, 10);

			if (num <= 0 || num > 7) {
				ret = STATUS_INVALID_UP;
				break;
			}
			pscs->scsparam.up = num;
		} else if (os_strncmp(token, "ipver", os_strlen("ipver")) == 0) {
			num = str2num(value, 10);
			if ((num < 0) || (num != VER_IPV4 && num != VER_IPV6)) {
				ret = STATUS_INVALID_VERSION;
				break;
			}
			ptyp4->version = num;
			ptyp4->cs_mask |= TYPE4_CS_MASK_VERSION;
		} else if (os_strncmp(token, "srcip", os_strlen("srcip")) == 0) {
			if (convert_ip_address(ptyp4->version, value,
				(char *)&ptyp4->srcIp, sizeof(ptyp4->srcIp)) < 0) {
				ret = STATUS_INVALID_IP;
				break;
			}
			ptyp4->cs_mask |= TYPE4_CS_MASK_SRC_IP;
		} else if (os_strncmp(token, "dstip", os_strlen("dstip")) == 0) {
			if (convert_ip_address(ptyp4->version, value,
				(char *)&ptyp4->destIp, sizeof(ptyp4->destIp)) < 0) {
				ret = STATUS_INVALID_IP;
				break;
			}
			ptyp4->cs_mask |= TYPE4_CS_MASK_DST_IP;
		} else if (os_strncmp(token, "srcport", os_strlen("srcport")) == 0) {
			num = str2num(value, 10);
			if (num < 0) {
				ret = STATUS_INVALID_PORT;
				break;
			}
			ptyp4->srcPort = num;
			ptyp4->srcPort = htons(ptyp4->srcPort);
			ptyp4->cs_mask |= TYPE4_CS_MASK_SRC_PORT;
		} else if (os_strncmp(token, "dstport", os_strlen("dstport")) == 0) {
			num = str2num(value, 10);
			if (num < 0) {
				ret = STATUS_INVALID_PORT;
				break;
			}
			ptyp4->destPort = num;
			ptyp4->destPort = htons(ptyp4->destPort);
			ptyp4->cs_mask |= TYPE4_CS_MASK_DST_PORT;
		} else if (os_strncmp(token, "protocol", os_strlen("protocol")) == 0) {
			num = str2protocol(value);
			if (num == IP_TYPE_UNKNOWN) {
				ret = STATUS_INVALID_PROTOCOL;
				break;
			}
			ptyp4->u.protocol = num;
			ptyp4->cs_mask |= TYPE4_CS_MASK_PROTOCOL;
		} else if (os_strncmp(token, "qoschar_dir", os_strlen("qoschar_dir")) == 0) {
			pqcharcfg->dir = convert_direction(value);
			pqcharcfg->qchar_mask |= QCHAR_MASK_DIR;
		} else if (os_strncmp(token, "qoschar_min_interval", os_strlen("qoschar_min_interval")) == 0) {
			num = str2num(value, 10);
			if (num < 0) {
				ret = STATUS_INVALID_QOSCHAR;
				break;
			}
			pqcharcfg->min_interval = num;
			pqcharcfg->qchar_mask |= QCHAR_MASK_MIN_INTERVAL;
		} else if (os_strncmp(token, "qoschar_max_interval", os_strlen("qoschar_max_interval")) == 0) {
			num = str2num(value, 10);
			if (num < 0) {
				ret = STATUS_INVALID_QOSCHAR;
				break;
			}
			pqcharcfg->max_interval = num;
			pqcharcfg->qchar_mask |= QCHAR_MASK_MAX_INTERVAL;
		} else if (os_strncmp(token, "qoschar_min_datarate", os_strlen("qoschar_min_datarate")) == 0) {
			num = str2num(value, 10);
			if (num < 0) {
				ret = STATUS_INVALID_QOSCHAR;
				break;
			}
			pqcharcfg->min_datarate = num;
			pqcharcfg->qchar_mask |= QCHAR_MASK_MIN_DATA_RATE;
		} else if (os_strncmp(token, "qoschar_delaybound", os_strlen("qoschar_delaybound")) == 0) {
			num = str2num(value, 10);
			if (num < 0) {
				ret = STATUS_INVALID_QOSCHAR;
				break;
			}
			pqcharcfg->delaybound = num;
			pqcharcfg->qchar_mask |= QCHAR_MASK_DELAY_BOUND;
		} else if (os_strncmp(token, "qoschar_userpriority", os_strlen("qoschar_userpriority")) == 0) {
			num = str2num(value, 10);
			if (num <= 0 || num > 7) {
				ret = STATUS_INVALID_UP;
				break;
			}
			pscs->scsparam.up = num;
		} else {
			if (os_strncmp(token, " ", 1) != 0)
				err(DEBUG_CAT_QOS, "unknown parameter:%s.\n", token);
		}
		token = strtok_r(NULL, ",", &pos);
	}

	if (ret == STATUS_SUCCESS && ptyp4->cs_mask)
		pscs->scsparam.tclas_num = 1;

	return ret;
}

static inline u8 getup_by_qosidx(u8 qosidx)
{
	u8 i = 0;

	for (i = 0; i < QOS_INDEX_MAX; i++) {
		if (qosidx_mapping_tbl[i].qosidx == QOS_INDEX_MAX)
			break;

		if (qosidx_mapping_tbl[i].qosidx == qosidx)
			return qosidx_mapping_tbl[i].up;
	}
	return UP_0;
}

/*
 * This function will parse ip tuple flow command.
 * Example:
 *  - perFlow,qosidx,1,sta_mac,01:02:03:45:67:89,ipver,4,srcip,192.165.100.101,dstip,192.165.100.70,
 *    srcport,5002,dstport,10002,protocol,UDP
 */
int parse_ip_tuple_cmd(char *buf, struct ip_tuple *tuple)
{
	int ret = STATUS_SUCCESS;
	char *token = NULL, *value = NULL, *pos = NULL;
	int num = 0;

	if (!buf || !tuple) {
		err(DEBUG_CAT_QOS, "invalid pointer, buf:%p, tuple:%p.\n", buf, tuple);
		return STATUS_INVALID_POINTER;
	}
	if (!os_strlen(buf)) {
		err(DEBUG_CAT_QOS, "invalid parameters, buf is empty.\n");
		return STATUS_INVALID_PARAM;
	}

	token = strtok_r(buf, ",", &pos);
	if (token == NULL || os_strncmp(token, "perFlow", os_strlen("perFlow")) != 0) {
		err(DEBUG_CAT_QOS, "invalid ip tuple command.\n");
		return STATUS_INVALID_CMD_TYPE;
	}

	tuple->cs_mask = 0;

	token = strtok_r(NULL, ",", &pos);
	while (token != NULL) {
		value = strtok_r(NULL, ",", &pos);
		if (value == NULL)
			break;

		if (os_strncmp(token, "qosidx", os_strlen("qosidx")) == 0) {
			num = str2num(value, 10);
			if (num >= QOS_INDEX_VOICE && num < QOS_INDEX_MAX)
				tuple->qosidx = num;
			else
				tuple->qosidx = QOS_INDEX_DOWNLOAD;

			tuple->up = getup_by_qosidx(tuple->qosidx);
			tuple->cs_mask |= CS_MASK_QOS_INDEX;
		} else if (os_strncmp(token, "sta_mac", os_strlen("sta_mac")) == 0) {
			if (convert_mac_addr(value, tuple->sta_mac) != STATUS_SUCCESS) {
				ret = STATUS_INVALID_STAMAC;
				break;
			}
			tuple->cs_mask |= CS_MASK_STA_MAC_ADDRESS;
		} else if (os_strncmp(token, "action", os_strlen("action")) == 0) {
			tuple->request_type = convert_action(value);
			if (tuple->request_type == REQUEST_TYPE_UNKNOWN) {
				ret = STATUS_INVALID_ACTION;
				break;
			}
		} else if (os_strncmp(token, "ipver", os_strlen("ipver")) == 0) {
			num = str2num(value, 10);
			if ((num < 0) || (num != VER_IPV4 && num != VER_IPV6)) {
				ret = STATUS_INVALID_VERSION;
				break;
			}
			tuple->version = num;
			tuple->cs_mask |= TYPE4_CS_MASK_VERSION;
		} else if (os_strncmp(token, "srcip", os_strlen("srcip")) == 0) {
			if (convert_ip_address(tuple->version, value,
				(char *)&tuple->srcIp, sizeof(tuple->srcIp)) < 0) {
				ret = STATUS_INVALID_IP;
				break;
			}
			tuple->cs_mask |= TYPE4_CS_MASK_SRC_IP;
		} else if (os_strncmp(token, "dstip", os_strlen("dstip")) == 0) {
			if (convert_ip_address(tuple->version, value,
				(char *)&tuple->destIp, sizeof(tuple->destIp)) < 0) {
				ret = STATUS_INVALID_IP;
				break;
			}
			tuple->cs_mask |= TYPE4_CS_MASK_DST_IP;
		} else if (os_strncmp(token, "srcport", os_strlen("srcport")) == 0) {
			num = str2num(value, 10);
			if (num < 0) {
				ret = STATUS_INVALID_PORT;
				break;
			}
			tuple->srcPort = num;
			tuple->srcPort = htons(tuple->srcPort);
			tuple->cs_mask |= TYPE4_CS_MASK_SRC_PORT;
		} else if (os_strncmp(token, "dstport", os_strlen("dstport")) == 0) {
			num = str2num(value, 10);
			if (num < 0) {
				ret = STATUS_INVALID_PORT;
				break;
			}
			tuple->destPort = num;
			tuple->destPort = htons(tuple->destPort);
			tuple->cs_mask |= TYPE4_CS_MASK_DST_PORT;
		} else if (os_strncmp(token, "protocol", os_strlen("protocol")) == 0) {
			num = str2protocol(value);
			if (num == IP_TYPE_UNKNOWN) {
				ret = STATUS_INVALID_PROTOCOL;
				break;
			}
			tuple->protocol = num;
			tuple->cs_mask |= TYPE4_CS_MASK_PROTOCOL;
		} else {
			if (os_strncmp(token, " ", 1) != 0)
				err(DEBUG_CAT_QOS, "unknown parameter:%s.\n", token);
		}
		token = strtok_r(NULL, ",", &pos);
	}

	return ret;
}

/*
 * This function will parse the command of BSS priority.
 * Example:
 *  - wappctrl ra0 set_qos_config perBSS,action,add,ssid,strssid,bssid:00:0c:43:11:22:33,up,6,qosidx,1
 */
int parse_bss_priority_cmd(char *buf, struct priority_bss *pribss)
{
	int num = 0, ret = STATUS_UNKNOWN;
	char *token = NULL, *value = NULL, *pos = NULL;

	if (!buf || !pribss) {
		err(DEBUG_CAT_QOS, "invalid pointer, buf:%p, pribss:%p\n", buf, pribss);
		return STATUS_INVALID_POINTER;
	}
	if (!os_strlen(buf)) {
		err(DEBUG_CAT_QOS, "invalid parameters, buf is empty.\n");
		return STATUS_INVALID_PARAM;
	}

	token = strtok_r(buf, ",", &pos);
	if (token == NULL || os_strncmp(token, "perBSS", os_strlen("perBSS")) != 0) {
		err(DEBUG_CAT_QOS, "invalid command:%s\n", buf);
		return STATUS_INVALID_CMD_TYPE;
	}

	token = strtok_r(NULL, ",", &pos);
	while (token != NULL) {
		value = strtok_r(NULL, ",", &pos);
		if (value == NULL || !strlen(value)) {
			err(DEBUG_CAT_QOS, "invalid value for %s\n", token);
			ret = STATUS_INVALID_PARAM;
			break;
		}

		if (os_strncmp(token, "action", os_strlen("action")) == 0) {
			pribss->request_type = convert_action(value);
			if (pribss->request_type == REQUEST_TYPE_UNKNOWN) {
				ret = STATUS_INVALID_ACTION;
				break;
			}
		} else if (os_strncmp(token, "ssid", os_strlen("ssid")) == 0) {
			if (strlen(value) > MAX_LEN_OF_SSID) {
				err(DEBUG_CAT_QOS, "the length of ssid(%s) exceed %d.\n", value, MAX_LEN_OF_SSID);
				ret = STATUS_INVALID_SSID_OR_BSSID;
				break;
			}
			os_memcpy(pribss->ssid, value, MIN(strlen(value), MAX_LEN_OF_SSID));
		} else if (os_strncmp(token, "bssid", os_strlen("bssid")) == 0) {
			if (convert_mac_addr(value, pribss->bssid) != STATUS_SUCCESS) {
				ret = STATUS_INVALID_STAMAC;
				break;
			}
		} else if (os_strncmp(token, "qosidx", os_strlen("qosidx")) == 0) {
			num = str2num(value, 10);
			if (num >= QOS_INDEX_VOICE && num < QOS_INDEX_MAX)
				pribss->qosidx = num;
			else
				pribss->qosidx = QOS_INDEX_DOWNLOAD;

			pribss->up = getup_by_qosidx(pribss->qosidx);
		} else if (os_strncmp(token, "up", os_strlen("up")) == 0) {
			num = str2num(value, 10);
			if (num < 0 || num > 7) {
				err(DEBUG_CAT_QOS, "invalid up value: %s.\n", value);
				ret = STATUS_INVALID_UP;
				break;
			}
			pribss->up = num;
		} else {
			if (os_strncmp(token, " ", 1) != 0)
				err(DEBUG_CAT_QOS, "unknown parameter:%s.\n", token);
		}
		token = strtok_r(NULL, ",", &pos);
	}
	return ret;
}

/*
 * will do sanity check on priority bss request configuration.
 */
int bss_priority_sanity_check(struct wifi_app *wapp, struct priority_bss *pribss)
{
	int ret = STATUS_INVALID_SSID_OR_BSSID;

	if (!wapp || !pribss)
		ret = STATUS_INVALID_POINTER;
	else if ((strlen(pribss->ssid) == 0 || strlen(pribss->ssid) > MAX_LEN_OF_SSID) &&
		MAC_ADDR_EQUAL(pribss->bssid, zero_mac))
		ret = STATUS_INVALID_SSID_OR_BSSID;
	else if (pribss->request_type >= REQUEST_TYPE_UNKNOWN)
		ret = STATUS_INVALID_ACTION;
	else
		ret = STATUS_SUCCESS;

	return ret;
}

int update_bss_priority_list(struct priority_bss *pribss)
{
	struct priority_bss_db *pos = NULL, *tmp = NULL;

	if (!pribss) {
		err(DEBUG_CAT_QOS, "update priority bss error, pribss is NULL.\n");
		return STATUS_INVALID_POINTER;
	}

	if (pribss->request_type >= REQUEST_TYPE_UNKNOWN) {
		err(DEBUG_CAT_QOS, "unknown request type: %u\n", pribss->request_type);
		return STATUS_INVALID_ACTION;
	}

	dl_list_for_each_safe(pos, tmp, &pribss_list, struct priority_bss_db, list) {
		if (str_equal(pos->node.ifname, pribss->ifname)) {
			if (pribss->request_type == REQUEST_TYPE_ADD) {
				err(DEBUG_CAT_QOS, "priority bss is existed, ifname:%s, up:%u\n", pos->node.ifname, pos->node.up);
				return STATUS_CFG_EXISTED;
			} else if (pribss->request_type == REQUEST_TYPE_CHANGE) {
				if (pos->node.up == pribss->up)
					return STATUS_CFG_IS_THE_SAME;

				pos->node.up = pribss->up;
				return STATUS_SUCCESS;
			} else if (pribss->request_type == REQUEST_TYPE_REMOVE) {
				dl_list_del(&pos->list);
				os_free(pos);

				if (pribss_list_cnt)
					pribss_list_cnt--;
				return STATUS_SUCCESS;
			}
		}
	}

	if (pribss->request_type == REQUEST_TYPE_CHANGE) {
		err(DEBUG_CAT_QOS, "bss config is not existed, failed to change it.\n");
		return STATUS_INVALID_ACTION;
	} else if (pribss->request_type == REQUEST_TYPE_REMOVE) {
		err(DEBUG_CAT_QOS, "bss config is not existed, failed to remove it.\n");
		return STATUS_INVALID_ACTION;
	}

	if (pribss_list_cnt >= 0xFF)
		return STATUS_INSUFFICIENT_RESOURCE;

	tmp = (struct priority_bss_db *)os_zalloc(sizeof(struct priority_bss_db));
	if (!tmp) {
		err(DEBUG_CAT_QOS, "Memory Alloc Fail.\n");
		return STATUS_ALLOC_MEM_FAIL;
	}

	os_memcpy(&tmp->node, pribss, sizeof(*pribss));
	/*add setting*/
	dl_list_add_tail(&pribss_list, &tmp->list);
	pribss_list_cnt++;

	return STATUS_SUCCESS;
}

void clean_bss_priority_list(void)
{
	struct priority_bss_db *pos, *pos_tmp;

	dl_list_for_each_safe(pos, pos_tmp, &pribss_list, struct priority_bss_db, list) {
		dl_list_del(&pos->list);
		os_free(pos);
	}
	pribss_list_cnt = 0;
}

/*
 * This function will parse the command of BSS priority.
 * Example:
 *  - wappctrl ra0 set_qos_config perSTA,action,add,sta_mac,01:02:03:45:67:89,up,6,qosidx,1
 */
int parse_sta_priority_cmd(char *buf, struct priority_sta *prista)
{
	int num = 0, ret = STATUS_UNKNOWN;
	char *token = NULL, *value = NULL, *pos = NULL;

	if (!buf || !prista) {
		err(DEBUG_CAT_QOS, "invalid pointer, buf:%p, prista:%p\n", buf, prista);
		return STATUS_INVALID_POINTER;
	}
	if (!os_strlen(buf)) {
		err(DEBUG_CAT_QOS, "invalid parameters, buf is empty.\n");
		return STATUS_INVALID_PARAM;
	}

	token = strtok_r(buf, ",", &pos);
	if (token == NULL || os_strncmp(token, "perSTA", os_strlen("perSTA")) != 0) {
		err(DEBUG_CAT_QOS, "invalid command:%s\n", buf);
		return STATUS_INVALID_CMD_TYPE;
	}

	token = strtok_r(NULL, ",", &pos);
	while (token != NULL) {
		value = strtok_r(NULL, ",", &pos);
		if (value == NULL || !strlen(value)) {
			err(DEBUG_CAT_QOS, "invalid value for %s\n", token);
			ret = STATUS_INVALID_PARAM;
			break;
		}

		if (os_strncmp(token, "action", os_strlen("action")) == 0) {
			prista->request_type = convert_action(value);
			if (prista->request_type == REQUEST_TYPE_UNKNOWN) {
				ret = STATUS_INVALID_ACTION;
				break;
			}
		} else if (os_strncmp(token, "sta_mac", os_strlen("sta_mac")) == 0) {
			if (convert_mac_addr(value, prista->sta_mac) != STATUS_SUCCESS) {
				ret = STATUS_INVALID_STAMAC;
				break;
			}
		} else if (os_strncmp(token, "qosidx", os_strlen("qosidx")) == 0) {
			num = str2num(value, 10);
			if (num >= QOS_INDEX_VOICE && num < QOS_INDEX_MAX)
				prista->qosidx = num;
			else
				prista->qosidx = QOS_INDEX_DOWNLOAD;

			prista->up = getup_by_qosidx(prista->qosidx);
		} else if (os_strncmp(token, "up", os_strlen("up")) == 0) {
			num = str2num(value, 10);
			if (num < 0 || num > 7) {
				err(DEBUG_CAT_QOS, "invalid up value: %s.\n", value);
				ret = STATUS_INVALID_UP;
				break;
			}
			prista->up = num;
		} else {
			if (os_strncmp(token, " ", 1) != 0)
				err(DEBUG_CAT_QOS, "unknown parameter:%s.\n", token);
		}
		token = strtok_r(NULL, ",", &pos);
	}
	return ret;
}

/*
 * will do sanity check on priority bss request configuration.
 */
int client_priority_sanity_check(struct wifi_app *wapp, struct priority_sta *prista)
{
	if (!wapp || !prista)
		return STATUS_INVALID_POINTER;
	if (MAC_ADDR_EQUAL(prista->sta_mac, zero_mac))
		return STATUS_INVALID_STAMAC;
	if (prista->up >= UP_MAX)
		return STATUS_INVALID_UP;
	if (prista->request_type >= REQUEST_TYPE_UNKNOWN)
		return STATUS_INVALID_ACTION;

	return STATUS_SUCCESS;
}

int update_sta_priority_list(struct priority_sta *prista)
{
	struct priority_sta_db *pos = NULL, *tmp = NULL;

	if (!prista) {
		err(DEBUG_CAT_QOS, "update priority sta error, client is NULL.\n");
		return STATUS_INVALID_POINTER;
	}

	if (prista->request_type >= REQUEST_TYPE_UNKNOWN) {
		err(DEBUG_CAT_QOS, "unknown request type: %u\n", prista->request_type);
		return STATUS_INVALID_ACTION;
	}

	dl_list_for_each_safe(pos, tmp, &prista_list, struct priority_sta_db, list) {
		if (MAC_ADDR_EQUAL(pos->node.sta_mac, prista->sta_mac)) {
			if (prista->request_type == REQUEST_TYPE_ADD) {
				err(DEBUG_CAT_QOS, "priority sta is existed, sta_mac:"MACSTR", up:%u\n",
					MAC2STR(pos->node.sta_mac), pos->node.up);
				return STATUS_CFG_EXISTED;
			} else if (prista->request_type == REQUEST_TYPE_CHANGE) {
				if (pos->node.up == prista->up)
					return STATUS_CFG_IS_THE_SAME;

				pos->node.up = prista->up;
				return STATUS_SUCCESS;
			} else if (prista->request_type == REQUEST_TYPE_REMOVE) {
				dl_list_del(&pos->list);
				os_free(pos);

				if (prista_list_cnt)
					prista_list_cnt--;
				return STATUS_SUCCESS;
			}
		}
	}

	if (prista->request_type == REQUEST_TYPE_CHANGE) {
		err(DEBUG_CAT_QOS, "priority sta config is not existed, failed to change it.\n");
		return STATUS_INVALID_ACTION;
	} else if (prista->request_type == REQUEST_TYPE_REMOVE) {
		err(DEBUG_CAT_QOS, "priority sta config is not existed, failed to remove it.\n");
		return STATUS_INVALID_ACTION;
	}

	if (prista_list_cnt >= 0xFF)
		return STATUS_INSUFFICIENT_RESOURCE;

	tmp = (struct priority_sta_db *)os_zalloc(sizeof(struct priority_sta_db));
	if (!tmp) {
		err(DEBUG_CAT_QOS, "Memory Alloc Fail.\n");
		return STATUS_ALLOC_MEM_FAIL;
	}

	os_memcpy(&tmp->node, prista, sizeof(*prista));
	/*add setting*/
	dl_list_add_tail(&prista_list, &tmp->list);
	prista_list_cnt++;

	return STATUS_SUCCESS;
}

void clean_sta_priority_list(void)
{
	struct priority_sta_db *pos, *pos_tmp;

	dl_list_for_each_safe(pos, pos_tmp, &prista_list, struct priority_sta_db, list) {
		dl_list_del(&pos->list);
		os_free(pos);
	}
	prista_list_cnt = 0;
}

/*
 * This function will parse qosmap command.
 * Example:
 *  - Qosmap,dscp_exception,53,3,54,2,dsccp_range,8,15,0,7,255,255,16,31,32,39,255,255,40,47,255,255
 */
int parse_qosmap_cmd(char *buf, struct qos_map *pqosmap)
{
	int ret = STATUS_INSUFFICIENT_PARAM;
	unsigned char i = 0;
	char *token = NULL, *value = NULL, *pos = NULL;
	int num = 0, dscp = 0, dscp_l = 0, dscp_h = 0, up = 0;

	if (!buf || !pqosmap) {
		err(DEBUG_CAT_QOS, "invalid pointer, buf:%p, pqosmap:%p.\n", buf, pqosmap);
		return STATUS_INVALID_POINTER;
	}
	if (!os_strlen(buf)) {
		err(DEBUG_CAT_QOS, "invalid parameters, buf is empty.\n");
		return STATUS_INVALID_PARAM;
	}

	token = strtok_r(buf, ",", &pos);
	if (token == NULL || os_strncmp(token, "Qosmap", os_strlen("Qosmap")) != 0) {
		err(DEBUG_CAT_QOS, "invalid pqosmap command.\n");
		return STATUS_INVALID_CMD_TYPE;
	}

	token = strtok_r(NULL, ",", &pos);
	while (token != NULL) {
		value = strtok_r(NULL, ",", &pos);
		if (value == NULL)
			break;

		if (os_strncmp(token, "sta_mac", os_strlen("sta_mac")) == 0) {
			if (convert_mac_addr(value, pqosmap->sta_mac) != STATUS_SUCCESS) {
				ret = STATUS_INVALID_STAMAC;
				break;
			}
		} else if (os_strncmp(token, "dscp_exception", os_strlen("dscp_exception")) == 0) {
			pqosmap->num = 0;
			while (value != NULL && pqosmap->num < MAX_EXCEPT_CNT) {
				num = str2num(value, 10);
				if (num < 0)
					break;
				dscp = num;

				value = strtok_r(NULL, ",", &pos);
				if (value == NULL)
					break;

				num = str2num(value, 10);
				if (num < 0)
					break;
				up = num;

				if (dscp < DSCP_TBL_SIZE && up < UP_MAX) {
					pqosmap->dscp_ex[pqosmap->num].dscp = dscp;
					pqosmap->dscp_ex[pqosmap->num].up = up;
					pqosmap->num++;
					ret = STATUS_SUCCESS;
				}
				value = strtok_r(NULL, ",", &pos);
			}
			token = value;
			continue;
		} else if (os_strncmp(token, "dscp_range", os_strlen("dscp_range")) == 0) {
			i = 0;
			while (value != NULL && i < UP_MAX) {
				num = str2num(value, 10);
				if (num < 0)
					break;
				dscp_l = num;

				value = strtok_r(NULL, ",", &pos);
				if (value == NULL)
					break;

				num = str2num(value, 10);
				if (num < 0)
					break;
				dscp_h = num;

				if ((dscp_l < DSCP_TBL_SIZE && dscp_h < DSCP_TBL_SIZE && dscp_l < dscp_h) ||
					(dscp_l == 255 && dscp_h == 255)) {
					pqosmap->dscp_rg[i].low = dscp_l;
					pqosmap->dscp_rg[i].high = dscp_h;
					i++;
					ret = STATUS_SUCCESS;
				}
				value = strtok_r(NULL, ",", &pos);
			}
			token = value;
			continue;
		} else {
			err(DEBUG_CAT_QOS, "unknown parameter:%s.\n", token);
		}
		token = strtok_r(NULL, ",", &pos);
	}
	return ret;
}

/*
 * This function will parse the command of configuring max MSCS/SCS sta count.
 * Example:
 *  - wappctrl ra0 set_qos_config maxstacnt,MSCS,16
 *  - wappctrl ra0 set_qos_config maxstacnt,SCS,16
 */
int parse_maxstacnt_cmd(char *buf)
{
	int num = 0, ret = STATUS_UNKNOWN;
	char *token = NULL, *value = NULL, *pos = NULL;

	if (!buf) {
		err(DEBUG_CAT_QOS, "invalid pointer, buf:%p\n", buf);
		return STATUS_INVALID_POINTER;
	}
	if (!os_strlen(buf)) {
		err(DEBUG_CAT_QOS, "invalid parameters, buf is empty.\n");
		return STATUS_INVALID_PARAM;
	}

	token = strtok_r(buf, ",", &pos);
	if (token == NULL || os_strncmp(token, "maxstacnt", os_strlen("maxstacnt")) != 0) {
		err(DEBUG_CAT_QOS, "invalid command.\n");
		return STATUS_INVALID_CMD_TYPE;
	}

	token = strtok_r(NULL, ",", &pos);
	while (token != NULL) {
		value = strtok_r(NULL, ",", &pos);
		if (value == NULL)
			break;

		if (os_strncmp(token, "MSCS", os_strlen("MSCS")) == 0) {
			num = str2num(value, 10);
			if (num < 0 || num > 0xFF) {
				ret = STATUS_INVALID_PARAM;
				break;
			}
			max_mscs_cfg_count = num;
		} else if (os_strncmp(token, "SCS", os_strlen("SCS")) == 0) {
			num = str2num(value, 10);
			if (num < 0 || num > 0xFF) {
				ret = STATUS_INVALID_PARAM;
				break;
			}
			max_scs_cfg_count = num;
		} else {
			if (os_strncmp(token, " ", 1) != 0)
				err(DEBUG_CAT_QOS, "unknown parameter:%s.\n", token);
		}
		token = strtok_r(NULL, ",", &pos);
	}
	return ret;
}

/*
 * will do sanity check on mscs structure and fill default for some of fields.
 */
int mscs_sanity_check(struct mscs_configuration *pmscs)
{
	int ret = STATUS_UNKNOWN;

	if (!pmscs)
		ret = STATUS_INVALID_POINTER;
	else if (MAC_ADDR_EQUAL(pmscs->csparam.sta_mac, zero_mac))
		ret = STATUS_INVALID_STAMAC;
	else if (pmscs->csparam.request_type >= REQUEST_TYPE_UNKNOWN)
		ret = STATUS_INVALID_ACTION;
	else
		ret = STATUS_SUCCESS;

	return ret;
}

unsigned char allocate_scsid(struct scs_configuration *pscs)
{
	unsigned char i = 0, used = 0;
	struct scs_configuration *pos = NULL;

	if (scs_active_sta_cnt == 0)
		return 0;

	if (pscs->scsparam.request_type == REQUEST_TYPE_ADD) {
		for (i = 0; i < scs_active_sta_cnt; i++) {
			used = 0;
			dl_list_for_each(pos, &scs_cfg_list, struct scs_configuration, list) {
				if (MAC_ADDR_EQUAL(pos->scsparam.sta_mac, pscs->scsparam.sta_mac) &&
					(pos->scsparam.scsid == i)) {
					used = 1;
					break;
				}
			}
			if (used == 0)
				break;
		}
		return i;
	}
	dl_list_for_each(pos, &scs_cfg_list, struct scs_configuration, list) {
		if (MAC_ADDR_EQUAL(pos->scsparam.sta_mac, pscs->scsparam.sta_mac))
			return pos->scsparam.scsid;
	}
	return 0;
}

int scs_sanity_check(struct scs_configuration *pscs)
{
	int ret = STATUS_UNKNOWN;
	struct classifier_type4 *ptyp4 = NULL;
	struct qoschar_user_setting *pqcharcfg = NULL;

	if (pscs) {
		ptyp4 = &pscs->scsparam.tclas_elem[0].type4;
		pqcharcfg = &pscs->qcharconfig;
	}

	if (!pscs)
		ret = STATUS_INVALID_POINTER;
	else if (MAC_ADDR_EQUAL(pscs->scsparam.sta_mac, zero_mac))
		ret = STATUS_INVALID_STAMAC;
	else if (pscs->scsparam.request_type >= REQUEST_TYPE_UNKNOWN)
		ret = STATUS_INVALID_ACTION;
	else if (pscs->scsparam.up >= UP_MAX)
		ret = STATUS_INVALID_UP;
	else if (pscs->scsparam.request_type == REQUEST_TYPE_REMOVE) {
		ret = get_scsid_by_index(pscs->index);
		if (ret >= 0 && ret < 0xFF) {
			pscs->scsparam.scsid = ret;
			ret = STATUS_SUCCESS;
		}
	} else if (ptyp4->cs_mask == 0 && pqcharcfg->qchar_mask == 0)
		ret = STATUS_INSUFFICIENT_PARAM;
	else if ((ptyp4->cs_mask & TYPE4_CS_MASK_VERSION) && (ptyp4->version != VER_IPV4 && ptyp4->version != VER_IPV6))
		ret = STATUS_INVALID_VERSION;
	else if (((ptyp4->cs_mask & TYPE4_CS_MASK_SRC_IP) && (ptyp4->version == VER_IPV4 && ptyp4->srcIp.ipv4 == 0)) ||
		((ptyp4->cs_mask & TYPE4_CS_MASK_DST_IP) && (ptyp4->version == VER_IPV4 && ptyp4->destIp.ipv4 == 0)))
		ret = STATUS_INVALID_IP;
	else if (((ptyp4->cs_mask & TYPE4_CS_MASK_SRC_PORT) && (ptyp4->srcPort == 0)) ||
		((ptyp4->cs_mask & TYPE4_CS_MASK_DST_PORT) && (ptyp4->destPort == 0)))
		ret = STATUS_INVALID_PORT;
	else if ((ptyp4->cs_mask & TYPE4_CS_MASK_PROTOCOL) && (ptyp4->u.protocol == 0))
		ret = STATUS_INVALID_PROTOCOL;
	else if ((pqcharcfg->qchar_mask & QCHAR_MASK_DIR) &&
		pqcharcfg->dir != DIR_UPLINK && pqcharcfg->dir != DIR_DOWNLINK)
		ret = STATUS_INVALID_DIR;
	else if (((pqcharcfg->qchar_mask & QCHAR_MASK_MIN_INTERVAL) && (pqcharcfg->min_interval == 0)) ||
		((pqcharcfg->qchar_mask & QCHAR_MASK_MAX_INTERVAL) && (pqcharcfg->max_interval == 0)) ||
		((pqcharcfg->qchar_mask & QCHAR_MASK_MIN_DATA_RATE) && (pqcharcfg->min_datarate == 0)) ||
		((pqcharcfg->qchar_mask & QCHAR_MASK_DELAY_BOUND) && (pqcharcfg->delaybound == 0)))
		ret = STATUS_INVALID_QOSCHAR;
	else
		ret = STATUS_SUCCESS;

	if (ret == STATUS_SUCCESS && ptyp4->cs_mask)
		ptyp4->cs_type = CLASSIFIER_TYPE4;

	if (pscs && pscs->scsparam.scsid == 0)
		pscs->scsparam.scsid = allocate_scsid(pscs);

	return ret;
}

int ip_tuple_sanity_check(struct ip_tuple *ptuple)
{
	if (!ptuple)
		return STATUS_INVALID_POINTER;

	if (ptuple->cs_mask == 0)
		return STATUS_INSUFFICIENT_PARAM;

	if ((ptuple->cs_mask & CS_MASK_STA_MAC_ADDRESS) && MAC_ADDR_EQUAL(ptuple->sta_mac, zero_mac))
		warn(DEBUG_CAT_QOS, "sta mac address was not designated.\n");

	if ((ptuple->cs_mask & CS_MASK_QOS_INDEX) && ptuple->qosidx >= QOS_INDEX_MAX)
		return STATUS_INVALID_QOS_INDEX;

	if ((ptuple->cs_mask & CS_MASK_QOS_UP) && ptuple->up >= UP_MAX)
		return STATUS_INVALID_UP;

	if ((ptuple->cs_mask & TYPE4_CS_MASK_SRC_IP) == 0 &&
		(ptuple->cs_mask & TYPE4_CS_MASK_DST_IP) == 0 &&
		(ptuple->cs_mask & TYPE4_CS_MASK_SRC_PORT) == 0 &&
		(ptuple->cs_mask & TYPE4_CS_MASK_DST_PORT) == 0 &&
		(ptuple->cs_mask & TYPE4_CS_MASK_PROTOCOL) == 0) {
		err(DEBUG_CAT_QOS, "ptuple->cs_mask:0x%04x.\n", ptuple->cs_mask);
		return STATUS_INVALID_IP_TUPLE;
	}

	if ((ptuple->cs_mask & TYPE4_CS_MASK_VERSION) && (ptuple->version != VER_IPV4 && ptuple->version != VER_IPV6))
		return STATUS_INVALID_VERSION;

	if (((ptuple->cs_mask & TYPE4_CS_MASK_SRC_IP) && (ptuple->version == VER_IPV4 && ptuple->srcIp.ipv4 == 0)) ||
		((ptuple->cs_mask & TYPE4_CS_MASK_DST_IP) && (ptuple->version == VER_IPV4 && ptuple->destIp.ipv4 == 0)))
		return STATUS_INVALID_IP;

	if (((ptuple->cs_mask & TYPE4_CS_MASK_SRC_PORT) && (ptuple->srcPort == 0)) ||
		((ptuple->cs_mask & TYPE4_CS_MASK_DST_PORT) && (ptuple->destPort == 0)))
		return STATUS_INVALID_PORT;

	if ((ptuple->cs_mask & TYPE4_CS_MASK_PROTOCOL) && (ptuple->protocol == 0))
		return STATUS_INVALID_PROTOCOL;

	return STATUS_SUCCESS;
}

static inline int compare_ip_tuple(struct ip_tuple *tuple1, struct ip_tuple *tuple2)
{
	u16 mask;

	if (!tuple1 || !tuple2)
		return -1;

	if (tuple1->cs_mask != tuple2->cs_mask)
		return 0;

	mask = tuple1->cs_mask;
	if ((mask & TYPE4_CS_MASK_VERSION) && (tuple1->version != tuple2->version))
		return 0;

	if (tuple1->version == VER_IPV4) {
		if ((mask & TYPE4_CS_MASK_SRC_IP) && (tuple1->srcIp.ipv4 != tuple2->srcIp.ipv4))
			return 0;

		if ((mask & TYPE4_CS_MASK_DST_IP) && (tuple1->destIp.ipv4 != tuple2->destIp.ipv4))
			return 0;
	}

	if (tuple1->version == VER_IPV6) {
		if ((mask & TYPE4_CS_MASK_SRC_IP) && (!IPV6_ADDR_EQUAL(tuple1->srcIp.ipv6, tuple2->srcIp.ipv6)))
			return 0;

		if ((mask & TYPE4_CS_MASK_DST_IP) && (!IPV6_ADDR_EQUAL(tuple1->destIp.ipv6, tuple2->destIp.ipv6)))
			return 0;
	}

	if ((mask & TYPE4_CS_MASK_PROTOCOL) && (tuple1->protocol != tuple2->protocol))
		return 0;

	if ((mask & TYPE4_CS_MASK_SRC_PORT) && (tuple1->srcPort != tuple2->srcPort))
		return 0;

	if ((mask & TYPE4_CS_MASK_DST_PORT) && (tuple1->destPort != tuple2->destPort))
		return 0;

	/*all parameters are matched*/
	return 1;
}

int update_ip_tuple_to_list(struct wifi_app *wapp, struct ip_tuple *ptuple)
{
	u8 existed = 0;
	int ret = STATUS_SUCCESS;
	struct ip_tuple_db *pos = NULL, *pos_tmp = NULL;

	if (!wapp || !ptuple)
		return STATUS_INVALID_POINTER;

	dl_list_for_each_safe(pos, pos_tmp, &perflow_tuple_list, struct ip_tuple_db, list) {
		if (compare_ip_tuple(&pos->node, ptuple) == 1) {
			existed = 1;
			if (ptuple->request_type == REQUEST_TYPE_ADD) {
				ret = STATUS_CFG_EXISTED;
				warn(DEBUG_CAT_QOS, "ip tuple already existed.\n");
			} else if (ptuple->request_type == REQUEST_TYPE_REMOVE) {
				/*remove setting*/
				dl_list_del(&pos->list);
				os_free(pos);
				if (perflow_tuple_cnt)
					perflow_tuple_cnt--;
				ret = STATUS_SUCCESS;
			} else {
				ret = STATUS_INVALID_ACTION;
				err(DEBUG_CAT_QOS, "unsupported ip tuple request type: %u\n", ptuple->request_type);
			}
			break;
		}
	}

	if (!existed) {
		if (ptuple->request_type == REQUEST_TYPE_ADD) {
			pos = (struct ip_tuple_db *)os_zalloc(sizeof(struct ip_tuple_db));
			if (pos) {
				memcpy(&pos->node, ptuple, sizeof(*ptuple));
				/*add setting*/
				dl_list_add_tail(&perflow_tuple_list, &pos->list);
				perflow_tuple_cnt++;
				ret = STATUS_SUCCESS;
			} else {
				err(DEBUG_CAT_QOS, "Memory Alloc Fail.\n");
				ret = STATUS_ALLOC_MEM_FAIL;
			}
		} else {
			ret = STATUS_INVALID_ACTION;
			warn(DEBUG_CAT_QOS, "unknown ip tuple request type: %u\n", ptuple->request_type);
		}
	}

	return ret;
}

int apply_ip_tuple_to_ap(struct wifi_app *wapp, const char *ifname, struct ip_tuple *ptuple)
{
	int ret;

	if (!wapp || !ptuple) {
		err(DEBUG_CAT_QOS, "invalid pointer, wapp:%p, ptuple:%p\n", wapp, ptuple);
		return STATUS_INVALID_POINTER;
	}

	/* update ip tuple to list*/
	ret = update_ip_tuple_to_list(wapp, ptuple);
	if (ret != STATUS_SUCCESS) {
		err(DEBUG_CAT_QOS, "update ip tuple to list failed, %s\n", err2str(ret));
		return ret;
	}

	/* send ip tuple to mtqos*/
	ret = wapp_drv_send_event(NL_SET_IP_TUPLE, (unsigned char *)ptuple, sizeof(*ptuple));
	if (ret < 0) {
		err(DEBUG_CAT_QOS, "send ip tuple to mtqos failed, ret=%d.\n", ret);
		ret = STATUS_NL_CMD_FAIL;
	}

	return ret;
}

int apply_bss_priority_to_ap(struct wifi_app *wapp, const char *ifname, struct priority_bss *pribss)
{
	u8 cpylen = 0;
	int ret = STATUS_SUCCESS;
	struct wapp_dev *wdev = NULL;
	struct ap_dev *apdev = NULL;
	struct dl_list *dev_list = NULL;

	if (!wapp || !pribss) {
		err(DEBUG_CAT_QOS, "invalid pointer, wapp:%p, pribss:%p\n", wapp, pribss);
		return STATUS_INVALID_POINTER;
	}

	dev_list = &wapp->dev_list;
	dl_list_for_each(wdev, dev_list, struct wapp_dev, list) {
		apdev = (struct ap_dev *)wdev->p_dev;
		if (wdev->dev_type != WAPP_DEV_TYPE_AP || !apdev)
			continue;

		if (!MAC_ADDR_EQUAL(pribss->bssid, zero_mac) && MAC_ADDR_EQUAL(pribss->bssid, apdev->bss_info.bssid)) {
			cpylen = MIN(strlen(wdev->ifname), sizeof(pribss->ifname)-1);
			os_strncpy(pribss->ifname, wdev->ifname, cpylen);
			pribss->ifname[cpylen] = '\0';

			if (apdev->bss_info.SsidLen) {
				cpylen = MIN(apdev->bss_info.SsidLen, MAX_LEN_OF_SSID);
				os_strncpy(pribss->ssid, apdev->bss_info.ssid, cpylen);
				pribss->ssid[cpylen] = '\0';
			}

			/* update priority bss to list */
			ret = update_bss_priority_list(pribss);
			if (ret != STATUS_SUCCESS) {
				err(DEBUG_CAT_QOS, "update priority bss list failed, %s\n", err2str(ret));
				return ret;
			}

			/* send priority bss to mtqos*/
			ret = wapp_drv_send_event(NL_SET_BSS_PRIORITY, (unsigned char *)pribss, sizeof(*pribss));
			if (ret < 0) {
				err(DEBUG_CAT_QOS, "send priority bss to mtqos failed, ret=%d.\n", ret);
				ret = STATUS_NL_CMD_FAIL;
			}

			break;
		} else if (os_strncmp(pribss->ssid, apdev->bss_info.ssid, apdev->bss_info.SsidLen) == 0) {
			cpylen = MIN(strlen(wdev->ifname), sizeof(pribss->ifname)-1);
			os_strncpy(pribss->ifname, wdev->ifname, cpylen);
			pribss->ifname[cpylen] = '\0';

			/* update priority bss to list */
			ret = update_bss_priority_list(pribss);
			if (ret != STATUS_SUCCESS) {
				err(DEBUG_CAT_QOS, "update priority bss list failed, %s\n", err2str(ret));
				return ret;
			}

			/* send priority bss to mtqos*/
			ret = wapp_drv_send_event(NL_SET_BSS_PRIORITY, (unsigned char *)pribss, sizeof(*pribss));
			if (ret < 0) {
				err(DEBUG_CAT_QOS, "send priority bss to mtqos failed, ret=%d.\n", ret);
				ret = STATUS_NL_CMD_FAIL;
			}
		}
	}

	return ret;
}

int apply_client_priority_to_ap(struct wifi_app *wapp, const char *ifname, struct priority_sta *prista)
{
	int ret;

	if (!wapp || !prista) {
		err(DEBUG_CAT_QOS, "invalid pointer, wapp:%p, prista:%p\n", wapp, prista);
		return STATUS_INVALID_POINTER;
	}

	ret = update_sta_priority_list(prista);
	if (ret != STATUS_SUCCESS) {
		err(DEBUG_CAT_QOS, "update priority sta list failed, %s\n", err2str(ret));
		return ret;
	}

	/* send priority bss to mtqos*/
	ret = wapp_drv_send_event(NL_SET_CLIENT_PRIORITY, (unsigned char *)prista, sizeof(*prista));
	if (ret < 0) {
		err(DEBUG_CAT_QOS, "send priority sta to mtqos failed, ret=%d.\n", ret);
		ret = STATUS_NL_CMD_FAIL;
	}

	return ret;
}

int qosmap_sanity_check(struct qos_map *pqosmap)
{
	unsigned char i = 0;
	int ret = STATUS_UNKNOWN, flag = 0;

	if (!pqosmap)
		ret = STATUS_INVALID_POINTER;
	else {
		ret = STATUS_SUCCESS;
		for (i = 0; i < pqosmap->num; i++) {
			if ((pqosmap->dscp_ex[i].dscp == 0 && pqosmap->dscp_ex[i].up == 0) ||
				(pqosmap->dscp_ex[i].dscp >= DSCP_TBL_SIZE) ||
				(pqosmap->dscp_ex[i].up >= UP_MAX)) {
				ret = STATUS_INVALID_DSCP_EXCEPTION;
				break;
			}
			flag = 1;
		}

		for (i = 0; i < UP_MAX; i++) {
			if (((pqosmap->dscp_rg[i].low != 255) && (pqosmap->dscp_rg[i].low >= DSCP_TBL_SIZE)) ||
				((pqosmap->dscp_rg[i].high != 255) && (pqosmap->dscp_rg[i].high >= DSCP_TBL_SIZE)) ||
				(pqosmap->dscp_rg[i].low > pqosmap->dscp_rg[i].high)) {
				ret = STATUS_INVALID_DSCP_RANGE;
				break;
			}
			flag = 1;
		}

		if (flag == 0)
			ret = STATUS_INSUFFICIENT_PARAM;
	}

	return ret;
}

int apply_mscs_to_ap(struct wifi_app *wapp, struct mscs_configuration *pmscs)
{
	u8 stat_code;

	stat_code = update_mscs_configuration(wapp, &pmscs->csparam);
	if (stat_code != STA_SUCCESS && stat_code != STA_TERMINATED) {
		err(DEBUG_CAT_QOS, "update mscs to list failed, %s\n", err2str(stat_code));
		return stat_code;
	}
	wapp_drv_send_event(NL_SET_MSCS_CONFIG, (unsigned char *)&pmscs->csparam, sizeof(pmscs->csparam));

	return STATUS_SUCCESS;
}

int send_qosmap_to_peer_sta(struct wifi_app *wapp, const char *ifname, struct qos_map *qosmap)
{
	int ret = STATUS_SUCCESS;
	struct associated_sta_info_db *pos = NULL;

	if (!wapp || !qosmap) {
		err(DEBUG_CAT_QOS, "invalid pointer, wapp:%p, qosmap:%p\n", wapp, qosmap);
		return STATUS_INVALID_POINTER;
	}

	info(DEBUG_CAT_QOS, "qosmap sta mac "MACSTR"\n", MAC2STR(qosmap->sta_mac));
	if (!MAC_ADDR_EQUAL(qosmap->sta_mac, zero_mac)) {
		/*send qos map configure frame to the specified STA*/
		dl_list_for_each(pos, &assoc_sta_list, struct associated_sta_info_db, list) {
			info(DEBUG_CAT_QOS, "qos sta mac "MACSTR"\n", MAC2STR(pos->src));
			if (MAC_ADDR_EQUAL(pos->src, qosmap->sta_mac)) {
				info(DEBUG_CAT_QOS, "send qos map config frame\n");
				wapp_send_qos_map_configure_frame(wapp, pos->ifname, pos->channel,
					qosmap->sta_mac, qosmap->dscp_ex, qosmap->num, qosmap->dscp_rg);
			}
		}
	} else {
		/*send qos map configure frame to all associated STAs*/
		dl_list_for_each(pos, &assoc_sta_list, struct associated_sta_info_db, list) {
			info(DEBUG_CAT_QOS, "qos sta mac "MACSTR"\n", MAC2STR(pos->src));
				info(DEBUG_CAT_QOS, "send qos map config frame\n");
				wapp_send_qos_map_configure_frame(wapp, pos->ifname, pos->channel,
					pos->src, qosmap->dscp_ex, qosmap->num, qosmap->dscp_rg);
		}
	}

	return ret;
}


int apply_qosmap_to_ap_local(struct wifi_app *wapp, const char *ifname, struct qos_map *qosmap)
{
	int ret = STATUS_SUCCESS;
	struct wapp_dev *wdev = NULL;
	struct dl_list *dev_list = NULL;

	if (!wapp || !qosmap) {
		err(DEBUG_CAT_QOS, "invalid pointer, wapp:%p, qosmap:%p\n", wapp, qosmap);
		return STATUS_INVALID_POINTER;
	}

	g_qosmap_up = 1;
	os_memcpy(&g_qosmap, qosmap, sizeof(g_qosmap));

	/*set qosmap to mtqos module*/
	ret = wapp_drv_send_event(NL_SET_QOS_MAP, (unsigned char *)qosmap, sizeof(struct qos_map));
	if (ret < 0)
		err(DEBUG_CAT_QOS, "set qosmap to mtqos fail, ret:%d\n", ret);

	/*set qosmap to Wi-Fi Driver*/
	if (ifname == NULL) {
		dev_list = &wapp->dev_list;
		dl_list_for_each(wdev, dev_list, struct wapp_dev, list) {
			if (wdev->dev_type == WAPP_DEV_TYPE_AP)
				set_qosmap_ie(wapp, wdev->ifname, qosmap);
		}
	} else {
		ret = set_qosmap_ie(wapp, ifname, qosmap);
		if (ret < 0)
			err(DEBUG_CAT_QOS, "set qosmap to wifi driver fail, ret:%d\n", ret);
	}

	return ret;
}


void mtqos_event_handler(int sock, void *eloop_ctx, void *sock_ctx)
{
	struct iovec iov;
	struct msghdr msghdr;
	struct sockaddr_nl dest_addr;
	struct qos_netlink_message *msg = NULL;
	struct wifi_app *wapp = (struct wifi_app *)eloop_ctx;
	struct wapp_vend_spec_classifier_para_report *pcs = NULL;
	struct ip_tuple *ptuple = NULL;

	/*init dest address for receive msg from netlink_sock*/
	memset(&dest_addr, 0, sizeof(dest_addr));
	dest_addr.nl_family = AF_NETLINK;
	dest_addr.nl_pid = 0; /* For Linux Kernel */
	dest_addr.nl_groups = 0; /* unicast */
	iov.iov_base = (void *)g_nlmsghdr;
	iov.iov_len = NLMSG_SPACE(MAX_PAYLOAD);

	memset(&msghdr, 0, sizeof(msghdr));
	msghdr.msg_name = (void *)&dest_addr;
	msghdr.msg_namelen = sizeof(dest_addr);
	msghdr.msg_iov = &iov;
	msghdr.msg_iovlen = 1;

	if (recvmsg(sock, &msghdr, 0) < 0)
		return;

	msg = (struct qos_netlink_message *)NLMSG_DATA(g_nlmsghdr);

	switch (msg->type) {
	case NL_VEND_SPECIFIC_CONFIG_EXPIRED:
		pcs = (struct wapp_vend_spec_classifier_para_report *)&msg->data[0];

		notice(DEBUG_CAT_QOS, "NL_VEND_SPECIFIC_CONFIG_EXPIRED on %s\n", pcs->ifname);

		wapp_drv_send_up_tuple_expired_notify(wapp, pcs->ifname,
			(char *)&msg->data[0], msg->len - sizeof(pcs->ifname));
		break;
	case NL_IP_TUPLE_EXPIRED_EVENT:
		ptuple = (struct ip_tuple *)&msg->data[0];
		notice(DEBUG_CAT_QOS, "received NL_IP_TUPLE_EXPIRED_EVENT.\n");

		update_ip_tuple_to_list(wapp, ptuple);
		break;
	default:
		warn(DEBUG_CAT_QOS, "unknown msg type(%02x)\n", msg->type);
		break;
	}
}

int set_qos_config(struct wifi_app *wapp, const char *iface, char *buf)
{
	u8 stat_code;
	int ret = 0;
	struct mscs_configuration mscs;
	struct scs_configuration scs;
	struct qos_map qosmap;
	struct ip_tuple iptuple;
	struct priority_bss pribss;
	struct priority_sta prista;
	char *token = NULL, *pos = NULL;

	/*triming space at the end of command*/
	token = strtok_r(buf, " ", &pos);

	if (!buf || !token) {
		err(DEBUG_CAT_QOS, "invalid buf:%p, token:%p\n", buf, token);
		return STATUS_INVALID_POINTER;
	}
	if (!os_strlen(buf)) {
		err(DEBUG_CAT_QOS, "buf len is 0.\n");
		return STATUS_INVALID_PARAM;
	}

	if (os_strncmp(buf, "MSCSReq", os_strlen("MSCSReq")) == 0) {
		os_memset(&mscs, 0, sizeof(mscs));

		/*1. parse mscs cmd*/
		ret = parse_mscs_cmd(buf, &mscs);
		if (ret != STATUS_SUCCESS) {
			err(DEBUG_CAT_QOS, "parsing mscs cmd failed, %s\n", err2str(ret));
			return ret;
		}

		/*2. sanity check*/
		ret = mscs_sanity_check(&mscs);
		if (ret != STATUS_SUCCESS) {
			err(DEBUG_CAT_QOS, "mscs cmd sanity check failed, %s\n", err2str(ret));
			return ret;
		}

		/*3. mscs request allowed check*/
		ret = allow_mscs_request_check(&mscs);
		if (ret < 0) {
			err(DEBUG_CAT_QOS, "mscs request is not allowed, %s\n", err2str(ret));
			return ret;
		}

		/*4. apply mscs to the AP*/
		ret = apply_mscs_to_ap(wapp, &mscs);
		if (ret != STATUS_SUCCESS)
			err(DEBUG_CAT_QOS, "apply mscs to AP failed, %s\n", err2str(ret));
	} else if (os_strncmp(buf, "SCSReq", os_strlen("SCSReq")) == 0) {
		os_memset(&scs, 0, sizeof(scs));

		/*1. parse scs cmd*/
		ret = parse_scs_cmd(buf, &scs);
		if (ret < 0) {
			err(DEBUG_CAT_QOS, "parsing scs cmd failed, %s\n", err2str(ret));
			return ret;
		}

		/*2. sanity check*/
		ret = scs_sanity_check(&scs);
		if (ret < 0) {
			err(DEBUG_CAT_QOS, "scs cmd sanity check failed, %s\n", err2str(ret));
			return ret;
		}

		/*3. scs request allowed check*/
		ret = allow_scs_request_check(&scs);
		if (ret < 0) {
			err(DEBUG_CAT_QOS, "scs request is not allowed, %s\n", err2str(ret));
			return ret;
		}

		/*4. build qos char IE if needed*/
		if (scs.qcharconfig.qchar_mask) {
			ret = build_qos_characteristics_ie(&scs);
			if (ret != STATUS_SUCCESS) {
				err(DEBUG_CAT_QOS, "build qos charIE failed, %s\n", err2str(ret));
				return ret;
			}
		}

		/*5. apply scs to the AP*/
		stat_code = apply_scs_to_ap(wapp, iface, &scs);
		if (stat_code != STA_SUCCESS && stat_code != STA_TERMINATED)
			err(DEBUG_CAT_QOS, "apply scs to AP failed, %s\n", err2str(ret));
	} else if (os_strncmp(buf, "perFlow", os_strlen("perFlow")) == 0) {
		os_memset(&iptuple, 0, sizeof(iptuple));
		iptuple.timeout = 60; /* init timeout to 60s */

		/*1. parse ip tuple cmd*/
		ret = parse_ip_tuple_cmd(buf, &iptuple);
		if (ret < 0) {
			err(DEBUG_CAT_QOS, "parsing iptuple cmd failed, %s\n", err2str(ret));
			return ret;
		}

		/*2. sanity check*/
		ret = ip_tuple_sanity_check(&iptuple);
		if (ret < 0) {
			err(DEBUG_CAT_QOS, "ip tuple cmd sanity check failed, %s\n", err2str(ret));
			return ret;
		}

		/*3. apply ip tuple to AP*/
		ret = apply_ip_tuple_to_ap(wapp, iface, &iptuple);
		if (ret < 0)
			err(DEBUG_CAT_QOS, "apply ip tuple to AP failed, %s\n", err2str(ret));
	} else if (os_strncmp(buf, "perBSS", os_strlen("perBSS")) == 0) {
		os_memset(&pribss, 0, sizeof(pribss));

		/*1. parse priority bss cmd*/
		ret = parse_bss_priority_cmd(buf, &pribss);
		if (ret < 0)
			err(DEBUG_CAT_QOS, "parsing priority bss cmd failed, %s\n", err2str(ret));

		/*2. sanity check*/
		ret = bss_priority_sanity_check(wapp, &pribss);
		if (ret != STATUS_SUCCESS) {
			err(DEBUG_CAT_QOS, "priority bss cmd sanity check failed, %s\n", err2str(ret));
			return ret;
		}

		/*3. apply priority bss to AP*/
		ret = apply_bss_priority_to_ap(wapp, iface, &pribss);
		if (ret < 0)
			err(DEBUG_CAT_QOS, "apply priority bss to AP failed, %s\n", err2str(ret));
	} else if (os_strncmp(buf, "perSTA", os_strlen("perSTA")) == 0) {
		os_memset(&prista, 0, sizeof(prista));

		/*1. parse priority sta cmd*/
		ret = parse_sta_priority_cmd(buf, &prista);
		if (ret < 0)
			err(DEBUG_CAT_QOS, "parsing priority sta cmd failed, %s\n", err2str(ret));

		/*2. sanity check*/
		ret = client_priority_sanity_check(wapp, &prista);
		if (ret != STATUS_SUCCESS) {
			err(DEBUG_CAT_QOS, "priority sta cmd sanity check failed, %s\n", err2str(ret));
			return ret;
		}

		/*3. apply priority sta to AP*/
		ret = apply_client_priority_to_ap(wapp, iface, &prista);
		if (ret < 0)
			err(DEBUG_CAT_QOS, "apply priority sta to AP failed, %s\n", err2str(ret));

	} else if (os_strncmp(buf, "Qosmap", os_strlen("Qosmap")) == 0) {
		os_memset(&qosmap, 0, sizeof(qosmap));
		os_memset(qosmap.dscp_rg, 0xFF, sizeof(qosmap.dscp_rg));

		/*1. parse qosmap cmd*/
		ret = parse_qosmap_cmd(buf, &qosmap);
		if (ret < 0) {
			err(DEBUG_CAT_QOS, "parsing qosmap cmd failed, %s\n", err2str(ret));
			return ret;
		}
		/*2. sanity check*/
		ret = qosmap_sanity_check(&qosmap);
		if (ret < 0) {
			err(DEBUG_CAT_QOS, "qosmap cmd sanity check failed, %s\n", err2str(ret));
			return ret;
		}

		if (!MAC_ADDR_EQUAL(qosmap.sta_mac, zero_mac))
			send_qosmap_to_peer_sta(wapp, iface, &qosmap);
		else
			apply_qosmap_to_ap_local(wapp, iface, &qosmap);

		if (ret < 0)
			err(DEBUG_CAT_QOS, "apply qosmap to AP failed, %s\n", err2str(ret));
	} else if (os_strncmp(buf, "maxstacnt", os_strlen("maxstacnt")) == 0) {
		ret = parse_maxstacnt_cmd(buf);
		if (ret < 0)
			err(DEBUG_CAT_QOS, "parsing cmd failed, %s\n", err2str(ret));
	} else {
		err(DEBUG_CAT_QOS, "invalid qos commands type.\n");
	}

	return ret;
}

int get_qos_config(struct wifi_app *wapp, char *cmdstr, char *reply_buf, size_t *reply_len)
{
	int ret = STATUS_SUCCESS;
	struct mscs_configuration *pos_mscs = NULL;
	struct scs_configuration *pos_scs = NULL;
	struct classifier_type4 *ptype4 = NULL;
	struct priority_bss_db *pos_bss = NULL;
	char *tmpbuf = NULL, *ip = NULL;
	unsigned int buflen = 10240, offset = 0;

	if (!wapp || !cmdstr || !reply_buf || !reply_len) {
		err(DEBUG_CAT_QOS,
			"invalid pointer, wapp:%p, cmdstr:%p, reply_buf:%p, reply_len:%p\n",
			wapp, cmdstr, reply_buf, reply_len);
		return STATUS_INVALID_POINTER;
	}

	if (os_strncmp(cmdstr, "MSCSReq", os_strlen("MSCSReq")) == 0) {
		if (mscs_active_sta_cnt == 0)
			return STATUS_CFG_NOT_EXISTED;

		tmpbuf = os_malloc(buflen);
		if (!tmpbuf) {
			err(DEBUG_CAT_QOS, "memory alloc fail\n");
			return STATUS_ALLOC_MEM_FAIL;
		}
		offset += ret;

		/* Form MSCS configuration as below format.
		 * MSCSReq,index,i,action,add,sta_mac,01:02:03:45:67:89,up_bitmap, 00001111,cs_mask,11111010
		 */
		dl_list_for_each(pos_mscs, &mscs_cfg_list, struct mscs_configuration, list) {
			ret = snprintf(tmpbuf + offset, buflen - offset,
				"MSCSReq,index,%u,sta_mac,"MACSTR",up_bitmap,%s,",
				pos_mscs->index, PRINT_MAC(pos_mscs->csparam.sta_mac),
				convert_i2strbitmap(pos_mscs->csparam.up_bitmap));
			if (os_snprintf_error(buflen - offset, ret))
				goto exit;
			offset += ret;

			ret = snprintf(tmpbuf + offset, buflen - offset, "cs_mask,%s\n",
				convert_i2strbitmap(pos_mscs->csparam.cs.header.cs_mask));
			if (os_snprintf_error(buflen - offset, ret))
				goto exit;
			offset += ret;
		}
	} else if (os_strncmp(cmdstr, "SCSReq", os_strlen("SCSReq")) == 0) {
		if (scs_active_sta_cnt == 0)
			return STATUS_CFG_NOT_EXISTED;

		tmpbuf = os_malloc(buflen);
		if (!tmpbuf) {
			err(DEBUG_CAT_QOS, "memory alloc fail\n");
			return STATUS_ALLOC_MEM_FAIL;
		}
		offset += ret;

		/* Form SCS configuration as below format.
		 * SCSReq,index,i,action,add,sta_mac,01:02:03:45:67:89,up,6,ipver,4,srcip,192.165.100.101,
		 * dstip,192.165.100.70,srcport,5002,dstport,10002,protocol,UDP
		 */
		dl_list_for_each(pos_scs, &scs_cfg_list, struct scs_configuration, list) {
			if (pos_scs->scsparam.tclas_num != 1)
				continue;

			ptype4 = &pos_scs->scsparam.tclas_elem[0].type4;

			ret = snprintf(tmpbuf + offset, buflen - offset,
				"SCSReq,index,%u,sta_mac,"MACSTR",up,%u,",
				pos_scs->index, PRINT_MAC(pos_scs->scsparam.sta_mac), pos_scs->scsparam.up);
			if (os_snprintf_error(buflen - offset, ret))
				goto exit;
			offset += ret;

			if (ptype4->cs_mask & TYPE4_CS_MASK_VERSION) {
				ret = snprintf(tmpbuf + offset, buflen - offset, "ipver,%d,", ptype4->version);
				if (os_snprintf_error(buflen - offset, ret))
					goto exit;
				offset += ret;
			}

			if (ptype4->version == VER_IPV4) {
				if (ptype4->cs_mask & TYPE4_CS_MASK_SRC_IP) {
					ip = (char *)&ptype4->srcIp.ipv4;
					ret = snprintf(tmpbuf + offset, buflen - offset,
						"srcip,"IPV4STR",", NIP4(ip));
					if (os_snprintf_error(buflen - offset, ret))
						goto exit;
					offset += ret;
				}
				if (ptype4->cs_mask & TYPE4_CS_MASK_DST_IP) {
					ip = (char *)&ptype4->destIp.ipv4;
					ret = snprintf(tmpbuf + offset, buflen - offset,
						"dstip,"IPV4STR",", NIP4(ip));
					if (os_snprintf_error(buflen - offset, ret))
						goto exit;
					offset += ret;
				}
			} else if (ptype4->version == VER_IPV6) {
				if (ptype4->cs_mask & TYPE4_CS_MASK_SRC_IP) {
					ret = snprintf(tmpbuf + offset, buflen - offset,
						"srcip,"IPV6STR",", NIP6(ptype4->srcIp.ipv6));
					if (os_snprintf_error(buflen - offset, ret))
						goto exit;
					offset += ret;
				}
				if (ptype4->cs_mask & TYPE4_CS_MASK_DST_IP) {
					ret = snprintf(tmpbuf + offset, buflen - offset,
						"dstip,"IPV6STR",", NIP6(ptype4->destIp.ipv6));
					if (os_snprintf_error(buflen - offset, ret))
						goto exit;
					offset += ret;
				}
			}

			if (ptype4->cs_mask & TYPE4_CS_MASK_SRC_PORT) {
				ret = snprintf(tmpbuf + offset, buflen - offset, "srcport,%d,", ntohs(ptype4->srcPort));
				if (os_snprintf_error(buflen - offset, ret))
					goto exit;
				offset += ret;
			}
			if (ptype4->cs_mask & TYPE4_CS_MASK_DST_PORT) {
				ret = snprintf(tmpbuf + offset, buflen - offset, "dstport,%d,",	ntohs(ptype4->destPort));
				if (os_snprintf_error(buflen - offset, ret))
					goto exit;
				offset += ret;
			}
			if (ptype4->cs_mask & TYPE4_CS_MASK_PROTOCOL) {
				ret = snprintf(tmpbuf + offset, buflen - offset, "protocol,%s,", protocol2str(ptype4->u.protocol));
				if (os_snprintf_error(buflen - offset, ret))
					goto exit;
				offset += ret;
			}

			ret = snprintf(tmpbuf + offset, buflen - offset, "\n");
			if (os_snprintf_error(buflen - offset, ret))
				goto exit;
			offset += ret;
		}
	} else if (os_strncmp(cmdstr, "perBSS", os_strlen("perBSS")) == 0) {
		if (pribss_list_cnt == 0)
			return STATUS_CFG_NOT_EXISTED;

		tmpbuf = os_malloc(buflen);
		if (!tmpbuf) {
			err(DEBUG_CAT_QOS, "memory alloc fail.\n");
			return STATUS_ALLOC_MEM_FAIL;
		}
		offset += ret;

		/* Form priority bss configuration as below format.
		 * perBSS,action,add,ssid,strssid,up,6
		 */
		dl_list_for_each(pos_bss, &pribss_list, struct priority_bss_db, list) {
			ret = snprintf(tmpbuf + offset, buflen - offset,
				"perBSS,action,add,ssid,%s,up,%u\n", pos_bss->node.ssid, pos_bss->node.up);
			if (os_snprintf_error(buflen - offset, ret))
				goto exit;
			offset += ret;
		}
	} else {
		ret = STATUS_INVALID_CMD_TYPE;
		err(DEBUG_CAT_QOS, "not support command type for getting qos config.\n");
	}

exit:
	if (os_snprintf_error(buflen - offset, ret)) {
		err(DEBUG_CAT_QOS, "error happen, ret = %d\n", ret);
		ret = STATUS_MEMORY_OVERFLOW;
	} else if (os_strlen(tmpbuf) && os_strlen(tmpbuf) < *reply_len) {
		memcpy(reply_buf, tmpbuf, os_strlen(tmpbuf));
		*reply_len = os_strlen(tmpbuf);
		ret = STATUS_SUCCESS;
	}

	if (tmpbuf)
		os_free(tmpbuf);

	return ret;
}

int save_qos_config(struct wifi_app *wapp)
{
	FILE *f = NULL;
	int ret = STATUS_SUCCESS;
	char *mscsbuf = NULL, *scsbuf = NULL;
	size_t mscsbuflen = 0, scsbuflen = 0;

	if (!wapp)
		return STATUS_INVALID_POINTER;

	if (mscs_active_sta_cnt == 0 && scs_active_sta_cnt == 0)
		err(DEBUG_CAT_QOS, "no qos config existed.\n");

	if (mscs_active_sta_cnt) {
		mscsbuflen = mscs_active_sta_cnt * 256;
		mscsbuf = os_malloc(mscsbuflen);
		if (!mscsbuf) {
			err(DEBUG_CAT_QOS, "MSCS memory alloc fail\n");
			ret = STATUS_ALLOC_MEM_FAIL;
			goto exit;
		}

		ret = get_qos_config(wapp, "MSCSReq", mscsbuf, &mscsbuflen);
		if (ret != STATUS_SUCCESS) {
			err(DEBUG_CAT_QOS, "get MSCS config fail.%s\n", err2str(ret));
			goto exit;
		}
	}

	if (scs_active_sta_cnt) {
		scsbuflen = scs_active_sta_cnt * 512;
		scsbuf = os_malloc(scsbuflen);
		if (!scsbuf) {
			err(DEBUG_CAT_QOS, "SCS memory alloc fail\n");
			ret = STATUS_ALLOC_MEM_FAIL;
			goto exit;
		}

		ret = get_qos_config(wapp, "SCSReq", scsbuf, &scsbuflen);
		if (ret != STATUS_SUCCESS) {
			err(DEBUG_CAT_QOS, "get SCS config fail.%s\n", err2str(ret));
			goto exit;
		}
	}

	/* write configuration to file. */
	f = fopen(QOS_CONF_PATH, "w");
	if (f == NULL)
		goto exit;

	if (mscsbuflen) {
		ret = fwrite(mscsbuf, 1, mscsbuflen, f);
		if (mscsbuflen != ret) {
			err(DEBUG_CAT_QOS, "write mscs error. mscsbuflen:%zu, ret:%d\n", mscsbuflen, ret);
			goto exit1;
		}
	}
	if (scsbuflen) {
		ret = fwrite(scsbuf, 1, scsbuflen, f);
		if (scsbuflen != ret) {
			err(DEBUG_CAT_QOS, "write scs error. mscsbuflen:%zu, ret:%d\n", scsbuflen, ret);
			goto exit1;
		}
	}

exit1:
	ret = fclose(f);
	if (ret != 0)
		err(DEBUG_CAT_QOS, "fclose fail\n");

exit:
	if (mscsbuf)
		os_free(mscsbuf);
	if (scsbuf)
		os_free(scsbuf);

	return ret;
}

int load_qos_config(struct wifi_app *wapp)
{
	FILE *f = NULL;
	int ret = STATUS_SUCCESS, buflen = 1024;
	char *buf = NULL;

	if (!wapp)
		return STATUS_INVALID_POINTER;

	/* write configuration to file. */
	f = fopen(QOS_CONF_PATH, "r");
	if (f == NULL) {
		warn(DEBUG_CAT_QOS, "open config file failed.\n");
		ret = STATUS_CFG_NOT_EXISTED;
		goto exit;
	}

	buf = os_malloc(buflen);
	if (!buf) {
		err(DEBUG_CAT_QOS, "memory alloc fail\n");
		goto exit1;
	}

	while (fgets(buf, buflen, f)) {
		ret = set_qos_config(wapp, NULL, buf);
		if (ret != STATUS_SUCCESS)
			err(DEBUG_CAT_QOS, "set config(%s) failed, %s\n", buf, err2str(ret));
	}

	if (buf)
		os_free(buf);
exit1:

	ret = fclose(f);
	if (ret < 0)
		err(DEBUG_CAT_QOS, "close file fail\n");
exit:
	return ret;
}

int get_qos_error_code(struct wifi_app *wapp, char *reply_buf, size_t *reply_len)
{
	int ret = STATUS_UNKNOWN;
	char tmpbuf[100] = {};

	if (!reply_buf || *reply_len == 0) {
		ret = snprintf(tmpbuf, sizeof(tmpbuf),
			"invalid reply_buf:%p or *reply_len:%zu.\n", reply_buf, *reply_len);
		if (os_snprintf_error(sizeof(tmpbuf), ret))
			goto exit;
		err(DEBUG_CAT_QOS, "%s\n", tmpbuf);
		return STATUS_INVALID_POINTER;
	}

	ret = snprintf(tmpbuf, sizeof(tmpbuf), "%s\n", err2str(g_status_code));
	if (os_snprintf_error(sizeof(tmpbuf), ret))
		goto exit;

	ret = STATUS_SUCCESS;

	if (os_strlen(tmpbuf) && (os_strlen(tmpbuf) < *reply_len)) {
		os_memcpy(reply_buf, tmpbuf, os_strlen(tmpbuf));
		*reply_len = os_strlen(tmpbuf);
	} else {
		err(DEBUG_CAT_QOS, "os_strlen(tmpbuf):%zu, *reply_len:%zu\n", os_strlen(tmpbuf), *reply_len);
		ret = STATUS_INVALID_PARAM;
	}
exit:
	if (os_snprintf_error(sizeof(tmpbuf), ret)) {
		err(DEBUG_CAT_QOS, "memory over flow, ret = %d\n", ret);
		ret = STATUS_MEMORY_OVERFLOW;
	}

	return ret;
}

void show_qos_config(struct wifi_app *wapp, const char *iface, char *buf)
{
	qos_cmd_show_config(wapp, iface, 0, NULL);
}

int wapp_ctrl_iface_cmd_set_qos_config(struct wifi_app *wapp,
	const char *iface, char *buf, char *reply, size_t *reply_len)
{
	int ret = 0;
	struct wapp_conf *conf;
	int is_found = 0;

	dl_list_for_each(conf, &wapp->conf_list, struct wapp_conf, list) {
		if (os_strcmp(conf->iface, iface) == 0) {
			is_found = 1;
			break;
		}
	}

	if (!is_found) {
		if (wapp_dev_list_lookup_by_ifname(wapp, iface) == NULL) {
			err(DEBUG_CAT_QOS, "can not find configuration for interface(%s)\n", iface);
			return -1;
		}
	}

	ret = set_qos_config(wapp, iface, buf);
	g_status_code = ret;

	return ret;
}

int wapp_ctrl_iface_cmd_get_qos_config(struct wifi_app *wapp,
	const char *iface, char *buf, char *reply, size_t *reply_len)
{
	int ret = 0;
	struct wapp_conf *conf;
	int is_found = 0;

	dl_list_for_each(conf, &wapp->conf_list, struct wapp_conf, list) {
		if (os_strcmp(conf->iface, iface) == 0) {
			is_found = 1;
			break;
		}
	}

	if (!is_found) {
		if (wapp_dev_list_lookup_by_ifname(wapp, iface) == NULL) {
			err(DEBUG_CAT_QOS, "can not find configuration for interface(%s)\n", iface);
			return -1;
		}
	}

	ret = get_qos_config(wapp, buf, reply, reply_len);
	g_status_code = ret;

	return ret;
}

int wapp_ctrl_iface_cmd_save_qos_config(struct wifi_app *wapp,
	const char *iface, char *buf, char *reply, size_t *reply_len)
{
	int ret = 0;
	struct wapp_conf *conf;
	int is_found = 0;

	dl_list_for_each(conf, &wapp->conf_list, struct wapp_conf, list) {
		if (os_strcmp(conf->iface, iface) == 0) {
			is_found = 1;
			break;
		}
	}

	if (!is_found) {
		if (wapp_dev_list_lookup_by_ifname(wapp, iface) == NULL) {
			err(DEBUG_CAT_QOS, "can not find configuration for interface(%s)\n", iface);
			return -1;
		}
	}

	ret = save_qos_config(wapp);
	g_status_code = ret;

	return ret;
}

int wapp_ctrl_iface_cmd_get_qos_errorcode(struct wifi_app *wapp,
	const char *iface, char *buf, char *reply, size_t *reply_len)
{
	int ret = 0;
	struct wapp_conf *conf;
	int is_found = 0;

	dl_list_for_each(conf, &wapp->conf_list, struct wapp_conf, list) {
		if (os_strcmp(conf->iface, iface) == 0) {
			is_found = 1;
			break;
		}
	}

	if (!is_found) {
		if (wapp_dev_list_lookup_by_ifname(wapp, iface) == NULL) {
			err(DEBUG_CAT_QOS, "can not find configuration for interface(%s)\n", iface);
			return -1;
		}
	}

	ret = get_qos_error_code(wapp, reply, reply_len);

	return ret;
}

int wapp_ctrl_iface_cmd_show_qos_config(struct wifi_app *wapp,
	const char *iface, char *buf, char *reply, size_t *reply_len)
{
	int ret = 0;
	struct wapp_conf *conf;
	int is_found = 0;

	dl_list_for_each(conf, &wapp->conf_list, struct wapp_conf, list) {
		if (os_strcmp(conf->iface, iface) == 0) {
			is_found = 1;
			break;
		}
	}

	if (!is_found) {
		if (wapp_dev_list_lookup_by_ifname(wapp, iface) == NULL) {
			err(DEBUG_CAT_QOS, "can not find configuration for interface(%s)\n", iface);
			return -1;
		}
	}

	show_qos_config(wapp, iface, buf);

	return ret;
}

#endif /* QOS_R1 */
