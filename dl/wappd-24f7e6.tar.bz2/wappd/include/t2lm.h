/* SPDX-License-Identifier: MediaTekProprietary*/
/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2023-2024  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#ifndef _T2LM_H_
#define _T2LM_H_

#define TID_MAX		8	/* TID0~TID7 */

/*struct nl_80211_t2lm_cmd is for communicating between driver/wapp,
 * when sending/received t2lm request/response frames.
 * @ta_addr:	inidicate mac address of sender.
 * @ra_addr:	inidicate mac address of receiver.
 * @dir:		indicate direction of t2lm mapping.
 * @tid_bit_map:	bit map for tid.
 * @tid_to_link_bitmap: bit map for link.
 * @status_code:	report status of response from driver, reserved in other cases.
 */
struct nl_80211_t2lm_cmd {
	u8 ta_addr[MAC_ADDR_LEN];
	u8 ra_addr[MAC_ADDR_LEN];
	u8 dir;
	u8 tid_bit_map;
	u16 tid_to_link_bitmap[TID_MAX];
	u16 status_code;
};

/*struct nl_80211_at2lm_map is for setting at2lm mapping to driver
 * when receiving TID-to-Link Mapping Policy TLV from mapd.
 * @mld_addr:	inidicate mld address of this TLV applied.
 * @dis_link_map: inidicate disabled linkid bit map.
 * @mst_dur:	Mapping Switch Time.
 * @exp_dur:	Expected Duration.
 */
struct nl_80211_at2lm_map {
	unsigned char mld_addr[MAC_ADDR_LEN];
	unsigned short dis_link_map;
	unsigned int mst_dur;
	unsigned int exp_dur;
};

int wapp_handle_map_t2lm_request(struct wifi_app *wapp, char *msg_buf, unsigned short msg_len);
int wapp_send_t2lm_request_frame(struct wifi_app *wapp, char *msg_buf, unsigned short msg_len);

#endif /* #ifndef _T2LM_H_ */
