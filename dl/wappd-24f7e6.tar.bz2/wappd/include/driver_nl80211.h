/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#ifndef __DRIVER_NL80211_H__
#define __DRIVER_NL80211_H__

#include "types.h"
#ifdef STANDARD_NL_CMD
#include "list.h"
#define EXTCHA_NONE			0
#define EXTCHA_ABOVE		0x1
#define EXTCHA_BELOW		0x3
#define EXTCHA_NOASSIGN		0xf
/* max_mcs_nss for 20M-only sta*/
#define DOT11BE_MCS_NSS_SHIFT 4
#define DOT11BE_MCS_NSS_MASK 0xf
/* phy_capinfo_1: bit0..bit31 */
#define DOT11BE_PHY_CAP_320M_6G BIT(1)
#define DOT11BE_PHY_CAP_242_TONE_RU_WT_20M BIT(2)
#define DOT11BE_PHY_CAP_NDP_4X_EHT_LTF_3DOT2US_GI BIT(3)
#define DOT11BE_PHY_CAP_PARTIAL_BW_UL_MU_MIMO BIT(4)
#define DOT11BE_PHY_CAP_SU_BFER BIT(5)
#define DOT11BE_PHY_CAP_SU_BFEE BIT(6)

#define GET_SEC_AKM(_SecConfig)              ((_SecConfig)->AKMMap)
#define CLEAR_SEC_AKM(_AKMMap)              (_AKMMap = 0x0)
#define CLEAR_NONFT_AKM(_AKMMap)              (_AKMMap &= ~((1 << SEC_AKM_WPA2) | (1 << SEC_AKM_WPA2PSK) |\
						(1 << SEC_AKM_WPA2_SHA256) | (1 << SEC_AKM_WPA2PSK_SHA256) |\
						(1 << SEC_AKM_SAE_SHA256) | (1 << SEC_AKM_SUITEB_SHA384)))
#define SET_AKM_OPEN(_AKMMap)           (_AKMMap |= (1 << SEC_AKM_OPEN))
#define SET_AKM_SHARED(_AKMMap)       (_AKMMap |= (1 << SEC_AKM_SHARED))
#define SET_AKM_AUTOSWITCH(_AKMMap)       (_AKMMap |= (1 << SEC_AKM_AUTOSWITCH))
#define SET_AKM_WPA1(_AKMMap)          (_AKMMap |= (1 << SEC_AKM_WPA1))
#define SET_AKM_WPA1PSK(_AKMMap)    (_AKMMap |= (1 << SEC_AKM_WPA1PSK))
#define SET_AKM_WPANONE(_AKMMap)  (_AKMMap |= (1 << SEC_AKM_WPANone))
#define SET_AKM_WPA2(_AKMMap)          (_AKMMap |= (1 << SEC_AKM_WPA2))
#define SET_AKM_WPA2PSK(_AKMMap)    (_AKMMap |= (1 << SEC_AKM_WPA2PSK))
#define SET_AKM_FT_WPA2(_AKMMap)                  (_AKMMap |= (1 << SEC_AKM_FT_WPA2))
#define SET_AKM_FT_WPA2PSK(_AKMMap)            (_AKMMap |= (1 << SEC_AKM_FT_WPA2PSK))
#define SET_AKM_WPA2_SHA256(_AKMMap)         (_AKMMap |= (1 << SEC_AKM_WPA2_SHA256))
#define SET_AKM_WPA2PSK_SHA256(_AKMMap)   (_AKMMap |= (1 << SEC_AKM_WPA2PSK_SHA256))
#define SET_AKM_TDLS(_AKMMap)                           (_AKMMap |= (1 << SEC_AKM_TDLS))
#define SET_AKM_SAE_SHA256(_AKMMap)              (_AKMMap |= (1 << SEC_AKM_SAE_SHA256))
#define SET_AKM_FT_SAE_SHA256(_AKMMap)        (_AKMMap |= (1 << SEC_AKM_FT_SAE_SHA256))
#define SET_AKM_SUITEB_SHA256(_AKMMap)         (_AKMMap |= (1 << SEC_AKM_SUITEB_SHA256))
#define SET_AKM_SUITEB_SHA384(_AKMMap)         (_AKMMap |= (1 << SEC_AKM_SUITEB_SHA384))
#define SET_AKM_FT_WPA2_SHA384(_AKMMap)     (_AKMMap |= (1 << SEC_AKM_FT_WPA2_SHA384))
#define SET_AKM_WAICERT(_AKMMap)                   (_AKMMap |= (1 << SEC_AKM_WAICERT))
#define SET_AKM_WPIPSK(_AKMMap)                     (_AKMMap |= (1 << SEC_AKM_WAIPSK))
#define SET_AKM_OWE(_AKMMap)     (_AKMMap |= (1 << SEC_AKM_OWE))
#define SET_AKM_FILS_SHA256(_AKMMap)                (_AKMMap |= (1 << SEC_AKM_FILS_SHA256))
#define SET_AKM_FILS_SHA384(_AKMMap)                (_AKMMap |= (1 << SEC_AKM_FILS_SHA384))
#define SET_AKM_WPA3(_AKMMap)     (_AKMMap |= (1 << SEC_AKM_WPA3))
#define SET_AKM_OSEN(_AKMMap)           (_AKMMap |= (1 << SEC_AKM_OSEN))
#define SET_AKM_DPP(_AKMMap)     (_AKMMap |= (1 << SEC_AKM_DPP))
#define SET_AKM_SAE_EXT(_AKMMap)                (_AKMMap |= (1 << SEC_AKM_SAE_EXT))
#define SET_AKM_FT_SAE_EXT(_AKMMap)          (_AKMMap |= (1 << SEC_AKM_FT_SAE_EXT))

#define IS_AKM_OPEN(_AKMMap)                           ((_AKMMap & (1 << SEC_AKM_OPEN)) > 0)
#define IS_AKM_SHARED(_AKMMap)                       ((_AKMMap & (1 << SEC_AKM_SHARED)) > 0)
#define IS_AKM_AUTOSWITCH(_AKMMap)              ((_AKMMap & (1 << SEC_AKM_AUTOSWITCH)) > 0)
#define IS_AKM_WPA1(_AKMMap)                           ((_AKMMap & (1 << SEC_AKM_WPA1)) > 0)
#define IS_AKM_WPA1PSK(_AKMMap)                    ((_AKMMap & (1 << SEC_AKM_WPA1PSK)) > 0)
#define IS_AKM_WPANONE(_AKMMap)                  ((_AKMMap & (1 << SEC_AKM_WPANone)) > 0)
#define IS_AKM_WPA2(_AKMMap)                          ((_AKMMap & (1 << SEC_AKM_WPA2)) > 0)
#define IS_AKM_WPA2PSK(_AKMMap)                    ((_AKMMap & (1 << SEC_AKM_WPA2PSK)) > 0)
#define IS_AKM_FT_WPA2(_AKMMap)                     ((_AKMMap & (1 << SEC_AKM_FT_WPA2)) > 0)
#define IS_AKM_FT_WPA2PSK(_AKMMap)              ((_AKMMap & (1 << SEC_AKM_FT_WPA2PSK)) > 0)
#define IS_AKM_WPA2_SHA256(_AKMMap)            ((_AKMMap & (1 << SEC_AKM_WPA2_SHA256)) > 0)
#define IS_AKM_WPA2PSK_SHA256(_AKMMap)      ((_AKMMap & (1 << SEC_AKM_WPA2PSK_SHA256)) > 0)
#define IS_AKM_TDLS(_AKMMap)                             ((_AKMMap & (1 << SEC_AKM_TDLS)) > 0)
#define IS_AKM_SAE_SHA256(_AKMMap)                ((_AKMMap & (1 << SEC_AKM_SAE_SHA256)) > 0)
#define IS_AKM_FT_SAE_SHA256(_AKMMap)          ((_AKMMap & (1 << SEC_AKM_FT_SAE_SHA256)) > 0)
#define IS_AKM_SUITEB_SHA256(_AKMMap)          ((_AKMMap & (1 << SEC_AKM_SUITEB_SHA256)) > 0)
#define IS_AKM_SUITEB_SHA384(_AKMMap)          ((_AKMMap & (1 << SEC_AKM_SUITEB_SHA384)) > 0)
#define IS_AKM_FT_WPA2_SHA384(_AKMMap)      ((_AKMMap & (1 << SEC_AKM_FT_WPA2_SHA384)) > 0)
#ifdef WAPI_SUPPORT
#define IS_AKM_WAICERT(_AKMMap)                      ((_AKMMap & (1 << SEC_AKM_WAICERT)) > 0)
#define IS_AKM_WPIPSK(_AKMMap)                        ((_AKMMap & (1 << SEC_AKM_WAIPSK)) > 0)
#endif /* WAPI_SUPPORT */
#define IS_AKM_WPA3(_AKMMap)	 ((_AKMMap & (1 << SEC_AKM_WPA3)) > 0)
#ifdef CONFIG_HOTSPOT_R3
#define IS_AKM_OSEN(_AKMMap)     ((_AKMMap & (1 << SEC_AKM_OSEN)) > 0)
#endif
#define IS_AKM_DPP(_AKMMap)      ((_AKMMap & (1 << SEC_AKM_DPP)) > 0)
#define IS_AKM_SAE_EXT(_AKMMap)                ((_AKMMap & (1 << SEC_AKM_SAE_EXT)) > 0)
#define IS_AKM_FT_SAE_EXT(_AKMMap)          ((_AKMMap & (1 << SEC_AKM_FT_SAE_EXT)) > 0)


#define IS_AKM_WPA3_192BIT(_AKMMap)	(IS_AKM_SUITEB_SHA384(_AKMMap))
#define SET_AKM_WPA3_192BIT(_AKMMap)	SET_AKM_SUITEB_SHA384(_AKMMap)

#define IS_AKM_FILS_SHA256(_AKMMap)                ((_AKMMap & (1 << SEC_AKM_FILS_SHA256)) > 0)
#define IS_AKM_FILS_SHA384(_AKMMap)                ((_AKMMap & (1 << SEC_AKM_FILS_SHA384)) > 0)
#define IS_AKM_FILS(_AKMMap)     (IS_AKM_FILS_SHA256(_AKMMap)  \
								|| IS_AKM_FILS_SHA384(_AKMMap))

#define IS_AKM_FILS_Entry(_Entry)     (IS_AKM_FILS_SHA256((_Entry)->SecConfig.AKMMap)  \
									 || IS_AKM_FILS_SHA384((_Entry)->SecConfig.AKMMap))
#define IS_AKM_WPA3PSK(_AKMMap) (IS_AKM_SAE_SHA256(_AKMMap) \
									|| IS_AKM_SAE_EXT(_AKMMap))
#define SET_AKM_WPA3PSK(_AKMMap) (_AKMMap |= (1 << SEC_AKM_SAE_SHA256) | (1 << SEC_AKM_SAE_EXT))

#define IS_AKM_OWE(_AKMMap) ((_AKMMap & (1 << SEC_AKM_OWE)) > 0)

#define IS_AKM_WPA3PSK_ONLY(_AKMMap)                          (_AKMMap == (1 << SEC_AKM_SAE_SHA256))
#define IS_AKM_WPA2PSK_ONLY(_AKMMap)                          (_AKMMap == (1 << SEC_AKM_WPA2PSK))

#define IS_AKM_SAE(_AKMMap)     (IS_AKM_SAE_SHA256(_AKMMap)  \
				|| IS_AKM_FT_SAE_SHA256(_AKMMap)  \
				|| IS_AKM_SAE_EXT(_AKMMap)  \
				|| IS_AKM_FT_SAE_EXT(_AKMMap))


#define IS_AKM_FT_SAE(_AKMMap)     (IS_AKM_FT_SAE_SHA256(_AKMMap)  \
				|| IS_AKM_FT_SAE_EXT(_AKMMap))

#define IS_AKM_PSK(_AKMMap)     (IS_AKM_WPA1PSK(_AKMMap)  \
				|| IS_AKM_WPA2PSK(_AKMMap)\
				|| IS_AKM_WPA3PSK(_AKMMap)\
				|| IS_AKM_DPP(_AKMMap)\
				|| IS_AKM_OWE(_AKMMap))

#define IS_AKM_1X(_AKMMap)     (IS_AKM_WPA1(_AKMMap)  \
								|| IS_AKM_WPA2(_AKMMap)\
								|| IS_AKM_WPA3_192BIT(_AKMMap))

#define STA_MLD_LINK_MAX  3
#define STA_MLD_LINK_MIN  0
enum _SEC_CIPHER_MODE {
	SEC_CIPHER_NONE,
	SEC_CIPHER_WEP40,
	SEC_CIPHER_WEP104,
	SEC_CIPHER_WEP128,
	SEC_CIPHER_TKIP,
	SEC_CIPHER_CCMP128,
	SEC_CIPHER_CCMP256,
	SEC_CIPHER_GCMP128,
	SEC_CIPHER_GCMP256,
	SEC_CIPHER_BIP_CMAC128,
	SEC_CIPHER_BIP_CMAC256,
	SEC_CIPHER_BIP_GMAC128,
	SEC_CIPHER_BIP_GMAC256,
	SEC_CIPHER_WPI_SMS4, /* WPI SMS4 support */
	SEC_CIPHER_MAX /* Not a real mode, defined as upper bound */
};

enum _SEC_AKM_MODE {
	SEC_AKM_OPEN,
	SEC_AKM_SHARED,
	SEC_AKM_AUTOSWITCH,
	SEC_AKM_WPA1, /* Enterprise security over 802.1x */
	SEC_AKM_WPA1PSK,
	SEC_AKM_WPANone, /* For Win IBSS, directly PTK, no handshark */
	SEC_AKM_WPA2, /* Enterprise security over 802.1x */
	SEC_AKM_WPA2PSK,
	SEC_AKM_FT_WPA2,
	SEC_AKM_FT_WPA2PSK,
	SEC_AKM_WPA2_SHA256,
	SEC_AKM_WPA2PSK_SHA256,
	SEC_AKM_TDLS,
	SEC_AKM_SAE_SHA256,
	SEC_AKM_FT_SAE_SHA256,
	SEC_AKM_SUITEB_SHA256,
	SEC_AKM_SUITEB_SHA384,
	SEC_AKM_FT_WPA2_SHA384,
	SEC_AKM_WAICERT, /* WAI certificate authentication */
	SEC_AKM_WAIPSK, /* WAI pre-shared key */
	SEC_AKM_OWE,
	SEC_AKM_FILS_SHA256,
	SEC_AKM_FILS_SHA384,
	SEC_AKM_WPA3, /* WPA3(ent) */
	SEC_AKM_OSEN,
	SEC_AKM_DPP,
	SEC_AKM_SAE_EXT,
	SEC_AKM_FT_SAE_EXT,
	SEC_AKM_MAX /* Not a real mode, defined as upper bound */
};

#define CLEAR_PAIRWISE_CIPHER(_SecConfig)      ((_SecConfig)->PairwiseCipher = 0x0)
#define CLEAR_GROUP_CIPHER(_SecConfig)          ((_SecConfig)->GroupCipher = 0x0)
#define CLEAR_INTEGRITY_GROUP_CIPHER(_SecConfig)          ((_SecConfig)->PmfCfg.igtk_cipher = 0x0)
#define CLEAR_BEACON_INTEGRITY_GROUP_CIPHER(_SecConfig)          ((_SecConfig)->bcn_prot_cfg.bigtk_cipher = 0x0)
#define GET_PAIRWISE_CIPHER(_SecConfig)         ((_SecConfig)->PairwiseCipher)
#define GET_GROUP_CIPHER(_SecConfig)              ((_SecConfig)->GroupCipher)
#define GET_INTEGRITY_GROUP_CIPHER(_SecConfig)      ((_SecConfig)->PmfCfg.igtk_cipher)
#define GET_BEACON_INTEGRITY_GROUP_CIPHER(_SecConfig)      ((_SecConfig)->bcn_prot_cfg.bigtk_cipher)
#define CLEAR_CIPHER(_cipher)					(_cipher  = 0x0)
#define SET_CIPHER_NONE(_cipher)               (_cipher |= (1 << SEC_CIPHER_NONE))
#define SET_CIPHER_WEP40(_cipher)             (_cipher |= (1 << SEC_CIPHER_WEP40))
#define SET_CIPHER_WEP104(_cipher)           (_cipher |= (1 << SEC_CIPHER_WEP104))
#define SET_CIPHER_WEP128(_cipher)           (_cipher |= (1 << SEC_CIPHER_WEP128))
#define SET_CIPHER_WEP(_cipher)                 \
		(_cipher |= (1 << SEC_CIPHER_WEP40) | (1 << SEC_CIPHER_WEP104) \
		 | (1 << SEC_CIPHER_WEP128))
#define SET_CIPHER_TKIP(_cipher)                  (_cipher |= (1 << SEC_CIPHER_TKIP))
#define SET_CIPHER_CCMP128(_cipher)          (_cipher |= (1 << SEC_CIPHER_CCMP128))
#define SET_CIPHER_CCMP256(_cipher)          (_cipher |= (1 << SEC_CIPHER_CCMP256))
#define SET_CIPHER_GCMP128(_cipher)         (_cipher |= (1 << SEC_CIPHER_GCMP128))
#define SET_CIPHER_GCMP256(_cipher)         (_cipher |= (1 << SEC_CIPHER_GCMP256))
#define SET_CIPHER_WPI_SMS4(_cipher)       (_cipher |= (1 << SEC_CIPHER_WPI_SMS4))
#define SET_CIPHER_BIP_CMAC128(_cipher)     (_cipher = (1 << SEC_CIPHER_BIP_CMAC128))
#define SET_CIPHER_BIP_CMAC256(_cipher)     (_cipher = (1 << SEC_CIPHER_BIP_CMAC256))
#define SET_CIPHER_BIP_GMAC128(_cipher)     (_cipher = (1 << SEC_CIPHER_BIP_GMAC128))
#define SET_CIPHER_BIP_GMAC256(_cipher)     (_cipher = (1 << SEC_CIPHER_BIP_GMAC256))

#define IS_CIPHER_NONE(_Cipher)          (((_Cipher) & (1 << SEC_CIPHER_NONE)) > 0)
#define IS_CIPHER_WEP40(_Cipher)          (((_Cipher) & (1 << SEC_CIPHER_WEP40)) > 0)
#define IS_CIPHER_WEP104(_Cipher)        (((_Cipher) & (1 << SEC_CIPHER_WEP104)) > 0)
#define IS_CIPHER_WEP128(_Cipher)        (((_Cipher) & (1 << SEC_CIPHER_WEP128)) > 0)
#define IS_CIPHER_WEP(_Cipher)              \
		(((_Cipher) & ((1 << SEC_CIPHER_WEP40) | (1 << SEC_CIPHER_WEP104) \
		| (1 << SEC_CIPHER_WEP128))) > 0)
#define IS_CIPHER_TKIP(_Cipher)              (((_Cipher) & (1 << SEC_CIPHER_TKIP)) > 0)
#define IS_CIPHER_WEP_TKIP_ONLY(_Cipher)     \
		((IS_CIPHER_WEP(_Cipher) || IS_CIPHER_TKIP(_Cipher)) \
		&& (_Cipher < (1 << SEC_CIPHER_CCMP128)))
#define IS_CIPHER_CCMP128(_Cipher)      (((_Cipher) & (1 << SEC_CIPHER_CCMP128)) > 0)
#define IS_CIPHER_CCMP256(_Cipher)      (((_Cipher) & (1 << SEC_CIPHER_CCMP256)) > 0)
#define IS_CIPHER_GCMP128(_Cipher)     (((_Cipher) & (1 << SEC_CIPHER_GCMP128)) > 0)
#define IS_CIPHER_GCMP256(_Cipher)     (((_Cipher) & (1 << SEC_CIPHER_GCMP256)) > 0)
#define IS_CIPHER_BIP_CMAC128(_Cipher)     (((_Cipher) & (1 << SEC_CIPHER_BIP_CMAC128)) > 0)
#define IS_CIPHER_BIP_CMAC256(_Cipher)     (((_Cipher) & (1 << SEC_CIPHER_BIP_CMAC256)) > 0)
#define IS_CIPHER_BIP_GMAC128(_Cipher)     (((_Cipher) & (1 << SEC_CIPHER_BIP_GMAC128)) > 0)
#define IS_CIPHER_BIP_GMAC256(_Cipher)     (((_Cipher) & (1 << SEC_CIPHER_BIP_GMAC256)) > 0)

#define MAX_LEN_OF_RSNIE			255
#define MIN_LEN_OF_RSNIE			2
#define MAX_LEN_OF_RSNXEIE                      255
#define MIN_LEN_OF_RSNXEIE                      2
#define MAX_LEN_GTK					32
#define MIN_LEN_GTK					5
#define LEN_OUI_SUITE				4

#define DOT11_RNR_TBTT_INFO_HDR_TBTTINFO_CNT_SHIFT 4
#define DOT11_RNR_TBTT_INFO_HDR_TBTTINFO_CNT_MASK (0xF << 4)
#define DOT11_RNR_TBTT_INFO_HDR_TBTTINFO_LEN_SHIFT 8
#define DOT11_RNR_TBTT_INFO_HDR_TBTTINFO_LEN_MASK (0xFF << 8)


#define EHT_OP_IE_BASIC_LEN 5 /* EHT Operation Parameters + Basic EHT-MCS And Nss Set */
#define EHT_OP_IE_MAX_LEN 10 /*the maxmum length of EHT Operation Parameters*/

#define BITS(m, n)              (~(BIT(m)-1) & ((BIT(n) - 1) | BIT(n)))

#define SET_CAP_BITS(_cap, _capinfo, _value)\
{\
	_capinfo &= ~_cap##_MASK;\
	_capinfo |= ((_value << _cap##_SHIFT)\
			& _cap##_MASK);\
}

#define GET_CAP_BITS(_cap, _capinfo)\
	(((_capinfo) & _cap##_MASK)\
		>> _cap##_SHIFT)

#define CAP_BITS_MASK(_cap)\
	BITS(_cap##_SHIFT, (_cap##_SHIFT + _cap##_BITS - 1))


#define DOT11BE_OP_PARAM_HAS_OP_INFO_SHIFT 0
#define DOT11BE_OP_PARAM_HAS_OP_INFO_MASK \
	BIT(DOT11BE_OP_PARAM_HAS_OP_INFO_SHIFT)
#define SET_DOT11BE_OP_PARAM_HAS_OP_INFO(_op_param, _value) \
	SET_CAP_BITS(DOT11BE_OP_PARAM_HAS_OP_INFO, _op_param, _value)
#define GET_DOT11BE_OP_PARAM_HAS_OP_INFO(_op_param) \
	GET_CAP_BITS(DOT11BE_OP_PARAM_HAS_OP_INFO, _op_param)

#define DOT11BE_OP_PARAM_HAS_DIS_SUB_CH_BITMAP_SHIFT 1
#define DOT11BE_OP_PARAM_HAS_DIS_SUB_CH_BITMAP_MASK \
	BIT(DOT11BE_OP_PARAM_HAS_DIS_SUB_CH_BITMAP_SHIFT)
#define SET_DOT11BE_OP_PARAM_HAS_DIS_SUB_CH_BITMAP(_op_param, _value) \
	SET_CAP_BITS(DOT11BE_OP_PARAM_HAS_DIS_SUB_CH_BITMAP, _op_param, _value)
#define GET_DOT11BE_OP_PARAM_HAS_DIS_SUB_CH_BITMAP(_op_param) \
	GET_CAP_BITS(DOT11BE_OP_PARAM_HAS_DIS_SUB_CH_BITMAP, _op_param)


enum RSN_FIELD {
	RSN_FIELD_NONE = 0,
	RSN_FIELD_GROUP_CIPHER,
	RSN_FIELD_PAIRWISE_CIPHER,
	RSN_FIELD_AKM,
	RSN_FIELD_RSN_CAP,
	RSN_FIELD_PMKID,
	RSN_FIELD_GROUP_MGMT_CIPHER,
	RSN_FIELD_EXTENSIBLE_ELE
};

struct GNU_PACKED akm_capabe {
	u8 oui[3];
	u8 suite_type;
};

struct GNU_PACKED _RSN_IE_HEADER_STRUCT {
	unsigned char Eid;
	unsigned char Length;
	unsigned short Version;		/* Little endian format */
};

#endif

#ifndef GNU_PACKED
#define GNU_PACKED  __attribute__((packed))
#endif /* GNU_PACKED */

#define AIR_MONITOR_RULE_SIZE 3

#ifdef STANDARD_NL_CMD
#define MODE_FLAG_HT_INFO_KNOWN BIT(0)
#define MODE_FLAG_VHT_INFO_KNOWN BIT(1)

#define CHAN_DISABLED 0x00000001
#define CHAN_NO_IR 0x00000002
#define CHAN_RADAR 0x00000008
#define CHAN_HT40PLUS 0x00000010
#define CHAN_HT40MINUS 0x00000020
#define CHAN_HT40 0x00000040
#define CHAN_SURVEY_LIST_INITIALIZED 0x00000080

#define CHAN_INDOOR_ONLY 0x00010000
#define CHAN_GO_CONCURRENT 0x00020000

#define CHAN_DFS_UNKNOWN 0x00000000
#define CHAN_DFS_USABLE 0x00000100
#define CHAN_DFS_UNAVAILABLE 0x00000200
#define CHAN_DFS_AVAILABLE 0x00000300
#define CHAN_DFS_MASK 0x00000300

#define HE_MAX_MAC_CAPAB_SIZE	6
#define HE_MAX_PHY_CAPAB_SIZE	11
#define HE_MAX_MCS_CAPAB_SIZE	12
#define HE_MAX_PPET_CAPAB_SIZE	25




enum {
	NL_WAPP_APCLI_DISASSOCIATED = 0,
	NL_WAPP_APCLI_ASSOCIATED,
};


struct nl_apcli_assoc_info {
	u32 interface_index;
	u8 apcli_assoc_state;
	signed char rssi;
	signed char PeerMAPEnable;
};

#define EHT_PHY_CAPAB_LEN			9
#define EHT_MCS_NSS_CAPAB_LEN		9
#define EHT_PPE_THRESH_CAPAB_LEN	62
#endif

struct driver_nl80211_data {
	struct unl nl_handle;
	struct unl nl_event;

	int opmode;
	u8 drv_mode;
	void *priv;
	u32 ifindex;
	void *get_data;
	u32 *get_data_len;
};

#ifdef STANDARD_NL_CMD

#define DOT11AX_PHY_CAP_CH_WIDTH_SET_MASK (0x7F << 1)
#define DOT11AX_PHY_CAP_CH_WIDTH_SET_SHIFT 1

#define GET_DOT11AX_CH_WIDTH(phy_cap)\
	(((phy_cap) & DOT11AX_PHY_CAP_CH_WIDTH_SET_MASK) >> DOT11AX_PHY_CAP_CH_WIDTH_SET_SHIFT)

enum eht_nss_mcs_len {
	EHT_NSS_MCS_20M_TO_80M = 3,
	EHT_NSS_MCS_20M_ONLY = 4,
	EHT_NSS_MCS_80M_TO_160M = 6,
	EHT_NSS_MCS_160M_TO_320M = 9,
};

enum he_channel_width_set {
	SUPP_40M_CW_IN_24G_BAND = 1,
	SUPP_40M_80M_CW_IN_5G_6G_BAND = (1 << 1),
	SUPP_160M_CW_IN_5G_6G_BAND = (1 << 2),
	SUPP_160M_8080M_CW_IN_5G_6G_BAND = (1 << 3),
	SUPP_20MSTA_RX_242TONE_RU_IN_24G_BAND = (1 << 4),
	SUPP_20MSTA_RX_242TONE_RU_IN_5G_BAND = (1 << 5)
};
struct GNU_PACKED ADD_HTINFO {

	unsigned char	ExtChanOffset:2;
	unsigned char	RecomWidth:1;
	unsigned char	RifsMode:1;
	unsigned char	S_PSMPSup:1;	 /*Indicate support for scheduled PSMP */
	unsigned char	SerInterGranu:3;	 /*service interval granularity */
};

struct GNU_PACKED ADD_HTINFO2 {

	unsigned short	OperaionMode:2;
	unsigned short	NonGfPresent:1;
	unsigned short	rsv:1;
	unsigned short	OBSS_NonHTExist:1;
	unsigned short  CentFreq2:8;
	unsigned short  rsv2:3;
};


/* TODO: Need sync with spec about the definition of StbcMcs. In Draft 3.03, it's reserved. */
struct GNU_PACKED ADD_HTINFO3 {

	unsigned short	StbcMcs:6;
	unsigned short	DualBeacon:1;
	unsigned short	DualCTSProtect:1;
	unsigned short	STBCBeacon:1;
	unsigned short	LsigTxopProt:1;	/* L-SIG TXOP protection full support */
	unsigned short	PcoActive:1;
	unsigned short	PcoPhase:1;
	unsigned short	rsv:4;
};

struct  GNU_PACKED ADD_HT_INFO_IE {

	unsigned char		ControlChan;
	struct ADD_HTINFO			AddHtInfo;
	struct ADD_HTINFO2			AddHtInfo2;
	struct ADD_HTINFO3			AddHtInfo3;
	unsigned char		MCSSet[16];		/* Basic MCS set */
};

struct GNU_PACKED HT_AS_CAP {

	u8	AntSelect:1;
	u8	ExpCSIFbkTxASEL:1;
	u8	AntIndFbkTxASEL:1;
	u8	ExpCSIFbk:1;
	u8	AntIndFbk:1;
	u8	RxASel:1;
	u8	TxSoundPPDU:1;
	u8	rsv:1;
};

struct GNU_PACKED HT_BF_CAP {

	u32	TxBFRecCapable:1;
	u32	RxSoundCapable:1;
	u32	TxSoundCapable:1;
	u32	RxNDPCapable:1;
	u32	TxNDPCapable:1;
	u32	ImpTxBFCapable:1;
	u32	Calibration:2;
	u32	ExpCSICapable:1;
	u32	ExpNoComSteerCapable:1;
	u32	ExpComSteerCapable:1;
	u32	ExpCSIFbk:2;
	u32	ExpNoComBF:2;
	u32	ExpComBF:2;
	u32	MinGrouping:2;
	u32	CSIBFAntSup:2;
	u32	NoComSteerBFAntSup:2;
	u32	ComSteerBFAntSup:2;
	u32	CSIRowBFSup:2;
	u32	ChanEstimation:2;
	u32	rsv:3;
};


struct GNU_PACKED EXT_HT_CAP_INFO {

	u16	Pco:1;
	u16	TranTime:2;
	u16	rsv:5;/*momi power safe */
	u16	MCSFeedback:2;	/*0:no MCS feedback, 2:unsolicited MCS feedback, 3:Full MCS feedback,  1:rsv. */
	u16	PlusHTC:1;	/*+HTC control field support */
	u16	RDGSupport:1;	/*reverse Direction Grant  support */
	u16	rsv2:4;
};

struct GNU_PACKED HT_CAP_PARM {

	u8	MaxRAmpduFactor:2;
	u8	MpduDensity:3;
	u8	rsv:3;/*momi power safe */
};
struct GNU_PACKED HT_CAP_INFO {

	u16	ht_rx_ldpc:1;
	u16	ChannelWidth:1;
	u16	MimoPs:2;		/* mimo power safe */
	u16	GF:1;			/* green field */
	u16	ShortGIfor20:1;
	u16	ShortGIfor40:1;	/* for40MHz */
	u16	TxSTBC:1;		/* 0:not supported,  1:if supported */
	u16	RxSTBC:2;
	u16	DelayedBA:1;
	u16	AMsduSize:1;	/* only support as zero */
	u16	CCKmodein40:1;
	u16	PSMP:1;
	u16	Forty_Mhz_Intolerant:1;
	u16	LSIGTxopProSup:1;
};

struct GNU_PACKED HT_CAPABILITY_IE {

	struct HT_CAP_INFO		HtCapInfo;
	struct HT_CAP_PARM		HtCapParm;
	/*	HT_MCS_SET		HtMCSSet; */
	unsigned char			MCSSet[16];
	struct EXT_HT_CAP_INFO	ExtHtCapInfo;
	struct HT_BF_CAP		TxBFCap;	/* beamforming cap. */
	struct HT_AS_CAP		ASCap;	/*antenna selection. */
};

struct GNU_PACKED he_txrx_mcs_nss {
	u16 max_rx_mcs_nss;
	u16 max_tx_mcs_nss;
};

struct GNU_PACKED he_phy_capinfo {
	u32 phy_capinfo_1;
	u32 phy_capinfo_2;
	u8 phy_capinfo_3;
	u8 phy_capinfo_4;
	u8 phy_capinfo_5;
};

struct GNU_PACKED he_mac_capinfo {
	u32 mac_capinfo_1;
	u16 mac_capinfo_2;
};

struct GNU_PACKED he_cap_ie {
	struct he_mac_capinfo mac_cap;
	struct he_phy_capinfo phy_cap;
	struct he_txrx_mcs_nss txrx_mcs_nss;
};

struct GNU_PACKED eht_mac_capinfo {
	u16 mac_capinfo;
};

struct GNU_PACKED eht_phy_capinfo {
	u32 phy_capinfo_1;
	u32 phy_capinfo_2;
	u8  phy_capinfo_3;
};

struct GNU_PACKED eht_cap_ie {
	struct eht_mac_capinfo mac_cap;
	struct eht_phy_capinfo phy_cap;
	/* Supported EHT-MCS And NSS Set */
	/* EHT PPE Thresholds (Optional) */
};
struct GNU_PACKED VHT_CAP_INFO {
	u32 max_mpdu_len:2;	/* 0: 3895, 1: 7991, 2: 11454, 3: rsv */
	u32 ch_width:2;	/* */
	u32 rx_ldpc:1;
	u32 sgi_80M:1;
	u32 sgi_160M:1;
	u32 tx_stbc:1;

	u32 rx_stbc:3;
	u32 bfer_cap_su:1;
	u32 bfee_cap_su:1;
	u32 bfee_sts_cap:3;

	u32 num_snd_dimension:3;
	u32 bfer_cap_mu:1;
	u32 bfee_cap_mu:1;
	u32 vht_txop_ps:1;
	u32 htc_vht_cap:1;
	u32 max_ampdu_exp:3;
	u32 vht_link_adapt:2;
	u32 rx_ant_consistency:1;
	u32 tx_ant_consistency:1;
	u32 ex_nss_bw:2;
};

struct GNU_PACKED vht_opinfo {
	u8 ch_width;
	u8 ccfs_0;
	u8 ccfs_1;
};

struct GNU_PACKED VHT_MCS_MAP {
	u16 mcs_ss1:2;
	u16 mcs_ss2:2;
	u16 mcs_ss3:2;
	u16 mcs_ss4:2;
	u16 mcs_ss5:2;
	u16 mcs_ss6:2;
	u16 mcs_ss7:2;
	u16 mcs_ss8:2;
};

struct GNU_PACKED VHT_MCS_SET {

	struct VHT_MCS_MAP rx_mcs_map;

	u16 rx_high_rate:13;
	u16 rsv:3;
	struct VHT_MCS_MAP tx_mcs_map;

	u16 tx_high_rate:13;
	u16 vht_ext_nss_bw_cap:1;
	u16 rsv2:2;
};

struct GNU_PACKED VHT_CAP_IE {
	struct VHT_CAP_INFO vht_cap;
	struct VHT_MCS_SET mcs_set;
};

struct GNU_PACKED VHT_OP_IE {
	struct vht_opinfo vht_op_info;
	struct VHT_MCS_MAP basic_mcs_set;
};

/**
 * struct hostapd_wmm_rule - WMM regulatory rule
 * @min_cwmin: Lower bound of CW_min value
 * @min_cwmax: Lower bound of CW_max value
 * @min_aifs: Lower bound of AIFS value
 * @max_txop: Upper bound of TXOP, value in units of 32 usec
 */
struct wmm_rule {
	int min_cwmin;
	int min_cwmax;
	int min_aifs;
	int max_txop;
};

struct ch_freq_survey {
	unsigned int freq;
	unsigned char ch;
	signed char nf;
	unsigned long long channel_time;
	unsigned long long channel_time_busy;
	unsigned long long channel_time_rx;
	unsigned long long channel_time_tx;
	unsigned long long channel_time_bss_rx;
	unsigned long long channel_time_rx_data;
	unsigned int filled;
};

struct channel_data {
	/**
	 * chan - Channel number (IEEE 802.11)
	 */
	short chan;

	/**
	 * freq - Frequency in MHz
	 */
	int freq;

	/**
	 * flag - Channel flags (CHAN_*)
	 */
	int flag;

	/**
	 * allowed_bw - Allowed channel width bitmask
	 *
	 * See enum hostapd_chan_width_attr.
	 */
	unsigned int allowed_bw;

	/**
	 * max_tx_power - Regulatory transmit power limit in dBm
	 */
	unsigned char max_tx_power;

	/**
	 * survey_list - Linked list of surveys (struct ch_freq_survey)
	 */
	struct ch_freq_survey survey;
	struct ch_freq_survey base_survey;
	/**
	 * scan_res_list - Linked list of scan result (struct scan_res)
	 */
	struct dl_list scan_res_list;

	/**
	 * min_nf - Minimum observed noise floor, in dBm, based on all
	 * surveyed channel data
	 */
	signed char min_nf;
	/**
	 * dfs_cac_ms - DFS CAC time in milliseconds
	 */
	unsigned int dfs_cac_ms;
	/**
	 * dfs_ms - DFS time in milliseconds
	 */
	unsigned int dfs_ms;
	/**
	 * wmm_rules_valid - Indicates wmm_rules state
	 */
	int wmm_rules_valid;
	/**
	 * wmm_rules - WMM regulatory rules
	 */
	struct wmm_rule wmm_rules[4];
};

/**
 * struct he_capabilities - IEEE 802.11ax HE capabilities
 */
struct he_capabilities {
	unsigned char he_supported;
	unsigned char phy_cap[HE_MAX_PHY_CAPAB_SIZE];
	unsigned char mac_cap[HE_MAX_MAC_CAPAB_SIZE];
	unsigned char mcs[HE_MAX_MCS_CAPAB_SIZE];
	unsigned char ppet[HE_MAX_PPET_CAPAB_SIZE];
	unsigned short he_6ghz_capa;
};

/* struct eht_capabilities - IEEE 802.11be EHT capabilities */
struct eht_capabilities {
	bool eht_supported;
	u16 mac_cap;
	u8 phy_cap[EHT_PHY_CAPAB_LEN];
	u8 mcs[EHT_MCS_NSS_CAPAB_LEN];
	u8 ppet[EHT_PPE_THRESH_CAPAB_LEN];
};

struct chan_params {
	u32 center_freq;
	u16 freq_offset;
	enum nl80211_chan_width width;
	u32 center_freq1;
	u32 center_freq2;
};

struct radar_params {
	enum nl80211_radar_event event;
	struct chan_params chan;
};


struct phy_info {
	unsigned char phy_id; /*per band info*/
	/**
	 * mode - Hardware mode
	 */
	unsigned short mode;

	/**
	 * num_channels - Number of entries in the channels array
	 */
	int num_channels;

	/**
	 * channels - Array of supported channels
	 */
	struct channel_data *channels;

	/**
	 * num_rates - Number of entries in the rates array
	 */
	int num_rates;

	/**
	 * rates - Array of supported rates in 100 kbps units
	 */
	int *rates;

	/**
	 * ht_capab - HT (IEEE 802.11n) capabilities
	 */
	unsigned short ht_capab;

	/**
	 * mcs_set - MCS (IEEE 802.11n) rate parameters
	 */
	unsigned char mcs_set[16];

	/**
	 * a_mpdu_params - A-MPDU (IEEE 802.11n) parameters
	 */
	unsigned char a_mpdu_params;
	unsigned char ht_set;
	/**
	 * vht_capab - VHT (IEEE 802.11ac) capabilities
	 */
	unsigned int vht_capab;

	/**
	 * vht_mcs_set - VHT MCS (IEEE 802.11ac) rate parameters
	 */
	unsigned char vht_mcs_set[8];
	unsigned char vht_set;

	unsigned int flags; /* MODE_FLAG_* */

	/**
	 * he_capab - HE (IEEE 802.11ax) capabilities
	 */
	struct he_capabilities he_capab;
	struct eht_capabilities eht_capab;
	unsigned char zero_wait_dfs;
	struct radar_params radar_event;
	struct chan_params ch_event;
	unsigned int bw;
	struct dl_list list;
};
/*used for nl80211 end*/

struct dev_info {
	unsigned char valid;
	unsigned char phy_id;
	unsigned int ifindex;
	char ifname[16];
	enum nl80211_iftype iftype;
	unsigned char ch;
	unsigned int freq;
	unsigned int txpower; /*dbm*/
	unsigned char mac[6];
	unsigned char use_4addr;
	char ssid[32];
	unsigned char ssid_len;
	unsigned char bw;
	unsigned short center1;
	unsigned short center2;
	unsigned char mesh_disable;/*1: means: dev is diasble by mesh feature, shouldn't delete it from dev list*/
	struct dl_list list;
	struct nl_sock *nl_mgmt;
	struct nl_cb *nl_cb;
	u8 get_phy_retry;
};

#define MAX_NL80211_NOISE_FREQS 50

enum eht_nss_mcs_bw {
	EHT_NSS_MCS_20,
	EHT_NSS_MCS_80,
	EHT_NSS_MCS_160,
	EHT_NSS_MCS_320,
	EHT_MCS_NSS_BW_NUM
};

struct GNU_PACKED eht_txrx_mcs_nss_20 {
	uint8_t max_tx_rx_mcs0_7_nss;	/*rx bit 0-3,tx bit 4-7*/
	uint8_t max_tx_rx_mcs8_9_nss;	/*rx bit 08-11,tx bit 12-15*/
	uint8_t max_tx_rx_mcs10_11_nss;	/*rx bit 16-19,tx bit 20-23*/
	uint8_t max_tx_rx_mcs12_13_nss;	/*rx bit 24-27,tx bit 28-31*/
};

struct GNU_PACKED eht_txrx_mcs_nss {
	uint8_t max_tx_rx_mcs0_9_nss;	/*rx bit 0-3,tx bit 4-7*/
	uint8_t max_tx_rx_mcs10_11_nss;	/*rx bit 08-11,tx bit 12-15*/
	uint8_t max_tx_rx_mcs12_13_nss;	/*rx bit 16-19,tx bit 20-23*/
};

struct GNU_PACKED eht_op_info {
	u8 control;
	u8 ccfs0;
	u8 ccfs1;
};

struct GNU_PACKED eht_op_ie {
	u8 op_parameters;
	struct eht_txrx_mcs_nss_20 basic_eht_mcs_nss;
	struct eht_op_info op_info;
};

struct GNU_PACKED eht_support_mcs_nss {
	struct eht_txrx_mcs_nss_20 eht_txrx_mcs_nss_20_only;
	struct eht_txrx_mcs_nss eht_txrx_mcs_nss[EHT_MCS_NSS_BW_NUM - 1];
};

enum vht_config_bw {
	VHT_BW_2040,
	VHT_BW_80,
	VHT_BW_160,
	VHT_BW_8080,
	VHT_BW_320
};

struct GNU_PACKED he_op_params {
	unsigned short param1;
	unsigned char param2;
};

struct GNU_PACKED he_op_ie {
	struct he_op_params he_op_param;
	unsigned char bss_color_info;
	unsigned short he_basic_mcs_nss;
};

struct GNU_PACKED he_6g_op_info {
	unsigned char prim_ch;
	unsigned char ctrl;
	unsigned char ccfs_0;
	unsigned char ccfs_1;
	unsigned char min_rate;
};

struct GNU_PACKED neighbor_ap_info {
	u16 tbtt_info_hdr;
	u8 op_class;
	u8 ch_num;
	u8 tbtt[];
};

struct Scan_data {
	int RNR_PRESENT, MULTI_LINK_PRESENT, HE_CAP_IE_EXISTS, HE_OP_IE_EXISTS;
	int EHT_CAP_IE_EXISTS, EHT_OP_IE_EXISTS, EHT_OP_INFO_EXISTS;
	struct HT_CAPABILITY_IE ht_cap_ie;
	struct ADD_HT_INFO_IE ht_op_ie;
	struct VHT_CAP_IE vht_cap_ie;
	struct VHT_OP_IE vht_op_ie;
	struct he_op_ie he_ops;
	struct he_6g_op_info he_6g_ops;
	struct he_cap_ie he_caps;
	struct eht_support_mcs_nss eht_support_mcs_nss;
	unsigned char op_class;
	struct eht_op_ie eht_op;
	UINT16 dis_subch_bitmap;
	UCHAR dscb_enable;
	struct eht_cap_ie eht_cap_ie;
	struct wdev_eht_cap w_eht_cap;
	u8 txrx_stream;
	uint8_t he_ch_width;
	int he_op_bw;
	uint32_t AKMMap;
	uint32_t PairwiseCipher;	/* Pairwise Key */
	uint32_t GroupCipher;
	bool IsSupportSHA256KeyDerivation;
	unsigned short RsnCapability;
	unsigned char rsnxe_content[MAX_LEN_OF_RSNXEIE];
	unsigned char rsnxe_len;
	unsigned char Privacy;
};


#endif


#endif /* __DRIVER_NL80211_H__ */

