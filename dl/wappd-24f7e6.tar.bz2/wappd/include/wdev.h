/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#ifndef _WDEV_H_
#define _WDEV_H_

#include <stdint.h>
//##include <if.h>
#include "types.h"
#include "list.h"
#include "wapp_cmm.h"
#ifdef MAP_R2
#include "off_ch_scan.h"
#endif
#ifndef MAC_ADDR_LEN
#define MAC_ADDR_LEN	6
#endif
#ifndef MTK_MLO_MAP_SUPPORT
#define CLIENT_TABLE_SIZE 256
#else
#define CLIENT_TABLE_SIZE 1024
#endif
#define MAX_BEACON_REPORT_LEN 1024
#define SUPPLICANT_NETWORK_ID_DEFAULT 255

#define RRM_BCN_MESURE_REPORT_TAG		39
#define RRM_BCN_MESURE_REPORT_TYPE		5

#define SUPPLICANT_NETWORK_ID_DEFAULT	255
#define MAX_SIZE_UCI_VALUE 64

#define APCLI_CONFIG_KEY_LENGTH 64

#ifdef MAP_6E_SUPPORT
#define WMODE_CAP_6G(_x)        (((_x) & (WMODE_AX_6G)) != 0)
#define WMODE_CAP_5G(_x)        (((_x) & (WMODE_A | WMODE_AN | WMODE_AC | WMODE_AX_5G)) != 0)
#define WMODE_CAP_2G(_x)        (((_x) & (WMODE_B | WMODE_G | WMODE_GN | WMODE_AX_24G)) != 0)
#endif

struct wifi_app;
#ifdef MAP_R3
struct dpp_authentication;
#endif
// TODO: alighn with driver
typedef enum {
	WAPP_DEV_TYPE_AP = 1,
	WAPP_DEV_TYPE_STA,
	WAPP_DEV_TYPE_APCLI = 128,
	WAPP_DEV_UNEXP,
} WAPP_DEV_TYPE;

struct sec_info {
	char auth[32];
	char encryp[32];
	char psphr[256];
};

struct GNU_PACKED eht_mcs_nss_map {
	unsigned char max_tx_rx_mcs0_7_nss;	/*rx bit 0-3,tx bit 4-7*/
	unsigned char max_tx_rx_mcs8_9_nss;	/*rx bit 08-11,tx bit 12-15*/
	unsigned char max_tx_rx_mcs10_11_nss;	/*rx bit 16-19,tx bit 20-23*/
	unsigned char max_tx_rx_mcs12_13_nss;	/*rx bit 24-27,tx bit 28-31*/
};

struct GNU_PACKED eht_operations_info {
	unsigned char ruid[MAC_ADDR_LEN];
	unsigned char bssid[MAC_ADDR_LEN];
	unsigned char eht_operation_information_valid;
	unsigned char eht_default_pe_duration;
	unsigned char group_addressed_BU_indication_limit;
	unsigned char group_addressed_BU_indication_exponent;
	struct eht_mcs_nss_map eht_mcs_nss_set;
	unsigned char control;
	unsigned char ccfs0;
	unsigned char ccfs1;
	unsigned short dscb_bitmap;
};
#ifdef STANDARD_NL_CMD
struct GNU_PACKED scan_active_time {
	u8 ch_count;
	u8 ch_num[MAX_NUM_OF_CHANNELS];
	u64 ch_active_time[MAX_NUM_OF_CHANNELS];
};
#endif
struct wapp_dev {
	struct	dl_list list;
	const	struct wdev_ops *ops;
	struct sec_info sec;
	void	*p_dev;
	u32		ifindex;
	u8		mac_addr[MAC_ADDR_LEN];
	char	ifname[IFNAMSIZ];
	u8		dev_type;
	u16		wireless_mode; /* ex: a/b/g/n/ac */
	struct wapp_radio *radio;
#ifdef MAP_SUPPORT
	u8		i_am_fh_bss;   /* from map_vendor_extension in wsc_config */
	u8		i_am_bh_bss;
#if defined(HOSTAPD_MAP_SUPPORT) || defined(MTK_HOSTAPD_SUPPORT)
	unsigned char bh_profile_id;
	BOOLEAN i_need_hostapd_reload;
#endif /* HOSTAPD_MAP_SUPPORT || MTK_HOSTAPD_SUPPORT */
	BOOLEAN cli_info_trigger;
	struct os_time cli_list_last_update_time;
#endif /* MAP_SUPPORT */
	int scan_cookie;
	struct wapp_wsc_scan_info wsc_scan_info;
	BOOLEAN wps_triggered;
	unsigned char bh_connect_priority;
	int arp_sock;
	u8 valid;
#ifdef KV_API_SUPPORT
	BOOLEAN rrm_enable;
	BOOLEAN wnm_enbale;
#endif /* KV_API_SUPPORT */
#ifdef MAP_R2
	u32		cac_not_required;
	u8		cac_method;
	u8		synA;
	u8		synB;
#endif
	BOOLEAN wapp_triggered_scan;
#ifdef DPP_SUPPORT
       struct dpp_config *config;
       UCHAR connection_tries;
#endif /* CONFIG_DPP */
#ifdef MAP_R3
	BOOLEAN is_configured;
	BOOLEAN waiting_cce_scan_res;
	BOOLEAN scan_done_ind;
        struct dpp_config *config2;
	struct os_time last_sr_time;
#endif /* MAP_R3 */
	int network_id;
	struct wifi_app *wapp;
#ifdef MTK_HOSTAPD_SUPPORT
	u32 bss_coex_buffer;
#endif
#ifdef MTK_MLO_MAP_SUPPORT
	u8 bh_mld_mac[MAC_ADDR_LEN];
#ifdef MAP_R6
	u8 bh_apcli_mld_mac[MAC_ADDR_LEN];
	u8 bh_apcli_bss_mld_mac[MAC_ADDR_LEN];
	u8 str_en_dis;
	u8 nstr_en_dis;
	u8 emlsr_en_dis;
	u8 emlmr_en_dis;
	u8 apcli_mlo_enable;
	u8 counter;
#endif /* MAP_R6 */
#endif /* MTK_MLO_MAP_SUPPORT */
	u8 mld_configured;
	u8 mld_id;
	u8 mld_id_renew;
	u8 mld_type_renew;
	u8 mld_addr_renew[MAC_ADDR_LEN];
#ifdef MAP_R6
	u8 mld_addr_before_del[MAC_ADDR_LEN];
	u8 mld_id_before_del;
#endif /* MAP_R6 */
#ifdef MAP_R6
	u8 mld_affltd_ap_in_renew;
	u8 mld_affltd_ap_in_add_renew;
	u8 ap_mld_num_aff_ap;
	int mld_del_link_state;
#endif
	struct eht_operations_info eht_oper_bitmap_info;
#if defined(MAP_R6) && defined(MTK_HOSTAPD_SUPPORT)
	unsigned char	pmk[66];
#endif
#ifdef COSR_SUPPORT
	u8 wdev_cosr_support;
	u8 cosr_support_mode;
#endif /* COSR_SUPPORT */
	u8 is_auth_open;
	u8 is_auth_owe;
	u8 is_auth_owe_transtn;
	u8 is_used_in_owe_transtn;
#ifdef STANDARD_NL_CMD
	struct dev_info *dev;
	struct phy_info *phy;
	struct scan_active_time active_time;
#endif
#ifdef MAP_EHT_SUPPORT
	u8 HE_EXTCHA;
#endif
#ifdef EM_PLUS_SUPPORT
	u8 AT_mld_configured;
	u8 AT_mlo_add_needed;
	u8 AT_mlo_grp_not_del;
#endif
	u8 cu;
};

struct GNU_PACKED wapp_block_sta {
	u8 mac_addr[MAC_ADDR_LEN];
	u16 valid_period;
};

#define BLOCK_LIST_NUM      128
#define MAX_COSR_STA_COUNT 8


struct GNU_PACKED ap_dev {
	/*struct wireless_client *client_table;*/
	u16				num_of_clients; //valid client number in client_table
	u16				num_of_assoc_cli;  //associated client number in client_table
	u8				max_num_of_cli;  // driver supported max number of client
	u8				max_num_of_bss;
	u8				num_of_bss;
	u8				max_num_of_block_cli;
	u8				num_of_block_cli;
	u8				rssi;	// from air monitor
	u8				isActive;
#ifdef MAP_R6
	u8				is_ap_mld_reconf;
	u8				ap_mld_ra_id_check;
#endif /* MAP_R6 */
	wdev_ht_cap		ht_cap;
	wdev_vht_cap	vht_cap;
	wdev_bss_info	bss_info;
	wdev_chn_info	ch_info;
#ifndef MAP_6E_SUPPORT
	wdev_op_class_info	op_class;
#else
	struct _wdev_op_class_info_ext op_class;
#endif
	wdev_ap_metric		ap_metrics;
	wdev_tx_power		pwr;
	wdev_steer_sta		str_sta;
	wapp_bssload_info	bssload;
	wapp_mnt_info 		mnt;
	struct wapp_sta		**client_table;
	struct wapp_block_sta	block_table[BLOCK_LIST_NUM];
	wdev_he_cap	he_cap;
#ifdef MAP_R2
	wdev_extended_ap_metric ext_ap_metrics;
#endif
	u8				num_of_acl_cli;
#ifdef MAP_R3_WF6
	wdev_wf6_cap_roles wf6_cap;
#endif /*MAP_R3_WF6*/
#ifdef MAP_R4_SPT
	// spatial reuse structure
	struct wapp_mesh_sr_info sr_info;
	struct ap_spt_reuse_req spt_reuse;
#endif
#if defined(MAP_R6) || defined(EM_PLUS_SUPPORT)
	struct wdev_wifi7_mlo_caps wifi7_mlo_cap;
#endif
#ifdef MAP_EHT_SUPPORT
	struct wdev_eht_cap	eht_cap;
#endif
#ifdef MTK_MLO_MAP_SUPPORT
	struct wdev_mlo_caps mlo_cap;
	struct  _wdev_mlo_info mlo_info;
#endif

#ifdef COSR_SUPPORT
	struct wapp_sta		*candlist_sta[MAX_COSR_STA_COUNT];
	u8			max_num_of_candlist_sta;
	u8			cosr_sta_id_bitmap;
#endif /*COSR_SUPPORT*/
	struct _wdev_tx_power_ext tx_pwr_ext;
};

#ifdef STANDARD_NL_CMD
enum {
	VHT_MCS_CAP_7,
	VHT_MCS_CAP_8,
	VHT_MCS_CAP_9,
	VHT_MCS_CAP_NA
};

struct vht_mcs_map {
	unsigned short mcs_ss1:2;
	unsigned short mcs_ss2:2;
	unsigned short mcs_ss3:2;
	unsigned short mcs_ss4:2;
	unsigned short mcs_ss5:2;
	unsigned short mcs_ss6:2;
	unsigned short mcs_ss7:2;
	unsigned short mcs_ss8:2;
};
#endif

int wapp_uci_update(char *config_name, char *option, char *value);
int wapp_uci_get_param(char *config_name, char *option, char *value);
struct wdev_ops {
	int (*wdev_del)(struct wifi_app	*wapp, struct wapp_dev	*wdev);
};
#ifdef MAP_RADIO_TEARDOWN
int wapp_dev_del(
	struct wifi_app	*wapp,
	struct wapp_dev	*wdev,
	const u8 *mac_addr,
	const u32 wdev_type);
#endif

struct wapp_dev* wapp_dev_list_lookup_by_mac_and_type(
	struct wifi_app *wapp,
	const u8 *mac_addr,
	const u8 wdev_type);

#ifdef MAP_R6
struct wapp_dev *wapp_dev_list_lookup_by_mld_link_id(struct wifi_app *wapp, const u8 link_id);
struct wapp_dev *wapp_dev_list_lookup_by_ruid(struct wifi_app *wapp, const u8 *ruid,
				const u8 *byssid, u8 ssidlen);
#endif /* MAP_R6 */
struct wapp_dev* wapp_dev_list_lookup_by_ifindex(
	struct wifi_app *wapp,
	const u32 ifindex);

struct wapp_dev* wapp_dev_list_lookup_by_ifname(
	struct wifi_app *wapp,
	const char *ifname);

struct wapp_dev* wapp_dev_list_lookup_by_radio(
	struct wifi_app *wapp,
	char* ra_identifier);
struct wapp_dev *wapp_bh_dev_list_lookup_by_radio(
	struct wifi_app *wapp,
	char *ra_identifier);
struct wapp_dev * wapp_dev_list_lookup_by_radio_for_sta(
	struct wifi_app *wapp,
	char *ra_identifier);

#ifdef MAP_R6
int wapp_wps_mlo_switch(
			struct wifi_app *wapp,
			struct mld_bsta_config *config);
int wapp_dpp_disable_mlo_switch(
				struct wifi_app *wapp,
				struct dpp_authentication *auth);
#endif

struct wapp_dev *wapp_ap_dev_list_lookup_by_sta_intf(
	struct wifi_app *wapp,
	struct wapp_dev *sta_wdev);

int wapp_dev_create(
	struct wifi_app *wapp,
	char 			*iface,
	u32				if_idx,
	u8				*mac_addr);

#ifdef STANDARD_NL_CMD
int wdev_ap_create_sd_nl(
	struct wifi_app *wapp,
	struct dev_info	*dev,
	struct phy_info	*phy);

int wdev_sta_create_sd_nl(
	struct wifi_app *wapp,
	struct dev_info	*dev,
	struct phy_info	*phy);
#endif

int wdev_ap_create(
	struct wifi_app *wapp,
	wapp_dev_info	*dev_info);

int wdev_sta_create(
	struct wifi_app *wapp,
	wapp_dev_info	*dev_info);

int wdev_ap_client_table_create(
	struct wifi_app *wapp,
	struct ap_dev	*ap);

int wdev_ap_client_table_release(
	struct wifi_app *wapp,
	struct ap_dev	*ap);

int wapp_client_create(
	struct wifi_app *wapp,
	struct ap_dev	*ap,
	struct wapp_sta **new_sta);

void wapp_fill_client_info(
	struct wifi_app *wapp,
	wapp_client_info *cli_info,
	struct wapp_sta *sta);

int wdev_show_wapp_sta_info(
	struct wapp_sta *cli);

struct wapp_sta*  wdev_ap_client_list_lookup_for_all_bss(
	struct wifi_app *wapp,
	const u8 *mac_addr);

#ifdef MAP_R3
struct wapp_dev*  wdev_sta_lookup_for_all_bss(
	struct wifi_app *wapp,
	const u8 *mac_addr);
#endif /* MAP_R3 */
struct wapp_dev *wdev_sta_lookup_for_all_bss_cosr(
	struct wifi_app *wapp,
	const u8 *mac_addr);

struct wapp_sta*  wdev_ap_client_list_lookup(
	struct wifi_app *wapp,
	struct ap_dev *ap,
	const u8 *mac_addr);

struct wapp_block_sta* wdev_ap_block_list_lookup(
	struct wifi_app *wapp,
	struct ap_dev *ap,
	u8 *mac_addr);

int wapp_del_block_sta(
	struct ap_dev *ap,
	unsigned char *sta_addr);

int wapp_update_block_list(
	struct wifi_app *wapp,
	struct wapp_dev *wdev,
	struct ap_dev *ap);

int wapp_add_block_sta(
	struct wifi_app *wapp,
	struct ap_dev *ap,
	u8 *sta_addr,
	u16 valid_period);

int wdev_ap_block_list_init(
	struct wifi_app *wapp,
	struct ap_dev *ap);

int wdev_ap_show_block_list(
	struct wifi_app *wapp,
	struct ap_dev *ap);

int wdev_ap_show_cli_list(
	struct wifi_app *wapp,
	struct ap_dev *ap);

void wdev_apcli_show_info(
	struct wifi_app *wapp,
	struct wapp_sta *sta);

int wdev_ap_show_chn_list(
	struct wifi_app *wapp,
	struct ap_dev *ap);

int wdev_ap_show_bss_info(
	struct wifi_app *wapp,
	struct ap_dev *ap);

int wdev_ap_show_ap_metric(struct wifi_app *wapp, char *buf, size_t max_len);

#ifdef MAP_R3
int wdev_set_dpp_cred(
	struct wifi_app *wapp,
	struct wapp_dev *wdev,
	struct wireless_setting* psetting,
	int primary_cred);
#endif /* MAP_R3 */

int wdev_set_sec_and_ssid(
	struct wifi_app *wapp,
	struct wapp_dev	*wdev,
	struct sec_info *sec,
	char *ssid);

int wdev_set_sec_and_ssid2(
	struct wifi_app *wapp,
	struct wapp_dev *wdev,
	struct sec_info *sec,
	char *ssid);

int wapp_issue_scan_request(
	struct wifi_app *wapp,
	struct wapp_dev	*wdev);

#ifdef MAP_6E_SUPPORT
int wdev_set_ch(
	struct wifi_app *wapp,
	struct wapp_dev *wdev,
	int ch,
	unsigned char op_class,
	u32 bw,
	unsigned char op_report);
#else
int wdev_set_ch(
	struct wifi_app *wapp,
	struct wapp_dev *wdev,
	int ch,
	unsigned char op_class);
#endif


int wdev_set_quick_ch(
	struct wifi_app *wapp,
	struct wapp_dev	*wdev,
	int ch);

int wdev_set_ssid(
	struct wifi_app *wapp,
	struct wapp_dev *wdev,
	char *ssid);

int wdev_set_psk(
	struct wifi_app *wapp,
	struct wapp_dev	*wdev,
	char *psk);

#if 0
/* Already defined in map_1905.h */
int wdev_send_add_network(
	struct wifi_app *wapp,
	struct wapp_dev *wdev);

int wdev_send_network_key(
	struct wifi_app *wapp,
	struct wapp_dev *wdev,
	const char *key);

int wdev_send_network_keymgmt(
	struct wifi_app *wapp,
	struct wapp_dev *wdev,
	const char *keymgmt);

int wdev_send_sae_pwd(
	struct wifi_app *wapp,
	struct wapp_dev *wdev,
	const char *pwd);

int wdev_send_wep_key(
	struct wifi_app *wapp,
	struct wapp_dev *wdev,
	int key_idx,
	const char *key);

int wdev_send_save_config(
	struct wifi_app *wapp,
	struct wapp_dev *wdev);

int wdev_set_scan_ssid(struct wifi_app *wapp,
	struct wapp_dev *wdev,
	int enable);
#endif

int wdev_enable_pmf(
	struct wifi_app *wapp,
	struct wapp_dev	*wdev,
	BOOLEAN enable);

#ifdef DPP_SUPPORT
enum dpp_akm;

int wdev_set_dpp_akm(
	struct wifi_app *wapp,
	struct wapp_dev	*wdev,
	enum dpp_akm akm);

int wdev_enable_apcli_iface(
	struct wifi_app *wapp,
	struct wapp_dev	*wdev,
	int enable);
#endif /*DPP_SUPPORT*/

int wdev_set_radio_onoff(
	struct wifi_app *wapp,
	struct wapp_dev	*wdev,
	int onoff);

int wdev_ap_show_ap_info(
	struct wifi_app *wapp,
	struct wapp_dev *wdev,
	struct ap_dev	*ap);


int wdev_ap_set_txpwr_limit(
	struct wifi_app *wapp,
	struct wapp_dev	*wdev,
	char pwr_limit,
	unsigned char op_class);

void wapp_show_dev_list(
	struct wifi_app *wapp);

int wapp_client_clear(
	struct wifi_app *wapp,
	struct ap_dev	*ap,
	u8 *mac_addr);

int wdev_set_bss_role(
	struct wifi_app *wapp,
	struct wapp_dev *wdev,
	unsigned char map_vendor_extension);

int wdev_set_hidden_ssid(
	struct wifi_app *wapp,
	struct wapp_dev *wdev,
	unsigned char hidden_ssid);
int wdev_set_bss_coex(
	struct wifi_app *wapp,
	struct wapp_dev *wdev,
	char enable);

int wdev_set_map_channel(
	struct wifi_app *wapp,
	struct wapp_dev *wdev,
	const u8 ch
#ifdef MAP_R2
	, const u8 cac_req,
	const u8 dev_role
#endif /* MAP_R2 */
	);

int wdev_set_static_punc_dscb(
	struct wifi_app *wapp,
	struct wapp_dev *wdev,
	const u16 puncture_dscb);

#ifdef CSA_BAND_SUPPORT
int wdev_set_static_2g_csa_support(
	struct wifi_app *wapp,
	struct wapp_dev *wdev,
	const u8 csa_2g_support);

int wdev_set_static_csa_support(
	struct wifi_app *wapp,
	struct wapp_dev *wdev,
	const u8 csa_5g_support);
#endif

int wdev_set_map_enable(
	struct wifi_app *wapp,
	struct wapp_dev *wdev,
	const u8 map_en);

#ifdef MAP_R6
int wdev_set_mlo_switch(
	struct wifi_app *wapp,
	struct wapp_dev *wdev,
	const u8 mlo_switch);
#endif

int wdev_set_ap_fhbss(
	struct wifi_app *wapp,
	struct wapp_dev *wdev,
	const u8 fh_en);

int wdev_set_ap_bhbss(
	struct wifi_app *wapp,
	struct wapp_dev *wdev,
	const u8 bh_en);

int wdev_set_v10converter(
	struct wifi_app *wapp,
	struct wapp_dev *wdev,
	const u8 v_en);

int wdev_set_approxyrefresh(
	struct wifi_app *wapp,
	struct wapp_dev *wdev,
	const u8 proxy_en);

int driver_wext_get_bss_coex(void *drv_data,
	const char *ifname, char *bss_coex);
#ifdef DPP_SUPPORT
struct wapp_dev* wapp_dev_list_lookup_by_radio_and_type(struct wifi_app *wapp, char* ra_identifier, const u8 wdev_type);
int driver_wext_get_dpp_frame(void *drv_data, const char *ifname, char *frame, size_t length);
char * wdev_get_dpp_driver_auth_type(enum dpp_akm akm);
#ifdef MTK_HOSTAPD_SUPPORT
char *wdev_get_dpp_supp_auth_type(enum dpp_akm akm);
#endif /* MTK_HOSTAPD_SUPPORT */
#endif /*DPP_SUPPORT*/
#ifdef MAP_R3
u16 wdev_get_dpp_driver_auth_type_wsc(enum dpp_akm akm);
#endif /* MAP_R3 */

void wdev_bh_sta_reset_default(struct wifi_app *wapp, struct wapp_dev *wdev);

int driver_wext_get_assoc_req_frame(void *drv_data,
	const char *ifname, char *assoc_data, int length);
void wdev_handle_nop_channels(struct nop_channel_list_s *nop_channels);
int wapp_get_nop_channels(struct wifi_app *wapp, const char *iface, char *buf,
		size_t buf_len);

#ifdef MAP_R2
void map_build_and_send_ch_scan_rep(struct wifi_app *wapp);
void ts_bh_set_default_8021q(struct wifi_app *wapp, struct wapp_dev *wdev, unsigned short primary_vid, unsigned char pcp);
void ts_bh_set_all_vid(struct wifi_app *wapp, struct wapp_dev *wdev, unsigned char vlan_num, unsigned short vids[]);
void ts_fh_set_vid(struct wifi_app *wapp, struct wapp_dev *wdev, unsigned short vid);
extern struct global_oper_class oper_class[];
#ifdef DFS_CAC_R2
int driver_wext_get_cac_capability(void *drv_data, const char *ifname, char *buf, size_t length);
int driver_wext_get_avail_channel(void *drv_data, const char *ifname, char *buf, size_t length);

#endif
void wapp_set_mbo_allow_disallow(struct wifi_app *wapp);
int driver_wext_set_sp_rule(void *drv_data, const char *ifname, char *buf, unsigned int length);
int driver_wext_set_dscp_tbl(void *drv_data, const char *ifname, char *buf, unsigned int length);
void wdev_bh_sta_connect_wsc_profile(struct wifi_app *wapp, struct wapp_dev *wdev, wsc_apcli_config *cli_conf);

#endif

void wapp_hapd_bcn_report_handle(struct wifi_app *wapp, const char *ifname,
				u8 *sta_addr, u8 token,
				u8 report_mode, u8 *bcn_rpt, u16 bcn_rpt_len);
void wapp_hapd_bcn_report_complete_handle(struct wifi_app *wapp, const char *ifname,
				u8 *sta_addr, u8 token,
				u8 report_mode);
void wapp_hapd_wps_dpp_uri_handle(struct wifi_app *wapp, const char *ifname,
				u8 *enrollee_stamac, u8 *dpp_uri, size_t dpp_uri_len);
void wapp_supp_wps_cred_handle(struct wifi_app *wapp, const char *ifname,
				u8 *wps_ced, size_t wps_cred_len);
void wapp_supp_reconfig_fail_handle(struct wifi_app *wapp, const char *ifname);
#ifdef MTK_TK_HOSTAPD_SUPPORT
void wapp_event_eapol_complete(struct wifi_app *wapp, const char *ifname,
				const u8 *addr, u8 multi_ap_ext);
#endif /* MTK_TK_HOSTAPD_SUPPORT */


#ifdef WPS_UNCONFIG_FEATURE_SUPPORT
void wapp_ap_wps_cred_handle(struct wifi_app *wapp, const char *ifname,
				u8 *wps_ced, size_t wps_cred_len);
#endif
int wdev_ap_wpactrl_init(struct wifi_app *wapp);
void wdev_ap_wpactrl_deinit(struct wifi_app *wapp);
int wdev_sta_wpactrl_init(struct wifi_app *wapp);
void wdev_sta_wpactrl_deinit(struct wifi_app *wapp);
#ifdef STANDARD_NL_CMD
/*standard interface*/
void assign_wdev_ht_cap(struct wifi_app *wapp, struct dev_info *dev, struct phy_info *phy);
void assign_wdev_vht_cap(struct wifi_app *wapp, struct dev_info *dev, struct phy_info *phy);
void assign_wdev_he_cap(struct wifi_app *wapp, struct dev_info *dev, struct phy_info *phy);
#ifdef MAP_R3_WF6
void assign_wdev_wf6_cap(struct wifi_app *wapp, struct dev_info *dev, struct phy_info *phy);
#endif
void assign_wdev_bss_info(struct wifi_app *wapp, struct dev_info *dev, struct phy_info *phy);
unsigned char get_40bw_by_freq(unsigned int freq, unsigned int cent_freq);
unsigned char get_band_by_mode(unsigned char mode);
unsigned char get_opclass_by_band_bw_ch(unsigned char band, unsigned char bw, unsigned char ch);
unsigned char check_primary_ch_in_gl_op(unsigned char ch);
int dump_chan_list(struct wifi_app *wapp, char *buf, size_t max_len);
void assign_wdev_chan_list(struct wifi_app *wapp, struct dev_info *dev, struct phy_info *phy);
void assign_wdev_op_class(struct wifi_app *wapp, struct dev_info *dev, struct phy_info *phy);
unsigned char find_opclass_by_ch_bw(unsigned short chan, unsigned char bw, unsigned short *new_chan);
struct opclass *get_opclass_item(unsigned char opclass);
int dump_opclass(struct wifi_app *wapp, char *buf, size_t max_len);

void wapp_event_intf_notify(struct wifi_app *wapp, struct dev_info *dev, char action);
void wapp_event_new_intf_notify(struct wifi_app *wapp, struct dev_info *dev);
void wapp_event_delete_intf_notify(struct wifi_app *wapp, struct dev_info *dev);
#endif /* STANDARD_NL_CMD */
#endif /* #ifndef _WDEV_H_ */
