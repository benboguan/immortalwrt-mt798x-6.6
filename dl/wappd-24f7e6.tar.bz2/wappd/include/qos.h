/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2020-2021  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#ifndef _QOS_H_
#define _QOS_H_




#ifndef GNU_PACKED
#define GNU_PACKED  __attribute__ ((packed))
#endif /* GNU_PACKED */

#define QOS_NETLINK_EXT 27
#define MAX_MSCS_CFG_CNT 32
#define MAX_EXCEPT_CNT	21
#define MAX_SCS_CFG_CNT 32
#define _802_11_HEADER 24

#define MAX_FILTER_LEN	32

/*Action Frame Category*/
#define CATEGORY_QOS			1
#define CATEGORY_RAVS                   19
#define CATEGORY_EHT_PROT_ACT           37
#ifdef QOS_R2
#define CATEGORY_VEND_SPECIFIC_PROTECTED	0x7E
#define CATEGORY_VEND_SPECIFIC				0x7F
#endif

/*Action Frame Action field*/
#ifdef QOS_R2
#define ACT_SCS_REQ	0
#define ACT_SCS_RSP	1
#endif
#define ACT_MSCS_REQ	4
#define ACT_MSCS_RSP	5

#define ACT_QOSMAP_CONFIG	4

#ifdef QOS_R2
#define IE_TCLAS_ELEMENT_ID		14  /*0x0e*/
#define IE_TCLAS_PROCESSING_ID		44  /*0x2c*/
#define IE_INTRA_ACCESS_CATE_PRI_ID	184 /*0xb8*/
#define IE_SCS_DESCRIPTOR_ELEMENT_ID	185 /*0xb9*/
#ifdef QOS_R3
#define IE_QOS_CHARACTERISTICS_ID	113 /*0x71*/
#define MIN_QOS_CHARACTERISTICS_IE_LEN	19
#define MAX_QOS_CHARACTERISTICS_IE_LEN	39
#endif
#define QOS_MGMT_ELEMENT_ID	0xDD
#define MAX_TCLAS_NUM		5
#define MAX_DOMAIN_NAME_LEN	64
#define MAX_POLICY_NUM		10

/*Attribute ID*/
#define ATTR_ID_PORT_RANGE	1
#define ATTR_ID_DSCP_POLICY	2
#define ATTR_ID_TCLAS		3
#define ATTR_ID_DOMAIN_NAME	4

/*OUI Type*/
#define QOS_ACT_FRM_OUI_TYPE	0x1A
#define QOS_MGMT_IE_OUI_TYPE	0x22

/*OUI Subtype*/
#define DSCP_POLICY_QRY		0
#define DSCP_POLICY_REQ		1
#define DSCP_POLICY_RSP		2

#endif

#ifdef MAP_R5
/*QoS Management Descriptor TLV*/
#define QOS_MGMT_DESCRIPTOR_TLV 0xDC

#define MAX_DESCRIPTOR_LEN	512
#define MAX_NUM_DISALLOWED	5
#endif
#define DSCP_TBL_SIZE		64

#define IE_EXTENSION_ID_MSCS_DESC	88
#define IE_EXTENSION_ID_TCLAS_MASK	89
#define IE_WLAN_EXTENSION 255

#define TYPE4_CS_MASK_VERSION	 1   /*(1 << 0)*/
#define	TYPE4_CS_MASK_SRC_IP	 2   /*(1 << 1)*/
#define	TYPE4_CS_MASK_DST_IP	 4   /*(1 << 2)*/
#define	TYPE4_CS_MASK_SRC_PORT	 8   /*(1 << 3)*/
#define	TYPE4_CS_MASK_DST_PORT	 16  /*(1 << 4)*/
#define	TYPE4_CS_MASK_DSCP	 32  /*(1 << 5)*/
#define	TYPE4_CS_MASK_PROTOCOL	 64  /*(1 << 6)*/
#define	TYPE4_CS_MASK_NXT_HEAD	 64  /*(1 << 6)*/
#define	TYPE4_CS_MASK_FLOW_LABEL 128 /*(1 << 7)*/

/* extension mask for ip tuple*/
#define	CS_MASK_STA_MAC_ADDRESS 256 /*(1 << 8)*/
#define	CS_MASK_QOS_INDEX	512 /*(1 << 9)*/
#define	CS_MASK_QOS_UP	1024 /*(1 << 10)*/

#define QCHAR_MASK_DIR			1   /*(1 << 0)*/
#define	QCHAR_MASK_MIN_INTERVAL		2   /*(1 << 1)*/
#define	QCHAR_MASK_MAX_INTERVAL		4   /*(1 << 2)*/
#define	QCHAR_MASK_MIN_DATA_RATE	8   /*(1 << 3)*/
#define	QCHAR_MASK_DELAY_BOUND		16  /*(1 << 4)*/

enum {
	NL_SET_MSCS_CONFIG = 1,
	NL_SET_QOS_MAP,
	NL_SET_VEND_SPECIFIC_CONFIG,
	NL_VEND_SPECIFIC_CONFIG_EXPIRED,
	NL_RESET_QOS_CONFIG,
	NL_SET_SCS_CONFIG,
	NL_MAP_SET_MSCS_CONFIG,
	NL_MAP_SET_SCS_CONFIG,
	NL_MAP_UPDATE_DEV_INFO,
	NL_MAP_SET_DEV_ROLE,
	NL_SET_IP_TUPLE,
	NL_SET_BSS_PRIORITY,
	NL_SET_CLIENT_PRIORITY,
	NL_IP_TUPLE_EXPIRED_EVENT,
};

enum MSCS_STATUS_CODE {
	STA_SUCCESS = 0,
	STA_REQUEST_DECLINED = 37,
	STA_INSUFFICIENT_RESOURCES = 57,
	STA_REQUESTED_NOT_SUPPORTED = 80,
	STA_RESOURCES_EXHAUSTED = 81,
	STA_TERMINATED = 97,
	STA_TERMINATED_INSUFFICIENT_QOS = 128,
	STA_TERMINATED_POLICY_CONFLICT = 129,
};

enum {
	REQUEST_TYPE_ADD = 0,
	REQUEST_TYPE_REMOVE = 1,
	REQUEST_TYPE_CHANGE = 2,
	REQUEST_TYPE_UNKNOWN
};

enum {
	CLASSIFIER_TYPE0 = 0,
	CLASSIFIER_TYPE1 = 1,
	CLASSIFIER_TYPE2 = 2,
	CLASSIFIER_TYPE3 = 3,
	CLASSIFIER_TYPE4 = 4,
	CLASSIFIER_TYPE5 = 5,
	CLASSIFIER_TYPE10 = 10,
};

enum {
	UP_0 = 0,
	UP_1,
	UP_2,
	UP_3,
	UP_4,
	UP_5,
	UP_6,
	UP_7,
	UP_MAX
};

enum {
	VER_IPV4 = 4,
	VER_IPV6 = 6,
};

enum {
	QOS_INDEX_VOICE = 0,
	QOS_INDEX_GAME,
	QOS_INDEX_VR,
	QOS_INDEX_WFH_VIDEO,
	QOS_INDEX_IPTV,
	QOS_INDEX_VIDEO,
	QOS_INDEX_BROWSE,
	QOS_INDEX_DOWNLOAD,
	QOS_INDEX_MAX
};

enum {
	IP_TYPE_ICMP = 1,
	IP_TYPE_IGMP = 2,
	IP_TYPE_TCP = 6,
	IP_TYPE_UDP = 17,
	IP_TYPE_ESP = 50,
	IP_TYPE_IGRP = 88,
	IP_TYPE_OSPF = 89,
	IP_TYPE_UNKNOWN = 0xFF
};

enum {
	DIR_UPLINK = 0,
	DIR_DIRECTLINK = 1,
	DIR_DOWNLINK = 2,
	DIR_UNKNOWN,
};

enum {
	BD_24G = 1,
	BD_5GL,
	BD_5GH,
};

typedef enum _RT_802_11_PHY_MODE {
	PHY_11BG_MIXED = 0,
	PHY_11B = 1,
	PHY_11A = 2,
	PHY_11ABG_MIXED = 3,
	PHY_11G = 4,
	PHY_11ABGN_MIXED = 5,	/* both band   5 */
	PHY_11N_2_4G = 6,		/* 11n-only with 2.4G band      6 */
	PHY_11GN_MIXED = 7,		/* 2.4G band      7 */
	PHY_11AN_MIXED = 8,		/* 5G  band       8 */
	PHY_11BGN_MIXED = 9,	/* if check 802.11b.      9 */
	PHY_11AGN_MIXED = 10,	/* if check 802.11b.      10 */
	PHY_11N_5G = 11,		/* 11n-only with 5G band                11 */
	PHY_11VHT_N_ABG_MIXED = 12, /* 12 -> AC/A/AN/B/G/GN mixed */
	PHY_11VHT_N_AG_MIXED = 13, /* 13 -> AC/A/AN/G/GN mixed  */
	PHY_11VHT_N_A_MIXED = 14, /* 14 -> AC/AN/A mixed in 5G band */
	PHY_11VHT_N_MIXED = 15, /* 15 -> AC/AN mixed in 5G band */
	PHY_11AX_24G = 16,
	PHY_11AX_5G = 17,
	PHY_11AX_6G = 18,
	PHY_11AX_24G_6G = 19,
	PHY_11AX_5G_6G = 20,
	PHY_11AX_24G_5G_6G = 21,
	PHY_MODE_MAX,
} RT_802_11_PHY_MODE;

enum RETURN_STATUS_CODE {
	STATUS_SUCCESS = 0,
	STATUS_INVALID_POINTER = -1,
	STATUS_INVALID_PARAM = -2,
	STATUS_INVALID_CMD_TYPE = -3,
	STATUS_INVALID_ALMAC = -4,
	STATUS_INVALID_STAMAC = -5,
	STATUS_INVALID_BSSID = -6,
	STATUS_INVALID_ACTION = -7,
	STATUS_INVALID_BITMAP = -8,
	STATUS_INVALID_UP = -9,
	STATUS_INVALID_VERSION = -10,
	STATUS_INVALID_IP = -11,
	STATUS_INVALID_PORT = -12,
	STATUS_INVALID_PROTOCOL = -13,
	STATUS_INVALID_DIR = -14,
	STATUS_INVALID_QOSCHAR = -15,
	STATUS_INVALID_DSCP_EXCEPTION = -16,
	STATUS_INVALID_DSCP_RANGE = -17,
	STATUS_INVALID_BUFLEN = -18,
	STATUS_CFG_EXISTED = -19,
	STATUS_CFG_NOT_EXISTED = -20,
	STATUS_CFG_IS_THE_SAME = -21,
	STATUS_ALLOC_MEM_FAIL = -22,
	STATUS_INSUFFICIENT_PARAM = -23,
	STATUS_NO_CLIENT_FOUND = -24,
	STATUS_CMD_NOT_SUPPORT = -25,
	STATUS_INSUFFICIENT_RESOURCE = -26,
	STATUS_MEMORY_OVERFLOW = -27,
	STATUS_INVALID_INDEX = -28,
	STATUS_INVALID_QOS_INDEX = -29,
	STATUS_INVALID_IP_TUPLE = -30,
	STATUS_NL_CMD_FAIL = -31,
	STATUS_INVALID_SSID_OR_BSSID = -32,
	STATUS_UNKNOWN = 0xFF,
};

struct GNU_PACKED classifier_header {
	u8 cs_type;	/*Classifier Type*/
	u8 cs_mask;	/*Classifier Mask*/
};

struct GNU_PACKED classifier_type3 {
	u8 cs_type;	/*Classifier Type*/
	u8 cs_mask;	/*Classifier Mask*/
	u16	filterOffset;
	u8	filterlen;
	u8	filterValue[MAX_FILTER_LEN];
	u8	filterMask[MAX_FILTER_LEN];
};

#ifdef QOS_R2
struct GNU_PACKED classifier_type4 {
	u8 cs_type;	/*Classifier Type*/
	u8 cs_mask;	/*Classifier Mask*/
	u8 version;
	union {
		u32	ipv4;
		u16	ipv6[8];
	} srcIp;
	union {
		u32	ipv4;
		u16	ipv6[8];
	} destIp;
	u16	srcPort;
	u16	destPort;
	u8	DSCP;
	union {
		u8	protocol;
		u8	nextheader;
	}u;
	u8	flowLabel[3];
};
#endif

struct GNU_PACKED classifier_type10 {
	u8 cs_type;	/*Classifier Type*/
	u8	protocolInstance;
	union {
		u8	protocol;
		u8	nextheader;
	}u;
	u8	filterlen;
	u8	filterValue[MAX_FILTER_LEN];
	u8	filterMask[MAX_FILTER_LEN];
};

struct GNU_PACKED classifier_parameter {
	u8 sta_mac[MAC_ADDR_LEN];
	u8 request_type;
	u8 up_bitmap;
	u8 up_limit;
	u32 timeout;
	union {
		struct classifier_header header;
		struct classifier_type3 type3;
		struct classifier_type10 type10;
	}cs;
};

#ifdef QOS_R2
struct GNU_PACKED scs_status {
	u8 scsid;
	u16 stacode;
};

typedef union GNU_PACKED _tclas_element {
	struct classifier_header header;
	struct classifier_type4 type4;
	struct classifier_type10 type10;
} tclas_element, *ptclas_element;

#ifdef QOS_R3
struct GNU_PACKED qos_characteristics {
	u8 sta_mac[MAC_ADDR_LEN];
	u8 scsid;
	u8 request_type;
	u8 dir;
	u8 QosCharIE[44];
};

struct GNU_PACKED qchar_control_info {
	unsigned int dir:2;
	unsigned int tid:4;
	unsigned int up:3;
	unsigned int prenence_bitmap:16;
	unsigned int linkid:4;
	unsigned int reserved:3;
};

struct qoschar_user_setting {
	unsigned char qchar_mask;
	unsigned char dir;
	unsigned int min_interval;
	unsigned int max_interval;
	unsigned int min_datarate;
	unsigned int delaybound;
};

#endif

struct GNU_PACKED scs_classifier_parameter {
	u8 sta_mac[MAC_ADDR_LEN];
	u8 scsid;
	u8 request_type;
	u8 up;
	u8 alt_queue;
	u8 drop_elig;
	u8 processing;

	u8 tclas_num;
	tclas_element tclas_elem[MAX_TCLAS_NUM];
};

struct scs_configuration {
	struct dl_list list;
	unsigned char index;

	/*scs tclas parameters*/
	struct scs_classifier_parameter scsparam;

#ifdef QOS_R3
	/*qos characteristics element*/
	struct qos_characteristics qchar;

	/*qos characteristics parameters from user*/
	struct qoschar_user_setting qcharconfig;
#endif
};

struct GNU_PACKED qos_management_element {
	u8 elementid;
	u8 length;
	u8 oui[3];
	u8 ouitype;
};

struct GNU_PACKED attribute_header {
	u8 attrid;
	u8 length;
};

struct GNU_PACKED dscp_policy_attribute {
	u8 attrid;
	u8 length;
	u8 policyid;
	u8 request_type;
	u8 dscp;
};

struct GNU_PACKED tclas_attribute_ipv4 {
	u8 attrid;
	u8 length;
	u8 cs_type;	/*Classifier Type*/
	u8 cs_mask;	/*Classifier Mask*/
	u8 version;
	u32 srcIp;
	u32 dstIp;
	u16 srcPort;
	u16 dstPort;
	u8  DSCP;
	u8  protocol;
	u8  reserved;
};

struct GNU_PACKED tclas_attribute_ipv6 {
	u8 attrid;
	u8 length;
	u8 cs_type;	/*Classifier Type*/
	u8 cs_mask;	/*Classifier Mask*/
	u8 version;
	u16 srcIp[8];
	u16 dstIp[8];
	u16 srcPort;
	u16 dstPort;
	u8  DSCP;
	u8  nextheader;
	u8  flowLabel[3];
};

struct GNU_PACKED domain_name_attribute {
	u8 attrid;
	u8 length;
	char  domainname[MAX_DOMAIN_NAME_LEN];
};

struct GNU_PACKED port_range_attribute {
	u8 attrid;
	u8 length;
	u16 startp;
	u16 endp;
};

struct dscp_policy_db {
	struct dl_list list;
	struct dscp_policy_attribute policyattri;
	union {
		struct attribute_header header;
		struct tclas_attribute_ipv4 ipv4;
		struct tclas_attribute_ipv6 ipv6;
	} tclasattri;
	struct domain_name_attribute domainattri;
	struct port_range_attribute portrange;
};

struct GNU_PACKED dscp_policy_req {
	u8 id_num;
	u8 policyids[MAX_POLICY_NUM];
	u8 token;
	u8 moreflag;
	u8 resetflag;
};

#endif

struct GNU_PACKED wapp_qos_action_frame {
	u8 src[MAC_ADDR_LEN];
	u32 frmid;
	u32 chan;
	u32 frm_len;
	u8 frm[0];
};

struct GNU_PACKED qos_netlink_message {
	unsigned char type;
	unsigned short len;
	unsigned char data[0];
};

struct mscs_configuration {
	struct dl_list list;
	unsigned char index;
	struct classifier_parameter csparam;
};

struct GNU_PACKED dscp_exception {
	u8 dscp;
	u8 up;
};

struct GNU_PACKED dscp_range {
	u8 low;
	u8 high;
};

struct GNU_PACKED qos_map {
	u8 num;	/*dscp exception number*/
	struct dscp_exception dscp_ex[MAX_EXCEPT_CNT];
	struct dscp_range dscp_rg[UP_MAX];
	u8 sta_mac[MAC_ADDR_LEN];
};

struct qos_wifi_config {
	u8 channel;
	u8 mode;
	char ssid[32];
	char keymgnt[16];
	char psk[16];
	u8 qosmap_set;
	u8 stamac[MAC_ADDR_LEN];
#ifdef QOS_R2
	u8 RequestCtrlReset;
	u8 dscppolicycapa;
	u8 qosmapcapa;
#endif
};

struct GNU_PACKED wapp_vend_spec_classifier_para_report {
	u32 id;
	u8 sta_mac[MAC_ADDR_LEN];
	u8 request_type;
	u8 up;
	u8 delay_bound;
	u8 protocol;
	u32 timeout;
	unsigned long expired;
	u8 version;
	union {
		u32	ipv4;
		u8	ipv6[16];
	} srcIp;
	union {
		u32	ipv4;
		u8	ipv6[16];
	} destIp;
	u16	srcPort;
	u16	destPort;

	char	ifname[IFNAMSIZ];
};

#ifdef MAP_R5
enum {
	DESCRIPTOR_TYPE_UNKNOWN = 0,
	DESCRIPTOR_TYPE_MSCS,
	DESCRIPTOR_TYPE_SCS,
	DESCRIPTOR_TYPE_QOS_ELEMENT,
};

enum {
	TUNNELLED_DSCP_QUERY = 5,
	TUNNELLED_DSCP_RESPONSE = 6,
};

struct GNU_PACKED qos_management_descriptor_tlv {
	u8 type;	/*QoS Management Descriptor TLV*/
	u16 length;
	u16 qmid;
	u8 bssid[MAC_ADDR_LEN];
	u8 sta_mac[MAC_ADDR_LEN];
	u8 descriptor[MAX_DESCRIPTOR_LEN];
};

struct GNU_PACKED qos_management_policy {
	unsigned char numMSCSDisallowed;
	unsigned char numSCSDisallowed;
	unsigned char MSCSDisallowed[MAX_NUM_DISALLOWED][MAC_ADDR_LEN];
	unsigned char SCSDisallowed[MAX_NUM_DISALLOWED][MAC_ADDR_LEN];

	unsigned char reserved:6;
	unsigned char dscp_policy_en:1;
	unsigned char dscp_to_up_en:1;
};

struct GNU_PACKED qos_management_element_attri {
	struct dscp_policy_attribute policyattri;
	union {
		struct attribute_header header;
		struct tclas_attribute_ipv4 ipv4;
		struct tclas_attribute_ipv6 ipv6;
	} tclasattri;
	struct domain_name_attribute domainattri;
	struct port_range_attribute portrange;
};

struct qos_management_descriptor_db {
	struct dl_list list;

	u16 qmid;
	u8 bssid[MAC_ADDR_LEN];
	u8 sta_mac[MAC_ADDR_LEN];
	u8 desctype;
	union {
		struct classifier_parameter mscs;
		struct scs_classifier_parameter scs;
		struct qos_management_element_attri qosmgmtelem;
	} descElem;

	struct qos_characteristics qchar;
};

struct GNU_PACKED device_info {
	u8 type;
	u8 ifname[IFNAMSIZ];
	u8 macaddr[MAC_ADDR_LEN];
	struct net_device *netdev;
};

struct GNU_PACKED dscp2pcp_mapping_table {
	unsigned char update;
	unsigned char dptbl[DSCP_TBL_SIZE];
};
#endif

struct associated_sta_info_db {
	struct dl_list list;

	u8 src[MAC_ADDR_LEN];
	char ifname[IFNAMSIZ];
	u8 channel;
};

struct index_string_tbl {
	int idx;
	char *str;
};

struct qosidx_mapping {
	int qosidx;
	char *service;
	char *priority;
	u8 up;
};

struct ip_tuple {
	u16 cs_mask;	/*Classifier Mask*/
	u8 sta_mac[MAC_ADDR_LEN];
	u8 request_type;
	u8 qosidx;
	u8 up;
	u8 protocol;
	u8 version;
	union {
		u32 ipv4;
		u16 ipv6[8];
	} srcIp;
	union {
		u32 ipv4;
		u16 ipv6[8];
	} destIp;
	u16	srcPort;
	u16	destPort;
	u32 timeout;
	unsigned long expired;
};

struct ip_tuple_db {
	struct dl_list list;
	struct ip_tuple node;
};

struct priority_bss {
	char ssid[MAX_LEN_OF_SSID + 1];
	char ifname[IFNAMSIZ];
	u8 bssid[MAC_ADDR_LEN];
	u8 qosidx;
	u8 up;
	u8 request_type;
};

struct priority_bss_db {
	struct dl_list list;
	struct priority_bss node;
};

struct priority_sta {
	u8 sta_mac[MAC_ADDR_LEN];
	u8 qosidx;
	u8 up;
	u8 request_type;
};

struct priority_sta_db {
	struct dl_list list;
	struct priority_sta node;
};


int qos_cmd_reset_default(struct wifi_app *wapp, const char *iface, u8 argc, char **argv);
int qos_cmd_set_config(struct wifi_app *wapp, const char *iface, u8 argc, char **argv);
int qos_cmd_commit_config(struct wifi_app *wapp, const char *iface, u8 argc, char **argv);
int qos_ctrl_interface_cmd_handle(struct wifi_app *wapp, const char *iface, u8 argc, char **argv);
int qos_cmd_show_help(struct wifi_app *wapp, const char *iface, u8 argc, char **argv);
int wapp_ctrl_iface_cmd_qos(struct wifi_app *wapp, const char *iface,
		char *param_value_pair, char *reply, size_t *reply_len);
int wapp_ctrl_iface_cmd_set_qos_config(struct wifi_app *wapp,
		const char *iface, char *buf, char *reply, size_t *reply_len);
int wapp_ctrl_iface_cmd_get_qos_config(struct wifi_app *wapp,
	const char *iface, char *buf, char *reply, size_t *reply_len);
int wapp_ctrl_iface_cmd_save_qos_config(struct wifi_app *wapp,
	const char *iface, char *buf, char *reply, size_t *reply_len);
int wapp_ctrl_iface_cmd_get_qos_errorcode(struct wifi_app *wapp,
	const char *iface, char *buf, char *reply, size_t *reply_len);
int wapp_ctrl_iface_cmd_show_qos_config(struct wifi_app *wapp,
		const char *iface, char *buf, char *reply, size_t *reply_len);
void wapp_handle_qos_action_frame(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data);
void wapp_handle_mscs_descriptor_element(struct wifi_app *wapp,
		u32 ifindex, wapp_event_data *event_data);
void wdev_handle_vend_spec_up_tuple_event(struct wifi_app *wapp,
		u32 ifindex, wapp_event_data *event_data);

void wapp_send_qos_map_configure_frame(struct wifi_app *wapp, const char *ifname,
	unsigned int channel, const u8 *dst, struct dscp_exception *dscp_ex, u8 ex_cnt, struct dscp_range *dscp_rg);
int wapp_write_pmk(char *filename, char *buf, u8 len);

int convert_mac_addr(char *strmac, unsigned char *mac_addr);
#ifdef QOS_R2
void wapp_scs_action_frame_process(struct wifi_app *wapp, struct wapp_dev *wdev, u8 channel, u8 *peermac, u8 *frmbuf, u32 frmlen);
void parse_dscp_policy_req(struct wifi_app *wapp, const char *ifname, char *str);
#endif

#ifdef MAP_6E_SUPPORT
unsigned char get_band_6E(struct wifi_app *wapp, unsigned char chan, unsigned char op);
#endif

void clean_iptuple_list(void);
void clean_bss_priority_list(void);
void clean_sta_priority_list(void);

#ifdef MAP_R5
void clean_assoc_sta_list(void);
int map_qos_management_policy(struct wifi_app *wapp, char *msg_buf, unsigned short msg_len);
int map_qos_management_descriptor(struct wifi_app *wapp, char *msg_buf, unsigned short msg_len);
int map_qos_dscp_mapping_table_update(struct wifi_app *wapp, char *msg_buf, unsigned short msg_len);
#ifdef STANDARD_NL_CMD
void map_update_device_info_sd_nl(struct wifi_app *wapp, struct dev_info *wapp_devinfo);
#endif
void map_update_device_info(struct wifi_app *wapp, wapp_dev_info *wapp_devinfo);
int map_set_device_role(u8 devrole);
#endif
void wdev_handle_assoc_sta_info(struct wifi_app *wapp, u32 ifindex, u8 *sta_mac);
int load_qos_config(struct wifi_app *wapp);
int apply_qosmap_to_ap_local(struct wifi_app *wapp, const char *ifname, struct qos_map *qosmap);
int send_qosmap_to_peer_sta(struct wifi_app *wapp, const char *ifname, struct qos_map *qosmap);
int qos_cmd_show_config(struct wifi_app *wapp, const char *iface, u8 argc, char **argv);
void mtqos_event_handler(int sock, void *eloop_ctx, void *sock_ctx);
int wapp_drv_qos_init(struct wifi_app *wapp);
int wapp_drv_qos_deinit(struct wifi_app *wapp);
#endif /* #ifndef _QOS_H_ */

