/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2023-2024  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#ifndef _EPCS_H_
#define _EPCS_H_

#define MAX_AUTHORIZED_STA_NUMBER	10

/* Protected EHT Action field values */
#define EPCS_REQUEST		3
#define EPCS_RESPONSE		4
#define EPCS_TEARDOWN		5

enum {
	STATE_EPCS_TORNDOWN = 0,
	STATE_EPCS_ENABLED,
};

enum STATUS_CODE {
	EPCS_STATUS_SUCCESS = 0,
	EPCS_STATUS_DENIED_UNAUTHORIZED = 131,
	EPCS_STATUS_DENIED_OTHER_REASON = 132,
	EPCS_STATUS_DENIED_VERIFICATION_FAILURE = 140,
};

#ifndef STANDARD_NL_CMD
enum WMM_AC_TYPE {
	WMM_AC_BE = 0,
	WMM_AC_BK,
	WMM_AC_VI,
	WMM_AC_VO,
	WMM_AC_NUM
};
#endif

struct wmm_parameter {
	u8 cwmin;
	u8 cwmax;
	u8 aifsn;
	u16 txop;
};

struct epcs_sta {
	u8 ifname[IFNAMSIZ];
	u8 mac[MAC_ADDR_LEN];
	u8 state;
	struct wmm_parameter wmmpe[WMM_AC_NUM];
};

struct epcs_entry {
	struct epcs_sta sta;
	struct dl_list list;
};


void wapp_epcs_init(struct wifi_app *wapp);
void wapp_epcs_deinit(struct wifi_app *wapp);

int wapp_ctrl_send_act_frame(
	struct wifi_app *wapp, const char *iface, char *file, char *reply, size_t *reply_len);
int wapp_ctrl_epcs_setup(struct wifi_app *wapp, const char *iface,
	char *cmd, char *reply, size_t *reply_len);
int wapp_ctrl_epcs_wmmpe(struct wifi_app *wapp, const char *iface,
	char *cmd, char *reply, size_t *reply_len);
int wapp_drv_send_action_frame(
	unsigned short sub_cmd_id, struct wifi_app *wapp, struct wapp_dev *wdev, unsigned int chan,
	unsigned int wait, const u8 *dst, const u8 *data, size_t len);
void wapp_eht_action_frame_receive(struct wifi_app *wapp,
	struct wapp_dev *wdev, u8 channel, u8 *peermac, u8 *frmbuf, u32 frmlen);

void clean_epcs_list(void);
void wapp_ctrl_show_epcs_list(void);
void wapp_epcs_sta_leave_action(struct wifi_app *wapp, struct wapp_dev *wdev, u8 *stamac);

#endif /* #ifndef _EPCS_H_ */

