/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2020-2021  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#ifndef _COSR_H_
#define _COSR_H_

#include "wapp_cmm.h"
#include "wapp_cmm_type.h"

#define RADIO1 "rai0"
#define RADIO2 "rai0"

#define MAX_COSR_CANDLIST_STA 8
#define WIFI_COSR_PERIOD 60
#define COSR_WAIT_TIME 3
#define COSR_11K_WAIT_TIME 2
/* Max count of coordinated AP */
#define MAX_COSR_CO_AP_COUNT 3

#define COSR_QUERY_TIME 5
#define WIFI_COSR_PERIOD_TEST 10
#define MIN_COSR_RSS_THR (-60)

#define COSR_SUPPORT 1
#define COSR_NOT_SUPPORT 0


#define COSR_STA_STATUS_VALID 1
#define COSR_STA_STATUS_INVALID 0


#define COSR_AIRMONITOR_DEFA (-110)
#define COSR_SET_AP_DEFA (-60)

#define BLACKLIST_TIME 300
#define COSR_STA_DEFA_RSSI (-110)
#define COSR_STA_DEFA_SINR_EHT (38)
#define COSR_STA_DEFA_SINR_HE_VHT (32)


#define COSR_AIRMONITOR_QUERY_TIMEOUT 750000U
#define COSR_CANDLIST_BLOCK_TIME 60
/*Set airtime default wait_time */
#define AIRTIME_SHARING_WAIT_TIME 10000
#define WAIT_COAP_READY_TIME 10

#define INVALID_STA_THRESHOLD (-65)

#define STA_RSSI_OFFSET (10)

/* cosr_airtime_state */

#define	AIRTIME_STATE_NO_REQ  (0x00)
#define	AIRTIME_STATE_SHARING (0x01)
#define	AIRTIME_STATE_SHARED  (0x02)
#define	AIRTIME_STATE_BOTH    (0x03)


#define AIRTIME_MAX_NONCE_LEN 32
#define COSR_LEN 6 /* OUI, OUI Type, Crypto Suite, Cosr frame type */
#define AIRMONITOR_CONTENT_LEN 7
#define COSR_MAX_11K_RETRIES 3
#define COSR_MAX_11K_CYCLE_COUNT 3
#define OUI_MTK 0x000CE7

#define WLAN_EID_VENDOR_SPECIFIC 221
#define WLAN_ACTION_PUBLIC 4
#define WLAN_PA_VENDOR_SPECIFIC 9
#define IE_MEASUREMENT_REPORT           39

#define rcpi_to_rssi(rcpi) ((rcpi == 255) ? (-127) : (rcpi - 220)/2)

/* STA PHY Mode Define */
#define MODE_CCK 0
#define MODE_OFDM 1
#define MODE_HTMIX 2
#define MODE_HTGREENFIELD 3
#define MODE_VHT 4
#define MODE_HE 5
#define MODE_EHT 6


static const u8 BROADCAST[MAC_ADDR_LEN] = { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff };

enum cosr_cmd_type {
	COSR_SET_ENABLE = 0,
	COSR_STA_INFO,
	COSR_STA_INFO_RST,
	COSR_AP_INFO,
	COSR_AP_INFO_RST,
	COSR_SR_DISABLE,
	COSR_SCS_DISABLE,
	COSR_SET_DISABLE
};

/*Set Cosr ie OUI Info */
#define COSR_OUI_0 0x50
#define COSR_OUI_1 0x11
#define COSR_OUI_2 0x22
#define COSR_OUI_VALUE 0x01

#define COSR_VENDOR_SPECIFIC 221
#define COSR_IE_LEN 4

struct GNU_PACKED cosr_bcn_info {
	u8 eid;
	u8 length;
	char oui[3]; /* 0x50 11 22 */
	u8 value;
};

struct GNU_PACKED req_beacon_info {
	u8 req_mode;
	u8 op_class;
	u8 channel;
	u16 random_val;
	u16 meas_dur;
	u8 meas_mode;
	u8 wild_addr[MAC_ADDR_LEN];
};

struct GNU_PACKED cosr_bcn_req {
	u8 op_class;
	u8 op_channel;
	u16 meadur;
	u8 meamode;
	u8 randint;
	u8 sta_mac[MAC_ADDR_LEN];
};

struct GNU_PACKED cosr_beacon_rsp {
	unsigned char sta_mac[ETH_ALEN];
	unsigned char reserved;
	unsigned char bcn_rpt_num;
	unsigned short rpt_len;
	unsigned char rpt[0];
};

struct GNU_PACKED cosr_beacon_rep_info {
	unsigned char regulatory_Class;
	unsigned char ch_number;
	unsigned long long actual_measure_start_time;
	unsigned short measure_duration;
	unsigned char rep_frame_Info;
	unsigned char rcpi;
	unsigned char rsni;
	unsigned char bssid[ETH_ALEN];
	unsigned char annta_dd;
	unsigned int parent_tsf;
	unsigned char option[0];
};

struct GNU_PACKED COSR_EID_STRUCT {
	u8 Eid;
	u8 Len;
	u8 Octet[1];
};

struct GNU_PACKED sta_rssi {
	struct dl_list rssi_entry;
	int8_t rssi;
	uint8_t channel;
	uint8_t bssid[MAC_ADDR_LEN];
};

enum CosrMeasState {
	COSR_STABLE = 0,
	COSR_UNSTABLE,
	COSR_INVALID,
};
enum CosrStaMeasState {
	INVALID = 0,
	WAIT_11K,
	WAIT_11K_OWN_MAC, /* Measuring Own AP, wait result */
	WAIT_11K_RESULT, /* Measuring Neighbor AP, wait result */
	WAIT_11K_FAIL,
	WAIT_AIRMONITOR,
	WAIT_AIRMONITOR_RESULT,
	PLDIFF_DONE,
};

struct cosr_meas_stat_data {
	u8 measurement_retries_11k;
	u8 cli_measurement_state;
	u8 u1OwnMac11kRssi;
	u8 u1NoAirMntRspCnt;
	BOOLEAN fg11k_support_fail;
};
enum subcat_type {
	UNKNOWN_SUBCAT = 0,
	AIRTIME_SHARING,
	AIRMONITOR,
};

enum cosr_type {
	AIRTIME_SHARING_REQ = 0,
	AIRTIME_SHARING_RESP,
	AIRMONITOR_REQ,
	AIRMONITOR_RESP,
	UNKNOWN_TYPE,
};

enum cosr_req_status {
	AIRTIME_SHARING_REQ_ABORT = 0,
	AIRTIME_SHARING_REQ_REQ,
	AIRTIME_SHARING_REQ_SYNC,
};
enum cosr_resp_status {
	AIRTIME_SHARING_RESP_ACCEPT = 0,
	AIRTIME_SHARING_RESP_DENY,
	AIRTIME_SHARING_ABORT_RESP_ACCEPT,
	AIRTIME_SHARING_ABORT_RESP_DENY,
};

struct GNU_PACKED airtime_vendor_content {
	union {
		struct {
			u8 req_status;
			u8 pri_bssid[MAC_ADDR_LEN];
			u8 apcli_mac[MAC_ADDR_LEN];
		} req_content;
		struct {
			u8 resp_status;
			u8 apcli_mac[MAC_ADDR_LEN];
		} resp_content;
	} u;
};

struct GNU_PACKED cosr_airtime_sharing {
	u8 subcat;
	u8 cosrtype;
	u8 target_bssid[MAC_ADDR_LEN];
	u8 pri_bssid[MAC_ADDR_LEN];
	u8 req_status;
	u8 resp_status;
	u8 current_state;
	struct airtime_vendor_content *content;
	struct wapp_dev *wdev;
	struct wpabuf *req_msg;
	struct wpabuf *resp_msg;
	unsigned int op_channel;

};

struct GNU_PACKED cosr_airmonitor_result_info {
	u8 sta_mac[MAC_ADDR_LEN];
	u8 peer_mac[MAC_ADDR_LEN];
	signed int uplink_rssi;
};

struct GNU_PACKED cosr_unlink_rsp_sta {
	u8 sta_mac[MAC_ADDR_LEN];
	signed int uplink_rssi;
};

struct GNU_PACKED cosr_unlink_rsp_info {
	struct dl_list list;
	u8 u1StaNum;
	struct cosr_airmonitor_result_info info[0];
};

struct GNU_PACKED cosr_airmonitor_resp_info {
	u8 subcat;
	u8 cosrtype;
	u8 target_bssid[MAC_ADDR_LEN];
	u8 own_mac[MAC_ADDR_LEN];
	u8 sta_num;
	struct cosr_unlink_rsp_sta info[0];
};

struct GNU_PACKED cosr_airmonitor_req_info {
	u8 subcat;
	u8 cosrtype;
	u8 target_bssid[MAC_ADDR_LEN];
	u8 own_mac[MAC_ADDR_LEN];
	u8 sta_num;
	u8 sta_list[0];
};

struct GNU_PACKED cosr_airmonitor_req_frame {
	struct wpabuf *req_msg;
	struct cosr_airmonitor_req_info req_info;
};


struct GNU_PACKED cosr_airmonitor_resp_frame {
	unsigned int bitmap;
	struct dl_list list;
	struct wpabuf *resp_msg;
	struct cosr_airmonitor_resp_info resp_info;
};

struct cosr_ap_candlist_ap {
	struct cosr_ap_candlist_ap *next;
	u8 bssid[MAC_ADDR_LEN];
	u8 apcli_mac[MAC_ADDR_LEN];
	int count;
	u8 cosr_status;
	u8 apid;
	u8 rssi;
	u8 bcn_detect_cnt;
	u8 bcn_detect;
	u8 band;
	u8 cosr_ap_mode;
};

struct cosr_bcn_report_list {
	struct cosr_bcn_report_list *next;
	u8 bssid[MAC_ADDR_LEN];
	u8 sta_mac[MAC_ADDR_LEN];
	u8 rcpi;
	int count;
};

struct cosr_ap_blacklist {
	struct cosr_ap_blacklist *next;
	u8 bssid[ETH_ALEN];
	int count;
};

/* function for cosr */
int wapp_cosr_init(struct wifi_app *wapp);
int wapp_cosr_deinit(struct wifi_app *wapp);
void cosr_system_cmd_w_if(struct wifi_app *wapp, int type, char *ifname);

void wapp_cosr_period(void *eloop_ctx, void *sock_ctx);
void cosr_trigger_own_bcn_req_timeout(void *eloop_ctx, void *timeout_ctx);
void cosr_trigger_bcn_req_timeout(void *eloop_ctx, void *timeout_ctx);
int cosr_set_bcn_ie(struct wifi_app *wapp, struct wapp_dev *wdev);
int wapp_set_cosr_ie(struct wifi_app *wapp, const char *iface, char *ie, size_t ie_len);

int wapp_cosr_stainfo_send(struct wifi_app *wapp, const char *iface, struct cosr_info_set *req);
int cosr_set_stainfo_by_mac(struct wifi_app *wapp, struct wapp_dev *wdev, u8 *mac_addr);

int wapp_cosr_apinfo_send(struct wifi_app *wapp, const char *iface, struct cosr_info_set *req);
int cosr_trigger_own_bcn_meas(struct wifi_app *wapp, struct wapp_dev *wdev, struct wapp_sta *sta);
int cosr_trigger_bcn_meas(struct wifi_app *wapp, struct wapp_dev *wdev, struct wapp_sta *sta, struct cosr_ap_candlist_ap *eAp);
int hostapd_cosr_handle_beacon_report(struct wifi_app *wapp, u16 data_len, char *data);
void cosr_record_bcn_own_mac(struct wifi_app *wapp, struct wapp_dev *wdev, u8 *sta_mac, struct cosr_bcn_report_list *bcn_report_result);
void cosr_cal_bcn_report_pathdiff(struct wifi_app *wapp, struct wapp_dev *wdev, u8 *sta_mac);

void wapp_cosr_rx_action(struct wifi_app *wapp, struct wapp_dev *wdev, const u8 *src,
				const u8 *buf, size_t len, unsigned int chan, char rssi);
int wapp_cosr_process_frames(struct wifi_app *wapp, struct wapp_dev *wdev, const u8 *src, const u8 *hdr,
				const u8 *buf, size_t len,  unsigned int chan, enum cosr_type type, char rssi);
int wapp_drv_send_cosr_action(struct wifi_app *wapp, struct wapp_dev *wdev, unsigned int chan,
		unsigned int wait, const u8 *dst, const u8 *data, size_t len);

void wdev_handle_found_coap_event(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data);
void wdev_get_cosr_action_frame(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data);
void wdev_handle_cosr_sta_rssi_change(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data);


struct wpabuf *cosr_airtime_buid_req(struct cosr_airtime_sharing *cosr_airtime_req,
										struct airtime_vendor_content *content);
struct wpabuf *cosr_airtime_buid_resp(struct cosr_airtime_sharing *cosr_airtime_resp,
										struct airtime_vendor_content *content);
struct wpabuf *cosr_airtime_alloc_msg(u8 subcat, u8 cosrtype, u8 *target_bssid, size_t len);
int wapp_cosr_airtime_sharing_send_req(struct wifi_app *wapp, struct wapp_dev *wdev, u8 *mac_addr, u8 fsm_status);
int wapp_cosr_airtime_sharing_send_resp(struct wifi_app *wapp, struct wapp_dev *wdev,
													const u8 *mac_addr, u8 resp_status);
void wapp_cosr_rx_airtime_req(struct wifi_app *wapp, struct wapp_dev *wdev,
	const u8 *src, const u8 *buf, size_t len, u8 rssi);
void wapp_cosr_rx_airtime_resp(struct wifi_app *wapp, struct wapp_dev *wdev, const u8 *src,
	const u8 *buf, size_t len, unsigned int chan, u8 rssi);

int cosr_set_stainfo(struct wifi_app *wapp, struct wapp_dev *wdev, const char *iface);
int cosr_set_apinfo(struct wifi_app *wapp, struct wapp_dev *wdev, const u8 *mac_addr, u8 coap_status);
int cosr_clear_apinfo(struct wifi_app *wapp, struct wapp_dev *wdev, u8 apid);



struct wapp_sta *cosr_get_candlist_sta(struct wifi_app *wapp, struct wapp_dev *wdev, const u8 *mac_addr);
int cosr_del_candlist_sta(struct wifi_app *wapp, struct wapp_dev *wdev, unsigned char *sta_addr);
int cosr_ap_candlist_sta_init(struct wifi_app *wapp, struct ap_dev *ap);
int cosr_wapp_candlist_sta_init(struct wifi_app *wapp);

int cosr_update_candlist_sta(struct wifi_app *wapp, struct wapp_dev *wdev);



int cosr_ap_candlist_ap_count_per_band(struct wifi_app *wapp, struct wapp_dev *wdev);
struct cosr_ap_candlist_ap *cosr_ap_get_candlist_per_band(struct wifi_app *wapp, struct wapp_dev *wdev, const u8 *bssid);
int cosr_ap_add_candlist_ap_per_band(struct wifi_app *wapp, struct wapp_dev *wdev, const u8 *bssid, u8 rssi, const u8 *apclimac);
int cosr_ap_del_candlist_ap_per_band(struct wifi_app *wapp, struct wapp_dev *wdev, const u8 *bssid);
void cosr_ap_clear_candlist_ap_per_band(struct wifi_app *wapp, struct wapp_dev *wdev);
int cosr_ap_set_coorap_status_per_band(struct wifi_app *wapp, struct wapp_dev *wdev, const u8 *bssid, u8 ap_status);
int cosr_ap_get_coorap_status_per_band(struct wifi_app *wapp, struct wapp_dev *wdev, const u8 *bssid);
int cosr_ap_set_coorap_id_per_band(struct wifi_app *wapp, struct wapp_dev *wdev, const u8 *bssid);
int cosr_ap_get_candlist_missing_apid(u8 *nums, u8 length);

int cosr_blacklist_count(struct wifi_app *wapp);
struct cosr_ap_blacklist *cosr_ap_get_blacklist(struct wifi_app *wapp, const u8 *bssid);
int cosr_ap_add_blacklist(struct wifi_app *wapp, const u8 *bssid);
int cosr_ap_del_blacklist(struct wifi_app *wapp, const u8 *bssid);
void cosr_ap_clear_blacklist(void *eloop_ctx, void *sock_ctx);


struct cosr_bcn_report_list *cosr_get_bcn_reportlist(struct wifi_app *wapp, const u8 *bssid,  const u8 *sta_mac);
struct cosr_bcn_report_list *cosr_update_bcn_reportlist(struct wifi_app *wapp, const u8 *bssid, const u8 *sta_mac, u8 rcpi);
int cosr_add_bcn_reportlist(struct wifi_app *wapp, const u8 *bssid, const u8 *sta_mac, u8 rcpi);
int cosr_del_report_list(struct wifi_app *wapp, const u8 *sta_mac, const u8 *bssid);
void cosr_clear_bcn_reportlist(struct wifi_app *wapp);

struct wpabuf *cosr_build_airmonitor_req_frame(struct cosr_airmonitor_req_frame *airmonitor_req);
struct wpabuf *cosr_build_airmonitor_resp_frame(struct cosr_airmonitor_resp_frame *airmonitor_resp);
int cosr_send_airmonitor_request(struct wifi_app *wapp, struct wapp_dev *wdev,
						struct cosr_airmonitor_req_frame *req_frame, u8 *mac_addr);
unsigned char cosr_get_bandidx(struct wifi_app *wapp, struct wapp_dev *wdev);
int cosr_check_trigger_candlistap_airmonitor(struct wifi_app *wapp, struct wapp_dev *wdev);
unsigned char cosr_airmonitor_entry_check(struct wifi_app *wapp, u8 *sta_mac, unsigned char channel);

unsigned char cosr_check_for_monitor_complettion(struct cosr_airmonitor_resp_frame  *airmonitor_resp);
int cosr_send_airmonitor_response(struct wifi_app *wapp, struct cosr_airmonitor_resp_frame *cosr_airmonitor_resp);
int cosr_update_sta_rssi(struct wifi_app *wapp, struct wapp_dev *wdev, wapp_mnt_info *mnt_info);
void clear_cosr_monitor_list(struct wifi_app *wapp);
void clear_cosr_airmonitor_req_list(struct wifi_app *wapp);
void cosr_airmonitor_query_timeout(void *eloop_data, void *user_ctx);
void wapp_cosr_wdev_ready_init_handler(void *eloop_ctx, void *sock_ctx);
void cosr_receive_airmonitor_request(struct wifi_app *wapp, struct wapp_dev *wdev,
	const u8 *bss_addr, size_t len, const u8 *msg_buf);
void cosr_send_air_monitor_response_check(struct wifi_app *wapp, wapp_mnt_info *mnt_info);
void cosr_airmonitor_packet_handle(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data);
void cosr_receive_airmonitor_response(struct wifi_app *wapp, struct wapp_dev *wdev,
										const u8 *bss_addr, size_t len, const u8 *msg_buf);
void cosr_cal_airmonitor_pathloss(struct wifi_app *wapp, struct wapp_dev *wdev);

int wapp_cosr_enable(struct wifi_app *wapp);
int wapp_cosr_disable(struct wifi_app *wapp);

int wapp_cosr_ap_mode_set_per_band(struct wifi_app *wapp, char *iface, BOOLEAN command);
int wapp_cosr_add_whitelist_ap(struct wifi_app *wapp, char *iface, u8 *mac_addr);
int wapp_cosr_del_whitelist_ap(struct wifi_app *wapp, char *iface, u8 *mac_addr);
int wapp_cosr_clear_whitelist_ap(struct wifi_app *wapp, char *iface);
int wapp_cosr_show_whitelist_ap(struct wifi_app *wapp, char *iface);

#endif /*_COSR_H_ */


