/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#ifndef __DRIVER_H__
#define __DRIVER_H__

#include "hotspot.h"
#include "wapp_cmm.h"

struct hotspot;
struct wifi_app;
struct wapp_req;
#ifdef MTK_HOSTAPD_SUPPORT
struct dpp_authentication;
#endif /* MTK_HOSTAPD_SUPPORT */

struct wapp_drv_ops {
	void * (*drv_inf_init)(struct wifi_app *wapp, const int opmode, const int drv_mode);
	int (*drv_inf_exit)(struct wifi_app *wapp);
	int (*drv_test)(void *drv_data, u32 test_data);
#ifdef STANDARD_NL_CMD
	struct phy_info * (*drv_get_hw_info)(void *drv_data, u8 *num_phys);
	struct dev_info * (*drv_get_devs)(void *drv_data, u8 *num_devs);
	int (*drv_get_dev)(void *drv_data, struct dev_info *dev);
	int (*drv_get_country)(void *drv_data, char *country_code);
	int (*drv_get_feature)(void *drv_data, struct phy_info *phy);
	int (*drv_get_scan_result)(struct wifi_app *wapp, struct wapp_dev *wdev, struct wapp_req *req, u8 op_class);
#endif
	int (*drv_wifi_version)(void *drv_data, const char *ifname,
							char *ver, size_t *len);
	int (*drv_wapp_version_check)(void *drv_data, const char *ifname);

	int (*drv_wapp_req) (void *drv_data, const char *ifname, struct wapp_req *req);
	int (*drv_send_btm_req)(void *drv_data, const char *ifname,
							const u8 *peer_sta_addr, const char *btm_req,
							size_t btm_req_len);
	int (*drv_send_btm_query)(void *drv_data, const char *ifname,
							  const char *peer_sta_addr, const char *btm_query,
							  size_t btm_query_len);
	int (*drv_send_btm_rsp)(void *drv_data, const char *ifname,
							const u8 *peer_sta_addr, const char *btm_rsp,
							size_t btm_rsp_len);
	int (*drv_send_bcn_req)(void *drv_data, const char *ifname,
							const u8 *peer_sta_addr, const u8 req_mode,
							const char *bcn_req, size_t bcn_req_len);
	int (*drv_send_reduced_nr_list)(void *drv_data, const char *ifname,
							const char *reduced_nr_list,
							size_t reduced_nr_list_len);
	int (*drv_wapp_param_setting)(void *drv_data, const char *ifname, u32 param, u32 value);
	int (*drv_send_anqp_req)(void *drv_data, const char *ifname,
							 const char *peer_sta_addr,const char *anqp_req,
							 size_t anqp_req_len);
	int (*drv_send_anqp_rsp)(void *drv_data, const char *ifname,
							 const u8 *peer_sta_addr,const char *anqp_rsp,
							 size_t anqp_rsp_len);
	int (*drv_set_interworking)(void *drv_data, const char *ifname, char *enable, size_t len);
	int (*drv_send_wnm_notify_req)(void *drv_data, const char *ifname,
							const char *peer_sta_addr, const char *btm_req, size_t btm_req_len, int type);
	int (*drv_set_ie)(void *drv_data, const char *ifname, char *ie,
					  size_t ie_len);
#ifdef COSR_SUPPORT
	int (*drv_set_cosr_ie)(void *drv_data, const char *ifname, char *ie, size_t ie_len);
	int (*drv_wapp_set_cosr_stainfo)(void *drv_data, const char *ifname, struct cosr_info_set *req);
	int (*drv_wapp_set_cosr_apinfo)(void *drv_data, const char *ifname, struct cosr_info_set *req);
#endif /* COSR_SUPPORT */
	int (*drv_wps_pbc_trigger)(void *drv_dta, const char *ifname,
							char *ver, size_t *len);
	int (*drv_get_wsc_profiles)(void *drv_dta, const char *ifname,
							char *buf, int *len);
#ifdef MTK_MLO_MAP_SUPPORT
	int (*drv_get_mlo_info)(void *drv_dta, const char *ifname,
			char *buf, size_t *len);
#endif
	int (*drv_get_wdev)(void *drv_data, const char *ifname, char *buf, size_t buf_len);
#ifdef MAP_R2
	int (*drv_ch_scan_req)(void *drv_dta, const char *ifname,
							const char *ch_scan_req, size_t len);
#ifdef DFS_CAC_R2
	int (*drv_get_cac_cap)(void *drv_data, const char *ifname, char *buf, size_t buf_len);
	int (*drv_cac_req)(void *drv_data, const char *ifname, u32 param, u32 value);
	int (*drv_set_monitor_ch_assign)(void *drv_data, const char *ifname, char *msg,
					  size_t msg_len);
	int (*drv_get_ch_avail_list)(void *drv_data, const char *ifname, char *msg,
				  size_t msg_len);
#endif
#endif
	int (*drv_get_misc_cap)(void *drv_data, const char *ifname, char *buf,
								  size_t *buf_len);
	int (*drv_get_ht_cap)(void *drv_data, const char *ifname, char *buf,
								  size_t *buf_len);
	int (*drv_get_vht_cap)(void *drv_data, const char *ifname, char *buf,
								  size_t *buf_len);
	int (*drv_get_he_cap)(void *drv_data, const char *ifname, char *buf,
								  size_t *buf_len);
#ifdef MAP_EHT_SUPPORT
	int (*drv_get_eht_cap)(void *drv_data, const char *ifname, char *buf,
								  size_t *buf_len);
#endif
#ifdef MTK_MLO_MAP_SUPPORT
	int (*drv_get_mlo_cap)(void *drv_data, const char *ifname, char *buf,
							size_t *buf_len);
#endif
	int (*drv_get_chan_list)(void *drv_data, const char *ifname, char *buf,
								  size_t *buf_len);
	int (*drv_get_nop_channels)(void *drv_data, const char *ifname, char *buf,
								  size_t *buf_len);
	int (*drv_get_op_class)(void *drv_data, const char *ifname, char *buf,
								  size_t *buf_len);
	int (*drv_get_bss_info)(void *drv_data, const char *ifname, char *buf,
								  size_t *buf_len);
	int (*drv_get_ap_metrics)(void *drv_data, const char *ifname, char *buf,
								  size_t *buf_len);
	int (*drv_off_ch_scan_req)(void *drv_dta, const char *ifname,
							const char *ch_scan_req, size_t len);
	int (*drv_get_chip_id)(void *drv_data, const char *ifname, char *buf,
								  size_t *buf_len);
	int (*drv_get_max_sta_num)(void *drv_data, const char *ifname, char *buf,
			size_t *buf_len);
	int (*drv_get_assoc_req_frame)(void *drv_data, const char *ifname, char *assoc_data, size_t length);
	int (*drv_get_bss_coex)(void *drv_data, const char *ifname, char *buf, size_t *buf_len);
#if WEXT_SUPPORT
	int (*drv_set_apcli_mode)(void *drv_data, const char *ifname, char *buf,
			size_t buf_len);
	int (*drv_set_authtype)(void *drv_data, const char *ifname, char *buf,
			size_t buf_len);
	int (*drv_set_htbw)(void *drv_data, const char *ifname, char *buf,
			size_t *buf_len);
	int (*drv_set_key1)(void *drv_data, const char *ifname, char *buf,
			size_t *buf_len);
	int (*drv_set_map_channel)(void *drv_data, const char *ifname, char *buf,
			size_t *buf_len);
	int (*drv_set_channel)(void *drv_data, const char *ifname, char *buf,
			size_t *buf_len);
	int (*drv_set_map_channel_enable)(void *drv_data, const char *ifname, char *buf,
			size_t *buf_len);
	int (*drv_set_map_enable)(void *drv_data, const char *ifname, char *buf,
			size_t *buf_len);
#endif /* WEXT_SUPPORT */
	int (*drv_set_anqp_elem)(void *drv_data, const char *ifname, int id, u8 *buf, size_t buf_len);
	int (*drv_set_pmfmfpc)(void *drv_data, const char *ifname, char *buf,
			size_t buf_len);
	int (*drv_set_map_param)(void *drv_data, const char *ifname,
				u8 map_param, char *buf,
				size_t buf_len);
#ifdef WEXT_SUPPORT
	int (*drv_set_radio_on)(void *drv_data, const char *ifname, char *buf,
			size_t *buf_len);
	int (*drv_set_ts_bh_primary_vid)(void *drv_data, const char *ifname, char *buf,
			size_t *buf_len);
	int (*drv_set_ts_bh_primary_pcp)(void *drv_data, const char *ifname, char *buf,
			size_t *buf_len);
	int (*drv_set_vhtbw)(void *drv_data, const char *ifname, char *buf,
			size_t *buf_len);
	int (*drv_set_v10converter)(void *drv_data, const char *ifname, char *buf,
			size_t *buf_len);
	int (*drv_set_wsc_stop)(void *drv_data, const char *ifname, char *buf,
			size_t *buf_len);
	int (*drv_set_wsc_conf_mode)(void *drv_data, const char *ifname, char *buf,
			size_t *buf_len);
	int (*drv_set_wsc_mode)(void *drv_data, const char *ifname, char *buf,
			size_t *buf_len);
	int (*drv_set_wsc_get_conf)(void *drv_data, const char *ifname, char *buf,
			size_t *buf_len);
	int (*drv_set_wsc_conf_status)(void *drv_data, const char *ifname, char *buf,
			size_t *buf_len);
	int (*drv_set_autoroam)(void *drv_data, const char *ifname, char *buf,
			size_t buf_len);
	int (*drv_set_bssid)(void *drv_data, const char *ifname, char *buf,
			size_t buf_len);
	int (*drv_set_APproxy_refresh)(void *drv_data, const char *ifname, char *buf,
			size_t buf_len);
	int (*drv_set_auth_mode)(void *drv_data, const char *ifname, char *buf,
			size_t buf_len);
	int (*drv_set_apcli_ssid)(void *drv_data, const char *ifname, char *buf,
			size_t buf_len);
	int (*drv_set_apcli_wpapsk)(void *drv_data, const char *ifname, char *buf,
			size_t buf_len);
#endif /* WEXT_SUPPORT */
	int (*drv_set_apcli_PMFMFPC)(void *drv_data, const char *ifname, int network_id, char *buf,
			size_t buf_len);
	int (*drv_set_apcli_dpp_pfs)(void *drv_data, const char *ifname, int network_id, int value);
	int (*drv_mbo_param_setting)(void *drv_data, const char *ifname, u32 param, u32 value);
#ifdef WEXT_SUPPORT
	int (*drv_set_apcli_EncrypType)(void *drv_data, const char *ifname, char *buf,
			size_t buf_len);
	int (*drv_set_EncrypType)(void *drv_data, const char *ifname, char *buf,
			size_t buf_len);
#endif /* WEXT_SUPPORT */
	int (*drv_set_ACLAddEntry)(void *drv_data, const char *ifname, u8 *buf, size_t buf_len);
	int (*drv_set_ACLDelEntry)(void *drv_data, const char *ifname, u8 *buf, size_t buf_len);
	int (*drv_set_ACLClearAll)(void *drv_data, const char *ifname, u8 *buf, size_t buf_len);
	int (*drv_set_AccessPolicy)(void *drv_data, const char *ifname, u8 *buf, size_t buf_len);
	int (*drv_set_BLAdd)(void *drv_data, const char *ifname, u8 *buf, size_t buf_len);
	int (*drv_set_BLDel)(void *drv_data, const char *ifname, u8 *buf, size_t buf_len);
#ifdef WEXT_SUPPORT
	int (*drv_set_AutoConnect)(void *drv_data, const char *ifname, char *buf,
			size_t buf_len);
	int (*drv_set_BLAdd)(void *drv_data, const char *ifname, char *buf,
			size_t buf_len);
	int (*drv_set_BLDel)(void *drv_data, const char *ifname, char *buf,
			size_t buf_len);
	int (*drv_set_bhbss)(void *drv_data, const char *ifname, char *buf,
			size_t buf_len);
	int (*drv_set_fhbss)(void *drv_data, const char *ifname, char *buf,
			size_t buf_len);
	int (*drv_set_DppEnable)(void *drv_data, const char *ifname, char *buf,
			size_t buf_len);
	int (*drv_set_DisConnectSta)(void *drv_data, const char *ifname, char *buf,
			size_t buf_len);
	int (*drv_set_DisConnectAllSta)(void *drv_data, const char *ifname, char *buf,
			size_t buf_len);
	int (*drv_set_HtBssCoex)(void *drv_data, const char *ifname, char *buf,
			size_t buf_len);
	int (*drv_set_HideSSID)(void *drv_data, const char *ifname, char *buf,
			size_t buf_len);
	int (*drv_set_BcnReq)(void *drv_data, const char *ifname, char *buf,
			size_t buf_len);
	int (*drv_set_mnt_en)(void *drv_data, const char *ifname, char *buf,
			size_t buf_len);
	int (*drv_set_mnt_rule)(void *drv_data, const char *ifname, char *buf,
			size_t buf_len);
	int(*drv_set_mnt_sta0)(void *drv_data, const char *ifname, char *buf,
			size_t buf_len);
	int (*drv_set_ts_bh_vid)(void *drv_data, const char *ifname, char *buf,
			size_t buf_len);
	int (*drv_set_ts_fh_vid)(void *drv_data, const char *ifname, char *buf,
			size_t buf_len);
	int (*drv_set_transparent_vid)(void *drv_data, const char *ifname, char *buf,
			size_t buf_len);
#endif /* WEXT_SUPPORT */
	int (*drv_set_ssid)(void *drv_data, const char *ifname, char *buf, int network_id);
	int (*drv_set_psk)(void *drv_data, const char *ifname, char *buf);
	int (*send_action)(unsigned short sub_cmd_id, void *drv_data, const char *ifname, unsigned int chan,
                                      unsigned int wait_time,
                                      const u8 *dst, const u8 *src,
                                      const u8 *bssid,
                                      const u8 *data, size_t data_len, u16 seq_no,
                                      int no_cck);
	int (*drv_cancel_roc)(void *drv_data, const char *ifname);
	int (*drv_start_roc)(void *drv_data, const char *ifname, unsigned int freq,
                                      unsigned int wait_time);

	int (*drv_get_tx_pwr)(void *drv_data, const char *ifname, char *buf,
							  size_t *buf_len);
	int (*drv_set_wireless_mode)(void *drv_data, const char *ifname, u8 mode);
	int (*drv_set_channel_proc)(void *drv_data, const char *ifname, u8 channel);
	int (*drv_set_bw_proc)(void *drv_data, const char *ifname, u32 bw);
	int (*drv_set_bw_channel_proc)(void *drv_data, const char *ifname, u32 bw, u8 channel, u8 cac_req, u8 eht_extcha);
	int (*drv_set_htbw_proc)(void *drv_data, const char *ifname, u8 bw);
	int (*drv_set_vhtbw_proc)(void *drv_data, const char *ifname, u8 bw);
#ifdef MAP_EHT_SUPPORT
	int (*drv_set_ehtbw_proc)(void *drv_data, const char *ifname, u8 bw);
#endif
#ifdef EM_PLUS_SUPPORT
	int (*drv_set_cfg_bw_proc)(void *drv_data, const char *ifname, u32 bw);
	int (*drv_set_acs_ch_list)(void *drv_data, const char *ifname,
					struct acs_ch_config_info *ch_info);
	int (*drv_set_acs_partial_scan)(void *drv_data, const char *ifname, u8 partial_scan_flag);
	int (*drv_set_acs_scan_ch_num)(void *drv_data, const char *ifname, u8 ch_scan_num);
	int (*drv_set_acs_ch_util_thresold)(void *drv_data, const char *ifname, u8 ch_util);
	int (*drv_set_acs_sta_thresold)(void *drv_data, const char *ifname, u16 sta_num_thr);
	int (*drv_set_acs_scan_dwell)(void *drv_data, const char *ifname, u16 ch_scan_dwell);
	int (*drv_set_acs_restore_dwell)(void *drv_data, const char *ifname, u16 ch_restore_dwell);
	int (*drv_set_acs_ch_check_time)(void *drv_data, const char *ifname, u32 ch_check_time);
	int (*drv_set_acs_ch_checktime_trigger)(void *drv_data, const char *ifname, u8 trigger_flag,
			u32 ch_check_time);
	int (*drv_set_acs_ch_6g_psc)(void *drv_data, const char *ifname, u8 ch_6g_psc);
#endif /* EM_PLUS_SUPPORT */
	int (*drv_set_hidden_ssid)(void *drv_data, const char *ifname, u8 hidden_ssid);
	int (*drv_set_auth_mode)(void *drv_data, const char *ifname, char *buf);
	int (*drv_set_encrypt_type)(void *drv_data, const char *ifname, char *buf);
	int (*drv_set_default_key_id)(void *drv_data, const char *ifname, u8 id);
	int (*drv_set_key1)(void *drv_data, const char *ifname, char *buf);
	int (*drv_set_wpapsk)(void *drv_data, const char *ifname, char *buf);
	int (*drv_set_raido_on)(void *drv_data, const char *ifname, int onoff);
	int (*drv_set_DisConnectSta)(void *drv_data, const char *ifname, unsigned char *sta_addr);
	int (*drv_set_ts_bh_primary_vid)(void *drv_data, const char *ifname, unsigned short vid);
	int (*drv_set_ts_bh_primary_pcp)(void *drv_data, const char *ifname, unsigned char pcp);
	int (*drv_set_ts_bh_vid)(void *drv_data, const char *ifname, char *buf, size_t buf_len);
	int (*drv_set_ts_fh_vid)(void *drv_data, const char *ifname, unsigned short vid);
	int (*drv_set_transparent_vid)(void *drv_data, const char *ifname, char *buf, size_t buf_len);
	int (*drv_set_BcnReq)(void *drv_data, const char *ifname, char *buf);
	int (*drv_set_HtBssCoex)(void *drv_data, const char *ifname, char enable);
	int (*drv_set_PMFMFPC)(void *drv_data, const char *ifname, char enable);
	int (*drv_set_AutoRoaming)(void *drv_data, const char *ifname, char enable);
	int (*drv_set_DSCPPolicyEnable)(void *drv_data, const char *ifname, char enable);
	int (*drv_set_QosMapCapa)(void *drv_data, const char *ifname, char enable);
	int (*drv_set_ScanType)(void *drv_data, const char *ifname, char *type);
	int (*drv_set_ScanClear)(void *drv_data, const char *ifname);
#ifdef DPP_SUPPORT
	int (*drv_set_pmk)(void *drv_data, const char *ifname,
                     const u8 *pmk, size_t pmk_len, const u8 *pmkid,
                     const u8 *aa, const u8 *spa, int session_timeout,
                     int akmp, u8 *ssid, size_t ssid_len);
	int (*drv_get_dpp_frame)(void *drv_data, const char *ifname, char *assoc_data, size_t length);
#endif /*DPP_SUPPORT*/
#ifdef MAP_R3
	int (*drv_reset_cce_ie)(void *drv_data, const char *ifname);
	int (*drv_agnt_dpp_uri)(void *drv_data, const char *ifname, char *buf);
	int (*drv_set_1905_sec)(void *drv_data, const char *ifname, const u8 flag);
	int (*drv_set_onboarding_type)(void *drv_data, const char *ifname, const u8 flag);
#endif /* MAP_R3 */
#ifdef MAP_R3_WF6
	int (*drv_get_wf6_cap)(void *drv_data, const char *ifname, char *buf,
			size_t *buf_len);
#endif /*MAP_R3_WF6*/

#ifdef QOS_R1
	int (*drv_send_up_tuple_expired)(void *drv_data, const char *ifname, char *buf, u32 buflen);
#ifdef QOS_R2
	int (*drv_get_pmk_by_peermac)(void *drv_data, const char *ifname, char *buf, int *length);
#endif
#ifdef QOS_R3
	int (*drv_set_qos_characteristics_ie)(void *drv_data, const char *ifname, char *buf, u32 buflen);
#endif
#ifdef MAP_R5
	int (*drv_reset_dscp2up_table)(void *drv_data, const char *ifname, char enable);
#endif
#endif
#ifdef EPCS_SUPPORT
	int (*drv_sync_epcs_state)(void *drv_data, const char *ifname, char *buf, u32 buflen);
#endif
#ifdef MAP_R6
	int (*drv_set_no_bcn)(void *drv_data, const char *ifname, char enable);
#endif /* MAP_R6 */
#ifdef MAP_R4_SPT
	int (*drv_get_spt_reuse_req)(void *drv_data, const char *ifname, char *buf,
			size_t *buf_len);
	int (*drv_set_bss_color)(void *drv_data, const char *ifname, char *buf,
			size_t buf_len);
	int (*drv_set_bh_bitmap)(void *drv_data, const char *ifname, char *buf,
		size_t buf_len);
	int (*drv_set_sr_enable)(void *drv_data, const char *ifname, char enable);
#endif
	int (*drv_set_air_mnt_en)(void *drv_data, const char *ifname, const u8 flag);
	int (*drv_set_air_mnt_rule)(void *drv_data, const char *ifname, const char *buf,
			size_t buf_len);
	int (*drv_set_air_mnt_sta_id)(void *drv_data, const char *ifname, const u8 id,
			const char *sta_mac);
	int (*drv_set_air_mnt_max_pkt)(void *drv_data, const char *ifname, const u32 pkt_num);
	int (*drv_get_air_mnt_result)(void *drv_data, const char *ifname, char *buf,
			size_t *buf_len);
	int (*drv_set_map_ch)(void *drv_data, const char *ifname, const u8 ch
#ifdef MAP_R2
		, const u8 cac_req, const u8 dev_role
#endif /* MAP_R2 */
	);
#ifdef MAP_R6
	int (*drv_set_mlo_switch)(void *drv_data, const char *ifname, const u8 mlo_en);
	int (*drv_set_t2lm_mapping)(void *drv_data, const char *ifname, char *buf, u32 buflen);
#endif
	int (*drv_set_static_punc_dscb)(void *drv_data, const char *ifname, const u16 punc_bitmap);
#ifdef CSA_BAND_SUPPORT
	int (*drv_set_2g_csa_support)(void *drv_data, const char *ifname, const u8 csa_2g_support);
	int (*drv_set_csa_support)(void *drv_data, const char *ifname, const u8 csa_support);
#endif
	int (*drv_set_map_enable)(void *drv_data, const char *ifname, const u8 map_en);
	int (*drv_set_ap_fhbss)(void *drv_data, const char *ifname, const u8 fh_en);
	int (*drv_set_ap_bhbss)(void *drv_data, const char *ifname, const u8 bh_en);
	int (*drv_set_ap_v10converter)(void *drv_data, const char *ifname, const u8 v_en);
	int (*drv_set_approxyrefresh)(void *drv_data, const char *ifname, const u8 proxy_en);
	int (*drv_send_ap_intf_enable)(void *drv_data, const char *ifname);
	int (*drv_send_ap_intf_disable)(void *drv_data, const char *ifname);
	int (*drv_send_sta_deauth)(void *drv_data, const char *ifname, char *sta_mac);
	int (*drv_send_remove_network)(void *drv_data, const char *ifname);
	int (*drv_send_hide_ssid)(void *drv_data, const char *ifname,  int enable);
	int (*drv_send_disable_network)(void *drv_data, const char *ifname, int network_id);
	int (*drv_send_enable_network)(void *drv_data, const char *ifname, int network_id);
	int (*drv_send_network_bssid)(void *drv_data, const char *ifname, int network_id, const char *bssid);
	int (*drv_send_add_network)(void *drv_data, const char *ifname);
	int (*drv_send_network_key)(void *drv_data, const char *ifname, int network_id, const char *key);
	int (*drv_send_network_keymgmt)(void *drv_data, const char *ifname, int network_id, const char *keymgmt);
	int (*drv_send_sae_pwd)(void *drv_data, const char *ifname, int network_id, const char *pwd);
	int (*drv_send_wep_key)(void *drv_data, const char *ifname, int network_id, int key_idx, const char *key);
	int (*drv_send_save_config)(void *drv_data, const char *ifname);
	int (*drv_set_scan_ssid)(void *drv_data, const char *ifname, int network_id, int enable);
	int (*drv_send_wps_pbc)(void *drv_data, const char *ifname, int map_enable);
	int (*drv_send_config_update)(void *drv_data, const char *ifname);
	int (*drv_send_reload)(void *drv_data, const char *ifname);
	int (*drv_send_ap_intf_stop)(void *drv_data, const char *ifname);
#ifdef MTK_HOSTAPD_SUPPORT
	int (*drv_set_dpp_peermac)(void *drv_data, const char *iface,
			struct dpp_authentication *auth);
	int (*drv_set_ap_pmk_hapd)(void *drv_data, const char *ifname,
			const u8 *sta_mac, const u8 *pmkid, const u8 *pmk,
			size_t pmk_len, int expiry, int akmp);
	int (*drv_set_sta_pmk_supp)(void *drv_data, const char *ifname,
			const u8 nw_id, const u8 *bssid, const u8 *pmkid,
			const u8 *pmk, size_t pmk_len, int reauth,
			int expiry, int akmp, int opportunistic);
	int (*drv_send_select_network)(void *drv_data, const char *ifname, int network_id, int frequency);
	int (*drv_send_bss_flush)(void *drv_data, const char *ifname);
	int (*drv_send_update_bridge)(void *drv_data, const char *ifname,
			u8 update_flag, const char *br_name);
	int (*drv_send_get_pmk)(void *drv_data, const char *ifname, char *sta_mac, char *buf);
#ifdef MAP_R6 /* GERNERIC_R6 */
	int (*drv_send_network_pairwise)(void *drv_data, const char *ifname, int network_id, const char *pairwise);
	int (*drv_send_network_group)(void *drv_data, const char *ifname, int network_id, const char *group);
	int (*drv_send_network_grpmgmt)(void *drv_data, const char *ifname, int network_id, const char *grpmgmt);
	int (*drv_send_beacon_prot)(void *drv_data, const char *ifname, int network_id, u8 beacon_prot);
#endif /* MAP_R6 */
#endif
	int (*drv_set_BhAssocCtrl)(void *drv_data, const char *ifname, char *buf, size_t *buf_len);
	int (*drv_set_mld_link_del)(void *drv_data, const char *ifname, u8 mld_id);
#ifdef MAP_R6
	int (*drv_set_mld_link_reconfig)(void *drv_data, const char *ifname, u8 mld_id, u16 reconfig_to);
#endif /* MAP_R6 */
	int (*drv_set_mld_link_add)(void *drv_data, const char *ifname, u8 mld_id, u16 is_reconfig);
	int (*drv_set_mld_group_delete)(void *drv_data, const char *ifname, u8 mld_id);
	int (*drv_set_mld_group_create)(void *drv_data, const char *ifname, u8 mld_group_idx, const u8 *mld_addr, u8 mld_type);
	int (*drv_set_mld_link_transfer)(void *drv_data, const char *ifname, u8 mld_id);
	int (*drv_send_ap_intf_add)(void *drv_data, const char *ifname, const char *ifname_prim);
#ifdef DFS_SLAVE_SUPPORT
	int (*drv_update_BhStatus)(void *drv_data, const char *ifname, char *buf, size_t buf_len);
#endif /* DFS_SLAVE_SUPPORT */
	int (*drv_get_radio_cpu_temperature)(void *drv_data, const char *ifname, char *buf,
								size_t *buf_len);
	int (*drv_send_t2lm_request)(void *drv_data, const char *ifname, char *buf, u32 buflen);
#ifdef MAP_VENDOR_SUPPORT
	int (*drv_set_vendor_nop_state)(void *drv_data, const char *ifname, char *buf, size_t *len);
	int (*drv_set_vendor_ch_pref_state)(void *drv_data, const char *ifname, char *buf, size_t *len);
#endif /* MAP_VENDOR_SUPPORT */
};

struct hotspot_drv_ops {
	int (*drv_test)(void *drv_data, const char *ifname);

	int (*drv_hotspot_onoff)(void *drv_data, const char *ifname,
                             int enable, int event_trigger, int event_type);

	int (*drv_hs_param_setting)(void *drv_data, const char *ifname, u32 param, u32 value);

	int (*drv_ipv4_proxy_arp_list)(void *drv_data, const char *ifname,
							  	   char *proxy_arp_list, size_t *proxy_arp_list_len);

	int (*drv_ipv6_proxy_arp_list)(void *drv_data, const char *ifname,
							  	   char *proxy_arp_list, size_t *proxy_arp_list_len);
	int (*drv_validate_security_type)(void *drv_data, const char *ifname);
	int (*drv_reset_resource)(void *drv_data, const char *ifname);
	int (*drv_get_bssid)(void *drv_data, const char *ifname, char *bssid, size_t *bssid_len);
	int (*drv_get_osu_ssid)(void *drv_data, const char *ifname, char *ssid, size_t *ssid_len);
	int (*drv_set_osu_asan)(void *drv_data, const char *ifname, char *enable, size_t len);

	int (*drv_send_qosmap_configure)(void *drv_data, const char *ifname,
							const char *peer_sta_addr, const char *qosmap, size_t qosmap_len);
	int (*drv_set_bss_load)(void *drv_data, const char *ifname, char *buf, size_t len);

};

struct mbo_drv_ops {
	int (*drv_mbo_param_setting)(void *drv_data, const char *ifname, u32 param, u32 value);
};

#endif /* __DRIVER_H__ */
