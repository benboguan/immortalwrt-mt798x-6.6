/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2020-2021  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#include <stdlib.h>
#include <stdio.h>
#include <linux/netlink.h>

#include "types.h"
#include "wapp_cmm.h"
#include "cosr.h"
#include "driver_wext.h"
#include "mtk_vendor_nl80211.h"
#include "rt_config.h"

#include "utils/wpabuf.h"
#include "utils/base64.h"
#include "utils/wpa_debug.h"
#include "util.h"

/* send beacon ie to driver */
int wapp_set_cosr_ie(struct wifi_app *wapp, const char *iface, char *ie, size_t ie_len)
{
	int ret = 0;

	ret = wapp->drv_ops->drv_set_cosr_ie(wapp->drv_data, iface, ie, ie_len);

	return ret;
}

/* send cosr_stainfo to driver */
int wapp_cosr_stainfo_send(struct wifi_app *wapp, const char *iface, struct cosr_info_set *req)
{
	int ret;

	ret = wapp->drv_ops->drv_wapp_set_cosr_stainfo(wapp->drv_data, iface, req);
	if (!ret)
		return WAPP_UNEXP;

	return ret;
}

/* send cosr ap info to driver */
int wapp_cosr_apinfo_send(struct wifi_app *wapp, const char *iface, struct cosr_info_set *req)
{
	int ret;

	ret = wapp->drv_ops->drv_wapp_set_cosr_apinfo(wapp->drv_data, iface, req);
	if (!ret)
		return WAPP_UNEXP;

	return ret;
}

int wapp_drv_send_cosr_action(struct wifi_app *wapp, struct wapp_dev *wdev, unsigned int chan,
		unsigned int wait, const u8 *dst, const u8 *data, size_t len)
{
	const u8 *bssid;
	u16 cosr_frame_seq_no = 1011;

	if (!wapp->drv_ops || !wapp->drv_ops->send_action)
		return WAPP_NOT_INITIALIZED;

	if (!wdev || !wdev->radio) {
		err(DEBUG_CAT_COSR, "wdev is null\n");
		return WAPP_NOT_INITIALIZED;
	}

	if (chan == 0)
		chan = wdev->radio->op_ch;

	/* All the COSR frames are sent in non connected state
	 * Set BSSID as always wildcard
	 */
	bssid = BROADCAST;

	if (os_memcmp(dst, BROADCAST, MAC_ADDR_LEN) != 0)
		cosr_frame_seq_no++;

	return wapp->drv_ops->send_action(MTK_NL80211_VENDOR_ATTR_SET_ACTION_COSR_ACTION_FRAME,
			wapp->drv_data, wdev->ifname, chan, wait, dst,
			wdev->mac_addr, bssid, data, len, cosr_frame_seq_no, 0);
}

void cosr_system_cmd_w_if(struct wifi_app *wapp, int type, char *ifname)
{
	struct wapp_dev *wdev = NULL;

	wdev = wapp_dev_list_lookup_by_ifname(wapp, ifname);
	if (!wdev) {
		err(DEBUG_CAT_COSR, "wdev for ifname:%s not found\n", ifname);
		return;
	}

	debug(DEBUG_CAT_COSR, "COSR type = %d %s\n", type, ifname);
	switch (type) {
	case COSR_SET_ENABLE:
		os_execute("mwctl", 3, ifname, "set", "CSREnable=1");
		break;
	case COSR_SET_DISABLE:
		os_execute("mwctl", 3, ifname, "set", "CSREnable=0");
		break;
	case COSR_AP_INFO:
		/* init cosr ap info, just clear candlist ap*/
		cosr_ap_clear_candlist_ap_per_band(wapp, wdev);
		break;
	case COSR_AP_INFO_RST:
		cosr_ap_clear_candlist_ap_per_band(wapp, wdev);
		os_execute("mwctl", 3, ifname, "set", "CSRCoordAPInfoRst=0-255");
		break;
	case COSR_STA_INFO:
		/* clear candlist sta */
		/* TBD */
		break;
	case COSR_STA_INFO_RST:
		os_execute("mwctl", 3, ifname, "set", "CSRStaInfoRst=1-255");
		break;
	case COSR_SR_DISABLE:
		os_execute("mwctl", 3, ifname, "set", "srcfgsren=0");
		break;
	case COSR_SCS_DISABLE:
		os_execute("mwctl", 3, ifname, "set", "scsenable=0");
		break;
	default:
		err(DEBUG_CAT_COSR, "%s Unknown Type.\n", ifname);
		break;
	}
}

int cosr_set_bcn_ie(struct wifi_app *wapp, struct wapp_dev *wdev)
{
	struct cosr_bcn_info *ie;
	char *buf;
	int ie_len = 0;

	ie_len = sizeof(struct cosr_bcn_info);
	buf = os_zalloc(ie_len);
	if (!buf) {
		err(DEBUG_CAT_COSR, "allocated memory failed\n");
		os_free(buf);
		return WAPP_UNEXP;
	}

	ie = (struct cosr_bcn_info *)buf;
	ie->eid = COSR_VENDOR_SPECIFIC;
	ie->length = COSR_IE_LEN;

	ie->oui[0] = COSR_OUI_0;
	ie->oui[1] = COSR_OUI_1;
	ie->oui[2] = COSR_OUI_2;
	ie->value = COSR_OUI_VALUE;

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		if (wapp_set_cosr_ie(wapp, wdev->ifname, buf, ie_len) < 0) {
			err(DEBUG_CAT_COSR, "set cosr bcn info failed\n");
			os_free(buf);
			return WAPP_UNEXP;
		}
	}
	if (ie)
		os_free(ie);
	return WAPP_SUCCESS;
}

unsigned char cosr_get_bandidx(struct wifi_app *wapp, struct wapp_dev *wdev)
{
	u8 band = 0;
	u8 bandidx = 0xFF;

	if (!wdev || !wdev->radio) {
		err(DEBUG_CAT_COSR, "NULL return\n");
		return bandidx;
	}

	if (wdev->radio->radio_band) {
		band = (*wdev->radio->radio_band);
		if (band == WPS_BAND_24G)
			bandidx = 0;
		else if ((band == WPS_BAND_5GL) ||
			(band == WPS_BAND_5GH) ||
			(band == WPS_BAND_5G))
			bandidx = 1;
#ifdef MAP_6E_SUPPORT
		else if (band == WPS_BAND_6G)
			bandidx = 2;
#endif
	}
	return bandidx;
}


int hapd_rrm_send_bcn_req_param_for_cosr(struct wifi_app *wapp, const char *ifname,
		unsigned char subelem_num, p_bcn_req_info p_beacon_req,
		u32 param_len)
{
	struct wpabuf *buf = NULL;
	unsigned int bcn_req_len = 0;

	buf = wpabuf_alloc(param_len + (subelem_num*2));
	if (!buf)
		return -1;

	wpabuf_put_u8(buf, p_beacon_req->regclass);
	bcn_req_len += 1;
	wpabuf_put_u8(buf, p_beacon_req->channum);
	bcn_req_len += 1;
	wpabuf_put_le16(buf, p_beacon_req->random_ivl); /* Randomization Interval */
	bcn_req_len += 2;
	wpabuf_put_le16(buf, p_beacon_req->duration); /* Measurement Duration */
	bcn_req_len += 2;
	wpabuf_put_u8(buf, p_beacon_req->mode); /* Measurement Mode */
	bcn_req_len += 1;
	wpabuf_put_data(buf, &p_beacon_req->bssid, MAC_ADDR_LEN); /* BSSID */
	bcn_req_len += MAC_ADDR_LEN;

	/* Optinal Elements for Beacon req */
	/* SSID */
	wpabuf_put_u8(buf, RRM_BCN_REQ_SUBID_SSID);
	wpabuf_put_u8(buf, p_beacon_req->req_ssid_len);
	wpabuf_put_data(buf, p_beacon_req->req_ssid, p_beacon_req->req_ssid_len);
	bcn_req_len += (p_beacon_req->req_ssid_len + 2);

	/* Beacon Reporting Information */
	wpabuf_put_u8(buf, RRM_BCN_REQ_SUBID_BCN_REP_INFO);
	wpabuf_put_u8(buf, 2);
	wpabuf_put_u8(buf, p_beacon_req->rep_conditon);
	wpabuf_put_u8(buf, p_beacon_req->ref_value);
	bcn_req_len += (2 + 2);

	/* Reporting Detail */
	wpabuf_put_u8(buf, RRM_BCN_REQ_SUBID_RET_DETAIL);
	wpabuf_put_u8(buf, 1);
	wpabuf_put_u8(buf, p_beacon_req->detail);
	bcn_req_len += (2 + 1);

	if (p_beacon_req->detail == 1) {
		/* Request */
		wpabuf_put_u8(buf, RRM_BCN_REQ_SUBID_REQUEST);
		wpabuf_put_u8(buf, p_beacon_req->request_len);
		wpabuf_put_data(buf, &p_beacon_req->request, p_beacon_req->request_len);
		bcn_req_len += (p_beacon_req->request_len + 2);
	}

	if (p_beacon_req->channum == 255) {
		/* AP channel report */
		unsigned char ap_ch_rpt_len = 0;
		/* Op class and channel list len */
		ap_ch_rpt_len = 1 + p_beacon_req->ch_list_len;
		wpabuf_put_u8(buf, RRM_BCN_REQ_SUBID_AP_CH_REP);
		wpabuf_put_u8(buf, ap_ch_rpt_len);
		wpabuf_put_u8(buf, p_beacon_req->op_class_list[0]);
		wpabuf_put_data(buf, p_beacon_req->ch_list, p_beacon_req->ch_list_len);
		bcn_req_len += (p_beacon_req->ch_list_len + 1 + 2);
	}

	/* Send beacon request to Hostapd thorough NL interface */
	wapp_send_beacon_req(wapp, ifname, p_beacon_req->peer_address, 0, wpabuf_head(buf), bcn_req_len);

	wpabuf_free(buf);
	return WAPP_SUCCESS;
}

int cosr_trigger_bcn_req_by_lib(struct wifi_app *wapp, struct wapp_dev *wdev,
									struct cosr_bcn_req *info, u8 *dest_mac)
{
	p_bcn_req_info p_beacon_req_to_driver = NULL;
	unsigned char rrm_elem = 0, len = 0;

	p_beacon_req_to_driver = (p_bcn_req_info)os_zalloc(sizeof(struct bcn_req_info_s));
	if (!p_beacon_req_to_driver) {
		err(DEBUG_CAT_COSR, "Allocated bcn req info failed\n");
		os_free(p_beacon_req_to_driver);
		return WAPP_RESOURCE_ALLOC_FAIL;
	}

	os_memcpy(p_beacon_req_to_driver->peer_address, info->sta_mac, MAC_ADDR_LEN);
	p_beacon_req_to_driver->regclass = info->op_class;
	p_beacon_req_to_driver->channum = info->op_channel;
	p_beacon_req_to_driver->duration = info->meadur;
	p_beacon_req_to_driver->mode = info->meamode;
	os_memcpy(p_beacon_req_to_driver->bssid, dest_mac, MAC_ADDR_LEN);

	rrm_elem = 4;
	len = sizeof(*p_beacon_req_to_driver);

	debug(DEBUG_CAT_COSR, "Dest_mac "MACSTR" RegClass %d CH %d Dur %d Mode %d\n",
			MAC2STR(dest_mac),
			p_beacon_req_to_driver->regclass,
			p_beacon_req_to_driver->channum,
			p_beacon_req_to_driver->duration,
			p_beacon_req_to_driver->mode);

	hapd_rrm_send_bcn_req_param_for_cosr(wapp, wdev->ifname, rrm_elem, p_beacon_req_to_driver, len);

	os_free(p_beacon_req_to_driver);
	return WAPP_SUCCESS;
}

void cosr_trigger_own_bcn_req_timeout(void *eloop_ctx, void *timeout_ctx)
{
	struct wifi_app *wapp = (struct wifi_app *)eloop_ctx;
	struct wapp_sta *candlist_sta = (struct wapp_sta *)timeout_ctx;
	struct wapp_dev *wdev = NULL, *wdev_temp = NULL;
	struct cosr_ap_candlist_ap *candlist_ap;
	u8 u1Bandidx = 0;
	struct dl_list *dev_list;
	BOOLEAN fgNextTimeout = FALSE;

	dev_list = &wapp->dev_list;
	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
		if (wdev->dev_type != WAPP_DEV_TYPE_AP)
			continue;
		u1Bandidx = cosr_get_bandidx(wapp, wdev);
		if (wdev->ifindex != candlist_sta->ifindex)
			continue;
		if (u1Bandidx >= ARRAY_SIZE(wapp->candlist_ap))
			continue;
		candlist_ap = wapp->candlist_ap[u1Bandidx];
		while (candlist_ap) {
			debug(DEBUG_CAT_COSR, "STA MAC "MACSTR", APID %d Cli Meas State %d\n",
				MAC2STR(candlist_sta->mac_addr),
				candlist_ap->apid,
				candlist_sta->meas_data[candlist_ap->apid].cli_measurement_state);
			if (candlist_sta->meas_data[candlist_ap->apid].cli_measurement_state != WAIT_11K_OWN_MAC) {
				err(DEBUG_CAT_COSR, "NOT in WAIT Own MAC state!!\n");
				candlist_ap = candlist_ap->next;
				continue;
			}

			if (candlist_sta->meas_data[candlist_ap->apid].measurement_retries_11k < COSR_MAX_11K_RETRIES) {
				candlist_sta->meas_data[candlist_ap->apid].measurement_retries_11k++;
				err(DEBUG_CAT_COSR, "11k Retry(%d) on channel %d\n",
				candlist_sta->meas_data[candlist_ap->apid].measurement_retries_11k, wdev->radio->op_ch);
				fgNextTimeout = TRUE;
			} else {
				candlist_sta->meas_data[candlist_ap->apid].measurement_retries_11k = 0;
				candlist_sta->meas_data[candlist_ap->apid].cli_measurement_state = WAIT_11K_FAIL;
				candlist_sta->meas_data[candlist_ap->apid].fg11k_support_fail = TRUE;
			}

			candlist_ap = candlist_ap->next;
		}

		if (fgNextTimeout == TRUE) {
			cosr_trigger_own_bcn_meas(wapp, wdev, candlist_sta);
			eloop_register_timeout(COSR_11K_WAIT_TIME, 0,
				cosr_trigger_own_bcn_req_timeout, wapp, candlist_sta);
		}
	}
}

void cosr_trigger_bcn_req_timeout(void *eloop_ctx, void *timeout_ctx)
{
	struct wifi_app *wapp = (struct wifi_app *)eloop_ctx;
	struct wapp_sta *sta = (struct wapp_sta *)timeout_ctx;
	struct wapp_dev *wdev = NULL, *wdev_temp = NULL;
	struct cosr_ap_candlist_ap *e;
	u8 u1Bandidx = 0;
	BOOLEAN fgNextTimeout = FALSE;
	struct dl_list *dev_list;


	dev_list = &wapp->dev_list;
	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
		if (wdev->dev_type != WAPP_DEV_TYPE_AP)
			continue;

		u1Bandidx = cosr_get_bandidx(wapp, wdev);
		if (wdev->ifindex != sta->ifindex)
			continue;
		if (u1Bandidx >= ARRAY_SIZE(wapp->candlist_ap))
			continue;
		e = wapp->candlist_ap[u1Bandidx];
		while (e) {
			debug(DEBUG_CAT_COSR, "STA MAC "MACSTR", APID %d Cli Meas State %d\n",
					MAC2STR(sta->mac_addr),
					e->apid,
					sta->meas_data[e->apid].cli_measurement_state);
			if (sta->meas_data[e->apid].cli_measurement_state != WAIT_11K_RESULT) {
				err(DEBUG_CAT_COSR, "NOT in WAIT RESULT state!!\n");
				e = e->next;
				continue;
			}

			if (sta->meas_data[e->apid].measurement_retries_11k < COSR_MAX_11K_RETRIES) {
				sta->meas_data[e->apid].measurement_retries_11k++;
				err(DEBUG_CAT_COSR, "11k Retry(%d) on channel %d\n",
					sta->meas_data[e->apid].measurement_retries_11k, wdev->radio->op_ch);
				cosr_trigger_bcn_meas(wapp, wdev, sta, e);
				fgNextTimeout = TRUE;
				e = e->next;
				continue;
			}

			sta->meas_data[e->apid].cli_measurement_state = WAIT_11K_FAIL;
			sta->meas_data[e->apid].measurement_retries_11k = 0;
			sta->meas_data[e->apid].fg11k_support_fail = TRUE;
			e = e->next;
		}

		if (fgNextTimeout == TRUE && cosr_ap_candlist_ap_count_per_band(wapp, wdev) > 0)
			eloop_register_timeout(COSR_11K_WAIT_TIME, 0, cosr_trigger_bcn_req_timeout, wapp, sta);
	}

}

int cosr_trigger_own_bcn_meas(struct wifi_app *wapp, struct wapp_dev *wdev, struct wapp_sta *sta)
{
	struct cosr_ap_candlist_ap *eAp = NULL;

	struct cosr_bcn_req *info;
	u8 u1Bandidx = 0;
	u8 *mac_addr = sta->mac_addr;

	err(DEBUG_CAT_COSR, "WDEV "MACSTR", STA MAC "MACSTR", STA BSSID "MACSTR"\n",
			MAC2STR(wdev->mac_addr), MAC2STR(sta->mac_addr), MAC2STR(sta->bssid));
	info = os_zalloc(sizeof(struct cosr_bcn_req));
	if (!info) {
		os_free(info);
		return WAPP_UNEXP;
	}

	/* setting by the driver value */
	info->meadur = 50;
	info->meamode = 1;
	info->randint = 10;
	info->op_channel = wdev->radio->op_ch;
	os_memcpy(info->sta_mac, mac_addr, MAC_ADDR_LEN);
	if (cosr_ap_candlist_ap_count_per_band(wapp, wdev) <= 0) {
		err(DEBUG_CAT_COSR, "cosr candlist ap not exit\n");
		os_free(info);
		return WAPP_UNEXP;
	}
	u1Bandidx = cosr_get_bandidx(wapp, wdev);
	if (u1Bandidx == 0xFF) {
		os_free(info);
		return WAPP_UNEXP;
	}

	eAp = wapp->candlist_ap[u1Bandidx];
	if (!eAp) {
		os_free(info);
		return WAPP_UNEXP;
	}

	if (cosr_get_bcn_reportlist(wapp, wdev->mac_addr, mac_addr) == NULL) {
		debug(DEBUG_CAT_COSR, "Trigger candlist ap "MACSTR" 11K MEAS\n", MAC2STR(wdev->mac_addr));
		cosr_trigger_bcn_req_by_lib(wapp, wdev, info, wdev->mac_addr);
		/* update per STA mapping AP state to Wait11kOwnMac measuring */
		while (eAp) {
			sta->meas_data[eAp->apid].cli_measurement_state = WAIT_11K_OWN_MAC;
			eAp = eAp->next;
		}
	}

	os_free(info);
	return WAPP_SUCCESS;
}


int cosr_trigger_bcn_meas(struct wifi_app *wapp, struct wapp_dev *wdev,
			struct wapp_sta *sta, struct cosr_ap_candlist_ap *eAp)
{
	struct cosr_bcn_req *info;
	u8 u1Bandidx = 0;
	u8 *mac_addr = sta->mac_addr;

	debug(DEBUG_CAT_COSR, "WDEV "MACSTR", STA MAC "MACSTR", STA BSSID "MACSTR"\n",
			MAC2STR(wdev->mac_addr), MAC2STR(sta->mac_addr), MAC2STR(sta->bssid));

	info = os_zalloc(sizeof(struct cosr_bcn_req));
	if (!info) {
		os_free(info);
		return WAPP_UNEXP;
	}

	/* setting by the driver value */
	info->meadur = 50;
	info->meamode = 1;
	info->randint = 10;
	info->op_channel = wdev->radio->op_ch;
	os_memcpy(info->sta_mac, mac_addr, MAC_ADDR_LEN);

	if (cosr_ap_candlist_ap_count_per_band(wapp, wdev) <= 0) {
		err(DEBUG_CAT_COSR, "cosr candlist ap not exit\n");
		os_free(info);
		return WAPP_UNEXP;
	}

	u1Bandidx = cosr_get_bandidx(wapp, wdev);
	if (u1Bandidx == 0xFF) {
		os_free(info);
		return WAPP_UNEXP;
	}
	/* trigger 11k measure for candlist ap*/
	if (cosr_ap_get_candlist_per_band(wapp, wdev, eAp->bssid) != NULL) {
		if (cosr_get_bcn_reportlist(wapp, eAp->bssid, mac_addr) == NULL) {
			debug(DEBUG_CAT_COSR, "Trigger candlist ap "MACSTR" 11K MEAS\n", MAC2STR(eAp->bssid));
			if (sta->meas_data[eAp->apid].fg11k_support_fail == FALSE) {
				cosr_trigger_bcn_req_by_lib(wapp, wdev, info, eAp->bssid);
				sta->meas_data[eAp->apid].cli_measurement_state = WAIT_11K_RESULT;
			}
		}
	}

	os_free(info);
	return WAPP_SUCCESS;
}


int cosr_handle_beacon_report(struct wifi_app *wapp, struct wapp_dev *wdev,
					u8 rcpi, u8 *mac_addr, u8 *bssid, u8 isSuccess)
{
	struct cosr_bcn_report_list *dl_rssi;
	struct cosr_ap_candlist_ap *e;
	struct wapp_sta *candlist_sta = NULL;
	struct ap_dev *ap = NULL;
	int report_count = 0;
	u8 u1Bandidx = 0;

	if (!wapp || !wdev || !mac_addr || !bssid) {
		err(DEBUG_CAT_COSR, "unexpect arg\n");
		return WAPP_UNEXP;
	}
	ap = (struct ap_dev *)wdev->p_dev;
	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		candlist_sta = cosr_get_candlist_sta(wapp, wdev, mac_addr);
		if (!candlist_sta)
			return WAPP_UNEXP;
	} else
		return WAPP_UNEXP;

	u1Bandidx = cosr_get_bandidx(wapp, wdev);
	if (u1Bandidx == 0xFF)
		return WAPP_UNEXP;
	if (!isSuccess) {
		err(DEBUG_CAT_COSR, "cosr bcn req Failed\n");
		return WAPP_UNEXP;
	}

	notice(DEBUG_CAT_COSR, "11k Success for channel %d, MAC Addr "MACSTR"\n",
		ap->ch_info.op_ch, MAC2STR(mac_addr));

	/* If beacon report is from own BSSID */
	if (os_memcmp(wdev->mac_addr, bssid, MAC_ADDR_LEN) == 0) {
		err(DEBUG_CAT_COSR, "Own BSSID\n");
		e = wapp->candlist_ap[u1Bandidx];
		while (e) {
			candlist_sta->meas_data[e->apid].measurement_retries_11k = 0;
			e = e->next;
		}
		report_count = cosr_add_bcn_reportlist(wapp, bssid, mac_addr, rcpi);
		if (report_count > 1) {
			dl_rssi = cosr_update_bcn_reportlist(wapp, bssid, mac_addr, rcpi);
			if (dl_rssi == NULL)
				return WAPP_UNEXP;
		}
	} else {
		/* If beacon report is from neighbor BSSID */
		e = cosr_ap_get_candlist_per_band(wapp, wdev, bssid);
		if (!e) {
			err(DEBUG_CAT_COSR, "cosr bcn req Failed\n");
			return WAPP_UNEXP;
		}

		candlist_sta->meas_data[e->apid].measurement_retries_11k = 0;

		report_count = cosr_add_bcn_reportlist(wapp, bssid, mac_addr, rcpi);
		if (report_count > 1) {
			dl_rssi = cosr_update_bcn_reportlist(wapp, bssid, mac_addr, rcpi);
			if (dl_rssi == NULL)
				return WAPP_UNEXP;
		}
	}

	return WAPP_SUCCESS;

}

int hostapd_cosr_handle_beacon_report(struct wifi_app *wapp, u16 data_len, char *data)
{
	struct cosr_beacon_rsp *bcn_rpt;
	struct cosr_beacon_rep_info *pBcnRep = NULL;
	struct cosr_bcn_report_list *own_dev_result;
	struct COSR_EID_STRUCT *eid_ptr = NULL;
	struct wapp_dev *wdev = NULL;
	char *buf = NULL;
	unsigned short parse_len = 0;
	int isSuccess = 1;
	int bcnrpt_cnt = 0;
	BOOLEAN fgInvalidBcnRpt = FALSE;

	buf = os_zalloc(data_len);
	if (buf == NULL) {
		err(DEBUG_CAT_COSR, "%s Alloc memory failed !\n", __func__);
		return WAPP_UNEXP;
	}
	os_memcpy(buf, data, data_len);
	bcn_rpt = (struct cosr_beacon_rsp *)buf;

	wdev = wdev_sta_lookup_for_all_bss_cosr(wapp, bcn_rpt->sta_mac);
	if (!wdev || wdev->dev_type != WAPP_DEV_TYPE_AP) {
		err(DEBUG_CAT_COSR, "wdev not found or dev type is not AP.\n");
		os_free(buf);
		return WAPP_LOOKUP_ENTRY_NOT_FOUND;
	}

	if (bcn_rpt->rpt_len == 0 || bcn_rpt->bcn_rpt_num == 0) {
		isSuccess = 0;
		fgInvalidBcnRpt = TRUE;
		err(DEBUG_CAT_COSR, "BSSID " MACSTR "Invalid Beacon Report num:%d len:%d\n",
			MAC2STR(bcn_rpt->sta_mac), bcn_rpt->bcn_rpt_num, bcn_rpt->rpt_len);
	}

	notice(DEBUG_CAT_COSR, "From " MACSTR " Num=%d len = %d\n",
				MAC2STR(bcn_rpt->sta_mac), bcn_rpt->bcn_rpt_num, bcn_rpt->rpt_len);

	if (bcn_rpt->rpt_len > 0) {
		eid_ptr = (struct COSR_EID_STRUCT *)bcn_rpt->rpt;
		parse_len = sizeof(struct cosr_beacon_rsp);
		while ((parse_len + eid_ptr->Len + 2) <= data_len) {
			switch (eid_ptr->Eid) {
			case IE_MEASUREMENT_REPORT:
				if (eid_ptr->Len - 3 > 0) {
					pBcnRep = (struct cosr_beacon_rep_info *)((u8 *)eid_ptr->Octet + 3);

					bcnrpt_cnt++;
					notice(DEBUG_CAT_COSR,
						"bcn_rpt_cnt:%d,Chan No:%d,rcpi:%d,bssid:"MACSTR"\n",
						bcnrpt_cnt, pBcnRep->ch_number,
						pBcnRep->rcpi, MAC2STR(pBcnRep->bssid));

					if (cosr_handle_beacon_report(wapp, wdev, pBcnRep->rcpi,
						bcn_rpt->sta_mac, pBcnRep->bssid, isSuccess) != WAPP_SUCCESS)
						fgInvalidBcnRpt = TRUE;
				} else {
					isSuccess = 0;
					fgInvalidBcnRpt = TRUE;
					err(DEBUG_CAT_COSR, "cosr beacon report len is Invalid\n");
				}
				break;
			default:
				break;
			}
			debug(DEBUG_CAT_COSR, "parse_len:%u, eid_ptr->Len:%d\n"
						"tlv_msg->length:%u, bcn_rpt->rpt_len:%u\n",
						parse_len, eid_ptr->Len, data_len, bcn_rpt->rpt_len);

			parse_len += 2 + eid_ptr->Len;
			if (parse_len >= data_len) {
				notice(DEBUG_CAT_COSR,	" parse beacon resp done\n");
				break;
			}
			eid_ptr = (struct COSR_EID_STRUCT *)((u8 *)eid_ptr + 2 + eid_ptr->Len);
		}
	}

	if (fgInvalidBcnRpt == TRUE) {
		/* For Invalid Beacon Report, Due to unknown report information, don''t do anything */
		err(DEBUG_CAT_COSR, "Get Beacon report is invalid.\n");
	} else {
		own_dev_result = cosr_get_bcn_reportlist(wapp, wdev->mac_addr, bcn_rpt->sta_mac);
		if (own_dev_result)
			cosr_record_bcn_own_mac(wapp, wdev, bcn_rpt->sta_mac, own_dev_result);
		else
			cosr_cal_bcn_report_pathdiff(wapp, wdev, bcn_rpt->sta_mac);
	}

	if (pBcnRep && bcn_rpt)
		cosr_del_report_list(wapp, pBcnRep->bssid, bcn_rpt->sta_mac);
	else
		err(DEBUG_CAT_COSR, "pBcnRep or bcn_rpt is NULL =====\n");

	os_free(buf);
	return WAPP_SUCCESS;
}

void cosr_record_bcn_own_mac(struct wifi_app *wapp, struct wapp_dev *wdev, u8 *sta_mac,
		struct cosr_bcn_report_list *bcn_report_result)
{
	struct wapp_sta *candlist_sta = NULL;
	struct cosr_ap_candlist_ap *eAp = NULL;
	BOOLEAN fgBcnReqSend = FALSE;
	u8 u1Bandidx = 0;

	u1Bandidx = cosr_get_bandidx(wapp, wdev);
	if (u1Bandidx == 0xFF)
		return;

	/* pathloss is in candlist_sta not in ap->client_table */
	candlist_sta = cosr_get_candlist_sta(wapp, wdev, sta_mac);
	if (!candlist_sta)
		return;
	eAp = wapp->candlist_ap[u1Bandidx];
	while (eAp) {
		err(DEBUG_CAT_COSR, "Meas STATE %d\n",
			candlist_sta->meas_data[eAp->apid].cli_measurement_state);
		if (candlist_sta->meas_data[eAp->apid].cli_measurement_state == WAIT_11K_OWN_MAC) {
			candlist_sta->meas_data[eAp->apid].u1OwnMac11kRssi = bcn_report_result->rcpi;
			candlist_sta->meas_data[eAp->apid].cli_measurement_state = WAIT_11K_RESULT;
			cosr_trigger_bcn_meas(wapp, wdev, candlist_sta, eAp);
			fgBcnReqSend = TRUE;
		}
		eAp = eAp->next;
	}
	if (fgBcnReqSend == TRUE)
		eloop_register_timeout(COSR_11K_WAIT_TIME, 0, cosr_trigger_bcn_req_timeout, wapp, candlist_sta);
	eloop_cancel_timeout(cosr_trigger_own_bcn_req_timeout, wapp, candlist_sta);
}

void cosr_cal_bcn_report_pathdiff(struct wifi_app *wapp, struct wapp_dev *wdev, u8 *sta_mac)
{
	struct cosr_bcn_report_list *bcn_report_result;
	struct cosr_ap_candlist_ap *e;
	struct wapp_sta *sta = NULL;
	struct wapp_sta *candlist_sta = NULL;
	u8 current_rcpi = 0;
	u8 u1Bandidx = 0;
	signed char rcvpathdiff = 0;


	sta = wdev_ap_client_list_lookup_for_all_bss(wapp, sta_mac);
	if (!sta)
		return;
	/* pathloss is in candlist_sta not in ap->client_table */
	candlist_sta = cosr_get_candlist_sta(wapp, wdev, sta_mac);
	if (!candlist_sta)
		return;

	u1Bandidx = cosr_get_bandidx(wapp, wdev);
		if (u1Bandidx == 0xFF)
			return;

	bcn_report_result = wapp->bcn_report_list;
	while (bcn_report_result) {
		e = wapp->candlist_ap[u1Bandidx];
		while (e) {
			debug(DEBUG_CAT_COSR, "AP BSSID "MACSTR" BCNRPT BSSID "MACSTR"\n",
				MAC2STR(e->bssid), MAC2STR(bcn_report_result->bssid));
			if (os_memcmp(e->bssid, bcn_report_result->bssid, MAC_ADDR_LEN) == 0) {
				current_rcpi = candlist_sta->meas_data[e->apid].u1OwnMac11kRssi;
				/* Sta listen to own AP's Beacon RSSI */
				rcvpathdiff = current_rcpi - bcn_report_result->rcpi;
				/* update pathloss difference with moving avg */
				notice(DEBUG_CAT_COSR, "NewPathDiff %d Old PathDiff %d\n", rcvpathdiff, candlist_sta->pathdiff[e->apid]);
				if (candlist_sta->pathdiff[e->apid] == COSR_AIRMONITOR_DEFA)
					candlist_sta->pathdiff[e->apid] = rcvpathdiff;
				else
					candlist_sta->pathdiff[e->apid] = ((rcvpathdiff + candlist_sta->pathdiff[e->apid]*3)-1)/4+1;

				candlist_sta->meas_data[e->apid].cli_measurement_state = PLDIFF_DONE;
				notice(DEBUG_CAT_COSR, "Pathloss Data %d = %d - %d\n",
					candlist_sta->pathdiff[e->apid], current_rcpi, bcn_report_result->rcpi);
				debug(DEBUG_CAT_COSR, "Cal patch diff from "MACSTR " to " MACSTR" and pathdiff = %d\n",
						MAC2STR(candlist_sta->mac_addr),
						MAC2STR(bcn_report_result->bssid),
						candlist_sta->pathdiff[e->apid]);
			} else {
				err(DEBUG_CAT_COSR, "result bssid not found in candlist ap.\n");
			}
			e = e->next;
		}
		bcn_report_result = bcn_report_result->next;
	}
	cosr_set_stainfo_by_mac(wapp, wdev, sta_mac);
	/*
	 * if target STA's all 11k measurement is done, then it can cancel,
	 * if one of STA's 11k measureing AP not complete, don't cancel timer
	 */
	e = wapp->candlist_ap[u1Bandidx];
	while (e) {
		/* if any STA->AP is waiting for 11k feedback, don't cancel timer */
		if (candlist_sta->meas_data[e->apid].cli_measurement_state == WAIT_11K_RESULT)
			return;
		e = e->next;
	}
	/* if ALL perSTA->AP not waiting 11k feedback, cancel timer */
	err(DEBUG_CAT_COSR, " STA "MACSTR" Cancel BcnReq Timer\n", MAC2STR(candlist_sta->mac_addr));

	eloop_cancel_timeout(cosr_trigger_bcn_req_timeout, wapp, candlist_sta);

}



struct wpabuf *cosr_airtime_alloc_msg(u8 subcat, u8 cosrtype,
				u8 *target_bssid, size_t len)
{
	struct wpabuf *msg;

	msg = wpabuf_alloc(13 + len);
	if (!msg)
		return NULL;
	wpabuf_put_u8(msg, WLAN_ACTION_PUBLIC);
	wpabuf_put_u8(msg, WLAN_PA_VENDOR_SPECIFIC);
	wpabuf_put_be24(msg, OUI_MTK);

	/* build vendor content msg */
	wpabuf_put_u8(msg, subcat);
	wpabuf_put_u8(msg, cosrtype);
	wpabuf_put_data(msg, target_bssid, MAC_ADDR_LEN);

	return msg;
}

struct wpabuf *cosr_airtime_buid_req(struct cosr_airtime_sharing *cosr_airtime_req, struct airtime_vendor_content *content)
{
	struct wpabuf *msg;
	u8 subcat, cosrtype;
	u8 target_bssid[MAC_ADDR_LEN];
	size_t attr_len;

	attr_len = 2*(4 + AIRTIME_MAX_NONCE_LEN + 4 + 4);

	subcat = cosr_airtime_req->subcat;
	cosrtype = cosr_airtime_req->cosrtype;
	os_memcpy(target_bssid, cosr_airtime_req->target_bssid, MAC_ADDR_LEN);
	msg = cosr_airtime_alloc_msg(subcat, cosrtype, target_bssid, attr_len);
	if (!msg) {
		err(DEBUG_CAT_COSR, "alloc msg failed\n");
		return NULL;
	}

	/* add airtime req_content */
	wpabuf_put_u8(msg, content->u.req_content.req_status);
	wpabuf_put_data(msg, content->u.req_content.pri_bssid, MAC_ADDR_LEN);
	wpabuf_put_data(msg, content->u.req_content.apcli_mac, MAC_ADDR_LEN);

	return msg;
}


struct wpabuf *cosr_airtime_buid_resp(struct cosr_airtime_sharing *cosr_airtime_resp,
										struct airtime_vendor_content *content)
{
	struct wpabuf *msg;
	u8 subcat, cosrtype;
	u8 target_bssid[MAC_ADDR_LEN];
	size_t attr_len;

	attr_len = 2*(4 + AIRTIME_MAX_NONCE_LEN + 4 + 4);

	subcat = cosr_airtime_resp->subcat;
	cosrtype = cosr_airtime_resp->cosrtype;
	os_memcpy(target_bssid, cosr_airtime_resp->target_bssid, MAC_ADDR_LEN);
	msg = cosr_airtime_alloc_msg(subcat, cosrtype, target_bssid, attr_len);
	if (!msg) {
		err(DEBUG_CAT_COSR, "alloc msg failed\n");
		return NULL;
	}

	/* add airtime req_content */
	wpabuf_put_u8(msg, content->u.resp_content.resp_status);
	wpabuf_put_data(msg, content->u.resp_content.apcli_mac, MAC_ADDR_LEN);

	return msg;
}

struct wpabuf *cosr_build_airmonitor_req_frame(struct cosr_airmonitor_req_frame *airmonitor_req)
{
	struct wpabuf *msg;
	u8 subcat, cosrtype;
	u8 target_bssid[MAC_ADDR_LEN];
	size_t attr_len;

	if (!airmonitor_req) {
		err(DEBUG_CAT_COSR, "Airmonitor req info is NULL\n");
		return NULL;
	}
	attr_len = 2*(4 + AIRTIME_MAX_NONCE_LEN + 4 + 4);

	subcat = airmonitor_req->req_info.subcat;
	cosrtype = airmonitor_req->req_info.cosrtype;
	os_memcpy(target_bssid, airmonitor_req->req_info.target_bssid, MAC_ADDR_LEN);
	msg = cosr_airtime_alloc_msg(subcat, cosrtype, target_bssid, attr_len);
	if (!msg) {
		err(DEBUG_CAT_COSR, "alloc msg failed\n");
		return NULL;
	}
	wpabuf_put_data(msg, airmonitor_req->req_info.own_mac, MAC_ADDR_LEN);
	wpabuf_put_u8(msg, airmonitor_req->req_info.sta_num);

	/* add airmonitor req_content */
	wpabuf_put_data(msg, (u8 *)&airmonitor_req->req_info.sta_list, airmonitor_req->req_info.sta_num * MAC_ADDR_LEN);

	return msg;
}

struct wpabuf *cosr_build_airmonitor_resp_frame(struct cosr_airmonitor_resp_frame *airmonitor_resp)
{
	struct wpabuf *msg;
	u8 subcat, cosrtype;
	u8 target_bssid[MAC_ADDR_LEN];
	size_t attr_len, packt_len = 0;

	if (!airmonitor_resp) {
		err(DEBUG_CAT_COSR, "Airmonitor resp info is NULL\n");
		return NULL;
	}
	attr_len = 2*(4 + AIRTIME_MAX_NONCE_LEN + 4 + 4);
	packt_len = sizeof(struct cosr_airmonitor_resp_info) +
			(airmonitor_resp->resp_info.sta_num * sizeof(struct cosr_unlink_rsp_sta) +
			attr_len);
	subcat = airmonitor_resp->resp_info.subcat;
	cosrtype = airmonitor_resp->resp_info.cosrtype;
	os_memcpy(target_bssid, airmonitor_resp->resp_info.target_bssid, MAC_ADDR_LEN);
	msg = cosr_airtime_alloc_msg(subcat, cosrtype, target_bssid, packt_len);
	if (!msg) {
		err(DEBUG_CAT_COSR, "alloc msg failed\n");
		return NULL;
	}
	wpabuf_put_data(msg, airmonitor_resp->resp_info.own_mac, MAC_ADDR_LEN);
	wpabuf_put_u8(msg, airmonitor_resp->resp_info.sta_num);

	/* add airmonitor resp content */
	wpabuf_put_data(msg, (u8 *)airmonitor_resp->resp_info.info, airmonitor_resp->resp_info.sta_num * 10);

	return msg;
}
int wapp_cosr_airtime_sharing_send_req(struct wifi_app *wapp, struct wapp_dev *wdev,
					u8 *mac_addr, u8 fsm_status)
{
	unsigned int wait_time, chan = 0;
	struct ap_dev *ap;
	struct cosr_airtime_sharing *cosr_airtime_req;
	struct airtime_vendor_content *content;
	u8 wdevBand = 0;
	struct dl_list *dev_list;
	struct wapp_dev *wdevCli = NULL;

	cosr_airtime_req = os_zalloc(sizeof(struct cosr_airtime_sharing));
	if (!cosr_airtime_req) {
		err(DEBUG_CAT_COSR, "wapp allocated failed\n");
		os_free(cosr_airtime_req);
		return WAPP_UNEXP;
	}

	content = os_zalloc(sizeof(struct airtime_vendor_content));
	if (!content) {
		err(DEBUG_CAT_COSR, "wapp allocated failed\n");
		os_free(content);
		os_free(cosr_airtime_req);
		return WAPP_UNEXP;
	}

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		ap = (struct ap_dev *)wdev->p_dev;
		/* get airtime_sharing sendig channel */
		chan = ap->ch_info.op_ch;
	}

	/* Find STA role Wdev Addr and report to neighbor AP */
	wdevBand = cosr_get_bandidx(wapp, wdev);
	debug(DEBUG_CAT_COSR, "wdev %s and wdevBand %d\n", wdev->ifname, wdevBand);
	dev_list = &wapp->dev_list;
	dl_list_for_each(wdevCli, dev_list, struct wapp_dev, list) {
		if (wdevBand == cosr_get_bandidx(wapp, wdevCli) &&
			(wdevCli->dev_type == WAPP_DEV_TYPE_STA ||
				wdevCli->dev_type == WAPP_DEV_TYPE_APCLI)) {
			debug(DEBUG_CAT_COSR, "Band %d WDEV APCLI MAC "MACSTR" %s\n",
				wdevBand, MAC2STR(wdevCli->mac_addr), wdevCli->ifname);
			os_memcpy(content->u.req_content.apcli_mac, wdevCli->mac_addr, MAC_ADDR_LEN);
		}
	}

	/* Setting wait_time */
	wait_time = AIRTIME_SHARING_WAIT_TIME;

	/* Setting frame data */
	cosr_airtime_req->subcat = AIRTIME_SHARING;
	cosr_airtime_req->cosrtype = AIRTIME_SHARING_REQ;
	os_memcpy(cosr_airtime_req->target_bssid, mac_addr, MAC_ADDR_LEN);

	content->u.req_content.req_status = fsm_status;
	os_memcpy(content->u.req_content.pri_bssid, wdev->mac_addr, MAC_ADDR_LEN);

	cosr_airtime_req->req_msg = cosr_airtime_buid_req(cosr_airtime_req, content);

	if (!cosr_airtime_req->req_msg) {
		err(DEBUG_CAT_COSR, "cosr build airtime req info failed\n");
		os_free(content);
		os_free(cosr_airtime_req);
		return WAPP_UNEXP;
	}

	wapp_drv_send_cosr_action(wapp, wdev, chan, wait_time, mac_addr,
					wpabuf_head(cosr_airtime_req->req_msg),
					wpabuf_len(cosr_airtime_req->req_msg));
	if (cosr_airtime_req->req_msg) {
		os_free(cosr_airtime_req->req_msg);
		os_free(content);
		os_free(cosr_airtime_req);
	}
	return WAPP_SUCCESS;
}

int wapp_cosr_airtime_sharing_send_resp(struct wifi_app *wapp, struct wapp_dev *wdev, const u8 *mac_addr, u8 resp_status)
{
	unsigned int wait_time, chan = 0;
	struct ap_dev *ap;
	struct cosr_airtime_sharing *cosr_airtime_resp;
	struct airtime_vendor_content *content;
	u8 wdevBand = 0;
	struct dl_list *dev_list;
	struct wapp_dev *wdevCli = NULL;

	cosr_airtime_resp = os_zalloc(sizeof(struct cosr_airtime_sharing));
	if (!cosr_airtime_resp) {
		err(DEBUG_CAT_COSR, "wapp cosr_airtime_resp allocated failed\n");
		os_free(cosr_airtime_resp);
		return WAPP_UNEXP;
	}

	content = os_zalloc(sizeof(struct airtime_vendor_content));
	if (!content) {
		err(DEBUG_CAT_COSR, "allocated content failed\n");
		os_free(content);
		os_free(cosr_airtime_resp);
		return WAPP_UNEXP;
	}

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		ap = (struct ap_dev *)wdev->p_dev;
		/* get airtime_sharing sendig channel */
		chan = ap->ch_info.op_ch;
	}

	/* Find STA role Wdev Addr and report to neighbor AP */
	wdevBand = cosr_get_bandidx(wapp, wdev);
	dev_list = &wapp->dev_list;
	dl_list_for_each(wdevCli, dev_list, struct wapp_dev, list) {
		if (wdevBand == cosr_get_bandidx(wapp, wdevCli) &&
			(wdevCli->dev_type == WAPP_DEV_TYPE_STA || wdevCli->dev_type == WAPP_DEV_TYPE_APCLI)) {
			os_memcpy(content->u.resp_content.apcli_mac, wdevCli->mac_addr, MAC_ADDR_LEN);
		}
	}

	/* Setting wait_time */
	wait_time = AIRTIME_SHARING_WAIT_TIME;

	/* Setting resp frame data */
	cosr_airtime_resp->subcat = AIRTIME_SHARING;
	cosr_airtime_resp->cosrtype = AIRTIME_SHARING_RESP;
	os_memcpy(cosr_airtime_resp->target_bssid, mac_addr, MAC_ADDR_LEN);
	content->u.resp_content.resp_status = resp_status;

	notice(DEBUG_CAT_COSR, "resp target to "MACSTR"\n", MAC2STR(cosr_airtime_resp->target_bssid));

	cosr_airtime_resp->resp_msg = cosr_airtime_buid_resp(cosr_airtime_resp, content);
	if (!cosr_airtime_resp->resp_msg) {
		err(DEBUG_CAT_COSR, "cosr build airtime resp info failed\n");
		os_free(content);
		os_free(cosr_airtime_resp);
		return WAPP_UNEXP;
	}

	wapp_drv_send_cosr_action(wapp, wdev, chan, wait_time, mac_addr,
				       wpabuf_head(cosr_airtime_resp->resp_msg),
				       wpabuf_len(cosr_airtime_resp->resp_msg));
	if (cosr_airtime_resp->resp_msg) {
		os_free(cosr_airtime_resp->resp_msg);
		os_free(content);
		os_free(cosr_airtime_resp);
	}
	return WAPP_SUCCESS;
}

void wapp_cosr_rx_airtime_req(struct wifi_app *wapp,  struct wapp_dev *wdev,
				 const u8 *src, const u8 *buf, size_t len, u8 rssi)
{
	char cosr_status = 0;
	u8 frame_status;
	u8 neighbor_mac[MAC_ADDR_LEN] = {0};
	u8 apcli_mac[MAC_ADDR_LEN] = {0};

	frame_status = *buf++;
	len -= 1;
	notice(DEBUG_CAT_COSR, "COSR: Airtime_Sharing Request from: "MACSTR" and status %d\n",
		MAC2STR(src), frame_status);

	if (len > MAC_ADDR_LEN) {
		os_memcpy(neighbor_mac, buf, MAC_ADDR_LEN);
		buf = buf + MAC_ADDR_LEN;
		len -= MAC_ADDR_LEN;
	}
	if (len > MAC_ADDR_LEN) {
		os_memcpy(apcli_mac, buf, MAC_ADDR_LEN);
		buf = buf + MAC_ADDR_LEN;
		len -= MAC_ADDR_LEN;
	}

	if (!wdev)
		return;
	if (!wdev->radio || !wdev->radio->radio_band)
		return;
	if (wapp->cosr_ap_mode[*(wdev->radio->radio_band)] == FALSE) {
		notice(DEBUG_CAT_COSR, "wdev Type is %d ifname %s cosr ap mode %d\n",
					wdev->dev_type, wdev->ifname, wapp->cosr_ap_mode[*(wdev->radio->radio_band)]);
		if (frame_status == AIRTIME_SHARING_REQ_SYNC) {
			if (cosr_ap_get_candlist_per_band(wapp, wdev, src)) {
				notice(DEBUG_CAT_COSR, "CoAP found Candlist, update apcli mac "MACSTR"\n", MAC2STR(apcli_mac));
				cosr_ap_add_candlist_ap_per_band(wapp, wdev, src, rssi, apcli_mac);
			}
		} else {
			wapp_cosr_airtime_sharing_send_resp(wapp, wdev, src, AIRTIME_SHARING_RESP_DENY);
		}
		return;
	}


	if (frame_status == AIRTIME_SHARING_REQ_REQ) {
		notice(DEBUG_CAT_COSR, "CoAP candlist AP count %d\n",
			cosr_ap_candlist_ap_count_per_band(wapp, wdev));
		if (cosr_ap_candlist_ap_count_per_band(wapp, wdev) < MAX_COSR_CO_AP_COUNT ||
			cosr_ap_get_candlist_per_band(wapp, wdev, src) != NULL) {
			if (cosr_ap_get_candlist_per_band(wapp, wdev, src) == NULL) {
				err(DEBUG_CAT_COSR, "CoAP Not Candlist\n");
				cosr_ap_add_candlist_ap_per_band(wapp, wdev, src, rssi, apcli_mac);
			}
			cosr_status = cosr_ap_get_coorap_status_per_band(wapp, wdev, src);
			if (cosr_status == -1) {
				err(DEBUG_CAT_COSR, "Unexpected cosr_ap_coorap_status_per_band!\n");
				cosr_status = 0;
			}
			cosr_status = cosr_status | AIRTIME_STATE_SHARING;
			cosr_ap_set_coorap_status_per_band(wapp, wdev, src, cosr_status);
			cosr_set_apinfo(wapp, wdev, src, cosr_status);
			wapp_cosr_airtime_sharing_send_resp(wapp, wdev, src, AIRTIME_SHARING_RESP_ACCEPT);
		} else {
			err(DEBUG_CAT_COSR, "skip - candlist_ap (count = %d limit = %d)\n",
				cosr_ap_candlist_ap_count_per_band(wapp, wdev), MAX_COSR_CO_AP_COUNT);
			/* Exceed Limit, not count in current AP list */
			wapp_cosr_airtime_sharing_send_resp(wapp, wdev, src, AIRTIME_SHARING_RESP_DENY);
		}

	} else if (frame_status == AIRTIME_SHARING_REQ_ABORT) {
		/* Clear Bit0 and check status */
		if (cosr_ap_get_candlist_per_band(wapp, wdev, src) != NULL) {
			cosr_status = cosr_ap_get_coorap_status_per_band(wapp, wdev, src);
			if (cosr_status == -1) {
				err(DEBUG_CAT_COSR, "Unexpected cosr_ap_coorap_status_per_band!\n");
				cosr_status = 0;
			}
			cosr_status = cosr_status ^ AIRTIME_STATE_SHARING;
			notice(DEBUG_CAT_COSR, "Rx AIRTIME_SHARING_REQ_ABORT status %d\n", cosr_status);
			if (cosr_status == AIRTIME_STATE_NO_REQ) {
				cosr_ap_set_coorap_status_per_band(wapp, wdev, src, cosr_status);
				cosr_set_apinfo(wapp, wdev, src, cosr_status);
				cosr_ap_del_candlist_ap_per_band(wapp, wdev, src);
				cosr_ap_add_blacklist(wapp, src);
				wapp_cosr_airtime_sharing_send_resp(wapp, wdev, src, AIRTIME_SHARING_ABORT_RESP_ACCEPT);
			} else if (cosr_status == AIRTIME_STATE_SHARED) {
				cosr_ap_set_coorap_status_per_band(wapp, wdev, src, cosr_status);
				cosr_set_apinfo(wapp, wdev, src, cosr_status);
				wapp_cosr_airtime_sharing_send_resp(wapp, wdev, src, AIRTIME_SHARING_ABORT_RESP_ACCEPT);
			} else
				err(DEBUG_CAT_COSR, "Receive Abort, Unexpect Status %d\n", cosr_status);
		}
	} else
		err(DEBUG_CAT_COSR, "parse frame_status fail or unknown status\n");
}

void wapp_cosr_rx_airtime_resp(struct wifi_app *wapp, struct wapp_dev *wdev, const u8 *src,
				const u8 *buf, size_t len, unsigned int chan, u8 rssi)
{
	char cosr_status;
	u8 frame_status;
	u8 apcli_mac[MAC_ADDR_LEN] = {0};

	debug(DEBUG_CAT_COSR, "COSR: Airtime_Sharing response from "MACSTR"\n", MAC2STR(src));

	if (!wdev || !wdev->radio ||
		!wdev->radio->radio_band ||
		wapp->cosr_ap_mode[*wdev->radio->radio_band] == FALSE)
		return;


	frame_status = *buf++;
	len -= 1;
	if (len > MAC_ADDR_LEN) {
		os_memcpy(apcli_mac, buf, MAC_ADDR_LEN);
		buf = buf + MAC_ADDR_LEN;
		len -= MAC_ADDR_LEN;
	}

	if (frame_status == AIRTIME_SHARING_RESP_ACCEPT) {
		if (cosr_ap_get_candlist_per_band(wapp, wdev, src) == NULL)
			cosr_ap_add_candlist_ap_per_band(wapp, wdev, src, rssi, apcli_mac);
		cosr_status = cosr_ap_get_coorap_status_per_band(wapp, wdev, src);
		if (cosr_status == -1) {
			err(DEBUG_CAT_COSR, "Unexpected cosr_ap_coorap_status_per_band!\n");
			cosr_status = 0;
		}
		cosr_status = cosr_status | AIRTIME_STATE_SHARED;
		cosr_ap_set_coorap_status_per_band(wapp, wdev, src, cosr_status);
		cosr_set_apinfo(wapp, wdev, src, cosr_status);
	} else if (frame_status == AIRTIME_SHARING_RESP_DENY) {
		cosr_ap_add_blacklist(wapp, src);
		if (cosr_ap_get_candlist_per_band(wapp, wdev, src) != NULL) {
			cosr_status = cosr_ap_get_coorap_status_per_band(wapp, wdev, src);
			if (cosr_status == -1) {
				err(DEBUG_CAT_COSR, "Unexpected cosr_ap_coorap_status_per_band!\n");
				cosr_status = 0;
			}
			cosr_status = cosr_status ^ AIRTIME_STATE_SHARED;
			cosr_ap_set_coorap_status_per_band(wapp, wdev, src, cosr_status);
			cosr_set_apinfo(wapp, wdev, src, cosr_status);
			if (cosr_status == AIRTIME_STATE_NO_REQ)
				cosr_ap_del_candlist_ap_per_band(wapp, wdev, src);
		}
	} else if (frame_status == AIRTIME_SHARING_ABORT_RESP_ACCEPT) {
		cosr_status = cosr_ap_get_coorap_status_per_band(wapp, wdev, src);
		cosr_status = cosr_status ^ AIRTIME_STATE_SHARED;
		if (cosr_status == AIRTIME_STATE_NO_REQ) {
			cosr_ap_set_coorap_status_per_band(wapp, wdev, src, cosr_status);
			cosr_set_apinfo(wapp, wdev, src, cosr_status);
			cosr_ap_add_blacklist(wapp, src);
			cosr_ap_del_candlist_ap_per_band(wapp, wdev, src);
		} else {
			cosr_ap_set_coorap_status_per_band(wapp, wdev, src, cosr_status);
			cosr_set_apinfo(wapp, wdev, src, cosr_status);
		}
	}
}


int cosr_send_airmonitor_request(struct wifi_app *wapp, struct wapp_dev *wdev,
								struct cosr_airmonitor_req_frame *req_frame, u8 *mac_addr)
{
	unsigned int wait_time, chan = 0;
	struct ap_dev *ap = NULL;
	u8 u1BandIdx = 0;

	if (!wapp || !wdev || !mac_addr)
		return WAPP_INVALID_ARG;
	u1BandIdx = cosr_get_bandidx(wapp, wdev);
	if (u1BandIdx == 0xFF)
		return WAPP_INVALID_ARG;

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		ap = (struct ap_dev *)wdev->p_dev;
		/* get airtime_sharing sendig channel */
		chan = ap->ch_info.op_ch;
	}

	/* Setting wait_time */
	wait_time = AIRTIME_SHARING_WAIT_TIME;

	/* Setting frame data */
	req_frame->req_info.subcat = AIRMONITOR;
	req_frame->req_info.cosrtype = AIRMONITOR_REQ;
	os_memcpy(req_frame->req_info.target_bssid, mac_addr, MAC_ADDR_LEN);
	os_memcpy(req_frame->req_info.own_mac, wdev->mac_addr, MAC_ADDR_LEN);

	req_frame->req_msg = cosr_build_airmonitor_req_frame(req_frame);
	if (!req_frame->req_msg) {
		err(DEBUG_CAT_COSR, "build cosr airmonitor req frame failed\n");
		os_free(req_frame->req_msg);
		return WAPP_UNEXP;
	}
	wapp_drv_send_cosr_action(wapp, wdev, chan, wait_time, mac_addr,
					wpabuf_head(req_frame->req_msg),
					wpabuf_len(req_frame->req_msg));

	return WAPP_SUCCESS;
}

int cosr_check_trigger_candlistap_airmonitor(struct wifi_app *wapp, struct wapp_dev *wdev)
{
	struct cosr_ap_candlist_ap *e;
	struct cosr_airmonitor_req_frame *req_frame = NULL;
	struct wapp_sta *sta;
	int sta_num = 0, sta_count = 0;
	int i;
	u8 u1BandIdx = 0;

	if (!wapp || !wdev)
		return WAPP_UNEXP;
	u1BandIdx = cosr_get_bandidx(wapp, wdev);
	if (u1BandIdx == 0xFF)
		return WAPP_UNEXP;

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		e = wapp->candlist_ap[u1BandIdx];
		if (e == NULL) {
			err(DEBUG_CAT_COSR, "candlist_ap not exist\n");
			return WAPP_UNEXP;
		}

		while (e) {
			debug(DEBUG_CAT_COSR, "APID %d "MACSTR"\n", e->apid, MAC2STR(e->bssid));
			for (i = 0; i < MAX_COSR_CANDLIST_STA; i++) {
				sta = wapp->candlist_sta[u1BandIdx][i];
				if (!sta)
					continue;
				if (sta->ifindex != wdev->ifindex)
					continue;
				if (sta->cosr_supported && sta->sta_status == WAPP_STA_CONNECTED) {
					if ((!sta->is_11k) ||
						sta->meas_data[e->apid].cli_measurement_state == WAIT_AIRMONITOR)
						sta_num++;
				}
			}

			if (sta_num == 0)
				return WAPP_LOOKUP_ENTRY_NOT_FOUND;

			req_frame = os_zalloc(sizeof(struct cosr_airmonitor_req_frame) + sta_num * MAC_ADDR_LEN);
			if (!req_frame) {
				err(DEBUG_CAT_COSR, "allocated req_frame failed\n");
				os_free(req_frame);
				return WAPP_UNEXP;
			}

			for (i = 0; i < MAX_COSR_CANDLIST_STA; i++) {
				sta = wapp->candlist_sta[u1BandIdx][i];
				if (!sta || sta->ifindex != wdev->ifindex)
					continue;
				if (sta->cosr_supported && sta->sta_status == WAPP_STA_CONNECTED) {
					if ((!sta->is_11k) ||
						sta->meas_data[e->apid].cli_measurement_state == WAIT_AIRMONITOR) {
						os_memcpy(&req_frame->req_info.sta_list[sta_count * MAC_ADDR_LEN],
							sta->mac_addr, MAC_ADDR_LEN);
						sta_count++;
						sta->meas_data[e->apid].cli_measurement_state = WAIT_AIRMONITOR_RESULT;
					}
				}
			}
			req_frame->req_info.sta_num = sta_num;

			cosr_send_airmonitor_request(wapp, wdev, req_frame, e->bssid);

			if (req_frame->req_msg)
				os_free(req_frame->req_msg);

			os_free(req_frame);

			e = e->next;
		}
	}

	return WAPP_SUCCESS;
}


unsigned char cosr_airmonitor_entry_check(struct wifi_app *wapp, u8 *sta_mac, unsigned char channel)
{
	struct sta_mnt_stat *sta_stat = NULL;
	struct wapp_dev *wdev = NULL;
	u8 wdev_found = 0;

	/*check if entry is present in existing list */
	if (!dl_list_empty(&wapp->cosr_sta_mntr_list)) {
		dl_list_for_each(sta_stat, &wapp->cosr_sta_mntr_list, struct sta_mnt_stat, list) {
			if ((!os_memcmp(sta_mac, sta_stat->sta_mac, MAC_ADDR_LEN))) {
				sta_stat->mnt_reference++;
				notice(DEBUG_CAT_COSR, "STA Entry found mnt_reference %d\n", sta_stat->mnt_reference);
				return WAPP_SUCCESS;
			}
		}

	}

	/*Search for wdev and channel match*/
	dl_list_for_each(wdev, &wapp->dev_list, struct wapp_dev, list) {
		if (wdev->radio && wdev->radio->op_ch == channel &&
			wdev->dev_type == WAPP_DEV_TYPE_AP) {
			wdev_found = TRUE;
			break;
		}
	}
	if (wdev_found) {
	/*create New Entry*/
		sta_stat = (struct sta_mnt_stat *)os_zalloc(sizeof(struct sta_mnt_stat));
		if (sta_stat == NULL) {
			err(DEBUG_CAT_COSR, "Memory Alloc Fail\n");
			return COSR_AIRMONITOR_DEFA;
		}
		notice(DEBUG_CAT_COSR, "STA Entry Add"MACSTR"\n", MAC2STR(sta_mac));
		os_memcpy(sta_stat->sta_mac, sta_mac, MAC_ADDR_LEN);
		sta_stat->Channel = channel;
		map_set_air_mnt_cmd(wapp, wdev, sta_mac, 1, 1);
		sta_stat->mnt_reference++;
		dl_list_add_tail(&wapp->cosr_sta_mntr_list, &sta_stat->list);
	} else {
		err(DEBUG_CAT_COSR, "Channel mismatch wdev not found\n");
		return COSR_AIRMONITOR_DEFA;
	}
	return WAPP_SUCCESS;

}


unsigned char cosr_check_for_monitor_complettion(struct cosr_airmonitor_resp_frame *airmonitor_resp)
{
	int i;

	notice(DEBUG_CAT_COSR, "STA NUM %d BITMAP %04X\n",
		airmonitor_resp->resp_info.sta_num, airmonitor_resp->bitmap);

	/*Check if need to wait for Results*/
	for (i = 0 ; i < airmonitor_resp->resp_info.sta_num; i++) {
		if (!(airmonitor_resp->bitmap & BIT(i)))
			break;
	}
	if (i == airmonitor_resp->resp_info.sta_num) {
		debug(DEBUG_CAT_COSR, "Return PASS\n");
		return 1;
	} else {
		debug(DEBUG_CAT_COSR, "Return FAIL\n");
		return 0;
	}
}


int cosr_send_airmonitor_response(struct wifi_app *wapp, struct cosr_airmonitor_resp_frame *cosr_airmonitor_resp)
{
		unsigned int wait_time, chan = 0;
		struct wapp_dev *wdev = NULL;
		struct ap_dev *ap = NULL;
		struct cosr_airmonitor_resp_frame *temp_resp;
		u8 dst_mac[6] = {0};


		wdev = wapp_dev_list_lookup_by_mac_and_type(wapp, cosr_airmonitor_resp->resp_info.own_mac, WAPP_DEV_TYPE_AP);
		if (!wdev) {
			err(DEBUG_CAT_COSR, "wdev not found or dev type is not AP.\n");
			cosr_airmonitor_resp->bitmap |= BIT(AIR_MONITOR_RESPONSE_DONE_BIT);
			return WAPP_LOOKUP_ENTRY_NOT_FOUND;
		}

		if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
			ap = (struct ap_dev *)wdev->p_dev;
			chan = ap->ch_info.op_ch;
		}

		temp_resp = (struct cosr_airmonitor_resp_frame *)os_zalloc(sizeof(struct cosr_airmonitor_resp_frame) +
			(cosr_airmonitor_resp->resp_info.sta_num * sizeof(struct cosr_unlink_rsp_sta)));
		if (temp_resp == NULL) {
			err(DEBUG_CAT_COSR, "%s Memory Alloc Fail\n", __func__);
			os_free(temp_resp);
			cosr_airmonitor_resp->bitmap |= BIT(AIR_MONITOR_RESPONSE_DONE_BIT);
			return WAPP_UNEXP;
		}

		cosr_airmonitor_resp->bitmap |= BIT(AIR_MONITOR_RESPONSE_DONE_BIT);
		/* Setting wait_time */
		wait_time = AIRTIME_SHARING_WAIT_TIME;

		/* Setting frame data */
		temp_resp->resp_info.subcat = AIRMONITOR;
		temp_resp->resp_info.cosrtype = AIRMONITOR_RESP;
		os_memcpy(temp_resp->resp_info.own_mac, wdev->mac_addr, MAC_ADDR_LEN);
		os_memcpy(temp_resp->resp_info.target_bssid, cosr_airmonitor_resp->resp_info.target_bssid, MAC_ADDR_LEN);
		os_memcpy(&dst_mac, temp_resp->resp_info.target_bssid, MAC_ADDR_LEN);
		temp_resp->resp_info.sta_num = cosr_airmonitor_resp->resp_info.sta_num;
		os_memcpy(temp_resp->resp_info.info,
			cosr_airmonitor_resp->resp_info.info,
			cosr_airmonitor_resp->resp_info.sta_num * 10);

		/* check content buf */
		temp_resp->resp_msg = cosr_build_airmonitor_resp_frame(temp_resp);
		if (!temp_resp->resp_msg) {
			err(DEBUG_CAT_COSR, "build cosr airmonitor resp frame failed\n");
			os_free(temp_resp);
			return WAPP_UNEXP;
		}

		wapp_drv_send_cosr_action(wapp, wdev, chan, wait_time, dst_mac,
							wpabuf_head(temp_resp->resp_msg),
							wpabuf_len(temp_resp->resp_msg));

		if (temp_resp->resp_msg) {
			os_free(temp_resp->resp_msg);
			os_free(temp_resp);
		}

		return WAPP_SUCCESS;

}

int cosr_update_sta_rssi(struct wifi_app *wapp, struct wapp_dev *wdev, wapp_mnt_info *mnt_info)
{
	struct sta_mnt_stat *sta_stat = NULL;

	if (!dl_list_empty(&wapp->cosr_sta_mntr_list)) {
		dl_list_for_each(sta_stat, &wapp->cosr_sta_mntr_list, struct sta_mnt_stat, list) {
			notice(DEBUG_CAT_COSR, "RxPktAddr"MACSTR" StaMntrList Addr"MACSTR"\n",
				MAC2STR(mnt_info->sta_addr),
				MAC2STR(sta_stat->sta_mac));
			if ((!os_memcmp(mnt_info->sta_addr, sta_stat->sta_mac, MAC_ADDR_LEN))
				&& (sta_stat->Channel == wdev->radio->op_ch)) {
				sta_stat->avg_rssi += mnt_info->rssi;
				sta_stat->mnt_cnt += wapp->air_mnt_max_pkt ? wapp->air_mnt_max_pkt : 1;
				notice(DEBUG_CAT_COSR, "STA mac: " MACSTR" Running Avg Rssi:%d MntCnt:%d\n",
					MAC2STR(sta_stat->sta_mac),
					sta_stat->avg_rssi,
					sta_stat->mnt_cnt);
				return WAPP_SUCCESS;
			} else
				err(DEBUG_CAT_COSR, "ADDR NOT MATCH\n");
		}
	} else
		err(DEBUG_CAT_COSR, "wapp->cosr_sta_mntr_list empty\n");
	return WAPP_UNEXP;
}


void clear_cosr_monitor_list(struct wifi_app *wapp)
{
	struct sta_mnt_stat *sta_stat = NULL, *sta_stat_tmp;
	struct wapp_dev *wdev = NULL, *wdev_tmp;
	unsigned char wdev_found = 0;
	struct dl_list *dev_list = &wapp->dev_list;

	if (!dl_list_empty(&wapp->cosr_sta_mntr_list)) {
		dl_list_for_each_safe(sta_stat, sta_stat_tmp,
			&wapp->cosr_sta_mntr_list, struct sta_mnt_stat, list) {

			notice(DEBUG_CAT_COSR, "sta_stat->mnt_reference %d "MACSTR"\n",
			sta_stat->mnt_reference,
			MAC2STR(sta_stat->sta_mac));

		if (sta_stat->mnt_reference <= 0) {
			if (!dl_list_empty(dev_list)) {
				dl_list_for_each_safe(wdev, wdev_tmp, &wapp->dev_list, struct wapp_dev, list) {
					if (wdev->radio && wdev->radio->op_ch == sta_stat->Channel &&
						wdev->dev_type == WAPP_DEV_TYPE_AP) {
						wdev_found = TRUE;
						break;
					}
				}
			}
			debug(DEBUG_CAT_COSR, ""MACSTR" free and delete from list\n", MAC2STR(sta_stat->sta_mac));
			dl_list_del(&sta_stat->list);
			os_free(sta_stat);
		}
		}
		if (dl_list_empty(&wapp->cosr_sta_mntr_list) && wdev_found) {
			err(DEBUG_CAT_COSR, "cosr_sta_mntr_list empty and wdev found, DISABLE AIRMONITOR\n");
			map_set_air_mnt_cmd(wapp, wdev, NULL, 0, 1);
			/* Temperary Solution NEED to MERGE WITH MAP*/
			wapp_clear_airmntidx(wapp, wdev);
		}
	}
}


void clear_cosr_airmonitor_req_list(struct wifi_app *wapp)
{
	struct cosr_airmonitor_resp_frame *metrics_rsp = NULL, *metrics_rsp_tmp;
	struct cosr_unlink_rsp_sta *info;
	struct sta_mnt_stat *sta_stat = NULL, *sta_stat_tmp;
	unsigned int i = 0;

	if (!dl_list_empty(&wapp->cosr_sta_mntr_list) &&
		!dl_list_empty(&wapp->cosr_airmonitor_query_list)) {
		dl_list_for_each_safe(metrics_rsp, metrics_rsp_tmp, &wapp->cosr_airmonitor_query_list,
								struct cosr_airmonitor_resp_frame, list) {
		if (metrics_rsp->bitmap & BIT(AIR_MONITOR_RESPONSE_DONE_BIT)) {
			DBGPRINT(RT_DEBUG_TRACE, " metrics_rsp->bitmap 0x%02X\n", metrics_rsp->bitmap);
			/*Clear STA reference Here*/
			for (i = 0 ; i < metrics_rsp->resp_info.sta_num ; i++) {
				info = &metrics_rsp->resp_info.info[i];
				dl_list_for_each_safe(sta_stat, sta_stat_tmp,
					&wapp->cosr_sta_mntr_list, struct sta_mnt_stat, list) {
					debug(DEBUG_CAT_COSR, " "MACSTR" "MACSTR" mnt_reference %d\n",
						MAC2STR(info->sta_mac), MAC2STR(sta_stat->sta_mac), sta_stat->mnt_reference);

					if ((!os_memcmp(info->sta_mac, sta_stat->sta_mac, MAC_ADDR_LEN)) &&
						(sta_stat->mnt_reference > 0)) {
						sta_stat->mnt_reference--;
						debug(DEBUG_CAT_COSR, "mnt_reference-- %d\n", sta_stat->mnt_reference);
					}
					}
			}
			dl_list_del(&metrics_rsp->list);
			os_free(metrics_rsp);
		}
	}
	}

}


static void cosr_update_rssi_for_timeout(struct wifi_app *wapp)
{
	struct cosr_airmonitor_resp_frame  *metrics_rsp, *metric_rsp_tmp = NULL;
	struct sta_mnt_stat *sta_stat = NULL, *sta_stat_tmp = NULL;
	struct cosr_unlink_rsp_sta *unlink_rsp;
	int i = 0;

	if (dl_list_empty(&wapp->cosr_sta_mntr_list) ||
		dl_list_empty(&wapp->cosr_airmonitor_query_list)) {
		err(DEBUG_CAT_COSR, "cosr_sta_mntr_list and query_list Empty\n");
		return;
	}

	dl_list_for_each_safe(sta_stat, sta_stat_tmp, &wapp->cosr_sta_mntr_list, struct sta_mnt_stat, list) {
		dl_list_for_each_safe(metrics_rsp, metric_rsp_tmp,
			&wapp->cosr_airmonitor_query_list, struct cosr_airmonitor_resp_frame, list) {
			debug(DEBUG_CAT_COSR, "metrics_rsp->resp_info.sta_num %d\n", metrics_rsp->resp_info.sta_num);
			debug(DEBUG_CAT_COSR, "Own MAC "MACSTR"\n", MAC2STR(metrics_rsp->resp_info.own_mac));
			debug(DEBUG_CAT_COSR, "TARGET BSSID "MACSTR"\n", MAC2STR(metrics_rsp->resp_info.target_bssid));
			for (i = 0; i < metrics_rsp->resp_info.sta_num; i++) {
				unlink_rsp = &metrics_rsp->resp_info.info[i];
				err(DEBUG_CAT_COSR, " sta %d MntCnt %d "MACSTR" "MACSTR"\n",
					i, sta_stat->mnt_cnt, MAC2STR(sta_stat->sta_mac), MAC2STR(unlink_rsp->sta_mac));
			if (!os_memcmp(sta_stat->sta_mac, unlink_rsp->sta_mac, MAC_ADDR_LEN)) {
				/* if timeout, send -110 back fo sharing AP */
				if (wapp->air_mnt_max_pkt == 0) {
					if (sta_stat->mnt_cnt > 0)
						unlink_rsp->uplink_rssi =
							(signed char)((sta_stat->avg_rssi)/(signed char)(sta_stat->mnt_cnt));
					else
						unlink_rsp->uplink_rssi = COSR_AIRMONITOR_DEFA;
				}
				notice(DEBUG_CAT_COSR, "Idx:%d STA:"MACSTR" RSSI:%d pkt cnt:%d\n",
							i, MAC2STR(unlink_rsp->sta_mac),
							unlink_rsp->uplink_rssi, sta_stat->mnt_cnt);
			}
		}
		}
	}
}


void cosr_airmonitor_query_timeout(void *eloop_data, void *user_ctx)
{
	struct wifi_app *wapp = (struct wifi_app *)eloop_data;
	struct wapp_dev *wdev, *wdev_tmp;
	struct cosr_airmonitor_resp_frame  *airmonitor_rsp = (struct cosr_airmonitor_resp_frame *)user_ctx;
	wapp_mnt_info mnt_info[MAX_NUM_OF_MONITOR_STA] = {0};
	u8 channel, i;
	size_t length = MAX_NUM_OF_MONITOR_STA * sizeof(wapp_mnt_info);
	struct sta_mnt_stat *sta = NULL;

	if (wapp->air_mnt_max_pkt) {
		sta = dl_list_first(&wapp->cosr_sta_mntr_list, struct sta_mnt_stat, list);
		if (sta == NULL)
			goto clean;
		channel = sta->Channel;

		err(DEBUG_CAT_COSR, "%s Air Monitor Query Timeout\n", __func__);

		dl_list_for_each_safe(wdev, wdev_tmp, &wapp->dev_list, struct wapp_dev, list) {
			if (wdev->radio &&
				wdev->radio->op_ch == channel &&
				wdev->dev_type == WAPP_DEV_TYPE_AP) {
				break;
			}
		}

		wapp_get_air_mnt_results(wapp, wdev->ifname, (char *) mnt_info, length);
		if (mnt_info->rssi != 0) {
			eloop_cancel_timeout(cosr_airmonitor_query_timeout, wapp, airmonitor_rsp);
			for (i = 0; i < MAX_NUM_OF_MONITOR_STA; i++)
				cosr_update_sta_rssi(wapp, wdev, &mnt_info[i]);
		}
	} else
		err(DEBUG_CAT_COSR, "air_mnt_max_pkt invalid.\n");
clean:
	err(DEBUG_CAT_COSR, "clean\n");
	cosr_update_rssi_for_timeout(wapp);
	/*Send Response to peer Device*/
	cosr_send_airmonitor_response(wapp, airmonitor_rsp);
	/*Clear NAC Request List*/
	clear_cosr_airmonitor_req_list(wapp);
	clear_cosr_monitor_list(wapp);
}


void cosr_receive_airmonitor_request(
	struct wifi_app *wapp, struct wapp_dev *wdev, const u8 *bss_addr, size_t len, const u8 *msg_buf)
{
	struct cosr_airmonitor_resp_frame *airmonitor_resp = NULL;
	struct cosr_airmonitor_req_info *airmonitor_req;
	struct cosr_unlink_rsp_sta *uplink_rsp;
	struct ap_dev *ap = NULL;
	int op_channel = 0;
	int i, ret;


	debug(DEBUG_CAT_COSR, "%s recive airmonitor request from bss_addr "MACSTR"\n",
				__func__, MAC2STR(bss_addr));

	airmonitor_req = (struct cosr_airmonitor_req_info *)msg_buf;

	debug(DEBUG_CAT_COSR,
			"\n subcat = %d, cosrtype= %d, sta_num = %d\n"
			"\t MAC "MACSTR"\n",
					airmonitor_req->subcat,
					airmonitor_req->cosrtype,
					airmonitor_req->sta_num,
					MAC2STR(airmonitor_req->target_bssid));

	airmonitor_resp = (struct cosr_airmonitor_resp_frame *)os_zalloc(sizeof(struct cosr_airmonitor_resp_frame) +
		(airmonitor_req->sta_num * sizeof(struct cosr_unlink_rsp_sta)));
	if (airmonitor_resp == NULL) {
		err(DEBUG_CAT_COSR, "%s Memory Alloc Fail\n", __func__);
		return;
	}

	airmonitor_resp->resp_info.sta_num = 0;

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		ap = (struct ap_dev *)wdev->p_dev;
		op_channel = ap->ch_info.op_ch;
	}

	for (i = 0; i < airmonitor_req->sta_num; i++) {
		uplink_rsp = &airmonitor_resp->resp_info.info[i];
		os_memcpy(uplink_rsp->sta_mac,
					&airmonitor_req->sta_list[i*MAC_ADDR_LEN],
					MAC_ADDR_LEN);

		uplink_rsp->uplink_rssi = COSR_AIRMONITOR_DEFA;
		ret = cosr_airmonitor_entry_check(wapp,	&airmonitor_req->sta_list[i*MAC_ADDR_LEN], op_channel);

		if (ret) {
			err(DEBUG_CAT_COSR, "Failed fill Default RSSI\n");
			uplink_rsp->uplink_rssi = ret;
			airmonitor_resp->bitmap |= BIT(airmonitor_resp->resp_info.sta_num);
		}
		airmonitor_resp->resp_info.sta_num++;
	}

	/* Copy received airmonitor interface to response content */
	os_memcpy(airmonitor_resp->resp_info.own_mac, wdev->mac_addr, MAC_ADDR_LEN);

	os_memcpy(airmonitor_resp->resp_info.target_bssid, airmonitor_req->own_mac, MAC_ADDR_LEN);

	if ((airmonitor_resp->resp_info.sta_num > 0) &&
			cosr_check_for_monitor_complettion(airmonitor_resp)) {
		/*send response from here only*/
		err(DEBUG_CAT_COSR, "[UNEXPECTED!!]%s Send Airmonitor Response at receive init stage\n", __func__);
		cosr_send_airmonitor_response(wapp, airmonitor_resp);
		os_free(airmonitor_resp);
		return;
	}
	dl_list_add_tail(&wapp->cosr_airmonitor_query_list, &airmonitor_resp->list);
	/* extend airmonitor timeout to 3 secs */
	eloop_register_timeout(COSR_WAIT_TIME, 0, cosr_airmonitor_query_timeout, wapp, airmonitor_resp);

}

void cosr_send_air_monitor_response_check(struct wifi_app *wapp, wapp_mnt_info *mnt_info)
{
	struct cosr_airmonitor_resp_frame *airmonitor_rsp, *airmonitor_rsp_tmp;
	struct sta_mnt_stat *sta_stat = NULL, *sta_stat_tmp;
	struct cosr_unlink_rsp_sta *unlink_rsp;
	int i = 0;

	if (dl_list_empty(&wapp->cosr_sta_mntr_list))
		return;
		/*sta List Parse*/
	dl_list_for_each_safe(sta_stat, sta_stat_tmp, &wapp->cosr_sta_mntr_list, struct sta_mnt_stat, list) {
		notice(DEBUG_CAT_COSR, "Packet count %d\n", sta_stat->mnt_cnt);
		if (dl_list_empty(&wapp->cosr_airmonitor_query_list))
			return;
		dl_list_for_each_safe(airmonitor_rsp, airmonitor_rsp_tmp,
				&wapp->cosr_airmonitor_query_list,
				struct cosr_airmonitor_resp_frame, list) {
			debug(DEBUG_CAT_COSR, "resp_info stanum %d\n", airmonitor_rsp->resp_info.sta_num);
			for (i = 0; i < airmonitor_rsp->resp_info.sta_num; i++) {
				unlink_rsp = &airmonitor_rsp->resp_info.info[i];
				debug(DEBUG_CAT_COSR, " unlink_rsp "MACSTR" sta_stat->sta_mac "MACSTR"\n",
				MAC2STR(unlink_rsp->sta_mac), MAC2STR(sta_stat->sta_mac));
				if (os_memcmp(sta_stat->sta_mac, unlink_rsp->sta_mac, MAC_ADDR_LEN))
					continue;
				debug(DEBUG_CAT_COSR, " sta_stat->mnt_cnt %d\n", sta_stat->mnt_cnt);
				if ((sta_stat->mnt_cnt == MONITOR_PACKET_COUNT) ||
						((wapp->air_mnt_max_pkt) &&
						(sta_stat->mnt_cnt == wapp->air_mnt_max_pkt))) {
					airmonitor_rsp->bitmap |= BIT(i);
					os_memcpy(unlink_rsp->sta_mac, sta_stat->sta_mac, MAC_ADDR_LEN);
					notice(DEBUG_CAT_COSR, "Monitor Result For Ind %d reference %d, bitmap 0x%02X\n",
							i, sta_stat->mnt_reference, airmonitor_rsp->bitmap);
					if (wapp->air_mnt_max_pkt == 0)
						unlink_rsp->uplink_rssi = (signed char)((sta_stat->avg_rssi)/
												(signed char)(sta_stat->mnt_cnt));
					else
						unlink_rsp->uplink_rssi = (signed char)sta_stat->avg_rssi;
					notice(DEBUG_CAT_COSR, "MntRef %d UplinkRssi %d\n",
								sta_stat->mnt_reference, unlink_rsp->uplink_rssi);
						}
				}
			}
	}

	/*Send Response if Monitor Done*/
	if (!dl_list_empty(&wapp->cosr_airmonitor_query_list)) {
		dl_list_for_each_safe(airmonitor_rsp, airmonitor_rsp_tmp,
			&wapp->cosr_airmonitor_query_list, struct cosr_airmonitor_resp_frame, list) {
			if (cosr_check_for_monitor_complettion(airmonitor_rsp)) {
				/*send response from here only*/
				eloop_cancel_timeout(cosr_airmonitor_query_timeout, wapp, airmonitor_rsp);
				cosr_send_airmonitor_response(wapp, airmonitor_rsp);
				clear_cosr_airmonitor_req_list(wapp);
			}
		}
	}

	/*Clear NAC Request List*/
	/*clear_air_monitor_req_list(wapp);*/
}


void cosr_airmonitor_packet_handle(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL;

	if (!wapp)
		return;
	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev) {
		err(DEBUG_CAT_COSR, "%s wdev not found idx %d\n", __func__, ifindex);
		return;
	}
	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		if (cosr_update_sta_rssi(wapp, wdev, &event_data->mnt_info) == 0) {
			cosr_send_air_monitor_response_check(wapp, &event_data->mnt_info);
			clear_cosr_monitor_list(wapp);
		} else {
			err(DEBUG_CAT_COSR, "%s  Drop Packet\n", __func__);
		}
	}
}

void cosr_receive_airmonitor_response(struct wifi_app *wapp, struct wapp_dev *wdev,
										const u8 *bss_addr, size_t len, const u8 *msg_buf)
{
	struct cosr_airmonitor_resp_info *airmonitor_resp;
	struct cosr_unlink_rsp_info *airmonitor_info;
	int i;


	airmonitor_resp = (struct cosr_airmonitor_resp_info *)msg_buf;


	notice(DEBUG_CAT_COSR, "airmonitor_resp sta_num = %d peer_mac is " MACSTR "\n",
					airmonitor_resp->sta_num, MAC2STR(airmonitor_resp->own_mac));

	airmonitor_info = (struct cosr_unlink_rsp_info *)os_zalloc(sizeof(struct cosr_unlink_rsp_info) +
					airmonitor_resp->sta_num * sizeof(struct cosr_airmonitor_result_info));
	if (!airmonitor_info) {
		DBGPRINT(RT_DEBUG_ERROR, "Allocated airmonitor_info failed\n");
		os_free(airmonitor_info);
		return;
	}

	for (i = 0; i < airmonitor_resp->sta_num; i++) {
		os_memcpy(airmonitor_info->info[i].peer_mac, airmonitor_resp->own_mac, MAC_ADDR_LEN);
		os_memcpy(airmonitor_info->info[i].sta_mac, airmonitor_resp->info[i].sta_mac, MAC_ADDR_LEN);
		airmonitor_info->info[i].uplink_rssi = airmonitor_resp->info[i].uplink_rssi;
	}

	airmonitor_info->u1StaNum = airmonitor_resp->sta_num;
	dl_list_add_tail(&wapp->cosr_airmonitor_result_list, &airmonitor_info->list);

	cosr_cal_airmonitor_pathloss(wapp, wdev);

}

void cosr_cal_airmonitor_pathloss(struct wifi_app *wapp, struct wapp_dev *wdev)
{
	struct cosr_unlink_rsp_info *airmonitor_result, *airmonitor_result_tmp;
	struct wapp_sta *sta = NULL;
	struct cosr_ap_candlist_ap *e;
	u8 u1BandIdx = 0;
	int i, j;
	signed char rcvpathdiff = 0;

	if (!wapp || !wdev)
		return;

	u1BandIdx = cosr_get_bandidx(wapp, wdev);
	if (u1BandIdx == 0xFF) {
		err(DEBUG_CAT_COSR, "BandIdx Error wdev %s\n", wdev->ifname);
		return;
	}
	if (u1BandIdx >= MAX_NUM_OF_RADIO) {
		err(DEBUG_CAT_COSR, "BandIdx %u is out of bounds\n", u1BandIdx);
		return;
	}
	/*airmonitor result list parse */
	dl_list_for_each_safe(airmonitor_result, airmonitor_result_tmp,
				&wapp->cosr_airmonitor_result_list, struct cosr_unlink_rsp_info, list){
		for (i = 0;  i < MAX_COSR_CANDLIST_STA; i++) {
			sta = wapp->candlist_sta[u1BandIdx][i];
			if (!sta || sta->sta_status != WAPP_STA_CONNECTED)
				continue;

			notice(DEBUG_CAT_COSR, "candlist_sta STA %d, "MACSTR"\n", i, MAC2STR(sta->mac_addr));

			for (j = 0; j < airmonitor_result->u1StaNum; j++) {
				notice(DEBUG_CAT_COSR, "airm STA %d, "MACSTR" uplink RSSI %d\n", j,
					MAC2STR(airmonitor_result->info[j].sta_mac),
				airmonitor_result->info[j].uplink_rssi);
				if (os_memcmp(sta->mac_addr, airmonitor_result->info[j].sta_mac, MAC_ADDR_LEN) == 0) {
					e = cosr_ap_get_candlist_per_band(wapp, wdev, airmonitor_result->info[j].peer_mac);
					if (e == NULL) {
						err(DEBUG_CAT_COSR, "e is null\n");
						continue;
					}
					if (airmonitor_result->info[j].uplink_rssi == COSR_AIRMONITOR_DEFA) {
						/* instead of delete STA, update predefined pathdiff to fw */
						/*
						sta->cosr_supported = 0;
						cosr_del_candlist_sta(wapp, wdev, sta->mac_addr);
						sta->pathdiff[e->apid] = COSR_AIRMONITOR_DEFA;
						*/
						/* sta uplink rssi - AP to AP rssi */
						if (sta->airmntfailcnt[e->apid] < 3) {
							rcvpathdiff = sta->pathdiff[e->apid];
							sta->airmntfailcnt[e->apid]++;
						} else {
							if (sta->cli_caps.phy_mode == MODE_EHT)
								rcvpathdiff = COSR_STA_DEFA_SINR_EHT;
							else
								rcvpathdiff = COSR_STA_DEFA_SINR_HE_VHT;
							sta->airmntfailcnt[e->apid] = 0;
						}
					} else {
						rcvpathdiff = ((signed char)(sta->uplink_rssi) -
									airmonitor_result->info[j].uplink_rssi);
						sta->airmntfailcnt[e->apid] = 0;
					}
					debug(DEBUG_CAT_COSR, "NewPathDiff %d Old PathDiff %d Airmnt FailCnt %d\n",
						rcvpathdiff, sta->pathdiff[e->apid], sta->airmntfailcnt[e->apid]);
					/* update pathloss difference with moving avg */
					if (sta->pathdiff[e->apid] == COSR_AIRMONITOR_DEFA)
						sta->pathdiff[e->apid] = rcvpathdiff;
					else
						sta->pathdiff[e->apid] = ((rcvpathdiff + sta->pathdiff[e->apid]*3)-1)/4+1;
					sta->meas_data[e->apid].cli_measurement_state = PLDIFF_DONE;
					debug(DEBUG_CAT_COSR,
						"Recive from" MACSTR " to cal sta_mac " MACSTR "\n"
						"Get pathdiff is %d uplink RSSI %d, Airmonitor RSSI %d\n",
						MAC2STR(airmonitor_result->info[j].peer_mac),
						MAC2STR(airmonitor_result->info[j].sta_mac),
						sta->pathdiff[e->apid],
						(signed char)(sta->uplink_rssi),
						airmonitor_result->info[j].uplink_rssi);
					cosr_set_stainfo_by_mac(wapp, wdev, sta->mac_addr);
					}
				}
			}
		dl_list_del(&airmonitor_result->list);
		os_free(airmonitor_result);
	}

}


