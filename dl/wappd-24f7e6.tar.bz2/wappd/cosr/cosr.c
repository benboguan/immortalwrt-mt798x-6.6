/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2020-2021  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#include <stdlib.h>
#include <stdio.h>
#include <linux/netlink.h>

#include "types.h"
#include "wapp_cmm.h"
#include "cosr.h"
#include "driver_wext.h"
#include "mtk_vendor_nl80211.h"
#include "rt_config.h"

#include "utils/wpabuf.h"
#include "utils/base64.h"
#include "utils/wpa_debug.h"
#include "util.h"

void wapp_cosr_period(void *eloop_ctx, void *sock_ctx)
{
	struct wifi_app *wapp = (struct wifi_app *)eloop_ctx;
	struct wapp_dev *wdev = NULL;
	struct wapp_dev *wdev_temp = NULL;
	struct dl_list *dev_list;
	int ret = 0;

	dev_list = &wapp->dev_list;
	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
		if (!wdev || wdev->dev_type != WAPP_DEV_TYPE_AP)
			continue;
		if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
			if (!wdev->radio || !wdev->radio->radio_band) {
				err(DEBUG_CAT_COSR, "wdev %s invalid radio\n", wdev->ifname);
				continue;
			}
			/* Skip Cosr Process if no valid AP exist */
			if (cosr_ap_candlist_ap_count_per_band(wapp, wdev) <= 0)
				continue;
			if (wdev->wdev_cosr_support == TRUE) {
				ret = cosr_update_candlist_sta(wapp, wdev);
				if (ret != WAPP_SUCCESS) {
					err(DEBUG_CAT_COSR, "update candlist sta failed, reason %d", ret);
					return;
				}
				cosr_set_stainfo(wapp, wdev, wdev->ifname);
			}
		}
	}
	eloop_register_timeout(WIFI_COSR_PERIOD, 0, wapp_cosr_period, wapp, NULL);
}


int wapp_cosr_enable(struct wifi_app *wapp)
{
	int ret = 0;

	if (wapp->cosr_enable != TRUE)
		wapp->cosr_enable = TRUE;

	ret = wapp_cosr_init(wapp);
	if (ret != WAPP_SUCCESS) {
		err(DEBUG_CAT_COSR, "Failed to init cosr\n");
		wapp_cosr_deinit(wapp);
		return ret;
	}

	return WAPP_SUCCESS;
}

int wapp_cosr_disable(struct wifi_app *wapp)
{

	if (wapp->cosr_enable != FALSE)
		wapp->cosr_enable = FALSE;

	wapp_cosr_deinit(wapp);

	return WAPP_SUCCESS;
}

int wapp_cosr_init(struct wifi_app *wapp)
{
	struct wapp_conf *conf;
	int ret = 0, count = 0;

	dl_list_for_each(conf, &wapp->conf_list, struct wapp_conf, list) {
		debug(DEBUG_CAT_COSR, "conf if name %s CoSR support %d\n",
			conf->iface, conf->cosr_support);
		if (conf->cosr_support == TRUE) {
			count++;
			continue;
		}
	}

	wapp->max_num_of_candlist_sta = MAX_COSR_STA_COUNT;
	ret = cosr_wapp_candlist_sta_init(wapp);
	if (ret) {
		err(DEBUG_CAT_COSR, "cosr ap candlist sta init failed!\n");
		return WAPP_SUCCESS;
	}

	if (count > 0) {
		eloop_cancel_timeout(wapp_cosr_wdev_ready_init_handler, wapp, NULL);
		eloop_register_timeout(COSR_WAIT_TIME, 0, wapp_cosr_wdev_ready_init_handler, wapp, NULL);
	}
	return WAPP_SUCCESS;

}

void wapp_cosr_wdev_ready_init_handler(void *eloop_ctx, void *sock_ctx)
{
	struct wifi_app *wapp = (struct wifi_app *)eloop_ctx;
	struct wapp_conf *conf;
	struct wapp_dev *wdev, *wdev_temp = NULL;
	struct dl_list *dev_list;
	struct wapp_sta *sta = NULL;
	struct ap_dev *ap = NULL;
	u8 fg_radio_band_support_cosr[MAX_NUM_OF_RADIO] = {0};
	u32 confifindex[MAX_NUM_OF_RADIO] = {0};
	u16 i = 0;

	dev_list = &wapp->dev_list;

	dl_list_for_each(conf, &wapp->conf_list, struct wapp_conf, list) {
		debug(DEBUG_CAT_COSR, "conf if name %s CoSR support %d\n",
			conf->iface, conf->cosr_support);
		dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
			if (!wdev || wdev->dev_type != WAPP_DEV_TYPE_AP) {
				err(DEBUG_CAT_COSR, "wdev is not null Type is %d ifname %s\n",
					wdev->dev_type, wdev->ifname);
				continue;
			}
			if (!os_strcmp(conf->iface, wdev->ifname)) {
				if (wdev->radio &&
					wdev->radio->radio_band &&
					conf->cosr_support &&
					fg_radio_band_support_cosr[*wdev->radio->radio_band] == FALSE) {
					if (wdev->radio && wdev->radio->radio_band) {
						debug(DEBUG_CAT_COSR, "conf->cosr_support %s %d\n",
							wdev->ifname, *wdev->radio->radio_band);
						fg_radio_band_support_cosr[*wdev->radio->radio_band] = TRUE;
						wapp->cosr_bcn_ifindex[*wdev->radio->radio_band] = 0xFFFF;
						wapp->cosr_ap_mode[*wdev->radio->radio_band] = FALSE;
						confifindex[*wdev->radio->radio_band] = wdev->ifindex;
					}
				}
			}
		}
	}

	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
		if (!wdev || wdev->dev_type != WAPP_DEV_TYPE_AP) {
			err(DEBUG_CAT_COSR, "wdev is not null Type is %d ifname %s\n",
				wdev->dev_type, wdev->ifname);
			continue;
		}

		if (wdev->cosr_support_mode & 0x01) {
			err(DEBUG_CAT_COSR,
				"wdev ifname %s not support cosr, skip it!\n", wdev->ifname);
			continue;
		}

		if (wdev->radio && wdev->radio->radio_band) {
			if (fg_radio_band_support_cosr[*wdev->radio->radio_band]) {
				wdev->wdev_cosr_support = TRUE;
				if (confifindex[*wdev->radio->radio_band] == wdev->ifindex) {
					wapp->cosr_bcn_ifindex[*wdev->radio->radio_band] = wdev->ifindex;
					debug(DEBUG_CAT_COSR, "Cosr Set BCN IE ifdex %d ifname %s\n",
					wdev->ifindex, wdev->ifname);
					cosr_set_bcn_ie(wapp, wdev);
					cosr_system_cmd_w_if(wapp, COSR_SET_ENABLE, wdev->ifname);
					cosr_system_cmd_w_if(wapp, COSR_STA_INFO_RST, wdev->ifname);
					cosr_system_cmd_w_if(wapp, COSR_AP_INFO_RST, wdev->ifname);
				}
			} else {
				wdev->wdev_cosr_support = FALSE;
			}
		}

		if (wdev->wdev_cosr_support) {
			ap = (struct ap_dev *)wdev->p_dev;
			for (i = 0; i < CLIENT_TABLE_SIZE; i++) {
				sta = ap->client_table[i];
				if (!sta)
					continue;
				debug(DEBUG_CAT_COSR, "STA MAC "MACSTR" STA BSSID "MACSTR" WDEV MAC "MACSTR"\n",
						MAC2STR(sta->mac_addr),
						MAC2STR(sta->bssid),
						MAC2STR(wdev->mac_addr));
				if (os_memcmp(sta->bssid, wdev->mac_addr, MAC_ADDR_LEN) != 0)
					continue;
				if (sta->sta_status == WAPP_STA_CONNECTED)
					wapp_query_cosr_sta_rssi(wapp, wdev, sta->mac_addr);
			}
		}
	}
	eloop_cancel_timeout(wapp_cosr_period, wapp, NULL);
	eloop_register_timeout(COSR_WAIT_TIME, 0, wapp_cosr_period, wapp, NULL);
}


int wapp_cosr_deinit(struct wifi_app *wapp)
{
	struct cosr_unlink_rsp_info *airmonitor_result, *airmonitor_result_tmp;
	struct dl_list *dev_list;
	struct wapp_dev *wdev, *wdev_temp = NULL;
	int i = 0, j = 0;

	dev_list = &wapp->dev_list;
	wapp->cosr_enable = FALSE;

	eloop_cancel_timeout(wapp_cosr_period, wapp, NULL);

	for (i = 0; i < MAX_COSR_CANDLIST_STA; i++) {
		for (j = 0; j < MAX_NUM_OF_RADIO; j++) {
			if (wapp->candlist_sta[j][i] != NULL) {
				os_free(wapp->candlist_sta[j][i]);
				wapp->candlist_sta[j][i] = NULL;
			}
		}
	}

	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
		if (!wdev || wdev->dev_type != WAPP_DEV_TYPE_AP) {
			err(DEBUG_CAT_COSR, "wdev is not null Type is %d ifname %s\n",
				wdev->dev_type, wdev->ifname);
			continue;
		}
		cosr_system_cmd_w_if(wapp, COSR_SET_DISABLE, wdev->ifname);
		cosr_system_cmd_w_if(wapp, COSR_STA_INFO_RST, wdev->ifname);
		cosr_system_cmd_w_if(wapp, COSR_AP_INFO_RST, wdev->ifname);
		wdev->wdev_cosr_support = FALSE;
	}

	dl_list_for_each_safe(airmonitor_result, airmonitor_result_tmp,
			&wapp->cosr_airmonitor_result_list, struct cosr_unlink_rsp_info, list) {
		dl_list_del(&airmonitor_result->list);
		os_free(airmonitor_result);
	}

	return WAPP_SUCCESS;
}

