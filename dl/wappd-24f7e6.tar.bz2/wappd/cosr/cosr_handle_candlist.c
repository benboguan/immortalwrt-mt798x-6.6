/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2020-2021  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */
#include <stdlib.h>
#include <stdio.h>
#include <linux/netlink.h>

#include "types.h"
#include "wapp_cmm.h"
#include "cosr.h"
#include "driver_wext.h"
#include "mtk_vendor_nl80211.h"
#include "rt_config.h"

#include "utils/wpabuf.h"
#include "utils/base64.h"
#include "utils/wpa_debug.h"
#include "util.h"

void wapp_check_cosr_sta_rssi(void *eloop_ctx, void *sock_ctx)
{
	struct wifi_app *wapp = (struct wifi_app *)eloop_ctx;
	struct wapp_dev *wdev = (struct wapp_dev *)sock_ctx;
	struct wapp_sta *candlist_sta = NULL;
	int i;
	u8 u1BandIdx = 0;

	if (wdev->dev_type != WAPP_DEV_TYPE_AP) {
		err(DEBUG_CAT_COSR, "wdev mode is not ready\n");
		return;
	}
	u1BandIdx = cosr_get_bandidx(wapp, wdev);
	if (u1BandIdx == 0xFF)
		return;

	for (i = 0; i < MAX_COSR_CANDLIST_STA; i++) {
		candlist_sta = wapp->candlist_sta[u1BandIdx][i];
		if (!candlist_sta)
			continue;
		if (wdev->ifindex != candlist_sta->ifindex)
			continue;
		if ((candlist_sta->cosr_supported) &&
			(candlist_sta->sta_status == WAPP_STA_CONNECTED)) {
			wapp_query_cosr_sta_rssi(wapp, wdev, candlist_sta->mac_addr);
		}
	}

	eloop_register_timeout(COSR_QUERY_TIME, 0, wapp_check_cosr_sta_rssi, wapp, wdev);
}

int cosr_wapp_candlist_sta_init(struct wifi_app *wapp)
{
	int i = 0, j = 0;

	if (!wapp)
		return WAPP_INVALID_ARG;

	if (wapp->max_num_of_candlist_sta) {
		for (j = 0; j < MAX_NUM_OF_RADIO; j++) {
			wapp->cosr_sta_id_bitmap[j] = 0;
			for (i = 0; i < wapp->max_num_of_candlist_sta; i++)
				wapp->candlist_sta[j][i] = os_zalloc(sizeof(struct wapp_sta));
		}
	} else {
		err(DEBUG_CAT_COSR, "ERROR! max_num_of_candlist_sta is zero.\n");
		return WAPP_INVALID_ARG;
	}

	return WAPP_SUCCESS;
}

int cosr_ap_candlist_sta_init(struct wifi_app *wapp, struct ap_dev *ap)
{
	int i = 0;

	if (!wapp || !ap)
		return WAPP_INVALID_ARG;

	if (ap->max_num_of_candlist_sta) {
		for (i = 0; i < ap->max_num_of_candlist_sta; i++)
			ap->candlist_sta[i] = os_zalloc(sizeof(struct wapp_sta));
	} else {
		err(DEBUG_CAT_COSR, "ERROR! max_num_of_candlist_sta is zero.\n");
		return WAPP_INVALID_ARG;
	}

	return WAPP_SUCCESS;
}

int cosr_update_candlist_sta(struct wifi_app *wapp, struct wapp_dev *wdev)
{
	struct ap_dev *ap = NULL;
	struct wapp_sta *sta = NULL;
	struct cosr_ap_candlist_ap *eAP;
	int i, j;
	signed char i1MinRssi = 0x7F;
	signed char i1StaRssi;
	u8 u1MinCandlistSTAid = 0;
	u8 u1MatchCandlistSTAid = 0xFF;
	u8 u1BandIdx = 0;
	u8 u1apid = 0;
	u8 fgApcli = 0;


	if (wdev->dev_type != WAPP_DEV_TYPE_AP) {
		err(DEBUG_CAT_COSR, "wdev mode is not ready\n");
		return WAPP_UNEXP;
	}
	ap = (struct ap_dev *)wdev->p_dev;
	eloop_cancel_timeout(wapp_check_cosr_sta_rssi, wapp, wdev);
	u1BandIdx = cosr_get_bandidx(wapp, wdev);
	if (u1BandIdx == 0xFF)
		return WAPP_UNEXP;
	debug(DEBUG_CAT_COSR, "u1BandIdx %d\n", u1BandIdx);

	for (i = 0; i < CLIENT_TABLE_SIZE; i++) {
		sta = ap->client_table[i];
		if (!sta)
			continue;
		notice(DEBUG_CAT_COSR, "STA PHY Mode %d\n", sta->cli_caps.phy_mode);

		if (sta->cli_caps.phy_mode < MODE_VHT)
			continue;

		notice(DEBUG_CAT_COSR, "STA MAC "MACSTR" STA BSSID "MACSTR" WDEV MAC "MACSTR"\n",
				MAC2STR(sta->mac_addr),
				MAC2STR(sta->bssid),
				MAC2STR(wdev->mac_addr));

		if (os_memcmp(sta->bssid, wdev->mac_addr, MAC_ADDR_LEN) != 0)
			continue;
		/* Skip STA if it's neighbor AP's APclient */
		fgApcli = FALSE;
		eAP = wapp->candlist_ap[u1BandIdx];
		while (eAP) {
			if (os_memcmp(eAP->apcli_mac, sta->mac_addr, MAC_ADDR_LEN) == 0)
				fgApcli = TRUE;
			eAP = eAP->next;
		}
		if (fgApcli == TRUE) {
			cosr_del_candlist_sta(wapp, wdev, sta->mac_addr);
			continue;
		}

		if (sta->sta_status == WAPP_STA_CONNECTED) {
			wapp_query_cosr_sta_rssi(wapp, wdev, sta->mac_addr);
			i1StaRssi = (signed char)(sta->uplink_rssi);
			notice(DEBUG_CAT_COSR, "i1StaRssi %d\n", i1StaRssi);
			if (i1StaRssi < INVALID_STA_THRESHOLD)
				continue;
			/*
			 * Search over candlist sta list to check if existing
			 * if exist, update rssi
			 * if non-exist check if rssi is 5dB higher than existing candlist sta,
			 *  if true, replace with new candliststa
			 */
			if (wapp->cosr_sta_id_bitmap[u1BandIdx] == 0xFF) {
				/* STA Array for this band is full, check for STA replacement */
				i1MinRssi = 0x7F;
				u1MatchCandlistSTAid = 0xFF;
				for (j = 0; j < MAX_COSR_CANDLIST_STA; j++) {
					if (os_memcmp(wapp->candlist_sta[u1BandIdx][j]->mac_addr, sta->mac_addr, MAC_ADDR_LEN)  == 0) {
						wapp->candlist_sta[u1BandIdx][j]->uplink_rssi = i1StaRssi;
						wapp->candlist_sta[u1BandIdx][j]->sta_status = sta->sta_status;
						u1MatchCandlistSTAid = j;
					}
					if (i1MinRssi > wapp->candlist_sta[u1BandIdx][j]->uplink_rssi) {
						u1MinCandlistSTAid = j;
						i1MinRssi = wapp->candlist_sta[u1BandIdx][j]->uplink_rssi;
					}
				}
				if (u1MatchCandlistSTAid == 0xFF &&
					(i1StaRssi > i1MinRssi + 5)) {
					/* Not found matched STA in candlist, check for replacement */
					sta->cosr_sta_id = u1MinCandlistSTAid;
					notice(DEBUG_CAT_COSR, "Band %d STA MAC "MACSTR" Adding Reset 1\n",
							u1BandIdx, MAC2STR(sta->mac_addr));
					for (u1apid = 0; u1apid < MAX_COSR_CO_AP_COUNT; u1apid++) {
						sta->pathdiff[u1apid] = COSR_STA_DEFA_RSSI;
						sta->meas_data[u1apid].fg11k_support_fail = FALSE;
						sta->meas_data[u1apid].measurement_retries_11k = 0;
						sta->meas_data[u1apid].cli_measurement_state = INVALID;
						sta->meas_data[u1apid].u1NoAirMntRspCnt = 0;
					}

					sta->cosr_supported = COSR_SUPPORT;
					sta->cosr_status = COSR_STA_STATUS_VALID;
					sta->ifindex = wdev->ifindex;

					os_memcpy(wapp->candlist_sta[u1BandIdx][u1MinCandlistSTAid], sta, sizeof(struct wapp_sta));
				}
			} else {
				/* STA Array for this band is not full */

				for (j = 0; j < MAX_COSR_CANDLIST_STA; j++) {
					if (os_memcmp(wapp->candlist_sta[u1BandIdx][j]->mac_addr, sta->mac_addr, MAC_ADDR_LEN) == 0 &&
						(wapp->cosr_sta_id_bitmap[u1BandIdx] & BIT(j)) >> j == 1) {
						wapp->candlist_sta[u1BandIdx][j]->uplink_rssi = i1StaRssi;
						wapp->candlist_sta[u1BandIdx][j]->sta_status = sta->sta_status;
						break;
					}
				}
				/* Not finding STA in Candlist STA array, update STA to vacant location and update bitmap */
				if (j == MAX_COSR_CANDLIST_STA) {
					for (j = 0; j < MAX_COSR_CANDLIST_STA; j++) {
						/* New CandlistSTA */
						if ((wapp->cosr_sta_id_bitmap[u1BandIdx] & BIT(j)) >> j == 0) {
							wapp->cosr_sta_id_bitmap[u1BandIdx] =
								wapp->cosr_sta_id_bitmap[u1BandIdx] | BIT(j);
							sta->cosr_sta_id = j;
							notice(DEBUG_CAT_COSR, "Band %d STA MAC "MACSTR" Adding Reset 2\n",
									u1BandIdx, MAC2STR(sta->mac_addr));
							for (u1apid=0; u1apid<MAX_COSR_CO_AP_COUNT; u1apid++){
								sta->pathdiff[u1apid] = COSR_STA_DEFA_RSSI;
								sta->meas_data[u1apid].fg11k_support_fail = FALSE;
								sta->meas_data[u1apid].measurement_retries_11k = 0;
								sta->meas_data[u1apid].cli_measurement_state = INVALID;
								sta->meas_data[u1apid].u1NoAirMntRspCnt = 0;
							}
							sta->cosr_supported = COSR_SUPPORT;
							sta->cosr_status = COSR_STA_STATUS_VALID;
							sta->ifindex = wdev->ifindex;
							os_memcpy(wapp->candlist_sta[u1BandIdx][j], sta, sizeof(struct wapp_sta));
							break;
						}
					}
				}
			}
		} else {
			for (j = 0; j < MAX_COSR_CANDLIST_STA; j++) {
				if (os_memcmp(wapp->candlist_sta[u1BandIdx][j]->mac_addr, sta->mac_addr, MAC_ADDR_LEN) == 0) {
					notice(DEBUG_CAT_COSR, "u1BandIdx %d Delete STA MAC "MACSTR"\n",
						u1BandIdx, MAC2STR(sta->mac_addr));
					cosr_del_candlist_sta(wapp, wdev, sta->mac_addr);
					break;
				}
			}
		}
	}
	eloop_register_timeout(COSR_QUERY_TIME, 0, wapp_check_cosr_sta_rssi, wapp, wdev);

	return WAPP_SUCCESS;
}

int cosr_set_stainfo(struct wifi_app *wapp, struct wapp_dev *wdev, const char *iface)
{
	struct cosr_info_set *info = NULL;
	struct wapp_sta *candlist_sta = NULL;
	struct cosr_ap_candlist_ap *eAp;
	struct cosr_ap_candlist_ap *eApLocal;
	int i, j, ret;
	u8 u1BandIdx = 0;
	u8 u1AvailableStaCnt = 0;
	u8 u1UpdPathDiff = 0;
	BOOLEAN fgNext11kTimeout = FALSE;
	BOOLEAN fgAirmontNeed = FALSE;


	info = os_zalloc(sizeof(struct cosr_info_set));
	if (!info)
		return WAPP_RESOURCE_ALLOC_FAIL;

	if (wdev->dev_type != WAPP_DEV_TYPE_AP) {
		err(DEBUG_CAT_COSR, "wdev mode is not ready\n");
		os_free(info);
		return WAPP_UNEXP;
	}
	u1BandIdx = cosr_get_bandidx(wapp, wdev);
	if (u1BandIdx == 0xFF) {
		os_free(info);
		return WAPP_UNEXP;
	}

	eAp = wapp->candlist_ap[u1BandIdx];
	if (!eAp) {
		err(DEBUG_CAT_COSR, "eAP is Null!\n");
		os_free(info);
		return WAPP_UNEXP;
	}

	for (i = 0; i < MAX_COSR_CANDLIST_STA; i++) {
		fgNext11kTimeout = FALSE;
		eAp = wapp->candlist_ap[u1BandIdx];
		eApLocal = eAp;
		candlist_sta = wapp->candlist_sta[u1BandIdx][i];
		notice(DEBUG_CAT_COSR, "STA ID %d\n", i);
		if (!candlist_sta ||
			(candlist_sta->ifindex != wdev->ifindex))
			continue;
		/* step 1 transfer cosr info to driver*/
		if ((candlist_sta->cosr_supported == COSR_SUPPORT) &&
			(candlist_sta->sta_status == WAPP_STA_CONNECTED)) {
			u1AvailableStaCnt++;
			info->sta_info.Candstaid = candlist_sta->cosr_sta_id;
			info->sta_info.u180211ksupport = candlist_sta->is_11k;
			info->sta_info.status = candlist_sta->cosr_status;
			os_memcpy(info->sta_info.sta_mac, candlist_sta->mac_addr, MAC_ADDR_LEN);
			/*
			 * Moving Avg Result if Airmonitor Rsp Fail
			 * For continuous 2 Airmnt rsp fail (1min),maybe due to collision or other causes.
			 * CoSR Needs to update Default value of SINR to FW to prevent STA not able to initiate
			 * CoSR with invalid Pathloss value -110.
			 */
			while (eApLocal) {
				if (candlist_sta->meas_data[eApLocal->apid].cli_measurement_state != WAIT_AIRMONITOR_RESULT) {
					candlist_sta->meas_data[eApLocal->apid].u1NoAirMntRspCnt = 0;
					eApLocal = eApLocal->next;
					continue;
				}

				candlist_sta->meas_data[eApLocal->apid].u1NoAirMntRspCnt++;
				debug(DEBUG_CAT_COSR, "AIRMNT RSP Fail APID %d, NoRspCnt %d\n",
						eApLocal->apid,
						candlist_sta->meas_data[eApLocal->apid].u1NoAirMntRspCnt);

				if (candlist_sta->meas_data[eApLocal->apid].u1NoAirMntRspCnt > 1) {
					u1UpdPathDiff = (candlist_sta->cli_caps.phy_mode == MODE_EHT) ?
						COSR_STA_DEFA_SINR_EHT : COSR_STA_DEFA_SINR_HE_VHT;

					/* update pathloss difference with moving avg */
					if (candlist_sta->pathdiff[eApLocal->apid] == COSR_AIRMONITOR_DEFA)
						candlist_sta->pathdiff[eApLocal->apid] = u1UpdPathDiff;
					else
						candlist_sta->pathdiff[eApLocal->apid] =
							((u1UpdPathDiff + candlist_sta->pathdiff[eApLocal->apid]*3)-1)/4+1;

					candlist_sta->meas_data[eApLocal->apid].u1NoAirMntRspCnt = 0;
					debug(DEBUG_CAT_COSR, "AIRMNT RSP Fail PathDiffUpd %d\n",
						candlist_sta->pathdiff[eApLocal->apid]);
				}
				eApLocal = eApLocal->next;
			}

			for (j = 0; j < MAX_COSR_CO_AP_COUNT; j++)
				info->sta_info.Pldiff[j] = candlist_sta->pathdiff[j];

			notice(DEBUG_CAT_COSR,
				"\n candlist sta info:\n"
				"\t candlist sta id = %d\n"
				"\t candlist sta 11k_cap = %d\n"
				"\t candlist sta sta_status = %d\n"
				"\t candlist sta mac = "MACSTR"\n"
				"\t candlist pathdiff[0] = %d\n"
				"\t candlist pathdiff[1] = %d\n"
				"\t candlist pathdiff[2] = %d\n",
				info->sta_info.Candstaid, info->sta_info.u180211ksupport,
				info->sta_info.status, MAC2STR(info->sta_info.sta_mac),
				info->sta_info.Pldiff[0],
				info->sta_info.Pldiff[1],
				info->sta_info.Pldiff[2]);
			ret = wapp_cosr_stainfo_send(wapp, iface, info);
			if (!ret) {
				err(DEBUG_CAT_COSR, "Cosr Send info failed!\n");
				os_free(info);
				return WAPP_UNEXP;
			}
		}
		/* step 2 init candlist_sta meas_stats for per ap */
		if (cosr_ap_candlist_ap_count_per_band(wapp, wdev) <= 0) {
			err(DEBUG_CAT_COSR, "cosr candlist ap not exit! AP counter %d\n",
					cosr_ap_candlist_ap_count_per_band(wapp, wdev));
			os_free(info);
			return WAPP_UNEXP;
		}
		eApLocal = eAp;
		while (eApLocal) {
			err(DEBUG_CAT_COSR, "APID %d [%d %d %d]\n",
					eApLocal->apid,
					candlist_sta->is_11k,
					candlist_sta->cosr_supported,
					candlist_sta->cycle_count);
			if (candlist_sta->is_11k &&
				candlist_sta->cosr_supported &&
				candlist_sta->meas_data[eApLocal->apid].fg11k_support_fail == FALSE) {
				candlist_sta->meas_data[eApLocal->apid].cli_measurement_state = WAIT_11K;
			} else {
				candlist_sta->meas_data[eApLocal->apid].cli_measurement_state = WAIT_AIRMONITOR;
				fgAirmontNeed = TRUE;
			}

			notice(DEBUG_CAT_COSR, " STA MAC "MACSTR" APID %d Sta Support Fail? %d\n",
					MAC2STR(candlist_sta->mac_addr),
					eApLocal->apid,
					candlist_sta->meas_data[eApLocal->apid].fg11k_support_fail);
			eApLocal = eApLocal->next;
		}
		notice(DEBUG_CAT_COSR, "fgAirmontNeed %d\n", fgAirmontNeed);
		/* reset pointer to first ap index */
		eApLocal = eAp;
		/* step 3 trigger bcn meas */
		if (candlist_sta->is_11k &&
			candlist_sta->cosr_supported) {
			while (eApLocal) {
				candlist_sta->meas_data[eApLocal->apid].measurement_retries_11k = 0;
				if (candlist_sta->meas_data[eApLocal->apid].cli_measurement_state == WAIT_11K) {
					if (cosr_get_bcn_reportlist(wapp, wdev->mac_addr, candlist_sta->mac_addr) == NULL) {
						err(DEBUG_CAT_COSR, "Trigger own ap "MACSTR" 11K MEAS\n", MAC2STR(wdev->mac_addr));
						ret = cosr_trigger_own_bcn_meas(wapp, wdev, candlist_sta);
						if (ret != WAPP_SUCCESS) {
							err(DEBUG_CAT_COSR, "trigger_bcn_meas failed\n");
						} else
							fgNext11kTimeout = TRUE;
						break;
					}
				}
				eApLocal = eApLocal->next;
			}
			if (fgNext11kTimeout == TRUE && cosr_ap_candlist_ap_count_per_band(wapp, wdev) > 0)
				eloop_register_timeout(COSR_11K_WAIT_TIME, 0, cosr_trigger_own_bcn_req_timeout, wapp, candlist_sta);
		}

	}
	/* Step 4 check trigger airmonitor */
	notice(DEBUG_CAT_COSR, "u1AvailableStaCnt %d fgAirmontNeed %d\n", u1AvailableStaCnt, fgAirmontNeed);
	if (u1AvailableStaCnt > 0 && fgAirmontNeed == TRUE) {
		ret = cosr_check_trigger_candlistap_airmonitor(wapp, wdev);
		if (ret != WAPP_SUCCESS)
			err(DEBUG_CAT_COSR, "cosr no need trigger airmonitor.\n");
	}
	os_free(info);
	return WAPP_SUCCESS;
}


int cosr_set_stainfo_by_mac(struct wifi_app *wapp, struct wapp_dev *wdev, u8 *mac_addr)
{
	struct cosr_info_set *info = NULL;
	struct wapp_sta *candlist = NULL;
	int i;

	info = os_zalloc(sizeof(struct cosr_info_set));
	if (!info)
		return WAPP_RESOURCE_ALLOC_FAIL;

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		candlist = cosr_get_candlist_sta(wapp, wdev, mac_addr);
		if (!candlist) {
			os_free(info);
			return WAPP_UNEXP;
		}
		if (candlist->cosr_supported && candlist->sta_status == WAPP_STA_CONNECTED) {
			info->sta_info.Candstaid = candlist->cosr_sta_id;
			os_memcpy(info->sta_info.sta_mac, candlist->mac_addr, MAC_ADDR_LEN);
			info->sta_info.u180211ksupport = candlist->is_11k;
			info->sta_info.status = candlist->cosr_status;
			for (i = 0; i < 3; i++)
				info->sta_info.Pldiff[i] = candlist->pathdiff[i];
			debug(DEBUG_CAT_COSR,
				"\n candlist sta info:\n"
				"\t candlist sta id = %d\n"
				"\t candlist sta 11k_cap = %d\n"
				"\t candlist sta sta_status = %d\n"
				"\t candlist sta mac = "MACSTR"\n"
				"\t candlist pathdiff[0] = %d\n"
				"\t candlist pathdiff[1] = %d\n"
				"\t candlist pathdiff[2] = %d\n",
				info->sta_info.Candstaid, info->sta_info.u180211ksupport,
				info->sta_info.status, MAC2STR(info->sta_info.sta_mac),
				info->sta_info.Pldiff[0],
				info->sta_info.Pldiff[1],
				info->sta_info.Pldiff[2]);

			if (wapp_cosr_stainfo_send(wapp, wdev->ifname, info)) {
				debug(DEBUG_CAT_COSR, "update cosr pathdiff to driver\n");
			} else {
				err(DEBUG_CAT_COSR, "cosr stainfo send failed\n");
				os_free(info);
				return WAPP_UNEXP;
			}
		}
	}
	os_free(info);
	return WAPP_SUCCESS;
}


struct wapp_sta *cosr_get_candlist_sta(struct wifi_app *wapp, struct wapp_dev *wdev, const u8 *mac_addr)
{
	int i;
	struct wapp_sta *cli = NULL;
	struct ap_dev *ap = NULL;
	u8 u1BandIdx = 0;

	if (!wapp || !wdev || !mac_addr)
		return cli;
	ap = (struct ap_dev *)wdev->p_dev;
	if (!ap || !ap->client_table)
		return cli;

	u1BandIdx = cosr_get_bandidx(wapp, wdev);
	if (u1BandIdx == 0xFF)
		return cli;
	for (i = 0; i < MAX_COSR_CANDLIST_STA; i++) {
		cli = wapp->candlist_sta[u1BandIdx][i];
		if (cli &&
			cli->cosr_supported &&
			(!os_memcmp(cli->mac_addr, mac_addr, MAC_ADDR_LEN)))
			return cli;
	}

	return NULL;
}


int cosr_del_candlist_sta(struct wifi_app *wapp, struct wapp_dev *wdev, unsigned char *sta_addr)
{
	struct wapp_sta *cli = NULL;
	struct cosr_info_set *cosr_info;
	int i;
	u8 u1BandIdx = 0;

	if (!wapp || !wdev)
		return WAPP_INVALID_ARG;

	cosr_info = os_zalloc(sizeof(struct cosr_info_set));
	if (!cosr_info) {
		os_free(cosr_info);
		return -1;
	}
	u1BandIdx = cosr_get_bandidx(wapp, wdev);
	if (u1BandIdx == 0xFF || u1BandIdx >= MAX_NUM_OF_RADIO) {
		os_free(cosr_info);
		return -1;
	}

	for (i = 0; i < MAX_COSR_CANDLIST_STA; i++) {
		cli = wapp->candlist_sta[u1BandIdx][i];
		if (cli && (os_memcmp(cli->mac_addr, sta_addr, MAC_ADDR_LEN) == 0)) {
			cli->cosr_supported = COSR_NOT_SUPPORT;
			cosr_info->sta_info.Candstaid = cli->cosr_sta_id;
			os_memcpy(cosr_info->sta_info.sta_mac, cli->mac_addr, MAC_ADDR_LEN);
			cosr_info->sta_info.u180211ksupport = cli->is_11k;
			cli->cosr_status = COSR_STA_STATUS_INVALID;
			cosr_info->sta_info.status = cli->cosr_status;
			cosr_info->sta_info.Pldiff[0] = COSR_STA_DEFA_RSSI;
			cosr_info->sta_info.Pldiff[1] = COSR_STA_DEFA_RSSI;
			cosr_info->sta_info.Pldiff[2] = COSR_STA_DEFA_RSSI;
			err(DEBUG_CAT_COSR, "Delete STA MAC ="MACSTR", cosrStaId %d\n",
				MAC2STR(sta_addr), cli->cosr_sta_id);
			wapp_cosr_stainfo_send(wapp, wdev->ifname, cosr_info);
			/* Remove STA ID from Bitmap */
			wapp->cosr_sta_id_bitmap[u1BandIdx] =
				wapp->cosr_sta_id_bitmap[u1BandIdx] & (~(BIT(cli->cosr_sta_id)));
			/* set candlist sta mac addr to 0s */
			os_memset(cli->mac_addr, 0, MAC_ADDR_LEN);
			break;
		}
	}

	os_free(cosr_info);

	return WAPP_SUCCESS;
}


struct cosr_bcn_report_list *cosr_ap_get_peer_rssi(struct wifi_app *wapp, struct wapp_dev *wdev,
						struct ap_dev *ap, const u8 *mac_addr)
{
	int i;
	int max_rssi = 0;
	struct cosr_bcn_report_list *e;
	u8 target_mac[MAC_ADDR_LEN] = {0};

	if (!wapp || !wdev || !ap) {
		err(DEBUG_CAT_COSR, "Input arg invalid\n");
		return NULL;
	}

	if (ap->candlist_sta[0] == NULL)
		return NULL;
	max_rssi = ap->candlist_sta[0]->uplink_rssi;

	for (i = 0; i < MAX_COSR_CANDLIST_STA; i++) {
		if (!ap->candlist_sta[i] &&
			ap->candlist_sta[i]->sta_status == WAPP_STA_CONNECTED &&
			ap->candlist_sta[i]->uplink_rssi > max_rssi) {
			max_rssi = ap->candlist_sta[i]->uplink_rssi;
			os_memcpy(target_mac, ap->candlist_sta[i]->mac_addr, MAC_ADDR_LEN);
		}
	}

	e = cosr_get_bcn_reportlist(wapp, mac_addr, target_mac);
	if (e == NULL) {
		err(DEBUG_CAT_COSR, "Can`t get bcn report result\n");
		return NULL;
	}
	return e;

}

int cosr_clear_apinfo(struct wifi_app *wapp, struct wapp_dev *wdev, u8 apid)
{
	struct cosr_info_set *info;

	info = os_zalloc(sizeof(struct cosr_info_set));
	if (!info)
		return WAPP_RESOURCE_ALLOC_FAIL;

	info->ap_info.apId = apid;
	os_memset(info->ap_info.aCoorAPBSSID, 0, MAC_ADDR_LEN);
	info->ap_info.CoorAPStatus = 0;
	info->ap_info.Rssi = 0;

	debug(DEBUG_CAT_COSR,
		"cosr_ap_info_clear:\n"
		"\t coorap_apid = %d\n"
		"\t coorap_status = %d\n"
		"\t coorap_rssi = %d\n"
		"\t coorap_bssid ="MACSTR"\n",
		info->ap_info.apId, info->ap_info.CoorAPStatus,
		info->ap_info.Rssi, MAC2STR(info->ap_info.aCoorAPBSSID));
	wapp_cosr_apinfo_send(wapp, wdev->ifname, info);
	os_free(info);
	return WAPP_SUCCESS;

}

int cosr_set_apinfo(struct wifi_app *wapp, struct wapp_dev *wdev, const u8 *mac_addr, u8 coap_status)
{
	struct cosr_info_set *info;
	struct cosr_ap_candlist_ap *e;

	info = os_zalloc(sizeof(struct cosr_info_set));
	if (!info)
		return WAPP_RESOURCE_ALLOC_FAIL;
	e = cosr_ap_get_candlist_per_band(wapp, wdev, mac_addr);
	if (!e) {
		err(DEBUG_CAT_COSR, "this ap not in candlist ap\n");
		os_free(info);
		return WAPP_UNEXP;
	}

	info->ap_info.apId = e->apid;
	os_memcpy(info->ap_info.aCoorAPBSSID, mac_addr, MAC_ADDR_LEN);
	info->ap_info.CoorAPStatus = coap_status;
	info->ap_info.Rssi = e->rssi; /*bcn_req meas */

	debug(DEBUG_CAT_COSR,
		"cosr_ap_info_show:\n"
		"\t coorap_apid = %d\n"
		"\t coorap_status = %d\n"
		"\t coorap_rssi = %d\n"
		"\t coorap_bssid ="MACSTR"\n",
		info->ap_info.apId, info->ap_info.CoorAPStatus,
		info->ap_info.Rssi, MAC2STR(info->ap_info.aCoorAPBSSID));
	wapp_cosr_apinfo_send(wapp, wdev->ifname, info);
	os_free(info);
	return WAPP_SUCCESS;

}

int cosr_ap_candlist_ap_count_per_band(struct wifi_app *wapp, struct wapp_dev *wdev)
{
	struct cosr_ap_candlist_ap *e;
	int i = 0;
	u8 u1Bandidx = 0;
	if (wapp == NULL)
		return -1;
	u1Bandidx = cosr_get_bandidx(wapp, wdev);
	if (u1Bandidx == 0xFF)
		return -1;
	e = wapp->candlist_ap[u1Bandidx];
	while (e) {
		e = e->next;
		i++;
	}
	return i;
}

struct cosr_ap_candlist_ap *cosr_ap_get_candlist_per_band(struct wifi_app *wapp, struct wapp_dev *wdev,
					 const u8 *bssid)
{
	struct cosr_ap_candlist_ap *e;
	u8 u1Bandidx = 0;

	if (wapp == NULL || bssid == NULL)
		return NULL;

	u1Bandidx = cosr_get_bandidx(wapp, wdev);
	if (u1Bandidx == 0xFF)
		return NULL;

	e = wapp->candlist_ap[u1Bandidx];
	while (e) {
		if (os_memcmp(e->bssid, bssid, MAC_ADDR_LEN) == 0)
			return e;
		e = e->next;
	}
	return NULL;
}

int cosr_ap_get_candlist_missing_apid(u8 *nums, u8 length)
{
	int sum = 0;

	for (int i = 0; i < length; i++)
		sum += i;

	for (int i = 0; i < length; i++)
		sum -= nums[i];

	return sum;

}
int cosr_ap_set_coorap_id_per_band(struct wifi_app *wapp, struct wapp_dev *wdev, const u8 *bssid)
{
	struct cosr_ap_candlist_ap *e;
	u8 cosr_ap_count;
	int apid = 0;
	int i = 0;
	u8 nums[3] = {0};
	u8 u1Bandidx = 0;

	u1Bandidx = cosr_get_bandidx(wapp, wdev);
	if (u1Bandidx == 0xFF)
		return -1;
	cosr_ap_count = cosr_ap_candlist_ap_count_per_band(wapp, wdev);
	notice(DEBUG_CAT_COSR, "cosr ap count has %d\n", cosr_ap_count);
	e = wapp->candlist_ap[u1Bandidx];

	if (cosr_ap_count > MAX_COSR_CO_AP_COUNT)
		return -1;

	if (cosr_ap_count == 0) {
		apid = 0;
		return apid;
	}

	if (cosr_ap_get_candlist_per_band(wapp, wdev, bssid) != NULL) {
		apid = e->apid;
		return apid;
	}

	if (cosr_ap_count == 1) {
		while (e) {
			apid = e->apid;
			e = e->next;
		}

		if (apid == 2) {
			apid = 0;
			return apid;
		}
		if (apid < 2) {
			apid += 1;
			return apid;
		}
	}

	if (cosr_ap_count == 2) {
		while (e && i < sizeof(nums)) {
			nums[i++] = e->apid;
			e = e->next;
		}
		apid = cosr_ap_get_candlist_missing_apid(nums, MAX_COSR_CO_AP_COUNT);
		i = 0;
		return apid;
	}

	return WAPP_SUCCESS;
}

void cosr_ap_alive_check(void *eloop_ctx, void *sock_ctx)
{
	struct wapp_dev *wdev = (struct wapp_dev *)eloop_ctx;
	struct wifi_app *wapp = NULL;
	struct cosr_ap_candlist_ap *eAP = (struct cosr_ap_candlist_ap *)sock_ctx;
	struct cosr_ap_candlist_ap *prev = NULL;
	struct cosr_ap_candlist_ap *eAPlist = NULL;

	if (wdev == NULL)
		return;
	wapp = wdev->wapp;
	if (wapp == NULL)
		return;
	if (eAP) {
		if (eAP->bcn_detect == FALSE) {
			eAPlist = wapp->candlist_ap[eAP->band];
			while (eAPlist) {
				if (os_memcmp(eAPlist->bssid, eAP->bssid, MAC_ADDR_LEN) == 0) {
					if (prev == NULL)
						wapp->candlist_ap[eAP->band] = eAPlist->next;
					else
						prev->next = eAPlist->next;
					notice(DEBUG_CAT_COSR, "Removed BSSID " MACSTR " from candlist_ap\n",
								MAC2STR(eAP->bssid));
					cosr_clear_apinfo(wapp, wdev, eAP->apid);
					os_free(eAP);
					break;
				}
				prev = eAPlist;
				eAPlist = eAPlist->next;
			}
		} else {
			eAP->bcn_detect = FALSE;
			eloop_register_timeout(60, 0, cosr_ap_alive_check, wdev, eAP);
		}
	}
}


int cosr_ap_add_candlist_ap_per_band(struct wifi_app *wapp, struct wapp_dev *wdev, const u8 *bssid, u8 rssi, const u8 *apclimac)
{
	struct cosr_ap_candlist_ap *e;
	int apid = 0;
	u8 u1Bandidx = 0;
	u8 invalidmac[MAC_ADDR_LEN] = {0};

	if (wapp == NULL || bssid == NULL)
		return WAPP_INVALID_ARG;
	u1Bandidx = cosr_get_bandidx(wapp, wdev);
	if (u1Bandidx == 0xFF)
		return WAPP_INVALID_ARG;
	e = cosr_ap_get_candlist_per_band(wapp, wdev, bssid);
	if (e) {
		e->count++;
		notice(DEBUG_CAT_COSR, "BSSID " MACSTR " candlist_ap count incremented to %d\n",
			MAC2STR(bssid), e->count);
		if (os_memcmp(e->apcli_mac, apclimac, MAC_ADDR_LEN) != 0)
			os_memcpy(e->apcli_mac, apclimac, MAC_ADDR_LEN);

		return e->count;
	}

	apid = cosr_ap_set_coorap_id_per_band(wapp, wdev, bssid);
	if (apid < 0)
		return WAPP_INVALID_ARG;

	e = os_zalloc(sizeof(*e));
	if (e == NULL)
		return WAPP_RESOURCE_ALLOC_FAIL;
	os_memcpy(e->bssid, bssid, MAC_ADDR_LEN);
	os_memcpy(e->apcli_mac, apclimac, MAC_ADDR_LEN);
	e->apid = apid;
	e->count = 1;
	e->rssi = rssi;
	e->next = wapp->candlist_ap[u1Bandidx];
	wapp->candlist_ap[u1Bandidx] = e;
	e->bcn_detect = FALSE;
	e->bcn_detect_cnt = 0;
	e->band = u1Bandidx;
	/* Deletect Candlist STA if it's MAC Addr matches NeighborAP's APcli MAC */
	/* if apcli mac is all 0s, skip */
	if (os_memcmp(e->apcli_mac, invalidmac, MAC_ADDR_LEN) != 0)
		cosr_del_candlist_sta(wapp, wdev, e->apcli_mac);

	/* First AP Add, by white list command or auto association */
	/* then execute SR off and SCS off command */
	if (cosr_ap_candlist_ap_count_per_band(wapp, wdev) == 1) {
		cosr_system_cmd_w_if(wapp, COSR_SR_DISABLE, wdev->ifname);
		cosr_system_cmd_w_if(wapp, COSR_SCS_DISABLE, wdev->ifname);
	}

	notice(DEBUG_CAT_COSR, "Added BSSID " MACSTR " into candlist_ap apid=%d\n",
			MAC2STR(bssid), e->apid);

	if (!wdev->radio || !wdev->radio->radio_band)
		return WAPP_UNEXP;
	if (wapp->cosr_ap_mode[*wdev->radio->radio_band] == TRUE)
		eloop_register_timeout(10, 0, cosr_ap_alive_check, wdev, e);

	return e->count;
}



int cosr_ap_del_candlist_ap_per_band(struct wifi_app *wapp, struct wapp_dev *wdev, const u8 *bssid)
{
	struct cosr_ap_candlist_ap *e, *prev = NULL;
	u8 u1Bandidx;
	if (wapp == NULL || bssid == NULL)
		return WAPP_INVALID_ARG;
	u1Bandidx = cosr_get_bandidx(wapp, wdev);
	if (u1Bandidx == 0xFF)
		return -1;
	e = wapp->candlist_ap[u1Bandidx];
	while (e) {
		if (os_memcmp(e->bssid, bssid, MAC_ADDR_LEN) == 0) {
			cosr_clear_apinfo(wapp, wdev, e->apid);
			if (prev == NULL)
				wapp->candlist_ap[u1Bandidx] = e->next;
			else
				prev->next = e->next;
			notice(DEBUG_CAT_COSR, "Removed BSSID " MACSTR " from candlist_ap\n",
						MAC2STR(bssid));
			eloop_cancel_timeout(cosr_ap_alive_check, wdev, e);
			os_free(e);
			return WAPP_SUCCESS;
		}
		prev = e;
		e = e->next;
	}
	return -1;
}

void cosr_ap_clear_candlist_ap_per_band(struct wifi_app *wapp, struct wapp_dev *wdev)
{
	struct cosr_ap_candlist_ap *e, *prev;
	int max_count = 0;
	u8 u1Bandidx = 0;
	if (wapp == NULL)
		return;
	u1Bandidx = cosr_get_bandidx(wapp, wdev);
	if (u1Bandidx == 0xFF)
		return;

	e = wapp->candlist_ap[u1Bandidx];
	wapp->candlist_ap[u1Bandidx] = NULL;
	while (e) {
		if (e->count > max_count)
			max_count = e->count;
		cosr_clear_apinfo(wapp, wdev, e->apid);
		prev = e;
		e = e->next;
		debug(DEBUG_CAT_COSR,
			"Removed BSSID " MACSTR " from candlist_ap (clear)\n",
			MAC2STR(prev->bssid));
		os_free(prev);
	}
}

int cosr_ap_set_coorap_status_per_band(struct wifi_app *wapp, struct wapp_dev *wdev, const u8 *bssid, u8 ap_status)
{
	struct cosr_ap_candlist_ap *e;
	u8 u1Bandidx = 0;
	if (wapp == NULL || bssid == NULL)
		return -1;
	u1Bandidx = cosr_get_bandidx(wapp, wdev);
	if (u1Bandidx == 0xFF)
		return -1;
	e = wapp->candlist_ap[u1Bandidx];
	while (e) {
		if (os_memcmp(e->bssid, bssid, MAC_ADDR_LEN) == 0) {
			e->cosr_status = ap_status;
			notice(DEBUG_CAT_COSR, "cosr ap mac:"MACSTR" set cosr_status is:%d\n",
			MAC2STR(bssid), e->cosr_status);
			break;
		}
		e = e->next;
	}

	return 0;
}

int cosr_ap_get_coorap_status_per_band(struct wifi_app *wapp, struct wapp_dev *wdev, const u8 *bssid)
{
	struct cosr_ap_candlist_ap *e;
	u8 ap_status = 0;
	u8 u1Bandidx = 0;

	if (wapp == NULL || bssid == NULL)
		return -1;
	u1Bandidx = cosr_get_bandidx(wapp, wdev);
	if (u1Bandidx == 0xFF)
		return -1;
	if (u1Bandidx >= ARRAY_SIZE(wapp->candlist_ap))
		return -1;
	e = wapp->candlist_ap[u1Bandidx];
	while (e) {
		if (os_memcmp(e->bssid, bssid, MAC_ADDR_LEN) == 0) {
			ap_status = e->cosr_status;
				notice(DEBUG_CAT_COSR, "cosr ap mac:"MACSTR" get cosr_status is:%d\n",
				MAC2STR(bssid), ap_status);
			return ap_status;
		}
		e = e->next;
	}

	return -1;
}


int cosr_blacklist_count(struct wifi_app *wapp)
{
	struct cosr_ap_blacklist *e;
	int i = 0;

	if (wapp == NULL)
		return -1;
	e = wapp->blacklist;
	while (e) {
		e = e->next;
		i++;
	}
	return i;
}

struct cosr_ap_blacklist *cosr_ap_get_blacklist(struct wifi_app *wapp,
					 const u8 *bssid)
{
	struct cosr_ap_blacklist *e;

	if (wapp == NULL || bssid == NULL)
		return NULL;
	e = wapp->blacklist;
	while (e) {
		if (os_memcmp(e->bssid, bssid, MAC_ADDR_LEN) == 0)
			return e;

		e = e->next;
	}

	return NULL;
}
void cosr_ap_clear_blacklist(void *eloop_ctx, void *sock_ctx)
{
	struct wifi_app *wapp = (struct wifi_app *)eloop_ctx;
	struct cosr_ap_blacklist *e, *prev;
	int max_count = 0;

	if (wapp == NULL)
		return;

	e = wapp->blacklist;
	wapp->blacklist = NULL;
	while (e) {
		if (e->count > max_count)
			max_count =  e->count;
		prev = e;
		e = e->next;
		debug(DEBUG_CAT_COSR, "Removed BSSID " MACSTR " from blacklist (clear)\n",
			MAC2STR(prev->bssid));
		os_free(prev);
		eloop_cancel_timeout(cosr_ap_clear_blacklist, wapp, NULL);
	}
	wapp->extra_blacklist_count += max_count;
}

int cosr_ap_del_blacklist(struct wifi_app *wapp, const u8 *bssid)
{
	struct cosr_ap_blacklist *e, *prev = NULL;

	if (wapp == NULL || bssid == NULL)
		return WAPP_INVALID_ARG;

	e = wapp->blacklist;
	while (e) {
		if (os_memcmp(e->bssid, bssid, MAC_ADDR_LEN) == 0) {
			if (prev == NULL)
				wapp->blacklist = e->next;
			else
				prev->next = e->next;

			notice(DEBUG_CAT_COSR, "Removed BSSID " MACSTR " from blacklist\n",
								MAC2STR(bssid));
			os_free(e);
			return WAPP_SUCCESS;
		}
		prev = e;
		e = e->next;
	}

	return WAPP_UNEXP;
}


int cosr_ap_add_blacklist(struct wifi_app *wapp, const u8 *bssid)
{
	struct cosr_ap_blacklist *e;

	if (wapp == NULL || bssid == NULL)
		return WAPP_INVALID_ARG;

	e = cosr_ap_get_blacklist(wapp, bssid);
	if (e) {
		e->count++;
		debug(DEBUG_CAT_COSR, "BSSID " MACSTR " blacklist count incremented to %d\n",
			   MAC2STR(bssid), e->count);
		return e->count;
	}

	e = os_zalloc(sizeof(*e));
	if (e == NULL)
		return WAPP_RESOURCE_ALLOC_FAIL;
	os_memcpy(e->bssid, bssid, MAC_ADDR_LEN);
	e->count = 1;
	e->next = wapp->blacklist;
	wapp->blacklist = e;
	debug(DEBUG_CAT_COSR, "Added BSSID " MACSTR " into blacklist\n",
			   MAC2STR(bssid));
	eloop_register_timeout(BLACKLIST_TIME, 0, cosr_ap_clear_blacklist, wapp, NULL);
	return e->count;
}

int wapp_cosr_add_whitelist_ap(struct wifi_app *wapp, char *iface, u8 *mac_addr)
{
	struct wapp_dev *wdev = NULL;
	struct cosr_ap_blacklist *blacklist = NULL;
	int cosr_status = 0;
	int ret = 0;

	wdev = wapp_dev_list_lookup_by_ifname(wapp, iface);
	if (wdev == NULL) {
		err(DEBUG_CAT_COSR, "%s returned NULL for interface %s\n", __func__, iface);
		return WAPP_UNEXP;
	}

	if (wdev->dev_type != WAPP_DEV_TYPE_AP)
		return WAPP_UNEXP;

	debug(DEBUG_CAT_COSR, "CoAP candlist AP count %d\n",
			cosr_ap_candlist_ap_count_per_band(wapp, wdev));
	if (cosr_ap_candlist_ap_count_per_band(wapp, wdev) < MAX_COSR_CO_AP_COUNT ||
		cosr_ap_get_candlist_per_band(wapp, wdev, mac_addr) != NULL) {
		blacklist = cosr_ap_get_blacklist(wapp, mac_addr);
		if (blacklist) {
			ret = cosr_ap_del_blacklist(wapp, mac_addr);
			if (ret != 0)
				err(DEBUG_CAT_COSR, "cosr_ap del blacklist failed!\n");
		}

		if (cosr_ap_get_candlist_per_band(wapp, wdev, mac_addr) == NULL) {
			err(DEBUG_CAT_COSR, "CoAP Not Candlist\n");
			cosr_ap_add_candlist_ap_per_band(wapp, wdev, mac_addr, 0, mac_addr);
		}

		cosr_status = cosr_ap_get_coorap_status_per_band(wapp, wdev, mac_addr);
		if (cosr_status == -1) {
			err(DEBUG_CAT_COSR, "Unexpected cosr_ap_coorap_status_per_band!\n");
			cosr_status = 0;
		}
		cosr_status = cosr_status | AIRTIME_STATE_BOTH;
		cosr_ap_set_coorap_status_per_band(wapp, wdev, mac_addr, cosr_status);
		cosr_set_apinfo(wapp, wdev, mac_addr, cosr_status);

		}
	return WAPP_SUCCESS;
}

int wapp_cosr_del_whitelist_ap(struct wifi_app *wapp, char *iface, u8 *mac_addr)
{
	struct wapp_dev *wdev = NULL;

	wdev = wapp_dev_list_lookup_by_ifname(wapp, iface);
	if (wdev == NULL) {
		err(DEBUG_CAT_COSR, "%s returned NULL for interface %s\n", __func__, iface);
		return WAPP_UNEXP;
	}
	if (wdev->dev_type != WAPP_DEV_TYPE_AP)
		return WAPP_UNEXP;
	cosr_ap_del_candlist_ap_per_band(wapp, wdev, mac_addr);
	return WAPP_SUCCESS;
}

int wapp_cosr_clear_whitelist_ap(struct wifi_app *wapp, char *iface)
{
	struct wapp_dev *wdev = NULL;
	struct cosr_ap_candlist_ap *e, *prev = NULL;
	u8 u1Bandidx;

	if (wapp == NULL)
		return WAPP_INVALID_ARG;

	wdev = wapp_dev_list_lookup_by_ifname(wapp, iface);
	if (wdev == NULL) {
		err(DEBUG_CAT_COSR, "%s returned NULL for interface %s\n", __func__, iface);
		return WAPP_UNEXP;
	}

	if (wdev->dev_type != WAPP_DEV_TYPE_AP)
		return WAPP_UNEXP;

	u1Bandidx = cosr_get_bandidx(wapp, wdev);
	if (u1Bandidx == 0xFF)
		return WAPP_UNEXP;

	e = wapp->candlist_ap[u1Bandidx];
	wapp->candlist_ap[u1Bandidx] = NULL;
	while (e) {
		cosr_clear_apinfo(wapp, wdev, e->apid);
		prev = e;
		e = e->next;
		debug(DEBUG_CAT_COSR, "Removed BSSID" MACSTR "from candlist (clear)\n",
			MAC2STR(prev->bssid));
		os_free(prev);
	}

	return WAPP_SUCCESS;
}

int wapp_cosr_show_whitelist_ap(struct wifi_app *wapp, char *iface)
{
	struct wapp_dev *wdev = NULL;
	struct cosr_ap_candlist_ap *e;
	u8 u1Bandidx;

	if (wapp == NULL)
		return WAPP_INVALID_ARG;

	wdev = wapp_dev_list_lookup_by_ifname(wapp, iface);
	if (wdev == NULL) {
		err(DEBUG_CAT_COSR, "%s returned NULL for interface %s\n", __func__, iface);
		return WAPP_UNEXP;
	}

	if (wdev->dev_type != WAPP_DEV_TYPE_AP)
		return WAPP_UNEXP;

	u1Bandidx = cosr_get_bandidx(wapp, wdev);
	if (u1Bandidx == 0xFF)
		return WAPP_UNEXP;

	e = wapp->candlist_ap[u1Bandidx];
	while (e) {
		notice(DEBUG_CAT_COSR, "Candlist BSSID :" MACSTR "\n",
			MAC2STR(e->bssid));
		e = e->next;
	}

	return WAPP_SUCCESS;

}

int wapp_cosr_ap_mode_set_per_band(struct wifi_app *wapp, char *iface, BOOLEAN command)
{
	struct wapp_dev *wdev = NULL;
	int ret = 0;

	if (wapp == NULL)
		return WAPP_UNEXP;

	wdev = wapp_dev_list_lookup_by_ifname(wapp, iface);
	if (!wdev) {
		DBGPRINT(RT_DEBUG_ERROR, "wdev is null\n");
		return WAPP_UNEXP;
	} else if (wdev->dev_type != WAPP_DEV_TYPE_AP) {
		err(DEBUG_CAT_COSR, "Invalid device type: %d for ifname %s\n",
				 wdev->dev_type, wdev->ifname);
		return WAPP_UNEXP;
	}


	ret = wapp_cosr_clear_whitelist_ap(wapp, iface);
	if (ret != WAPP_SUCCESS)
		return WAPP_UNEXP;

	if (!wdev->radio || !wdev->radio->radio_band)
		return WAPP_UNEXP;

	wapp->cosr_ap_mode[*(wdev->radio->radio_band)] = command;
	debug(DEBUG_CAT_COSR, "wdev Type is %d ifname %s cosr ap mode %d radioband %d\n",
					wdev->dev_type, wdev->ifname,
					wapp->cosr_ap_mode[*(wdev->radio->radio_band)],
					*(wdev->radio->radio_band));


	return WAPP_SUCCESS;
}

struct cosr_bcn_report_list *cosr_get_bcn_reportlist(struct wifi_app *wapp, const u8 *bssid, const u8 *sta_mac)
{
	struct cosr_bcn_report_list *e;

	if (wapp == NULL || bssid == NULL)
		return NULL;
	debug(DEBUG_CAT_COSR, "BSSID "MACSTR" STAMAC "MACSTR"\n", MAC2STR(bssid), MAC2STR(sta_mac));

	e = wapp->bcn_report_list;
	while (e) {
		debug(DEBUG_CAT_COSR, "BCNRPT BSSID "MACSTR" STAMAC "MACSTR"\n",
			MAC2STR(e->bssid), MAC2STR(e->sta_mac));
		debug(DEBUG_CAT_COSR, "%d %d\n",
			os_memcmp(e->bssid, bssid, MAC_ADDR_LEN),
			os_memcmp(e->sta_mac, sta_mac, MAC_ADDR_LEN));
		if (os_memcmp(e->bssid, bssid, MAC_ADDR_LEN) == 0 &&
			os_memcmp(e->sta_mac, sta_mac, MAC_ADDR_LEN) == 0)
			return e;
		e = e->next;
	}

	return NULL;
}

struct cosr_bcn_report_list *cosr_update_bcn_reportlist(struct wifi_app *wapp, const u8 *bssid,
								const u8 *sta_mac, u8 rcpi)
{
	struct cosr_bcn_report_list *e;

	if (wapp == NULL || bssid == NULL)
		return NULL;
	e = wapp->bcn_report_list;
	while (e) {
		if ((os_memcmp(e->bssid, bssid, MAC_ADDR_LEN) == 0) &&
			(os_memcmp(e->sta_mac, sta_mac, MAC_ADDR_LEN) == 0)) {
			e->rcpi = rcpi;
			e->count = 1;
			err(DEBUG_CAT_COSR, "Update " MACSTR " rssi to %d", MAC2STR(e->bssid), e->rcpi);
			return e;
		}
		e = e->next;
	}

	return NULL;
}


int cosr_add_bcn_reportlist(struct wifi_app *wapp, const u8 *bssid, const u8 *sta_mac, u8 rcpi)
{
	struct cosr_bcn_report_list *e;

	if (wapp == NULL || bssid == NULL)
		return WAPP_INVALID_ARG;
	e = cosr_get_bcn_reportlist(wapp, bssid, sta_mac);
	if (e) {
		e->count++;
		debug(DEBUG_CAT_COSR, "BSSID " MACSTR " same report count incremented to %d\n",
			MAC2STR(bssid), e->count);
		return e->count;
	}

	e = os_zalloc(sizeof(*e));
	if (e == NULL)
		return WAPP_RESOURCE_ALLOC_FAIL;
	os_memcpy(e->bssid, bssid, MAC_ADDR_LEN);
	os_memcpy(e->sta_mac, sta_mac, MAC_ADDR_LEN);
	e->count = 1;
	e->rcpi = rcpi;
	e->next = wapp->bcn_report_list;
	wapp->bcn_report_list = e;
	notice(DEBUG_CAT_COSR, "Get BSSID " MACSTR " bcn report results\n",
			MAC2STR(bssid));
	return e->count;
}

int cosr_del_report_list(struct wifi_app *wapp, const u8 *bssid, const u8 *sta_mac)
{
	struct cosr_bcn_report_list *e, *prev = NULL;

	if (wapp == NULL || bssid == NULL)
		return WAPP_INVALID_ARG;
	e = wapp->bcn_report_list;
	while (e) {
		if ((os_memcmp(e->bssid, bssid, MAC_ADDR_LEN) == 0)  &&
			(os_memcmp(e->sta_mac, sta_mac, MAC_ADDR_LEN) == 0)) {
			if (prev == NULL)
				wapp->bcn_report_list = e->next;
			else
				prev->next = e->next;

			notice(DEBUG_CAT_COSR, "Removed BSSID " MACSTR" from " MACSTR" bcn_reportlist\n",
					MAC2STR(bssid), MAC2STR(sta_mac));
			os_free(e);
			return WAPP_SUCCESS;
		}
		prev = e;
		e = e->next;
	}

	return WAPP_UNEXP;
}
void cosr_clear_bcn_reportlist(struct wifi_app *wapp)
{
	struct cosr_bcn_report_list *e, *prev;
	int max_count = 0;

	e = wapp->bcn_report_list;
	wapp->bcn_report_list = NULL;
	while (e) {
		if (e->count > max_count)
			max_count = e->count;
		prev = e;
		e = e->next;
		notice(DEBUG_CAT_COSR, "Removed BSSID " MACSTR " from bcn_report_list (clear)\n",
				MAC2STR(prev->bssid));
		os_free(prev);

	}
}
