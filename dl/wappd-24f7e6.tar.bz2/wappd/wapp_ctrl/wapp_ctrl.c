/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#include "wapp_ctrl.h"
#include "util.h"

static inline size_t os_strlncpy(char *dest, const char *src, size_t siz)
{
	const char *s = src;
	size_t left = siz;

	if (left) {
	/* Copy string up to the maximum size of the dest buffer*/
		while (--left != 0) {
			*dest = *s;
			if (*s == '\0')
				break;
			dest++;
			s++;
			/*if ((*dest++ = *s++) == '\0') break;*/
		}
	}

	if (left == 0) {
	/* Not enough room for the string; force NUL-termination*/
		if (siz != 0)
			*dest = '\0';
		while (*s++)
			; /* determine total src string length */
	}

	return s - src - 1;
}

struct wapp_ctrl *wapp_ctrl_open(const char *ctrl_path)
{
	struct wapp_ctrl *ctrl;
	int ret;

	ctrl = os_zalloc(sizeof(*ctrl));

	if (!ctrl) {
		err(DEBUG_CAT_MISC, "memory is not available\n");
		return NULL;
	}

	ctrl->s = socket(AF_UNIX, SOCK_STREAM, 0);

	if (ctrl->s < 0) {
		os_free(ctrl);
		err(DEBUG_CAT_MISC, "create socket for ctrl interface fail\n");
		return NULL;
	}

	ctrl->local.sun_family = AF_UNIX;
	ret = os_snprintf(ctrl->local.sun_path, sizeof(ctrl->local.sun_path), "/tmp/hsctrl_%d", getpid());
	if (os_snprintf_error(sizeof(ctrl->local.sun_path), ret))
		err(DEBUG_CAT_MISC, "snprintf error\n");

	if (bind(ctrl->s, (struct sockaddr *)&ctrl->local, sizeof(ctrl->local)) < 0) {
		err(DEBUG_CAT_MISC, "Bind local domain address fail\n");
		close(ctrl->s);
		os_free(ctrl);
		return NULL;
	}

	ctrl->dest.sun_family = AF_UNIX;
	os_strlncpy(ctrl->dest.sun_path, ctrl_path, sizeof(ctrl->dest.sun_path));
	ctrl->dest.sun_path[sizeof(ctrl->dest.sun_path) - 1] = '\0';

	if (connect(ctrl->s, (struct sockaddr *)&ctrl->dest, sizeof(ctrl->dest)) < 0) {
		err(DEBUG_CAT_MISC, "Connect to server address fail\n");
		unlink(ctrl->local.sun_path);
		close(ctrl->s);
		os_free(ctrl);
		return NULL;
	}

	return ctrl;
}

void wapp_ctrl_close(struct wapp_ctrl *ctrl)
{
	unlink(ctrl->local.sun_path);
	close(ctrl->s);
	os_free(ctrl);
}

int wapp_ctrl_command(struct wapp_ctrl *ctrl, const char *cmd, size_t cmd_len)
{
#define REPLY_LEN 5210
	struct timeval tv;
	fd_set rfds;
	char *buf = NULL, *tmp = NULL, *reply = NULL;
	int res = 0, rcv_len = 0, reply_len = 0;

	if (send(ctrl->s, cmd, cmd_len, 0) < 0) {
		printf("%s send fail\n", __func__);
		return -1;
	}
	buf = malloc(REPLY_LEN);
	if (!buf) {
		printf("%s fail to alloc reply buffer; size=5120\n", __func__);
		return -1;
	}
	memset(buf, 0, REPLY_LEN);

	errno = 0;
	for ( ; ; ) {
		tv.tv_sec = 2;
		tv.tv_usec = 0;
		FD_ZERO(&rfds);
		FD_SET(ctrl->s, &rfds);
		res = select(ctrl->s + 1, &rfds, NULL, NULL, &tv);
		if (res <= 0)
			goto out;
		if (FD_ISSET(ctrl->s, &rfds)) {
			while (1) {
				res = recv(ctrl->s, buf, REPLY_LEN, 0);
				if (res < 0)
					goto out;
				if (res < REPLY_LEN) {
					buf[res] = '\0';
					tmp = realloc(reply, rcv_len + res + 1);
					if (tmp == NULL) {
						printf("%s fail to realloc reply buffer", __func__);
						res = -ENOMEM;
						goto out;
					}
					reply = tmp;
					memcpy(reply + rcv_len, buf, res + 1);
					rcv_len += res + 1;
					reply_len = rcv_len;

					res = 0;
					goto out;
				}
				tmp = realloc(reply, rcv_len + REPLY_LEN);
				if (tmp == NULL) {
					printf("%s fail to realloc reply buffer", __func__);
					res = -ENOMEM;
					goto out;
				}
				reply = tmp;
				memcpy(reply + rcv_len, buf, REPLY_LEN);
				rcv_len += REPLY_LEN;
				memset(buf, 0, REPLY_LEN);
			}
		}
	}
out:
	if (res == 0 && reply && reply_len) {
		//printf("%s reply=%d\n%s\n", __func__, reply_len, reply);
		free(reply);
		free(buf);
		return 0;
	}

	if (buf)
		free(buf);
	if (reply)
		free(reply);

	return res;
}

int wapp_ctrl_event_regiser(struct wapp_ctrl *ctrl)
{
	int ret = 0;

	ret = wapp_ctrl_command(ctrl, "EVENT_REGISTER", 14);

	return ret;
}

int wapp_ctrl_event_unregister(struct wapp_ctrl *ctrl)
{
	int ret = 0;

	ret = wapp_ctrl_command(ctrl, "EVENT_UNREGISTER", 16);

	return ret;
}
