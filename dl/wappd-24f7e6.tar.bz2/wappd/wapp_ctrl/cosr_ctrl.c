/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2020-2021  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#include "wapp_cmm.h"
#include "wapp_ctrl.h"
#include "wapp_cli.h"
#ifdef COSR_SUPPORT
#include "cosr.h"
#endif


static int wapp_cosr_cli_cmd(struct wapp_ctrl *ctrl, const char *src_cmd, int min_args, int argc, char *argv[])
{
	char rsp[2048];
	size_t rsp_len = 0;
	char cmd[2048];
	int ret;
	int i = 0, j = 0, k = 0;

	os_memset(cmd, 0, 2048);
	os_memset(rsp, 0, 2048);
	rsp_len = sizeof(rsp) - 1;

	ret = snprintf(&cmd[i], 2048, "interface=%s\n", argv[0]);
	if (os_snprintf_error(2048, ret))
		err(DEBUG_CAT_COSR, "snprintf error\n");

	i += 11 + os_strlen(argv[0]);
	ret = snprintf(&cmd[i], 2048 - i, "cmd=cosr %s ", src_cmd);
	if (os_snprintf_error(2048 - i, ret))
		err(DEBUG_CAT_COSR, "snprintf error\n");

	notice(DEBUG_CAT_COSR, "argc is %d\n", argc);
	i += os_strlen(src_cmd) + 9;
	DBGPRINT(RT_DEBUG_WARN, "i %d\n", i);
	for (j = 3; j < argc; j++) {
		if (i < 2048) {
			k = (2048 - i);
			if (k > (os_strlen(argv[j] + 1))) {
				ret = snprintf(&cmd[i], 2048 - i, "%s", argv[j]);
				if (os_snprintf_error(2048 - i, ret))
					err(DEBUG_CAT_COSR, "snprintf error\n");

				i += os_strlen(argv[j]);
				ret = snprintf(&cmd[i], 2048 - i, "%s", " ");
				if (os_snprintf_error(2048 - i, ret))
					err(DEBUG_CAT_COSR, "snprintf error\n");

				i++;
			}
		}
	}
	notice(DEBUG_CAT_COSR, "cmd is = %s\n", cmd);

	if (argc < min_args) {
		err(DEBUG_CAT_COSR, "Invalid %s command - at least %d argument%s required.\n", cmd, min_args,
			min_args > 1 ? "s are" : " is");
		return -1;
	}
	return _wapp_ctrl_command(ctrl, cmd, rsp, &rsp_len);
}

static int wapp_cli_cmd_cosr_on_off(struct wapp_ctrl *ctrl, int argc, char *argv[])
{
	return wapp_cosr_cli_cmd(ctrl, "COSR_ENABLE", 1, argc, argv);
}

static int wapp_cli_cmd_cosr_start(struct wapp_ctrl *ctrl, int argc, char *argv[])
{
	return wapp_cosr_cli_cmd(ctrl, "COSR_START", 1, argc, argv);
}

static int wapp_cli_cmd_cosr_stop(struct wapp_ctrl *ctrl, int argc, char *argv[])
{
	return wapp_cosr_cli_cmd(ctrl, "COSR_STOP", 1, argc, argv);
}

static int wapp_cli_cmd_cosr_add_candlist_ap(struct wapp_ctrl *ctrl, int argc, char *argv[])
{
	return wapp_cosr_cli_cmd(ctrl, "COSR_ADD_CANDLIST", 1, argc, argv);
}

static int wapp_cli_cmd_cosr_del_candlist_ap(struct wapp_ctrl *ctrl, int argc, char *argv[])
{
	return wapp_cosr_cli_cmd(ctrl, "COSR_DEL_CANDLIST", 1, argc, argv);
}

static int wapp_cli_cmd_cosr_del_all_candlist_ap(struct wapp_ctrl *ctrl, int argc, char *argv[])
{
	return wapp_cosr_cli_cmd(ctrl, "COSR_CLEAR_CANDLIST", 1, argc, argv);
}

static int wapp_cli_cmd_cosr_show_candlist_info(struct wapp_ctrl *ctrl, int argc, char *argv[])
{
	return wapp_cosr_cli_cmd(ctrl, "COSR_SHOW_CANDLIST_INFO", 1, argc, argv);
}

struct wapp_cli_cmd cosr_cmd[] = {
	{"cosrt_enable", wapp_cli_cmd_cosr_on_off, "enable/disable cosr"},
	{"cosr_start", wapp_cli_cmd_cosr_start, "start cosr <interface>"},
	{"cosr_stop", wapp_cli_cmd_cosr_stop, "stop cosr <interface>"},
	{"cosr_add_candlist", wapp_cli_cmd_cosr_add_candlist_ap, "cosr add candlist <interface><ssid>"},
	{"cosr_del_candlist", wapp_cli_cmd_cosr_del_candlist_ap, "cosr del candlist <interface><ssid>"},
	{"cosr_clear_candlist", wapp_cli_cmd_cosr_del_all_candlist_ap, "cosr del all candlist <interface>"},
	{"cosr_show_candlist", wapp_cli_cmd_cosr_show_candlist_info, "cosr show candlist info"}};

int wapp_cosr_cli_request(struct wapp_ctrl *ctrl, int argc, char *argv[])
{
	struct wapp_cli_cmd *cmd, *match = NULL;
	int ret = 0;

	cmd = cosr_cmd;

	while (cmd->cmd) {
		if (os_strncmp(cmd->cmd, argv[2], os_strlen(argv[2])) == 0) {
			match = cmd;
			break;
		}
		cmd++;
	}

	if (match) {
		ret = match->cmd_handler(ctrl, argc, &argv[0]);
	} else {
		err(DEBUG_CAT_COSR, "Unknown command\n");
		ret = -1;
	}

	return ret;
}

int wapp_cosr_cmd_show_help(struct wapp_ctrl *ctrl, int argc, char *argv[])
{
	struct wapp_cli_cmd *wapp_cmd = cosr_cmd;
	u8 i = 0;

	for (i = 0; (wapp_cmd[i].cmd != NULL); i++)
		err(DEBUG_CAT_COSR, "  %-60s %-50s\n", wapp_cmd[i].cmd, wapp_cmd[i].usage);

	return WAPP_SUCCESS;
}
