// SPDX-License-Identifier: MediaTekProprietary
/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2023-2024  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */
#ifdef EPCS_SUPPORT

#include <stdlib.h>
#include <stdio.h>

#include "debug.h"
#include "wapp_cmm.h"
#include "t2lm.h"

#include "mtk_vendor_nl80211.h"

#ifdef MTK_MLO_MAP_SUPPORT
#ifdef MAP_R6
u8 bc_mac[] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};

void wapp_show_t2lm_map(struct tid_to_link_map *tid_link_map)
{
	u8 i = 0, j = 0;
	char *buf = NULL;
	struct t2lm_control *t2lm_ctrl = NULL;
	int buflen = 4096, ret = 1, offset = 0;

	if (!tid_link_map) {
		err(DEBUG_CAT_T2LM, "invalid pointer\n");
		return;
	}

	buf = os_malloc(buflen);
	if (!buf) {
		err(DEBUG_CAT_T2LM, "alloc memory failed\n");
		return;
	}
	os_memset(buf, 0, buflen);

	ret = snprintf(buf + offset, buflen - offset, "[wappd]------------show t2lm mapping-----------\n");
	if (os_snprintf_error(buflen - offset, ret))
		goto exit;
	offset += ret;

	ret = snprintf(buf + offset, buflen - offset,
		"MLD_ADDR:" MACSTR ", is_bsta_config:%d, tid_to_link_negotiation:%d, num_mapping:%d\n",
		MAC2STR(tid_link_map->mld_mac),	tid_link_map->is_bsta_config,
		tid_link_map->tid_to_link_negotiation, tid_link_map->num_mapping);
	if (os_snprintf_error(buflen - offset, ret))
		goto exit;
	offset += ret;

	for (i = 0; i < tid_link_map->num_mapping; i++) {
		ret = snprintf(buf + offset, buflen - offset, "-----------------t2lm map[%d]------------------\n", i);
		if (os_snprintf_error(buflen - offset, ret))
			goto exit;
		offset += ret;

		ret = snprintf(buf + offset, buflen - offset, "sta_mld_mac:" MACSTR ", add_remove:%d\n",
			MAC2STR(tid_link_map->map[i].sta_mld_mac), tid_link_map->map[i].add_remove);
		if (os_snprintf_error(buflen - offset, ret))
			goto exit;
		offset += ret;

		t2lm_ctrl = (struct t2lm_control *)&tid_link_map->map[i].tid_to_link_control;
		ret = snprintf(buf + offset, buflen - offset,
			"direct:%d, default_link_map:%d, mst_dur_present:%d, exp_dur_present:%d, link_map_size:%d\n",
			t2lm_ctrl->direction, t2lm_ctrl->default_link_map, t2lm_ctrl->mst_dur_present,
			t2lm_ctrl->exp_dur_present, t2lm_ctrl->link_map_size);
		if (os_snprintf_error(buflen - offset, ret))
			goto exit;
		offset += ret;

		ret = snprintf(buf + offset, buflen - offset,
			"mapping_presence:0x%x, expected_duration:0x%02x%02x%02x\n",
			tid_link_map->map[i].mapping_presence, tid_link_map->map[i].expected_duration[0],
			tid_link_map->map[i].expected_duration[1], tid_link_map->map[i].expected_duration[2]);
		if (os_snprintf_error(buflen - offset, ret))
			goto exit;
		offset += ret;

		ret = snprintf(buf + offset, buflen - offset, "tid_map:");
		if (os_snprintf_error(buflen - offset, ret))
			goto exit;
		offset += ret;
		for (j = 0; j < 8; j++) {
			ret = snprintf(buf + offset, buflen - offset, "0x%x, ", tid_link_map->map[i].tid_map[j]);
			if (os_snprintf_error(buflen - offset, ret))
				goto exit;
			offset += ret;
		}

		ret = snprintf(buf + offset, buflen - offset, "\n-------------------------------------------------\n");
		if (os_snprintf_error(buflen - offset, ret))
			goto exit;
		offset += ret;	}

	if (strlen(buf))
		printf("%s\n", buf);
exit:
	if (os_snprintf_error(buflen - offset, ret))
		err(DEBUG_CAT_T2LM, "error happen, ret = %d\n", ret);

	if (buf)
		os_free(buf);
}
#endif

int wapp_handle_map_t2lm_request(struct wifi_app *wapp, char *msg_buf, unsigned short msg_len)
{
	struct tid_to_link_map *tid_link_map = NULL;
	struct wapp_dev *wdev = NULL, *wdev_temp = NULL;
	struct dl_list *dev_list = NULL;
	struct wapp_sta *sta = NULL;
	struct nl_80211_t2lm_cmd t2lm_cmd;
#ifdef MAP_R6
	int i = 0;
	struct ap_dev *ap = NULL;
	struct nl_80211_at2lm_map at2lm;
#endif

	tid_link_map = (struct tid_to_link_map *)msg_buf;
	dev_list = &wapp->dev_list;
	if (tid_link_map->is_bsta_config) {
		dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
			if (wdev->dev_type == WAPP_DEV_TYPE_STA) {
				sta = (struct wapp_sta *)wdev->p_dev;
				if (sta->mlo.is_setup_link_entry) {
					os_memcpy(t2lm_cmd.ta_addr, wdev->mac_addr, ETH_ALEN);
					t2lm_cmd.dir = 2;
					os_memcpy(t2lm_cmd.ra_addr, sta->bssid, ETH_ALEN);
					t2lm_cmd.status_code = 1;
					t2lm_cmd.tid_bit_map = tid_link_map->map[0].mapping_presence;
					os_memcpy(t2lm_cmd.tid_to_link_bitmap, tid_link_map->map[0].tid_map,
									TID_MAX * sizeof(unsigned short));
					wapp_send_t2lm_request_frame(wapp, (char *)&t2lm_cmd, sizeof(struct nl_80211_t2lm_cmd));
					break;
				}
			}
		}
#ifdef MAP_R6
	} else {
		/*show information for debug use*/
		wapp_show_t2lm_map(tid_link_map);

		os_memset(&at2lm, 0, sizeof(at2lm));
		os_memcpy(at2lm.mld_addr, tid_link_map->mld_mac, MAC_ADDR_LEN);
		at2lm.mst_dur = 5120;

		dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
			ap = (struct ap_dev *)wdev->p_dev;
			if (wdev->dev_type != WAPP_DEV_TYPE_AP || !ap)
				continue;

			notice(DEBUG_CAT_T2LM, "%s, mld_addr:" MACSTR "\n", wdev->ifname, MAC2STR(ap->mlo_info.mld_addr));

			if (os_memcmp(ap->mlo_info.mld_addr, tid_link_map->mld_mac, MAC_ADDR_LEN) == 0) {
				for (i = 0; i < tid_link_map->num_mapping; i++) {
					if (os_memcmp(tid_link_map->map[i].sta_mld_mac, bc_mac, MAC_ADDR_LEN) != 0) {
						err(DEBUG_CAT_T2LM, MACSTR "not allowed for at2lm mapping\n",
							MAC2STR(tid_link_map->map[i].sta_mld_mac));
						continue;
					}
					at2lm.dis_link_map = ~tid_link_map->map[i].tid_map[0];
					at2lm.exp_dur = (tid_link_map->map[i].expected_duration[0] << 16) |
							(tid_link_map->map[i].expected_duration[1] << 8) |
							(tid_link_map->map[i].expected_duration[2]);

					at2lm.exp_dur = (at2lm.exp_dur * 1024)/1000;

					wapp->drv_ops->drv_set_t2lm_mapping(
						wapp->drv_data, wdev->ifname, (char *)&at2lm, sizeof(at2lm));
					return 0;
				}
			}
		}
#endif
	}
	return 0;
}

int wapp_send_t2lm_request_frame(struct wifi_app *wapp, char *msg_buf, unsigned short msg_len)
{
	char is_found = 0;
	struct dl_list *dev_list = NULL;
	struct wapp_dev *wdev = NULL, *wdev_temp = NULL;
	struct nl_80211_t2lm_cmd *t2lm_cmd = (struct nl_80211_t2lm_cmd *)msg_buf;

	if (!t2lm_cmd || (msg_len != sizeof(*t2lm_cmd))) {
		err(DEBUG_CAT_T2LM, "invalid t2lm_cmd=%p or msg_len=%d\n", t2lm_cmd, msg_len);
		return -1;
	}

	debug(DEBUG_CAT_T2LM, "t2lm_cmd:\n"
		"ta_addr "MACSTR"; ra addr "MACSTR"\n"
		"tid_bit_map %d\n"
		"Links %02x %02x %02x %02x %02x %02x %02x %02x\n",
		MAC2STR(t2lm_cmd->ta_addr), MAC2STR(t2lm_cmd->ra_addr), t2lm_cmd->tid_bit_map,
		t2lm_cmd->tid_to_link_bitmap[0], t2lm_cmd->tid_to_link_bitmap[1], t2lm_cmd->tid_to_link_bitmap[2],
		t2lm_cmd->tid_to_link_bitmap[3], t2lm_cmd->tid_to_link_bitmap[4], t2lm_cmd->tid_to_link_bitmap[5],
		t2lm_cmd->tid_to_link_bitmap[6], t2lm_cmd->tid_to_link_bitmap[7]);

	dev_list = &wapp->dev_list;
	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list)	{
		if (os_memcmp(wdev->mac_addr, t2lm_cmd->ta_addr, MAC_ADDR_LEN) == 0) {
			is_found = 1;
			break;
		}
	}

	if (!is_found) {
		err(DEBUG_CAT_T2LM, "no interafce mac "MACSTR" not found\n", MAC2STR(t2lm_cmd->ta_addr));
		return MAP_ERROR;
	}

	if (!wapp->drv_ops) {
		err(DEBUG_CAT_T2LM, "invalid drv_ops:%p\n",	wapp->drv_ops);
		return MAP_ERROR;
	} else if (!wapp->drv_ops->drv_send_t2lm_request) {
		err(DEBUG_CAT_T2LM, "invalid drv_ops:%p, and drv_send_t2lm_request:%p\n",
				wapp->drv_ops, wapp->drv_ops->drv_send_t2lm_request);
		return MAP_ERROR;
	}

	return wapp->drv_ops->drv_send_t2lm_request(wapp->drv_data, wdev->ifname, (char *)t2lm_cmd, sizeof(*t2lm_cmd));
}
#endif

#endif /* EPCS_SUPPORT */
