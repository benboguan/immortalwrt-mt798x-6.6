/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#include "wapp_cmm.h"

/* ACL command to driver */
int acl_cmd(struct wifi_app *wapp, const char *ifname, ACL_CMD_TYPE type)
{
	return acl_cmd_data(wapp, ifname, type, NULL, 0);
}

int blacl_cmd(struct wifi_app *wapp, const char *ifname, enum blacklist_cmd_type type)
{
	return acl_cmd_bldata(wapp, ifname, type, NULL, 0);
}

char *get_acl_type_str(int type)
{
	switch (type) {
	case ACL_ADD:
		return "ADD";
	case ACL_DEL:
		return "DEL";
	case ACL_FLUSH:
		return "FLUSH";
	case ACL_POLICY_0:
		return "POLICY_0";
	case ACL_POLICY_1:
		return "POLICY_1";
	case ACL_POLICY_2:
		return "POLICY_2";
	case ACL_SHOW:
		return "SHOW";
#ifdef MAP_R5
	case ACL_ADD_REASON:
		return "ADD_REASON";
#endif
	default:
		return "INVALID";
	}
}

char *get_blacl_type_str(int type)
{
	switch (type) {
	case BL_ADD:
		return "ADD";
	case BL_DEL:
		return "DEL";
	default:
		return "INVALID";
	}
}
int acl_cmd_data(struct wifi_app *wapp, const char *ifname,
		 ACL_CMD_TYPE type, u8 *data, size_t len)
{
	u8 AccessPolicy;
	int ret = -1;

	notice(DEBUG_CAT_MISC, "[ACL]ifname=%s; acl_type=%d(%s)\n",
		ifname, type, get_acl_type_str(type));

	switch (type) {
	case ACL_ADD:
		ret = wapp_set_ACLAddEntry(wapp, ifname, data, len);
		break;
	case ACL_DEL:
		ret = wapp_set_ACLDelEntry(wapp, ifname, data, len);
		break;
	case ACL_FLUSH:
		ret = wapp_set_ACLClearAll(wapp, ifname, NULL, 0);
		break;
	case ACL_POLICY_0:
		AccessPolicy = 0;
		ret = wapp_set_AccessPolicy(wapp, ifname, &AccessPolicy, 1);
		break;
	case ACL_POLICY_1:
		AccessPolicy = 1;
		ret = wapp_set_AccessPolicy(wapp, ifname, &AccessPolicy, 1);
		break;
	case ACL_POLICY_2:
		AccessPolicy = 2;
		ret = wapp_set_AccessPolicy(wapp, ifname, &AccessPolicy, 1);
		break;
	case ACL_SHOW:
		err(DEBUG_CAT_MISC, "[ACL]ACL_SHOW not implemented\n");
		break;
#ifdef MAP_R5
	case ACL_ADD_REASON:
		AccessPolicy = 3;
		ret = wapp_set_AccessPolicy(wapp, ifname, &AccessPolicy, 1);
		if (ret != 0)
			break;
		ret = wapp_set_ACLAddEntry(wapp, ifname, data, len);
		break;
#endif
	default:
		err(DEBUG_CAT_MISC, "[ACL]unknown acl; ifname=%s; acl_type=%d(%s)\n",
			ifname, type, get_acl_type_str(type));
		break;
	}

	if (ret != 0)
		err(DEBUG_CAT_MISC, "[ACL]acl fail; ifname=%s; acl_type=%d(%s)\n",
			ifname, type, get_acl_type_str(type));

	return ret;
}

int acl_cmd_bldata(struct wifi_app *wapp, const char *ifname,
		 enum blacklist_cmd_type type, u8 *data, size_t len)
{
	int ret = -1;

	notice(DEBUG_CAT_MISC, "ifname=%s; acl_type=%d(%s)\n",
		ifname, type, get_blacl_type_str(type));

	switch (type) {
	case BL_ADD:
		ret = wapp_set_BlAdd(wapp, ifname, data, len);
		break;
	case BL_DEL:
		ret = wapp_set_BlDel(wapp, ifname, data, len);
		break;
	default:
		err(DEBUG_CAT_MISC, "unknown acl; ifname=%s; acl_type=%d(%s)\n",
			ifname, type, get_blacl_type_str(type));
		break;
	}

	if (ret != 0)
		err(DEBUG_CAT_MISC, "acl fail; ifname=%s; acl_type=%d(%s)\n",
			ifname, type, get_blacl_type_str(type));

	return ret;
}
