/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#include <stdlib.h>
#include <stdio.h>
#include <limits.h>
#include "wdev.h"
#include "driver_wext.h"
#include "interface.h"
#include "wps.h"
#include "debug.h"
#ifdef DPP_SUPPORT
#include "dpp/dpp_wdev.h"
#include "gas_query.h"
#include "gas_server.h"
#endif /*DPP_SUPPORT*/
#include "wapp_cmm.h"
#ifdef EPCS_SUPPORT
#include "epcs.h"
#endif

extern unsigned short prev_1905_msg;

#ifdef MTK_HOSTAPD_SUPPORT
#define REASON_4_WAY_TIMEOUT            15
#endif
struct wapp_dev *wapp_dev_list_lookup_by_radio(struct wifi_app *wapp, char *ra_identifier)
{
	struct wapp_dev *wdev, *target_wdev = NULL, *wdev_temp = NULL;
	unsigned char wdev_identifier[ETH_ALEN];
	struct dl_list *dev_list;

	dev_list = &wapp->dev_list;

	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list)
	{
		if (wdev->radio) {
			MAP_GET_RADIO_IDNFER(wdev->radio, wdev_identifier);
			if (!os_memcmp(wdev_identifier, ra_identifier, ETH_ALEN) && (wdev->dev_type == WAPP_DEV_TYPE_AP)
			&& (test_inf_status(wdev->ifname, IFF_UP)) == TRUE) {
				target_wdev = wdev;
				break;
			}
		}
	}

	return target_wdev;
}
struct wapp_dev *wapp_bh_dev_list_lookup_by_radio(struct wifi_app *wapp, char *ra_identifier)
{
	struct wapp_dev *wdev, *target_wdev = NULL, *wdev_temp = NULL;
	unsigned char wdev_identifier[ETH_ALEN];
	struct dl_list *dev_list;

	dev_list = &wapp->dev_list;

	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
		if (wdev->radio && wdev->i_am_bh_bss) {
			MAP_GET_RADIO_IDNFER(wdev->radio, wdev_identifier);
			if (!os_memcmp(wdev_identifier, ra_identifier, ETH_ALEN) && (wdev->dev_type == WAPP_DEV_TYPE_AP)) {
				target_wdev = wdev;
				break;
			}
		}
	}

	return target_wdev;
}
struct wapp_dev *wapp_dev_list_lookup_by_radio_for_sta(struct wifi_app *wapp, char *ra_identifier)
{
	struct wapp_dev *wdev, *target_wdev = NULL, *wdev_temp = NULL;
	unsigned char wdev_identifier[ETH_ALEN];
	struct dl_list *dev_list;

	dev_list = &wapp->dev_list;

	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
		if (wdev->radio) {
			MAP_GET_RADIO_IDNFER(wdev->radio, wdev_identifier);
			if (!os_memcmp(wdev_identifier, ra_identifier, ETH_ALEN) && (wdev->dev_type == WAPP_DEV_TYPE_STA)) {
				target_wdev = wdev;
				break;
			}
		}
	}

	return target_wdev;
}

#ifdef MAP_R6
int wapp_wps_mlo_switch(struct wifi_app *wapp, struct mld_bsta_config *config)
{
	struct wapp_dev *wdev, *wdev_temp = NULL;
	unsigned char wdev_identifier[ETH_ALEN];
	struct dl_list *dev_list;
	u8 ZERO_MAC_ADDR[MAC_ADDR_LEN] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
	u8 num_sta = 0;
	u8 radio_count = 0;
	int config_change = 0;
	struct apcli_association_info *apcli_stat_info = &wapp->cli_assoc_info;
	struct wapp_dev *apcli_wdev = NULL;
	/*struct mlo_wapp_bsta_config *wapp_map_bsta_config = &wapp->mlo_bsta_cfg;*/

	if (!config)
		return -1;

	if (config->num_affiliated_sta > 0 && config->num_affiliated_sta < MAX_MLO_NON_SETUP_LINK)
		num_sta = config->num_affiliated_sta;
	else {
		err(DEBUG_CAT_MLO, "mld not disabling %d\n", config->num_affiliated_sta);
		return -1;
	}

	if (wapp->radio_count > MAX_MLO_NON_SETUP_LINK)
		radio_count = MAX_MLO_NON_SETUP_LINK;
	else
		radio_count = wapp->radio_count;

	dev_list = &wapp->dev_list;

	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
		if (wdev->radio) {
			MAP_GET_RADIO_IDNFER(wdev->radio, wdev_identifier);
			if ((os_memcmp(wdev_identifier, ZERO_MAC_ADDR, ETH_ALEN) != 0)
				&& (os_memcmp(wdev_identifier, config->sta[0].ruid, ETH_ALEN) != 0)
				&& (os_memcmp(wdev_identifier, config->sta[1].ruid, ETH_ALEN) != 0)
				&& (os_memcmp(wdev_identifier, config->sta[2].ruid, ETH_ALEN) != 0)
				&& (wdev->dev_type == WAPP_DEV_TYPE_STA)) {
				if (wdev->apcli_mlo_enable == 1) {
					wdev->apcli_mlo_enable = 0;   /* Disable MLO */
				if (!(apcli_stat_info->apcli_assoc_state == WAPP_APCLI_DISASSOCIATED)) {
					apcli_wdev = wapp_dev_list_lookup_by_ifindex(wapp, apcli_stat_info->interface_index);
					if (!apcli_wdev) {
						err(DEBUG_CAT_MLO, "apcli for wdev NULL\n");
						return -1;
					}
#ifdef MTK_HOSTAPD_SUPPORT
				if (wapp->drv_ops->drv_send_disable_network)
					wapp->drv_ops->drv_send_disable_network(wapp->drv_data, apcli_wdev->ifname, apcli_wdev->network_id);
				config_change = 1;
#endif /* MTK_HOSTAPD_SUPPORT */
				}

					wdev_set_mlo_switch(wapp, wdev, 0); /* MLO Switch disable */
				}

				num_sta += 1;
	err(DEBUG_CAT_MLO, "Disable MLO for ifname:%s, num_sta:%d, radio_count:%d\n", wdev->ifname, num_sta, radio_count);
				if (num_sta >= radio_count)
					break;
			}
		}
	}

	return config_change;
}
int wapp_dpp_disable_mlo_switch(struct wifi_app *wapp, struct dpp_authentication *auth)
{
	struct wapp_dev *wdev, *wdev_temp = NULL;
	unsigned char wdev_identifier[ETH_ALEN];
	struct dl_list *dev_list;
	u8 ZERO_MAC_ADDR[MAC_ADDR_LEN] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
	u8 num_sta = 0;
	u8 radio_count = 0;

	if (!auth)
		return -1;

	if (auth->num_affiliated_sta > 0 && auth->num_affiliated_sta < MAX_MLO_NON_SETUP_LINK)
		num_sta = auth->num_affiliated_sta;
	else {
		err(DEBUG_CAT_MLO, "mld not disabling %d\n", auth->num_affiliated_sta);
		return -1;
	}

	if (wapp->radio_count > MAX_MLO_NON_SETUP_LINK)
		radio_count = MAX_MLO_NON_SETUP_LINK;
	else
		radio_count = wapp->radio_count;
	debug(DEBUG_CAT_MLO, "%d\n", auth->num_affiliated_sta);
	dev_list = &wapp->dev_list;

	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
		if (wdev->radio) {
			MAP_GET_RADIO_IDNFER(wdev->radio, wdev_identifier);
			if ((os_memcmp(wdev_identifier, ZERO_MAC_ADDR, ETH_ALEN) != 0)
				&& (os_memcmp(wdev_identifier, auth->sta[0].ruid, ETH_ALEN) != 0)
				&& (os_memcmp(wdev_identifier, auth->sta[1].ruid, ETH_ALEN) != 0)
				&& (os_memcmp(wdev_identifier, auth->sta[2].ruid, ETH_ALEN) != 0)
				&& (wdev->dev_type == WAPP_DEV_TYPE_STA)) {
				wdev->apcli_mlo_enable = 0;   /* Disable MLO */
				wdev_set_mlo_switch(wapp, wdev, 0); /* MLO Switch disable */
				num_sta += 1;
				debug(DEBUG_CAT_MLO, "Disable MLO for ifname:%s, num_sta:%d, radio_count:%d\n",
						wdev->ifname, num_sta, radio_count);
				if (num_sta >= radio_count)
					break;
			}
		}
	}

	return 0;
}
#endif
/*
should lookup wdev by addr and wdev type,
due to WDS has the same addr with AP main inf
*/
struct wapp_dev *wapp_dev_list_lookup_by_mac_and_type(struct wifi_app *wapp, const u8 *mac_addr, const u8 wdev_type)
{
	struct wapp_dev *wdev, *target_wdev = NULL, *wdev_temp = NULL;
	struct dl_list *dev_list;

	dev_list = &wapp->dev_list;

	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list)
	{
		if ((os_memcmp(wdev->mac_addr, mac_addr, MAC_ADDR_LEN) == 0) && wdev->dev_type == wdev_type) {
			target_wdev = wdev;
			break;
		}
	}

	return target_wdev;
}

#ifdef MAP_R6
struct wapp_dev *wapp_dev_list_lookup_by_mld_link_id(struct wifi_app *wapp, const u8 link_id)
{
	struct wapp_dev *wdev, *target_wdev = NULL;
	struct dl_list *dev_list;

	dev_list = &wapp->dev_list;

	dl_list_for_each(wdev, dev_list, struct wapp_dev, list)
	{
		if (wdev->mld_id == link_id && wdev->dev_type == WAPP_DEV_TYPE_AP
			&& wdev->mld_configured == TRUE) {
			target_wdev = wdev;
			break;
		}
	}

	return target_wdev;
}

struct wapp_dev *wapp_dev_list_lookup_by_ruid(struct wifi_app *wapp, const u8 *ruid,
				const u8 *byssid, u8 ssidlen)
{
	struct wapp_dev *wdev, *target_wdev = NULL;
	struct dl_list *dev_list;
	int i;
	struct wapp_radio *ra = NULL;
	u8 idfr[MAC_ADDR_LEN];
	struct ap_dev *ap;

	for (i = 0; i < MAX_NUM_OF_RADIO; i++) {
		ra = &wapp->radio[i];
		if (ra->adpt_id) {
			MAP_GET_RADIO_IDNFER(ra, idfr);
			if (!os_memcmp(idfr, ruid, ETH_ALEN))
				break;
		}
	}

	dev_list = &wapp->dev_list;

	dl_list_for_each(wdev, dev_list, struct wapp_dev, list)
	{
		ap = (struct ap_dev *)wdev->p_dev;
#ifdef DUMP_LOG
		if (ap && wdev->dev_type == WAPP_DEV_TYPE_AP) {
			notice(DEBUG_CAT_CAP, "ssid = %s\n", os_ssid_txt(byssid, ssidlen));
			notice(DEBUG_CAT_CAP, "ap->bss_info.ssid = %s\n", os_ssid_txt((u8 *)ap->bss_info.ssid, ap->bss_info.SsidLen));
			notice(DEBUG_CAT_CAP, "ifname = %s\n", wdev->ifname);
			notice(DEBUG_CAT_CAP, "wdev->radio->radio_id = %d\n", wdev->radio->radio_id);
			notice(DEBUG_CAT_CAP, "ra->radio_id = %d\n", ra->radio_id);
		}
#endif
		if (wdev->radio->radio_id == ra->radio_id && wdev->dev_type == WAPP_DEV_TYPE_AP) {
			if (byssid && !os_memcmp(byssid, ap->bss_info.ssid, ssidlen))
				return wdev;
		}

	}

	return target_wdev;
}

#endif /* MAP_R6 */

struct wapp_dev *wapp_dev_list_lookup_by_ifindex(struct wifi_app *wapp, const u32 ifindex)
{
	struct wapp_dev *wdev, *target_wdev = NULL, *wdev_temp = NULL;
	struct dl_list *dev_list;

	dev_list = &wapp->dev_list;

	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list)
	{
		if (wdev->ifindex == ifindex) {
			target_wdev = wdev;
			break;
		}
	}

	return target_wdev;
}

struct wapp_dev *wapp_dev_list_lookup_by_ifname(struct wifi_app *wapp, const char *ifname)
{
	struct wapp_dev *wdev, *target_wdev = NULL, *wdev_temp = NULL;
	struct dl_list *dev_list;

	dev_list = &wapp->dev_list;

	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list)
	{
		if (strcmp(ifname, (char *)wdev->ifname) == 0) {
			target_wdev = wdev;
			break;
		}
	}

	return target_wdev;
}

struct wapp_dev *wapp_ap_dev_list_lookup_by_sta_intf(struct wifi_app *wapp, struct wapp_dev *sta_wdev)
{
	struct wapp_dev *wdev, *target_wdev = NULL, *wdev_temp = NULL;
	struct dl_list *dev_list;
	unsigned char wdev_id[MAC_ADDR_LEN] = {0};
	unsigned char sta_wdev_id[MAC_ADDR_LEN] = {0};

	dev_list = &wapp->dev_list;

	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
		if (wdev->radio && sta_wdev->radio) {
			MAP_GET_RADIO_IDNFER(wdev->radio, wdev_id);
			MAP_GET_RADIO_IDNFER(sta_wdev->radio, sta_wdev_id);
			if ((wdev->dev_type == WAPP_DEV_TYPE_AP) &&
				(os_memcmp(sta_wdev_id, wdev_id, MAC_ADDR_LEN) == 0)) {
				target_wdev = wdev;
				break;
			}
		}
	}

	return target_wdev;
}

int wapp_dev_create(struct wifi_app *wapp, char *iface, u32 if_idx, u8 *mac_addr)
{
	struct wapp_dev *wdev = NULL;
#ifndef STANDARD_NL_CMD
	size_t len = sizeof(wapp_dev_info);
	wapp_dev_info buf = {0};
#endif

	wdev = os_zalloc(sizeof(struct wapp_dev));
	if (!wdev) {
		err(DEBUG_CAT_MISC, "alloc struct wapp_dev fail\n");
		return WAPP_RESOURCE_ALLOC_FAIL;
	}

	dl_list_init(&wdev->list);
	os_memcpy(wdev->mac_addr, mac_addr, MAC_ADDR_LEN);
	os_memcpy(wdev->ifname, iface, IFNAMSIZ);
	wdev->ifindex = if_idx;
#ifdef EM_PLUS_SUPPORT
	os_get_time(&wdev->cli_list_last_update_time);
#endif
#ifdef MAP_R3
	wdev->is_configured = FALSE;
	wdev->scan_done_ind = FALSE;
	wdev->waiting_cce_scan_res = FALSE;
	os_get_time(&wdev->last_sr_time);
#endif /* MAP_R3 */
#ifdef MAP_R6
	wdev->mld_configured = FALSE;
	wdev->mld_id = FALSE;
	wdev->mld_del_link_state = DEL_LINK_INVALID;
#endif
#ifdef MTK_HOSTAPD_SUPPORT
	wdev->network_id = SUPPLICANT_NETWORK_ID_DEFAULT;
#endif /* MTK_HOSTAPD_SUPPORT */
#ifdef EM_PLUS_SUPPORT
	wdev->AT_mld_configured = FALSE;
#endif /* EM_PLUS_SUPPORT */
	dl_list_add_tail(&wapp->dev_list, &wdev->list);

	wapp_drv_support_version_check(wapp, wdev->ifname);
#ifndef STANDARD_NL_CMD
	wapp_get_wdev_from_driver(wapp, wdev->ifname, (char *)&buf, len);
	wdev_query_rsp_handle(wapp, (wapp_dev_info *)&buf);
#endif

	return WAPP_SUCCESS;
}

int wapp_dev_del(struct wifi_app *wapp, struct wapp_dev *wdev, const u8 *mac_addr, const u32 wdev_type)
{
	struct wapp_dev *del_wdev = NULL;
	// struct wdev_ops *ops = NULL;

	if (!wapp) {
		return WAPP_INVALID_ARG;
	}

	if (wdev) {
		del_wdev = wdev;
		goto entry_del;
	}

	if (mac_addr) {
		del_wdev = wapp_dev_list_lookup_by_mac_and_type(wapp, mac_addr, wdev_type);
		if (del_wdev)
			goto entry_del;
		else
			return WAPP_LOOKUP_ENTRY_NOT_FOUND;
	}

	/* at least one of sta or mac_addr should not be NULL */
	return WAPP_UNEXP;

entry_del:

	if (del_wdev->p_dev != NULL) {
		if (wdev && wdev->ops->wdev_del)
			wdev->ops->wdev_del(wapp, wdev);
		else {
			notice(DEBUG_CAT_MISC, "Error! No wdev_del ops.\n");
			return WAPP_NOT_INITIALIZED;
		}
	}

	dl_list_del(&del_wdev->list);
	os_free(del_wdev);
	del_wdev = NULL;

	return WAPP_SUCCESS;
}

int wapp_clear_dev_list(struct wifi_app *wapp)
{
	if (!wapp) {
		return WAPP_INVALID_ARG;
	}

	if (!dl_list_empty(&wapp->dev_list)) {
		struct wapp_dev *wdev, *wdev_tmp;

		dl_list_for_each_safe(wdev, wdev_tmp, &wapp->dev_list, struct wapp_dev, list)
		{
			wapp_dev_del(wapp, wdev, wdev->mac_addr, wdev->dev_type);
		}
	}

	return WAPP_SUCCESS;
}

void wdev_dev_info_update(struct wifi_app *wapp, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL;
	wapp_dev_info *dev_info = (wapp_dev_info *)event_data;

	if (dev_info)
		wdev = wapp_dev_list_lookup_by_ifindex(wapp, dev_info->ifindex);

	if (!wdev)
		return;

	debug(DEBUG_CAT_MISC, "%s mac: "MACSTR" ifindex:%u\n",
		wdev->ifname, MAC2STR(wdev->mac_addr), dev_info->ifindex);

	if (!os_strcmp(wdev->ifname, (char *)dev_info->ifname) &&
		os_memcmp(wdev->mac_addr, dev_info->mac_addr, MAC_ADDR_LEN)) {
		os_memcpy(wdev->mac_addr, dev_info->mac_addr, MAC_ADDR_LEN);
		debug(DEBUG_CAT_MISC, "update %s mac: "MACSTR"\n",
			wdev->ifname, MAC2STR(wdev->mac_addr));
	}
}

int wapp_show_devinfo(struct wapp_dev *wdev)
{
	if (!wdev) {
		return WAPP_INVALID_ARG;
	}

	notice(DEBUG_CAT_MISC, "dev_type: %u\n", wdev->dev_type);
	notice(DEBUG_CAT_MISC, "ifindex: %u\n", wdev->ifindex);
	notice(DEBUG_CAT_MISC, "ifname: %s\n", wdev->ifname);
	if (wdev->radio)
		notice(DEBUG_CAT_MISC, "radio index: %u\n", wdev->radio->index);
	notice(DEBUG_CAT_MISC, "mac_addr: " MACSTR "\n", MAC2STR(wdev->mac_addr));

#ifdef MAP_SUPPORT
	notice(DEBUG_CAT_MISC, "i_am_fh_bss: %d\n", wdev->i_am_fh_bss);
	notice(DEBUG_CAT_MISC, "i_am_bh_bss: %d\n", wdev->i_am_bh_bss);
#endif /* MAP_SUPPORT */

	notice(DEBUG_CAT_MISC, "---\n");
	return WAPP_SUCCESS;
}

void wapp_show_dev_list(struct wifi_app *wapp)
{
	struct wapp_dev *wdev_tmp, *wdev_temp = NULL;

	if (!wapp)
		return;

	notice(DEBUG_CAT_MISC, "wdev_list:\n");
	notice(DEBUG_CAT_MISC, "==============================\n");

	if (!dl_list_empty(&wapp->dev_list)) {
		dl_list_for_each_safe(wdev_tmp, wdev_temp, &wapp->dev_list, struct wapp_dev, list) wapp_show_devinfo(wdev_tmp);
	}

	return;
}

void wdev_query_rsp_handle(struct wifi_app *wapp, wapp_dev_info *dev_info)
{

	debug(DEBUG_CAT_MISC, "wdev_query_rsp_handle: dev_type = %u, mac = " MACSTR ", ifname = %s\n", dev_info->dev_type,
		     MAC2STR(dev_info->mac_addr), dev_info->ifname);
#ifdef MAP_R5
	map_update_device_info(wapp, dev_info);
#endif
	switch (dev_info->dev_type) {
	case WAPP_DEV_TYPE_AP:
		wdev_ap_create(wapp, dev_info);
		break;

	case WAPP_DEV_TYPE_STA:
	case WAPP_DEV_TYPE_APCLI:
		wdev_sta_create(wapp, dev_info);
		break;

	default:
		break;
	}
#if defined(DPP_SUPPORT) && !defined(MAP_R3)
	dpp_conf_init(wapp, dev_info->ifindex);
#endif /* DPP_SUPPORT && !MAP_R3*/
}

void wdev_ht_cap_query_rsp_handle(struct wifi_app *wapp, u32 ifindex, wdev_ht_cap *ht_cap_rcvd)
{
	struct wapp_dev *wdev = NULL;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev) {
		err(DEBUG_CAT_NL80211, "can't find wdev by ifindex(%d)\n", ifindex);
		return;
	}

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		struct ap_dev *ap = (struct ap_dev *)wdev->p_dev;
		wdev_ht_cap *ht_cap;

		ht_cap = &ap->ht_cap;
		os_memcpy(ht_cap, ht_cap_rcvd, sizeof(wdev_ht_cap));
	}
}

void wdev_vht_cap_query_rsp_handle(struct wifi_app *wapp, u32 ifindex, wdev_vht_cap *vht_cap_rcvd)
{
	struct wapp_dev *wdev = NULL;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev) {
		err(DEBUG_CAT_NL80211, "can't find wdev by ifindex(%d)\n", ifindex);
		return;
	}

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		struct ap_dev *ap = (struct ap_dev *)wdev->p_dev;
		wdev_vht_cap *vht_cap;

		vht_cap = &ap->vht_cap;
		os_memcpy(vht_cap, vht_cap_rcvd, sizeof(wdev_vht_cap));
	}
}

#ifdef STANDARD_NL_CMD
void get_ht_tx_rx_stream(struct phy_info *phy, unsigned char *rx_stream,
	unsigned char *tx_stream)
{
	unsigned char i = 0, tmp_tx_stream = 0, tmp_rx_stream = 0;

	/*b0~b76-rx mcs bitmask, b77~b79-reserved*/
	for (i = 0; i < 10; i++) {
		if (phy->mcs_set[i] == 0xff)
			tmp_rx_stream++;
	}

	/*b96-tx mcs set defined, b97-txrx mcs set not equal*/
	if (phy->mcs_set[12] & BIT(0)) {
		if (phy->mcs_set[12] & BIT(1)) {
			/*b98~b99- rx maximum number spatial streams supported*/
			tmp_tx_stream = (phy->mcs_set[12] & (BIT(2) | BIT(3))) + 1;
		} else {
			tmp_tx_stream = tmp_rx_stream;
		}
	} else {
		tmp_tx_stream = tmp_rx_stream;
		warn(DEBUG_CAT_MISC, "no tx mcs is set, assume it is equal to rx stream\n");
	}

	*rx_stream = tmp_rx_stream;
	*tx_stream = tmp_tx_stream;
}

void assign_wdev_ht_cap(struct wifi_app *wapp, struct dev_info *dev, struct phy_info *phy)
{
	struct wapp_dev *wdev = NULL;
	struct ap_dev *ap = NULL;
	wdev_ht_cap *ht_cap = NULL;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, dev->ifindex);
	if (!wdev) {
		err(DEBUG_CAT_MISC, "can't find wdev by ifindex(%d)\n", dev->ifindex);
		return;
	}
	if (wdev->dev_type != WAPP_DEV_TYPE_AP) {
		err(DEBUG_CAT_MISC, "dev %s is not ap\n", dev->ifname);
		return;
	}
	ap = (struct ap_dev *)wdev->p_dev;
	if (!ap) {
		err(DEBUG_CAT_MISC, "struct ap_dev not created for %s\n", dev->ifname);
		return;
	}

	ht_cap = &ap->ht_cap;

	get_ht_tx_rx_stream(phy, &(ht_cap->rx_stream), &(ht_cap->tx_stream));

	ht_cap->sgi_20 = (phy->ht_capab & BIT(5)) ? 1:0;
	ht_cap->sgi_40 = (phy->ht_capab & BIT(6)) ? 1:0;
	ht_cap->ht_40 = (phy->ht_capab & BIT(1)) ? 1:0;
}

void assign_wdev_vht_cap(struct wifi_app *wapp, struct dev_info *dev, struct phy_info *phy)
{
	struct wapp_dev *wdev = NULL;
	struct ap_dev *ap = NULL;
	wdev_vht_cap *vht_cap = NULL;
	unsigned char i = 0;
	unsigned short rx_vht_mcs = 0, tx_vht_mcs = 0;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, dev->ifindex);
	if (!wdev) {
		err(DEBUG_CAT_MISC, "can't find wdev by ifindex-%d\n", dev->ifindex);
		return;
	}
	if (wdev->dev_type != WAPP_DEV_TYPE_AP) {
		err(DEBUG_CAT_MISC, "dev %s is not ap\n", dev->ifname);
		return;
	}
	ap = (struct ap_dev *)wdev->p_dev;
	if (!ap) {
		err(DEBUG_CAT_MISC, "struct ap_dev not created for %s\n", dev->ifname);
		return;
	}

	vht_cap = &ap->vht_cap;
	if (phy->vht_capab & BIT(3)) {
		vht_cap->vht_160 = TRUE;
		vht_cap->vht_8080 = TRUE;
	} else if (phy->vht_capab & BIT(2)) {
		vht_cap->vht_160 = TRUE;
		vht_cap->vht_8080 = FALSE;
	}

	vht_cap->sgi_80 = (phy->vht_capab & BIT(5)) ? 1:0;
	vht_cap->sgi_160 = (phy->vht_capab & BIT(6)) ? 1:0;
	vht_cap->su_bf = (phy->vht_capab & BIT(11)) ? 1:0;
	vht_cap->mu_bf = (phy->vht_capab & BIT(19)) ? 1:0;

	rx_vht_mcs = WPA_GET_LE16(&phy->vht_mcs_set[0]);
	tx_vht_mcs = WPA_GET_LE16(&phy->vht_mcs_set[4]);

	for (i = 0; i < 8; i++) {
		if (((rx_vht_mcs >> (i * 2)) & 0x0003) != 3)
			vht_cap->rx_stream++;
		if (((tx_vht_mcs >> (i * 2)) & 0x0003) != 3)
			vht_cap->tx_stream++;
	}

	memcpy(vht_cap->sup_tx_mcs, &phy->vht_mcs_set[4], 2);
	memcpy(vht_cap->sup_rx_mcs, &phy->vht_mcs_set[0], 2);
}

void assign_wdev_he_cap(struct wifi_app *wapp, struct dev_info *dev, struct phy_info *phy)
{
	struct wapp_dev *wdev = NULL;
	struct ap_dev *ap = NULL;
	wdev_he_cap *he_cap = NULL;
	unsigned char dl_mu_mimo_cap = 0;
	unsigned char mask = 0;
	unsigned char i = 0, j = 0;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, dev->ifindex);
	if (!wdev) {
		err(DEBUG_CAT_MISC, "can't find wdev by ifindex-%d\n", dev->ifindex);
		return;
	}
	if (wdev->dev_type != WAPP_DEV_TYPE_AP) {
		err(DEBUG_CAT_MISC, "dev %s is not ap\n", dev->ifname);
		return;
	}
	ap = (struct ap_dev *)wdev->p_dev;
	if (!ap) {
		err(DEBUG_CAT_MISC, "struct ap_dev not created for %s\n", dev->ifname);
		return;
	}

	he_cap = &ap->he_cap;
	/*use Rx/Tx HE-MCS Map 80 MHz */
	for (i = 0; i < 2; i++) {
		for (j = 0; j < 4; j++) {
			mask = (phy->he_capab.mcs[i] >> (j * 2)) & 0x3;
			if (mask != 0x3)
				he_cap->rx_stream++;
			mask = (phy->he_capab.mcs[i + 2] >> (j * 2)) & 0x3;
			if (mask != 0x3)
				he_cap->tx_stream++;
		}
	}

	he_cap->he_8080 = (phy->he_capab.phy_cap[0] & BIT(4)) ? 1 : 0;
	he_cap->he_160 = (phy->he_capab.phy_cap[0] & BIT(3)) ? 1 : 0;

	if (he_cap->he_160 && he_cap->he_8080)
		he_cap->he_mcs_len = MAX_HE_MCS_LEN;
	else if (he_cap->he_160)
		he_cap->he_mcs_len = MAX_HE_MCS_LEN - 4;
	else
		he_cap->he_mcs_len = MAX_HE_MCS_LEN - 8;
	os_memcpy(he_cap->he_mcs, phy->he_capab.mcs, he_cap->he_mcs_len);

	he_cap->su_bf_cap = (phy->he_capab.phy_cap[3] & BIT(7)) ? 1 : 0;
	he_cap->mu_bf_cap = (phy->he_capab.phy_cap[4] & BIT(1)) ? 1 : 0;

	if ((phy->he_capab.phy_cap[2] & BIT(6)) ||
		(phy->he_capab.phy_cap[2] & BIT(7)))
		he_cap->ul_mu_mimo_cap = 1;
	if (phy->he_capab.phy_cap[6] & BIT(6))
		dl_mu_mimo_cap = 1;

	he_cap->ul_ofdma_cap = 1;
	he_cap->dl_ofdma_cap = 1;

	if (he_cap->ul_mu_mimo_cap && he_cap->ul_ofdma_cap)
		he_cap->ul_mu_mimo_ofdma_cap = 1;
	else
		he_cap->ul_mu_mimo_ofdma_cap = 0;

	if (dl_mu_mimo_cap && he_cap->dl_ofdma_cap)
		he_cap->dl_mu_mimo_ofdma_cap = 1;
	else
		he_cap->dl_mu_mimo_ofdma_cap = 0;

	/* set gi to auto be default */
	he_cap->gi = 0;
}

#ifdef MAP_R3_WF6
void assign_wdev_wf6_cap(struct wifi_app *wapp, struct dev_info *dev, struct phy_info *phy)
{
	struct wapp_dev *wdev = NULL;
	struct ap_dev *ap = NULL;
	wdev_wf6_cap_roles *wf6_cap = NULL;
	char beamformee_sts_less80 = 0, beamformee_sts_more80 = 0;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, dev->ifindex);
	if (!wdev) {
		err(DEBUG_CAT_MISC, "can't find wdev by ifindex-%d\n", dev->ifindex);
		return;
	}
	if (wdev->dev_type != WAPP_DEV_TYPE_AP) {
		err(DEBUG_CAT_MISC, "dev %s is not ap\n", dev->ifname);
		return;
	}
	ap = (struct ap_dev *)wdev->p_dev;
	if (!ap) {
		err(DEBUG_CAT_MISC, "struct ap_dev not created for %s\n", dev->ifname);
		return;
	}

	wf6_cap = &ap->wf6_cap;
	wf6_cap->role_supp = 1;/*only support ap:1; support ap and sta:2*/

	wf6_cap->wf6_role[0].tx_stream = ap->he_cap.tx_stream;
	wf6_cap->wf6_role[0].rx_stream = ap->he_cap.rx_stream;

	wf6_cap->wf6_role[0].he_160 = ap->he_cap.he_160;
	wf6_cap->wf6_role[0].he_8080 = ap->he_cap.he_8080;

	wf6_cap->wf6_role[0].he_mcs_len = ap->he_cap.he_mcs_len;
	os_memcpy(wf6_cap->wf6_role[0].he_mcs, ap->he_cap.he_mcs, wf6_cap->wf6_role[0].he_mcs_len);

	/*Driver doesn't support 80_80, so handle in wappd*/
	if (wapp->map->MapMode == MAP_CERT_MODE) {
		if (ap->he_cap.he_160) {
			wf6_cap->wf6_role[0].he_8080 = 1;
			os_memcpy(wf6_cap->wf6_role[0].he_mcs + wf6_cap->wf6_role[0].he_mcs_len, ap->he_cap.he_mcs, (MAX_HE_MCS_LEN / 3));
			wf6_cap->wf6_role[0].he_mcs_len += (MAX_HE_MCS_LEN / 3);
		}
	}
	wf6_cap->wf6_role[0].su_bf_cap = ap->he_cap.su_bf_cap;
	wf6_cap->wf6_role[0].mu_bf_cap = ap->he_cap.mu_bf_cap;

	wf6_cap->wf6_role[0].ul_mu_mimo_cap = ap->he_cap.ul_mu_mimo_cap;

	wf6_cap->wf6_role[0].ul_ofdma_cap = ap->he_cap.ul_ofdma_cap;
	wf6_cap->wf6_role[0].dl_ofdma_cap = ap->he_cap.dl_ofdma_cap;

	wf6_cap->wf6_role[0].ul_mu_mimo_ofdma_cap = ap->he_cap.ul_mu_mimo_ofdma_cap;
	wf6_cap->wf6_role[0].dl_mu_mimo_ofdma_cap = ap->he_cap.dl_mu_mimo_ofdma_cap;

	wf6_cap->wf6_role[0].agent_role = 0;
	wf6_cap->wf6_role[0].su_beamformee_status = (phy->he_capab.phy_cap[4] & BIT(0)) ? 1 : 0;

	beamformee_sts_less80 = phy->he_capab.phy_cap[4] & 0x1C;
	beamformee_sts_more80 = phy->he_capab.phy_cap[4] & 0xE0;
	if (beamformee_sts_less80)
		wf6_cap->wf6_role[0].beamformee_sts_less80 = 1;
	else
		wf6_cap->wf6_role[0].beamformee_sts_less80 = 0;
	if (beamformee_sts_more80)
		wf6_cap->wf6_role[0].beamformee_sts_more80 = 1;
	else
		wf6_cap->wf6_role[0].beamformee_sts_more80 = 0;

	wf6_cap->wf6_role[0].max_user_dl_tx_mu_mimo = 0;
	wf6_cap->wf6_role[0].max_user_ul_rx_mu_mimo = 0;
	wf6_cap->wf6_role[0].max_user_dl_tx_ofdma = 0;
	wf6_cap->wf6_role[0].max_user_ul_rx_ofdma = 0;

	wf6_cap->wf6_role[0].rts_status = 0;
	wf6_cap->wf6_role[0].mu_rts_status = 0;
	wf6_cap->wf6_role[0].m_bssid_status = 1;
	wf6_cap->wf6_role[0].mu_edca_status = 1;

	wf6_cap->wf6_role[0].twt_requester_status = (phy->he_capab.mac_cap[0] & BIT(1)) ? 1 : 0;
	wf6_cap->wf6_role[0].twt_responder_status = (phy->he_capab.mac_cap[0] & BIT(2)) ? 1 : 0;
}
#endif
#endif

void wdev_misc_cap_query_rsp_handle(struct wifi_app *wapp, u32 ifindex, wdev_misc_cap *misc_cap)
{
	struct wapp_dev *wdev = NULL;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev) {
		err(DEBUG_CAT_NL80211, "can't find wdev by ifindex(%d)\n", ifindex);
		return;
	}

	/* TODO: use wdev hooking funcion? */
	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		struct ap_dev *ap = (struct ap_dev *)wdev->p_dev;

		ap->max_num_of_cli = misc_cap->max_num_of_cli;
		ap->max_num_of_bss = misc_cap->max_num_of_bss;
		ap->num_of_bss = misc_cap->num_of_bss;
		if (misc_cap->max_num_of_block_cli < BLOCK_LIST_NUM)
			ap->max_num_of_block_cli = (u8)(misc_cap->max_num_of_block_cli);
		else
			ap->max_num_of_block_cli = (u8)(BLOCK_LIST_NUM-1);

		if (ap->client_table == NULL)
			wdev_ap_client_table_create(wapp, ap);

		wdev_ap_block_list_init(wapp, ap);
	}
}

#ifdef STANDARD_NL_CMD
void assign_wdev_bss_info(struct wifi_app *wapp, struct dev_info *dev, struct phy_info *phy)
{
	struct wapp_dev *wdev = NULL;
	struct ap_dev *ap = NULL;
	wdev_bss_info *bss_info = NULL;
	unsigned char idx = 0;
	u8 bss_en = FALSE;
	int i = 0;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, dev->ifindex);
	if (!wdev) {
		err(DEBUG_CAT_MISC, "can't find wdev by ifindex-%d\n", dev->ifindex);
		return;
	}
	if (wdev->dev_type != WAPP_DEV_TYPE_AP) {
		err(DEBUG_CAT_MISC, "dev %s is not ap\n", dev->ifname);
		return;
	}
	ap = (struct ap_dev *)wdev->p_dev;
	if (!ap) {
		err(DEBUG_CAT_MISC, "struct ap_dev not created for %s\n", dev->ifname);
		return;
	}

	bss_info = &ap->bss_info;
	memcpy(bss_info->if_addr, dev->mac, MAC_ADDR_LEN);
	memcpy(bss_info->bssid, dev->mac, MAC_ADDR_LEN);
	bss_info->SsidLen = dev->ssid_len;
	(void)snprintf(bss_info->ssid, MAX_LEN_OF_SSID + 1, "%s", dev->ssid);

	for (i = 0; i < wapp->map->bss_tbl_idx; i++) {
		if (!os_memcmp(wapp->map->op_bss_table[i].bssid, bss_info->bssid, MAC_ADDR_LEN)) {
			err(DEBUG_CAT_MISC, "Entry is existing at %d index\n", i);
			bss_en = TRUE;
			break;
		}
	}

	if (bss_en == TRUE)
		idx = i;
	else
		idx = wapp->map->bss_tbl_idx;

	if (idx >= MAX_WIFI_COUNT) {
		err(DEBUG_CAT_MISC, "MAX CNT reached\n");
		return;
	}

	notice(DEBUG_CAT_MISC, "Update entry at %d index\n", idx);
	wapp->map->op_bss_table[idx] = *bss_info;
	if (bss_en == FALSE)
		wapp->map->bss_tbl_idx++;

#ifdef MAP_R2
#if !defined(EM_PLUS_SUPPORT)
	if (wapp->map->MapMode == 4)
#endif
	{ /* perform onboot scan only for certification*/
		if (eloop_is_timeout_registered(wapp_on_boot_scan, wapp, NULL))
			eloop_cancel_timeout(wapp_on_boot_scan, wapp, NULL);
		eloop_register_timeout(15, 0, wapp_on_boot_scan, wapp, NULL);
	}
#endif
}
#endif

void wdev_cli_query_rsp_handle(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL;
	struct wapp_sta *sta = NULL;
	struct ap_dev *ap = NULL;
#ifdef MAP_SUPPORT
	struct wapp_sta temp_sta = {0};
#endif
#ifdef MAP_R3_WF6
	int i = 0;
#endif

	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);

	if (!wdev)
		return;

	/* TODO: use wdev hooking funcion? */
	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		wapp_client_info *cli = &event_data->cli_info;
		ap = (struct ap_dev *)wdev->p_dev;
		if (is_zero_ether_addr(cli->mac_addr)) {
			err(DEBUG_CAT_STATS, "cli mac is zero in query resp\n");
			return;
		}
		sta = wdev_ap_client_list_lookup(wapp, ap, cli->mac_addr);
		if (!sta && cli->sta_status == WAPP_STA_CONNECTED)
			wapp_client_create(wapp, ap, &sta);

		if (sta) {
#if 1 // MBO
			dl_list_init(&sta->non_pref_ch_list);
#endif
			if (cli->sta_status == WAPP_STA_CONNECTED) {
				if (sta->sta_status != WAPP_STA_CONNECTED) {
					ap->num_of_assoc_cli++;
					sta->sta_status = WAPP_STA_CONNECTED;
#ifdef MAP_R2
					wapp_set_mbo_allow_disallow(wapp);
#endif
				}
				wapp_fill_client_info(wapp, cli, sta);
#ifdef MAP_R2
				sta->ext_sta_metrics.sta_info.last_data_dl_rate = cli->ext_metric_info.sta_info.last_data_dl_rate;
				sta->ext_sta_metrics.sta_info.last_data_ul_rate = cli->ext_metric_info.sta_info.last_data_ul_rate;
				sta->ext_sta_metrics.sta_info.utilization_rx = cli->ext_metric_info.sta_info.utilization_rx;
				sta->ext_sta_metrics.sta_info.utilization_tx = cli->ext_metric_info.sta_info.utilization_tx;
#endif
#ifdef MAP_R3_WF6
				sta->tid_cnt = cli->tid_cnt;
				for (i = 0; i < MAX_TID; i++) {
					sta->status_tlv[i].tid = cli->status_tlv[i].tid;
					sta->status_tlv[i].tid_q_size = cli->status_tlv[i].tid_q_size;
				}
#endif
			} else if (cli->sta_status == WAPP_STA_DISCONNECTED) {
				if (sta->sta_status == WAPP_STA_CONNECTED) {
					ap->num_of_assoc_cli--;
#ifdef MAP_R2
					wapp_set_mbo_allow_disallow(wapp);
#endif
				}
				sta->sta_status = WAPP_STA_DISCONNECTED;
				if (sta->beacon_report) {
					free(sta->beacon_report);
					sta->beacon_report = NULL;
				}
			}
#if 0
			wdev_show_wapp_sta_info(sta);
#endif
		}

#ifdef MAP_SUPPORT
		if (!sta) {
			sta = &temp_sta;
			sta->sta_status = WAPP_STA_DISCONNECTED;
			sta->beacon_report = NULL;
		}
		map_send_one_assoc_sta_msg(wapp, sta);
#endif
	}
}

void wdev_cli_list_query_rsp_handle(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL;
	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);

	if (!wdev)
		return;

	wdev->cli_info_trigger = FALSE;
	os_get_time(&wdev->cli_list_last_update_time);
}

void wdev_apcli_query_rsp_handle(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL;
	struct wapp_sta *sta = NULL;

	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev)
		return;

	if (wdev->dev_type == WAPP_DEV_TYPE_STA) {
		wapp_client_info *cli = &event_data->cli_info;
		sta = (struct wapp_sta *)wdev->p_dev;
		if (sta) {
			wapp_fill_client_info(wapp, cli, sta);
			wdev_show_wapp_sta_info(sta);
#ifdef MAP_SUPPORT
			map_send_one_assoc_sta_msg(wapp, sta);
#endif
			sta->is_sta_dev_type = 1;
		}
	}
}

void wdev_handle_wapp_t2lm_conf_response(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL;
	struct nl_80211_t2lm_cmd *tid_link_map = NULL;
	struct wapp_sta *sta = NULL;

	if (!wapp)
		return;
	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev)
		return;
	if (wdev->radio == NULL)
		return;

	tid_link_map = (struct nl_80211_t2lm_cmd *)event_data;

	if (wdev->dev_type == WAPP_DEV_TYPE_STA) {
		sta = (struct wapp_sta *)wdev->p_dev;
		if (sta) {
			map_send_t2lm_response_msg(wapp, wdev, tid_link_map);
		}
	}
}

void wdev_handle_wapp_eht_oper_punc_bitmap_info(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL;
	int send_pkt_len = 0;
	char *buf = NULL;
	struct wapp_eht_operations_info *eht_oper_info = NULL;
	struct eht_operations_info *eht_operation_data = NULL;
	unsigned char wdev_identifier[ETH_ALEN] = {0};
	unsigned int event_size = 0;
	char *channel_prefer_info = NULL;
	struct evt *evt_tlv = NULL;
	unsigned char count;
	unsigned short len;
	unsigned char radio_id[MAC_ADDR_LEN];

	if (!wapp)
		return;
	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev)
		return;
	if (wdev->radio == NULL)
		return;


	eht_oper_info = &event_data->eht_op_info;
	if (!eht_oper_info)
		return;

	/*find ruid using wdev ka radio*/
	os_alloc_mem(NULL, (UCHAR **)&eht_operation_data, sizeof(struct eht_operations_info));
	os_memset(eht_operation_data, 0, sizeof(struct eht_operations_info));
	if (!eht_operation_data) {
		err(DEBUG_CAT_MLO, "Not available memory\n");
		return;
	}
	MAP_GET_RADIO_IDNFER(wdev->radio, wdev_identifier);
	os_memcpy(eht_operation_data->ruid, wdev_identifier, MAC_ADDR_LEN);
	os_memcpy(eht_operation_data->bssid, wdev->mac_addr, MAC_ADDR_LEN);
	eht_operation_data->eht_operation_information_valid = eht_oper_info->eht_operation_information_valid;
	eht_operation_data->eht_default_pe_duration = eht_oper_info->eht_default_pe_duration;
	eht_operation_data->group_addressed_BU_indication_limit = eht_oper_info->group_addressed_BU_indication_limit;
	eht_operation_data->group_addressed_BU_indication_exponent = eht_oper_info->group_addressed_BU_indication_exponent;
	eht_operation_data->eht_mcs_nss_set.max_tx_rx_mcs0_7_nss = eht_oper_info->eht_mcs_nss_set.max_tx_rx_mcs0_7_nss;
	eht_operation_data->eht_mcs_nss_set.max_tx_rx_mcs8_9_nss = eht_oper_info->eht_mcs_nss_set.max_tx_rx_mcs8_9_nss;
	eht_operation_data->eht_mcs_nss_set.max_tx_rx_mcs10_11_nss = eht_oper_info->eht_mcs_nss_set.max_tx_rx_mcs10_11_nss;
	eht_operation_data->eht_mcs_nss_set.max_tx_rx_mcs12_13_nss = eht_oper_info->eht_mcs_nss_set.max_tx_rx_mcs12_13_nss;
	eht_operation_data->control = eht_oper_info->control;
	eht_operation_data->ccfs0 = eht_oper_info->ccfs0;
	eht_operation_data->ccfs1 = eht_oper_info->ccfs1;
	eht_operation_data->dscb_bitmap = eht_oper_info->dscb_bitmap;

	send_pkt_len = sizeof(struct eht_operations_info);
	os_alloc_mem(NULL, (UCHAR **)&buf, send_pkt_len);
	os_memset(buf, 0, send_pkt_len);
	if (!buf) {
		err(DEBUG_CAT_MLO, "Not available memory\n");
		if (eht_operation_data)
			os_free(eht_operation_data);
		return;
	}
	os_memcpy(buf, eht_operation_data, send_pkt_len);
	wapp_send_1905_msg(wapp, WAPP_EHT_OPERATION_CH_BITMAP_INFO, send_pkt_len, buf);
	/* for debugging purpose
	wpa_hexdump(MSG_ERROR, DPP_MAP_PREX "eht op punctured info from wapp to mapd is", eht_operation_data, send_pkt_len);
	 */
	MAP_GET_RADIO_IDNFER(wdev->radio, radio_id);
	count = get_total_opclass_for_pref(wdev);
	len = sizeof(struct evt) + sizeof(struct ch_prefer) + sizeof(struct prefer_info) * count;
	channel_prefer_info = os_zalloc(len);
	if (channel_prefer_info == NULL) {
		if (buf)
			os_free(buf);
		if (eht_operation_data)
			os_free(eht_operation_data);
		return;
	}

	evt_tlv = (struct evt *)channel_prefer_info;
	event_size = map_build_chn_pref(wapp, radio_id, channel_prefer_info, 0);
	if (event_size) {
		wapp_send_1905_msg(wapp, WAPP_CHANNEL_PREFERENCE, event_size  - sizeof(struct evt),
				(char *)evt_tlv->buffer);
	}
	os_free(channel_prefer_info);
	if (buf)
		os_free(buf);
	if (eht_operation_data)
		os_free(eht_operation_data);

}

void wdev_ap_join_handle(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL;
	struct wapp_sta *sta = NULL;

	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev)
		return;

	sta = wdev->p_dev;

	if (wdev->dev_type == WAPP_DEV_TYPE_STA) {
		wapp_client_info *cli = &event_data->cli_info;

		os_memcpy(sta->mac_addr, cli->mac_addr, MAC_ADDR_LEN);
		os_memcpy(sta->bssid, cli->bssid, MAC_ADDR_LEN);
		sta->sta_status = cli->sta_status;
		sta->is_APCLI = cli->is_APCLI;
		/* MLD Specific data */
#ifdef MTK_MLO_MAP_SUPPORT
		sta->mlo_join = cli->mlo_join;
		os_memcpy(&sta->mlo, &cli->mlo, sizeof(struct mld_data));
		sta->EmlsrBitmap = cli->EmlsrBitmap;
#endif
	}
}

void wdev_cli_join_handle(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL;
	unsigned short old_msg;
	struct wapp_sta *sta = NULL;

	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev)
		return;

	old_msg = prev_1905_msg;
	/* reset previous 1905 msg type */
	prev_1905_msg = 0;
	wdev_cli_query_rsp_handle(wapp, ifindex, event_data);
#ifdef MAP_SUPPORT
	char buf[MAX_EVT_BUF_LEN];
	wapp_client_info *cli = &event_data->cli_info;
	char assoc_buffer[ASSOC_REQ_LEN_MAX] = {0};

	if (!cli)
		return;

#ifdef QOS_R1
	wdev_handle_assoc_sta_info(wapp, ifindex, cli->mac_addr);
#endif

#ifndef EM_PLUS_SUPPORT
	if (!cli->assoc_req_len) {
		debug(DEBUG_CAT_EVENT, "assoc_req_len is 0\n");
		return;
	}
#endif

#ifdef MAP_R6
	if (is_zero_ether_addr(cli->mac_addr)) {
		err(DEBUG_CAT_EVENT, "cli mac is zero\n");
		return;
	}
#endif

	os_memcpy(&assoc_buffer[0], cli->mac_addr, MAC_ADDR_LEN);

#ifdef EM_PLUS_SUPPORT
	if (cli->assoc_req_len)
#endif
		wapp_get_assoc_req_frame(wapp, wdev->ifname, assoc_buffer, cli->assoc_req_len);


	sta = wdev_ap_client_list_lookup(wapp, (struct ap_dev *)wdev->p_dev, cli->mac_addr);
	if (sta && cli->assoc_req_len) {
		sta->assoc_req_len = cli->assoc_req_len;
		os_memcpy(sta->assoc_req, &assoc_buffer[0], sta->assoc_req_len);
		notice(DEBUG_CAT_EVENT, "Got Assoc request\n");
		/*hex_dump_dbg("Assoc Req", (UCHAR *)sta->assoc_req,sta->assoc_req_len);*/
	}

#ifdef MAP_R6
	notice(DEBUG_CAT_MLO, "cli mlo enable:%d STA MLD: "MACSTR"\n", cli->mlo.mlo_en, MAC2STR(cli->mlo.sta_mld_addr));
	notice(DEBUG_CAT_MLO, "Cli bssid = " MACSTR "\n", MAC2STR(cli->bssid));
	notice(DEBUG_CAT_MLO, "Cli mac_addr = " MACSTR "\n", MAC2STR(cli->mac_addr));
	if (cli->mlo.mlo_en != 1)
		map_send_assoc_cli_msg(wapp, cli->bssid, cli->mac_addr, STA_JOIN, buf, 0
		, NULL, NULL, 0, NULL, 0);
	else {
		debug(DEBUG_CAT_MLO, "ELSE CASE ASSOC\n");
#endif
		map_send_assoc_cli_msg(wapp, cli->bssid, cli->mac_addr, STA_JOIN, buf, 0
#ifdef MAP_R6
		, cli->mlo.sta_mld_addr, cli->mlo.ap_mld_addr, cli->mlo.affiliated_ap_num,
			cli->mlo.affiliated_info,  cli->mlo.is_setup_link_entry
#endif
		);
#ifdef MAP_R6
	}
#endif
#endif
	/* restore previous 1905 msg type */
	prev_1905_msg = old_msg;
#ifdef MAP_R6
	/* For non setup link entry do not send tunnel assoc event to mapd */
	if (cli->mlo.mlo_en == 1 && cli->mlo.is_setup_link_entry != 1) {
		notice(DEBUG_CAT_MLO, "R6 non setup link entry "MACSTR"\n", MAC2STR(cli->mac_addr));
		return;
	}
#endif
#ifdef MAP_R2
	if (cli->assoc_req_len)
#ifdef MAP_R6
		{
			if (cli->mlo.mlo_en == 1)
				wdev_send_tunnel_assoc_req(wapp, ifindex, cli->assoc_req_len,
					cli->mlo.sta_mld_addr, cli->IsReassoc, (u8 *)assoc_buffer);
			else
#endif
				wdev_send_tunnel_assoc_req(wapp, ifindex, cli->assoc_req_len,
					cli->mac_addr, cli->IsReassoc, (u8 *)assoc_buffer);
#ifdef MAP_R6
		}
#endif
#endif

}
void wdev_cli_all_leave_handle(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL;
	struct wapp_sta *sta = NULL;
	struct ap_dev *ap = NULL;
	u8 zero_mac[] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
	int i = 0;
	u8 FF_mac[] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};

	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);

	if (!wdev)
		return;

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		wapp_client_info *cli = &event_data->cli_info;
#ifdef MAP_SUPPORT
		char buf[MAX_EVT_BUF_LEN] = {0};

		notice(DEBUG_CAT_MLO, MACSTR"\n", MAC2STR(cli->mac_addr));
#ifdef MAP_R6
		if (cli->mlo.mlo_en != 1)
			map_send_assoc_cli_msg(wapp, wdev->mac_addr, FF_mac, STA_LEAVE, buf, cli->disassoc_reason
			, NULL, NULL, 0, NULL, 0
		);
		else {
#endif
			map_send_assoc_cli_msg(wapp, wdev->mac_addr, FF_mac, STA_LEAVE, buf, cli->disassoc_reason
#ifdef MAP_R6
			, cli->mlo.sta_mld_addr, cli->mlo.ap_mld_addr, cli->mlo.affiliated_ap_num,
					cli->mlo.affiliated_info, cli->mlo.is_setup_link_entry
#endif
			);
#ifdef MAP_R6
		}
#endif
#endif
		ap = (struct ap_dev *)wdev->p_dev;
		if (!ap)
			return;
		for (i = 0; i < CLIENT_TABLE_SIZE; i++) {
			sta = ap->client_table[i];
			if (sta && (os_memcmp(sta->mac_addr, zero_mac, MAC_ADDR_LEN) != 0) &&
				(os_memcmp(sta->bssid, wdev->mac_addr, MAC_ADDR_LEN) == 0)) {
				notice(DEBUG_CAT_MLO, "wapp found valid cli"MACSTR"\n", MAC2STR(sta->mac_addr));
			} else {
				continue;
			}
			if (sta) {
				notice(DEBUG_CAT_MLO, " CLI LEAVE MAC " MACSTR "\n", MAC2STR(sta->mac_addr));
				if (sta->sta_status == WAPP_STA_CONNECTED) {
					ap->num_of_assoc_cli--;
#ifdef MAP_R2
					wapp_set_mbo_allow_disallow(wapp);
#endif
					sta->sta_status = WAPP_STA_DISCONNECTED;
					if (sta->beacon_report) {
						free(sta->beacon_report);
						sta->beacon_report = NULL;
					}
				}
			}
		}
	}
}

void wdev_cli_leave_handle(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL;
	struct wapp_sta *sta = NULL;
	struct ap_dev *ap = NULL;

	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);

	if (!wdev)
		return;

	/* TODO: use wdev hooking funcion? */
	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		wapp_client_info *cli = &event_data->cli_info;
#ifdef MAP_SUPPORT
		char buf[MAX_EVT_BUF_LEN] = {0};
#ifdef MAP_R6
		if (cli->mlo.mlo_en != 1)
			map_send_assoc_cli_msg(wapp, wdev->mac_addr, cli->mac_addr, STA_LEAVE, buf, cli->disassoc_reason
			, NULL, NULL, 0, NULL, 0
		);
		else {
#endif
			map_send_assoc_cli_msg(wapp, wdev->mac_addr, cli->mac_addr, STA_LEAVE, buf, cli->disassoc_reason
#ifdef MAP_R6
			, cli->mlo.sta_mld_addr, cli->mlo.ap_mld_addr, cli->mlo.affiliated_ap_num,
					cli->mlo.affiliated_info, cli->mlo.is_setup_link_entry
#endif
			);
#ifdef MAP_R6
		}
#endif
#endif
#ifdef EPCS_SUPPORT
		wapp_epcs_sta_leave_action(wapp, wdev, cli->mac_addr);
#endif
		ap = (struct ap_dev *)wdev->p_dev;
		if (!ap)
			return;

		sta = wdev_ap_client_list_lookup(wapp, (struct ap_dev *)wdev->p_dev, cli->mac_addr);
		if (sta) {
			notice(DEBUG_CAT_MLO, " CLI LEAVE MAC " MACSTR "\n", MAC2STR(cli->mac_addr));
			if (sta->sta_status == WAPP_STA_CONNECTED) {
				ap->num_of_assoc_cli--;
#ifdef MAP_R2
				wapp_set_mbo_allow_disallow(wapp);
#endif
				sta->sta_status = WAPP_STA_DISCONNECTED;
				if (sta->beacon_report) {
					free(sta->beacon_report);
					sta->beacon_report = NULL;
				}
			}
		}
	}
}
#ifdef MAP_R2
int mbo_set_assoc_disallow(struct wifi_app *wapp, char *iface, int value)
{
	struct mbo_cfg *mbo = wapp->mbo;

	mbo->assoc_disallow_reason = value;

	/* mbo assoc disallow */
	mbo_param_setting(wapp, (const char *)iface, PARAM_MBO_AP_ASSOC_DISALLOW, wapp->mbo->assoc_disallow_reason);

#ifdef MAP_R2
	/* Send assoc status notification to controller/agents */
	map_send_assoc_notification(wapp, (const char *)iface, wapp->mbo->assoc_disallow_reason);
#endif

	return MBO_SUCCESS;
}

void wdev_sta_disassoc_stats_handle(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL;

	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev)
		return;

	/* TODO: use wdev hooking funcion? */
	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		wapp_client_info *cli = &event_data->cli_info;
		notice(DEBUG_CAT_MISC, "event cli info: %d\n", event_data->cli_info.disassoc_reason);
		char buf[MAX_EVT_BUF_LEN];
		map_send_sta_disassoc_stats_msg(wapp, wdev->mac_addr, cli, buf);
	}
}
void wapp_set_mbo_allow_disallow(struct wifi_app *wapp)
{
	int tot_cnt = 0;
	struct ap_dev *ap = NULL;
	struct dl_list *dev_list = NULL;
	struct wapp_dev *wdev = NULL, *wdev_temp = NULL;

	dev_list = &wapp->dev_list;
	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
		if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
			ap = (struct ap_dev *)wdev->p_dev;
			tot_cnt += ap->num_of_assoc_cli;
		}
	}
	if (tot_cnt >= wapp->map->max_client_cnt && wapp->mbo->assoc_disallow_reason == 0) {
		notice(DEBUG_CAT_MISC, "MAX num of client cnt reached disallowing\n");
		wdev = NULL;
		wdev_temp = NULL;
		dev_list = &wapp->dev_list;
		dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list)
		{
			if (wdev->dev_type == WAPP_DEV_TYPE_AP)
				mbo_set_assoc_disallow(wapp, wdev->ifname, 2);
		}
	} else if (tot_cnt <= wapp->map->max_client_cnt && wapp->mbo->assoc_disallow_reason == 2) {
		notice(DEBUG_CAT_MISC, "Reduced num of client, allowing\n");
		wdev = NULL;
		wdev_temp = NULL;
		dev_list = &wapp->dev_list;
		dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list)
		{
			if (wdev->dev_type == WAPP_DEV_TYPE_AP)
				mbo_set_assoc_disallow(wapp, wdev->ifname, 0);
		}
	}
}
#endif
void wdev_cli_probe_handle(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct probe_info *info;
	wapp_probe_info *probe = &event_data->probe_info;
	int send_pkt_len = 0;
	char *buf = NULL;
#ifdef MAP_6E_SUPPORT
	struct wapp_dev *wdev = NULL;
	struct map_probe_info *probe_info;
#endif

	/* TODO varify conf status for controller */
	if ((wapp->is_bs20_attached == FALSE) && (wapp->map->conf != MAP_CONN_STATUS_CONF)) {
		debug(DEBUG_CAT_MISC, "device is unconfigued, ignore probes\n");
		return;
	}

	info = wapp_probe_lookup(wapp, probe->mac_addr);
	if (info == NULL) {
		info = wapp_probe_create(wapp, probe->mac_addr);
	}

	// Update probe info in wapp
	info->rssi = probe->rssi;
	info->channel = probe->channel;
#ifdef MAP_6E_SUPPORT
	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!(wdev && wdev->radio && wdev->radio->radio_band)) {
		debug(DEBUG_CAT_MISC, "wdev is not found, ignore probes\n");
		return;
	}
	info->band = *(wdev->radio->radio_band);
#endif
	os_memcpy(info->preq, probe->preq, probe->preq_len);
	os_get_time(&info->last_update_time);

	/* Send to other daemon*/
#ifdef MAP_6E_SUPPORT
	send_pkt_len = sizeof(struct map_probe_info);
#else
	send_pkt_len = sizeof(struct probe);
#endif
	buf = os_zalloc(send_pkt_len);
	if (buf) {
#ifdef MAP_6E_SUPPORT
		probe_info = (struct map_probe_info *) buf;
		os_memcpy(probe_info, probe, sizeof(struct _wapp_probe_info));
		probe_info->band = info->band;
#else
		os_memcpy(buf, probe, send_pkt_len);
#endif
		wapp_send_1905_msg(wapp, WAPP_UPDATE_PROBE_INFO, send_pkt_len, buf);
		os_free(buf);
	}
}
#ifdef MAP_6E_SUPPORT
void fill_skiplist_by_band(struct wifi_app *wapp, wdev_chn_info *chn_list_rcvd)
{
	struct AutoCHSkipList_band *tmp = &wapp->skiplist;
	u8 band = 0;
	int i = 0, j = 0, k = 0;
	u8 skip_add = 0;

	if (WMODE_CAP_6G(chn_list_rcvd->band)) {
		tmp->valid_bands |= BIT(MAP_BAND_6G);
		band = MAP_BAND_6G;
	} else if (WMODE_CAP_5G(chn_list_rcvd->band)) {
		tmp->valid_bands |= BIT(MAP_BAND_5GL);
		band = MAP_BAND_5GL;
	} else if (WMODE_CAP_2G(chn_list_rcvd->band)) {
		tmp->valid_bands |= BIT(MAP_BAND_2G);
		band = MAP_BAND_2G;
	}

	if (chn_list_rcvd->AutoChannelSkipListNum > 0 &&
		chn_list_rcvd->AutoChannelSkipListNum <= MAX_NUM_OF_CHANNELS) {
		for (j = tmp->skiplist[band].AutoChannelSkipListNum, i = 0;
				i < chn_list_rcvd->AutoChannelSkipListNum;
				i++) {

			/*Checking duplicate in skiplist.*/
			for (k = 0; k < j; k++) {
				if (chn_list_rcvd->AutoChannelSkipList[i] == tmp->skiplist[band].AutoChannelSkipList[k]) {
					skip_add = 1;
					break;
				}
			}

			/* channel needs to be added in the list. */
			if (!skip_add) {
				if (j < 0 || j >= MAX_NUM_OF_CHANNELS)
					return;
				tmp->skiplist[band].AutoChannelSkipList[j++] = chn_list_rcvd->AutoChannelSkipList[i];
			} else /* Skip this channel as it is duplicate. */
				skip_add = 0;
		}
	}
	tmp->skiplist[band].band = band;
	tmp->skiplist[band].AutoChannelSkipListNum = j;
	tmp->total_skipch += chn_list_rcvd->AutoChannelSkipListNum;
}
#endif

#ifdef STANDARD_NL_CMD
void assign_ch_cac_timer(wdev_chn_info *chn_list,
		wdev_chn_info *chn_list_rcvd)
{
	unsigned char i = 0, j = 0;

	for (i = 0; i < chn_list->ch_list_num; i++) {
		for (j = 0; j < chn_list_rcvd->ch_list_num &&
			j < MAX_NUM_OF_CHANNELS + 1; j++) {
			if (chn_list->ch_list[i].channel == chn_list_rcvd->ch_list[j].channel) {
				chn_list->ch_list[i].cac_timer = chn_list_rcvd->ch_list[j].cac_timer;
				break;
			}
		}
	}
}
#endif

void wdev_chn_list_query_rsp_handle(struct wifi_app *wapp, u32 ifindex, wdev_chn_info *chn_list_rcvd)
{
	struct wapp_dev *wdev = NULL;
#ifndef MAP_6E_SUPPORT
	int i = 0;
	int j = 0;
	int k = 0;
	int skip_add = 0;
#endif

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev) {
		err(DEBUG_CAT_MISC, "can't find wdev by ifindex(%d)", ifindex);
		return;
	}

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		struct ap_dev *ap = (struct ap_dev *)wdev->p_dev;
		wdev_chn_info *chn_list;
		chn_list = &ap->ch_info;
#ifdef STANDARD_NL_CMD
		assign_ch_cac_timer(chn_list, chn_list_rcvd);
#ifndef MAP_6E_SUPPORT
		chn_list->AutoChannelSkipListNum =  chn_list_rcvd->AutoChannelSkipListNum;
		os_memcpy(chn_list->AutoChannelSkipList, chn_list_rcvd->AutoChannelSkipList,
			MAX_NUM_OF_CHANNELS + 1);
#endif
#else
		os_memcpy(chn_list, chn_list_rcvd, sizeof(wdev_chn_info));
#ifdef MAP_6E_SUPPORT
		wdev->radio->opclass = chn_list->op_class;
#endif
#ifdef MAP_R3_6E_SUPPORT
		/* If dpp is init then set 6e variable for CCE control */
		if (wapp->dpp) {
			if (IS_OP_CLASS_6G(wdev->radio->opclass))
				wapp->dpp->wdev_6e_support = 1;
		}
#endif /* MAP_R3_6E_SUPPORT */
		if (ap->isActive)
			wapp_radio_update_ch(wapp, wdev->radio, chn_list->op_ch);
#endif
#ifndef MAP_6E_SUPPORT
		if (chn_list && chn_list->AutoChannelSkipListNum > MAX_NUM_OF_CHANNELS + 1) {
			err(DEBUG_CAT_MISC, "AutoChannelSkipListNum is invalid\n");
			return;
		}

		for (j = wapp->AutoChannelSkipListNum, i = 0; i < chn_list->AutoChannelSkipListNum; i++) {
			/*Checking duplicate in skiplist.*/
			for (k = 0; k < j; k++) {
				if (chn_list->AutoChannelSkipList[i] == wapp->AutoChannelSkipList[k]) {
					skip_add = 1;
					break;
				}
			}
			/* channel needs to be added in the list. */
			if (!skip_add) {
				wapp->AutoChannelSkipList[j++] = chn_list->AutoChannelSkipList[i];

				notice(DEBUG_CAT_MISC,
						"WAPP: at boot time we have rcv'd on band=%d skipList[%d]=%d\n",
						chn_list->band, j-1, chn_list->AutoChannelSkipList[i]);
			} else /* Skip this channel as it is duplicate. */
				skip_add = 0;
		}
		wapp->AutoChannelSkipListNum = j;
#else
		fill_skiplist_by_band(wapp, chn_list_rcvd);
#endif
	}
}

#if defined(STANDARD_NL_CMD) && defined(MAP_6E_SUPPORT) && defined(MAP_VENDOR_SUPPORT)
void assign_ch_pref(struct _wdev_op_class_info_ext *op_class,
		struct _wdev_op_class_info_ext *op_class_rcvd)
{
	struct opClassInfoExt *op = NULL, *op_rcv = NULL;
	unsigned char i = 0, j = 0, k = 0, m = 0;
	unsigned char op_found = 0, ch_found = 0;

	for (i = 0; i < op_class->num_of_op_class; i++) {
		op = &op_class->opClassInfoExt[i];
		op_found = 0;
		for (j = 0; j < op_class_rcvd->num_of_op_class &&
			j < MAX_OP_CLASS; j++) {
			op_rcv = &op_class_rcvd->opClassInfoExt[j];
			if (op->op_class == op_rcv->op_class) {
				op_found = 1;
				break;
			}
		}
		if (op_found == 0) {
			warn(DEBUG_CAT_CHANNEL, "can't find op-%d in op_class_rcvd\n", op->op_class);
			continue;
		}
		for (k = 0; k < op->num_of_ch; k++) {
			ch_found = 0;
			for (m = 0; m < op_rcv->num_of_ch &&
				m < MAX_NUM_OF_CHANNELS; m++) {
				if (op->ch_list[k] == op_rcv->ch_list[m]) {
					ch_found = 1;
					break;
				}
			}
			if (ch_found == 0) {
				warn(DEBUG_CAT_CHANNEL, "can't find ch-%d in op_class_rcvd\n", op->ch_list[k]);
				continue;
			}
			op->ch_pref[k] = op_rcv->ch_pref[m];
			debug(DEBUG_CAT_CHANNEL, "op=%d ch-%d ch_pref=%d\n",
				op->op_class, op->ch_list[k], op->ch_pref[k]);
		}
	}
}
#endif

void wdev_op_class_query_rsp_handle(struct wifi_app *wapp, u32 ifindex,
#ifndef MAP_6E_SUPPORT
	wdev_op_class_info * op_class_rcvd
#else
	struct _wdev_op_class_info_ext *op_class_rcvd
#endif
)
{
	struct wapp_dev *wdev = NULL;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev) {
		err(DEBUG_CAT_CHANNEL, "can't find wdev by ifindex(%d)", ifindex);
		return;
	}

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		struct ap_dev *ap = (struct ap_dev *)wdev->p_dev;
#ifdef MAP_6E_SUPPORT
		struct _wdev_op_class_info_ext *op_class = &ap->op_class;

		os_memcpy(op_class, op_class_rcvd, sizeof(struct _wdev_op_class_info_ext));
#else
		wdev_op_class_info *op_class = &ap->op_class;
		os_memcpy(op_class, op_class_rcvd, sizeof(wdev_op_class_info));
#endif
	}
}

void wdev_bss_info_query_rsp_handle(struct wifi_app *wapp, u32 ifindex, wdev_bss_info *bss_info_rcvd)
{
	struct wapp_dev *wdev = NULL;
	u8 idx = 0;
	u8 bss_en = FALSE;
	int i = 0;

	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);

	if (!wdev)
		return;

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		struct ap_dev *ap = (struct ap_dev *)wdev->p_dev;
		wdev_bss_info *bss_info;
		bss_info = os_zalloc(sizeof(wdev_bss_info));

		if (!bss_info) {
			return;
		}
		os_memcpy(bss_info, bss_info_rcvd, sizeof(wdev_bss_info));

		notice(DEBUG_CAT_MISC,
			     "bss_info: (%u)\n"
			     "\t table idx = %u\n"
			     "\t ssid = %s\n"
			     "\t SsidLen = %u\n"
			     "\t map role = %u\n"
			     "\t Bssid = " MACSTR "\n"
			     "\t Identifier = " MACSTR "\n",
			     ifindex, wapp->map->bss_tbl_idx, bss_info->ssid, bss_info->SsidLen, bss_info->map_role,
			     MAC2STR(bss_info->bssid), MAC2STR(bss_info->if_addr));

		os_memcpy(&ap->bss_info, bss_info, sizeof(wdev_bss_info));

		for (i = 0; i < wapp->map->bss_tbl_idx; i++) {
			if (!os_memcmp(wapp->map->op_bss_table[i].bssid, bss_info->bssid, MAC_ADDR_LEN)) {
				DBGPRINT(RT_DEBUG_ERROR, "Entry is existing at %d index\n", i);
				bss_en = TRUE;
				break;
			}
		}

		if (bss_en == TRUE)
			idx = i;
		else
			idx = wapp->map->bss_tbl_idx;

		if (idx >= MAX_WIFI_COUNT) {
			DBGPRINT(RT_DEBUG_ERROR, "MAX CNT reached\n");
			os_free(bss_info);
			return;
		}

		DBGPRINT(RT_DEBUG_ERROR, "Update entry at %d index\n", idx);
		wapp->map->op_bss_table[idx] = *bss_info;
		if (bss_en == FALSE)
			wapp->map->bss_tbl_idx++;

		os_free(bss_info);

#ifdef MAP_R2
#if !defined(EM_PLUS_SUPPORT)
		if (wapp->map->MapMode == 4)
#endif
		{ /* perform onboot scan only for certification*/
			if (eloop_is_timeout_registered(wapp_on_boot_scan, wapp, NULL))
				eloop_cancel_timeout(wapp_on_boot_scan, wapp, NULL);
			eloop_register_timeout(15, 0, wapp_on_boot_scan, wapp, NULL);
		}
#endif
	}
}

void wdev_ap_metric_query_rsp_handle(struct wifi_app *wapp, u32 ifindex, wdev_ap_metric *ap_metrics_rcvd)
{
	struct wapp_dev *wdev = NULL;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev) {
		err(DEBUG_CAT_MISC, "can't find wdev by ifindex(%d)", ifindex);
		return;
	}

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		struct ap_dev *ap = (struct ap_dev *)wdev->p_dev;
		wdev_ap_metric *ap_metrics;

		ap_metrics = &ap->ap_metrics;
		os_memcpy(ap_metrics, ap_metrics_rcvd, sizeof(wdev_ap_metric));
#ifdef MAP_SUPPORT
		map_send_ap_metric_msg(wapp, wdev, ap);
#endif
	}
}

#ifdef MTK_MLO_MAP_SUPPORT
void wdev_mlo_mld_quey_rsp_handle(struct wifi_app *wapp, u32 ifindex,  struct _wdev_mlo_info *ap_mlo_info)
{
	struct wapp_dev *wdev = NULL;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev) {
		err(DEBUG_CAT_NL80211, "can't find wdev by ifindex(%d)", ifindex);
		return;
	}

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		struct ap_dev *ap = (struct ap_dev *)wdev->p_dev;
		struct _wdev_mlo_info *mlo_info;

		mlo_info = &ap->mlo_info;
		os_memcpy(mlo_info->mld_addr, ap_mlo_info->mld_addr, MAC_ADDR_LEN);
		mlo_info->mld_idx = ap_mlo_info->mld_idx;
		mlo_info->link_id = ap_mlo_info->link_id;
		mlo_info->ap_str_support = ap_mlo_info->ap_str_support;
		mlo_info->ap_nstr_support = ap_mlo_info->ap_nstr_support;
		mlo_info->ap_emlsr_support = ap_mlo_info->ap_emlsr_support;
		mlo_info->ap_emlmr_support = ap_mlo_info->ap_emlmr_support;
		if (mlo_info->mld_idx) {
			wdev->mld_configured = TRUE;
			wdev->mld_id = mlo_info->mld_idx;
		} else {
			wdev->mld_configured = FALSE;
			wdev->mld_id = 0;
		}
	}
}
#endif

#ifdef MAP_R2
void wdev_radio_metric_query_rsp_handle(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	map_send_radio_metric_msg(wapp, event_data, ifindex);
}
#endif

void wdev_ch_util_query_rsp_handle(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL;
	struct wapp_radio *ra = NULL;

	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);

	if (!wdev)
		return;

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		debug(DEBUG_CAT_CHANNEL, "ch_util: %d\n", event_data->ch_util);
		ra = wdev->radio;
		ra->metric_policy.ch_util_prev = ra->metric_policy.ch_util_current;
		ra->metric_policy.ch_util_current = event_data->ch_util;
	}
}

void wdev_ap_config_query_rsp_handle(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL;

	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);

	if (!wdev)
		return;

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		wapp->map->rssi_steer = event_data->ap_conf.rssi_steer;
		wapp->map->sta_report_not_cop = event_data->ap_conf.sta_report_not_cop;
		wapp->map->sta_report_on_cop = event_data->ap_conf.sta_report_on_cop;

		notice(DEBUG_CAT_MISC,
			     "Ap_conf: (%u)\n"
			     "\t rssi_steer = %u\n"
			     "\t sta_report_not_cop = %u\n"
			     "\t sta_report_on_cop = %u\n",
			     ifindex, wapp->map->rssi_steer, wapp->map->sta_report_not_cop, wapp->map->sta_report_on_cop);
	}
}

void wapp_hapd_bcn_report_handle(struct wifi_app *wapp, const char *ifname,
				u8 *sta_addr, u8 token,
				u8 report_mode, u8 *bcn_rept, u16 bcn_rpt_len)
{
	struct wapp_dev *wdev = NULL;
	struct beacon_metrics_rsp *bcn_report = NULL;
	struct wapp_sta *sta = NULL;
	struct ap_dev *ap = NULL;

	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifname(wapp, ifname);
	if (!wdev)
		return;

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		ap = (struct ap_dev *)wdev->p_dev;
		sta = wdev_ap_client_list_lookup(wapp, ap, sta_addr);
		if (!sta || sta->sta_status != WAPP_STA_CONNECTED)
			return;
		if (sta->beacon_report == NULL) {
			sta->beacon_report = (struct beacon_metrics_rsp *)os_zalloc(sizeof(struct beacon_metrics_rsp)
				+ MAX_BEACON_REPORT_LEN);
			if (sta->beacon_report) {
				os_memset(sta->beacon_report, 0, sizeof(*sta->beacon_report));
				os_memcpy(sta->beacon_report->sta_mac, sta_addr, MAC_ADDR_LEN);
			}
		}
		bcn_report = sta->beacon_report;
		if (!bcn_report) {
			debug(DEBUG_CAT_MISC, "Beacon Report Not Found\n");
			return;
		}
		if ((bcn_report->rpt_len + bcn_rpt_len + 5) > MAX_BEACON_REPORT_LEN) {
			debug(DEBUG_CAT_MISC, "Beacon Report len is not valid\n");
			return;
		}
		if (bcn_rpt_len > 252) {
			debug(DEBUG_CAT_MISC, "bcn_rpt_len is greater than 252\n");
			return;
		}
		bcn_report->bcn_rpt_num++;

		/* Adding 5 header bytes for mapd parsing */
		bcn_report->rpt[bcn_report->rpt_len] = RRM_BCN_MESURE_REPORT_TAG;
		bcn_report->rpt[bcn_report->rpt_len + 1] = bcn_rpt_len + 3;
		bcn_report->rpt[bcn_report->rpt_len + 2] = token;
		bcn_report->rpt[bcn_report->rpt_len + 3] = report_mode;
		bcn_report->rpt[bcn_report->rpt_len + 4] = RRM_BCN_MESURE_REPORT_TYPE;
		bcn_report->rpt_len += 5;

		os_memcpy(&bcn_report->rpt[bcn_report->rpt_len], bcn_rept, bcn_rpt_len);
		bcn_report->rpt_len += bcn_rpt_len;

		 notice(DEBUG_CAT_MISC,
			     " get bcn rpt from " MACSTR " len:%d accumulate bcn_rpt num:%d bcn rpt len:%d\n",
			     MAC2STR(sta_addr), bcn_rpt_len, bcn_report->bcn_rpt_num,
			     bcn_report->rpt_len);
	}
}

void wapp_hapd_bcn_report_complete_handle(struct wifi_app *wapp, const char *ifname,
				u8 *sta_addr, u8 token,
				u8 report_mode)
{
#if defined(MAP_SUPPORT) && defined(MTK_HOSTAPD_SUPPORT)
	char buf[MAX_EVT_BUF_LEN];
	int send_pkt_len = 0;
#endif /* MAP_SUPPORT && MTK_HOSTAPD_SUPPORT */
#ifdef COSR_SUPPORT
	char cosr_buf[MAX_EVT_BUF_LEN];
	int  pkt_len = 0;
#endif /* COSR_SUPPORT */

	struct wapp_dev *wdev = NULL;
	struct wapp_sta *sta = NULL;
	struct ap_dev *ap = NULL;

	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifname(wapp, ifname);
	if (!wdev)
		return;

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		ap = (struct ap_dev *)wdev->p_dev;
		sta = wdev_ap_client_list_lookup(wapp, ap, sta_addr);
		if (!sta || sta->sta_status != WAPP_STA_CONNECTED)
			return;
		if (sta->beacon_report) {
			notice(DEBUG_CAT_MISC, " get bcn rpt complete from " MACSTR "\n", MAC2STR(sta_addr));
#if defined(MAP_SUPPORT) && defined(MTK_HOSTAPD_SUPPORT)
			send_pkt_len = sizeof(struct beacon_metrics_rsp) + sta->beacon_report->rpt_len;
			if (send_pkt_len < 0 || send_pkt_len > MAX_BEACON_REPORT_LEN) {
				err(DEBUG_CAT_MISC, "alloc pkt_len unqualified\n ");
				free(sta->beacon_report);
				sta->beacon_report = NULL;
				return;
			}
			os_memcpy(buf, sta->beacon_report, send_pkt_len);
			wapp_send_1905_msg(wapp, WAPP_BEACON_METRICS_REPORT, send_pkt_len, buf);
#endif /* MAP_SUPPORT && MTK_HOSTAPD_SUPPORT */
#ifdef COSR_SUPPORT
			pkt_len = sizeof(struct beacon_metrics_rsp) + sta->beacon_report->rpt_len;
			if (pkt_len < 0 || pkt_len > MAX_EVT_BUF_LEN) {
				err(DEBUG_CAT_MISC, "alloc pkt_len unqualified\n ");
				free(sta->beacon_report);
				sta->beacon_report = NULL;
				return;
			}
			os_memcpy(cosr_buf, sta->beacon_report, pkt_len);
			hostapd_cosr_handle_beacon_report(wapp, pkt_len, cosr_buf);
#endif /* COSR_SUPPORT */
			free(sta->beacon_report);
			sta->beacon_report = NULL;
		}
	}
}


void wapp_hapd_wps_dpp_uri_handle(struct wifi_app *wapp, const char *ifname,
				u8 *enrollee_stamac, u8 *dpp_uri, size_t dpp_uri_len)
{
#if defined(MAP_R3) && !defined(EM_PLUS_SUPPORT)
	struct wapp_dev *wdev = NULL;
	int peer_bi_id = 0;

	wdev = wapp_dev_list_lookup_by_ifname(wapp, ifname);
	if (!wdev || !wapp->dpp) {
		err(DEBUG_CAT_DPP, "valid wdev not found..\n");
		return;
	}

	if ((wapp->map->map_version == DEV_TYPE_R3) && (wapp->dpp->onboarding_type != 0)) {
		err(DEBUG_CAT_DPP, "invalid map version or onboarding type..\n");
		return;
	}

	notice(DEBUG_CAT_DPP, "Sta_MAC " MACSTR " for wdev:%s uri:%s len:%zu\n",
		MAC2STR(enrollee_stamac), wdev->ifname, dpp_uri, dpp_uri_len);

	if (wapp->dpp->dpp_allowed_roles == DPP_CAPAB_CONFIGURATOR) {
		peer_bi_id = wapp_dpp_qr_code(wapp, (const char *)dpp_uri);
		if (peer_bi_id == 0) {
			err(DEBUG_CAT_MISC, "invalid bi id..\n");
			return;
		}
		return;
	}

	if ((wapp->dpp->dpp_allowed_roles == DPP_CAPAB_PROXYAGENT)
		&& (wapp->dpp->map_sec_done == TRUE)) {
		dpp_URI_1905_send(wapp, NULL, wdev, (unsigned char *)enrollee_stamac,
				  (unsigned short)dpp_uri_len, (unsigned char *)dpp_uri);
	} else {
		err(DEBUG_CAT_DPP, "1905 security is not enabled.\n");
	}
#endif /* MAP_R3 */
}
#ifdef MTK_TK_HOSTAPD_SUPPORT
void wapp_event_eapol_complete(struct wifi_app *wapp, const char *ifname, const u8 *addr, u8 multi_ap_ext)
{
	struct wapp_dev *wdev = NULL;
	struct wapp_bhsta_info bhsta_info;

	debug(DEBUG_CAT_EVENT, "%s\n", ifname);

	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifname(wapp, ifname);
	if (!wdev) {
		err(DEBUG_CAT_EVENT, RED("wdev %s not found\n"), ifname);
		return;
	}

	os_memcpy(bhsta_info.mac_addr, addr, MAC_ADDR_LEN);
	os_memcpy(bhsta_info.connected_bssid, wdev->mac_addr, MAC_ADDR_LEN);
	bhsta_info.peer_map_enable = multi_ap_ext == BIT(MAP_ROLE_BACKHAUL_STA);

	if (wapp->map && wapp->map->TurnKeyEnable)
		wdev_handle_wsc_eapol_end_notif(wapp, wdev->ifindex, (wapp_event_data *) &bhsta_info);
}
#endif /* MTK_TK_HOSTAPD_SUPPORT */
void wapp_supp_wps_cred_handle(struct wifi_app *wapp, const char *ifname,
				u8 *wps_ced, size_t wps_cred_len)
{
	struct wapp_dev *wdev = NULL;
#ifdef MTK_TK_HOSTAPD_SUPPORT
	struct wps_credential *wps_cred = NULL;
	int send_pkt_len = 0;
	char wsc_profile_buffer[512] = {0};
	u8 i;
	wsc_apcli_config_msg *apcli_config_msg;
#endif

	wdev = wapp_dev_list_lookup_by_ifname(wapp, ifname);
	if (!wdev) {
		err(DEBUG_CAT_EVENT, "valid wdev not found..\n");
		return;
	}

#ifdef MTK_TK_HOSTAPD_SUPPORT
	if (wapp->map && wapp->map->TurnKeyEnable && wps_cred_len != 0) {
		/* hex_dump_dbg("WAPPD-WPS-CRED", wps_ced, wps_cred_len); */
		wps_cred = (struct wps_credential *)wps_ced;

		if (wapp->wsc_save_bh_profile == TRUE) {
			write_configurations(wapp, wps_cred, 0, NULL);
			wapp->wsc_save_bh_profile = FALSE;
		}
		if (wapp->wps_on_controller_cli == 1) {
			write_configurations(wapp, wps_cred, 0, NULL);
			wapp->wps_on_controller_cli = 0;
		}
		wapp->wsc_configs_pending = FALSE;

		apcli_config_msg = (wsc_apcli_config_msg *)wsc_profile_buffer;
		apcli_config_msg->profile_count = 1;

		for (i = 0; i < apcli_config_msg->profile_count; i++) {
			os_memcpy(apcli_config_msg->apcli_config[i].ssid, wps_cred->ssid, wps_cred->ssid_len);
			os_memcpy(apcli_config_msg->apcli_config[i].Key, wps_cred->key, wps_cred->key_len);
			os_memcpy(apcli_config_msg->apcli_config[i].bssid, wps_cred->mac_addr, MAC_ADDR_LEN);

			apcli_config_msg->apcli_config[i].SsidLen = wps_cred->ssid_len;
			apcli_config_msg->apcli_config[i].AuthType = wps_cred->auth_type;
#ifdef MAP_R6
			if ((wps_cred->auth_type & AUTH_SAE_AKM24) || (wps_cred->auth_type & WSC_AUTHTYPE_SAE_AKM24_D)) {
				apcli_config_msg->apcli_config[i].AuthType &= ~AUTH_SAE_AKM24;
				apcli_config_msg->apcli_config[i].AuthType |= WSC_AUTHTYPE_SAE_AKM24_D;
			}
#endif
			apcli_config_msg->apcli_config[i].EncrType = wps_cred->encr_type;
			apcli_config_msg->apcli_config[i].KeyLength = wps_cred->key_len;
			apcli_config_msg->apcli_config[i].KeyIndex = wps_cred->key_idx;
		}

		send_pkt_len = sizeof(wsc_apcli_config_msg) + sizeof(wsc_apcli_config) * apcli_config_msg->profile_count;

		wapp_send_1905_msg(wapp, WAPP_MAP_BH_CONFIG, send_pkt_len, (char *)apcli_config_msg);
	}
#endif /* MTK_TK_HOSTAPD_SUPPORT */
#ifdef MAP_R3
	if (wps_cred_len == 0) {
		/*
		 * If wps crdentials received from supplicant is
		 * with len Zero then trigger DPP Onboarding
		 */
		if (!wapp->dpp) {
			err(DEBUG_CAT_DPP, "DPP not init yet, can't trigger onboarding\n");
			return;
		}

		if (wapp->dpp->onboarding_type == DPP_ONBOARDING_TYPE) {
			notice(DEBUG_CAT_DPP, "No cred in M8, start DPP onboarding\n");
			wapp->dpp->annouce_enrolle.is_enable = 1;
			wapp->wsc_configs_pending = FALSE;
			wapp_dpp_presence_annouce(wapp, NULL);
		}
	}
#endif /* MAP_R3 */
}
#ifdef WPS_UNCONFIG_FEATURE_SUPPORT
void wapp_ap_wps_cred_handle(struct wifi_app *wapp, const char *ifname,
				u8 *wps_ced, size_t wps_cred_len)
{
#ifdef MTK_HOSTAPD_SUPPORT
	struct wapp_dev *wdev = NULL;
	struct wps_credential *wps_cred = NULL;

	wdev = wapp_dev_list_lookup_by_ifname(wapp, ifname);

	if (!wdev) {
		err(DEBUG_CAT_EVENT, "valid wdev not found..\n");
		return;
	}

	debug(DEBUG_CAT_EVENT, "Handle WPS creds\n");

	if (wapp->map && wapp->map->TurnKeyEnable && wps_cred_len != 0) {
		int ret = 0;
		char config_name[16] = {0};
		char value[16] = {0};
		int index;

		if (os_strchr(wdev->ifname, '1'))
			index = 1;
		else if (os_strchr(wdev->ifname, '2'))
			index = 2;
		else if (os_strchr(wdev->ifname, '3'))
			index = 3;
		else
			index = 0;

		if (*(wdev->radio->radio_band) == RADIO_24G)
			index += 5;
		else if ((*(wdev->radio->radio_band) == RADIO_5GL) || (*(wdev->radio->radio_band) == RADIO_5G))
			index += 1;
		else if (*(wdev->radio->radio_band) == RADIO_5GH)
			index += 9;
#ifdef MAP_6E_SUPPORT
		else if (*(wdev->radio->radio_band) == RADIO_6G)
			index += 12;
#endif

		if (!index) {
			err(DEBUG_CAT_EVENT, "invalid index\n");
			return;
		}

		wps_cred = (struct wps_credential *)wps_ced;

		notice(DEBUG_CAT_EVENT, "Update WPS creds for index = %d\n", index);
		ret = os_snprintf(config_name, sizeof(config_name), "mapd.%d", index);

		if (os_snprintf_error(sizeof(config_name), ret)) {
			err(DEBUG_CAT_EVENT, "os_snprintf fail\n");
			return;
		}
		/* Update ssid in /etc/config/mapd */
		wapp_uci_update(config_name, "ssid", (char *) wps_cred->ssid);
		/* Update psk in /etc/config/mapd */
		wapp_uci_update(config_name, "PSK", (char *) wps_cred->key);

		/* Update authmode in /etc/config/mapd */
		ret = os_snprintf(value, sizeof(value), "0x00%x", wps_cred->auth_type);
		if (os_snprintf_error(sizeof(value), ret)) {
			err(DEBUG_CAT_EVENT, "os_snprintf fail for wps authmode\n");
			return;
		}
		wapp_uci_update(config_name, "authmode",  value);

		/* Update encryption type in /etc/config/mapd */
		memset(value, 0, sizeof(value));
		ret = os_snprintf(value, sizeof(value), "0x000%x", wps_cred->encr_type);
		if (os_snprintf_error(sizeof(value), ret)) {
			err(DEBUG_CAT_EVENT, "os_snprintf fail for wps authmode\n");
			return;
		}
		wapp_uci_update(config_name, "EncryptType",  value);


		if (os_execute("/etc/uci2map.lua", 0) < 0) {
			err(DEBUG_CAT_EVENT, "os_execute() fail\n");
			return;
		}

		/* wts file updated, issue the mapd renew command to mapd*/
		map_wps_conf_done_send_map_renew(wapp);
	}
#endif
}
#endif

void wapp_supp_reconfig_fail_handle(struct wifi_app *wapp, const char *ifname)
{
#ifdef MAP_R3_RECONFIG
	struct wapp_dev *wdev = NULL;

	wdev = wapp_dev_list_lookup_by_ifname(wapp, ifname);
	if (!wdev) {
		err(DEBUG_CAT_DPP, "valid wdev not found..\n");
		return;
	}

	/*
	 * IF SAE failure received from supplicant then
	 * trigger reconfiguration
	 */
	if (!wapp->dpp) {
		err(DEBUG_CAT_DPP,  "DPP not init yet, can't trigger reconfig\n");
		return;
	}

	wdev_handle_reconfig_trigger(wapp, wdev->ifindex, NULL);
#endif /* MAP_R3_RECONFIG */
}

void wdev_bcn_report_handle(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL;
	struct beacon_metrics_rsp *bcn_rpt = NULL;
	struct wapp_sta *sta = NULL;
	struct ap_dev *ap = NULL;

	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev)
		return;

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		ap = (struct ap_dev *)wdev->p_dev;
		sta = wdev_ap_client_list_lookup(wapp, ap, event_data->bcn_rpt_info.sta_addr);
		if (!sta || sta->sta_status != WAPP_STA_CONNECTED)
			return;
		if (sta->beacon_report == NULL) {
			sta->beacon_report = (struct beacon_metrics_rsp *)malloc(sizeof(struct beacon_metrics_rsp) + MAX_BEACON_REPORT_LEN);
			if (!sta->beacon_report) {
				err(DEBUG_CAT_MISC, "Error due to null sta->beacon_report\n");
				return;
			}
			os_memset(sta->beacon_report, 0, sizeof(*sta->beacon_report));
			os_memcpy(sta->beacon_report->sta_mac, event_data->bcn_rpt_info.sta_addr, MAC_ADDR_LEN);
		}
		bcn_rpt = sta->beacon_report;
		if ((bcn_rpt->rpt_len + event_data->bcn_rpt_info.bcn_rpt_len) > MAX_BEACON_REPORT_LEN)
			return;
		if (event_data->bcn_rpt_info.last_fragment)
			bcn_rpt->bcn_rpt_num++;
		os_memcpy(&bcn_rpt->rpt[bcn_rpt->rpt_len], event_data->bcn_rpt_info.bcn_rpt,
			(event_data->bcn_rpt_info.bcn_rpt_len > BCN_RPT_LEN) ? BCN_RPT_LEN : event_data->bcn_rpt_info.bcn_rpt_len);
		bcn_rpt->rpt_len += event_data->bcn_rpt_info.bcn_rpt_len;

		 notice(DEBUG_CAT_MISC,
			     " get bcn rpt from " MACSTR " len: %d"
			     " accumulate bcn rpt num: %d\n"
			     " accumulate bcn rpt len: %d\n",
			     MAC2STR(event_data->bcn_rpt_info.sta_addr), event_data->bcn_rpt_info.bcn_rpt_len, bcn_rpt->bcn_rpt_num,
			     bcn_rpt->rpt_len);
	}
}

void wdev_bcn_report_complete_handle(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
#if defined(MAP_SUPPORT)
	char buf[MAX_EVT_BUF_LEN];
	int send_pkt_len = 0;
#endif

	struct wapp_dev *wdev = NULL;
	struct wapp_sta *sta = NULL;
	struct ap_dev *ap = NULL;

	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev)
		return;

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		ap = (struct ap_dev *)wdev->p_dev;
		sta = wdev_ap_client_list_lookup(wapp, ap, event_data->bcn_rpt_info.sta_addr);
		if (!sta || sta->sta_status != WAPP_STA_CONNECTED)
			return;
		if (sta->beacon_report) {
			notice(DEBUG_CAT_MISC, " get bcn rpt complete from " MACSTR "\n", MAC2STR(event_data->bcn_rpt_info.sta_addr));
#if defined(MAP_SUPPORT)
			send_pkt_len = sizeof(struct beacon_metrics_rsp) + sizeof(unsigned char) * sta->beacon_report->rpt_len;
			os_memcpy(buf, sta->beacon_report, send_pkt_len);
			wapp_send_1905_msg(wapp, WAPP_BEACON_METRICS_REPORT, send_pkt_len, buf);
#endif
			free(sta->beacon_report);
			sta->beacon_report = NULL;
		}
	}
}

void wdev_bssload_query_rsp_handle(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL;
	struct bssload_info bssload_info;
	int send_pkt_len = 0;
	char *buf = NULL;

	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);

	if (!wdev)
		return;

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		struct ap_dev *ap = (struct ap_dev *)wdev->p_dev;
		os_memcpy(&ap->bssload, &event_data->bssload_info, sizeof(wapp_bssload_info));

		 notice(DEBUG_CAT_MISC,
			     " sta_cnt: %d"
			     " ch_util: %d\n"
			     " AvalAdmCap: %x\n",
			     event_data->bssload_info.sta_cnt, event_data->bssload_info.ch_util, event_data->bssload_info.AvalAdmCap);

		os_memcpy(&bssload_info, &ap->bssload, sizeof(struct bssload_info));
		send_pkt_len = sizeof(struct bssload_info);
		buf = os_zalloc(send_pkt_len);
		if (buf) {
			os_memcpy(buf, &bssload_info, send_pkt_len);
			wapp_send_1905_msg(wapp, WAPP_STA_BSSLOAD, send_pkt_len, buf);
			os_free(buf);
		}
	}
}

void wdev_mnt_info_query_rsp_handle(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL;
	int send_pkt_len = 0;
	char *buf = NULL;

	if (!wapp)
		return;

#ifdef MAP_SUPPORT
	if (!dl_list_empty(&wapp->sta_mntr_list)) {
		air_monitor_packet_handle(wapp, ifindex, event_data);
		return;
	}
#endif
#ifdef COSR_SUPPORT
	if (!dl_list_empty(&wapp->cosr_sta_mntr_list)) {
		cosr_airmonitor_packet_handle(wapp, ifindex, event_data);
		return;
	}
#endif
	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev)
		return;

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		struct ap_dev *ap = (struct ap_dev *)wdev->p_dev;
		wapp_mnt_info *mnt_info;

		mnt_info = &ap->mnt;
		os_memcpy(mnt_info, &event_data->mnt_info, sizeof(wapp_mnt_info));

		send_pkt_len = sizeof(wapp_mnt_info);
		buf = os_zalloc(send_pkt_len);
		if (buf) {
			os_memcpy(buf, mnt_info, send_pkt_len);
			wapp_send_1905_msg(wapp, WAPP_NAC_INFO, send_pkt_len, buf);
			os_free(buf);
		}
	}
}

void wdev_sta_rssi_query_rsp_handle(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL;
	wapp_client_info *cli = NULL;
	struct wapp_sta *sta = NULL;
	int send_pkt_len = 0;
	char *buf = NULL;

	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev)
		return;

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		cli = &event_data->cli_info;

		sta = wdev_ap_client_list_lookup_for_all_bss(wapp, cli->mac_addr);
		if (sta) {
			sta->uplink_rssi = cli->uplink_rssi;
			 notice(DEBUG_CAT_MISC, "sta->uplink_rssi: %d", sta->uplink_rssi);

			send_pkt_len = MAC_ADDR_LEN + sizeof(u8);
			buf = os_zalloc(send_pkt_len);
			if (buf) {
				os_memcpy(buf, sta->mac_addr, MAC_ADDR_LEN);
				os_memcpy(buf + MAC_ADDR_LEN, &sta->uplink_rssi, sizeof(u8));
				wapp_send_1905_msg(wapp, WAPP_STA_RSSI, send_pkt_len, buf);
				os_free(buf);
			}
		}
	}
}

#ifdef COSR_SUPPORT
void wdev_sr_support_mode_query_rsp_handle(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	int sr_support_mode = 0;
	struct wapp_dev *wdev = NULL;

	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev)
		return;

	sr_support_mode = event_data->sr_support_mode;
	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		wdev->cosr_support_mode = sr_support_mode;
		debug(DEBUG_CAT_MISC, "sr_suppor_mode = %d\n", wdev->cosr_support_mode);
	}
}

void wdev_cosr_sta_rssi_query_rsp_handle(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL;
	wapp_client_info *cli = NULL;
	struct wapp_sta *sta = NULL;
	struct ap_dev *ap = NULL;
	u8 i = 0, u1BandIdx = 0;
	signed char cand_sta_rssi = 0;

	 debug(DEBUG_CAT_MISC, "cosr_sta_rssi_query_rsp\n");

	if (!wapp)
		return;
	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev || (wdev->dev_type != WAPP_DEV_TYPE_AP))
		return;
	ap = (struct ap_dev *)wdev->p_dev;
	if (!ap)
		return;
	u1BandIdx = cosr_get_bandidx(wapp, wdev);
	if (u1BandIdx == 0xFF)
		return;
	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		cli = &event_data->cli_info;

		sta = wdev_ap_client_list_lookup_for_all_bss(wapp, cli->mac_addr);
		if (sta == NULL) {
			err(DEBUG_CAT_MISC, "get sta NULL\n");
			return;
		}
		sta->uplink_rssi = cli->uplink_rssi;
		 notice(DEBUG_CAT_MISC, "sta->uplink_rssi: %d", sta->uplink_rssi);

		for (i = 0; i < MAX_COSR_STA_COUNT; i++) {
			if (wapp->candlist_sta[u1BandIdx][i])
				if (!os_memcmp(wapp->candlist_sta[u1BandIdx][i]->mac_addr, cli->mac_addr, MAC_ADDR_LEN))
					break;
		}
		if (i < MAX_COSR_STA_COUNT) {
			debug(DEBUG_CAT_MISC, "sta id %d instant rssi %d candlist rssi %d\n", i,
				sta->uplink_rssi, wapp->candlist_sta[u1BandIdx][i]->uplink_rssi);
			cand_sta_rssi = (signed char)wapp->candlist_sta[u1BandIdx][i]->uplink_rssi;
			 debug(DEBUG_CAT_MISC, "candlist rssi %d\n", cand_sta_rssi);
			/* only when previous uplink rssi is valid */
			if (cand_sta_rssi > -100) {
				if ((abs(wapp->candlist_sta[u1BandIdx][i]->uplink_rssi - sta->uplink_rssi) > 10) ||
					(sta->uplink_rssi < (INVALID_STA_THRESHOLD))) {
					 debug(DEBUG_CAT_MISC, "Temporarily remove delete blacklist\n");
					/* Removed Large RSSI variation detection due to impact on FW tracking algorithm */
					//cosr_del_candlist_sta(wapp, wdev, wapp->candlist_sta[u1BandIdx][i]->mac_addr);
				}
			}
		}
	}
}
#endif

void wdev_cli_active_change_rsp_handle(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL;
	wapp_client_info *cli = NULL;
	struct wapp_sta *sta = NULL;
	struct ap_dev *ap = NULL;
	int send_pkt_len = 0;
	wapp_sta_status_info *sta_status = NULL;

	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev)
		return;

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		cli = &event_data->cli_info;
		ap = (struct ap_dev *)wdev->p_dev;
		sta = wdev_ap_client_list_lookup(wapp, ap, cli->mac_addr);

		if (sta) {
			sta->stat = cli->status;
			 notice(DEBUG_CAT_MISC, RED("sta->stat: %d"), sta->stat);

			send_pkt_len = sizeof(wapp_sta_status_info);
			sta_status = (wapp_sta_status_info *)os_zalloc(send_pkt_len);
			if (sta_status) {
				os_memcpy(sta_status->sta_mac, sta->mac_addr, MAC_ADDR_LEN);
				sta_status->status = sta->stat;
				wapp_send_1905_msg(wapp, WAPP_STA_STAT, send_pkt_len, (char *)sta_status);
				os_free(sta_status);
			}
		} else
			err(DEBUG_CAT_MISC, RED("Null sta\n"));
	}
}

void wdev_ssid_change_rsp_handle(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct evt *wapp_event = NULL;
	char *map_evt_buf = NULL;
	int send_pkt_len = 0;
	struct wapp_dev *wdev = NULL;

	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev)
		return;

	send_pkt_len = (event_data->SSID.SsidLength + MAC_ADDR_LEN + sizeof(struct evt));
	map_evt_buf = (char *)os_zalloc(send_pkt_len);
	if (map_evt_buf) {
		memset(map_evt_buf, 0, send_pkt_len);
		wapp_event = (struct evt *)map_evt_buf;
		wapp_event->type = WAPP_SSID;
		wapp_event->length = event_data->SSID.SsidLength + MAC_ADDR_LEN;
		os_memcpy(wapp_event->buffer, wdev->mac_addr, MAC_ADDR_LEN);
		os_memcpy(wapp_event->buffer + MAC_ADDR_LEN, event_data->SSID.Ssid, event_data->SSID.SsidLength);

		if (event_data->SSID.SsidLength) {
			if (map_1905_send(wapp, map_evt_buf, send_pkt_len) < 0) {
				os_free(map_evt_buf);
				return;
			}
		}
		os_free(map_evt_buf);
	}
}

void wdev_chn_change_rsp_handle(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL;
	struct wapp_dev *wdev_temp = NULL, *wdev_tmp = NULL;
	struct dl_list *dev_list = NULL;
	u8 new_ch = 0;
	u8 op_class = 0;
#ifdef MAP_EHT_SUPPORT
	unsigned int event_size = 0;
	char *channel_prefer_info = NULL;
	struct evt *evt_tlv = NULL;
	unsigned char count;
	unsigned short len;
	unsigned char radio_id[MAC_ADDR_LEN];
#endif

	if (!wapp)
		return;

	if (event_data->ch_change_info.new_ch == 0 ||
		event_data->ch_change_info.op_class == 0) {
		err(DEBUG_CAT_MISC, "new_channel or op_class invalid, skip it\n");
		return;
	}

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev)
		return;

	dev_list = &wapp->dev_list;
	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		struct ap_dev *ap = (struct ap_dev *)wdev->p_dev;
		wdev_chn_info *chn_list;

		chn_list = &ap->ch_info;
		chn_list->op_ch = event_data->ch_change_info.new_ch;
		chn_list->op_class = event_data->ch_change_info.op_class;
		notice(DEBUG_CAT_CHANNEL, "ch: %u op_class: %u\n", ap->ch_info.op_ch, ap->ch_info.op_class);
		if (wdev->radio) {
			wdev->radio->op_ch = chn_list->op_ch;
#ifdef MAP_6E_SUPPORT
			wdev->radio->opclass = chn_list->op_class;
#endif

		}
		dl_list_for_each_safe(wdev_temp, wdev_tmp, dev_list, struct wapp_dev, list)
		{
			if (wdev->radio == wdev_temp->radio && wdev_temp->dev_type == WAPP_DEV_TYPE_AP) {
				struct ap_dev *ap = (struct ap_dev *)wdev_temp->p_dev;

				if (ap) {
					ap->ch_info.op_ch = event_data->ch_change_info.new_ch;
					ap->ch_info.op_class = event_data->ch_change_info.op_class;
				}
			}
		}
	} else if (wdev->dev_type == WAPP_DEV_TYPE_STA) {
		new_ch = event_data->ch_change_info.new_ch;
		op_class = event_data->ch_change_info.op_class;
#ifdef MAP_6E_SUPPORT
		wdev->radio->opclass = op_class;
#endif
		wapp_radio_update_ch(wapp, wdev->radio, new_ch);
		dl_list_for_each_safe(wdev_temp, wdev_tmp, dev_list, struct wapp_dev, list)
		{
			if (wdev->radio == wdev_temp->radio) {
				if (wdev_temp->dev_type == WAPP_DEV_TYPE_AP) {
					struct ap_dev *ap = (struct ap_dev *)wdev_temp->p_dev;
					ap->ch_info.op_ch = new_ch;
					ap->ch_info.op_class = op_class;
				}
			}
		}
	}
#ifdef MAP_EHT_SUPPORT
	if ((event_data->eht_ch_change == 1
#ifdef EM_PLUS_SUPPORT
		|| (wapp->radat_detect && wdev->radio && IS_OP_CLASS_5G(wdev->radio->opclass))
#endif
	) && wdev->radio) {
		if (event_data->eht_ch_change == 1)
			wapp_radio_update_eht_cap(wapp, wdev);
		notice(DEBUG_CAT_CHANNEL, "send preference report");
		/*build channel preference for each radio*/
		MAP_GET_RADIO_IDNFER(wdev->radio, radio_id);
#ifdef EM_PLUS_SUPPORT /* 3 */
		wdev = NULL;
		wdev = wapp_dev_list_lookup_by_radio(wapp, (char *)radio_id);
		if (!wdev) {
			err(DEBUG_CAT_MISC, "null wdev\n");
			return;
		}
#endif /* EM_PLUS_SUPPORT */
		count = get_total_opclass_for_pref(wdev);
		len = sizeof(struct evt) + sizeof(struct ch_prefer) + sizeof(struct prefer_info) * count;
		channel_prefer_info = os_zalloc(len);
		if (channel_prefer_info == NULL)
			return;

		evt_tlv = (struct evt *)channel_prefer_info;
		event_size = map_build_chn_pref(wapp, radio_id, channel_prefer_info, 0);
		if (event_size) {
			wapp_send_1905_msg(wapp, WAPP_CHANNEL_PREFERENCE, event_size - sizeof(struct evt),
					(char *)evt_tlv->buffer);
		}
#ifdef EM_PLUS_SUPPORT
		wapp->radat_detect = 0;
#endif
		os_free(channel_prefer_info);
	}
#endif
}

void wdev_csa_event_rsp_handle(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct dl_list *dev_list;
	struct wapp_dev *wdev = NULL, *wdev_temp = NULL;
	int send_pkt_len = 0;
	char *buf = NULL;
	u8 ruid[MAC_ADDR_LEN];

	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev)
		return;

	if (wdev->dev_type == WAPP_DEV_TYPE_STA) {
		MAP_GET_RADIO_IDNFER(wdev->radio, ruid);

		if (wdev->radio->op_ch != event_data->csa_info.new_channel) {
			wdev_chn_info *chn_list;
			struct csa_info_rsp csa_info;
#ifdef MAP_6E_SUPPORT
			/* ToDo: Send opclass from driver */
			/* wdev->radio->opclass = event_data->csa_info.new_opclass; */
#endif
			wapp_radio_update_ch(wapp, wdev->radio, event_data->csa_info.new_channel);

			// update op_ch of ap wdev under this ruid
			dev_list = &wapp->dev_list;
			dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list)
			{
				if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
					u8 wdev_identifier[MAC_ADDR_LEN];
					MAP_GET_RADIO_IDNFER(wdev->radio, wdev_identifier);
					if (!os_memcmp(wdev_identifier, ruid, MAC_ADDR_LEN)) {
						struct ap_dev *ap = (struct ap_dev *)wdev->p_dev;

						ap->ch_info.op_ch = event_data->csa_info.new_channel;
						chn_list = &ap->ch_info;
						chn_list->op_ch = event_data->csa_info.new_channel;
					}
				}
			}

			os_memcpy(csa_info.ruid, ruid, MAC_ADDR_LEN);
			csa_info.new_ch = event_data->csa_info.new_channel;
			send_pkt_len = sizeof(struct csa_info_rsp);
			buf = os_zalloc(send_pkt_len);
			if (buf) {
				os_memcpy(buf, &csa_info, send_pkt_len);
				wapp_send_1905_msg(wapp, WAPP_CSA_INFO, send_pkt_len, buf);
				os_free(buf);
			}
		}
	}
	wapp->csa_new_channel = event_data->csa_info.new_channel;
	if (wapp->map->quick_ch_change == TRUE)
		wapp->cli_assoc_info.current_channel = event_data->csa_info.new_channel;
	map_operating_channel_info(wapp);
}

void wdev_apcli_rssi_query_rsp_handle(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL;
	int send_pkt_len = 0;
	char *buf = NULL;

	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev)
		return;

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		wapp_apcli_association_info *apcli_info = &event_data->apcli_association_info;

		send_pkt_len = sizeof(char);
		buf = os_zalloc(send_pkt_len);
		if (buf) {
			os_memcpy(buf, &apcli_info->rssi, send_pkt_len);
			wapp_send_1905_msg(wapp, WAPP_APCLI_UPLINK_RSSI, send_pkt_len, buf);
			os_free(buf);
		}
	}
}

#ifdef WPS_UNCONFIG_FEATURE_SUPPORT
int map_wps_conf_done_send_map_renew(struct wifi_app *wapp)
{
	struct evt *map_event = NULL;
	char buf[50] = {0};
	u16 evt_len = 0;

	map_event = (struct evt *)buf;
	map_event->type = WAPP_MAP_RENEW;
	map_event->length = 0;
	evt_len = sizeof(struct evt);

	notice(DEBUG_CAT_WIFI_CONFIG, "\nwapp :: WPS Configuration done, sending mapd renew to sync all\n");
	if (map_1905_send(wapp, buf, evt_len) < 0) {
		err(DEBUG_CAT_WIFI_CONFIG, "Error send map renew event\n");
		return -1;
	}
	memset(buf, 0, evt_len);
	return 0;
}
/* Below function was used when Event was received from driver in Jedi */
#define MAX_WTS_AP_CONF_LENGTH 200
void wdev_wps_configuration_handle(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	char *buf = NULL, *file = NULL, *index_ptr = NULL, *next_to_index_ptr = NULL;
	int ch = 0, index_2G = 0, index_5GL = 0, index_5GH = 0;
	char index = 0, temp[10], str[200];
	FILE *f;
	int i = 0, size = 0, res = 0, ret;
	struct set_config_bss_info bss_config = {0};
	u8 radio_num = 0;
	long val = 0;

	for (i = 0; i < MAX_NUM_OF_RADIO; i++) {
		if (wapp->radio[i].adpt_id)
			radio_num++;
	}

	i = 0;
	buf = os_zalloc(sizeof(struct set_config_bss_info) * MAX_SET_BSS_INFO_NUM);
	if (buf == NULL) {
		err(DEBUG_CAT_MISC, "\nwdev_wps_configuration_handle, buf memory allocation fail");
		return;
	}

	file = os_zalloc(sizeof(struct set_config_bss_info) * MAX_SET_BSS_INFO_NUM);
	if (file == NULL) {
		err(DEBUG_CAT_MISC, "\nwdev_wps_configuration_handle, file memory allocation fail");
		goto error;
	}

	notice(DEBUG_CAT_MISC, "\nwdev_wps_configuration_handle");
	notice(DEBUG_CAT_MISC, "\nSSID = %s, key = %s, len = %d", event_data->wps_conf_info.SSID, event_data->wps_conf_info.Key,
		 event_data->wps_conf_info.KeyLength);
	notice(DEBUG_CAT_MISC, "\nchannel = %d,", event_data->wps_conf_info.channel);
	notice(DEBUG_CAT_MISC, "\nindex = %d,", event_data->wps_conf_info.index);
	notice(DEBUG_CAT_MISC, "\nAuth = %d, EncyType = %d, Bss_role = %d", event_data->wps_conf_info.AuthType,
		 event_data->wps_conf_info.EncrType, event_data->wps_conf_info.bss_role);
	notice(DEBUG_CAT_MISC, "\nMAC :: 02x%x:02x%x:02x%x:02x%x:02x%x:02x%x\n", event_data->wps_conf_info.MacAddr[0],
		 event_data->wps_conf_info.MacAddr[1], event_data->wps_conf_info.MacAddr[2], event_data->wps_conf_info.MacAddr[3],
		 event_data->wps_conf_info.MacAddr[4], event_data->wps_conf_info.MacAddr[5]);

	os_strncpy(bss_config.ssid, (char *)event_data->wps_conf_info.SSID, sizeof(bss_config.ssid));
	bss_config.ssid[sizeof(bss_config.ssid) - 1] = '\0';
	NdisCopyMemory(bss_config.key, event_data->wps_conf_info.Key, event_data->wps_conf_info.KeyLength);
	bss_config.authmode = event_data->wps_conf_info.AuthType;
	bss_config.encryptype = event_data->wps_conf_info.EncrType;
	index = event_data->wps_conf_info.index;

	/* Read wts_bss_info_config file*/
	f = fopen("/etc/map/wts_bss_info_config", "r");
	if (f == NULL) {
		err(DEBUG_CAT_MISC, "\nfile opening error\n");
		goto error2;
	}

	while (1) {
		ch = fgetc(f);
		if (ferror(f) != 0) {
			err(DEBUG_CAT_MISC, "fgetc error\n");
			clearerr(f);
			goto error3;
		}
		if (ch == EOF)
			break;
		file[i++] = ch;
	}
	ret = fseek(f, 0, SEEK_SET);
	if (ret != 0) {
		err(DEBUG_CAT_MISC, "fseek fail\n");
		goto error3;
	}

	while (!feof(f)) {
		if (fgets(str, 200, f) == NULL)
			err(DEBUG_CAT_MISC, "fgets() return value NULL\n");
		if (strstr(str, "8x") && !index_2G) {
			memmove(temp, str, 2);
			val = strtol(temp, NULL, 10);
			if (val == LONG_MAX || val == LONG_MIN)
				err(DEBUG_CAT_INIT, "strtol fail\n");
			else
				index_2G = (int)val;
		} else if (strstr(str, "11x") && !index_5GL) {
			memmove(temp, str, 2);
			val = strtol(temp, NULL, 10);
			if (val == LONG_MAX || val == LONG_MIN)
				err(DEBUG_CAT_INIT, "strtol fail\n");
			else
				index_5GL = (int)val;
		} else if (strstr(str, "12x") && !index_5GH) {
			memmove(temp, str, 2);
			val = strtol(temp, NULL, 10);
			if (val == LONG_MAX || val == LONG_MIN)
				err(DEBUG_CAT_INIT, "strtol fail\n");
			else
				index_5GH = (int)val;
		} else
			continue;
	}
	ret = fclose(f);
	if (ret != 0) {
		err(DEBUG_CAT_MISC, "fclose fail\n");
		goto error2;
	}
	f = NULL;
	/* update the index with new configuration and copy to buf for file write*/
	if (IS_MAP_CH_24G(event_data->wps_conf_info.channel)) {
		index += index_2G;
		if (index == index_2G) {
			res = os_snprintf(buf, MAX_WTS_AP_CONF_LENGTH,
					"%d,ff:ff:ff:ff:ff:ff 8x %s 0x00%x 0x000%x %s 1 0 hidden-N 4095 N/A N/A\n", index,
					bss_config.ssid, bss_config.authmode, bss_config.encryptype, event_data->wps_conf_info.Key);
		} else {
			res = os_snprintf(buf, MAX_WTS_AP_CONF_LENGTH,
					"%d,ff:ff:ff:ff:ff:ff 8x %s 0x00%x 0x000%x %s 0 1 hidden-N 4095 N/A N/A\n", index,
					bss_config.ssid, bss_config.authmode, bss_config.encryptype, event_data->wps_conf_info.Key);
		}

		if (os_snprintf_error(MAX_WTS_AP_CONF_LENGTH, res)) {
			err(DEBUG_CAT_MISC, "[%d] Unexpected snprintf fail\n", __LINE__);
			goto error2;
		}
	} else if ((radio_num >= 3) && (IS_MAP_CH_5GH(event_data->wps_conf_info.channel))) {
		index += index_5GH;
		if (index == index_5GH) {
			res = os_snprintf(buf, MAX_WTS_AP_CONF_LENGTH,
					"%d,ff:ff:ff:ff:ff:ff 12x %s 0x00%x 0x000%x %s 1 0 hidden-N 4095 N/A N/A\n", index,
					bss_config.ssid, bss_config.authmode, bss_config.encryptype, event_data->wps_conf_info.Key);
		} else {
			res = os_snprintf(buf, MAX_WTS_AP_CONF_LENGTH,
					"%d,ff:ff:ff:ff:ff:ff 12x %s 0x00%x 0x000%x %s 0 1 hidden-N 4095 N/A N/A\n", index,
					bss_config.ssid, bss_config.authmode, bss_config.encryptype, event_data->wps_conf_info.Key);
		}

		if (os_snprintf_error(MAX_WTS_AP_CONF_LENGTH, res)) {
			err(DEBUG_CAT_MISC, "Unexpected snprintf fail\n");
			goto error2;
		}
	} else {
		index += index_5GL;
		if (index == index_5GL) {
			res = os_snprintf(buf, MAX_WTS_AP_CONF_LENGTH,
					  "%d,ff:ff:ff:ff:ff:ff 11x %s 0x00%x 0x000%x %s 1 0 hidden-N 4095 pvid 5\n", index,
					  bss_config.ssid, bss_config.authmode, bss_config.encryptype, event_data->wps_conf_info.Key);
		} else {
			res = os_snprintf(buf, MAX_WTS_AP_CONF_LENGTH,
					  "%d,ff:ff:ff:ff:ff:ff 11x %s 0x00%x 0x000%x %s 0 1 hidden-N 4095 N/A N/A\n", index,
					  bss_config.ssid, bss_config.authmode, bss_config.encryptype, event_data->wps_conf_info.Key);
		}

		if (os_snprintf_error(MAX_WTS_AP_CONF_LENGTH, res)) {
			err(DEBUG_CAT_MISC, "Unexpected snprintf fail\n");
			goto error2;
		}
	}

	notice(DEBUG_CAT_MISC, "\n%s", buf);

	memset(temp, 0, sizeof(temp));
	res = os_snprintf(temp, sizeof(temp), "%d,", index);
	if (os_snprintf_error(sizeof(temp), res)) {
		err(DEBUG_CAT_MISC, "Unexpected snprintf fail\n");
		goto error2;
	}
	index_ptr = strstr(file, temp);
	if (index_ptr == NULL)
		goto error2;
	res = os_snprintf(temp, sizeof(temp), "%d,", index + 1);
	if (os_snprintf_error(sizeof(temp), res)) {
		err(DEBUG_CAT_MISC, "Unexpected snprintf fail\n");
		goto error2;
	}
	next_to_index_ptr = strstr(file, temp);

	size = strlen(buf);
	/*  contents after the index, copy to buf*/
	if (next_to_index_ptr == NULL)
		goto error2;

	memmove(buf + size, next_to_index_ptr, strlen(next_to_index_ptr));
	/* reset wts file contents from the index*/
	memset(index_ptr, 0, strlen(index_ptr));
	/* copy the updated buf with the new configuration to wts file.*/
	memmove(index_ptr, buf, strlen(buf));
	notice(DEBUG_CAT_MISC, "\n%s\n", file);

	/* open wts file in write mode to write with updated configuration*/
	f = fopen("/etc/map/wts_bss_info_config", "w+");
	if (f == NULL) {
		err(DEBUG_CAT_MISC, "\nfile opening error\n");
		goto error2;
	}
	size = 0;
	size = fwrite(file, 1, strlen(file), f);
	if (strlen(file) != size) {
		err(DEBUG_CAT_MISC, "write error");
		goto error3;
	}
	ret = fclose(f);
	if (ret != 0)
		err(DEBUG_CAT_MISC, "fclose fail\n");

	os_free(file);
	os_free(buf);

	/* wts file updated, issue the mapd renew command to mapd*/
	map_wps_conf_done_send_map_renew(wapp);
	return;

error3:
	if (f != NULL) {
		ret = fclose(f);
		if (ret != 0)
			err(DEBUG_CAT_MISC, "fclose fail\n");
	}
error2:
	if (file)
		os_free(file);
error:
	if (buf)
		os_free(buf);
}
#endif
void wdev_bss_stat_change_handle(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL;
	int send_pkt_len = 0;
	char *buf = NULL;
#ifdef EM_PLUS_SUPPORT
	size_t len = sizeof(wapp_dev_info);
	wapp_dev_info dev_buf = {0};
#endif

	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev)
		return;

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		struct ap_dev *ap = (struct ap_dev *)wdev->p_dev;
#ifdef EM_PLUS_SUPPORT
		if (ap->isActive == WAPP_BSS_STOP &&
			event_data->bss_state_info.bss_state == WAPP_BSS_START) {
			warn(DEBUG_CAT_MISC, "BSS:%s current state:%d\n", wdev->ifname, ap->isActive);
			wapp_get_wdev_from_driver(wapp, wdev->ifname, (char *)&dev_buf, len);
			wdev_query_rsp_handle(wapp, (wapp_dev_info *)&dev_buf);
		}
#endif
		ap->isActive = event_data->bss_state_info.bss_state;

		// Send to other daemon
		struct bss_state_info bss_stat_info;
		bss_stat_info.bss_state = event_data->bss_state_info.bss_state;
		bss_stat_info.interface_index = event_data->bss_state_info.interface_index;
		send_pkt_len = sizeof(struct bss_state_info);
		os_alloc_mem(NULL, (UCHAR **)&buf, send_pkt_len);
		if (buf) {
			os_memcpy(buf, &bss_stat_info, send_pkt_len);
			wapp_send_1905_msg(wapp, WAPP_BSS_STAT_CHANGE, send_pkt_len, buf);
			os_free(buf);
		}
	}
}

void wdev_bssload_crossing_handle(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL;
	int send_pkt_len = 0;
	char *buf = NULL;

	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev)
		return;

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		struct bssload_crossing_info bssload_crossing_info;

		bssload_crossing_info.bssload = event_data->bssload_crossing_info.bssload;
		bssload_crossing_info.bssload_high_thrd = event_data->bssload_crossing_info.bssload_high_thrd;
		bssload_crossing_info.bssload_low_thrd = event_data->bssload_crossing_info.bssload_low_thrd;
		bssload_crossing_info.interface_index = event_data->bssload_crossing_info.interface_index;

		send_pkt_len = sizeof(struct bssload_crossing_info);
		os_alloc_mem(NULL, (UCHAR **)&buf, send_pkt_len);
		if (buf) {
			os_memcpy(buf, &bssload_crossing_info, send_pkt_len);
			wapp_send_1905_msg(wapp, WAPP_BSS_LOAD_CROSSING, send_pkt_len, buf);
			os_free(buf);
		}
	}
}

#ifdef STANDARD_NL_CMD
void wdev_apcli_assoc_stat_change_nl_handle(struct wifi_app *wapp, struct nl_apcli_assoc_info *event_data)
{
	struct wapp_dev *wdev = NULL, *ap_wdev = NULL;
	int i = 0, ifindex = 0;
#if WEXT_SUPPORT
	u8 Enable = 0;
#else
#ifndef MTK_HOSTAPD_SUPPORT
	int ret = 0;
#endif /* MTK_HOSTAPD_SUPPORT */
#endif /* WEXT_SUPPORT */

	if (!wapp || !event_data)
		return;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, event_data->interface_index);
	if (!wdev)
		return;

	if (wdev->dev_type == WAPP_DEV_TYPE_STA) {
		// Send to other daemon
		struct apcli_association_info *apcli_stat_info = &wapp->cli_assoc_info;

		ifindex = event_data->interface_index;
		apcli_stat_info->interface_index = event_data->interface_index;
		apcli_stat_info->apcli_assoc_state = event_data->apcli_assoc_state;
		apcli_stat_info->peer_map_enable = event_data->PeerMAPEnable;
		apcli_stat_info->current_channel = wdev->radio->op_ch;
		 debug(DEBUG_CAT_MISC, "apcli_stat_info->apcli_assoc_state %d\n", apcli_stat_info->apcli_assoc_state);

#ifdef MAP_R3
		/* If dpp onboard is ongoing then don't handle BEST AP for disconnection */
		if ((wapp->map && wapp->map->map_version == DEV_TYPE_R3) &&
		    (wapp->dpp && ((wapp->dpp_caused_disconnect == 1) || (wapp->reconfigTrigger == TRUE))) &&
		    (apcli_stat_info->apcli_assoc_state == WAPP_APCLI_DISASSOCIATED) &&
			(wapp->dpp->dpp_allowed_roles == DPP_CAPAB_ENROLLEE)) {
			apcli_stat_info->dpp_onb_ongoing = 1;
			wapp->dpp_caused_disconnect = 0;
		} else {
			if (wapp->dpp && wapp->dpp->dpp_onboard_ongoing) {
				wapp->dpp->dpp_onboard_ongoing = 0;
				wapp_dpp_presence_announce_stop(wapp);
			}
			apcli_stat_info->dpp_onb_ongoing = 0;
		}

		if (wapp->dpp)
			warn(DEBUG_CAT_MISC, "value of apcli flag onboard:%u and dpp onboard flag:%u\n",
				apcli_stat_info->dpp_onb_ongoing, wapp->dpp->dpp_onboard_ongoing);
#endif /* MAP_R3 */

		if (!wapp->wsc_configs_pending) {
			if (wapp->map && (wapp->map->quick_ch_change == TRUE || wapp->csa_notif_received != TRUE)) {
				wapp_send_1905_msg(wapp, WAPP_APCLI_ASSOC_STAT_CHANGE, sizeof(struct apcli_association_info),
						   (char *)&wapp->cli_assoc_info);
				map_update_bh_link_info(wapp, MAP_BH_WIFI, wapp->cli_assoc_info.apcli_assoc_state, ifindex);
				if (!wapp->map->bh_link_num) {
					wapp->map->bh_link_ready = 0;
					if (wapp->map->my_map_dev_role != DEVICE_ROLE_CONTROLLER)
						wapp->map->ctrler_found = 0;
				}
			} else {
				wapp->link_change_notif_pending = TRUE;
			}

			if (wapp->map && (wapp->map->TurnKeyEnable && apcli_stat_info->apcli_assoc_state == WAPP_APCLI_DISASSOCIATED)
#ifdef MAP_R3
				&& wapp->map->map_version == DEV_TYPE_R3
				&& (wapp->dpp && ((wapp->dpp_caused_disconnect == 1)
				|| (wapp->reconfigTrigger == TRUE)))
				&& (wapp->dpp->dpp_allowed_roles == DPP_CAPAB_ENROLLEE)
#endif
			) {
				eloop_cancel_timeout(map_config_state_check, wapp, NULL);
				if (wdev && wdev->dev_type == WAPP_DEV_TYPE_STA) {
#if WEXT_SUPPORT
					wapp_set_apcli_mode(wapp, (const char *)wdev->ifname, (char *)&Enable, 1);
#else
#ifdef MTK_HOSTAPD_SUPPORT
					if (wapp->drv_ops->drv_send_disable_network)
						wapp->drv_ops->drv_send_disable_network(wapp->drv_data, wdev->ifname, wdev->network_id);

#else
					char local_command[128];

					os_memset(local_command, 0, sizeof(local_command));

					ret = os_snprintf(local_command, sizeof(local_command), "mwctl %s set ApCliEnable=0", wdev->ifname);
					if (os_snprintf_error(sizeof(local_command), ret)) {
						err(DEBUG_CAT_MISC, "os_snprintf fail\n");
						return;
					}
					system(local_command);
#endif /* MTK_HOSTAPD_SUPPORT */
#endif
				}
			} else {
				for (i = 0; i < MAX_NUM_OF_RADIO; i++) {
					/* This command will go twice in case of single chip DBDC */
					if (wapp->radio[i].adpt_id) {
						char idfr[MAC_ADDR_LEN];
						struct wapp_radio *ra = &wapp->radio[i];

						MAP_GET_RADIO_IDNFER(ra, idfr);
						ap_wdev = wapp_dev_list_lookup_by_radio(wapp, idfr);
						if (!ap_wdev) {
							err(DEBUG_CAT_MISC, "null wdev\n");
							continue;
						}
#if WEXT_SUPPORT
						Enable = 1;
						wapp_set_APproxy_refresh(wapp, (const char *)wdev->ifname, (char *)&Enable, 1);
#else
						wdev_set_approxyrefresh(wapp, ap_wdev, 1);
#endif
					}
				}
			}
		} else {
			if (apcli_stat_info->apcli_assoc_state == WAPP_APCLI_DISASSOCIATED)
				stop_con_cli_wps(wapp, NULL);
		}
	}
}
#endif/*STANDARD_NL_CMD*/
void wdev_apcli_assoc_stat_change_handle(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL, *ap_wdev;
	int i;
#if WEXT_SUPPORT
	u8 Enable = 0;
#else
#ifndef MTK_HOSTAPD_SUPPORT
	int ret = 0;
#endif /* MTK_HOSTAPD_SUPPORT */
#endif /* WEXT_SUPPORT */

	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev)
		return;

	if (wdev->dev_type == WAPP_DEV_TYPE_STA) {
		// Send to other daemon
		struct apcli_association_info *apcli_stat_info = &wapp->cli_assoc_info;
		apcli_stat_info->interface_index = event_data->apcli_association_info.interface_index;
		apcli_stat_info->apcli_assoc_state = event_data->apcli_association_info.apcli_assoc_state;
		apcli_stat_info->peer_map_enable = event_data->apcli_association_info.PeerMAPEnable;
		apcli_stat_info->current_channel = wdev->radio->op_ch;
		notice(DEBUG_CAT_MISC, "apcli_stat_info->apcli_assoc_state %d\n", apcli_stat_info->apcli_assoc_state);

#ifdef MAP_R3
		/* If dpp onboard is ongoing then don't handle BEST AP for disconnection */
		if ((wapp->map && wapp->map->map_version == DEV_TYPE_R3) &&
		    (wapp->dpp && ((wapp->dpp_caused_disconnect == 1) || (wapp->reconfigTrigger == TRUE))) &&
		    (apcli_stat_info->apcli_assoc_state == WAPP_APCLI_DISASSOCIATED) &&
			(wapp->dpp->dpp_allowed_roles == DPP_CAPAB_ENROLLEE)) {
			apcli_stat_info->dpp_onb_ongoing = 1;
			wapp->dpp_caused_disconnect = 0;
		} else {
			if (wapp->dpp && wapp->dpp->dpp_onboard_ongoing) {
				wapp->dpp->dpp_onboard_ongoing = 0;
				wapp_dpp_presence_announce_stop(wapp);
			}
			apcli_stat_info->dpp_onb_ongoing = 0;
		}

		if (wapp->dpp)
			warn(DEBUG_CAT_MISC, "value of apcli flag onboard:%u and dpp onboard flag:%u\n",
				 apcli_stat_info->dpp_onb_ongoing, wapp->dpp->dpp_onboard_ongoing);
#endif /* MAP_R3 */

		if (!wapp->wsc_configs_pending) {
			if (wapp->map && (wapp->map->quick_ch_change == TRUE || wapp->csa_notif_received != TRUE)) {
				wapp_send_1905_msg(wapp, WAPP_APCLI_ASSOC_STAT_CHANGE, sizeof(struct apcli_association_info),
						   (char *)&wapp->cli_assoc_info);
				map_update_bh_link_info(wapp, MAP_BH_WIFI, wapp->cli_assoc_info.apcli_assoc_state, ifindex);
				if (!wapp->map->bh_link_num) {
					wapp->map->bh_link_ready = 0;
					if (wapp->map->my_map_dev_role != DEVICE_ROLE_CONTROLLER)
						wapp->map->ctrler_found = 0;
				}
			} else {
				wapp->link_change_notif_pending = TRUE;
			}

			if (wapp->map && (wapp->map->TurnKeyEnable && apcli_stat_info->apcli_assoc_state == WAPP_APCLI_DISASSOCIATED)
#ifdef MAP_R3
				&& wapp->map->map_version == DEV_TYPE_R3
				&& (wapp->dpp && ((wapp->dpp_caused_disconnect == 1)
				|| (wapp->reconfigTrigger == TRUE)))
				&& (wapp->dpp->dpp_allowed_roles == DPP_CAPAB_ENROLLEE)
#endif
			) {
				eloop_cancel_timeout(map_config_state_check, wapp, NULL);
				if (wdev && wdev->dev_type == WAPP_DEV_TYPE_STA) {
#if WEXT_SUPPORT
					wapp_set_apcli_mode(wapp, (const char *)wdev->ifname, (char *)&Enable, 1);
#else
#ifdef MTK_HOSTAPD_SUPPORT
					if (wapp->drv_ops->drv_send_disable_network)
						wapp->drv_ops->drv_send_disable_network(wapp->drv_data, wdev->ifname, wdev->network_id);

#else
					char local_command[128];

					os_memset(local_command, 0, sizeof(local_command));

					ret = os_snprintf(local_command, sizeof(local_command), "mwctl %s set ApCliEnable=0", wdev->ifname);
					if (os_snprintf_error(sizeof(local_command), ret)) {
						err(DEBUG_CAT_MISC, "os_snprintf fail\n");
						return;
					}
					system(local_command);
#endif /* MTK_HOSTAPD_SUPPORT */
#endif
				}
			} else {
				for (i = 0; i < MAX_NUM_OF_RADIO; i++) {
					/* This command will go twice in case of single chip DBDC */
					if (wapp->radio[i].adpt_id) {
						char idfr[MAC_ADDR_LEN];
						struct wapp_radio *ra = &wapp->radio[i];
						MAP_GET_RADIO_IDNFER(ra, idfr);
						ap_wdev = wapp_dev_list_lookup_by_radio(wapp, idfr);
						if (!ap_wdev) {
							err(DEBUG_CAT_MISC, "null wdev\n");
							continue;
						}
#if WEXT_SUPPORT
						Enable = 1;
						wapp_set_APproxy_refresh(wapp, (const char *)wdev->ifname, (char *)&Enable, 1);
#else
						wdev_set_approxyrefresh(wapp, ap_wdev, 1);
#endif
					}
				}
			}
		} else {
			if (apcli_stat_info->apcli_assoc_state == WAPP_APCLI_DISASSOCIATED) {
				stop_con_cli_wps(wapp, NULL);
			}
		}
	}
}

void wdev_apcli_assoc_stat_change_handle_vendor10(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL, *ap_wdev;
	int i;

	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev)
		return;
	if (wdev->dev_type == WAPP_DEV_TYPE_STA) {
		// Send to other daemon
		struct apcli_association_info *apcli_stat_info = &wapp->cli_assoc_info;
		apcli_stat_info->interface_index = event_data->apcli_association_info.interface_index;
		apcli_stat_info->apcli_assoc_state = event_data->apcli_association_info.apcli_assoc_state;
		apcli_stat_info->current_channel = wdev->radio->op_ch;
		for (i = 0; i < MAX_NUM_OF_RADIO; i++) {
			/* This command will go twice in case of single chip DBDC */
			if (wapp->radio[i].adpt_id) {
				char idfr[MAC_ADDR_LEN];
				struct wapp_radio *ra = &wapp->radio[i];
#if WEXT_SUPPORT
				u8 disable = 0;
				u8 enable = 1;
#else
				/* char cmd[256] = {0}; */
				int ret = 0;
#endif /* WEXT_SUPPORT */

				MAP_GET_RADIO_IDNFER(ra, idfr);
				ap_wdev = wapp_dev_list_lookup_by_radio(wapp, idfr);
				if (!ap_wdev) {
					err(DEBUG_CAT_EVENT, "null wdev\n");
					continue;
				}
				if (wdev->radio->op_ch != ap_wdev->radio->op_ch)
					continue;

#if WEXT_SUPPORT
				if (event_data->apcli_association_info.apcli_assoc_state == WAPP_APCLI_DISASSOCIATED)
					wapp_set_v10converter(wapp, (const char *)ap_wdev->ifname, (char *)&disable, 1);
				else
					wapp_set_v10converter(wapp, (const char *)ap_wdev->ifname, (char *)&enable, 1);

#else
				if (event_data->apcli_association_info.apcli_assoc_state == WAPP_APCLI_DISASSOCIATED) {
					ret = wdev_set_v10converter(wapp, ap_wdev, 0);
					if (ret != 0) {
						err(DEBUG_CAT_EVENT, "wdev_set_v10converter fail\n");
						continue;
					}
				} else {
					ret = wdev_set_v10converter(wapp, ap_wdev, 1);
					if (ret != 0) {
						err(DEBUG_CAT_MISC, "wdev_set_v10converter fail\n");
						continue;
					}
				}
#endif /* WEXT_SUPPORT */
			}
		}
	}
}

#ifdef MAP_R2
void assoc_fail_count_timer(void *eloop_ctx, void *timeout_ctx)
{
	struct wifi_app *wapp = (struct wifi_app *)eloop_ctx;
	wapp->map->assoc_fail_rep_count = 0;
}
#endif

#ifdef MTK_HOSTAPD_SUPPORT
void hapd_wdev_sta_cnnct_rej_handle(struct wifi_app *wapp, u32 ifindex,  uint8_t *mac)
{
	struct wapp_dev *wdev = NULL;
	int send_pkt_len = 0;
	char *buf = NULL;

	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev)
		return;

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		struct sta_cnnct_rej_info sta_cnnct_rej_info;

		sta_cnnct_rej_info.interface_index = wdev->ifindex;
		os_memcpy(sta_cnnct_rej_info.sta_mac, mac, MAC_ADDR_LEN);
		os_memcpy(sta_cnnct_rej_info.bssid, wdev->mac_addr, MAC_ADDR_LEN);
		sta_cnnct_rej_info.cnnct_fail.connect_stage = WAPP_EAPOL;
		sta_cnnct_rej_info.cnnct_fail.reason = REASON_4_WAY_TIMEOUT;
#ifdef MAP_R2
		sta_cnnct_rej_info.assoc_status_code = 0;
		sta_cnnct_rej_info.assoc_reason_code = REASON_4_WAY_TIMEOUT;

		/* code to check */
		notice(DEBUG_CAT_MISC, "assoc_status_code = %d: %d\n", sta_cnnct_rej_info.assoc_status_code,
		       sta_cnnct_rej_info.assoc_reason_code);
		notice(DEBUG_CAT_MISC, "report_unsuccessful_association = %d\n",
		       wapp->map->assoc_failed_policy.report_unsuccessful_association);
		notice(DEBUG_CAT_MISC, "max_supporting_rate = %d\n", wapp->map->assoc_failed_policy.max_supporting_rate);

		wapp->map->assoc_fail_rep_count++;
		if (wapp->map->assoc_failed_policy.report_unsuccessful_association &&
		    (wapp->map->assoc_failed_policy.max_supporting_rate > wapp->map->assoc_fail_rep_count))
			sta_cnnct_rej_info.send_failed_assoc_frame = 1;
		else
			sta_cnnct_rej_info.send_failed_assoc_frame = 0;
		notice(DEBUG_CAT_MISC, "send_failed_assoc_frame = %d\n", sta_cnnct_rej_info.send_failed_assoc_frame);
#endif
		send_pkt_len = sizeof(struct sta_cnnct_rej_info);
		os_alloc_mem(NULL, (UCHAR **)&buf, send_pkt_len);
		if (buf) {
			os_memcpy(buf, &sta_cnnct_rej_info, send_pkt_len);
			wapp_send_1905_msg(wapp, WAPP_STA_CNNCT_REJ_INFO, send_pkt_len, buf);
			os_free(buf);
		}
	}
}
#endif
void wdev_sta_cnnct_rej_handle(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL;
	int send_pkt_len = 0;
	char *buf = NULL;

	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev)
		return;

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		struct sta_cnnct_rej_info sta_cnnct_rej_info;

		sta_cnnct_rej_info.interface_index = event_data->sta_cnnct_rej_info.interface_index;
		os_memcpy(sta_cnnct_rej_info.sta_mac, event_data->sta_cnnct_rej_info.sta_mac, MAC_ADDR_LEN);
		os_memcpy(sta_cnnct_rej_info.bssid, event_data->sta_cnnct_rej_info.bssid, MAC_ADDR_LEN);
		sta_cnnct_rej_info.cnnct_fail.connect_stage = event_data->sta_cnnct_rej_info.cnnct_fail.connect_stage;
		sta_cnnct_rej_info.cnnct_fail.reason = event_data->sta_cnnct_rej_info.cnnct_fail.reason;
#ifdef MAP_R2
		sta_cnnct_rej_info.assoc_status_code = event_data->sta_cnnct_rej_info.assoc_status_code;
		sta_cnnct_rej_info.assoc_reason_code = event_data->sta_cnnct_rej_info.assoc_reason_code;
#ifdef EM_PLUS_SUPPORT
		if ((os_strncmp(wdev->sec.auth, "WPA2PSK", 7) == 0)
			&& ((sta_cnnct_rej_info.cnnct_fail.reason == 15)
			&& (sta_cnnct_rej_info.assoc_status_code == 0))) {
			sta_cnnct_rej_info.assoc_reason_code = 14;
			sta_cnnct_rej_info.cnnct_fail.reason = 14;
		}

		if ((sta_cnnct_rej_info.assoc_status_code == 0)
			&& (sta_cnnct_rej_info.assoc_reason_code == 2
			|| sta_cnnct_rej_info.cnnct_fail.reason == 2)) {
			return;
		}
#endif /* EM_PLUS_SUPPORT */
		// code to check
		notice(DEBUG_CAT_MISC, "assoc_status_code = %d: %d\n", sta_cnnct_rej_info.assoc_status_code,
		       sta_cnnct_rej_info.assoc_reason_code);
		notice(DEBUG_CAT_MISC, "report_unsuccessful_association = %d\n",
		       wapp->map->assoc_failed_policy.report_unsuccessful_association);
		notice(DEBUG_CAT_MISC, "max_supporting_rate = %d\n", wapp->map->assoc_failed_policy.max_supporting_rate);

		wapp->map->assoc_fail_rep_count++;
		if (wapp->map->assoc_failed_policy.report_unsuccessful_association &&
		    (wapp->map->assoc_failed_policy.max_supporting_rate > wapp->map->assoc_fail_rep_count))
			sta_cnnct_rej_info.send_failed_assoc_frame = 1;
		else
			sta_cnnct_rej_info.send_failed_assoc_frame = 0;
		notice(DEBUG_CAT_MISC, "send_failed_assoc_frame = %d\n", sta_cnnct_rej_info.send_failed_assoc_frame);

		if (!eloop_is_timeout_registered(assoc_fail_count_timer, wapp, NULL)) {
			eloop_register_timeout(60, 0, assoc_fail_count_timer, wapp, NULL);
		}
#endif
		send_pkt_len = sizeof(struct sta_cnnct_rej_info);
		os_alloc_mem(NULL, (UCHAR **)&buf, send_pkt_len);
		if (buf) {
			os_memcpy(buf, &sta_cnnct_rej_info, send_pkt_len);
			wapp_send_1905_msg(wapp, WAPP_STA_CNNCT_REJ_INFO, send_pkt_len, buf);
			os_free(buf);
		}
	}
}

#define L1_PROFILE_PATH "/etc/wireless/l1profile.dat"
int wapp_read_l1_profile_file(char *ifname, int *radio_index, int *band_index)
{
	FILE *file;
	char buf[256], *pos, *token;
	char tmpbuf[256];
	char test_buf[256];
	int line = 0, i = 0;
	char ra_band_idx = 0;
	int ret = 0;

	file = fopen(L1_PROFILE_PATH, "r");
	if (!file) {
		err(DEBUG_CAT_MISC, TOPO_PREX "open l1 profile file (%s) fail\n", L1_PROFILE_PATH);
		return -1;
	}

	for (i = 0; i < 3; i++) {
		ret = os_snprintf(test_buf, sizeof(test_buf), "INDEX%d_apcli_ifname", i);
		if (os_snprintf_error(sizeof(test_buf), ret)) {
			err(DEBUG_CAT_MISC, "os_snprintf fail\n");
			continue;
		}
		line = 0;
		os_memset(buf, 0, 256);
		os_memset(tmpbuf, 0, 256);
		ra_band_idx = 0;
		while (wapp_config_get_line(buf, sizeof(buf), file, &line, &pos)) {
			ret = os_snprintf(tmpbuf, sizeof(tmpbuf), "%s", pos);
			if (os_snprintf_error(sizeof(tmpbuf), ret)) {
				err(DEBUG_CAT_MISC, "os_snprintf fail\n");
				continue;
			}
			token = strtok(pos, "=");
			if (token != NULL) {
				if (os_strcmp(token, test_buf) == 0) {
					token = strtok(NULL, ";");
					while (token != NULL && ra_band_idx < 2) {
						if (os_strcmp(token, ifname) == 0) {
							*radio_index = i;
							*band_index = ra_band_idx;
							ret = fclose(file);
							if (ret != 0) {
								err(DEBUG_CAT_MISC, "os_snprintf fail\n");
								return -1;
							}
							return 0;
						}
						ra_band_idx++;
						token = strtok(NULL, ";");
					}
				}
			}
		}
	}

	ret = fclose(file);
	if (ret != 0)
		err(DEBUG_CAT_MISC, "fclose fail\n");
	return -1;
}
#ifdef COSR_SUPPORT
int wapp_cosr_process_frames(struct wifi_app *wapp, struct wapp_dev *wdev, const u8 *src, const u8 *hdr,
							const u8 *buf, size_t len,  unsigned int chan, enum cosr_type type, char rssi)
{
	if (wapp == NULL || wdev == NULL ||
		src == NULL || hdr == NULL ||
		buf == NULL) {
		err(DEBUG_CAT_MISC, "Cosr Rx arg invalid\n");
		return WAPP_UNEXP;
	}

	if (wdev->wdev_cosr_support == FALSE) {
		err(DEBUG_CAT_MISC, "wdev doesn`t support cosr!\n");
		return WAPP_UNEXP;
	}

	 debug(DEBUG_CAT_MISC, "COSR: Rx frame subtype %d", type);

	switch (type) {
	case AIRTIME_SHARING_REQ:
			wapp_cosr_rx_airtime_req(wapp, wdev, src, buf, len, rssi);
		break;
	case AIRTIME_SHARING_RESP:
			wapp_cosr_rx_airtime_resp(wapp, wdev, src, buf, len, chan, rssi);
		break;
	case AIRMONITOR_REQ:
			cosr_receive_airmonitor_request(wapp, wdev, src, len, hdr);
		break;
	case AIRMONITOR_RESP:
			cosr_receive_airmonitor_response(wapp, wdev, src, len, hdr);
		break;
	default:
		err(DEBUG_CAT_MISC, "COSR: Ignored unsupported frame subtype %d", type);
		break;
	}

	return WAPP_SUCCESS;
}

void  wapp_cosr_rx_action(struct wifi_app *wapp, struct wapp_dev *wdev, const u8 *src,
			   const u8 *buf, size_t len, unsigned int chan, char rssi)
{
	enum cosr_type cosr_type;
	enum subcat_type subcat;
	const u8 *hdr, *wlan_hdr;
	u8 da[MAC_ADDR_LEN];

	if (len < COSR_LEN)
		return;

	wlan_hdr = buf;
	os_memcpy(da, &wlan_hdr[4], MAC_ADDR_LEN);
	/* skipping the wlan header part, category and pub action type*/
	buf += 24 + 2;
	len -= (24 - 2);
	if (WPA_GET_BE24(buf) != OUI_MTK)
		return;


	buf += 3;
	len -= 3;
	hdr = buf;
	hex_dump("Dump cosr public aciton frame", (u8 *)hdr, 32);

	subcat = *buf++;
	cosr_type = *buf++;
	len -= 2;

	 notice(DEBUG_CAT_MISC,
		   "COSR: Received COSR Public Action frame subcat %d type %d from "
		   MACSTR " chan=%u rssi=%d\n",
		   subcat, cosr_type, MAC2STR(src), chan, rssi);

	if (subcat == UNKNOWN_SUBCAT) {
		debug(DEBUG_CAT_MISC, "COSR: Unsupported subcat %d", subcat);
		return;
	}

	buf += 6;
	len -= 6;

	/* this function parse cosr frame*/
	wapp_cosr_process_frames(wapp, wdev, src, hdr, buf, len, chan, cosr_type, rssi);

}

void wdev_handle_cosr_action_frame(struct wifi_app *wapp, struct wapp_dev *wdev, struct wapp_cosr_action_frame *frame)
{
	if (wapp == NULL || wdev == NULL || frame == NULL) {
		err(DEBUG_CAT_MISC, "cosr is NULL\n");
		return;
	}
	wapp_cosr_rx_action(wapp, wdev, (u8 *)frame->target_bssid, frame->frm, frame->frm_len, frame->chan, frame->rssi);
}

void wdev_handle_cosr_sta_rssi_change(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (wdev == NULL)
		return;
	 debug(DEBUG_CAT_MISC, "MACAddress "MACSTR"\n",
			MAC2STR(event_data->sta_event.sta_mac));

	cosr_del_candlist_sta(wapp, wdev, event_data->cosr_frame.sta_mac);
}

void wdev_get_cosr_action_frame(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL;
	struct wapp_cosr_action_frame *cosr_frame = NULL;

	if (!wapp)
		return;
	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev || wdev->wdev_cosr_support == FALSE)
		return;
	if (!wdev->radio || !wdev->radio->radio_band)
		return;
	/* not in white list mode, shall update wdev to bcn ie wdev */
	if (wapp->cosr_ap_mode[*wdev->radio->radio_band] == TRUE) {
		if (wapp->cosr_bcn_ifindex[*wdev->radio->radio_band]) {
			wdev = wapp_dev_list_lookup_by_ifindex(wapp,
						wapp->cosr_bcn_ifindex[*wdev->radio->radio_band]);
			if (!wdev || wdev->wdev_cosr_support == FALSE)
				return;
		}
	}
	cosr_frame = &event_data->cosr_frame;
	if (!cosr_frame) {
		err(DEBUG_CAT_MISC, "cosr action frame pointer is null\n ");
		return;
	}
	if (!cosr_frame->frm_len ||
		cosr_frame->frm_len > (sizeof(*event_data) - offsetof(struct wapp_cosr_action_frame, frm))) {
		err(DEBUG_CAT_MISC,
				"cosr action frame frm_len:%d is invalid\n",
				cosr_frame->frm_len);
		return;
	}
	wdev_handle_cosr_action_frame(wapp, wdev, cosr_frame);

}

void wdev_handle_found_coap_event(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL;
	struct cosr_ap_candlist_ap *eAP = NULL;
	u8 peer_mac[MAC_ADDR_LEN];
	u8 count = 0, i = 0, retry_count = 5;
	u8 coap_status =  0;

	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev ||
		!wdev->radio ||
		!wdev->radio->radio_band)
		return;
	if (wapp->cosr_bcn_ifindex[*wdev->radio->radio_band]) {
		wdev = wapp_dev_list_lookup_by_ifindex(wapp,
					wapp->cosr_bcn_ifindex[*wdev->radio->radio_band]);
		if (!wdev || wdev->wdev_cosr_support == FALSE)
			return;
	}
	os_memcpy(peer_mac, event_data->cosr_frame.target_bssid, MAC_ADDR_LEN);
	eAP = cosr_ap_get_candlist_per_band(wapp, wdev, peer_mac);
	coap_status = cosr_ap_get_coorap_status_per_band(wapp, wdev, peer_mac);
	if (eAP)
		eAP->bcn_detect = TRUE;
	else
		err(DEBUG_CAT_MISC, "eAP is NULL "MACSTR" wdev %s\n",
			MAC2STR(peer_mac), wdev->ifname);

	if (wapp->cosr_ap_mode[*wdev->radio->radio_band] == FALSE) {
		if (eAP) {
			eAP->bcn_detect_cnt++;
			if (eAP->bcn_detect_cnt % 2 == 0)
				wapp_cosr_airtime_sharing_send_req(wapp, wdev,
					event_data->cosr_frame.target_bssid, AIRTIME_SHARING_REQ_SYNC);
		}
		return;
	}

	if (!eAP ||
		(eAP && ((coap_status & (AIRTIME_STATE_SHARED)) == 0))) {
		if (cosr_ap_candlist_ap_count_per_band(wapp, wdev) >= MAX_COSR_CO_AP_COUNT) {
			debug(DEBUG_CAT_MISC, "skip this event.\n");
			return;
		}
		if (cosr_ap_get_blacklist(wapp, peer_mac) == NULL) {
			count  = cosr_ap_candlist_ap_count_per_band(wapp, wdev);
			notice(DEBUG_CAT_MISC, "Now Candlist ap count is %d\n", count);
			cosr_set_apinfo(wapp, wdev, peer_mac, coap_status);
			/*
			 * coap status if its already in SHARED state,
			 * no need to send airtime sharing again
			 */
			/* according mac to setting coorap status */
			for (i = 0; i < retry_count; i++) {
				if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
					wapp_cosr_airtime_sharing_send_req(wapp, wdev,
						event_data->cosr_frame.target_bssid, AIRTIME_SHARING_REQ_REQ);
				}
			}
			wapp->found_coap = TRUE;

		} else {
			err(DEBUG_CAT_MISC, "Cosr ap "MACSTR" in cand blacklist.\n", MAC2STR(peer_mac));
			return;
		}

		/*Todo Recived FW abort Message to Send airtime sharing abort */
	} else if (eAP) {
		notice(DEBUG_CAT_MISC, "Candlist ap device: "MACSTR" exist, Beacon Detect Count %d\n",
			MAC2STR(peer_mac), eAP->bcn_detect_cnt);
		eAP->bcn_detect_cnt++;
		/* AP shall send airtime request periodically to prevent neighbor AP reset */
		if (eAP->bcn_detect_cnt == 2) {
			if (cosr_ap_get_blacklist(wapp, peer_mac) == NULL) {
				wapp_cosr_airtime_sharing_send_req(wapp, wdev,
							event_data->cosr_frame.target_bssid, AIRTIME_SHARING_REQ_REQ);
			}
			eAP->bcn_detect_cnt = 0;
		}
	}

}

#endif /*COSR_SUPPORT*/

#ifdef DPP_SUPPORT
struct wapp_dev *wapp_dev_list_lookup_by_radio_and_type(struct wifi_app *wapp, char *ra_identifier, const u8 wdev_type)
{
	struct wapp_dev *wdev, *target_wdev = NULL, *wdev_temp = NULL;
	unsigned char wdev_identifier[ETH_ALEN];
	struct dl_list *dev_list;

	dev_list = &wapp->dev_list;

	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list)
	{
		if (wdev->radio) {
			MAP_GET_RADIO_IDNFER(wdev->radio, wdev_identifier);
			if (!os_memcmp(wdev_identifier, ra_identifier, ETH_ALEN) && (wdev->dev_type == wdev_type)) {
				target_wdev = wdev;
				break;
			}
		}
	}

	return target_wdev;
}

void wdev_get_dpp_action_frame(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL;
	char dpp_frame_event[2048] = {0};
	int frame_len = 2048;
	u32 frm_id;

	if (!wapp)
		return;
	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev)
		return;

	frm_id = event_data->wapp_dpp_frame_id_no;
	os_memcpy(dpp_frame_event, (char *)&(frm_id), sizeof(u32));
	debug(DEBUG_CAT_DPP, "frame id number = %d\n", frm_id);
	wapp_get_dpp_frame(wapp, wdev->ifname, dpp_frame_event, frame_len);
	wdev_handle_dpp_action_frame(wapp, wdev, (struct wapp_dpp_action_frame *)dpp_frame_event);
}

void wdev_handle_dpp_action_frame(struct wifi_app *wapp, struct wapp_dev *wdev, struct wapp_dpp_action_frame *frame)
{
	if (!wapp->dpp) {
		err(DEBUG_CAT_DPP, "DPP is NULL\n");
		return;
	}
#ifdef MAP_R3
	if (wapp->map && (wapp->map->map_version == 3) && (wapp->dpp->dpp_allowed_roles == DPP_CAPAB_ENROLLEE) &&
	    wapp->dpp->dpp_eth_conn_ind) {
		err(DEBUG_CAT_DPP, "Ignore wifi action frames as ETH is connected\n");
		return;
	}
#endif /* MAP_R3 */
	if (frame->is_gas) {
		if (wapp->dpp->dpp_configurator_supported
#if defined(MAP_R3) || defined(EM_PLUS_SUPPORT)
		    || (wapp->dpp->is_map && (wapp->dpp->dpp_allowed_roles == DPP_CAPAB_PROXYAGENT))
#endif /* MAP_R3 || EM_PLUS_SUPPORT */
		)
			gas_server_rx(wapp->dpp->gas_server, wdev, wdev->mac_addr, (u8 *)frame->src, wdev->mac_addr, 10, frame->frm,
				      frame->frm_len, frame->chan);
		else
			gas_query_rx(wapp->dpp->gas_query_ctx, wdev->mac_addr, (u8 *)frame->src, (u8 *)frame->src, 10, frame->frm,
				     frame->frm_len, frame->chan);

	} else
		wapp_dpp_rx_action(wapp, wdev, (u8 *)frame->src, frame->frm, frame->frm_len - 4, frame->chan);
}

void wdev_handle_dpp_frm_tx_status(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct dpp_tx_status *tx_status = wapp_dpp_get_status_info_from_sq(wapp, event_data->tx_status.seq_no);

	if (!tx_status) {
		err(DEBUG_CAT_DPP, "failed to get status for sq=%u\n", event_data->tx_status.seq_no);
		return;
	}
	if (tx_status->is_gas_frame) {
		if (wapp->dpp->dpp_configurator_supported)
			gas_server_tx_status(wapp->dpp->gas_server, tx_status->dst, NULL, 0, event_data->tx_status.tx_success ? 0 : 1);
		else
			gas_query_tx_status(wapp, 0, tx_status->dst, NULL, NULL, NULL, 0, event_data->tx_status.tx_success ? 0 : 1);
	} else
		wapp_dpp_tx_status(wapp, tx_status->dst, NULL, 0, event_data->tx_status.tx_success ? 0 : 1);
}
#endif /*DPP_SUPPORT*/

#ifdef MAP_R3
void wdev_handle_dpp_sta_info(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	char buf[2048] = {0};
	char *hex_pmk = NULL;
	char *hex_ptk = NULL;
	size_t len1 = event_data->sta_info.pmk_len * 2 + 1;
	size_t len2 = event_data->sta_info.ptk_len * 2 + 1;
	//char hex_pmk[event_data->sta_info.pmk_len * 2 + 1];
	//char hex_ptk[event_data->sta_info.ptk_len * 2 + 1];
	int ret = 0;

	if (len1 > 0) {
		hex_pmk = os_zalloc(event_data->sta_info.pmk_len * 2 + 1);
		if (hex_pmk == NULL) {
			os_free(hex_pmk);
			return;
		}
	}

	if (len2 > 0) {
		hex_ptk = os_zalloc(event_data->sta_info.ptk_len * 2 + 1);
		if (hex_ptk == NULL) {
			os_free(hex_pmk);
			os_free(hex_ptk);
			return;
		}
	}

#if defined(MAP_R6) && defined(MTK_HOSTAPD_SUPPORT)
	int res = 0;
	struct wapp_dev *wdev = NULL;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev || !wapp) {
		err(DEBUG_CAT_DPP, "valid wdev not found..\n");
		os_free(hex_pmk);
		os_free(hex_ptk);
		return;
	}
#endif
#ifdef MAP_R3_RECONFIG
#ifndef MAP_R6
	if (wapp->reconfigTrigger == TRUE) {
#endif
		ret = remove("/etc/dpp_cfg_test.txt");
		if (ret != 0) {
			debug(DEBUG_CAT_DPP, "remove dpp_cfg_test.txt failed!\n");
			os_free(hex_pmk);
			os_free(hex_ptk);
			return;
		}
#ifndef MAP_R6
		wapp->reconfigTrigger = FALSE;
	}
#endif
#endif
	ret = os_snprintf(buf, sizeof(buf), "%02x:%02x:%02x:%02x:%02x:%02x_SSID %s\n", PRINT_MAC(event_data->sta_info.src),
		    event_data->sta_info.ssid);
	if (os_snprintf_error(sizeof(buf), ret)) {
		err(DEBUG_CAT_DPP, "os_snprintf fail\n");
		os_free(hex_pmk);
		os_free(hex_ptk);
		return;
	}
	wpa_write_config_file(DPP_CFG_FILE_TEST, buf, strlen(buf));
	os_memset(buf, 0, 2048);
	ret = os_snprintf(buf, sizeof(buf), "%02x:%02x:%02x:%02x:%02x:%02x_passphrase %s\n", PRINT_MAC(event_data->sta_info.src),
		    event_data->sta_info.passphrase);
	if (os_snprintf_error(sizeof(buf), ret)) {
		err(DEBUG_CAT_DPP, "os_snprintf fail\n");
		os_free(hex_pmk);
		os_free(hex_ptk);
		return;
	}
	wpa_write_config_file(DPP_CFG_FILE_TEST, buf, strlen(buf));
	/*get pmk from hostapd via wpactrl*/
	os_memset(buf, 0, 2048);
#if defined(MAP_R6) && defined(MTK_HOSTAPD_SUPPORT)
	if (wdev) {
		os_memset(wdev->pmk, 0, 66);
		res = wdev_send_get_pmk(wapp, wdev, event_data->sta_info.src, wdev->pmk);
		if (!res) {
			os_snprintf_hex(hex_pmk, len1, (const u8 *)wdev->pmk, event_data->sta_info.pmk_len);
			ret = os_snprintf(buf, sizeof(buf), "%02x:%02x:%02x:%02x:%02x:%02x_PMK %s\n",
					PRINT_MAC(event_data->sta_info.src), wdev->pmk);
				if (os_snprintf_error(sizeof(buf), ret)) {
					err(DEBUG_CAT_MISC, "os_snprintf fail\n");
					os_free(hex_pmk);
					os_free(hex_ptk);
					return;
				}
			}
		}
#else
	os_snprintf_hex(hex_pmk, len2, event_data->sta_info.pmk, event_data->sta_info.pmk_len);
	ret = os_snprintf(buf, sizeof(buf), "%02x:%02x:%02x:%02x:%02x:%02x_PMK %s\n", PRINT_MAC(event_data->sta_info.src), hex_pmk);
	if (os_snprintf_error(sizeof(buf), ret)) {
		err(DEBUG_CAT_DPP, "os_snprintf fail\n");
		os_free(hex_pmk);
		os_free(hex_ptk);
		return;
	}
#endif
	wpa_write_config_file(DPP_CFG_FILE_TEST, buf, strlen(buf));
	os_memset(buf, 0, 2048);
	os_snprintf_hex(hex_ptk, len2, event_data->sta_info.ptk, event_data->sta_info.ptk_len);
	ret = os_snprintf(buf, sizeof(buf), "%02x:%02x:%02x:%02x:%02x:%02x_PTK %s\n", PRINT_MAC(event_data->sta_info.src), hex_ptk);
	if (os_snprintf_error(sizeof(buf), ret)) {
		err(DEBUG_CAT_DPP, "os_snprintf fail\n");
		os_free(hex_pmk);
		os_free(hex_ptk);
		return;
	}
	os_free(hex_pmk);
	os_free(hex_ptk);
	wpa_write_config_file(DPP_CFG_FILE_TEST, buf, strlen(buf));
}

void wdev_handle_dpp_uri_info(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL;
	int peer_bi_id = 0;
	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);

	if (!wdev || !wapp || !wapp->dpp) {
		err(DEBUG_CAT_DPP, "valid wdev not found..\n");
		return;
	}

	if ((wapp->map->map_version == DEV_TYPE_R3) && (wapp->dpp->onboarding_type != 0)) {
		err(DEBUG_CAT_DPP, "invalid map version or onboarding type..\n");
		return;
	}

	notice(DEBUG_CAT_DPP, DPP_MAP_PREX "Sta_MAC:" MACSTR "for wdev:%s uri:%s len:%u\n", PRINT_MAC(event_data->uri_info.src_mac),
		 wdev->ifname, event_data->uri_info.rcvd_uri, event_data->uri_info.uri_len);

	if (wapp->dpp->dpp_allowed_roles == DPP_CAPAB_CONFIGURATOR) {
		peer_bi_id = wapp_dpp_qr_code(wapp, (const char *)event_data->uri_info.rcvd_uri);
		if (peer_bi_id == 0) {
			err(DEBUG_CAT_DPP, "invalid bi id..\n");
			return;
		}
	}

	if ((wapp->dpp->dpp_allowed_roles == DPP_CAPAB_PROXYAGENT) && (wapp->dpp->map_sec_done == TRUE)) {
		dpp_URI_1905_send(wapp, NULL, wdev, (unsigned char *)event_data->uri_info.src_mac,
				  (unsigned short)event_data->uri_info.uri_len, (unsigned char *)event_data->uri_info.rcvd_uri);
	} else {
		err(DEBUG_CAT_DPP, "1905 security is not enabled.\n");
	}
}
#endif /* MAP_R3 */

void wdev_handle_wsc_eapol_notif(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL;
	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	stop_con_ap_wps(wapp, wdev);
}

void wdev_handle_wsc_eapol_end_notif(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL;
	int send_pkt_len = 0;
	char *buf = NULL;
	struct wapp_bhsta_info *bhsta_info;

	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev)
		return;

	wapp_device_status *device_status = &wapp->map->device_status;
	device_status->status_fhbss = STATUS_FHBSS_WPS_SUCCESSFULL;
#ifndef MTK_HOSTAPD_SUPPORT
	eloop_cancel_timeout(map_wps_timeout, wapp, device_status);
#endif

	if (event_data != NULL) {
		bhsta_info = (struct wapp_bhsta_info *)event_data;
		send_pkt_len = sizeof(struct wapp_bhsta_info);

		notice(DEBUG_CAT_WIFI_CONFIG, "connected_bssid: "MACSTR"\n", MAC2STR(bhsta_info->connected_bssid));
		notice(DEBUG_CAT_WIFI_CONFIG, "mac_addr: "MACSTR"\n", MAC2STR(bhsta_info->mac_addr));
		notice(DEBUG_CAT_WIFI_CONFIG, "peer_map_enable: %d, send_pkt_len %d\n", bhsta_info->peer_map_enable, send_pkt_len);

		os_alloc_mem(NULL, (UCHAR **)&buf, send_pkt_len);

		if (buf) {
			os_memcpy(buf, bhsta_info, send_pkt_len);
			if (wapp_send_1905_msg(wapp, WAPP_MAP_AGENT_WPS_SUCCESS, send_pkt_len, buf) < 0)
				err(DEBUG_CAT_WIFI_CONFIG, "wapp_send_1905_msg failed\n");
			os_free(buf);
		} else
			err(DEBUG_CAT_WIFI_CONFIG, "buf alloc failed\n");
	}

	wapp_send_1905_msg(wapp, WAPP_DEVICE_STATUS, sizeof(wapp_device_status), (char *)device_status);
}

void wdev_handle_scan_complete_notif(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev)
		return;

	/*Ignore! if scan is not triggered by wapp*/
	if (!wdev->wapp_triggered_scan) {
		return;
	}
	wdev->wapp_triggered_scan = FALSE;
	map_get_scan_result(wapp, wdev);
}

int wdev_enable_pmf(struct wifi_app *wapp, struct wapp_dev *wdev, BOOLEAN enable)
{
	int ret = 0;

	debug(DEBUG_CAT_WIFI_CONFIG, "pmf = %d\n", enable);

	if (!wapp || !wdev) {
		err(DEBUG_CAT_WIFI_CONFIG, "wapp or wdev is null\n");
		return -1;
	}

#ifdef MTK_HOSTAPD_SUPPORT
	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
#ifdef MAP_6E_SUPPORT
		if (wdev->radio && IS_OP_CLASS_6G(wdev->radio->opclass))
			/* For 6G wdev, PMF support should be mandatory */
			ret = wapp_set_pmfmfpc(wapp, wdev->ifname, enable ? "2" : "0", 1);
		else
#endif /* MAP_6E_SUPPORT */
			ret = wapp_set_pmfmfpc(wapp, wdev->ifname, enable ? "1" : "0", 1);
	} else {
#ifdef MAP_6E_SUPPORT
		if (wdev->radio && IS_OP_CLASS_6G(wdev->radio->opclass))
			/* For 6G wdev, PMF support should be mandatory */
			ret = wapp_set_apcli_PMFMFPC(wapp, wdev->ifname, wdev->network_id,
					enable ? "2" : "0", 1);
		else
#endif /* MAP_6E_SUPPORT */
			ret = wapp_set_apcli_PMFMFPC(wapp, wdev->ifname, wdev->network_id,
					enable ? "1" : "0", 1);
	}

	if (ret)
		err(DEBUG_CAT_MISC, "fail (%d)\n", -ret);
#else /* !MTK_HOSTAPD_SUPPORT */
	char cmd[100];

	os_memset(cmd, 0, 100);
	if (wdev->dev_type == WAPP_DEV_TYPE_AP)
		ret = os_snprintf(cmd, sizeof(cmd), "mwctl %s set PMFMFPC=%d", wdev->ifname, enable);
	else
		ret = os_snprintf(cmd, sizeof(cmd), "mwctl %s set ApCliPMFMFPC=%d", wdev->ifname, enable);

	if (os_snprintf_error(sizeof(cmd), ret)) {
		err(DEBUG_CAT_MISC, "os_snprintf fail\n");
		return -1;
	}

	ret = system(cmd);
	if (ret)
		err(DEBUG_CAT_WIFI_CONFIG, "system() call return value is -1\n");
	 debug(DEBUG_CAT_MISC, "%s\n", cmd);
#endif /* !MTK_HOSTAPD_SUPPORT */
	return ret;
}

void wdev_bh_sta_reset_default(struct wifi_app *wapp, struct wapp_dev *wdev)
{
	if (!wapp)
		return;

#ifndef MTK_HOSTAPD_SUPPORT
	int ret = 0;
#endif /* MTK_HOSTAPD_SUPPORT */

#if WEXT_SUPPORT
	u8 Enable = 0;
	wapp_set_apcli_mode(wapp, (const char *)wdev->ifname, (char *)&Enable, 1);
	wapp_set_apcli_ssid(wapp, (const char *)wdev->ifname, (char *)"MAP_APCLI_UNCONF", 16);
	wapp_set_apcli_wpapsk(wapp, (const char *)wdev->ifname, (char *)"12345678", 8);
	wapp_set_authtype(wapp, (const char *)wdev->ifname, "OPEN", 4);
	wdev_enable_pmf(wapp, wdev, FALSE);
	wapp_set_apcli_EncrypType(wapp, (const char *)wdev->ifname, (char *)"NONE", 4);
#else
#ifdef MTK_HOSTAPD_SUPPORT
	if (wapp->drv_ops->drv_send_remove_network)
		wapp->drv_ops->drv_send_remove_network(wapp->drv_data, wdev->ifname);
#else
	char cmd[100];

	memset(cmd, 0, 100);
	ret = os_snprintf(cmd, sizeof(cmd), "mwctl %s set ApCliEnable=0;", wdev->ifname);
	if (os_snprintf_error(sizeof(cmd), ret)) {
		err(DEBUG_CAT_MISC, "os_snprintf fail\n");
		return;
	}
	if (system(cmd) == -1)
		err(DEBUG_CAT_MISC, "system() call return value is -1\n");

	memset(cmd, 0, 100);
	ret = snprintf(cmd, sizeof(cmd), "mwctl %s set ApCliSsid=MAP_APCLI_UNCONF", wdev->ifname);
	if (os_snprintf_error(sizeof(cmd), ret)) {
		err(DEBUG_CAT_MISC, "os_snprintf fail\n");
		return;
	}
	notice(DEBUG_CAT_MISC, "<CMD:%s>\n", cmd);
	if (system(cmd) == -1)
		err(DEBUG_CAT_MISC, "system() call return value is -1\n");

	memset(cmd, 0, 100);
	ret = snprintf(cmd, sizeof(cmd), "mwctl %s set ApCliWPAPSK=12345678", wdev->ifname);
	if (os_snprintf_error(sizeof(cmd), ret)) {
		err(DEBUG_CAT_MISC, "os_snprintf fail\n");
		return;
	}
	if (system(cmd) == -1)
		err(DEBUG_CAT_MISC, "system() call return value is -1\n");

	memset(cmd, 0, 100);
	ret = snprintf(cmd, sizeof(cmd), "mwctl %s set ApCliAuthMode=OPEN", wdev->ifname);
	notice(DEBUG_CAT_MISC, "<CMD:%s>\n", cmd);
	if (os_snprintf_error(sizeof(cmd), ret)) {
		err(DEBUG_CAT_MISC, "os_snprintf fail\n");
		return;
	}
	if (system(cmd) == -1)
		err(DEBUG_CAT_MISC, "system() call return value is -1\n");

	wdev_enable_pmf(wapp, wdev, FALSE);

	memset(cmd, 0, 100);
	ret = snprintf(cmd, sizeof(cmd), "mwctl %s set ApCliEncrypType=NONE", wdev->ifname);
	if (os_snprintf_error(sizeof(cmd), ret)) {
		err(DEBUG_CAT_MISC, "os_snprintf fail\n");
		return;
	}
	if (system(cmd) == -1)
		err(DEBUG_CAT_MISC, "system() call return value is -1\n");
	notice(DEBUG_CAT_MISC, "<CMD:%s>\n", cmd);
#endif /* MTK_HOSTAPD_SUPPORT */
#endif /* WEXT_SUPPORT */
	return;
}

#ifdef MAP_R2
void wdev_bh_sta_connect_wsc_profile(struct wifi_app *wapp, struct wapp_dev *wdev, wsc_apcli_config *cli_conf)
{
	char *auth_str[] = {"OPEN", "WPAPSK", "SHARED", "WPA", "WPA2", "WPA2PSK", "WPA2PSKWPA3PSK"};
	char *encryp_str[] = {
		"NONE",
		"WEP",
		"TKIP",
		"AES",
	};
	int i = 0, j = 0;
	unsigned short authmode = cli_conf->AuthType;
	unsigned short encryptype = cli_conf->EncrType;
#if WEXT_SUPPORT
	u8 Enable = 0;
#else
	char cmd[200];
	int ret = 0;
#endif

	if (!wapp)
		return;

	if (cli_conf->SsidLen <= MAX_LEN_OF_SSID)
		cli_conf->ssid[cli_conf->SsidLen] = '\0';
	else
		cli_conf->ssid[MAX_LEN_OF_SSID] = '\0';

	if (cli_conf->KeyLength) {
		if (cli_conf->KeyLength < 64)
			cli_conf->Key[cli_conf->KeyLength] = '\0';
		else
			cli_conf->Key[63] = '\0';
	}

#if WEXT_SUPPORT
	wapp_set_apcli_mode(wapp, (const char *)wdev->ifname, (char *)&Enable, 1);
	wapp_set_apcli_ssid(wapp, (const char *)wdev->ifname, (char *)cli_conf->ssid, cli_conf->SsidLen);
	wapp_set_apcli_wpapsk(wapp, (const char *)wdev->ifname, (char *)cli_conf->Key, cli_conf->KeyLength);
#else

	memset(cmd, 0, 200);
#ifdef MTK_HOSTAPD_SUPPORT
	if (wapp->drv_ops->drv_send_disable_network)
		wapp->drv_ops->drv_send_disable_network(wapp->drv_data, wdev->ifname, wdev->network_id);

#else
	ret = os_snprintf(cmd, sizeof(cmd), "mwctl %s set ApCliEnable=0;", wdev->ifname);
#endif /* MTK_HOSTAPD_SUPPORT */
	if (os_snprintf_error(sizeof(cmd), ret)) {
		err(DEBUG_CAT_MISC, "os_snprintf fail\n");
		return;
	}
	notice(DEBUG_CAT_MISC, "<CMD:%s>\n", cmd);
	if (system(cmd) == -1)
		err(DEBUG_CAT_MISC, "system() call return value is -1\n");

	memset(cmd, 0, 200);
	ret = os_snprintf(cmd, sizeof(cmd), "mwctl %s set ApCliSsid=%s", wdev->ifname, cli_conf->ssid);
	if (os_snprintf_error(sizeof(cmd), ret)) {
		err(DEBUG_CAT_MISC, "os_snprintf fail\n");
		return;
	}
	if (system(cmd) == -1)
		err(DEBUG_CAT_MISC, "system() call return value is -1\n");
	notice(DEBUG_CAT_MISC, "<%s>\n", cmd);

	/* this validation is invalid in case of WPA2+WPA */
	if ((authmode < WSC_AUTHTYPE_OPEN || authmode > (WSC_AUTHTYPE_WPA2PSK | WSC_AUTHTYPE_SAE)) ||
	    (encryptype < WSC_ENCRTYPE_NONE || encryptype > WSC_ENCRTYPE_AES)) {
		err(DEBUG_CAT_MISC, "invalid sec_info auth=%d enc=%d\n", authmode, encryptype);
		return;
	}

	memset(cmd, 0, 200);
	ret = os_snprintf(cmd, sizeof(cmd), "mwctl %s set ApCliWPAPSK=%s", wdev->ifname, cli_conf->Key);
	if (os_snprintf_error(sizeof(cmd), ret)) {
		err(DEBUG_CAT_MISC, "os_snprintf fail\n");
		return;
	}
	if (system(cmd) == -1)
		err(DEBUG_CAT_MISC, "system() call return value is -1\n");
#endif
#ifdef MAP_R2
	/* Make it mixed mode */
	if (wapp->map->map_version == DEV_TYPE_R2 && authmode == WSC_AUTHTYPE_WPA2PSK)
		authmode = authmode << 1;
#endif
	notice(DEBUG_CAT_MISC, "setting wpa3\n");
	while (authmode) {
		authmode = authmode >> 1;
		i++;
	}
	i--;
#if WEXT_SUPPORT
	wapp_set_authtype(wapp, (const char *)wdev->ifname, (char *)auth_str[i], strlen(auth_str[i]));
#else
	memset(cmd, 0, 200);
	if (i >= 0 && i < ARRAY_SIZE(auth_str) && auth_str[i] != NULL) {
		ret = os_snprintf(cmd, sizeof(cmd), "mwctl %s set ApCliAuthMode=%s", wdev->ifname, auth_str[i]);
		if (os_snprintf_error(sizeof(cmd), ret)) {
			err(DEBUG_CAT_MISC, "os_snprintf fail\n");
			return;
		}
		notice(DEBUG_CAT_MISC, "<CMD:%s>\n", cmd);
		if (system(cmd) == -1)
			err(DEBUG_CAT_MISC, "system() call return value is -1\n");
	}
#endif
	if (i < ARRAY_SIZE(auth_str) && auth_str[i] != NULL) {
		if (strcmp(auth_str[i], "WPA2PSKWPA3PSK") == 0)
			wdev_enable_pmf(wapp, wdev, TRUE);
	}

	while (encryptype) {
		encryptype = encryptype >> 1;
		j++;
	}
	j--;

#if WEXT_SUPPORT
	wapp_set_apcli_EncrypType(wapp, (const char *)wdev->ifname, (char *)encryp_str[j], strlen(encryp_str[j]));
	Enable = 1;
	wapp_set_apcli_mode(wapp, (const char *)wdev->ifname, (char *)&Enable, 1);
#else
	memset(cmd, 0, 200);
	if (j >= 0 && j < ARRAY_SIZE(encryp_str) && encryp_str[j] != NULL) {
		ret = os_snprintf(cmd, sizeof(cmd), "mwctl %s set ApCliEncrypType=%s", wdev->ifname, encryp_str[j]);
		if (os_snprintf_error(sizeof(cmd), ret)) {
			err(DEBUG_CAT_MISC, "os_snprintf fail\n");
			return;
		}
		if (system(cmd) == -1)
			err(DEBUG_CAT_MISC, "system() call return value is -1\n");
	}
	memset(cmd, 0, 200);
#ifdef MTK_HOSTAPD_SUPPORT
	if (wapp->drv_ops->drv_send_enable_network)
		wapp->drv_ops->drv_send_enable_network(wapp->drv_data, wdev->ifname, wdev->network_id);
#else
	ret = os_snprintf(cmd, sizeof(cmd), "mwctl %s set ApCliEnable=1;", wdev->ifname);
#endif /* MTK_HOSTAPD_SUPPORT */
	if (os_snprintf_error(sizeof(cmd), ret)) {
		err(DEBUG_CAT_MISC, "os_snprintf fail\n");
		return;
	}
	if (system(cmd) == -1)
		err(DEBUG_CAT_MISC, "system() call return value is -1\n");
#endif
	return;
}
#endif

#ifndef MTK_MLO_MAP_SUPPORT
void wdev_handle_wsc_config_write(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL;
	int send_pkt_len = 0;
	wsc_apcli_config_msg *apcli_config_msg;
	char wsc_profile_buffer[512] = {0};
	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev)
		return;
	/* send cmd here to fill up the wsc profile credentials from driver */
	wapp_get_wsc_profiles(wapp, wdev->ifname, wsc_profile_buffer, &send_pkt_len);
	apcli_config_msg = (wsc_apcli_config_msg *)wsc_profile_buffer;
	notice(DEBUG_CAT_MISC, "In WAPP , profile count is %d ,send_pkt_len %d\n", apcli_config_msg->profile_count, send_pkt_len);
#ifdef MAP_R3
	/* Storing the WSC profile count for decision regarding
	 * WSC or DPP onboarding while configuring BSS's */
	if (wapp->dpp) {
		wapp->dpp->wsc_profile_cnt = apcli_config_msg->profile_count;
		if (wapp->map && (wapp->map->map_version == DEV_TYPE_R3) && (wapp->dpp->onboarding_type == 0) &&
		    (apcli_config_msg->profile_count == 0)) {
			/* In MAP-R3 DPP case if no credentials found
			 * in M8 then trigger Chirping */
			wapp->wsc_configs_pending = FALSE;
			wapp->dpp->annouce_enrolle.is_enable = 1;
			wapp_dpp_presence_annouce(wapp, NULL);
			return;
		}
	}
#endif /* MAP_R3 */
	if (wapp->wsc_save_bh_profile == TRUE) {
		write_configs(wapp, apcli_config_msg->apcli_config, 0, NULL);
		wapp->wsc_save_bh_profile = FALSE;
	}
	if (wapp->wps_on_controller_cli == 1) {
		write_configs(wapp, apcli_config_msg->apcli_config, 0, NULL);
		wapp->wps_on_controller_cli = 0;
	}
	wapp->wsc_configs_pending = FALSE;
	if (wapp->map && wapp->map->TurnKeyEnable)
		wapp_send_1905_msg(wapp, WAPP_MAP_BH_CONFIG, send_pkt_len, (char *)apcli_config_msg);
#ifdef MAP_R2
	else {
		/*4.14.2_BH5GL_FH24G: we have received WPS profiles from driver. Need to trigger connection on the bh_sta configured.*/
		if (!wapp->map) {
			err(DEBUG_CAT_WIFI_CONFIG, "wap->map found NULL\n");
			return;
		}

		struct wapp_dev *bsta_wdev = wapp->map->bh_wifi_dev;
		notice(DEBUG_CAT_WIFI_CONFIG, "<ProfileSSID: %s>\n", apcli_config_msg->apcli_config[0].ssid);
		if (bsta_wdev == NULL || apcli_config_msg->profile_count == 0)
			return;
		// Stop WPS on APCLI interface

		notice(DEBUG_CAT_WIFI_CONFIG, "Calling WSC stop\n");
#if WEXT_SUPPORT
		u8 enable = 1;
		wapp_set_wsc_stop(wapp, (const char *)wdev->ifname, (char *)&enable, 1);
#else
		char cmd[100];
		int ret = 0;

		os_memset(cmd, 0, sizeof(cmd));
		 ret = os_snprintf(cmd, sizeof(cmd), "mwctl %s set WscStop=1;", wdev->ifname);
		if (os_snprintf_error(sizeof(cmd), ret)) {
			err(DEBUG_CAT_WIFI_CONFIG, "os_snprintf fail\n");
			return;
		}
		if (system(cmd) == -1)
			err(DEBUG_CAT_WIFI_CONFIG, "system() call return value is -1\n");
#endif
		// TODO: what if channel of the BSS is different.
		/*Only trigger connection on the bh_wdev configured through the command.*/
		wdev_bh_sta_connect_wsc_profile(wapp, bsta_wdev, &apcli_config_msg->apcli_config[0]);
		/*Disable APCLI on other interfaces*/
		{
			struct wapp_dev *tmp_wdev;
			struct dl_list *dev_list;

			dev_list = &wapp->dev_list;

			dl_list_for_each(tmp_wdev, dev_list, struct wapp_dev, list)
			{
				if (tmp_wdev->dev_type == WAPP_DEV_TYPE_STA && tmp_wdev != bsta_wdev) {
#if WEXT_SUPPORT
					u8 Enable = 0;
					wapp_set_apcli_mode(wapp, (const char *)wdev->ifname, (char *)&Enable, 1);
#else
#ifdef MTK_HOSTAPD_SUPPORT
					if (wapp->drv_ops->drv_send_disable_network)
						wapp->drv_ops->drv_send_disable_network(wapp->drv_data, wdev->ifname, wdev->network_id);

#else
					memset(cmd, 0, 100);
					ret = os_snprintf(cmd, sizeof(cmd), "mwctl %s set ApCliEnable=0;", tmp_wdev->ifname);
					if (os_snprintf_error(sizeof(cmd), ret)) {
						err(DEBUG_CAT_MISC, "os_snprintf fail\n");
						return;
					}
					if (system(cmd) == -1)
						err(DEBUG_CAT_MISC, "system() call fail\n");
#endif /* MTK_HOSTAPD_SUPPORT */
#endif
				}
			}
		}
	}
#endif
}
#endif

void wdev_handle_map_vend_ie_evt(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL;
	int send_pkt_len = 0;
	char *buf = NULL;
	struct map_vendor_ie *map_ie;

	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev)
		return;

	map_ie = (struct map_vendor_ie *)event_data;
	send_pkt_len = sizeof(struct map_vendor_ie);
	os_alloc_mem(NULL, (UCHAR **)&buf, send_pkt_len);
	os_memcpy(buf, map_ie, send_pkt_len);
	wapp_send_1905_msg(wapp, WAPP_MAP_VEND_IE_CHANGED, send_pkt_len, buf);
	os_free(buf);
}

void wdev_handle_a4_entry_missing_notif(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	uint32_t dstip = (uint32_t)event_data->a4_missing_entry_ip;

	if (dstip == 0 || dstip == 0xffffffff) {
		err(DEBUG_CAT_MISC, "Invalid source IP\n");
		return;
	}

	test_arping(wapp->map->br.arp_sock, wapp->map->br.ifindex, wapp->map->br.mac_addr, (uint32_t)wapp->map->br.ip, dstip);
}

#ifdef WIFI_MD_COEX_SUPPORT
extern int map_send_ap_oper_bss_msg(struct wifi_app *wapp, unsigned char *addr, char *evt_buf, int *len_buf);
/*below channel list is defined by modem*/
unsigned char channel_24G[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14};
unsigned char channel_5G0[] = {36, 40, 44,  48,	 52,  56,  60,	64,  68,  72,  76,  80,	 84,  88,
			       92, 96, 100, 104, 108, 112, 116, 120, 124, 128, 132, 136, 140, 144};
unsigned char channel_5G1[] = {149, 153, 157, 161, 165, 169, 173, 177, 181};

void wdev_handle_unsafe_ch_event(struct wifi_app *wapp, wapp_event_data *event_data)
{
	struct unsafe_channel_notif_s *unsafe_ch = &event_data->unsafe_ch_notif;
	unsigned char radio_id[MAC_ADDR_LEN];
	struct wapp_dev *wdev = NULL;
	unsigned int event_size = 0, i = 0;
	unsigned int count = 0, len = 0;
	char *channel_prefer_info = NULL;
	struct evt *evt_tlv = NULL;

	wapp->map->off_ch_scan_state.ch_scan_state = CH_SCAN_IDLE;

	notice(DEBUG_CAT_MISC, "bitmap([0~2]=%lu,%lu,%lu) ch_bitmap_len-%zu\n",
		unsafe_ch->ch_bitmap[0], unsafe_ch->ch_bitmap[1], unsafe_ch->ch_bitmap[2],
		sizeof(unsafe_ch->ch_bitmap[0]));

	/*align with modem, bit 0 is not used for 2.4G band*/
	unsafe_ch->ch_bitmap[0] = unsafe_ch->ch_bitmap[0] >> 1;
	/*update channel_operable_status*/
	for (i = 0; i < (sizeof(channel_5G0) / sizeof(unsigned char)); i++) {
		if (i < (sizeof(channel_24G) / sizeof(unsigned char)))
			update_primary_idc_ch_status(channel_24G[i], ((1 << i) & unsafe_ch->ch_bitmap[0]) ? 1 : 0);
		if (i < (sizeof(channel_5G0) / sizeof(unsigned char)))
			update_primary_idc_ch_status(channel_5G0[i], ((1 << i) & unsafe_ch->ch_bitmap[1]) ? 1 : 0);
		if (i < (sizeof(channel_5G1) / sizeof(unsigned char)))
			update_primary_idc_ch_status(channel_5G1[i], ((1 << i) & unsafe_ch->ch_bitmap[2]) ? 1 : 0);
	}

	dump_operable_channel();

	/*build channel preference for each radio*/
	for (i = 0; i < MAX_NUM_OF_RADIO; i++) {
		if (wapp->radio[i].adpt_id != 0) {
			MAP_GET_RADIO_IDNFER(((struct wapp_radio *)&wapp->radio[i]), radio_id);
			wdev = wapp_dev_list_lookup_by_radio(wapp, (char *)radio_id);
			if (!wdev) {
				err(DEBUG_CAT_MISC, "null wdev\n");
				return;
			}
			count = get_total_opclass_for_pref(wdev);
			len = sizeof(struct evt) + sizeof(struct ch_prefer) + sizeof(struct prefer_info) * count;
			channel_prefer_info = os_zalloc(len);
			if (channel_prefer_info == NULL)
				return;

			evt_tlv = (struct evt *)channel_prefer_info;
			event_size = map_build_chn_pref(wapp, radio_id, channel_prefer_info, 1);
			if (event_size)
				wapp_send_1905_msg(wapp, WAPP_CHANNEL_PREFERENCE, event_size - sizeof(struct evt),
					(char *)evt_tlv->buffer);
			os_sleep(0, 10);
			os_free(channel_prefer_info);
		}
	}

}

void wdev_handle_band_status_change(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct band_status_change *band_status_change = &event_data->band_status;
	unsigned char radio_id[MAC_ADDR_LEN];
	struct wapp_dev *wdev = NULL;
	int event_size = 0;
	char *event_buf = NULL;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev)
		return;

	event_buf = os_malloc(3072);

	if (!event_buf) {
		err(DEBUG_CAT_MISC, "fail to alloc memory\n");
		return;
	}

	wdev->radio->operatable = band_status_change->status;

	MAP_GET_RADIO_IDNFER(wdev->radio, radio_id);
	notice(DEBUG_CAT_MISC, "radio(" MACSTR ")- %s operatable by modem\n", MAC2STR(radio_id), !wdev->radio->operatable ? "not" : "");

	/*update operational bss information when current radio's status changing*/
	map_send_ap_oper_bss_msg(wapp, (unsigned char *)&radio_id, event_buf, &event_size);

	if (0 > map_1905_send(wapp, event_buf, event_size)) {
		err(DEBUG_CAT_MISC, "send fail\n");
		os_free(event_buf);
		return;
	}

	notice(DEBUG_CAT_MISC, "radio(" MACSTR ")-update oper BSS\n", MAC2STR(radio_id));

	os_free(event_buf);
}
#endif

void wdev_handle_radar(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
#ifdef MAP_R3
	struct dpp_authentication *auth = NULL, *auth_tmp = NULL;
	char value[200] = {0};
	char param[65] = {0}, profile_found = 0;
	int i = 0;
#endif
#ifdef MAP_R3_RECONFIG
	u8 target_band = 0;
	u8 reconfig_bh_flag = 0;
	struct wapp_dev *target_wdev = NULL;
	struct wapp_dev *radar_wdev = NULL, *tmp_wdev = NULL;
	struct dl_list *dev_list = NULL;
#endif /* MAP_R3_RECONFIG */
	struct nop_channel_list_s nop_channels;
	struct radar_notif_s *radar_notif = &event_data->radar_notif;
	unsigned char radio_id[MAC_ADDR_LEN] = {0};
	struct wapp_dev *wdev = NULL;
#ifndef EM_PLUS_SUPPORT
	unsigned int event_size = 0;
	char *channel_prefer_info = NULL;
	struct evt *evt_tlv = NULL;
	unsigned char count;
	unsigned short len;
#endif

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev)
		return;

	os_memset(&nop_channels, 0, sizeof(struct nop_channel_list_s));
	wapp->map->off_ch_scan_state.ch_scan_state = CH_SCAN_IDLE;
	if (wdev->radio)
		MAP_GET_RADIO_IDNFER(wdev->radio, radio_id);

	if (radar_notif->status) {
		notice(DEBUG_CAT_RADAR, "RADAR Absent, channel = %d, bw = %u!!!\n", radar_notif->channel, radar_notif->bw);
	} else {
		notice(DEBUG_CAT_RADAR, "RADAR Present, channel = %d, bw = %u!!!\n", radar_notif->channel, radar_notif->bw);
	}

	wapp_get_nop_channels(wapp, (char *)wdev->ifname, (char *)&nop_channels, sizeof(nop_channels));
	wdev_handle_nop_channels(&nop_channels);
	if (radar_notif->status == TRUE)
		update_primary_ch_status(radar_notif->channel, radar_notif->status);
	/* dump_operable_channel(); */
#ifdef MAP_R3
	if ((wapp->dpp->onboarding_type == DPP_ONBOARDING_TYPE) && (wapp->map->map_version == DEV_TYPE_R3)) {
		if (wapp->dpp->dpp_allowed_roles == DPP_CAPAB_CONFIGURATOR || wapp->dpp->dpp_allowed_roles == DPP_CAPAB_PROXYAGENT) {
			dl_list_for_each_safe(auth, auth_tmp, &wapp->dpp->dpp_auth_list, struct dpp_authentication, list)
			{
				if (auth->curr_chan == radar_notif->channel && auth->ethernetTrigger == FALSE) {
					wapp_dpp_cancel_timeouts(wapp, auth);
					eloop_cancel_timeout(wapp_dpp_conn_status_result_wait_timeout, wapp, auth);
					dpp_auth_deinit(auth);
					dpp_auth_fail_wrapper(wapp, "DPP Onboarding Fail - Radar Hit");
				}
			}
		} else if (wapp->dpp->dpp_allowed_roles == DPP_CAPAB_ENROLLEE) {
			dl_list_for_each_safe(auth, auth_tmp, &wapp->dpp->dpp_auth_list, struct dpp_authentication, list)
			{
				if (auth && (wapp->is_eth_onboard != TRUE) && (wapp->dpp->dpp_onboard_ongoing == 1) &&
				    (auth->curr_chan == radar_notif->channel)) {
					notice(DEBUG_CAT_RADAR, "radar hit enrollee\n");
#ifdef MAP_R3_RECONFIG
					if (auth->reconfigTrigger == TRUE) {
						wapp->dpp->reconfig_annouce.is_enable = 1;
						wapp->dpp->reconfig_annouce.an_status = DPP_AN_STATUS_INIT;
						wapp->dpp->dpp_allowed_roles = DPP_CAPAB_ENROLLEE;
						wapp->dpp->cce_driver_scan_done = 0;
						// New Addition
					if (wdev->radio) {
						target_band = (int)wapp_op_band_frm_ch(wapp, wdev->radio->op_ch);
						radar_wdev = wapp_dev_list_lookup_by_band_and_type(wapp,
								target_band, WAPP_DEV_TYPE_STA);

					if (!radar_wdev) {
						err(DEBUG_CAT_RADAR,
						"DPP: Radar ApCli wdev not found..\n");
						goto out;
					}
					dev_list = &wapp->dev_list;
					/* Skipping the radar detected wdev for reconfig announce */
					dl_list_for_each(tmp_wdev, dev_list, struct wapp_dev, list) {
					if (((tmp_wdev->dev_type == WAPP_DEV_TYPE_STA)
						&& (tmp_wdev->ifindex == radar_wdev->ifindex))
						|| (tmp_wdev->dev_type == WAPP_DEV_TYPE_AP))
						continue;
							target_wdev = tmp_wdev;
						}
					if (!target_wdev) {
						err(DEBUG_CAT_RADAR,
						"DPP: ApCli wdev not found..\n");
						goto out;
						}
					} else {
						err(DEBUG_CAT_RADAR,
						"DPP: wdev invalid:%s\n", target_wdev->ifname);
						goto out;
					}
					if (!target_wdev->config) {
						err(DEBUG_CAT_RADAR, "target wdev config is NULL\n");
						goto out;
					}
					if (!target_wdev->config->dpp_ppkey) {
						err(DEBUG_CAT_RADAR,
						"DPP: No PP-Key, no Reconfiguration");
						goto out;
					}

				if (!target_wdev->config->dpp_reconfig_id) {
					target_wdev->config->dpp_reconfig_id =
					dpp_gen_reconfig_id(target_wdev->config->dpp_csign,
					target_wdev->config->dpp_csign_len,
					target_wdev->config->dpp_ppkey,
					target_wdev->config->dpp_ppkey_len);

					if (!target_wdev->config->dpp_reconfig_id) {
						err(DEBUG_CAT_MISC,
						"DPP: Failed to generate E-id for reconfiguration");
						goto out;
					}
				}

					wapp_dpp_cancel_timeouts(wapp, auth);
					eloop_cancel_timeout(wapp_dpp_conn_result_timeout, wapp, auth);
					reconfig_bh_flag = auth->reconfig_bhconfig_done;
					dpp_auth_deinit(auth);
					if (reconfig_bh_flag) {
						err(DEBUG_CAT_MISC,
						"DPP: Skipping triggerring reconfiguration if BH Profile is present");
						continue;
					}

						wapp->dpp->radar_detect_ind = TRUE;
						radar_wdev->scan_done_ind = TRUE;
						wapp->cce_scan_count++;
						wapp_dpp_send_reconfig_annouce(wapp, target_wdev);
					} else


#endif
#ifdef DPP_R2_SUPPORT
				{
						int ret = 0;

						wapp_dpp_cancel_timeouts(wapp, auth);
						eloop_cancel_timeout(wapp_dpp_conn_result_timeout, wapp, auth);
						dpp_auth_deinit(auth);
						// Add check to prevent presence announcement if profile already exist
						for (i = 0; i < MAX_NUM_OF_RADIO; i++) {
							ret = os_snprintf(param, sizeof(param), "BhProfile%dValid", i);
							//							get_map_parameters(wapp->map, param,
							//value, NON_DRIVER_PARAM, sizeof(value));
							if (os_snprintf_error(sizeof(param), ret)) {
								err(DEBUG_CAT_RADAR, "os_snprintf fail\n");
								continue;
							}
							get_parameters((char *)wapp->map->map_user_cfg, param, value, NON_DRIVER_PARAM,
								       sizeof(value));
							if ((strcmp(value, "1")) == 0) {
								profile_found = 1;
								break;
							}
						}

						if (profile_found != 1) {
							wapp->dpp->annouce_enrolle.pre_status = DPP_PRE_STATUS_INIT;
							wapp_dpp_presence_annouce(wapp, NULL);
						}
					}
#endif /* DPP_R2_SUPPORT */
					dpp_auth_fail_wrapper(wapp, "DPP Onboarding Fail - Radar Hit");
				}
			}
		}
	}
#endif

#ifdef EM_PLUS_SUPPORT
	wapp->radat_detect = 1;
#endif /* EM_PLUS_SUPPORT */

#ifndef EM_PLUS_SUPPORT
#ifdef EM_PLUS_SUPPORT /* 3 */
	wdev = NULL;
	wdev = wapp_dev_list_lookup_by_radio(wapp, (char *)radio_id);
	if (!wdev) {
		err(DEBUG_CAT_MISC, "null wdev\n");
		return;
	}
#endif /* EM_PLUS_SUPPORT */

	count = get_total_opclass_for_pref(wdev);
	len = sizeof(struct evt) + sizeof(struct ch_prefer) + sizeof(struct prefer_info) * count;
	channel_prefer_info = os_zalloc(len);
	if (channel_prefer_info == NULL)
		return;

	evt_tlv = (struct evt *)channel_prefer_info;
	event_size = map_build_chn_pref(wapp, radio_id, channel_prefer_info, 0);
	if (event_size) {
		wapp_send_1905_msg(wapp, WAPP_CHANNEL_PREFERENCE, event_size  - sizeof(struct evt),
										(char *)evt_tlv->buffer);
	}
#endif

#ifdef MAP_R3
#ifdef MAP_R3_RECONFIG
out:
	;
#endif
#endif
#ifndef EM_PLUS_SUPPORT
	if (channel_prefer_info != NULL) {
		os_free(channel_prefer_info);
		channel_prefer_info = NULL;
	}
#endif
}

#ifdef MTK_HOSTAPD_SUPPORT
int wapp_event_eap_failure(struct wifi_app *wapp, const char *iface, uint8_t *mac)
{
	struct wapp_dev *wdev = NULL;

	if (!wapp)
		return WAPP_INVALID_ARG;

	wdev = wapp_dev_list_lookup_by_ifname(wapp, iface);
	if (!wdev) {
		err(DEBUG_CAT_EVENT, RED("wdev %s not found\n"), iface);
		return WAPP_NOT_INITIALIZED;
	}
	if (wdev->dev_type == WAPP_DEV_TYPE_AP)
		hapd_wdev_sta_cnnct_rej_handle(wapp, wdev->ifindex, mac);

	return 0;
}

int wapp_event_eap_timeout(struct wifi_app *wapp, const char *iface)
{
#ifdef MAP_R3_RECONFIG
	struct wapp_dev *wdev = NULL;

	if (!wapp)
		return WAPP_INVALID_ARG;

	wdev = wapp_dev_list_lookup_by_ifname(wapp, iface);
	if (!wdev) {
		err(DEBUG_CAT_EVENT, RED("wdev %s not found\n"), iface);
		return WAPP_NOT_INITIALIZED;
	}

	/*
	 * IF EAPOL timeout received from supplicant then
	 * trigger reconfiguration
	 */
	if (!wapp->dpp) {
		err(DEBUG_CAT_EVENT, "DPP not init yet, can't trigger reconfig\n");
		return WAPP_INVALID_ARG;
	}

	/* TODO add reconfig trigger if needed */
#endif /* MAP_R3_RECONFIG */
	return 0;

}
#endif /*MTK_HOSTAPD_SUPPORT*/

#ifdef MAP_R3_RECONFIG

int reconfigset = 0;
void wdev_handle_reconfig_trigger(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL, *wdevlist = NULL, *wdev_temp = NULL;
	struct dl_list *dev_list;

	char reconfigTrigger = TRUE;


	if ((wapp->dpp->onboarding_type == DPP_ONBOARDING_TYPE) && (wapp->map->map_version > 2) &&
	    (wapp->dpp->dpp_allowed_roles != DPP_CAPAB_CONFIGURATOR)) {
		/* Send event to map for reconfig trigger */
		wapp_send_1905_msg(wapp, WAPP_RECONFIG_STATUS, 1, (char *)&reconfigTrigger);

		wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);

		if (!wdev) {
			err(DEBUG_CAT_MISC, "return wdev error");
			reconfigTrigger = FALSE;
			wapp_send_1905_msg(wapp, WAPP_RECONFIG_STATUS, 1, (char *)&reconfigTrigger);
			return;
		}

		if (!wdev->config) {
			err(DEBUG_CAT_MISC, "return wdev dpp config error\n");
			reconfigTrigger = FALSE;
			wapp_send_1905_msg(wapp, WAPP_RECONFIG_STATUS, 1, (char *)&reconfigTrigger);
			return;
		}

		notice(DEBUG_CAT_DPP, "wdev type %d", wdev->dev_type);
		if (!wapp->drv_ops || !wapp->drv_ops->drv_set_1905_sec) {
			reconfigTrigger = FALSE;
			wapp_send_1905_msg(wapp, WAPP_RECONFIG_STATUS, 1, (char *)&reconfigTrigger);
			return;
		}

		dev_list = &wapp->dev_list;
		notice(DEBUG_CAT_DPP, "\n Prak wdev ifindex -%d, ifname -%s", wdev->ifindex, wdev->ifname);
#if 0
//	if (wdev->dev_type == WAPP_DEV_TYPE_STA) {
		if (reconfigset == 0) {
			reconfigset++;
			wapp->dpp->reconfig_annouce.is_enable = 1;
			wapp->dpp->reconfig_annouce.an_status = DPP_AN_STATUS_INIT;
#if WEXT_SUPPORT
			u8 Enable = 0;
			wapp_set_apcli_mode(wapp, (const char *)wdev->ifname,
					(char *)&Enable, 1);
#else
			os_memset(cmd, 0, 100);
			sprintf(cmd, "mwctl apclix0 set ApCliEnable=0;");
			system(cmd);
#endif
			sleep(20);
			wapp_dpp_send_reconfig_annouce(wapp, wdev);

		}
//	}
#endif
		if (wapp->reconfigTrigger != TRUE) {
			dl_list_for_each_safe(wdevlist, wdev_temp, dev_list, struct wapp_dev, list)
			{
				if (wdevlist->radio && wdevlist->dev_type == WAPP_DEV_TYPE_STA) {
#if WEXT_SUPPORT
					u8 Enable = 0;
					wapp_set_apcli_mode(wapp, (const char *)wdev->ifname, (char *)&Enable, 1);
#ifdef MTK_HOSTAPD_SUPPORT
					if (wapp->drv_ops->drv_send_disable_network)
						wapp->drv_ops->drv_send_disable_network(wapp->drv_data, wdev->ifname, wdev->network_id);

#else
					int ret = 0;
					char cmd[100];

					os_memset(cmd, 0, 100);
					ret = os_snprintf(cmd, sizeof(cmd), "mwctl %s set ApCliEnable=0;", wdevlist->ifname);
					if (os_snprintf_error(sizeof(cmd), ret)) {
						err(DEBUG_CAT_DPP, "os_snprintf fail\n");
						continue;
					}
					if (system(cmd) == -1)
						err(DEBUG_CAT_DPP, "system() call fail\n");
#endif /* MTK_HOSTAPD_SUPPORT */
					// sleep(1);
#endif
				}
			}
			// if (wapp->reconfigTrigger != TRUE) {
			wapp->dpp->reconfig_annouce.is_enable = 1;
			wapp->dpp->reconfig_annouce.an_status = DPP_AN_STATUS_INIT;
			wapp->dpp->dpp_allowed_roles = DPP_CAPAB_ENROLLEE;
			wapp->dpp->cce_driver_scan_done = 0;
			// New Addition
			if (!wdev->config->dpp_ppkey) {
				err(DEBUG_CAT_MISC, "DPP: No PP-Key, no Reconfiguration");
				reconfigTrigger = FALSE;
				wapp_send_1905_msg(wapp, WAPP_RECONFIG_STATUS, 1, (char *)&reconfigTrigger);
				return;
			}

			wdev->config->dpp_reconfig_id = dpp_gen_reconfig_id(wdev->config->dpp_csign, wdev->config->dpp_csign_len,
									    wdev->config->dpp_ppkey, wdev->config->dpp_ppkey_len);
			if (!wdev->config->dpp_reconfig_id) {
				err(DEBUG_CAT_MISC, "DPP: Failed to generate E-id for reconfiguration");
				reconfigTrigger = FALSE;
				wapp_send_1905_msg(wapp, WAPP_RECONFIG_STATUS, 1, (char *)&reconfigTrigger);
				return;
			}

			wapp_dpp_send_reconfig_annouce(wapp, wdev);
		}
	}
}
#endif
void wdev_process_wsc_scan_comp(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);

	if (!wdev) {
		err(DEBUG_CAT_MISC, "wdev==NULL!!!\n");
		return;
	}

	wdev->wsc_scan_info.bss_count = event_data->wsc_scan_info.bss_count;
	os_memcpy(wdev->wsc_scan_info.Uuid, event_data->wsc_scan_info.Uuid, sizeof(event_data->wsc_scan_info.Uuid));
	/*
		results for WPS scan on wapp->wsc_trigger_wdev are available now,
		call wps_ctrl_run_cli_wps to check if WPS needs to be executed on next BH CLI
		If status for back haul or fronthaul bss is wps_triggered then only
		check for next bss. otherwise just process the last scan results.
	*/
	if ((wapp->map->device_status.status_bhsta == STATUS_BHSTA_WPS_TRIGGERED) ||
	    (wapp->map->device_status.status_fhbss == STATUS_FHBSS_WPS_TRIGGERED)) {
		wapp->wsc_trigger_wdev = wps_ctrl_run_cli_wps(wapp, wapp->wsc_trigger_wdev);
	} else {
		wps_ctrl_process_scan_results(wapp);
		return;
	}
	/*
		if wps_ctrl_run_cli_wps returns a NULL WDEV, we have executed scan on all
		available BH CLI. Now we process scan results of all CLIs together.
	*/
	if (wapp->wsc_trigger_wdev == NULL) {
		notice(DEBUG_CAT_MISC, "will process scan results now\n");
		wps_ctrl_process_scan_results(wapp);
	}
}

#ifdef MAP_R2
void map_fill_last_scan_time(struct wifi_app *wapp, u8 radio_idx)
{
	// u8 *radio_id = wapp->map->ch_scan_req->body[radio_idx].radio_id;
	// TODO: Raghav
}
// handle channel scan compelete event from driver.
void wapp_fill_ch_bw_str(struct neighbor_info *dst, wdev_ht_cap ht_cap, wdev_vht_cap vht_cap);
u8 rssi_to_rcpi(signed char rssi);

void wdev_send_tunnel_assoc_req(struct wifi_app *wapp, u32 ifindex, u16 assoc_len, u8 *mac_addr, u8 isReassoc, u8 *assoc_buffer)
{
	struct wapp_dev *wdev = NULL;
	int send_pkt_len = 0;
	struct tunneled_msg_tlv *tunelled_tlv = NULL;
	u8 num_payload_tlv = 1;
	u8 proto_type = 0;

	if (!wapp || !assoc_len || (assoc_len <= LENGTH_802_11))
		return;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev)
		return;
	//	send oid here to fill up the wsc profile credentials from driver

	if (isReassoc)
		proto_type = 1;

	send_pkt_len = sizeof(struct tunneled_msg_tlv) + assoc_len - LENGTH_802_11;
	tunelled_tlv = os_zalloc(send_pkt_len);
	if (tunelled_tlv == NULL) {
		err(DEBUG_CAT_MISC, "memory alloc fail");
		return;
	}

	tunelled_tlv->payload_len = assoc_len - LENGTH_802_11;
	os_memcpy(&tunelled_tlv->payload[0], assoc_buffer + LENGTH_802_11, assoc_len - LENGTH_802_11);

	map_build_and_send_tunneled_message(wapp, mac_addr, proto_type, num_payload_tlv, tunelled_tlv);
}
#endif // MAP_R2

#ifdef STANDARD_NL_CMD
void wapp_scan_res_free(struct nl80211_bss_info_arg arg)
{
	size_t i;

	if (!arg.res)
		return;

	for (i = 0; i < arg.num; i++)
		os_free(arg.res[i]);

	os_free(arg.res);
}


void wdev_nl_handle_scan_results(struct wifi_app *wapp, struct nl80211_bss_info_arg arg, int ifindex)
{
	struct wapp_dev *wdev = NULL;
	int i = 0, j = 0, send_pkt_len = 0;
	struct wapp_scan_info *scan_info = NULL;
	char *buf = NULL;

	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev) {
		wapp_scan_res_free(arg);
		return;
	}

#ifdef MAP_R3
	if (wdev->waiting_cce_scan_res == TRUE) {
		wapp->dpp->scan_trigerred = 0;
		wapp->cce_scan_count++;
#ifdef MAP_R3_6E_SUPPORT
		debug(DEBUG_CAT_SCAN, "CCE scan done for %s, psc_scan_req:%d\n", wdev->ifname, wapp->dpp->psc_scan_req);
		if (IS_OP_CLASS_6G(wdev->radio->opclass) && wapp->dpp->psc_scan_req) {
			debug(DEBUG_CAT_SCAN, DPP_MAP_PREX"DPP: Query for 6G\n");
			wapp->cce_scan_count = 0;
			if (wdev->dev_type == WAPP_DEV_TYPE_STA) {
				wdev->scan_done_ind = TRUE;
				wdev->waiting_cce_scan_res = FALSE;
			}

			wapp->dpp->cce_driver_scan_done = 1;
			/* Query for CCE ch to driver and start chirping */
			debug(DEBUG_CAT_MISC, "DPP: After Scan Done Query for 6G\n");
			wapp_dpp_query_cce_channel(wapp);
#ifdef MAP_R3_RECONFIG
		if (!wapp->wdev_backup) {
#endif
			debug(DEBUG_CAT_SCAN, "DPP: Trigger presence annouce for 6G\n");
			wapp_dpp_presence_annouce(wapp, NULL);
#ifdef MAP_R3_RECONFIG
		} else
			wapp_dpp_send_reconfig_annouce(wapp, wapp->wdev_backup);
#endif
			wapp_scan_res_free(arg);
			return;
		}
#endif
		wdev->scan_done_ind = TRUE;
		wapp_dpp_presence_ch_scan(wapp);
		wapp_scan_res_free(arg);
		return;
	}
#endif /* MAP_R3 */


	send_pkt_len = sizeof(struct scan_bss_info)  + sizeof(u8) + sizeof(u8) + sizeof(unsigned int);
	buf = (char *) os_zalloc(send_pkt_len);
	if (buf == NULL) {
		debug(DEBUG_CAT_SCAN, "Buf alloc error");
		wapp_scan_res_free(arg);
		return;
	}

	for (j = 0; j < (int)arg.num; j++) {
		os_memset(buf, 0, send_pkt_len);
		os_memcpy(buf, arg.res[j], send_pkt_len);
		// wapp_nl_Scan_dump(&(arg.res[j]->bss));

#ifdef DPP_SUPPORT
		scan_info = arg.res[j];
#ifdef MAP_R3
	if (wapp->map->map_version == DEV_TYPE_R3 && !wapp->map->TurnKeyEnable) {
#endif /* MAP_R3 */
		for (i = 0; i < scan_info->bss_count; i++) {
			struct bss_info_scan_result *scan_result = os_malloc(sizeof(*scan_result));

			if (!scan_result) {
				err(DEBUG_CAT_SCAN, "Scan_recult malloc failed\n");
				goto End;
			}
#ifdef MTK_MLO_MAP_SUPPORT
			scan_result->bss = scan_info->bss;
#else
			scan_result->bss = scan_info->bss[i];
#endif
			dl_list_add_tail(&(wapp->scan_results_list), &scan_result->list);
		}
#ifdef MAP_R3
	}
#endif /* MAP_R3 */
#endif /* DPP_SUPPORT */

		wapp_send_1905_msg(wapp, WAPP_SCAN_RESULT, send_pkt_len, buf);
	}

#ifdef DPP_SUPPORT
#ifdef MAP_R3
		if (wapp->map->map_version == DEV_TYPE_R3 && !wapp->map->TurnKeyEnable)
			wapp_handle_dpp_scan(wapp, wdev);
#endif
		notice(DEBUG_CAT_SCAN, "scan_done\n");
#endif /* DPP_SUPPORT */

	wapp_send_1905_msg(wapp, WAPP_SCAN_DONE, sizeof(int), (char *)&(wdev->scan_cookie));
	eloop_cancel_timeout(map_get_scan_result, wapp, wdev);
End:
	if (buf)
		os_free(buf);
	wapp->temp_scan_count = 0;
	wapp->scan_count = 0;
	if (wapp->scan_ssids) {
		os_free(wapp->scan_ssids);
		wapp->scan_ssids = NULL;
	}
	wapp_scan_res_free(arg);
}
#endif

void wdev_handle_scan_results(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL;
	int send_pkt_len = 0;
	char *buf = NULL;
	struct wapp_scan_info *scan_info = NULL;
	int scan_done = 1;
#ifdef DPP_SUPPORT
	int i;
#endif /* DPP_SUPPORT */

	if (!wapp)
		goto End;
	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev)
		goto End;

	if (!wdev->scan_cookie)
		goto End;

	debug(DEBUG_CAT_DPP, "for %s\n", wdev->ifname);

	scan_info = &event_data->scan_info;
	scan_info->interface_index = ifindex;
	if (scan_info->more_bss) {
		scan_done = 0;
		wapp_query_scan_result(wapp, wdev, 1);
	}

#ifdef MAP_R3
	if (scan_done && (wdev->waiting_cce_scan_res == TRUE)) {
		wapp->dpp->scan_trigerred = 0;
		wapp->cce_scan_count++;
#ifdef MAP_R3_6E_SUPPORT
		debug(DEBUG_CAT_SCAN, "CCE scan done for %s, psc_scan_req:%d\n", wdev->ifname, wapp->dpp->psc_scan_req);
		if (IS_OP_CLASS_6G(wdev->radio->opclass) && wapp->dpp->psc_scan_req) {
			debug(DEBUG_CAT_MISC, "DPP: Query for 6G\n");
			wapp->cce_scan_count = 0;
			if (wdev->dev_type == WAPP_DEV_TYPE_STA) {
				wdev->scan_done_ind = TRUE;
				wdev->waiting_cce_scan_res = FALSE;
			}

			wapp->dpp->cce_driver_scan_done = 1;
			/* Query for CCE ch to driver and start chirping */
			debug(DEBUG_CAT_SCAN, "DPP: After Scan Done Query for 6G\n");
			wapp_dpp_query_cce_channel(wapp);
#ifdef MAP_R3_RECONFIG
		if (!wapp->wdev_backup) {
#endif
			debug(DEBUG_CAT_SCAN, "DPP: Trigger presence annouce for 6G\n");
			wapp_dpp_presence_annouce(wapp, NULL);
#ifdef MAP_R3_RECONFIG
		} else
			wapp_dpp_send_reconfig_annouce(wapp, wapp->wdev_backup);
#endif
			return;
		}
#endif
		wdev->scan_done_ind = TRUE;
		wapp_dpp_presence_ch_scan(wapp);
		return;
	}
#endif /* MAP_R3 */
	send_pkt_len = sizeof(struct scan_bss_info) * scan_info->bss_count + sizeof(u8) + sizeof(u8) + sizeof(unsigned int);
	os_alloc_mem(NULL, (UCHAR **)&buf, send_pkt_len);
	os_memcpy(buf, scan_info, send_pkt_len);
#ifdef DPP_SUPPORT
#ifdef MAP_R3
	if (wapp->map->map_version == DEV_TYPE_R3 && !wapp->map->TurnKeyEnable) {
#endif /* MAP_R3 */
		for (i = 0; i < scan_info->bss_count; i++) {
			struct bss_info_scan_result *scan_result = os_malloc(sizeof(*scan_result));
			if (!scan_result) {
				err(DEBUG_CAT_SCAN, "Scan_recult malloc failed\n");
				goto End;
			}
#ifdef MTK_MLO_MAP_SUPPORT
			scan_result->bss = scan_info->bss;
#else
			scan_result->bss = scan_info->bss[i];
#endif
			dl_list_add_tail(&(wapp->scan_results_list), &scan_result->list);
		}
#ifdef MAP_R3
	}
#endif /* MAP_R3 */
#endif /* DPP_SUPPORT */
	wapp_send_1905_msg(wapp, WAPP_SCAN_RESULT, send_pkt_len, buf);
	if (scan_done) {
#ifdef DPP_SUPPORT
#ifdef MAP_R3
		if (wapp->map->map_version == DEV_TYPE_R3 && !wapp->map->TurnKeyEnable)
			wapp_handle_dpp_scan(wapp, wdev);
#endif
		notice(DEBUG_CAT_SCAN, "scan_done\n");
#endif /* DPP_SUPPORT */
		wapp_send_1905_msg(wapp, WAPP_SCAN_DONE, sizeof(int), (char *)&(wdev->scan_cookie));
	}

End:
	if (buf)
		os_free(buf);
}

int wapp_issue_scan_request(struct wifi_app *wapp, struct wapp_dev *wdev)
{
	int ret = 0;

	if (!wapp || !wdev) {
		return WAPP_INVALID_ARG;
	}

	ret = wapp->drv_ops->drv_set_ScanClear(wapp->drv_data, wdev->ifname);
	if (ret < 0)
		err(DEBUG_CAT_SCAN, "set ScanClear, command failed.\n");

	/*Flag to check if scan is triggered from wapp*/
	wdev->wapp_triggered_scan = TRUE;
#ifdef DPP_SUPPORT
#ifdef MAP_R3
	wapp->dpp->scan_trigerred = 1;  /* For DPP CCE Scan */
#endif
#endif

	ret = wapp->drv_ops->drv_set_ScanType(wapp->drv_data, wdev->ifname, "full");
	if (ret < 0)
		err(DEBUG_CAT_SCAN, "set ScanType=full, command failed.\n");


	return ret;
}

#ifdef MAP_R3
int wdev_set_dpp_cred(struct wifi_app *wapp, struct wapp_dev *wdev, struct wireless_setting *psetting, int primary_cred)
{
	struct dpp_config *wdev_config = NULL;

	wdev_config = os_zalloc(sizeof(*wdev_config));
	if (!wdev_config)
		goto fail;
	wdev_config->ssid_len = os_strlen((const char *)psetting->Ssid);
	wdev_config->ssid = os_malloc(wdev_config->ssid_len + 1);
	if (!wdev_config->ssid)
		goto fail;
	os_memcpy(wdev_config->ssid, psetting->Ssid, wdev_config->ssid_len);
	wdev_config->ssid[wdev_config->ssid_len] = '\0';

	if (primary_cred) {
		if (dpp_parse_map_conf_obj(wdev_config, wapp, (u8 *)psetting->Cred, (u16)psetting->cred_len) != MAP_SUCCESS) {
			err(DEBUG_CAT_DPP, "error wireless setting while parsing dpp obj\n");
			goto fail;
		}
	} else {
		if (dpp_parse_map_conf_obj(wdev_config, wapp, (u8 *)(psetting->Cred + psetting->cred_len), (u16)psetting->ext_cred_len) !=
		    MAP_SUCCESS) {
			err(DEBUG_CAT_SCAN, "error wireless setting while parsing second dpp obj\n");
			goto fail;
		}
	}
#if 0
	if (auth->connector) {
		wdev_config->key_mgmt = WPA_KEY_MGMT_DPP;
		wdev_config->dpp_connector = os_strdup(auth->connector);
		if (!wdev_config->dpp_connector)
			goto fail;
		 notice(DEBUG_CAT_MISC, "dpp connector copied\n");
	}

	if (auth->c_sign_key) {
		wdev_config->dpp_csign = os_malloc(wpabuf_len(auth->c_sign_key));
		if (!wdev_config->dpp_csign)
			goto fail;
		os_memcpy(wdev_config->dpp_csign, wpabuf_head(auth->c_sign_key),
			  wpabuf_len(auth->c_sign_key));
		wdev_config->dpp_csign_len = wpabuf_len(auth->c_sign_key);
		notice(DEBUG_CAT_MISC, "dpp c-sign key copied: %d\n", (int)wdev_config->dpp_csign_len);

	}

	if (auth->net_access_key) {
		wdev_config->dpp_netaccesskey =
			os_malloc(wpabuf_len(auth->net_access_key));
		if (!wdev_config->dpp_netaccesskey)
			goto fail;
		os_memcpy(wdev_config->dpp_netaccesskey,
			  wpabuf_head(auth->net_access_key),
			  wpabuf_len(auth->net_access_key));
		wdev_config->dpp_netaccesskey_len = wpabuf_len(auth->net_access_key);
		wdev_config->dpp_netaccesskey_expiry = auth->net_access_key_expiry;
		notice(DEBUG_CAT_MISC, "dpp new access key copied: %d\n", (int)wdev_config->dpp_csign_len);
	}
#endif

	if (dpp_akm_psk(wdev_config->map_bss_akm) || dpp_akm_sae(wdev_config->map_bss_akm)) {
		if (dpp_akm_psk(wdev_config->map_bss_akm))
			wdev_config->key_mgmt |= WPA_KEY_MGMT_PSK | WPA_KEY_MGMT_PSK_SHA256 | WPA_KEY_MGMT_FT_PSK;
		if (dpp_akm_sae(wdev_config->map_bss_akm))
			wdev_config->key_mgmt |= WPA_KEY_MGMT_SAE | WPA_KEY_MGMT_FT_SAE;
#if 0 // comment for now to be taken care in future
		{
			wdev_config->psk_set = conf->psk_set;
			os_memcpy(wdev_config->psk, conf->psk, PMK_LEN);
		}
#endif
	}

	if (wdev && wdev->config && primary_cred) {
		os_free(wdev->config->dpp_connector);
		os_free(wdev->config->dpp_netaccesskey);
		os_free(wdev->config->dpp_csign);
		os_free(wdev->config->ssid);
		os_free(wdev->config);
		wdev->config = NULL;
	} else if (wdev && wdev->config2) {
		os_free(wdev->config2->dpp_connector);
		os_free(wdev->config2->dpp_netaccesskey);
		os_free(wdev->config2->dpp_csign);
		os_free(wdev->config2->ssid);
		os_free(wdev->config2);
		wdev->config2 = NULL;
	}
	if (wdev && primary_cred) {
		/* Set this config in ongoing wdev */
		wdev->config = wdev_config;
	} else if (wdev)
		wdev->config2 = wdev_config;
	else {
		goto fail;
	}

#ifndef MTK_HOSTAPD_SUPPORT
	if (primary_cred) {
		/* setting creds to driver only once */
		err(DEBUG_CAT_SCAN, DPP_MAP_PREX "came here to set akm is :%s\n",
			 wdev_get_dpp_driver_auth_type(wdev_config->map_bss_akm));
		wdev_set_dpp_akm(wapp, wdev, wdev_config->map_bss_akm);

		if (!dpp_akm_legacy(wdev_config->map_bss_akm))
			wdev_enable_pmf(wapp, wdev, TRUE);

		wdev_set_psk(wapp, wdev, (char *)psetting->WPAKey);
		wdev_set_ssid(wapp, wdev, (char *)psetting->Ssid);
	}
#endif /* MTK_HOSTAPD_SUPPORT */

	return WAPP_SUCCESS;

fail:
	if (wdev_config && wdev_config->ssid)
		os_free(wdev_config->ssid);
	if (wdev_config && wdev_config->dpp_connector)
		os_free(wdev_config->dpp_connector);
	if (wdev_config && wdev_config->dpp_csign)
		os_free(wdev_config->dpp_csign);
	if (wdev_config && wdev_config->dpp_netaccesskey)
		os_free(wdev_config->dpp_netaccesskey);
	if (wdev_config)
		os_free(wdev_config);

	return WAPP_INVALID_ARG;
}
#endif /* MAP_R3 */

/* need to set SSID in the end to apply sec settings */
int wdev_set_sec_and_ssid(
	struct wifi_app *wapp, struct wapp_dev *wdev, struct sec_info *sec, char *ssid)
{
#if WEXT_SUPPORT
	char cmd[MAX_CMD_MSG_LEN];
#endif
	int ret = 0;
	struct ap_dev *ap = NULL;

	if (!wapp || !wdev || !sec) {
		return WAPP_INVALID_ARG;
	}

	notice(DEBUG_CAT_WIFI_CONFIG,
			"set sec_info:\n"
			"\t ifname = %s\n"
			"\t ssid = %s\n"
			"\t auth = %s\n"
			"\t encryp = %s\n"
			"\t passphrases = %s\n",
			wdev->ifname, ssid, sec->auth, sec->encryp, sec->psphr);

	ap = (struct ap_dev *)wdev->p_dev;
 /* Authmode apply after the encryptype */
#if 0
#if WEXT_SUPPORT
	wapp_set_auth_mode(wapp, (const char *)wdev->ifname, (char *)sec->auth, sizeof(sec->auth));
#else
#ifdef MAP_6E_SUPPORT
	/* As 6G Band does not support WPA2PSK,
	 * so removing WPA2PSK security.
	 */
	if (wdev->radio && IS_OP_CLASS_6G(wdev->radio->opclass)) {
		if (os_strncmp(sec->auth, "WPA2PSKWPA3PSK", 14) == 0)
			os_memset(sec->auth, 0, sizeof(sec->auth));
		os_strncpy(sec->auth, "WPA3PSK", 7);
	}
#endif /* MAP_6E_SUPPORT */
	/* set authmode */
	ret = wapp->drv_ops->drv_set_auth_mode(wapp->drv_data, wdev->ifname, sec->auth);
	if (ret < 0) {
		err(DEBUG_CAT_MISC, "set AuthMode, command failed.\n");
		return WAPP_INVALID_ARG;
	}
	debug(DEBUG_CAT_MISC, "set AuthMode = %s\n", sec->auth);
#endif /* WEXT_SUPPORT */
#endif

#ifndef MTK_HOSTAPD_SUPPORT
#if WEXT_SUPPORT
	wapp_set_EncrypType(wapp, (const char *)wdev->ifname, (char *)sec->encryp, strlen(sec->encryp));
	os_memset(cmd, 0, MAX_CMD_MSG_LEN);
	ret = os_snprintf(cmd, sizeof(cmd), "wifi_config_save %s EncrypType %s", wdev->ifname, sec->encryp);
	if (os_snprintf_error(sizeof(cmd), ret)) {
		err(DEBUG_CAT_WIFI_CONFIG, "os_snprintf fail\n");
		return WAPP_INVALID_ARG;
	}
	ret = system(cmd);
	if (ret == -1)
		err(DEBUG_CAT_WIFI_CONFIG, "system() call return value is -1\n");
#else
	ret = wapp->drv_ops->drv_set_encrypt_type(wapp->drv_data, wdev->ifname, sec->encryp);
	if (ret < 0) {
		err(DEBUG_CAT_WIFI_CONFIG, "set EncrypType, command failed.\n");
		return WAPP_INVALID_ARG;
	}
	debug(DEBUG_CAT_WIFI_CONFIG, "set EncrypType = %s\n", sec->encryp);
#endif /* WEXT_SUPPORT*/
#endif /* MTK_HOSTAPD_SUPPORT */
	if (os_strcmp(sec->encryp, "WEP") == 0) {
		ret = wapp->drv_ops->drv_set_default_key_id(wapp->drv_data, wdev->ifname, 1);
		if (ret < 0) {
			err(DEBUG_CAT_MISC, "set DefaultKeyID, command failed.\n");
			return WAPP_INVALID_ARG;
		}
		debug(DEBUG_CAT_WIFI_CONFIG, "set DefaultKeyID = 1\n");

		if ((os_strlen(sec->psphr) != 13) && (os_strlen(sec->psphr) != 5) && (os_strlen(sec->psphr) != 10) &&
				(os_strlen(sec->psphr) != 26)) {
			err(DEBUG_CAT_WIFI_CONFIG, "in WEP key len should be 13 or 5 ascii OR 10 or 26 in valid hex\n");
			return WAPP_INVALID_ARG;
		}

#if WEXT_SUPPORT
		wapp_set_key1(wapp, (const char *)wdev->ifname, (char *)sec->psphr, (size_t)sizeof(sec->psphr));
		os_memset(cmd, 0, MAX_CMD_MSG_LEN);
		ret = os_snprintf(cmd, sizeof(cmd), "wifi_config_save %s Key1 %s", wdev->ifname, sec->psphr);
		if (os_snprintf_error(sizeof(cmd), ret)) {
			err(DEBUG_CAT_WIFI_CONFIG, "os_snprintf fail\n");
			return WAPP_INVALID_ARG;
		}

		ret = system(cmd);
		if (ret == -1)
			err(DEBUG_CAT_WIFI_CONFIG, "system() call return value is -1\n");
#endif /* WEXT_SUPPORT */
		ret = wapp->drv_ops->drv_set_key1(wapp->drv_data, wdev->ifname, sec->psphr);
		if (ret < 0) {
			err(DEBUG_CAT_WIFI_CONFIG, "set Key1, command failed.\n");
			return WAPP_INVALID_ARG;
		}
		debug(DEBUG_CAT_WIFI_CONFIG, "set Key1 = %s\n", sec->psphr);
	} else if (os_strcmp(sec->encryp, "WPAPSKWPA2PSK") == 0) {
#ifndef MTK_HOSTAPD_SUPPORT
		ret = wapp->drv_ops->drv_set_default_key_id(wapp->drv_data, wdev->ifname, 2);
		if (ret < 0) {
			err(DEBUG_CAT_WIFI_CONFIG, "set DefaultKeyID, command failed.\n");
			return WAPP_INVALID_ARG;
		}
		debug(DEBUG_CAT_WIFI_CONFIG, "set DefaultKeyID = 2\n");

		wdev_set_psk(wapp, wdev, (char *)sec->psphr);
#endif
	} else {
		wdev_set_psk(wapp, wdev, (char *)sec->psphr);
	}

#if WEXT_SUPPORT
	wapp_set_auth_mode(wapp, (const char *)wdev->ifname,
			(char *)sec->auth, sizeof(sec->auth));
	os_memset(cmd, 0, MAX_CMD_MSG_LEN);
	ret = os_snprintf(cmd, sizeof(cmd), "wifi_config_save %s AuthMode %s", wdev->ifname, sec->auth);
	if (os_snprintf_error(sizeof(cmd), ret)) {
		err(DEBUG_CAT_WIFI_CONFIG, "os_snprintf fail\n");
		return WAPP_INVALID_ARG;
	}

	ret = system(cmd);
	if (ret == -1)
		err(DEBUG_CAT_WIFI_CONFIG, "system() call return value is -1\n");
	ret = wapp->drv_ops->drv_set_auth_mode(wapp->drv_data, wdev->ifname, sec->auth);
	if (ret < 0) {
		err(DEBUG_CAT_WIFI_CONFIG, "set AuthMode, command failed.\n");
		return WAPP_INVALID_ARG;
	}
	debug(DEBUG_CAT_WIFI_CONFIG, "set AuthMode = %s\n", sec->auth);

#endif /* WEXT_SUPPORT */
	/* Need hook funcion */
	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		wdev_set_ssid(wapp, wdev, ssid ? ssid : ap->bss_info.ssid);
	}

	if (
#ifdef MTK_HOSTAPD_SUPPORT
		ret != -1 &&
#endif /* MTK_HOSTAPD_SUPPORT */
		ssid) {
		os_strncpy(ap->bss_info.ssid, ssid, MAX_LEN_OF_SSID);
		os_memcpy(&wdev->sec, sec, sizeof(struct sec_info));
	}

	return WAPP_SUCCESS;
}

int wdev_set_sec_and_ssid2(
	struct wifi_app *wapp, struct wapp_dev *wdev, struct sec_info *sec, char *ssid)
{
#ifdef MTK_HOSTAPD_SUPPORT
	int ret = 0;
#endif
	struct ap_dev *ap = NULL;

	if (!wapp || !wdev || !sec)
		return WAPP_INVALID_ARG;

	notice(DEBUG_CAT_WIFI_CONFIG,
		 "set sec_info:\n"
		 "\t ifname = %s\n"
		 "\t ssid = %s\n"
		 "\t auth = %s\n"
		 "\t encryp = %s\n"
		 "\t passphrases = %s\n",
		 wdev->ifname, ssid, sec->auth, sec->encryp, sec->psphr);

	ap = (struct ap_dev *)wdev->p_dev;
	if (wdev->dev_type == WAPP_DEV_TYPE_AP)
		wdev_set_ssid(wapp, wdev, ssid ? ssid : ap->bss_info.ssid);
#if 1 /*UCI Refine*/
#ifdef MTK_HOSTAPD_SUPPORT
	char *auth = sec->auth;
#ifdef MAP_6E_SUPPORT
	if (IS_OP_CLASS_6G(wdev->radio->opclass) &&
		(os_strncmp(auth, "WPA2PSKWPA3PSK", sizeof("WPA2PSKWPA3PSK")) == 0))
		auth = "WPA3PSK";
#endif

	if ((os_strncmp(auth, "OPEN", sizeof("OPEN")) == 0) &&
		   (os_strncmp(sec->encryp, "NONE", sizeof("NONE")) == 0)) {
		wapp_uci_update(wdev->ifname, "encryption", "none");
		wapp_uci_update(wdev->ifname, "key", "");
		wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_NON_6G);
	} else if ((os_strncmp(auth, "OPEN", sizeof("OPEN")) == 0) &&
		   (os_strncmp(sec->encryp, "WEP", sizeof("WEP")) == 0)) {
		wapp_uci_update(wdev->ifname, "encryption", "wep-open");
		wapp_uci_update(wdev->ifname, "key", "1");
		wapp_uci_update(wdev->ifname, "key1", sec->psphr);
		wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_NON_6G);
	} else if ((os_strncmp(auth, "SHARED", sizeof("SHARED")) == 0) &&
		   (os_strncmp(sec->encryp, "WEP", sizeof("WEP")) == 0)) {
		wapp_uci_update(wdev->ifname, "encryption", "wep-shared");
		wapp_uci_update(wdev->ifname, "key", "1");
		wapp_uci_update(wdev->ifname, "key1", sec->psphr);
		wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_NON_6G);
	} else if ((os_strncmp(auth, "WEPAUTO", sizeof("WEPAUTO")) == 0) &&
		   (os_strncmp(sec->encryp, "WEP", sizeof("WEP")) == 0)) {
		wapp_uci_update(wdev->ifname, "encryption", "wep-auto");
		wapp_uci_update(wdev->ifname, "key", "1");
		wapp_uci_update(wdev->ifname, "key1", sec->psphr);
		wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_NON_6G);
	} else if ((os_strncmp(auth, "WPA", sizeof("WPA")) == 0) &&
		   (os_strncmp(sec->encryp, "TKIP", sizeof("TKIP")) == 0)) {
		wapp_uci_update(wdev->ifname, "encryption", "wpa+tkip");
		wapp_uci_update(wdev->ifname, "key", "");
		wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_NON_6G);
	} else if ((os_strncmp(auth, "WPA", sizeof("WPA")) == 0) &&
		   (os_strncmp(sec->encryp, "TKIPAES", sizeof("TKIPAES")) == 0)) {
		wapp_uci_update(wdev->ifname, "encryption", "wpa+tkip+ccmp");
		wapp_uci_update(wdev->ifname, "key", "");
		wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_NON_6G);
	} else if ((os_strncmp(auth, "WPA", sizeof("WPA")) == 0) &&
		   (os_strncmp(sec->encryp, "AES", sizeof("AES")) == 0)) {
		wapp_uci_update(wdev->ifname, "encryption", "wpa+ccmp");
		wapp_uci_update(wdev->ifname, "key", "");
		wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_NON_6G);
	} else if ((os_strncmp(auth, "WPA2", sizeof("WPA2")) == 0) &&
		   (os_strncmp(sec->encryp, "TKIP", sizeof("TKIP")) == 0)) {
		wapp_uci_update(wdev->ifname, "encryption", "wpa2+tkip");
		wapp_uci_update(wdev->ifname, "key", "");
		wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_NON_6G);
	} else if ((os_strncmp(auth, "WPA2", sizeof("WPA2")) == 0) &&
		   (os_strncmp(sec->encryp, "TKIPAES", sizeof("TKIPAES")) == 0)) {
		wapp_uci_update(wdev->ifname, "encryption", "wpa2+tkip+ccmp");
		wapp_uci_update(wdev->ifname, "key", "");
		wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_NON_6G);
	} else if ((os_strncmp(auth, "WPA2", sizeof("WPA2")) == 0) &&
		   (os_strncmp(sec->encryp, "AES", sizeof("AES")) == 0)) {
		wapp_uci_update(wdev->ifname, "encryption", "wpa2+ccmp");
		wapp_uci_update(wdev->ifname, "key", "");
		wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_NON_6G);
	} else if ((os_strncmp(auth, "WPA3", sizeof("WPA3")) == 0) &&
		   (os_strncmp(sec->encryp, "AES", sizeof("AES")) == 0)) {
		wapp_uci_update(wdev->ifname, "encryption", "wpa3");
		wapp_uci_update(wdev->ifname, "key", "");
		wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_NON_6G);
	} else if ((os_strncmp(auth, "WPA3-192", sizeof("WPA3-192")) == 0) &&
		   (os_strncmp(sec->encryp, "GCMP256", sizeof("GCMP256")) == 0)) {
		wapp_uci_update(wdev->ifname, "encryption", "wpa3-192");
		wapp_uci_update(wdev->ifname, "key", "");
		wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_NON_6G);
	} else if ((os_strncmp(auth, "WPAPSK", sizeof("WPAPSK")) == 0) &&
		   (os_strncmp(sec->encryp, "AES", sizeof("AES")) == 0)) {
		wapp_uci_update(wdev->ifname, "encryption", "psk+ccmp");
		wapp_uci_update(wdev->ifname, "key", sec->psphr);
		wapp_uci_update(wdev->ifname, "ieee80211w", "");
	} else if ((os_strncmp(auth, "WPAPSK", sizeof("WPAPSK")) == 0) &&
		   (os_strncmp(sec->encryp, "TKIP", sizeof("TKIP")) == 0)) {
		wapp_uci_update(wdev->ifname, "encryption", "psk+tkip");
		wapp_uci_update(wdev->ifname, "key", sec->psphr);
		wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_NON_6G);
	} else if ((os_strncmp(auth, "WPAPSK", sizeof("WPAPSK")) == 0) &&
		   (os_strncmp(sec->encryp, "TKIPAES", sizeof("TKIPAES")) == 0)) {
		wapp_uci_update(wdev->ifname, "encryption", "psk+tkip+ccmp");
		wapp_uci_update(wdev->ifname, "key", sec->psphr);
		wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_NON_6G);
	} else if ((os_strncmp(auth, "WPA2PSK", sizeof("WPA2PSK")) == 0) &&
		   (os_strncmp(sec->encryp, "AES", sizeof("AES")) == 0)) {
		wapp_uci_update(wdev->ifname, "encryption", "psk2+ccmp");
		wapp_uci_update(wdev->ifname, "key", sec->psphr);
		wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_NON_6G);
	} else if ((os_strncmp(auth, "WPA2PSK", sizeof("WPA2PSK")) == 0) &&
		   (os_strncmp(sec->encryp, "TKIP", sizeof("TKIP")) == 0)) {
		wapp_uci_update(wdev->ifname, "encryption", "psk2+tkip");
		wapp_uci_update(wdev->ifname, "key", sec->psphr);
		wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_NON_6G);
	} else if ((os_strncmp(auth, "WPA2PSK", sizeof("WPA2PSK")) == 0) &&
		   (os_strncmp(sec->encryp, "TKIPAES", sizeof("TKIPAES")) == 0)) {
		wapp_uci_update(wdev->ifname, "encryption", "psk2+tkip+ccmp");
		wapp_uci_update(wdev->ifname, "key", sec->psphr);
		wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_NON_6G);
	} else if ((os_strncmp(auth, "WPA3PSK", sizeof("WPA3PSK")) == 0) &&
		   (os_strncmp(sec->encryp, "AES", sizeof("AES")) == 0)) {
		wapp_uci_update(wdev->ifname, "encryption", "sae");
		wapp_uci_update(wdev->ifname, "key", sec->psphr);
		wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_NON_6G);
	} else if ((os_strncmp(auth, "WPAPSKWPA2PSK", sizeof("WPAPSKWPA2PSK")) == 0) &&
		   (os_strncmp(sec->encryp, "TKIP", sizeof("TKIP")) == 0)) {
		wapp_uci_update(wdev->ifname, "encryption", "psk-mixed+tkip");
		wapp_uci_update(wdev->ifname, "key", sec->psphr);
		wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_NON_6G);
	} else if ((os_strncmp(auth, "WPAPSKWPA2PSK", sizeof("WPAPSKWPA2PSK")) == 0) &&
		   (os_strncmp(sec->encryp, "TKIPAES", sizeof("TKIPAES")) == 0)) {
		wapp_uci_update(wdev->ifname, "encryption", "psk-mixed+tkip+ccmp");
		wapp_uci_update(wdev->ifname, "key", sec->psphr);
		wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_NON_6G);
	} else if ((os_strncmp(auth, "WPAPSKWPA2PSK", sizeof("WPAPSKWPA2PSK")) == 0) &&
		   (os_strncmp(sec->encryp, "AES", sizeof("AES")) == 0)) {
		wapp_uci_update(wdev->ifname, "encryption", "psk-mixed+ccmp");
		wapp_uci_update(wdev->ifname, "key", sec->psphr);
		wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_NON_6G);
	} else if ((os_strncmp(auth, "WPA2PSKWPA3PSK", sizeof("WPA2PSKWPA3PSK")) == 0) &&
		   (os_strncmp(sec->encryp, "AES", sizeof("AES")) == 0)) {
		wapp_uci_update(wdev->ifname, "encryption", "sae-mixed");
		wapp_uci_update(wdev->ifname, "key", sec->psphr);
		wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_NON_6G);
	} else if ((os_strncmp(auth, "WPA1WPA2", sizeof("WPA1WPA2")) == 0) &&
		   (os_strncmp(sec->encryp, "TKIP", sizeof("TKIP")) == 0)) {
		wapp_uci_update(wdev->ifname, "encryption", "wpa-mixed+tkip");
		wapp_uci_update(wdev->ifname, "key", "");
		wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_NON_6G);
	} else if ((os_strncmp(auth, "WPA1WPA2", sizeof("WPA1WPA2")) == 0) &&
		   (os_strncmp(sec->encryp, "AES", sizeof("AES")) == 0)) {
		wapp_uci_update(wdev->ifname, "encryption", "wpa-mixed+ccmp");
		wapp_uci_update(wdev->ifname, "key", "");
		wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_NON_6G);
	} else if ((os_strncmp(auth, "WPA1WPA2", sizeof("WPA1WPA2")) == 0) &&
		   (os_strncmp(sec->encryp, "TKIPAES", sizeof("TKIPAES")) == 0)) {
		wapp_uci_update(wdev->ifname, "encryption", "wpa-mixed+tkip+ccmp");
		wapp_uci_update(wdev->ifname, "key", "");
		wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_NON_6G);
	} else if ((os_strncmp(auth, "WPA3WPA2", sizeof("WPA3WPA2")) == 0)) {
		wapp_uci_update(wdev->ifname, "encryption", "wpa3-mixed");
		wapp_uci_update(wdev->ifname, "key", "");
		wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_NON_6G);
	} else if ((os_strncmp(auth, "OWE", sizeof("OWE")) == 0) &&
		   (os_strncmp(sec->encryp, "AES", sizeof("AES")) == 0)) {
		wapp_uci_update(wdev->ifname, "encryption", "owe");
		wapp_uci_update(wdev->ifname, "key", "");
		wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_6G);
	} else {
		wapp_uci_update(wdev->ifname, "encryption", "none");
		wapp_uci_update(wdev->ifname, "key", "");
		wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_NON_6G);
	}

	ret = wapp->drv_ops->drv_set_encrypt_type(wapp->drv_data, wdev->ifname, sec->encryp);
	if (ret < 0) {
		err(DEBUG_CAT_WIFI_CONFIG, "set EncrypType, command failed.\n");
		return WAPP_INVALID_ARG;
	}
	debug(DEBUG_CAT_WIFI_CONFIG, "set EncrypType = %s\n", sec->encryp);

	if (os_strcmp(sec->encryp, "WEP") == 0) {
		if ((os_strlen(sec->psphr) != 13) && (os_strlen(sec->psphr) != 5) && (os_strlen(sec->psphr) != 10) &&
				(os_strlen(sec->psphr) != 26)) {
			err(DEBUG_CAT_WIFI_CONFIG, "in WEP key len should be 13 or 5 ascii OR 10 or 26 in valid hex\n");
			return WAPP_INVALID_ARG;
		}

		ret = wapp->drv_ops->drv_set_default_key_id(wapp->drv_data, wdev->ifname, 1);
		if (ret < 0) {
			err(DEBUG_CAT_WIFI_CONFIG, "set DefaultKeyID, command failed.\n");
			return WAPP_INVALID_ARG;
		}
		debug(DEBUG_CAT_WIFI_CONFIG, "set DefaultKeyID = 1\n");
	}
	if ((os_strcmp(auth, "WPAPSK") == 0)
			|| (os_strcmp(auth, "WPA2PSK") == 0)
			|| (os_strcmp(auth, "WPAPSKWPA2PSK") == 0)) {
		ret = wapp->drv_ops->drv_set_auth_mode(wapp->drv_data, wdev->ifname, auth);
		if (ret < 0) {
			err(DEBUG_CAT_WIFI_CONFIG, "set AuthMode, command failed.\n");
			return WAPP_INVALID_ARG;
		}
		debug(DEBUG_CAT_WIFI_CONFIG, "set AuthMode = %s\n", auth);

		wdev_set_psk(wapp, wdev, (char *)sec->psphr);
	} else {
		ret = wapp->drv_ops->drv_set_auth_mode(wapp->drv_data, wdev->ifname, "SAE");
		if (ret < 0)
			err(DEBUG_CAT_WIFI_CONFIG, "set AuthMode, command failed.\n");

		ret = wapp->drv_ops->drv_set_encrypt_type(wapp->drv_data, wdev->ifname, "AES");
		if (ret < 0) {
			err(DEBUG_CAT_WIFI_CONFIG, "set EncrypType, command failed.\n");
			return WAPP_INVALID_ARG;
		}

		wdev_send_sae_pwd(wapp, wdev, (const char *)sec->psphr);
	}


	if (wapp->drv_ops->drv_send_reload)
		wapp->drv_ops->drv_send_reload(wapp->drv_data, wdev->ifname);
#endif
	if (ssid) {
		os_strncpy(ap->bss_info.ssid, ssid, MAX_LEN_OF_SSID);
		os_memcpy(&wdev->sec, sec, sizeof(struct sec_info));
	}

	return WAPP_SUCCESS;
#else /* MTK UCI refine */
#ifdef MTK_HOSTAPD_SUPPORT
	uint8_t is_6g_authmode = 0;
	char auth_str[50] = {0};
	char param[64] = {0};

#ifdef MAP_6E_SUPPORT
	if (IS_OP_CLASS_6G(wdev->radio->opclass))
		is_6g_authmode = 1;
#endif /* MAP_6E_SUPPORT */
	/* Set Authmode */
#ifdef MAP_6E_SUPPORT
	if (is_6g_authmode) {
		if (os_strncmp(sec->auth, "WPA2PSKWPA3PSK", 14) == 0) {
			os_memset(sec->auth, 0, sizeof(sec->auth));
			os_strncpy(sec->auth, "WPA3PSK", 7);
		}
	}
#endif
	if (!is_str_null(auth_str)) {
		ret = os_snprintf(param, sizeof(param), "map_wpa_key_mgmt");
		if (os_snprintf_error(sizeof(param), ret)) {
			err(DEBUG_CAT_MISC, "os_snprintf fail\n");
			return -1;
		}
	}

	wapp_uci_update(wdev->ifname, param, sec->auth);
	NdisZeroMemory(param, sizeof(param));


	if (((os_strcmp(sec->auth, "WPAPSKWPA2PSK") == 0)
				|| (os_strcmp(sec->auth, "WPAPSK") == 0)) && (!is_6g_authmode))
		ret = os_snprintf(param, sizeof(param), "map_wpa_pairwise");
	else
		ret = os_snprintf(param, sizeof(param), "map_rsn_pairwise");

	if (os_snprintf_error(sizeof(param), ret)) {
		err(DEBUG_CAT_MISC, "os_snprintf fail\n");
		return -1;
	}

	wapp_uci_update(wdev->ifname, param, sec->encryp);
	NdisZeroMemory(param, sizeof(param));

	ret = os_snprintf(param, sizeof(param), "map_wpa");
	if (os_snprintf_error(sizeof(param), ret)) {
		err(DEBUG_CAT_MISC, "os_snprintf fail\n");
		return -1;
	}
	wapp_uci_update(wdev->ifname, param, "1");
	NdisZeroMemory(param, sizeof(param));

	ret = wapp->drv_ops->drv_set_encrypt_type(wapp->drv_data, wdev->ifname, sec->encryp);
	if (ret < 0) {
		err(DEBUG_CAT_MISC, "set EncrypType, command failed.\n");
		return WAPP_INVALID_ARG;
	}
	 debug(DEBUG_CAT_MISC, "set EncrypType = %s\n", sec->encryp);

	if (os_strcmp(sec->encryp, "WEP") == 0) {
		if ((os_strlen(sec->psphr) != 13) && (os_strlen(sec->psphr) != 5) && (os_strlen(sec->psphr) != 10) &&
				(os_strlen(sec->psphr) != 26)) {
			err(DEBUG_CAT_MISC, "in WEP key len should be 13 or 5 ascii OR 10 or 26 in valid hex\n");
			return WAPP_INVALID_ARG;
		}

		if (!is_str_null(sec->auth)) {
			ret = os_snprintf(param, sizeof(param), "map_wpa_key_mgmt");
			if (os_snprintf_error(sizeof(param), ret)) {
				err(DEBUG_CAT_MISC, "os_snprintf fail\n");
				return -1;
			}
		}

		wapp_uci_update(wdev->ifname, param, "none");
		NdisZeroMemory(param, sizeof(param));


		ret = os_snprintf(param, sizeof(param), "map_wep_default_key");
		if (os_snprintf_error(sizeof(param), ret)) {
			err(DEBUG_CAT_MISC, "os_snprintf fail\n");
			return -1;
		}

		wapp_uci_update(wdev->ifname, param, "1");
		NdisZeroMemory(param, sizeof(param));
		ret = os_snprintf(param, sizeof(param), "map_wep_key1");
		if (os_snprintf_error(sizeof(param), ret)) {
			err(DEBUG_CAT_MISC, "os_snprintf fail\n");
			return -1;
		}

		wapp_uci_update(wdev->ifname, param, (char *)sec->encryp);
		NdisZeroMemory(param, sizeof(param));
		ret = wapp->drv_ops->drv_set_default_key_id(wapp->drv_data, wdev->ifname, 1);
		if (ret < 0) {
			err(DEBUG_CAT_MISC, "set DefaultKeyID, command failed.\n");
			return WAPP_INVALID_ARG;
		}
		 debug(DEBUG_CAT_MISC, "set DefaultKeyID = 1\n");
	}
	if ((os_strcmp(sec->auth, "WPAPSK") == 0)
		|| (os_strcmp(sec->auth, "WPA2PSK") == 0)
		|| (os_strcmp(sec->auth, "WPAPSKWPA2PSK") == 0)) {
		uint8_t wpa_val = 2;

		ret = os_snprintf(param, sizeof(param), "map_wpa_passphrase");
		if (os_snprintf_error(sizeof(param), ret)) {
			err(DEBUG_CAT_MISC, "os_snprintf fail\n");
			return -1;
		}
		wapp_uci_update(wdev->ifname, param, (char *)sec->psphr);
		NdisZeroMemory(param, sizeof(param));
		if (!is_str_null(sec->auth)) {
			ret = os_snprintf(param, sizeof(param), "map_wpa_key_mgmt");
			if (os_snprintf_error(sizeof(param), ret)) {
				err(DEBUG_CAT_MISC, "os_snprintf fail\n");
				return -1;
			}
		}

		wapp_uci_update(wdev->ifname, param, "WPA-PSK");
		NdisZeroMemory(param, sizeof(param));
		ret = wapp->drv_ops->drv_set_auth_mode(wapp->drv_data, wdev->ifname, sec->auth);
		if (ret < 0) {
			err(DEBUG_CAT_MISC, "set AuthMode, command failed.\n");
			return WAPP_INVALID_ARG;
		}
		 debug(DEBUG_CAT_MISC, "set AuthMode = %s\n", sec->auth);

		if (os_strcmp(sec->auth, "WPAPSK") == 0)
			wpa_val = 1;

		ret = os_snprintf(param, sizeof(param), "map_wpa");
		if (os_snprintf_error(sizeof(param), ret)) {
			err(DEBUG_CAT_MISC, "os_snprintf fail\n");
			return -1;
		}

		if (wpa_val == 1)
			wapp_uci_update(wdev->ifname, param, "1");
		else
			wapp_uci_update(wdev->ifname, param, "2");

		NdisZeroMemory(param, sizeof(param));
		wdev_set_psk(wapp, wdev, (char *)sec->psphr);
	} else {
		if (!is_str_null(sec->auth)) {
			ret = os_snprintf(param, sizeof(param), "map_wpa_key_mgmt");
			if (os_snprintf_error(sizeof(param), ret)) {
				err(DEBUG_CAT_MISC, "os_snprintf fail\n");
				return -1;
			}
		}
		wapp_uci_update(wdev->ifname, param, "SAE");
		NdisZeroMemory(param, sizeof(param));

		ret = wapp->drv_ops->drv_set_auth_mode(wapp->drv_data, wdev->ifname, "SAE");
		if (ret < 0)
			err(DEBUG_CAT_MISC, "set AuthMode, command failed.\n");

		ret = wapp->drv_ops->drv_set_encrypt_type(wapp->drv_data, wdev->ifname, "AES");
		if (ret < 0) {
			err(DEBUG_CAT_MISC, "set EncrypType, command failed.\n");
			return WAPP_INVALID_ARG;
		}

		ret = os_snprintf(param, sizeof(param), "map_sae_password");
		if (os_snprintf_error(sizeof(param), ret)) {
			err(DEBUG_CAT_MISC, "os_snprintf fail\n");
			return -1;
		}
		wapp_uci_update(wdev->ifname, param, (char *)sec->psphr);
		NdisZeroMemory(param, sizeof(param));
		wdev_send_sae_pwd(wapp, wdev, (const char *)sec->psphr);
	}

	if (wapp->drv_ops->drv_send_reload)
		wapp->drv_ops->drv_send_reload(wapp->drv_data, wdev->ifname);
	if (ssid) {
		os_strncpy(ap->bss_info.ssid, ssid, MAX_LEN_OF_SSID);
		os_memcpy(&wdev->sec, sec, sizeof(struct sec_info));
	}

	return WAPP_SUCCESS;
#endif
#endif /* MTK UCI refine */
}


int wdev_set_map_channel(struct wifi_app *wapp, struct wapp_dev *wdev, const u8 ch
#ifdef MAP_R2
		, const u8 cac_req, const u8 dev_role
#endif /* MAP_R2 */
		)
{
	if (!wapp || !wdev)
		return WAPP_INVALID_ARG;

	if (ch == 0) {
		err(DEBUG_CAT_CHANNEL, "channel is 0, return\n");
		return WAPP_INVALID_ARG;
	}


	if (wapp->drv_ops->drv_set_map_ch)
		wapp->drv_ops->drv_set_map_ch(wapp->drv_data, wdev->ifname, ch
#ifdef MAP_R2
			, cac_req, dev_role
#endif /* MAP_R2 */
		);

	return WAPP_SUCCESS;
}

int wdev_set_map_enable(struct wifi_app *wapp, struct wapp_dev *wdev, const u8 map_en)
{
	if (!wapp || !wdev)
		return WAPP_INVALID_ARG;


	if (wapp->drv_ops->drv_set_map_enable)
		wapp->drv_ops->drv_set_map_enable(wapp->drv_data, wdev->ifname, map_en);

	return WAPP_SUCCESS;
}

#ifdef MAP_R6
int wdev_set_mlo_switch(struct wifi_app *wapp, struct wapp_dev *wdev, const u8 mlo_en)
{
	if (!wapp || !wdev)
		return WAPP_INVALID_ARG;

	notice(DEBUG_CAT_MLO, "mlo switch ifname:%s mlo_en = %d\n", wdev->ifname, mlo_en);

	if (wapp->drv_ops->drv_set_mlo_switch)
		wapp->drv_ops->drv_set_mlo_switch(wapp->drv_data, wdev->ifname, mlo_en);

	return WAPP_SUCCESS;
}
#endif

int wdev_set_static_punc_dscb(struct wifi_app *wapp, struct wapp_dev *wdev, const u16 puncture_dscb)
{
	if (!wapp || !wdev)
		return WAPP_INVALID_ARG;

	notice(DEBUG_CAT_MLO, "ifname:%s\n", wdev->ifname);

	if (wapp->drv_ops->drv_set_static_punc_dscb)
		wapp->drv_ops->drv_set_static_punc_dscb(wapp->drv_data, wdev->ifname, puncture_dscb);

	return WAPP_SUCCESS;
}

#ifdef CSA_BAND_SUPPORT
int wdev_set_static_2g_csa_support(struct wifi_app *wapp, struct wapp_dev *wdev, const u8 csa_2g_support)
{
	if (!wapp || !wdev)
		return WAPP_INVALID_ARG;

	notice(DEBUG_CAT_MLO, "ifname:%s\n", wdev->ifname);

	if (wapp->drv_ops->drv_set_2g_csa_support)
		wapp->drv_ops->drv_set_2g_csa_support(wapp->drv_data, wdev->ifname, csa_2g_support);

	return WAPP_SUCCESS;
}


int wdev_set_static_csa_support(struct wifi_app *wapp, struct wapp_dev *wdev, const u8 csa_5g_support)
{
	if (!wapp || !wdev)
		return WAPP_INVALID_ARG;

	notice(DEBUG_CAT_MLO, "ifname:%s\n", wdev->ifname);

	if (wapp->drv_ops->drv_set_csa_support)
		wapp->drv_ops->drv_set_csa_support(wapp->drv_data, wdev->ifname, csa_5g_support);

	return WAPP_SUCCESS;
}
#endif

int wdev_set_ap_fhbss(struct wifi_app *wapp, struct wapp_dev *wdev, const u8 fh_en)
{
	if (!wapp || !wdev)
		return WAPP_INVALID_ARG;

	if (wapp->drv_ops->drv_set_ap_fhbss)
		wapp->drv_ops->drv_set_ap_fhbss(wapp->drv_data, wdev->ifname, fh_en);

	return WAPP_SUCCESS;
}

int wdev_set_ap_bhbss(struct wifi_app *wapp, struct wapp_dev *wdev, const u8 bh_en)
{
	if (!wapp || !wdev)
		return WAPP_INVALID_ARG;


	if (wapp->drv_ops->drv_set_ap_bhbss)
		wapp->drv_ops->drv_set_ap_bhbss(wapp->drv_data, wdev->ifname, bh_en);

	return WAPP_SUCCESS;
}

int wdev_set_v10converter(struct wifi_app *wapp, struct wapp_dev *wdev, const u8 v_en)
{
	if (!wapp || !wdev)
		return WAPP_INVALID_ARG;

	if (wapp->drv_ops->drv_set_ap_v10converter)
		wapp->drv_ops->drv_set_ap_v10converter(wapp->drv_data, wdev->ifname, v_en);

	return WAPP_SUCCESS;
}

int wdev_set_approxyrefresh(struct wifi_app *wapp, struct wapp_dev *wdev, const u8 proxy_en)
{
	if (!wapp || !wdev)
		return WAPP_INVALID_ARG;

	if (wapp->drv_ops->drv_set_approxyrefresh)
		wapp->drv_ops->drv_set_approxyrefresh(wapp->drv_data, wdev->ifname, proxy_en);

	return WAPP_SUCCESS;
}

int wdev_set_quick_ch(struct wifi_app *wapp, struct wapp_dev *wdev, int ch)
{
	struct dl_list *dev_list;
	struct wapp_dev *wdev_temp = NULL, *wdev_tmp = NULL;
	dev_list = &wapp->dev_list;
	int ret = 0;
	unsigned int bss_coex_buffer = 0;

	if (!wapp || !wdev) {
		err(DEBUG_CAT_CHANNEL, "invalid_argument\n");
		return WAPP_INVALID_ARG;
	}

	if (ch == 0) {
		err(DEBUG_CAT_CHANNEL, "channel is 0, return\n");
		return WAPP_INVALID_ARG;
	}

	if (wdev->radio && ch == wdev->radio->op_ch) {
		return WAPP_SUCCESS;
	}
	notice(DEBUG_CAT_CHANNEL,
		     "set ch:\n"
		     "\t ifname = %s\n"
		     "\t ch = %d\n",
		     wdev->ifname, ch);

	dl_list_for_each_safe(wdev_temp, wdev_tmp, dev_list, struct wapp_dev, list)
	{
		if (wdev->radio == wdev_temp->radio)
			if (wdev_temp->dev_type == WAPP_DEV_TYPE_AP) {
				struct ap_dev *ap = (struct ap_dev *)wdev_temp->p_dev;
				ap->ch_info.op_ch = ch;
			}
	}

	/* Disable coex scan for this channel, since this is a configuration/auth phase */
	wapp_get_bss_coex(wapp, (char *)wdev->ifname, (char *)&bss_coex_buffer, sizeof(bss_coex_buffer));
	if (bss_coex_buffer)
		wdev_set_bss_coex(wapp, wdev, FALSE);

		// TODO move this code outside of MAP in driver
#if WEXT_SUPPORT
	wapp_set_map_channel(wapp, (const char *)wdev->ifname, (char *)&ch, (size_t)sizeof(ch));
#else
	ret = wdev_set_map_channel(wapp, wdev, (const u8)ch
#ifdef MAP_R2
			, SET_CH_ARG_NOT_REQ, SET_CH_ARG_NOT_REQ
#endif /* MAP_R2 */
			);
	if (ret != WAPP_SUCCESS) {
		err(DEBUG_CAT_CHANNEL, "wdev_set_map_channel fail\n");
		return WAPP_INVALID_ARG;
	}
#endif /* WEXT_SUPPORT */

	notice(DEBUG_CAT_CHANNEL, " Send Channel %d\n", ch);
	wapp_radio_update_ch(wapp, wdev->radio, ch);

	/* Enable coex scan */
	if (bss_coex_buffer)
		wdev_set_bss_coex(wapp, wdev, TRUE);

	return WAPP_SUCCESS;
}

#ifdef MAP_6E_SUPPORT
int wdev_set_ch(
	struct wifi_app *wapp,
	struct wapp_dev	*wdev,
	int ch,
	unsigned char op_class,
	u32 bw,
	unsigned char op_report)
#else
int wdev_set_ch(
	struct wifi_app *wapp,
	struct wapp_dev	*wdev,
	int ch,
	unsigned char op_class)
#endif
{
	char cmd[256];
	struct dl_list *dev_list;
	struct wapp_dev *wdev_temp, *wdev_tmp = NULL;
	dev_list = &wapp->dev_list;
	int ret = 0;
	int chan_list = 0;
	BOOLEAN found = FALSE;
	unsigned int bss_coex_buffer = 0;
#ifdef MAP_R2
#ifdef DFS_CAC_R2
	union dfs_zero_wait_msg msg;
	size_t msg_len = 0;
	char buf[4096] = {0};
#endif
#endif

	if (!wapp || !wdev || !wdev->radio)
		return WAPP_INVALID_ARG;

	if (ch == 0) {
		notice(DEBUG_CAT_CHANNEL, "channel is 0, return\n");
		return WAPP_INVALID_ARG;
	}

	if ((wdev->radio && ch == wdev->radio->op_ch) &&
		(wdev->radio->opclass != op_class)) {
		err(DEBUG_CAT_CHANNEL,
				"wdev set ch: %d due to different opclass wdev-opclass %d: set-opclass %d\n",
				ch, wdev->radio->opclass, op_class);
		goto set_channel;
	}

	if (wdev->radio && ch == wdev->radio->op_ch) {
		map_operating_channel_info(wapp);
		err(DEBUG_CAT_CHANNEL, "return due to same channel%d\n", ch);
#ifdef MAP_R2
#ifdef DFS_CAC_R2
#ifdef ZW_DFS_BW80_ONLY
		err(DEBUG_CAT_CHANNEL, "\n radio_band %d, zw_dfs_state %d\n",
			 *(wdev->radio->radio_band), wapp->map->zw_dfs_state);
#endif
		if (wdev->radio->radio_band && ((*(wdev->radio->radio_band) == RADIO_5GL)
			|| (*(wdev->radio->radio_band) == RADIO_5G)
			|| (*(wdev->radio->radio_band) == RADIO_5GH))
			&& (wdev->cac_method == DEDICATED_CAC)
			) {
#ifdef ZW_DFS_BW80_ONLY
			if (wapp->map->zw_dfs_state != DFS_FIRST_HALF_INIT)
				return WAPP_SUCCESS;
#endif

				msg.set_monitored_ch_msg.Action = MONITOR_CH_ASSIGN;
				msg.set_monitored_ch_msg.Channel = ch;
				msg.set_monitored_ch_msg.Bw = bw;
				msg.set_monitored_ch_msg.doCAC = 1;
				msg.set_monitored_ch_msg.SyncNum = RDD_DEDICATED_RX;

				msg_len = sizeof(union dfs_zero_wait_msg);

				os_memset(buf, 0, 4096);
				os_memcpy(buf, &msg, msg_len);

				wapp_set_channel_monitor_assign(wapp, (const char *) wdev->ifname,
						(char *)buf, msg_len);
		}
#endif
#endif
		return WAPP_SUCCESS;
	}

set_channel:

	notice(DEBUG_CAT_CHANNEL, "ifname = %s ch = %d\n", wdev->ifname, ch);

#ifdef MAP_SUPPORT
#if WEXT_SUPPORT
	if (wapp->map->quick_ch_change)
		wapp_set_map_channel(wapp, (const char *)wdev->ifname, (char *)&ch, (size_t)sizeof(ch));
	else
		wapp_set_channel(wapp, (const char *)wdev->ifname, (char *)&ch, (size_t)sizeof(ch));
#else
	if (wapp->map->quick_ch_change) {
		/* Disable coex scan for this channel, since this is a configuration/auth phase */
		wapp_get_bss_coex(wapp, (char *)wdev->ifname, (char *)&bss_coex_buffer, sizeof(bss_coex_buffer));
		notice(DEBUG_CAT_MISC, "get coex buffer %d\n", bss_coex_buffer);
		if (bss_coex_buffer)
			wdev_set_bss_coex(wapp, wdev, FALSE);
#ifndef MAP_R2
		ret = wdev_set_map_channel(wapp, wdev, (const u8)ch);
#else
		notice(DEBUG_CAT_CHANNEL, "dev role in wapp is %d\n", wapp->map->my_map_dev_role);
#ifdef MAP_EHT_SUPPORT
		ret = wapp->drv_ops->drv_set_bw_channel_proc(wapp->drv_data, wdev->ifname,
				bw, ch, !wdev->cac_not_required,  wdev->HE_EXTCHA);
#else
		ret = wapp->drv_ops->drv_set_bw_channel_proc(wapp->drv_data, wdev->ifname,
				bw, ch, !wdev->cac_not_required, 0);
#endif

		wdev->cac_not_required = 0;
		if (bss_coex_buffer) {
			err(DEBUG_CAT_CHANNEL, "set coex buffer %d\n", bss_coex_buffer);
			wdev_set_bss_coex(wapp, wdev, TRUE);
		}
#endif /* MAP_R2 */
		if (ret != WAPP_SUCCESS) {
			err(DEBUG_CAT_CHANNEL, "wdev_set_map_channel fail\n");
			return WAPP_INVALID_ARG;
		}
	} else
#endif /* MAP_SUPPORT */
	ret = wapp->drv_ops->drv_set_channel_proc(wapp->drv_data, wdev->ifname, ch);
	if (ret < 0) {
		err(DEBUG_CAT_CHANNEL, "set channel, command failed.\n");
		return WAPP_INVALID_ARG;
	}
	 debug(DEBUG_CAT_MISC, "set channel = %d\n", ch);
#endif /* WEXT_SUPPORT */

	/* Skip upating wrong channel for bootup */
	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		struct ap_dev *ap = (struct ap_dev *)wdev->p_dev;

		for (chan_list = 0; chan_list < ap->ch_info.ch_list_num; chan_list++) {
			if (ap->ch_info.ch_list[chan_list].channel == ch) {
				found = TRUE;
				break;
			}
		}
	}

	if (found == TRUE) {
		os_memset(cmd, 0, sizeof(cmd));
		ret = os_snprintf(cmd, sizeof(cmd), "%d", ch);
		if (os_snprintf_error(sizeof(cmd), ret)) {
			err(DEBUG_CAT_CHANNEL, "os_snprintf fail\n");
			return WAPP_INVALID_ARG;
		}
		ret = os_execute("/usr/bin/wifi_config_save", 3, wdev->ifname, "Channel", cmd);
		if (ret == -1)
			err(DEBUG_CAT_CHANNEL, "system() call return value is -1\n");
		notice(DEBUG_CAT_CHANNEL, "Send Channel Command: %s, ret = %d\n", cmd, ret);
#ifdef MTK_HOSTAPD_SUPPORT
		/* Write channel in HOSTAPD conf file */
		char param[MAX_SIZE_UCI_VALUE] = {0};
		char ch_str[MAX_SIZE_UCI_VALUE] = {0};
		char value[MAX_SIZE_UCI_VALUE] = {0};

		ret = os_snprintf(param, sizeof(param), "channel");
		if (os_snprintf_error(sizeof(param), ret)) {
			err(DEBUG_CAT_CHANNEL, "os_snprintf fail\n");
			return -1;
		}
		ret = os_snprintf(ch_str, sizeof(ch_str), "%d", ch);
		if (os_snprintf_error(sizeof(ch_str), ret)) {
			err(DEBUG_CAT_CHANNEL, "os_snprintf fail\n");
			return -1;
		}
		wapp_uci_get_param(wdev->ifname, "device", value);
		wapp_uci_update(value, param, ch_str);
#endif /*MTK_HOSTAPD_SUPPORT */
	}
#ifdef MAP_R2
#ifdef DFS_CAC_R2
#ifdef ZW_DFS_BW80_ONLY
	if (wdev->radio->radio_band)
		err(DEBUG_CAT_CHANNEL, "found %d, radio_band %d, zw_dfs_state %d", found,
			*(wdev->radio->radio_band), wapp->map->zw_dfs_state);
#endif
	if (wdev->radio->radio_band && ((*(wdev->radio->radio_band) == RADIO_5GL)
		|| (*(wdev->radio->radio_band) == RADIO_5G)
		|| (*(wdev->radio->radio_band) == RADIO_5GH))
		&& (wdev->cac_method == DEDICATED_CAC)
		) {
#ifdef ZW_DFS_BW80_ONLY
		if (wapp->map->zw_dfs_state == DFS_FIRST_HALF_INIT) {
#endif
			msg.set_monitored_ch_msg.Action = MONITOR_CH_ASSIGN;
			msg.set_monitored_ch_msg.Channel = ch;
			msg.set_monitored_ch_msg.Bw = bw;
			msg.set_monitored_ch_msg.doCAC = 1;
			msg.set_monitored_ch_msg.SyncNum = RDD_DEDICATED_RX;

			msg_len = sizeof(union dfs_zero_wait_msg);

			os_memset(buf, 0, 4096);
			os_memcpy(buf, &msg, msg_len);

			wapp_set_channel_monitor_assign(wapp, (const char *) wdev->ifname,
				(char *)buf, msg_len);
#ifdef ZW_DFS_BW80_ONLY
		}
#endif
	}
#endif
#endif
#ifdef MAP_6E_SUPPORT
	if (wdev->radio && op_class)
		wdev->radio->opclass = op_class;
#endif
	wapp_radio_update_ch(wapp, wdev->radio, ch);
	dl_list_for_each_safe(wdev_temp, wdev_tmp, dev_list, struct wapp_dev, list)
	{
		if (wdev->radio == wdev_temp->radio)
			if (wdev_temp->dev_type == WAPP_DEV_TYPE_AP) {
				struct ap_dev *ap = (struct ap_dev *)wdev_temp->p_dev;
				ap->ch_info.op_ch = ch;
				if (op_class != 0)
					ap->ch_info.op_class = op_class;
			}
	}
#ifdef MAP_6E_SUPPORT
	if (op_report)
#endif
	map_operating_channel_info(wapp);

	return WAPP_SUCCESS;
}

int wdev_set_bss_coex(struct wifi_app *wapp, struct wapp_dev *wdev, char enable)
{
	if (!wapp || !wdev) {
		return WAPP_INVALID_ARG;
	}
	notice(DEBUG_CAT_CHANNEL,
		 "set bss_coex:\n"
		 "\t ifname = %s\n"
		 "\t enable = %d\n",
		 wdev->ifname, enable);

#if WEXT_SUPPORT
	wapp_set_HtBssCoex(wapp, (const char *)wdev->ifname, (char *)&enable, 1);
#else
	int ret = 0;

	if (!wapp->drv_ops->drv_set_HtBssCoex) {
		err(DEBUG_CAT_CHANNEL, "drv_set_HtBssCoex invalid.\n");
		return WAPP_INVALID_ARG;
	}
	ret = wapp->drv_ops->drv_set_HtBssCoex(wapp->drv_data, wdev->ifname, enable);
	if (ret < 0) {
		err(DEBUG_CAT_CHANNEL, "set HtBssCoex, command failed.\n");
		return WAPP_INVALID_ARG;
	}
	debug(DEBUG_CAT_CHANNEL, "set HtBssCoex = %d\n", enable);
#endif
	return WAPP_SUCCESS;
}

#ifdef MAP_R3
u16 wdev_get_dpp_driver_auth_type_wsc(enum dpp_akm akm)
{
	switch (akm) {
	case DPP_AKM_DPP:
		return WPS_AUTH_DPP;
	case DPP_AKM_PSK:
		return WSC_AUTHTYPE_WPA2PSK;
	case DPP_AKM_SAE:
		return WSC_AUTHTYPE_SAE;
	case DPP_AKM_PSK_SAE:
		return WSC_AUTHTYPE_SAE | WSC_AUTHTYPE_WPA2PSK;
	case DPP_AKM_PSK_DPP:
		return WPS_AUTH_DPP | WSC_AUTHTYPE_WPA2PSK;
	case DPP_AKM_SAE_DPP:
		return WPS_AUTH_DPP | WSC_AUTHTYPE_SAE;
	case DPP_AKM_PSK_SAE_DPP:
		return WPS_AUTH_DPP | WSC_AUTHTYPE_SAE | WSC_AUTHTYPE_WPA2PSK;
#ifdef MAP_R6
	case DPP_AKM_PSK_SAE24:
		return WSC_AUTHTYPE_SAE_AKM24_D | WSC_AUTHTYPE_WPA2PSK;
	case DPP_AKM_PSK_SAE24_DPP:
		return WSC_AUTHTYPE_SAE_AKM24_D | WPS_AUTH_DPP | WSC_AUTHTYPE_WPA2PSK;
	case DPP_AKM_SAE24:
		return WSC_AUTHTYPE_SAE_AKM24_D;
	case DPP_AKM_SAE24_DPP:
		return WSC_AUTHTYPE_SAE_AKM24_D | WPS_AUTH_DPP;
	case DPP_AKM_SAE_SAE24:
		return WSC_AUTHTYPE_SAE_AKM24_D | WPS_AUTH_SAE;
	case DPP_AKM_PSK_SAE_SAE24:
		return WSC_AUTHTYPE_SAE_AKM24_D | WSC_AUTHTYPE_SAE | WSC_AUTHTYPE_WPA2PSK;
	case DPP_AKM_SAE_SAE24_DPP:
		return WSC_AUTHTYPE_SAE_AKM24_D | WSC_AUTHTYPE_SAE | WPS_AUTH_DPP;
	case DPP_AKM_PSK_SAE_SAE24_DPP:
		return WSC_AUTHTYPE_SAE_AKM24_D | WPS_AUTH_DPP | WSC_AUTHTYPE_SAE | WSC_AUTHTYPE_WPA2PSK;
#endif
	default:
		return WSC_AUTHTYPE_WPA2PSK;
	}
}
#endif /* MAP_R3 */

#ifdef DPP_SUPPORT
char *wdev_get_dpp_driver_auth_type(enum dpp_akm akm)
{
	switch (akm) {
	case DPP_AKM_DPP:
		return "DPP";
	case DPP_AKM_PSK:
		return "WPA2PSK";
	case DPP_AKM_SAE:
		return "WPA3PSK";
	case DPP_AKM_PSK_SAE:
		return "WPA2PSKWPA3PSK";
	case DPP_AKM_PSK_DPP:
		return "DPPWPA2PSK";
	case DPP_AKM_SAE_DPP:
		return "DPPWPA3PSK";
	case DPP_AKM_PSK_SAE_DPP:
		return "DPPWPA3PSKWPA2PSK";
	default:
		return "WPA2PSK";
	}
}

#ifdef MTK_HOSTAPD_SUPPORT
char *wdev_get_dpp_supp_auth_type(enum dpp_akm akm)
{
	switch (akm) {
	case DPP_AKM_DPP:
		return "DPP";
	case DPP_AKM_PSK:
		return "WPA-PSK";
	case DPP_AKM_SAE:
		return "SAE";
	case DPP_AKM_PSK_SAE:
		return "WPA-PSK SAE";
	case DPP_AKM_PSK_DPP:
		return "WPA-PSK DPP";
	case DPP_AKM_SAE_DPP:
		return "SAE DPP";
	case DPP_AKM_PSK_SAE_DPP:
		return "WPA-PSK SAE DPP";
#ifdef MAP_R6
	case DPP_AKM_PSK_SAE24:
		return "WPA-PSK SAE-EXT-KEY";
	case DPP_AKM_PSK_SAE24_DPP:
		return "DPP WPA-PSK SAE-EXT-KEY";
	case DPP_AKM_SAE24:
		return "SAE-EXT-KEY";
	case DPP_AKM_SAE24_DPP:
		return "DPP SAE-EXT-KEY";
	case DPP_AKM_SAE_SAE24:
		return "SAE SAE-EXT-KEY";
	case DPP_AKM_PSK_SAE_SAE24:
		return "WPA-PSK SAE SAE-EXT-KEY";
	case DPP_AKM_SAE_SAE24_DPP:
		return "DPP SAE SAE-EXT-KEY";
	case DPP_AKM_PSK_SAE_SAE24_DPP:
		return "WPA-PSK SAE SAE-EXT-KEY DPP";
#endif
	default:
		return "WPA-PSK";
	}
}
#endif /* MTK_HOSTAPD_SUPPORT */

int wdev_enable_apcli_iface(struct wifi_app *wapp, struct wapp_dev *wdev, int enable)
{
#ifndef MTK_HOSTAPD_SUPPORT
	char cmd[100] = {0};
#endif /* MTK_HOSTAPD_SUPPORT */

	if (!wapp || !wdev) {
		return WAPP_INVALID_ARG;
	}

	if (wdev->dev_type != WAPP_DEV_TYPE_STA) {
		debug(DEBUG_CAT_WIFI_CONFIG, "incorrect iface type =%d\n", wdev->dev_type);
		return -1;
	}

#if WEXT_SUPPORT
	wapp_set_apcli_mode(wapp, (const char *)wdev->ifname, (char *)&enable, 1);
#else
#ifdef MTK_HOSTAPD_SUPPORT
	if (wapp->drv_ops->drv_send_disable_network)
		wapp->drv_ops->drv_send_disable_network(wapp->drv_data, wdev->ifname, wdev->network_id);

#else
	int ret = 0;

	ret = os_snprintf(cmd, sizeof(cmd), "mwctl %s set ApCliEnable=%d", wdev->ifname, enable);
	if (os_snprintf_error(sizeof(cmd), ret)) {
		err(DEBUG_CAT_WIFI_CONFIG, "os_snprintf fail\n");
		return WAPP_INVALID_ARG;
	}
	if (system(cmd) == -1)
		err(DEBUG_CAT_WIFI_CONFIG, "system() call return value is -1\n");
#endif /* MTK_HOSTAPD_SUPPORT */
#endif /* WEXT_SUPPORT */

	return WAPP_SUCCESS;
}

int wdev_set_dpp_akm(struct wifi_app *wapp, struct wapp_dev *wdev, enum dpp_akm akm)
{

	if (!wapp || !wdev) {
		return WAPP_INVALID_ARG;
	}


#if WEXT_SUPPORT
	if (wdev->dev_type == WAPP_DEV_TYPE_AP)
		wapp_set_auth_mode(wapp, (const char *)wdev->ifname, (char *)wdev_get_dpp_driver_auth_type(akm), strlen(sec->auth));
	else
		wapp_set_authtype(wapp, (const char *)wdev->ifname, (char *)wdev_get_dpp_driver_auth_type(akm), strlen(sec->auth));

	if (wdev->dev_type == WAPP_DEV_TYPE_AP)
		wapp_set_EncrypType(wapp, (const char *)wdev->ifname, (char *)"AES", 3);
	else
		wapp_set_apcli_EncrypType(wapp, (const char *)wdev->ifname, (char *)"AES", 3);
#else
	int ret = 0;
#ifndef MTK_HOSTAPD_SUPPORT
	char cmd[100];

	memset(cmd, 0, 100);
#endif /* MTK_HOSTAPD_SUPPORT */

#ifdef MAP_R3_6E_SUPPORT
	/* As 6G Band does not support WPA2PSK,
	 * so removing WPA2PSK security  for
	 * DPP Mixed modes.
	 */

	if (wdev->radio && IS_OP_CLASS_6G(wdev->radio->opclass)) {
		if (akm == DPP_AKM_PSK_SAE_DPP)
			akm = DPP_AKM_SAE_DPP;
		else if (akm == DPP_AKM_PSK_DPP)
			akm = DPP_AKM_DPP;
		else if (akm == DPP_AKM_PSK_SAE)
			akm = DPP_AKM_SAE;
#ifdef MAP_R6
		else if (akm == DPP_AKM_PSK_SAE24)
			akm = DPP_AKM_SAE24;
		else if (akm == DPP_AKM_PSK_SAE_SAE24_DPP)
			akm = DPP_AKM_SAE_SAE24_DPP;
		else if (akm == DPP_AKM_PSK_SAE_SAE24)
			akm = DPP_AKM_SAE_SAE24;
		else if (akm == DPP_AKM_PSK_SAE24_DPP)
			akm = DPP_AKM_SAE24_DPP;
#endif
	}
#endif

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
#ifndef MTK_HOSTAPD_SUPPORT
		ret = wapp->drv_ops->drv_set_auth_mode(wapp->drv_data, wdev->ifname, wdev_get_dpp_driver_auth_type(akm));
		if (ret < 0) {
			err(DEBUG_CAT_DPP, "set AuthMode, command failed.\n");
			return WAPP_INVALID_ARG;
		}
		 notice(DEBUG_CAT_DPP, "set AuthMode = %s\n", wdev_get_dpp_driver_auth_type(akm));
#endif /* MTK_HOSTAPD_SUPPORT */
	} else {
#ifdef MTK_HOSTAPD_SUPPORT
		ret = wdev_send_network_keymgmt(wapp, wdev, (const char *)wdev_get_dpp_supp_auth_type(akm));
		if (ret != WAPP_SUCCESS) {
			err(DEBUG_CAT_DPP, "wdev_send_network_keymgmt fail\n");
			return WAPP_INVALID_ARG;
		}
#else
		ret = os_snprintf(cmd, sizeof(cmd), "mwctl %s set ApCliAuthMode=%s", wdev->ifname, wdev_get_dpp_driver_auth_type(akm));
		if (os_snprintf_error(sizeof(cmd), ret)) {
			err(DEBUG_CAT_DPP, "os_snprintf fail\n");
			return WAPP_INVALID_ARG;
		}
#endif /* MTK_HOSTAPD_SUPPORT */
		if (dpp_akm_dpp(akm) && wapp->drv_ops->drv_set_auth_mode) {
			ret = wapp->drv_ops->drv_set_auth_mode(wapp->drv_data,
					wdev->ifname, wdev_get_dpp_driver_auth_type(akm));
			if (ret < 0) {
				err(DEBUG_CAT_DPP, "set AuthMode, command failed.\n");
				return WAPP_INVALID_ARG;
			}
			debug(DEBUG_CAT_DPP, "set AuthMode = %s\n", wdev_get_dpp_driver_auth_type(akm));
		}
	}

#ifndef MTK_HOSTAPD_SUPPORT
	if (system(cmd) == -1)
		err(DEBUG_CAT_DPP, "system() call return value is -1\n");

	memset(cmd, 0, 100);

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		ret = os_snprintf(cmd, sizeof(cmd), "wifi_config_save %s AuthMode %s", wdev->ifname, wdev_get_dpp_driver_auth_type(akm));
		if (os_snprintf_error(sizeof(cmd), ret)) {
			err(DEBUG_CAT_DPP, "os_snprintf fail\n");
			return WAPP_INVALID_ARG;
		}
	}

	if (system(cmd) == -1)
		err(DEBUG_CAT_DPP, "system() call return value is -1\n");

	memset(cmd, 0, 100);
#endif /* MTK_HOSTAPD_SUPPORT */
	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
#ifndef MTK_HOSTAPD_SUPPORT
		ret = wapp->drv_ops->drv_set_encrypt_type(wapp->drv_data, wdev->ifname, "AES");
		if (ret < 0) {
			err(DEBUG_CAT_MISC, "set EncrypType, command failed.\n");
			return WAPP_INVALID_ARG;
		}
		debug(DEBUG_CAT_DPP, "set EncrypType = AES\n");
#endif /* MTK_HOSTAPD_SUPPORT */
	} else {
#ifdef MTK_HOSTAPD_SUPPORT
		/* TODO: Milan add function provided by Saurabh
		 * and send Encryp type as string CCMP
		 * wpa_cli -i apcli0 set_network 0 pairwise CCMP
		 */
#else
		ret = os_snprintf(cmd, sizeof(cmd), "mwctl %s set ApCliEncrypType=AES", wdev->ifname);
		if (os_snprintf_error(sizeof(cmd), ret)) {
			err(DEBUG_CAT_DPP, "os_snprintf fail\n");
			return WAPP_INVALID_ARG;
		}
#endif /* MTK_HOSTAPD_SUPPORT */
	}

#ifndef MTK_HOSTAPD_SUPPORT
	if (system(cmd) == -1)
		err(DEBUG_CAT_DPP, "system() call return value is -1\n");

	memset(cmd, 0, 100);
	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		ret = os_snprintf(cmd, sizeof(cmd), "wifi_config_save %s EncrypType %s", wdev->ifname, "AES");
		if (os_snprintf_error(sizeof(cmd), ret)) {
			err(DEBUG_CAT_DPP, "os_snprintf fail\n");
			return WAPP_INVALID_ARG;
		}
	}
	if (system(cmd) == -1)
		err(DEBUG_CAT_DPP, "system() call return value is -1\n");
#endif /* MTK_HOSTAPD_SUPPORT */
#endif

	return WAPP_SUCCESS;
}
#endif /*DPP_SUPPORT*/

int wdev_set_ssid(struct wifi_app *wapp, struct wapp_dev *wdev, char *ssid)
{
	if (!wapp || !wdev || !ssid) {
		return WAPP_INVALID_ARG;
	}

	notice(DEBUG_CAT_WIFI_CONFIG,
		     "set ssid:\n"
		     "\t ifname = %s\n"
		     "\t ssid = %s\n",
		     wdev->ifname, ssid);

#ifdef MTK_HOSTAPD_SUPPORT
	int ret = 0;
	char param[64] = {0};

	/* Set SSID as per wireless setting */
	ret = os_snprintf(param, sizeof(param), "ssid");
	if (os_snprintf_error(sizeof(param), ret)) {
		err(DEBUG_CAT_WIFI_CONFIG, "os_snprintf fail\n");
		return -1;
	}
	wapp_uci_update(wdev->ifname, param, (char *)ssid);
#endif /* MTK_HOSTAPD_SUPPORT */
	if (wapp->drv_ops->drv_set_ssid)
		wapp->drv_ops->drv_set_ssid(wapp->drv_data, wdev->ifname, ssid,  wdev->network_id);


	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		struct ap_dev *ap = (struct ap_dev *)wdev->p_dev;
		os_strncpy(ap->bss_info.ssid, ssid, MAX_LEN_OF_SSID);
	}

	return WAPP_SUCCESS;
}

int wdev_set_psk(struct wifi_app *wapp, struct wapp_dev *wdev, char *psk)
{
	if (!wapp || !wdev || !psk) {
		return WAPP_INVALID_ARG;
	}

	notice(DEBUG_CAT_WIFI_CONFIG,
		     "set psk:\n"
		     "\t ifname = %s\n"
		     "\t psk = %s\n",
		     wdev->ifname, psk);
	wapp->drv_ops->drv_set_psk(wapp->drv_data, wdev->ifname, psk);

	return WAPP_SUCCESS;
}

int wdev_set_radio_onoff(struct wifi_app *wapp, struct wapp_dev *wdev, int onoff)
{
	if (!wapp || !wdev)
		return WAPP_INVALID_ARG;

	if (!wdev->radio)
		return WAPP_NOT_INITIALIZED;

	if (wdev->radio->onoff == onoff)
		return WAPP_SUCCESS;

#if 1
	if (onoff == RADIO_ON) {
		notice(DEBUG_CAT_WIFI_CONFIG,
			     GRN("set radio:\n"
				 "\t ifname = %s\n"
				 "\t onoff = %d\n"),
			     wdev->ifname, onoff);

	} else {
		notice(DEBUG_CAT_WIFI_CONFIG,
			     RED("set radio:\n"
				 "\t ifname = %s\n"
				 "\t onoff = %d\n"),
			     wdev->ifname, onoff);
	}
#endif
#if WEXT_SUPPORT
	wapp_set_radio_on(wapp, (const char *)wdev->ifname, (char *)&onoff, (size_t)sizeof(onoff));
#else
	int ret = 0;

	ret = wapp->drv_ops->drv_set_raido_on(wapp->drv_data, wdev->ifname, onoff);
	if (ret < 0) {
		err(DEBUG_CAT_MISC, "set RadioOn, command failed.\n");
		return WAPP_INVALID_ARG;
	}
	debug(DEBUG_CAT_WIFI_CONFIG, "set RadioOn = %d\n", onoff);
	wdev->radio->onoff = onoff;
#endif /* WEXT_SUPPORT */

	return WAPP_SUCCESS;
}

int wdev_set_bss_role(struct wifi_app *wapp, struct wapp_dev *wdev, unsigned char map_vendor_extension)
{
	struct ap_dev *ap = NULL;
	BOOLEAN need_disconnect = FALSE;
	u8 new_i_am_fh_bss = 0;
	u8 new_i_am_bh_bss = 0;
#ifdef MTK_HOSTAPD_SUPPORT
	static const u8 sta_mac[MAC_ADDR_LEN] = { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff };
#endif /* MTK_HOSTAPD_SUPPORT */

	if (!wdev) {
		return WAPP_INVALID_ARG;
	}

	ap = (struct ap_dev *)wdev->p_dev;

	new_i_am_fh_bss = (map_vendor_extension & (1 << MAP_ROLE_FRONTHAUL_BSS)) ? 1 : 0;
	new_i_am_bh_bss = (map_vendor_extension & (1 << MAP_ROLE_BACKHAUL_BSS)) ? 1 : 0;

	if ((wdev->i_am_fh_bss != new_i_am_fh_bss) || (wdev->i_am_bh_bss != new_i_am_bh_bss)) {
		need_disconnect = TRUE;
	}

	wdev->i_am_fh_bss = new_i_am_fh_bss;
	wdev->i_am_bh_bss = new_i_am_bh_bss;

	/* This info will be sent back to mapd */
	ap->bss_info.map_role = map_vendor_extension;

	notice(DEBUG_CAT_WIFI_CONFIG, "[%s] i_am_fh_bss %d , i_am_bh_bss %d, need_disconnect %d\n", wdev->ifname, wdev->i_am_fh_bss,
		 wdev->i_am_bh_bss, need_disconnect);

	/* Reset previous values for bh and fh bss */
#if WEXT_SUPPORT
	if (!wdev->i_am_fh_bss)
		wapp_set_fhbss(wapp, (const char *)wdev->ifname, (char *)&wdev->i_am_fh_bss, 1);
	if (!wdev->i_am_bh_bss)
		wapp_set_bhbss(wapp, (const char *)wdev->ifname, (char *)&wdev->i_am_bh_bss, 1);
	if (wdev->i_am_fh_bss)
		wapp_set_fhbss(wapp, (const char *)wdev->ifname, (char *)&wdev->i_am_fh_bss, 1);
	if (wdev->i_am_bh_bss)
		wapp_set_bhbss(wapp, (const char *)wdev->ifname, (char *)&wdev->i_am_bh_bss, 1);
	if (need_disconnect)
		wapp_set_DisConnectAllSta(wapp, (const char *)wdev->ifname, (char *)&need_disconnect, 1);
#else
	char cmd[256] = {0};
	int ret = 0;

	if (!wdev->i_am_fh_bss) {
		ret = wdev_set_ap_fhbss(wapp, wdev, 0);
		if (ret != WAPP_SUCCESS) {
			err(DEBUG_CAT_WIFI_CONFIG, "wdev_set_ap_fhbss fail\n");
			return WAPP_INVALID_ARG;
		}
	}

	if (!wdev->i_am_bh_bss) {
		ret = wdev_set_ap_bhbss(wapp, wdev, 0);
		if (ret != WAPP_SUCCESS) {
			err(DEBUG_CAT_WIFI_CONFIG, "wdev_set_ap_bhbss fail\n");
			return WAPP_INVALID_ARG;
		}
	}

	if (wdev->i_am_fh_bss) {
		ret = wdev_set_ap_fhbss(wapp, wdev, 1);
		if (ret != WAPP_SUCCESS) {
			err(DEBUG_CAT_WIFI_CONFIG, "wdev_set_ap_fhbss fail\n");
			return WAPP_INVALID_ARG;
		}
	}
	if (wdev->i_am_bh_bss) {
		ret = wdev_set_ap_bhbss(wapp, wdev, 1);
		if (ret != WAPP_SUCCESS) {
			err(DEBUG_CAT_WIFI_CONFIG, "wdev_set_ap_bhbss fail\n");
			return WAPP_INVALID_ARG;
		}
	}

	os_memset(cmd, 0, 256);
	if (need_disconnect) {
		err(DEBUG_CAT_WIFI_CONFIG, "In wapp need to disconnect all sta\n");
#ifdef MTK_HOSTAPD_SUPPORT
	/* command to hostapd to disconnect all STA */
	if (wapp->drv_ops->drv_send_sta_deauth)
		wapp->drv_ops->drv_send_sta_deauth(wapp->drv_data, wdev->ifname, (char *)sta_mac);

#else
		ret = os_snprintf(cmd, sizeof(cmd), "mwctl %s set DisConnectAllSta=;", wdev->ifname);
		if (os_snprintf_error(sizeof(cmd), ret)) {
			err(DEBUG_CAT_WIFI_CONFIG, "os_snprintf fail\n");
			return WAPP_INVALID_ARG;
		}
		if (system(cmd) == -1)
			err(DEBUG_CAT_WIFI_CONFIG, "system() call return value is -1\n");
#endif /* MTK_HOSTAPD_SUPPORT */
	}
#endif /* WEXT_SUPPORT */
	return WAPP_SUCCESS;
}

int wdev_set_hidden_ssid(struct wifi_app *wapp, struct wapp_dev *wdev, unsigned char hidden_ssid)
{
#ifndef MTK_HOSTAPD_SUPPORT
	char cmd[256] = {0};
	int ret = 0;
#endif /* MTK_HOSTAPD_SUPPORT */
	struct ap_dev *ap = NULL;


	if (!wdev) {
		return WAPP_INVALID_ARG;
	}

	ap = (struct ap_dev *)wdev->p_dev;
	ap->bss_info.hidden_ssid = hidden_ssid;

	notice(DEBUG_CAT_WIFI_CONFIG,
		 "set ifname = %s\n"
		 "\t hidessid = %d\n",
		 wdev->ifname, hidden_ssid);

#if WEXT_SUPPORT
	wapp_set_HideSSID(wapp, (const char *)wdev->ifname, (char *)&hidden_ssid, sizeof(hidden_ssid));
#else
#ifndef MTK_HOSTAPD_SUPPORT
	ret = wapp->drv_ops->drv_set_hidden_ssid(wapp->drv_data, wdev->ifname, hidden_ssid);
	if (ret < 0) {
		err(DEBUG_CAT_WIFI_CONFIG, "set HideSSID, command failed.\n");
		return WAPP_INVALID_ARG;
	}
	debug(DEBUG_CAT_WIFI_CONFIG, "set HideSSID = %d\n", hidden_ssid);
#else
	if (hidden_ssid) {
		if (wapp->drv_ops->drv_send_hide_ssid)
			wapp->drv_ops->drv_send_hide_ssid(wapp->drv_data, wdev->ifname, 1);
	} else {
		if (wapp->drv_ops->drv_send_hide_ssid)
			wapp->drv_ops->drv_send_hide_ssid(wapp->drv_data, wdev->ifname, 0);
	}
#endif /* MTK_HOSTAPD_SUPPORT */
#endif

#ifndef MTK_HOSTAPD_SUPPORT
	os_memset(cmd, 0, sizeof(cmd));
	ret = os_snprintf(cmd, sizeof(cmd), "wifi_config_save %s HideSSID %d", wdev->ifname, hidden_ssid);
	if (os_snprintf_error(sizeof(cmd), ret)) {
		err(DEBUG_CAT_WIFI_CONFIG, "os_snprintf fail\n");
		return WAPP_INVALID_ARG;
	}
	if (system(cmd) == -1)
		err(DEBUG_CAT_WIFI_CONFIG, "system() call return value is -1\n");
#else
	/* TODO: Add hidden ssid set in hostapd config file */
#endif /* MTK_HOSTAPD_SUPPORT */

	return WAPP_SUCCESS;
}
void wdev_he_cap_query_rsp_handle(struct wifi_app *wapp, u32 ifindex, wdev_he_cap *he_cap_rcvd)
{
	struct wapp_dev *wdev = NULL;

	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);

	if (!wdev)
		return;

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		struct ap_dev *ap = (struct ap_dev *)wdev->p_dev;
		wdev_he_cap *he_cap;
		he_cap = &ap->he_cap;
		os_memcpy(he_cap, he_cap_rcvd, sizeof(wdev_he_cap));
	}
}
#ifdef MTK_MLO_MAP_SUPPORT
void wdev_mlo_cap_query_rsp_handle(struct wifi_app *wapp, u32 ifindex, struct wdev_mlo_caps *mlo_cap_rcvd)
{
	struct wapp_dev *wdev = NULL;
	int i = 0;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev) {
		err(DEBUG_CAT_MLO, "can't find wdev by ifindex(%d)", ifindex);
		return;
	}

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		struct ap_dev *ap = (struct ap_dev *)wdev->p_dev;
		struct wdev_mlo_caps *mlo_cap;

		mlo_cap = &ap->mlo_cap;
		mlo_cap->RoleNum = mlo_cap_rcvd->RoleNum;
		if (mlo_cap_rcvd->RoleNum > MAX_ROLE_NUM) {
			err(DEBUG_CAT_NL80211, "RoleNum(%d) for wdev %s > MAX_ROLE_NUM(%d)", mlo_cap_rcvd->RoleNum,
				wdev->ifname, MAX_ROLE_NUM);
			return;
		}
		for (i = 0; i < mlo_cap_rcvd->RoleNum && i < MAX_ROLE_NUM; i++) {
			mlo_cap->MloCapPerRole[i].DeviceRole = mlo_cap_rcvd->MloCapPerRole[i].DeviceRole;
			mlo_cap->MloCapPerRole[i].StatPunctureSupport = mlo_cap_rcvd->MloCapPerRole[i].StatPunctureSupport;
			mlo_cap->MloCapPerRole[i].MloEnable = mlo_cap_rcvd->MloCapPerRole[i].MloEnable;
			os_memcpy(&mlo_cap->MloCapPerRole[i].EmlCap, &mlo_cap_rcvd->MloCapPerRole[i].EmlCap, sizeof(struct eml_caps_info));
			os_memcpy(&mlo_cap->MloCapPerRole[i].MldCap, &mlo_cap_rcvd->MloCapPerRole[i].MldCap, sizeof(struct mld_caps_info));
		}
	}
}
#endif

#ifdef MAP_EHT_SUPPORT
void wdev_eht_cap_query_rsp_handle(struct wifi_app *wapp, u32 ifindex, struct wdev_eht_cap *eht_cap_rcvd)
{
	struct wapp_dev *wdev = NULL;
	struct wapp_dev *wdev_temp = NULL, *wdev_tmp = NULL;
	struct dl_list *dev_list;

	dev_list = &wapp->dev_list;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev) {
		err(DEBUG_CAT_NL80211, "can't find wdev by ifindex(%d)", ifindex);
		return;
	}

	dl_list_for_each_safe(wdev_temp, wdev_tmp, dev_list, struct wapp_dev, list) {
		if (wdev_temp->p_dev == NULL || !wdev_temp->radio) {
			err(DEBUG_CAT_NL80211, "invalid input parameters\n");
			continue;
		}

		if (wdev_temp->dev_type != WAPP_DEV_TYPE_AP) {
			err(DEBUG_CAT_NL80211, "wdev type invalid %d\n", wdev_temp->dev_type);
			continue;
		}

		if (wdev_temp->radio->radio_band != wdev->radio->radio_band)
			continue;

		struct ap_dev *ap = (struct ap_dev *)wdev_temp->p_dev;
		struct wdev_eht_cap *eht_cap;

		eht_cap = &ap->eht_cap;
		os_memcpy(eht_cap, eht_cap_rcvd, sizeof(struct wdev_eht_cap));
		if (eht_cap->ccfs0 > eht_cap->ccfs1)
			wdev_temp->HE_EXTCHA = 0;
		else
			wdev_temp->HE_EXTCHA = 1;
	}
}
#endif
void wdev_tx_pwr_query_rsp_handle(struct wifi_app *wapp, u32 ifindex, wdev_tx_power *tx_pwr_rcvd)
{
	struct wapp_dev *wdev = NULL;
	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev) {
		err(DEBUG_CAT_NL80211, "can't find wdev by ifindex(%d)", ifindex);
		return;
	}
	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		struct ap_dev *ap = (struct ap_dev *)wdev->p_dev;
		wdev_tx_power *tx_pwr;
		int i = 0;
		tx_pwr = &ap->pwr;
		os_memcpy(tx_pwr, tx_pwr_rcvd, sizeof(wdev_tx_power));
		for (i = 0; i < tx_pwr->num_of_op_class; i++) {
			/* For 2.4G channels the max power should be 30 as per
			 * spec, bt driver provides max power with EIRP as 36
			 */
#ifdef EM_PLUS_SUPPORT
			if (tx_pwr->tx_pwr_limit[i].max_pwr > 30)
				tx_pwr->tx_pwr_limit[i].max_pwr -= 6;
#endif /* EM_PLUS_SUPPORT */
		}
	}
}

void wdev_tx_pwr_query_rsp_handle_ext(struct wifi_app *wapp, u32 ifindex, struct _wdev_tx_power_ext *tx_pwr_rcvd)
{
	struct wapp_dev *wdev = NULL;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev) {
		err(DEBUG_CAT_NL80211, "can't find wdev by ifindex(%d)", ifindex);
		return;
	}

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		struct ap_dev *ap = (struct ap_dev *)wdev->p_dev;
		struct _wdev_tx_power_ext *tx_pwr;
		int i = 0;

		tx_pwr = &ap->tx_pwr_ext;
		os_memcpy(tx_pwr, tx_pwr_rcvd, sizeof(struct _wdev_tx_power_ext));

		for (i = 0; i < tx_pwr->num_of_op_class; i++) {
			/* For 2.4G channels the max power should be 30 as per
			 * spec, bt driver provides max power with EIRP as 36
			 */
#ifdef EM_PLUS_SUPPORT
			if (tx_pwr->tx_pwr_limit[i].max_pwr > 30)
				tx_pwr->tx_pwr_limit[i].max_pwr -= 6;
#endif /* EM_PLUS_SUPPORT */
#ifdef CH_TXPWR_SUPPORT
			int j = 0;

			for (j = 0; j < tx_pwr->tx_pwr_limit[i].ch_num; j++) {
				debug(DEBUG_CAT_NL80211, "Power:%u, channel:%u\n",
				tx_pwr->tx_pwr_limit[i].ch_pwr[j].pwrlimit,
				tx_pwr->tx_pwr_limit[i].ch_pwr[j].channel);
			}
#endif
		}
#ifdef CH_TXPWR_SUPPORT
		if (tx_pwr->tx_power_set == 1 && tx_pwr->band == BAND_2GHZ) {
			notice(DEBUG_CAT_NL80211, "TX POWER 2G\n");
			os_memcpy(&wapp->pwr_2g, tx_pwr_rcvd, sizeof(struct _wdev_tx_power_ext));
		} else if (tx_pwr->tx_power_set == 1 && tx_pwr->band == BAND_5GHZ) {
			notice(DEBUG_CAT_NL80211, "TX POWER 5G\n");
			os_memcpy(&wapp->pwr_5g, tx_pwr_rcvd, sizeof(struct _wdev_tx_power_ext));
		} else if (tx_pwr->tx_power_set == 1 && tx_pwr->band == BAND_6GHZ) {
			notice(DEBUG_CAT_NL80211, "TX POWER 6G\n");
			os_memcpy(&wapp->pwr_6g, tx_pwr_rcvd, sizeof(struct _wdev_tx_power_ext));
		}
#endif
	}
}

#ifdef MAP_R3_WF6
void print_wf6(wdev_wf6_cap_roles *wf6_cap)
{
#if 0
	int i = 0;

	notice(DEBUG_CAT_MISC, "WF6:WAPPD: wf6_cap->role_supp = %d\n", wf6_cap->role_supp);
	for (; i < wf6_cap->role_supp; i++) {
		notice_np(DEBUG_CAT_MISC, "WF6:WAPPD: wf6_cap->wf6_role[i].tx_stream = %d\n", wf6_cap->wf6_role[i].tx_stream);
		notice_np(DEBUG_CAT_MISC, "WF6:WAPDD: wf6_cap->wf6_role[i].rx_stream = %d\n", wf6_cap->wf6_role[i].rx_stream);
		notice_np(DEBUG_CAT_MISC, "WF6:WAPPD: wf6_cap->wf6_role[i].he_mcs_len = %d\n", wf6_cap->wf6_role[i].he_mcs_len);
		notice_np(DEBUG_CAT_MISC, "WF6:WAPPD: wf6_cap->wf6_role[i].su_bf_cap = %d\n", wf6_cap->wf6_role[i].su_bf_cap);
		notice_np(DEBUG_CAT_MISC, "WF6:WAPPD: wf6_cap->wf6_role[i].mu_bf_cap = %d\n", wf6_cap->wf6_role[i].mu_bf_cap);
		notice_np(DEBUG_CAT_MISC, "WF6:WAPPD: wf6_cap->wf6_role[i].dl_mu_mimo_ofdma_cap = %d\n", wf6_cap->wf6_role[i].dl_mu_mimo_ofdma_cap);
		notice_np(DEBUG_CAT_MISC, "WF6:WAPPD: wf6_cap->wf6_role[i].ul_mu_mimo_ofdma_cap = %d\n", wf6_cap->wf6_role[i].ul_mu_mimo_ofdma_cap);
		notice_np(DEBUG_CAT_MISC, "WF6:WAPPD: wf6_cap->wf6_role[i].ul_mu_mimo_cap = %d\n", wf6_cap->wf6_role[i].ul_mu_mimo_cap);
		notice_np(DEBUG_CAT_MISC, "WF6:WAPPD: wf6_cap->wf6_role[i].agent_role = %d\n", wf6_cap->wf6_role[i].agent_role);
		notice_np(DEBUG_CAT_MISC, "WF6:WAPDD: wf6_cap->wf6_role[i].su_beamformee_status = %d\n", wf6_cap->wf6_role[i].su_beamformee_status);
		notice_np(DEBUG_CAT_MISC, "WF6:WAPPD: wf6_cap->wf6_role[i].beamformee_sts_less80 = %d\n", wf6_cap->wf6_role[i].beamformee_sts_less80);
		notice_np(DEBUG_CAT_MISC, "WF6:WAPPD: wf6_cap->wf6_role[i].beamformee_sts_more80 = %d\n", wf6_cap->wf6_role[i].beamformee_sts_more80);
		notice_np(DEBUG_CAT_MISC, "WF6:WAPPD: wf6_cap->wf6_role[i].max_user_dl_tx_mu_mimo = %d\n", wf6_cap->wf6_role[i].max_user_dl_tx_mu_mimo);
		notice_np(DEBUG_CAT_MISC, "WF6:WAPPD: wf6_cap->wf6_role[i].max_user_ul_rx_mu_mimo = %d\n", wf6_cap->wf6_role[i].max_user_ul_rx_mu_mimo);
		notice_np(DEBUG_CAT_MISC, "WF6:WAPPD: wf6_cap->wf6_role[i].max_user_dl_tx_ofdma = %d\n", wf6_cap->wf6_role[i].max_user_dl_tx_ofdma);
		notice_np(DEBUG_CAT_MISC, "WF6:WAPPD: wf6_cap->wf6_role[i].max_user_ul_rx_ofdma =%d\n", wf6_cap->wf6_role[i].max_user_ul_rx_ofdma);
		notice_np(DEBUG_CAT_MISC, "WF6:WAPPD: wf6_cap->wf6_role[i].rts_status = %d\n", wf6_cap->wf6_role[i].rts_status);
		notice_np(DEBUG_CAT_MISC, "WF6:WAPPD: wf6_cap->wf6_role[i].mu_rts_status = %d\n", wf6_cap->wf6_role[i].mu_rts_status);
		notice_np(DEBUG_CAT_MISC, "WF6:WAPPD: wf6_cap->wf6_role[i].m_bssid_status = %d\n", wf6_cap->wf6_role[i].m_bssid_status);
		notice_np(DEBUG_CAT_MISC, "WF6:WAPPD: wf6_cap->wf6_role[i].mu_edca_status = %d\n", wf6_cap->wf6_role[i].mu_edca_status);
		notice_np(DEBUG_CAT_MISC, "WF6:WAPPD: wf6_cap->wf6_role[i].twt_requester_status = %d\n", wf6_cap->wf6_role[i].twt_requester_status);
		notice_np(DEBUG_CAT_MISC, "WF6:WAPPD: wf6_cap->wf6_role[i].twt_responder_status = %d\n", wf6_cap->wf6_role[i].twt_responder_status);
		notice_np(DEBUG_CAT_MISC, "WF6:WAPPD: wf6_cap->wf6_role[i].ul_ofdma_cap = %d\n", wf6_cap->wf6_role[i].ul_ofdma_cap);
		notice_np(DEBUG_CAT_MISC, "WF6:WAPPD: wf6_cap->wf6_role[i].dl_ofdma_cap = %d\n", wf6_cap->wf6_role[i].dl_ofdma_cap);
	}
#endif
}

void wdev_wf6_cap_query_rsp_handle(struct wifi_app *wapp, u32 ifindex, wdev_wf6_cap_roles *wf6_cap_rcvd)
{
	struct wapp_dev *wdev = NULL;

	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev)
		return;

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		struct ap_dev *ap = (struct ap_dev *)wdev->p_dev;
		wdev_wf6_cap_roles *wf6_cap;
		wf6_cap = &ap->wf6_cap;
		os_memcpy(wf6_cap, wf6_cap_rcvd, sizeof(wdev_wf6_cap_roles));
#if 0
		 notice(DEBUG_CAT_MISC,
				"he_cap (%u):\n"
				"\t tx_stream = %u, rx_stream = %u, he_160 = %u, he_8080 = %u, he_mcs_len = %u\n",
				ifindex,
				wf6_cap->tx_stream,
				wf6_cap->rx_stream,
				wf6_cap->he_160,
				wf6_cap->he_8080,
				wf6_cap->he_mcs_len)
#endif
	}
}
#endif /*MAP_R3_WF6*/

void wdev_handle_cac_period(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL;
	int send_pkt_len = 0;
	char *buf = NULL;

	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev)
		return;

	send_pkt_len = sizeof(struct _wapp_cac_info);
	buf = os_zalloc(send_pkt_len);
	if (buf) {
		os_memcpy(buf, &event_data->cac_info, send_pkt_len);
		debug(DEBUG_CAT_WIFI_CONFIG, "cac_enable:%d\n", event_data->cac_info.ret);
		wapp_send_1905_msg(wapp, WAPP_CAC_PERIOD_ENABLE, send_pkt_len, buf);
		os_free(buf);
	}
}

#ifdef LOW_POWER_SUPPORT
void wdev_handle_no_sta_connect_timeout(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL;
	struct low_power_status low_power;
	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev)
		return;

	low_power.status = WAPP_LOW_POWER_NO_STA_CONNECT_TIMEOUT;

	wapp_send_1905_msg(wapp, WAPP_LOW_POWER_NOTIF, sizeof(struct low_power_status), (char *)&low_power);
}

void wdev_handle_no_traffic_timeout(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL;
	struct low_power_status low_power;
	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev)
		return;

	low_power.status = WAPP_LOW_POWER_NO_DATA_TRAFFIC_TIMEOUT;

	wapp_send_1905_msg(wapp, WAPP_LOW_POWER_NOTIF, sizeof(struct low_power_status), (char *)&low_power);
}

void wdev_handle_wifi_open(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct low_power_status low_power;
	if (!wapp)
		return;

	low_power.status = WAPP_LOW_POWER_WIFI_ON;

	wapp_send_1905_msg(wapp, WAPP_LOW_POWER_NOTIF, sizeof(struct low_power_status), (char *)&low_power);
}

void wdev_handle_wifi_close(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct low_power_status low_power;
	if (!wapp)
		return;

	low_power.status = WAPP_LOW_POWER_WIFI_OFF;

	wapp_send_1905_msg(wapp, WAPP_LOW_POWER_NOTIF, sizeof(struct low_power_status), (char *)&low_power);
}
#endif

#ifdef MAP_R4_SPT
void wdev_handle_uplink_traffic_event(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL;
	struct os_time now, diff;

	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev)
		return;

	struct ap_dev *ap = (struct ap_dev *)wdev->p_dev;
	if (ap == NULL)
		return;
	struct wapp_mesh_sr_info *spt_reuse_info;
	struct uplink_traffic_status up_traffic_status;
	spt_reuse_info = &ap->sr_info;
	if (spt_reuse_info->sr_mode == 0)
		return;

	spt_reuse_info->ul_traffic_status = event_data->mesh_sr_info.ul_traffic_status;
	up_traffic_status.band = *wdev->radio->radio_band;
	up_traffic_status.status = event_data->mesh_sr_info.ul_traffic_status;
	debug(DEBUG_CAT_STATS,
		 GRN("handle uplink event") "ifindex %d"
					    "band %d status %d \n",
		 ifindex, up_traffic_status.band, up_traffic_status.status);
	os_get_time(&now);
	os_time_sub(&now, &wdev->last_sr_time, &diff);
	/* Only send event to map after 1 second */
	if (diff.sec >= 1) {
		wdev->last_sr_time = now;
		debug(DEBUG_CAT_STATS, "Sending type=d1 to mapd\n");
		wapp_send_1905_msg(wapp, WAPP_UPLINK_TRAFFIC_STATUS, sizeof(struct uplink_traffic_status), (char *)&up_traffic_status);
	}
}

void wdev_handle_self_srg_bm_event(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL;
	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);

	if (!wdev)
		return;

	struct ap_dev *ap = (struct ap_dev *)wdev->p_dev;
	if (ap == NULL)
		return;
	struct wapp_mesh_sr_info *spt_reuse_info;
	spt_reuse_info = &ap->sr_info;

	if (spt_reuse_info->sr_mode == 0)
		return;

	os_memcpy(&spt_reuse_info->bm_info, &event_data->mesh_sr_info.bm_info, sizeof(struct wapp_srg_bitmap));

	notice(DEBUG_CAT_SR, GRN("wapp bm") "ifindex %u Color:[63_32][0x%4x]-[31_0 [0x%4x] \
			PBssid::[63_32][0x%4x]-[31_0][0x%4x]",
		     ifindex, spt_reuse_info->bm_info.color_63_32, spt_reuse_info->bm_info.color_31_0, spt_reuse_info->bm_info.bssid_63_32,
		     spt_reuse_info->bm_info.bssid_31_0);

	if (wapp->map->my_map_dev_role == DEVICE_ROLE_CONTROLLER)
		map_send_ch_select_req_info(wapp, wdev);
	else
		map_operating_channel_info(wapp);
}

void wdev_spt_reuse_query_rsp_handle(struct wifi_app *wapp, u32 ifindex, struct wapp_mesh_sr_info *spl_reuse_rcvd)
{
	struct wapp_dev *wdev = NULL;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev) {
		err(DEBUG_CAT_NL80211, "can't find wdev by ifindex(%d)", ifindex);
		return;
	}

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		struct ap_dev *ap = (struct ap_dev *)wdev->p_dev;
		struct wapp_mesh_sr_info *mesh_sr_info;

		mesh_sr_info = &ap->sr_info;
		os_memcpy(mesh_sr_info, spl_reuse_rcvd, sizeof(struct wapp_mesh_sr_info));
	}
}
#endif

#ifdef STANDARD_NL_CMD
struct opclass gl_op[] = {
	{81, FREQ_2G_START, CHAN_WIDTH_20, BAND_2GHZ, 13, {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13} },
	{82, FREQ_2G_START, CHAN_WIDTH_20, BAND_2GHZ, 1, {14} },
	{83, FREQ_2G_START, CHAN_WIDTH_40P, BAND_2GHZ, 9, {1, 2, 3, 4, 5, 6, 7, 8, 9} },
	{84, FREQ_2G_START, CHAN_WIDTH_40M, BAND_2GHZ, 9, {5, 6, 7, 8, 9, 10, 11, 12, 13} },
	{115, FREQ_5G_START, CHAN_WIDTH_20, BAND_5GHZ, 4, {36, 40, 44, 48} },
	{116, FREQ_5G_START, CHAN_WIDTH_40P, BAND_5GHZ, 2, {36, 44} },
	{117, FREQ_5G_START, CHAN_WIDTH_40M, BAND_5GHZ, 2, {40, 48} },
	{118, FREQ_5G_START, CHAN_WIDTH_20, BAND_5GHZ, 4, {52, 56, 60, 64} },
	{119, FREQ_5G_START, CHAN_WIDTH_40P, BAND_5GHZ, 2, {52, 60} },
	{120, FREQ_5G_START, CHAN_WIDTH_40M, BAND_5GHZ, 2, {56, 64} },
	{121, FREQ_5G_START, CHAN_WIDTH_20, BAND_5GHZ, 12, {100, 104, 108, 112, 116, 120, 124, 128, 132, 136, 140, 144} },
	{122, FREQ_5G_START, CHAN_WIDTH_40P, BAND_5GHZ, 6, {100, 108, 116, 124, 132, 140} },
	{123, FREQ_5G_START, CHAN_WIDTH_40M, BAND_5GHZ, 6, {104, 112, 120, 128, 136, 144} },
	{125, FREQ_5G_START, CHAN_WIDTH_20, BAND_5GHZ, 8, {149, 153, 157, 161, 165, 169, 173, 177} },
	{126, FREQ_5G_START, CHAN_WIDTH_40P, BAND_5GHZ, 4, {149, 157, 165, 173} },
	{127, FREQ_5G_START, CHAN_WIDTH_40M, BAND_5GHZ, 4, {153, 161, 169, 177} },
	{128, FREQ_5G_START, CHAN_WIDTH_80, BAND_5GHZ, 7, {42, 58, 106, 122, 138, 155, 171} },
	{129, FREQ_5G_START, CHAN_WIDTH_160, BAND_5GHZ, 3, {50, 114, 163} },
	{131, FREQ_6G_START, CHAN_WIDTH_20, BAND_6GHZ, 59, {1, 5, 9, 13, 17, 21, 25, 29, 33, 37, 41, 45, 49,
		53, 57, 61, 65, 69, 73, 77, 81, 85, 89, 93, 97, 101, 105, 109, 113, 117, 121,
		125, 129, 133, 137, 141, 145, 149, 153, 157, 161, 165, 169, 173, 177, 181, 185,
		189, 193, 197, 201, 205, 209, 213, 217, 221, 225, 229, 233} },
	{132, FREQ_6G_START, CHAN_WIDTH_40P | CHAN_WIDTH_40M, BAND_6GHZ, 29, {3, 11, 19, 27, 35, 43,
		51, 59, 67, 75, 83, 91, 99, 107, 115, 123, 131, 139, 147, 155, 163, 171,
		179, 187, 195, 203, 211, 219, 227} },
	{133, FREQ_6G_START, CHAN_WIDTH_80, BAND_6GHZ, 14, {7, 23, 39, 55, 71, 87, 103, 119, 135, 151, 167, 183, 199, 215} },
	{134, FREQ_6G_START, CHAN_WIDTH_160, BAND_6GHZ, 7, {15, 47, 79, 111, 143, 175, 207} },
	{137, FREQ_6G_START, CHAN_WIDTH_320, BAND_6GHZ, 6, {31, 63, 95, 127, 159, 191} },
};


unsigned char get_40bw_by_freq(unsigned int freq, unsigned int cent_freq)
{
	if (freq > FREQ_6G_START)
		return CHAN_WIDTH_40P | CHAN_WIDTH_40M;
	else if (freq > cent_freq)
		return CHAN_WIDTH_40M;
	else
		return CHAN_WIDTH_40P;
}

unsigned char abs_ch(unsigned char ch, unsigned char ch1)
{
	if (ch > ch1)
		return ch - ch1;
	else
		return ch1 - ch;
}

unsigned char get_band_by_mode(unsigned char mode)
{
	if (mode & WMODE_B)
		return BAND_2GHZ;
	else if (mode & WMODE_A)
		return BAND_5GHZ;
	else
		return BAND_6GHZ;
}

unsigned char get_opclass_by_band_bw_ch(unsigned char band, unsigned char bw,
	unsigned char ch)
{
	struct opclass *op = NULL;
	unsigned char i = 0, j = 0;
	unsigned char cnt = 0;

	cnt = ARRAY_SIZE(gl_op);
	for (i = 0; i < cnt; i++) {
		op = &gl_op[i];
		if (op->bw != bw)
			continue;
		if (op->band != band)
			continue;
		/* workaround, because ch = primary channel, op->ch[j] is the central channel, we
		 * cannot get op class if our bw is operating on 80MHz, 160MHz and 320MHz. so if we are
		 * operating on 80MHz, 160MHz or 320MHz, return it's operating class directly.
		 */
		if ((op->bw == (CHAN_WIDTH_40P | CHAN_WIDTH_40M)) ||
			(op->bw == CHAN_WIDTH_80) ||
			(op->bw == CHAN_WIDTH_160) ||
			(op->bw == CHAN_WIDTH_320))
			return op->global_class;
		for (j = 0; j < op->ch_num; j++)
			if (op->ch[j] == ch)
				return op->global_class;
	}

	return 0;
}

unsigned char check_primary_ch_in_gl_op(unsigned char ch)
{
	u8 i = 0, j = 0;
	u8 cnt = 0;
	struct opclass *op = NULL;

	cnt = ARRAY_SIZE(gl_op);
	for (i = 0; i < cnt; i++) {
		op = &gl_op[i];
		if (op->bw != CHAN_WIDTH_20)
			continue;
		for (j = 0; j < op->ch_num; j++) {
			if (op->ch[j] == ch)
				return 1;
		}
	}

	return 0;
}

#ifdef MAP_6E_SUPPORT
char *get_band_str_6e(unsigned char band, char *buf, int max_len)
{
	int ret = 0, len = 0;
	unsigned char i = 0;

	if (band == 0)
		return "INVALID";

	while (band) {
		if ((band & BIT(i)) == 0) {
			i++;
			if (i == 3)
				break;
			continue;
		}
		switch (BIT(i)) {
		case MAP_BAND_2G:
			ret = snprintf(buf + len, max_len - len, "|%s", "2G");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf error\n");
				return "INVALID_AUTH";
			}
			len += ret;
			break;
		case MAP_BAND_5GL:
			ret = snprintf(buf + len, max_len - len, "|%s", "5G");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf error\n");
				return "INVALID_AUTH";
			}
			len += ret;
			break;
		case MAP_BAND_6G:
			ret = snprintf(buf + len, max_len - len, "|%s", "6G");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf error\n");
				return "INVALID_AUTH";
			}
			len += ret;
			break;
		default:
			return "INVALID";
		}
		i++;
		if (i == 3)
			break;
	}

	return buf;
}

#endif

int dump_chan_list(struct wifi_app *wapp, char *buf, size_t max_len)
{
	unsigned char i = 0, j = 0, k = 0, cnt = 0;
	struct chnList *ch = NULL;
	int ret = 0, len = 0;
#ifdef MAP_6E_SUPPORT
	struct AutoCHSkipList_band *skiplist = &wapp->skiplist;
	char buf1[128] = {0};
#endif
	struct wapp_dev *wdev = NULL;
	struct ap_dev *ap = NULL;
	struct wapp_radio *ra = NULL;
	unsigned char id[MAC_ADDR_LEN] = {0};
	wdev_chn_info *chn_list = NULL;

	ret = snprintf(buf + len, max_len - len, "\nch info:\n");
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	for (i = 0; i < MAX_NUM_OF_RADIO; i++) {
		ra = &wapp->radio[i];
		if (!ra->adpt_id)
			continue;
		MAP_GET_RADIO_IDNFER(ra, id);
		dl_list_for_each(wdev, &wapp->dev_list, struct wapp_dev, list) {
			if (ra == wdev->radio && wdev->valid == 1 &&
				wdev->dev_type == WAPP_DEV_TYPE_AP)
				break;
		}
		if (!wdev) {
			err(DEBUG_CAT_MISC, "no valid ap wdev for raid "MACSTR"\n",
				MAC2STR(id));
			return -1;
		}
		ap = (struct ap_dev *)wdev->p_dev;
		chn_list = &ap->ch_info;

		ret = snprintf(buf + len, max_len - len,
			"\traid="MACSTR"; op_ch=%d; op_class=%d; op_band=%d; dl_mcs=%d\n",
			MAC2STR(id), chn_list->op_ch, chn_list->op_class, chn_list->band, chn_list->dl_mcs);
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;

		cnt = ARRAY_SIZE(chn_list->ch_list);
		ret = snprintf(buf + len, max_len - len, "\t ch_num=%d; max_ch_num=%d",
			chn_list->ch_list_num, cnt);
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;

		for (j = 0; j < chn_list->ch_list_num && j < cnt; j++) {
			ch = &chn_list->ch_list[j];
			ret = snprintf(buf + len, max_len - len,
				"\n\t  channel=%d; pref=%d; cac_timer=%d\n",
				ch->channel, ch->pref, ch->cac_timer);
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf fail\n");
				return -1;
			}
			len += ret;
		}

		cnt = ARRAY_SIZE(chn_list->non_op_ch_list);
		ret = snprintf(buf + len, max_len - len,
			"\t non_op_ch_num(%d); max_non_op_ch_num(%d); non_op_ch=",
			chn_list->non_op_chn_num, cnt);
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;
		for (j = 0; j < chn_list->non_op_chn_num && j < cnt; j++) {
			ret = snprintf(buf + len, max_len - len, "%d ", chn_list->non_op_ch_list[j]);
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf fail\n");
				return -1;
			}
			len += ret;
		}
		ret = snprintf(buf + len, max_len - len, "\n");
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;
#ifdef MAP_6E_SUPPORT
		ret = snprintf(buf + len, max_len - len,
			"\t AutoChannelSkipList info: valid_bands=%d(%s); total_skipch=%d\n",
			skiplist->valid_bands, get_band_str_6e(skiplist->valid_bands, buf1, 128),
			skiplist->total_skipch);
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;
		for (j = 0; j < MAX_NUM_OF_RADIO; j++) {
			if (skiplist->skiplist[j].band == 0)
				continue;
			ret = snprintf(buf + len, max_len - len, "\t  band=%d(%s); AutoChannelSkipListNum=%d; List=\n",
				skiplist->skiplist[j].band, get_band_str_6e(skiplist->skiplist[j].band, buf1, 128),
				skiplist->skiplist[j].AutoChannelSkipListNum);
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf fail\n");
				return -1;
			}
			len += ret;
			for (k = 0; k < skiplist->skiplist[j].AutoChannelSkipListNum; k++) {
				ret = snprintf(buf + len, max_len - len, "%d ",
					skiplist->skiplist[j].AutoChannelSkipList[k]);
				if (os_snprintf_error(max_len - len, ret)) {
					err(DEBUG_CAT_MISC, "snprintf fail\n");
					return -1;
				}
				len += ret;
			}
			ret = snprintf(buf + len, max_len - len, "\n");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf fail\n");
				return -1;
			}
			len += ret;
		}
	}
#endif

	return len;
}

void assign_wdev_chan_list(struct wifi_app *wapp, struct dev_info *dev, struct phy_info *phy)
{
#define OP_DISALLOWED_DUE_TO_DFS  (BIT(0)|BIT(1)|BIT(2))

	struct wapp_dev *wdev = NULL;
	struct ap_dev *ap = NULL;
	u8 i = 0, j = 0, cnt = 0;
	wdev_chn_info *chn_list = NULL;
	struct channel_data *channel = NULL;
	u8 ret = 0;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, dev->ifindex);
	if (!wdev) {
		err(DEBUG_CAT_CHANNEL, "can't find wdev by ifindex-%d\n", dev->ifindex);
		return;
	}
	if (wdev->dev_type != WAPP_DEV_TYPE_AP) {
		err(DEBUG_CAT_CHANNEL, "dev %s is not ap\n", dev->ifname);
		return;
	}
	ap = (struct ap_dev *)wdev->p_dev;
	if (!ap) {
		err(DEBUG_CAT_CHANNEL, "struct ap_dev not created for %s\n", dev->ifname);
		return;
	}

	if (!ap->isActive) {
		err(DEBUG_CAT_CHANNEL, "wdev %s is inactive\n", dev->ifname);
		return;
	}

	chn_list = &ap->ch_info;
	chn_list->band = get_band_by_mode(phy->mode);
	chn_list->op_ch = dev->ch;
	chn_list->op_class = get_opclass_by_band_bw_ch(chn_list->band, dev->bw, chn_list->op_ch);
	if (!chn_list->op_class) {
		err(DEBUG_CAT_CHANNEL, "can't find opclass for chn_list->band=%d, ch-%d bw-%d\n",
			chn_list->band, dev->ch, dev->bw);
		return;
	}
#ifdef MAP_6E_SUPPORT
	wdev->radio->opclass = chn_list->op_class;
#endif

	wapp_radio_update_ch(wapp, wdev->radio, dev->ch);
	wapp_refine_phy_channels(wapp, wdev->radio, phy);

#ifdef MAP_R3_6E_SUPPORT
	/* If dpp is init then set 6e variable for CCE control */
	if (wapp->dpp) {
		if (IS_OP_CLASS_6G(wdev->radio->opclass))
			wapp->dpp->wdev_6e_support = 1;
	}
#endif /* MAP_R3_6E_SUPPORT */

	cnt = MAX_NUM_OF_CHANNELS;
	for (i = 0; i < phy->num_channels; i++) {
		channel = &phy->channels[i];
		if (is_bit_set(channel->flag, CHAN_DISABLED)) {
			ret = check_primary_ch_in_gl_op(channel->chan);
			if (ret)
				chn_list->non_op_ch_list[chn_list->non_op_chn_num++] = channel->chan;
		} else {
			if (j < cnt) {
				chn_list->ch_list[j].channel = channel->chan;
				if (channel->flag & CHAN_RADAR) {
					chn_list->ch_list[j].pref = OP_DISALLOWED_DUE_TO_DFS;
					chn_list->ch_list[j].cac_timer = channel->dfs_cac_ms / 1000;
				}
				if (channel->chan == dev->ch)
					chn_list->ch_list[j].pref = PREF_SCORE_14;
				j++;
			}
		}
	}
	chn_list->ch_list_num = j;
}

void assign_full_opclass_to_wdev(
#ifndef MAP_6E_SUPPORT
	wdev_op_class_info *op_class,
#else
	struct _wdev_op_class_info_ext *op_class,
#endif
	unsigned char band)
{
	u8 i = 0, j = 0;
	u8 cnt = 0;
	struct opclass *op = NULL;

	cnt = ARRAY_SIZE(gl_op);
	for (i = 0; i < cnt; i++) {
		op = &gl_op[i];
		if (op->band != band)
			continue;
#ifndef MAP_6E_SUPPORT
		op_class->opClassInfo[j].op_class = op->global_class;
		op_class->opClassInfo[j].num_of_ch = op->ch_num;
		memcpy(op_class->opClassInfo[j].ch_list, op->ch, op->ch_num);
#else
		op_class->opClassInfoExt[j].op_class = op->global_class;
		op_class->opClassInfoExt[j].num_of_ch = op->ch_num;
		memcpy(op_class->opClassInfoExt[j].ch_list, op->ch, op->ch_num);
#endif
		j++;
		if (j >= MAX_OP_CLASS)
			break;
	}
	op_class->num_of_op_class = j;
}

unsigned char get_band_by_opclass(unsigned char op_class)
{
	if (op_class >= 81 && op_class <= 84)
		return BAND_2GHZ;
	else if (op_class >= 115 && op_class <= 130)
		return BAND_5GHZ;
	else
		return BAND_6GHZ;
}

unsigned char get_bw_by_opclass(unsigned char op_class)
{
	struct opclass *op = NULL;
	u8 i = 0, cnt = 0;

	cnt = ARRAY_SIZE(gl_op);
	for (i = 0; i < cnt; i++) {
		op = &gl_op[i];
		if (op->global_class == op_class)
			return op->bw;
	}

	return CHAN_WIDTH_INVALID;
}

void disable_ch_all_bw(
#ifndef MAP_6E_SUPPORT
	wdev_op_class_info *op_class,
#else
	struct _wdev_op_class_info_ext *op_class,
#endif
	unsigned char band,
	unsigned char ch)
{
	unsigned char i = 0, j = 0;
	unsigned char band1 = 0;
#ifndef MAP_6E_SUPPORT
	struct opClassInfo *op = NULL;
#else
	struct opClassInfoExt *op = NULL;
#endif

	for (i = 0; i < op_class->num_of_op_class; i++) {
#ifndef MAP_6E_SUPPORT
		op = &op_class->opClassInfo[i];
#else
		op = &op_class->opClassInfoExt[i];
#endif
		band1 = get_band_by_opclass(op->op_class);
		if (band != band1)
			continue;
		for (j = 0; j < op->num_of_ch; j++) {
			if (op->ch_list[j] == ch) {
				op->ch_list[j] = 0;
				break;
			} else if ((op->op_class == 128) || (op->op_class == 130)) {
				if (abs_ch(ch, op->ch_list[j]) <= 6) {
					op->ch_list[j] = 0;
					break;
				}
			} else if (op->op_class == 129) {
				if (abs_ch(ch, op->ch_list[j]) <= 14) {
					op->ch_list[j] = 0;
					break;
				}
			} else if (op->op_class == 132) {
				if (abs_ch(ch, op->ch_list[j]) <= 2) {
					op->ch_list[j] = 0;
					break;
				}
			} else if (op->op_class == 133) {
				if (abs_ch(ch, op->ch_list[j]) <= 6) {
					op->ch_list[j] = 0;
					break;
				}
			} else if (op->op_class == 134) {
				if (abs_ch(ch, op->ch_list[j]) <= 14) {
					op->ch_list[j] = 0;
					break;
				}
			} else if (op->op_class == 137) {
				if (abs_ch(ch, op->ch_list[j]) <= 30) {
					op->ch_list[j] = 0;
					break;
				}
			}
		}
	}
}

void disable_ch_by_bw(
#ifndef MAP_6E_SUPPORT
	wdev_op_class_info *op_class,
#else
	struct _wdev_op_class_info_ext *op_class,
#endif
	unsigned char band,
	unsigned char ch, unsigned char bw)
{
#ifndef MAP_6E_SUPPORT
		struct opClassInfo *op = NULL;
#else
		struct opClassInfoExt *op = NULL;
#endif
	unsigned char i = 0, j = 0;
	unsigned char band1 = 0;
	unsigned char bw1 = 0;

	for (i = 0; i < op_class->num_of_op_class; i++) {
#ifndef MAP_6E_SUPPORT
		op = &op_class->opClassInfo[i];
#else
		op = &op_class->opClassInfoExt[i];
#endif
		band1 = get_band_by_opclass(op->op_class);
		if (band != band1)
			continue;
		bw1 = get_bw_by_opclass(op->op_class);
		if ((bw1 == CHAN_WIDTH_INVALID) ||
			(bw1 != bw))
			continue;
		for (j = 0; j < op->num_of_ch; j++) {
			if (bw == CHAN_WIDTH_20 || bw == CHAN_WIDTH_40P ||
				bw == CHAN_WIDTH_40M) {
				if (op->ch_list[j] == ch) {
					op->ch_list[j] = 0;
					return;
				}
			} else {
				if ((op->op_class == 128) || (op->op_class == 130)) {
					if (abs_ch(ch, op->ch_list[j]) <= 6) {
						op->ch_list[j] = 0;
						return;
					}
				} else if (op->op_class == 129) {
					if (abs_ch(ch, op->ch_list[j]) <= 14) {
						op->ch_list[j] = 0;
						return;
					}
				} else if (op->op_class == 132) {
					if (abs_ch(ch, op->ch_list[j]) <= 2) {
						op->ch_list[j] = 0;
						return;
					}
				} else if (op->op_class == 133) {
					if (abs_ch(ch, op->ch_list[j]) <= 6) {
						op->ch_list[j] = 0;
						return;
					}
				} else if (op->op_class == 134) {
					if (abs_ch(ch, op->ch_list[j]) <= 14) {
						op->ch_list[j] = 0;
						return;
					}
				} else if (op->op_class == 137) {
					if (abs_ch(ch, op->ch_list[j]) <= 30) {
						op->ch_list[j] = 0;
						return;
					}
				}
			}
		}
	}
}

void copy_opclass(
#ifndef MAP_6E_SUPPORT
	wdev_op_class_info *ap_opclass,
	wdev_op_class_info *op_class
#else
	struct _wdev_op_class_info_ext *ap_opclass,
	struct _wdev_op_class_info_ext *op_class
#endif
	)
{
#ifndef MAP_6E_SUPPORT
	struct opClassInfo *op = NULL, *op1 = NULL;
#else
	struct opClassInfoExt *op = NULL, *op1 = NULL;
#endif
	unsigned char i = 0, j = 0, k = 0;
	unsigned char valid = 0;

	for (i = 0; i < op_class->num_of_op_class; i++) {
#ifndef MAP_6E_SUPPORT
		op = &ap_opclass->opClassInfo[k];
		op1 = &op_class->opClassInfo[i];
#else
		op = &ap_opclass->opClassInfoExt[k];
		op1 = &op_class->opClassInfoExt[i];
#endif
		valid = 0;
		op->op_class = op1->op_class;
		for (j = 0; j < op1->num_of_ch; j++) {
			if (op1->ch_list[j]) {
				op->ch_list[op->num_of_ch++] = op1->ch_list[j];
				valid = 1;
			}
		}
		if (valid)
			k++;
	}
	ap_opclass->num_of_op_class = k;
}

int dump_opclass(struct wifi_app *wapp, char *buf, size_t max_len)
{
#ifndef MAP_6E_SUPPORT
	struct opClassInfo *op = NULL;
#else
	struct opClassInfoExt *op = NULL;
#endif
	unsigned char i = 0, j = 0, k = 0;
	int ret = 0, len = 0;
	struct wapp_dev *wdev = NULL;
	struct ap_dev *ap = NULL;
	struct wapp_radio *ra = NULL;
	unsigned char id[MAC_ADDR_LEN] = {0};
#ifndef MAP_6E_SUPPORT
	wdev_op_class_info *ap_opclass = NULL;
#else
	struct _wdev_op_class_info_ext *ap_opclass = NULL;
#endif

	ret = snprintf(buf + len, max_len - len, "\nopclass info:");
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	for (i = 0; i < MAX_NUM_OF_RADIO; i++) {
		ra = &wapp->radio[i];
		if (!ra->adpt_id)
			continue;
		MAP_GET_RADIO_IDNFER(ra, id);
		dl_list_for_each(wdev, &wapp->dev_list, struct wapp_dev, list) {
			if (ra == wdev->radio && wdev->valid == 1 &&
				wdev->dev_type == WAPP_DEV_TYPE_AP)
				break;
		}
		if (!wdev) {
			err(DEBUG_CAT_MISC, "no valid ap wdev for raid "MACSTR"\n",
				MAC2STR(id));
			return -1;
		}
		ap = (struct ap_dev *)wdev->p_dev;
		ap_opclass = &ap->op_class;

		ret = snprintf(buf + len, max_len - len,
			 "\n\traid="MACSTR"; num_of_op_class=%d",
			MAC2STR(id), ap_opclass->num_of_op_class);
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;
#ifdef MAP_VENDOR_SUPPORT
		ret = snprintf(buf + len, max_len - len, "; is_40M_bw_disable=%d",
			ap_opclass->is_40M_bw_disable);
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;
#endif

		for (j = 0;  j < ap_opclass->num_of_op_class && j < MAX_OP_CLASS ;  j++) {
#ifndef MAP_6E_SUPPORT
			op = &ap_opclass->opClassInfo[j];
#else
			op = &ap_opclass->opClassInfoExt[j];
#endif
#ifdef MAP_VENDOR_SUPPORT
			ret = snprintf(buf + len, max_len - len, "\n\t op=%d; ch_num=%d\n",
				op->op_class, op->num_of_ch);
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf fail\n");
				return -1;
			}
			len += ret;
#else
			ret = snprintf(buf + len, max_len - len, "\n\t op=%d; ch_num=%d; ch=",
				op->op_class, op->num_of_ch);
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf fail\n");
				return -1;
			}
			len += ret;
#endif
			for (k = 0; k < op->num_of_ch && k < MAX_NUM_OF_CHANNELS; k++) {
#ifdef MAP_VENDOR_SUPPORT
				ret = snprintf(buf + len, max_len - len, "\t  ch=%d; ch_pref=%d\n",
					op->ch_list[k], op->ch_pref[k]);
				if (os_snprintf_error(max_len - len, ret)) {
					err(DEBUG_CAT_MISC, "snprintf fail\n");
					return -1;
				}
				len += ret;
#else
				ret = snprintf(buf + len, max_len - len, "%d ", op->ch_list[k]);
				if (os_snprintf_error(max_len - len, ret)) {
					err(DEBUG_CAT_MISC, "snprintf fail\n");
					return -1;
				}
				len += ret;
				ret = snprintf(buf + len, max_len - len, "\n");
				if (os_snprintf_error(max_len - len, ret)) {
					err(DEBUG_CAT_MISC, "snprintf fail\n");
					return -1;
				}
				len += ret;
#endif
			}
		}
	}

	return len;
}

void assign_wdev_op_class(struct wifi_app *wapp, struct dev_info *dev, struct phy_info *phy)
{
	struct wapp_dev *wdev = NULL;
#ifndef MAP_6E_SUPPORT
	wdev_op_class_info tmp_op;
	wdev_op_class_info *ap_op = NULL;
#else
	struct _wdev_op_class_info_ext tmp_op;
	struct _wdev_op_class_info_ext *ap_op = NULL;
#endif
	struct ap_dev *ap = NULL;
	struct channel_data *channel = NULL;
	unsigned char i = 0, band = 0;

	if (!phy || !dev || !wapp) {
		err(DEBUG_CAT_MISC, "invalid input parameter\n");
		return;
	}
	wdev = wapp_dev_list_lookup_by_ifindex(wapp, dev->ifindex);
	if (!wdev) {
		err(DEBUG_CAT_MISC, "can't find wdev by ifindex-%d\n", dev->ifindex);
		return;
	}
	if (wdev->dev_type != WAPP_DEV_TYPE_AP) {
		err(DEBUG_CAT_MISC, "dev %s is not ap\n", dev->ifname);
		return;
	}
	ap = (struct ap_dev *)wdev->p_dev;
	if (!ap) {
		err(DEBUG_CAT_MISC, "struct ap_dev not created for %s\n", dev->ifname);
		return;
	}

	ap_op = &ap->op_class;
	os_memset(&tmp_op, 0, sizeof(tmp_op));
	os_memset(ap_op, 0, sizeof(*ap_op));

	band = get_band_by_mode(phy->mode);
	assign_full_opclass_to_wdev(&tmp_op, band);
	for (i = 0; i < phy->num_channels; i++) {
		channel = &phy->channels[i];
		if (is_bit_set(channel->flag, CHAN_DISABLED)) {
			disable_ch_all_bw(&tmp_op, band, channel->chan);
			continue;
		}
		if (!(phy->bw & PHY_BW_40)) {
			disable_ch_by_bw(&tmp_op, band, channel->chan, CHAN_WIDTH_40P);
			disable_ch_by_bw(&tmp_op, band, channel->chan, CHAN_WIDTH_40M);
		}
		if ((phy->bw & PHY_BW_40) && !(channel->allowed_bw & CHAN_WIDTH_40P))
			disable_ch_by_bw(&tmp_op, band, channel->chan, CHAN_WIDTH_40P);
		if ((phy->bw & PHY_BW_40) && !(channel->allowed_bw & CHAN_WIDTH_40M))
			disable_ch_by_bw(&tmp_op, band, channel->chan, CHAN_WIDTH_40M);
		if (!(phy->bw & PHY_BW_80) || !(channel->allowed_bw & CHAN_WIDTH_80))
			disable_ch_by_bw(&tmp_op, band, channel->chan, CHAN_WIDTH_80);
		if (!(phy->bw & PHY_BW_160) || !(channel->allowed_bw & CHAN_WIDTH_160))
			disable_ch_by_bw(&tmp_op, band, channel->chan, CHAN_WIDTH_160);
		if (!(phy->bw & PHY_BW_320) || !(channel->allowed_bw & CHAN_WIDTH_320))
			disable_ch_by_bw(&tmp_op, band, channel->chan, CHAN_WIDTH_320);
	}
	copy_opclass(ap_op, &tmp_op);
}

/*this function is only used for 2g 5g*/
unsigned char find_opclass_by_ch_bw(unsigned short chan, unsigned char bw,
	unsigned short *new_chan)
{
	u8 i = 0, j = 0, cnt = 0;

	cnt = ARRAY_SIZE(gl_op);
	for (i = 0; i < cnt; i++) {
		if (gl_op[i].bw != bw)
			continue;
		for (j = 0; j < gl_op[i].ch_num; j++) {
			if (bw < CHAN_WIDTH_80) {
				if (gl_op[i].ch[j] == chan)
					return gl_op[i].global_class;
			} else if (bw == CHAN_WIDTH_80) {
				if (abs_ch(chan, gl_op[i].ch[j]) <= 6) {
					*new_chan = gl_op[i].ch[j];
					return gl_op[i].global_class;
				}
			} else if (bw == CHAN_WIDTH_160) {
				if (abs_ch(chan, gl_op[i].ch[j]) <= 14) {
					*new_chan = gl_op[i].ch[j];
					return gl_op[i].global_class;
				}
			}
		}
	}

	return 0;
}

struct opclass *get_opclass_item(unsigned char opclass)
{
	struct opclass *op = NULL;
	u8 i = 0, cnt = 0;

	cnt = ARRAY_SIZE(gl_op);
	for (i = 0; i < cnt; i++) {
		op = &gl_op[i];
		if (op->global_class == opclass)
			return op;
	}

	return NULL;
}
#endif
