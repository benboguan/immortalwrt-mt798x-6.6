/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#include "stdio.h"
#include "types.h"
#include "util.h"
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <limits.h>
#ifdef OPENWRT_SUPPORT
#include <libdatconf.h>
#endif
#include "wdev.h"
#include "driver_wext.h"
#include "hotspot.h"
#include "wapp_cmm.h"
#include "wps.h"
#ifdef DPP_SUPPORT
#include "dpp/dpp_wdev.h"
#endif /*DPP_SUPPORT */
#ifdef WPACTRL_SUPPORT
#include <libwpactrl.h>
#endif

#include <uci.h>
#include <uci_config.h>

#define SIOCBRADDIF 0x89a2

extern struct wapp_drv_ops wapp_drv_nl80211_ops;
extern struct wapp_drv_ops wapp_drv_wext_ops;
extern struct hotspot_event_ops hs_event_ops;
extern int wapp_iface_init(struct wifi_app *wapp);
struct wifi_app_event_ops wapp_event_ops = {
#ifndef MTK_HOSTAPD_SUPPORT
	.event_get_mbo_neighbor_report = wapp_event_get_neighbor_report_list,
#endif
	.event_handle = wapp_event_handle,
	.event_btm_rsp = wapp_event_btm_rsp,
	.event_btm_req = wapp_event_btm_req,
	.event_anqp_req = wapp_event_anqp_req,
	.event_btm_query = wapp_event_btm_query,
	.event_offch_info = wapp_event_offchannel_info,
#ifdef MAP_R2
	.event_wnm_notify = wapp_event_wnm_notify_req,
#endif
	.event_wps_overlap = wapp_event_wps_overlap,
#ifdef MTK_HOSTAPD_SUPPORT
	.event_eap_failure = wapp_event_eap_failure,
	.event_eap_timeout = wapp_event_eap_timeout,
#endif
	.event_wps_failure = wapp_event_wps_failure,
	.event_network_add = wapp_event_network_add,
	.event_wps_timeout = wapp_event_wps_timeout,
	.event_wps_scan_fail = wapp_event_wps_scan_failure,
	.event_wps_success = wapp_event_wps_success,
	.event_hapd_bcn_report = wapp_hapd_bcn_report_handle,
	.event_hapd_bcn_report_complete = wapp_hapd_bcn_report_complete_handle,
	.event_hapd_wps_dpp_uri = wapp_hapd_wps_dpp_uri_handle,
	.event_supp_wps_cred = wapp_supp_wps_cred_handle,
	.event_supp_reconfig_fail = wapp_supp_reconfig_fail_handle,
#ifdef MTK_TK_HOSTAPD_SUPPORT
	.event_eapol_complete = wapp_event_eapol_complete,
#endif
#ifdef DFS_SLAVE_SUPPORT
	.event_bhstatus = wapp_bhstatus_event,
#endif /* DFS_SLAVE_SUPPORT */
#ifdef MAP_R6
	.event_mlo_reconfig_status = wapp_mlo_reconfig_status_event,
#endif /* MAP_R6 */
#ifdef WPS_UNCONFIG_FEATURE_SUPPORT
	/* Handle WPS creds from libwpactrl*/
	.event_ap_wps_cred = wapp_ap_wps_cred_handle,
#endif
#ifdef STANDARD_NL_CMD
	.event_intf = wapp_event_intf_notify,
	.event_new_intf_notify = wapp_event_new_intf_notify,
	.event_delete_intf_notify = wapp_event_delete_intf_notify,
#endif /* STANDARD_NL_CMD */
};

#ifdef STANDARD_NL_CMD
struct wapp_nl_drv_ops wapp_nl_event_ops = {
	.nl_event_handle = wapp_nl_event_handle,
};
#endif

VOID os_alloc_mem(
	UCHAR *pAd,
	UCHAR **ppMem,
	UINT32 Size)
{
	if (ppMem == NULL)
		return;

	*ppMem = (UCHAR *)malloc(Size);
	if (*ppMem == NULL)
		return;
}

VOID os_free_mem(UCHAR *pAd, VOID *pMem)
{
	free(pMem);
}

int wapp_cmm_init(struct wifi_app *wapp, int drv_mode, int opmode, int version, struct hotspot *hs, struct mbo_cfg *mbo,
		  struct oce_cfg *oce, struct map_info *map)
{
	int ret = 0;
	int i;

	wapp->hs = hs;
	wapp->mbo = mbo;
	wapp->oce = oce;
#ifdef MAP_SUPPORT
	wapp->map = map;
	wapp->wsc_save_bh_profile = FALSE;
#endif

	dl_list_init(&wapp->dev_list);
	wapp->opmode = opmode;
	wapp->drv_mode = drv_mode;

	dl_list_init(&wapp->conf_list);

	if (wapp->drv_mode == WEXT) {
#ifdef MBO_SUPPORT
		ret += mbo_init(wapp->mbo);
#endif /* MBO_SUPPORT */
#ifdef OCE_SUPPORT
		ret += oce_init(wapp->oce);
#endif /* OCE_SUPPORT */
		ret += anqp_init(wapp, &hs_event_ops, version);
	}
#ifdef MAP_SUPPORT
	ret += map_init(wapp->map);
#endif /* MAP_SUPPORT */

	/* init daemon neighbor report list */
	os_memset(&wapp->daemon_nr_list, 0, sizeof(DAEMON_NR_LIST));
	for (i = 0; i < PROBE_TABLE_SIZE; i++)
		wapp->probe_entry[i].valid = 0;
	os_memset(&wapp->probe_hash[0], 0, sizeof(wapp->probe_hash));
#ifdef STANDARD_NL_CMD
	wapp->nl_rest_ap = 0;
	wapp->nl_rest_apcli = 0;
	wapp->mld_info.mld_count = 0;
	wapp->mld_info.mld_result = NULL;
#endif
#ifdef MAP_R6
	wapp->renew_buf_state = RENEW_BUFFER_INVALID;
#endif /* MAP_R6 */
#ifdef MTK_HOSTAPD_SUPPORT
	wapp->is_mesh_wps_onboarding = FALSE;
#endif

	return ret;
}

int wapp_socket_and_ctrl_inf_init(struct wifi_app *wapp, int drv_mode, int opmode)
{
	/* Initialze event loop */
	if (eloop_init() != 0) {
		err(DEBUG_CAT_INIT, "eloop_init fail\n");
		return -1;
	}

	if (drv_mode == NL80211)
		wapp->drv_ops = &wapp_drv_nl80211_ops;
	else
		wapp->drv_ops = &wapp_drv_wext_ops;
	wapp->event_ops = &wapp_event_ops;
#ifdef STANDARD_NL_CMD
	wapp->nl_event_ops = &wapp_nl_event_ops;
#endif
	wapp->drv_data = wapp->drv_ops->drv_inf_init(wapp, opmode, drv_mode);
	if (!wapp->drv_data) {
		err(DEBUG_CAT_INIT, "drv_inf_init fail\n");
		/* deinit control interface */
		return -1;
	}

	eloop_register_timeout(1, 0, wapp_periodic_exec, NULL, wapp);

	return 0;
}

int wapp_get_mac_addr_by_ifname(char *ifname, u8 *mac_addr)
{
	int fd;
	struct ifreq ifr = {0};
	u8 *mac = NULL;

	memset(&ifr, 0, sizeof(struct ifreq));
	ifr.ifr_addr.sa_family = AF_INET;
	os_strlcpy(ifr.ifr_name, ifname, IFNAMSIZ);
	fd = socket(AF_INET, SOCK_DGRAM, 0);
	if (fd < 0) {
		err(DEBUG_CAT_MISC, "socket fail\n");
		return WAPP_UNEXP;
	}

	if (ioctl(fd, SIOCGIFHWADDR, &ifr) < 0) {
		err(DEBUG_CAT_MISC, "failed to get the hw addr of %s\n", ifname);
		close(fd);
		return WAPP_UNEXP;
	}

	if (fd >= 0)
		close(fd);

	mac = (unsigned char *)ifr.ifr_hwaddr.sa_data;

	os_memcpy(mac_addr, mac, MAC_ADDR_LEN);

	return WAPP_SUCCESS;
}

int get_mac_addr_by_ifname(char *_iface, u8 *mac_addr)
{
	struct ifreq ifr = {0};
	int fd = socket(AF_INET, SOCK_DGRAM, 0);

	if (fd < 0) {
		err(DEBUG_CAT_MISC, "socket fail\n");
		goto error;
	}

	ifr.ifr_addr.sa_family = AF_INET;
	os_strlcpy(ifr.ifr_name, _iface, IFNAMSIZ);
	if (ioctl(fd, SIOCGIFHWADDR, &ifr) < 0) {
		err(DEBUG_CAT_MISC, RED("failed to get the hw addr of %s\n"), _iface);
		close(fd);
		return WAPP_UNEXP;
	} else {
		os_memcpy(mac_addr, ifr.ifr_hwaddr.sa_data, MAC_ADDR_LEN);
	}

error:
	if (fd >= 0)
		close(fd);
	return WAPP_SUCCESS;
}

int test_inf_status(const char *_iface, u32 if_flag)
{
	struct ifreq ifr = {0};
	int sockfd;
	int ret = 0;

	sockfd = socket(AF_INET, SOCK_DGRAM, 0);
	if (sockfd < 0) {
		err(DEBUG_CAT_MISC, "can't open socket\n");
		return FALSE;
	}
	bzero(&ifr, sizeof(ifr));
	os_strlcpy(ifr.ifr_name, _iface, IFNAMSIZ);

	ret = ioctl(sockfd, SIOCGIFFLAGS, &ifr);
	if (ret < 0) {
		err(DEBUG_CAT_MISC, "ioctl failed\n");
		close(sockfd);
		return FALSE;
	}

	close(sockfd);
	if (ifr.ifr_flags & if_flag)
		return TRUE;
	else
		return FALSE;
}

int wapp_add_intf_interface_bridge(struct wifi_app *wapp, char *ifname, char *br_name)
{
	int fd;
	struct ifreq ifr;
	int ifindex;

	fd = socket(PF_INET, SOCK_DGRAM, 0);
	if (fd < 0) {
		err(DEBUG_CAT_MISC, "socket fail\n");
		return WAPP_UNEXP;
	}

	ifindex = if_nametoindex(ifname);
	if (ifindex == 0) {
		err(DEBUG_CAT_MISC, "invalid ifindex\n");
		close(fd);
		return -1;
	}

	os_memset(&ifr, 0, sizeof(ifr));
	os_strlcpy(ifr.ifr_name, br_name, IFNAMSIZ);
	ifr.ifr_ifindex = ifindex;
	if (ioctl(fd, SIOCBRADDIF, &ifr) < 0) {
		err(DEBUG_CAT_MISC, "failed adding %s to bridge\n", ifname);
		close(fd);
		return -1;
	}

	if (fd >= 0)
		close(fd);

	return WAPP_SUCCESS;
}

int wapp_get_wireless_interfaces(struct wifi_app *wapp)
{
	struct iwreq wrq;
	int skfd;
	u8 addr[MAC_ADDR_LEN] = {0};
	char *token;
	char buff[1024], *pbuf;
	FILE *fh = NULL;
	char *end;
	char name[IFNAMSIZ + 1] = {0};
	char value[350] = {0};
	char *rem_strng = value;
	int ret = 0;
	char *tmp = NULL;

	skfd = socket(AF_INET, SOCK_DGRAM, 0);

	if (skfd < 0) {
		err(DEBUG_CAT_MISC, "create socket fail\n");
		goto error1;
	}

	/* 1. get all local interfaces */
	get_map_parameters(wapp->map, "bss_config_priority", value, NON_DRIVER_PARAM, sizeof(value));

	if (strlen(value) > 0) {
		/* Static Interface list */
		token = strtok_r(rem_strng, ";", &rem_strng);
		/* Read each device line */
		while (token) {
			os_memset(name, 0, IFNAMSIZ + 1);
			ret = os_snprintf(name, sizeof(name), "%s", token);
			if (os_snprintf_error(sizeof(name), ret)) {
				err(DEBUG_CAT_MISC, "os_snprintf fail\n");
				continue;
			}
			/* Got it, print info about this interface */
			os_memset(&wrq, 0, sizeof(struct iwreq));
			/* check if the interface is a wireless interface */
			os_strlcpy(wrq.ifr_name, name, IFNAMSIZ);

			if ((ioctl(skfd, SIOCGIWNAME, &wrq)) >= 0) {
				/* Valid wireless interface, create a wdev for this interface */
				if (get_mac_addr_by_ifname(name, addr) != WAPP_SUCCESS) {
					err(DEBUG_CAT_MISC, RED("failed to get hw addr for %s\n"), name);
				} else {
					wapp_dev_create(wapp, name, if_nametoindex(name), addr);
				}
			}
			token = strtok_r(rem_strng, ";", &rem_strng);
		}
	} else {
		/* Dynamic interface list */
		fh = fopen(PROC_NET_DEV, "r");
		if (fh != NULL) {
			/* Ignore two lines */
			tmp = fgets(buff, sizeof(buff), fh);
			if (!tmp) {
				err(DEBUG_CAT_MISC, "fgets fail\n");
				goto error1;
			}
			tmp = fgets(buff, sizeof(buff), fh);
			if (!tmp) {
				err(DEBUG_CAT_MISC, "fgets fail\n");
				goto error1;
			}
			/* Read each device line */
			while (fgets(buff, sizeof(buff), fh)) {
				char *s;

				if ((buff[0] == '\0') || (buff[1] == '\0'))
					continue;
				/* Extract interface name */
				pbuf = buff;
				while (isspace(*pbuf))
					pbuf++;
				end = strrchr(pbuf, ':');
				if ((end == NULL) || (((end - pbuf) + 1) > sizeof(name)))
					s = NULL;
				else {
					os_memset(name, 0, IFNAMSIZ + 1);
					if ((end >= pbuf) && ((end - pbuf) < (sizeof(name) - 1))) {
						size_t length = end - pbuf;

						memcpy(name, pbuf, length);
						name[length] = '\0';
					} else {
						err(DEBUG_CAT_MISC, " buf length invalid!\n");
						continue;
					}
					s = end;
				}
				if (s) {
					/* Got it, print info about this interface */
					os_memset(&wrq, 0, sizeof(struct iwreq));
					/* check if the interface is a wireless interface */
					os_strlcpy(wrq.ifr_name, name, IFNAMSIZ);
					if ((ioctl(skfd, SIOCGIWNAME, &wrq)) >= 0) {
						/* Valid wireless interface, create a wdev for this interface */
						if (get_mac_addr_by_ifname(name, addr) != WAPP_SUCCESS) {
							err(DEBUG_CAT_MISC, RED("failed to get hw addr for %s\n"), name);
						} else {
							wapp_dev_create(wapp, name, if_nametoindex(name), addr);
						}
					}
				}
			}
			(void)fclose(fh);
		}
	}

	if (skfd >= 0)
		(void)close(skfd);

	return WAPP_SUCCESS;
error1:
	if (fh) {
		ret = fclose(fh);
		if (ret != 0)
			err(DEBUG_CAT_MISC, "fclose fail\n");
	}
	if (skfd >= 0)
		(void)close(skfd);
	return WAPP_INVALID_ARG;
}

void wapp_periodic_exec(void *eloop_data, void *user_ctx)
{
	struct wifi_app *wapp = (struct wifi_app *)user_ctx;

#ifdef MAP_SUPPORT
	map_periodic_exec(wapp);
#endif /* MAP_SUPPORT */
#ifdef MAP_R3
#ifdef MAP_R3_RECONFIG
	time_t now;

	now = time(NULL);
	if (now < 0) {
		wpa_printf(MSG_ERROR, DPP_MAP_PREX
			"DPP: Cannot get current time - assume expired key");
		goto out;
	}

	if (wapp->dpp && wapp->map
		&& wapp->netaccesskey_expiry
		&& wapp->map->my_map_dev_role != DEVICE_ROLE_CONTROLLER
		&& !wapp->dpp->dpp_onboard_ongoing
		&& wapp->map->map_version == DEV_TYPE_R3
		&& now > wapp->netaccesskey_expiry) {

	struct wapp_dev *wdev = NULL;
	struct apcli_association_info *apcli_info = &wapp->cli_assoc_info;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, apcli_info->interface_index);
	if (!wdev)
		goto out;

	if (wdev->dev_type == WAPP_DEV_TYPE_STA) {
		wapp->dpp->cce_driver_scan_done = 0;
		wapp->netaccesskey_expiry = 0;
		struct dpp_authentication *auth = NULL;

		auth = wapp_dpp_get_first_auth(wapp);
		if (auth) {
			auth->timeout_recon = 1;
			dpp_auth_deinit(auth);
		}

		wdev_handle_reconfig_trigger(wapp, wdev->ifindex, NULL);
	}
	}
out:
#endif
#endif
	eloop_register_timeout(1, 0, wapp_periodic_exec, NULL, wapp);
}

/* send wapp request to driver */
int wapp_req_send(struct wifi_app *wapp, const char *iface, struct wapp_req *req)
{
	int ret;

	if (test_inf_status(iface, IFF_UP) == FALSE) {
		err(DEBUG_CAT_MISC, "intf %s is not up\n", iface);
		return WAPP_NOT_INITIALIZED;
	}
	ret = wapp->drv_ops->drv_wapp_req(wapp->drv_data, iface, req);

	return ret;
}

int wapp_query_wdev(struct wifi_app *wapp, const char *iface)
{
	int ret = 0;
	struct wapp_req req;

	if (!iface) {
		err(DEBUG_CAT_MISC, "Invalid argument\n");
		return WAPP_INVALID_ARG;
	}

	req.req_id = WAPP_DEV_QUERY_REQ;
	req.data_len = 0;
	req.data.ifindex = if_nametoindex(iface);
	debug(DEBUG_CAT_MISC, "inf name [%s], ifindex = %u\n", iface, req.data.ifindex);

	ret = wapp_req_send(wapp, iface, &req);

	return ret;
}

int wapp_query_wdev_by_req_id(struct wifi_app *wapp, const char *iface, u8 req_id)
{
	int ret;
	struct wapp_req req;
	struct wapp_dev *wdev = NULL;

	if (!iface) {
		err(DEBUG_CAT_MISC, "iface is null\n");
		return WAPP_INVALID_ARG;
	}

	wdev = wapp_dev_list_lookup_by_ifname(wapp, iface);
	if (!wdev) {
		err(DEBUG_CAT_MISC, "can't find wdev by %s\n", iface);
		return WAPP_LOOKUP_ENTRY_NOT_FOUND;
	}

	req.req_id = req_id;
	/*req.data_len = sizeof(wapp_req_data); */
	req.data.ifindex = wdev->ifindex;

	ret = wapp_req_send(wapp, iface, &req);

	return ret;
}

int wapp_query_wdev_ht_cap(struct wifi_app *wapp, const char *iface)
{
	int ret;
	struct wapp_req req;
	struct wapp_dev *wdev = NULL;

	if (!iface) {
		err(DEBUG_CAT_MISC, "Invalid argument\n");
		return WAPP_INVALID_ARG;
	}

	wdev = wapp_dev_list_lookup_by_ifname(wapp, iface);

	if (!wdev)
		return WAPP_LOOKUP_ENTRY_NOT_FOUND;

	req.req_id = WAPP_HT_CAP_QUERY_REQ;
	req.data.ifindex = wdev->ifindex;

	ret = wapp_req_send(wapp, iface, &req);
	return ret;
}

int wapp_query_wdev_vht_cap(struct wifi_app *wapp, const char *iface)
{
	int ret;
	struct wapp_req req;
	struct wapp_dev *wdev = NULL;

	if (!iface) {
		err(DEBUG_CAT_MISC, "Invalid argument\n");
		return WAPP_INVALID_ARG;
	}

	wdev = wapp_dev_list_lookup_by_ifname(wapp, iface);

	if (!wdev)
		return WAPP_LOOKUP_ENTRY_NOT_FOUND;

	req.req_id = WAPP_VHT_CAP_QUERY_REQ;
	/*req.data_len = sizeof(wapp_req_data); */
	req.data.ifindex = wdev->ifindex;

	ret = wapp_req_send(wapp, iface, &req);
	return ret;
}

int wapp_query_cli(struct wifi_app *wapp, const char *iface, const u8 *mac_addr)
{
	int ret;
	struct wapp_req req;
	struct wapp_dev *wdev = NULL;

	wdev = wapp_dev_list_lookup_by_ifname(wapp, iface);

	if (!wdev)
		return WAPP_LOOKUP_ENTRY_NOT_FOUND;

	req.req_id = WAPP_CLI_QUERY_REQ;
	req.data.ifindex = wdev->ifindex;
	COPY_MAC_ADDR(req.data.mac_addr, mac_addr);

	ret = wapp_req_send(wapp, iface, &req);
	return ret;
}

int wapp_set_bss_start(struct wifi_app *wapp, const char *iface)
{
	int ret;
	struct wapp_req req;
	struct wapp_dev *wdev = NULL;

	wdev = wapp_dev_list_lookup_by_ifname(wapp, iface);

	if (!wdev)
		return WAPP_LOOKUP_ENTRY_NOT_FOUND;

	if (wdev->dev_type != WAPP_DEV_TYPE_AP) {
		debug(DEBUG_CAT_MISC, "wdev(%s) type is not AP, do nothing\n", wdev->ifname);
		return WAPP_LOOKUP_ENTRY_NOT_FOUND;
	}

	req.req_id = WAPP_BSS_START_REQ;
	req.data.ifindex = wdev->ifindex;

	ret = wapp_req_send(wapp, iface, &req);
	return ret;
}

int wapp_set_bss_stop(struct wifi_app *wapp, const char *iface)
{
	int ret;
	struct wapp_req req;
	struct wapp_dev *wdev = NULL;

	wdev = wapp_dev_list_lookup_by_ifname(wapp, iface);

	if (!wdev)
		return WAPP_LOOKUP_ENTRY_NOT_FOUND;

	if (wdev->dev_type != WAPP_DEV_TYPE_AP) {
		notice(DEBUG_CAT_AUTOCONFIG, "%s wdev type is not AP, do nothing.", __func__);
		return WAPP_LOOKUP_ENTRY_NOT_FOUND;
	}

	req.req_id = WAPP_BSS_STOP_REQ;
	req.data.ifindex = wdev->ifindex;

	ret = wapp_req_send(wapp, iface, &req);
	return ret;
}

int wapp_set_bssload_thrd(struct wifi_app *wapp, const char *iface, char *high_thrd, char *low_thrd)
{
	int ret;
	struct wapp_req req;
	struct wapp_dev *wdev = NULL;
	char *endptr = NULL;
	unsigned long high_thrd_val = 0, low_thrd_val = 0;


	if (!iface || !high_thrd || !low_thrd) {
		err(DEBUG_CAT_MISC, "Invalid argument\n");
		return WAPP_INVALID_ARG;
	}

	wdev = wapp_dev_list_lookup_by_ifname(wapp, iface);
	if (!wdev)
		return WAPP_LOOKUP_ENTRY_NOT_FOUND;

	errno = 0;
	high_thrd_val = strtoul(high_thrd, &endptr, 10);
	if (errno != 0 || *endptr != '\0' || high_thrd_val > UINT8_MAX)
		return WAPP_INVALID_ARG;

	errno = 0;
	low_thrd_val = strtoul(low_thrd, &endptr, 10);
	if (errno != 0 || *endptr != '\0' || low_thrd_val > UINT8_MAX)
		return WAPP_INVALID_ARG;

	req.req_id = WAPP_BSS_LOAD_THRD_SET_REQ;
	req.data.ifindex = wdev->ifindex;
	req.data.bssload_thrd.high_bssload_thrd = (uint8_t)high_thrd_val;
	req.data.bssload_thrd.low_bssload_thrd = (uint8_t)low_thrd_val;
	ret = wapp_req_send(wapp, iface, &req);
	return ret;
}

int wapp_set_tx_power_percentage(struct wifi_app *wapp, struct wapp_dev *wdev, u8 pwr_prctg)
{
	int ret;
	struct wapp_req req;

	if (!wapp || !wdev) {
		return WAPP_INVALID_ARG;
	}

	notice(DEBUG_CAT_MISC, "%s:\n \t ifname = %s\n \t pwr_prctg = %u(%%)\n", __func__, wdev->ifname, pwr_prctg);

	req.req_id = WAPP_TXPWR_PRCTG_REQ;
	req.data.ifindex = wdev->ifindex;
	req.data.value = pwr_prctg;

	ret = wapp_req_send(wapp, wdev->ifname, &req);

	return ret;
}

int wapp_set_steering_policy(struct wifi_app *wapp, struct wapp_dev *wdev, wdev_steer_policy *policy)
{
	int ret;
	struct wapp_req req;

	if (!wapp || !wdev)
		return WAPP_INVALID_ARG;

	req.req_id = WAPP_STEERING_POLICY_SET_REQ;
	req.data.ifindex = wdev->ifindex;
	os_memcpy(&req.data.str_policy, policy, sizeof(wdev_steer_policy));

	ret = wapp_req_send(wapp, wdev->ifname, &req);
	return ret;
}

static void wapp_init_features(struct wifi_app *wapp, struct wapp_dev *wdev)
{
#ifdef KV_API_SUPPORT
	/* enable wnm */
	if (wdev) {
		driver_wnm_btm_onoff(wapp->drv_data, wdev->ifname, 1);
		wdev->wnm_enbale = 1;

		/* enable rrm */
		driver_rrm_onoff(wapp->drv_data, wdev->ifname, 1);
		wdev->rrm_enable = 1;
	}
#endif /*KV_API_SUPPORT */
}

int wapp_set_ap_config(struct wifi_app *wapp, struct wapp_dev *wdev)
{
	int ret;
	struct wapp_req req;

	req.req_id = WAPP_AP_CONFIG_SET_REQ;
	req.data.ifindex = wdev->ifindex;
	req.data.ap_conf.sta_report_on_cop = wapp->map->sta_report_on_cop;
	req.data.ap_conf.sta_report_not_cop = wapp->map->sta_report_not_cop;
	req.data.ap_conf.rssi_steer = wapp->map->rssi_steer;

	ret = wapp_req_send(wapp, wdev->ifname, &req);

	/* TODO: init other feature */
	if (wapp->drv_mode == WEXT)
		wapp_init_features(wapp, wdev);

	return ret;
}

int wapp_query_bssload(struct wifi_app *wapp, struct wapp_dev *wdev)
{
	int ret;
	struct wapp_req req;

	if (!wapp || !wdev)
		return WAPP_INVALID_ARG;

	req.req_id = WAPP_BSSLOAD_QUERY_REQ;
	req.data.ifindex = wdev->ifindex;

	ret = wapp_req_send(wapp, wdev->ifname, &req);
	return ret;
}

int wapp_query_he_cap(struct wifi_app *wapp, struct wapp_dev *wdev)
{
	int ret;
	struct wapp_req req;

	if (!wapp || !wdev)
		return WAPP_INVALID_ARG;

	req.req_id = WAPP_HECAP_QUERY_REQ;
	req.data.ifindex = wdev->ifindex;

	ret = wapp_req_send(wapp, wdev->ifname, &req);
	return ret;
}

int wapp_query_sta_rssi(struct wifi_app *wapp, struct wapp_dev *wdev, const u8 *mac_addr)
{
	int ret;
	struct wapp_req req;

	if (!wapp || !wdev)
		return WAPP_INVALID_ARG;

	req.req_id = WAPP_STA_RSSI_QUERY_REQ;
	req.data.ifindex = wdev->ifindex;
	COPY_MAC_ADDR(req.data.mac_addr, mac_addr);

	ret = wapp_req_send(wapp, wdev->ifname, &req);
	return ret;
}
int wapp_query_cosr_sta_rssi(struct wifi_app *wapp, struct wapp_dev *wdev, const u8 *mac_addr)
{
	int ret;
	struct wapp_req req;

	if (!wapp || !wdev)
		return WAPP_INVALID_ARG;

	req.req_id = WAPP_COSR_STA_RSSI_QUERY_REQ;
	req.data.ifindex = wdev->ifindex;
	COPY_MAC_ADDR(req.data.mac_addr, mac_addr);

	ret = wapp_req_send(wapp, wdev->ifname, &req);
	return ret;
}

int wapp_query_apcli_rssi(struct wifi_app *wapp, struct wapp_dev *wdev, const u8 *mac_addr)
{
	int ret;
	struct wapp_req req;

	if (!wapp || !wdev)
		return WAPP_INVALID_ARG;

	req.req_id = WAPP_APCLI_RSSI_QUERY_REQ;
	req.data.ifindex = wdev->ifindex;
	COPY_MAC_ADDR(req.data.mac_addr, mac_addr);

	ret = wapp_req_send(wapp, wdev->ifname, &req);
	return ret;
}

/* Fucntion is required to fetch the scan results from the driver
 */
int wapp_query_scan_result(struct wifi_app *wapp, struct wapp_dev *wdev, char more_data)
{
	int ret;
	struct wapp_req req;

	if (!wapp || !wdev)
		return WAPP_INVALID_ARG;

	os_memset(&req, 0, sizeof(req));
	req.req_id = WAPP_GET_SCAN_RESULTS;
	req.data.ifindex = wdev->ifindex;

	req.data.value = wdev->scan_cookie;

	ret = wapp_req_send(wapp, wdev->ifname, &req);
	return ret;
}

#ifdef STANDARD_NL_CMD
int wapp_scan_trigger(struct wifi_app *wapp, struct wapp_dev *wdev,
	struct scan_BH_ssids *scan_ssids, u8 op_class)
{
	int ret;
	struct wapp_req req;

	if (!wapp || !wdev)
		return WAPP_INVALID_ARG;

	os_memset(&req, 0, sizeof(req));
	req.req_id = NL80211_CMD_TRIGGER_SCAN;
	req.data.ifindex = wdev->ifindex;
	debug(DEBUG_CAT_MISC, "%d\n", wdev->ifindex);
	req.data.value = wdev->scan_cookie;
	if (scan_ssids)
		os_memcpy(&req.data.scan_bh_ssids, scan_ssids, sizeof(struct scan_BH_ssids));

#ifdef DPP_SUPPORT
#ifdef MAP_R3
	wapp->dpp->scan_trigerred = 1;  /* For DPP CCE Scan */
#endif
#endif

	if (test_inf_status(wdev->ifname, IFF_UP) == FALSE) {
		debug(DEBUG_CAT_MISC, "inf name [%s] is not up\n", wdev->ifname);
		return WAPP_NOT_INITIALIZED;
	}
	ret = wapp->drv_ops->drv_get_scan_result(wapp, wdev, &req, op_class); // Standard NL code

	return ret;
}
#endif

/*
	Function sends an OID to driver to perform single step in APCLI PBC state machine
*/
int wapp_trigger_wsc_pbc_exec(struct wifi_app *wapp, struct wapp_dev *wdev)
{
	int ret;
	struct wapp_req req;

	if (!wapp || !wdev)
		return WAPP_INVALID_ARG;

	req.req_id = WAPP_WSC_PBC_EXEC;
	req.data.ifindex = wdev->ifindex;

	ret = wapp_req_send(wapp, wdev->ifname, &req);
	return ret;
}

int wapp_query_sr_support_mode(struct wifi_app *wapp)
{
	struct dl_list *dev_list;
	struct wapp_req req;
	struct wapp_dev *wdev, *wdev_temp = NULL;
	int ret = 0;

	if (!wapp)
		return WAPP_INVALID_ARG;

	dev_list = &wapp->dev_list;

	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
		if (!wdev || wdev->dev_type != WAPP_DEV_TYPE_AP) {
			err(DEBUG_CAT_MISC, "wdev is not null Type is %d ifname %s\n",
				wdev->dev_type, wdev->ifname);
			continue;
		}
		req.req_id = WAPP_SR_SUPPORT_MODE_QUERY_REQ;
		req.data.ifindex = wdev->ifindex;
		ret = wapp_req_send(wapp, wdev->ifname, &req);
		if (ret != WAPP_SUCCESS) {
			err(DEBUG_CAT_MISC, "wapp send req_id %d failed\n", req.req_id);
			continue;
		}
	}
	return WAPP_SUCCESS;
}

#ifdef HOSTAPD_MAP_SUPPORT
int wapp_get_hapd_wifi_profile(struct wifi_app *wapp, struct wapp_dev *wdev, struct wireless_setting *wifi_profile, unsigned int bh_idx,
			       BOOLEAN is_backhaul_bss)
{
	char param_prefix[6] = {0};
	char file_name[64] = {0};
	char value[128] = {0};
	char param[32] = {0};
	char *endptr = NULL;
	long val = 0;

	os_memset(param_prefix, 0, sizeof(param_prefix));
	if (is_backhaul_bss == TRUE) {
		if (bh_idx < RADIO_5G)
			os_snprintf(param_prefix, sizeof(param_prefix), "bh%d", bh_idx);
		else {
			printf("Invalid bh profile index %d\n", bh_idx);
			return 0;
		}
	} else
		os_strcpy(param_prefix, "");

	os_snprintf(file_name, sizeof(file_name), "/etc/hostapd_%s_map.conf", wdev->ifname);

	/*read ssid */
	os_snprintf(param, sizeof(param), "%sssid", param_prefix);
	get_parameters(file_name, param, value, NON_DRIVER_PARAM, sizeof(wifi_profile->Ssid));
	os_memcpy(wifi_profile->Ssid, value, os_strlen(value));

	/*read wpa */
	os_snprintf(param, sizeof(param), "%swpa", param_prefix);
	get_parameters(file_name, param, value, NON_DRIVER_PARAM, sizeof(value));
	if (value[0] == '2') {
		os_snprintf(param, sizeof(param), "%swpa_key_mgmt", param_prefix);
		get_parameters(file_name, param, value, NON_DRIVER_PARAM, sizeof(value));
		if (os_memcmp(value, "WPA-PSK", 7) == 0)
			wifi_profile->AuthMode = 0x20; /*WPA2PSK */
	} else {
		wifi_profile->AuthMode = 0x01;
	 /*OPEN*/}

	 /*read wpa_passphrase */
	 os_snprintf(param, sizeof(param), "%swpa_passphrase", param_prefix);
	 get_parameters(file_name, param, value, NON_DRIVER_PARAM, sizeof(wifi_profile->WPAKey));
	 os_memcpy(wifi_profile->WPAKey, value, os_strlen(value));

	 /*read rsn_pairwise */
	 os_snprintf(param, sizeof(param), "%srsn_pairwise", param_prefix);
	 get_parameters(file_name, param, value, NON_DRIVER_PARAM, sizeof(value));
	 if (os_memcmp(value, "CCMP", 4) == 0)
		wifi_profile->EncrypType = 0x08;
	/*CCMP*/
	/*read map_vendor_extension */
	 os_snprintf(param, sizeof(param), "%smap_vendor_extension", param_prefix);
	 get_parameters(file_name, param, value, NON_DRIVER_PARAM, sizeof(value));
	errno = 0;
	val = strtol(value, &endptr, 10); /*map_vendor_extension */
	if (errno == ERANGE || *endptr != '\0' || val < 0 ||  val > UCHAR_MAX)
		err(DEBUG_CAT_MISC, "the map vendor extension strtol fails.\n");
	else
		wifi_profile->map_vendor_extension = (u8)val;

	 /*read bh mac address */
	 if (is_backhaul_bss == TRUE) {
		 os_snprintf(param, sizeof(param), "%smacaddr", param_prefix);
		 get_parameters(file_name, param, value, NON_DRIVER_PARAM, sizeof(value));
		 hwaddr_aton(value, wifi_profile->mac_addr);
	 }

	 return 0;
}

int wapp_set_hapd_wifi_profile(struct wifi_app *wapp, struct wapp_dev *wdev, struct wireless_setting *wifi_profile, unsigned int bh_idx,
			       BOOLEAN is_backhaul_profile)
{
	char param_prefix[6];
	char file_name[64] = {0};
	char value[128] = {0};
	char param[32] = {0};

	os_memset(param_prefix, 0, sizeof(param_prefix));
	if (is_backhaul_profile == TRUE) {
		struct wapp_dev *wdev_wifi_profile = NULL;

		if (!(wifi_profile->map_vendor_extension & BIT_BH_BSS)) {
			err(DEBUG_CAT_WIFI_CONFIG, "Dont set fronthaul profile %s as bh for %s\n", wifi_profile->Ssid, wdev->ifname);
			return 0;
		}
		wdev_wifi_profile = wapp_dev_list_lookup_by_mac_and_type(wapp, wifi_profile->mac_addr, WAPP_DEV_TYPE_AP);

		if (wdev_wifi_profile) {
			if (bh_idx < RADIO_5GH)
				os_snprintf(param_prefix, sizeof(param_prefix), "bh%d", bh_idx);
			else {
				err(DEBUG_CAT_WIFI_CONFIG, "LINE %d:Invalid bh profile index %d\n", __LINE__, bh_idx);
				return 0;
			}
		} else {
			err(DEBUG_CAT_WIFI_CONFIG, "Error!! bh wdev not found\n");
			return 0;
		}
	} else
		os_strcpy(param_prefix, "");

	os_snprintf(file_name, sizeof(file_name), "/etc/hostapd_%s_map.conf", wdev->ifname);

	/*set ssid */

	os_snprintf(param, sizeof(param), "%sssid", param_prefix);
	set_parameters(file_name, param, (char *)wifi_profile->Ssid, NON_DRIVER_PARAM);

	/*set wpa2psk */
	if (wifi_profile->AuthMode == 0x20) {
		/*set wpa */
		os_snprintf(param, sizeof(param), "%swpa", param_prefix);
		set_parameters(file_name, param, "2", NON_DRIVER_PARAM);

		/*set wpa_key_mgmt */
		os_snprintf(param, sizeof(param), "%swpa_key_mgmt", param_prefix);
		set_parameters(file_name, param, "WPA-PSK", NON_DRIVER_PARAM);

		/*set rsn_pairwise */
		if (wifi_profile->EncrypType == 0x08) {
			os_snprintf(param, sizeof(param), "%srsn_pairwise", param_prefix);
			set_parameters(file_name, param, "CCMP", NON_DRIVER_PARAM);
		}

		/*set wpa_passphrase */
		os_snprintf(param, sizeof(param), "%swpa_passphrase", param_prefix);
		set_parameters(file_name, param, (char *)wifi_profile->WPAKey, NON_DRIVER_PARAM);
	} else if (wifi_profile->AuthMode == 0x01) { /* OPEN */
		/*set wpa */
		os_snprintf(param, sizeof(param), "%swpa", param_prefix);
		set_parameters(file_name, param, "0", NON_DRIVER_PARAM);

		/*set wpa_key_mgmt */
		os_snprintf(param, sizeof(param), "%swpa_key_mgmt", param_prefix);
		set_parameters(file_name, param, "", NON_DRIVER_PARAM);

		/*set rsn_pairwise */
		if (wifi_profile->EncrypType == 0x08) {
			os_snprintf(param, sizeof(param), "%srsn_pairwise", param_prefix);
			set_parameters(file_name, param, "", NON_DRIVER_PARAM);
		}

		/*set wpa_passphrase */
		os_snprintf(param, sizeof(param), "%swpa_passphrase", param_prefix);
		set_parameters(file_name, param, "", NON_DRIVER_PARAM);
	} else
		err(DEBUG_CAT_WIFI_CONFIG, "wrong bh_profile config\n");

	/*set map_vendor_extension */
	os_snprintf(param, sizeof(param), "%smap_vendor_extension", param_prefix);
	os_snprintf(value, sizeof(value), "%c", wifi_profile->map_vendor_extension);
	set_parameters(file_name, param, value, NON_DRIVER_PARAM);

	if (is_backhaul_profile == TRUE) {
		os_snprintf(param, sizeof(param), "%smacaddr", param_prefix);
		os_snprintf(value, sizeof(value), "%02x:%02x:%02x:%02x:%02x:%02x", PRINT_MAC(wifi_profile->mac_addr));
		set_parameters(file_name, param, value, NON_DRIVER_PARAM);
	}

	return 0;
}
#endif /* HOSTAPD_MAP_SUPPORT */

/*
 *	Function is called to send an OID to fronthaul BSS to inform about
 *	profile parameters of one of the backhaul BSS present on the same device.
 */
int wapp_set_bh_wsc_profile(struct wifi_app *wapp, struct wapp_dev *wdev, struct wireless_setting *bh_wsc_profile)
{
#ifndef HOSTAPD_MAP_SUPPORT
	int ret;
#endif /* HOSTAPD_MAP_SUPPORT */
#if !defined(HOSTAPD_MAP_SUPPORT) || !defined(MTK_HOSTAPD_SUPPORT)
	struct wapp_req req;
	BOOLEAN auth_reset_required = FALSE;
	short auth_mode;
#endif /* MTK_HOSTAPD_SUPPORT */

#ifdef HOSTAPD_MAP_SUPPORT
	int bh_idx = 0;
	BOOLEAN bh_profile_update = FALSE;
	struct wireless_setting hapd_bh_wsc_profile = {0};
#endif /* HOSTAPD_MAP_SUPPORT */

	if (!wapp || !wdev)
		return WAPP_INVALID_ARG;

#if !defined(HOSTAPD_MAP_SUPPORT) || !defined(MTK_HOSTAPD_SUPPORT)
	os_memset(&req, 0, sizeof(struct wapp_req));
	req.req_id = WAPP_WSC_SET_BH_PROFILE;
	req.data.ifindex = wdev->ifindex;

	req.data.bh_wsc_profile.SSID.SsidLength = os_strlen((char *)bh_wsc_profile->Ssid);
	os_memcpy(req.data.bh_wsc_profile.SSID.Ssid, bh_wsc_profile->Ssid, os_strlen((char *)bh_wsc_profile->Ssid));
	COPY_MAC_ADDR(req.data.bh_wsc_profile.MacAddr, bh_wsc_profile->mac_addr);
#ifdef MAP_SUPPORT /*Add WAP3 support with MAP_R1 */
	if ((bh_wsc_profile->AuthMode & WSC_AUTHTYPE_SAE)
#ifdef MAP_R3
	    || (bh_wsc_profile->AuthMode & AUTH_DPP_ONLY)
#endif /* MAP_R3 */
	) {
		auth_reset_required = TRUE;
		auth_mode = bh_wsc_profile->AuthMode;
		bh_wsc_profile->AuthMode = WSC_AUTHTYPE_WPA2PSK;
	}
#endif
	req.data.bh_wsc_profile.AuthType = bh_wsc_profile->AuthMode;
	req.data.bh_wsc_profile.EncrType = bh_wsc_profile->EncrypType;
	req.data.bh_wsc_profile.bss_role = bh_wsc_profile->map_vendor_extension & BIT_BH_BSS;
	os_memcpy(req.data.bh_wsc_profile.Key, bh_wsc_profile->WPAKey, os_strlen((char *)bh_wsc_profile->WPAKey));
	req.data.bh_wsc_profile.KeyLength = os_strlen((char *)bh_wsc_profile->WPAKey);
	ret = wapp_req_send(wapp, wdev->ifname, &req);
	if (auth_reset_required)
		bh_wsc_profile->AuthMode = auth_mode;
	if (ret != 0) {
		err(DEBUG_CAT_WIFI_CONFIG, "%s WAPP_REQ_SEND FAILED\n", __func__);
		return ret;
	}
#endif /* MTK_HOSTAPD_SUPPORT */

#ifdef MTK_HOSTAPD_SUPPORT
	/*
	 * Write the BSS configuration to hostapd.conf map file
	 * setting BH BSS bit as the BH profile is to be updated here
	 *
	 */
	bh_wsc_profile->map_vendor_extension &= BIT_BH_BSS;
	ret = wdev_set_hapd_wifi_profile(wapp, wdev, bh_wsc_profile);
	if (ret != 0) {
		err(DEBUG_CAT_WIFI_CONFIG, DPP_MAP_PREX"%s wdev_set_hapd_wifi_profile failure\n", __func__);
		return WAPP_INVALID_ARG;
	}
	wdev->i_need_hostapd_reload = TRUE;
#endif /* MTK_HOSTAPD_SUPPORT */

#ifdef HOSTAPD_MAP_SUPPORT
	for (bh_idx = RADIO_24G; bh_idx < RADIO_5GH; bh_idx++) {
		wapp_get_hapd_wifi_profile(wapp, wdev, &hapd_bh_wsc_profile, bh_idx, TRUE);
		if (!(os_memcmp(bh_wsc_profile->mac_addr, hapd_bh_wsc_profile.mac_addr, ETH_ALEN))) {
			if ((bh_wsc_profile->AuthMode == hapd_bh_wsc_profile.AuthMode) &&
			    (bh_wsc_profile->EncrypType == hapd_bh_wsc_profile.EncrypType) &&
			    (bh_wsc_profile->map_vendor_extension == hapd_bh_wsc_profile.map_vendor_extension) &&
			    (hapd_bh_wsc_profile.map_vendor_extension & BIT_BH_BSS) &&
			    !(os_memcmp(bh_wsc_profile->Ssid, hapd_bh_wsc_profile.Ssid, os_strlen((char *)bh_wsc_profile->Ssid))) &&
			    !(os_memcmp(bh_wsc_profile->WPAKey, hapd_bh_wsc_profile.WPAKey, os_strlen((char *)bh_wsc_profile->WPAKey)))) {
				err(DEBUG_CAT_MISC, "new bh profile is already updated to hostapd conf\n");
				bh_profile_update = FALSE;
			} else {
				err(DEBUG_CAT_WIFI_CONFIG, "Update bh profile %d\n", bh_idx);
				bh_profile_update = TRUE;
			}
			break;
		} else if (bh_idx == RADIO_5GL) { /* BH MAC address not found, update as a new profile (first time update) */
			bh_idx = wdev->bh_profile_id;
			if (wdev->bh_profile_id < RADIO_5GL)
				wdev->bh_profile_id++;
			else
				wdev->bh_profile_id = 0;
			bh_profile_update = TRUE;
			break;
		}
	}

	if (bh_profile_update == TRUE) {
		notice(DEBUG_CAT_WIFI_CONFIG, "Update bh profile %d\n", bh_idx);
		wapp_set_hapd_wifi_profile(wapp, wdev, bh_wsc_profile, bh_idx, TRUE);
		wdev->i_need_hostapd_reload = TRUE;
	}
#endif /* HOSTAPD_MAP_SUPPORT */
	return ret;
}

int wapp_send_null_frames(struct wifi_app *wapp, struct wapp_dev *wdev, unsigned char *sta_addr, unsigned int count)
{
	int ret;
	struct wapp_req req;

	if (!wapp || !wdev)
		return WAPP_INVALID_ARG;

	req.req_id = WAPP_SEND_NULL_FRAMES;
	req.data.ifindex = wdev->ifindex;
	req.data.value = count;
	os_memcpy(req.data.mac_addr, sta_addr, ETH_ALEN);

	ret = wapp_req_send(wapp, wdev->ifname, &req);

	return ret;
}

#ifdef MAP_R6
int wapp_set_no_bcn(struct wifi_app *wapp, struct wapp_dev *wdev, char enable)
{
	int ret = 0;

	if (!wapp || !wdev)
		return WAPP_INVALID_ARG;

	if (wapp->drv_ops->drv_set_no_bcn)
		ret = wapp->drv_ops->drv_set_no_bcn(wapp->drv_data, wdev->ifname, enable);

	return ret;
}
#endif /* MAP_R6 */

#ifdef MAP_R4_SPT
int wapp_set_uplink_traffic_status(struct wifi_app *wapp, struct wapp_dev *wdev, u8 traffic_status)
{
	int ret;
	struct wapp_req req;

	if (!wapp || !wdev)
		return WAPP_INVALID_ARG;

	req.req_id = WAPP_SET_SRG_UPLINK_STATUS;
	req.data.ifindex = wdev->ifindex;
	req.data.value = traffic_status;

	ret = wapp_req_send(wapp, wdev->ifname, &req);
	return ret;
}

int wapp_set_sr_topo_info(struct wifi_app *wapp, struct wapp_dev *wdev, struct wapp_mesh_sr_topology *topo_update)
{
	int ret = 0;
	struct wapp_req req;

	if (!wapp || !wdev)
		return WAPP_INVALID_ARG;

	req.req_id = WAPP_SET_TOPOLOGY_UPDATE;
	req.data.ifindex = wdev->ifindex;
	req.data.band_index = IS_MAP_CH_24G(wdev->radio->op_ch) ? 0 : 1;

	notice(DEBUG_CAT_SR,
		 RED("[topo update]") "map count%d"
				      "mode %d, self_role %d\n"
				      "[almac]" MACSTR " [fh_bssid]" MACSTR " [BHMAC]" MACSTR "\n",
		 topo_update->map_dev_count, topo_update->map_dev_sr_support_mode, topo_update->self_role,
		 MAC2STR(topo_update->map_remote_al_mac), MAC2STR(topo_update->map_remote_fh_bssid),
		 MAC2STR(topo_update->map_remote_bh_mac));

	os_memcpy(&req.data.topology_update, topo_update, sizeof(struct wapp_mesh_sr_topology));

	ret = wapp_req_send(wapp, wdev->ifname, &req);
	return ret;
}

int wapp_set_sr_bitmap(struct wifi_app *wapp, struct wapp_dev *wdev, unsigned char *color_bm, unsigned char *pbssid_bm)
{
	int ret;
	struct wapp_req req;

	if (!wapp || !wdev)
		return WAPP_INVALID_ARG;

	req.req_id = WAPP_SET_SRG_BITMAP;
	req.data.ifindex = wdev->ifindex;
	req.data.value = 1;
	req.data.bm_info.color_31_0 = (color_bm[3] << 24) | (color_bm[2] << 16) | (color_bm[1] << 8) | color_bm[0];

	req.data.bm_info.color_63_32 = (color_bm[7] << 24) | (color_bm[6] << 16) | (color_bm[5] << 8) | color_bm[4];

	req.data.bm_info.bssid_31_0 = (pbssid_bm[3] << 24) | (pbssid_bm[2] << 16) | (pbssid_bm[1] << 8) | pbssid_bm[0];

	req.data.bm_info.bssid_63_32 = (pbssid_bm[7] << 24) | (pbssid_bm[6] << 16) | (pbssid_bm[5] << 8) | pbssid_bm[4];

	notice(DEBUG_CAT_SR, GRN("set color") "color:[63_32][0x%4x]-[31_0 [0x%4x] PBssid::[63_32][%4X]-[31_0][%4X]\n",
		     req.data.bm_info.color_63_32, req.data.bm_info.color_31_0, req.data.bm_info.bssid_63_32, req.data.bm_info.bssid_31_0);

	ret = wapp_req_send(wapp, wdev->ifname, &req);
	return ret;
}

#ifdef MTK_HOSTAPD_SUPPORT
int wapp_set_bss_color(struct wifi_app *wapp, struct wapp_dev *wdev, char *color_val, size_t len)
{
	int ret = 0;

	if (!wapp || !wdev)
		return WAPP_INVALID_ARG;

	if (wapp->drv_ops->drv_set_bss_color)
		ret = wapp->drv_ops->drv_set_bss_color(wapp->drv_data, wdev->ifname, color_val, len);

	return ret;
}

int wapp_set_sr_enable(struct wifi_app *wapp, struct wapp_dev *wdev, char enable)
{
	int ret = 0;

	if (!wapp || !wdev)
		return WAPP_INVALID_ARG;

	if (wapp->drv_ops->drv_set_sr_enable)
		ret = wapp->drv_ops->drv_set_sr_enable(wapp->drv_data, wdev->ifname, enable);

	return ret;
}

int wapp_set_bh_srg_bitmap(struct wifi_app *wapp, struct wapp_dev *wdev, char *bitmap, size_t len)
{
	int ret = 0;

	if (!wapp || !wdev)
		return WAPP_INVALID_ARG;

	if (wapp->drv_ops->drv_set_bh_bitmap)
		ret = wapp->drv_ops->drv_set_bh_bitmap(wapp->drv_data, wdev->ifname, bitmap, len);

	return ret;
}
#endif /* MTK_HOSTAPD_SUPPORT */
#endif

void wapp_csa_time_out_handler(void *eloop_data, void *user_ctx)
{
	struct wifi_app *wapp = (struct wifi_app *)eloop_data;
	struct apcli_association_info *apcli_stat_info = &wapp->cli_assoc_info;

	map_operating_channel_info(wapp);
	wapp->csa_notif_received = FALSE;

	if (wapp->link_change_notif_pending == TRUE) {
		apcli_stat_info->current_channel = wapp->csa_new_channel;
		wapp_send_1905_msg(wapp, WAPP_APCLI_ASSOC_STAT_CHANGE, sizeof(struct apcli_association_info),
				   (char *)&wapp->cli_assoc_info);
		wapp->link_change_notif_pending = FALSE;
	}
}

#ifdef STANDARD_NL_CMD
int wapp_nl_event_handle(struct wifi_app *wapp, struct nl80211_bss_info_arg arg, int ifindex)
{
	struct wapp_dev *wdev = NULL;
	int ret = -1;
	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (wdev) {
		if ((wapp->map->off_ch_scan_state.ch_scan_state == CH_SCAN_IDLE) &&
		 (wapp->partial_scan_count > 0 && (wapp->temp_scan_count < wapp->scan_count))
		  && (wdev->dev_type == WAPP_DEV_TYPE_STA || wdev->dev_type == WAPP_DEV_TYPE_APCLI)) {
			ret = wapp_scan_trigger(wapp, wdev, wapp->scan_ssids, 0);
		} else if ((wapp->map->off_ch_scan_state.ch_scan_state == CH_SCAN_IDLE) &&
			(wdev->dev_type == WAPP_DEV_TYPE_STA || wdev->dev_type == WAPP_DEV_TYPE_APCLI)) {
			wdev_nl_handle_scan_results(wapp, arg, ifindex);
		}
		else
			wdev_nl_handle_off_ch_scan_results(wapp, arg, ifindex);
	}

	return 0;
}
#endif

void wapp_event_handle(struct wifi_app *wapp, struct wapp_event *event)
{
	debug(DEBUG_CAT_EVENT, "event_id %d\n", event->event_id);
	struct wapp_dev *wdev = NULL;
	switch (event->event_id) {
	case WAPP_DEV_QUERY_RSP:
		wdev_dev_info_update(wapp, &event->data);
		break;
#ifdef MTK_HOSTAPD_SUPPORT
	case WAPP_CONFIG_NR_EVENT: {
		char ifname[IFNAMSIZ] = {0};

		if_indextoname(event->ifindex, ifname);
		wapp_event_get_neighbor_report_list(wapp, ifname, &event->data.NeighborRepList, event->len);

		break;
	}
#endif
	case WAPP_HT_CAP_QUERY_RSP:
		wdev_ht_cap_query_rsp_handle(wapp, event->ifindex, &event->data.ht_cap);
		break;
	case WAPP_VHT_CAP_QUERY_RSP:
		wdev_vht_cap_query_rsp_handle(wapp, event->ifindex, &event->data.vht_cap);
		break;
	case WAPP_MISC_CAP_QUERY_RSP:
		wdev_misc_cap_query_rsp_handle(wapp, event->ifindex, &event->data.misc_cap);
		break;
	case WAPP_CLI_QUERY_RSP:
		wdev_cli_query_rsp_handle(wapp, event->ifindex, &event->data);
		break;
	case WAPP_CLI_LIST_QUERY_RSP:
		wdev_cli_list_query_rsp_handle(wapp, event->ifindex, &event->data);
		break;
	case WAPP_CLI_JOIN_EVENT:
		wdev_cli_join_handle(wapp, event->ifindex, &event->data);
		break;
	case WAPP_CLI_LEAVE_EVENT:
		wdev_cli_leave_handle(wapp, event->ifindex, &event->data);
		break;
	case WAPP_CLI_ALL_LEAVE_EVENT:
		wdev_cli_all_leave_handle(wapp, event->ifindex, &event->data);
		break;
	case WAPP_CLI_PROBE_EVENT:
		wdev_cli_probe_handle(wapp, event->ifindex, &event->data);
		break;
	case WAPP_CHN_LIST_RSP:
		wdev_chn_list_query_rsp_handle(wapp, event->ifindex, &event->data.chn_list);
		break;
	case WAPP_OP_CLASS_RSP:
#ifndef MAP_6E_SUPPORT
		wdev_op_class_query_rsp_handle(wapp, event->ifindex, &event->data.op_class);
#endif
		break;
	case WAPP_BSS_INFO_RSP:
		wdev_bss_info_query_rsp_handle(wapp, event->ifindex, &event->data.bss_info);
		break;
	case WAPP_AP_METRIC_RSP:
		wdev_ap_metric_query_rsp_handle(wapp, event->ifindex, &event->data.ap_metrics);
		break;
#ifdef MAP_R2
	case WAPP_RADIO_METRIC_RSP:
		wdev_radio_metric_query_rsp_handle(wapp, event->ifindex, &event->data);
		break;
#endif
	case WAPP_CH_UTIL_QUERY_RSP:
		wdev_ch_util_query_rsp_handle(wapp, event->ifindex, &event->data);
		break;
	case WAPP_AP_CONFIG_RSP:
		wdev_ap_config_query_rsp_handle(wapp, event->ifindex, &event->data);
		break;
	case WAPP_APCLI_QUERY_RSP:
		wdev_apcli_query_rsp_handle(wapp, event->ifindex, &event->data);
		break;
#ifdef MAP_SUPPORT
	case MAP_BH_STA_WPS_DONE:
#ifdef DPP_R2_SUPPORT
		wapp_dpp_connected(wapp, event->ifindex);
#endif /* DPP_R2_SUPPORT */
		map_event_bh_sta_wap_done(wapp, event->ifindex, &event->data);
		break;
	case MAP_TRIGGER_RSSI_STEER:
		map_event_str_sta_rsp_handle(wapp, event->ifindex, &event->data);
		break;
#endif
	case WAPP_RCEV_BCN_REPORT:
		wdev_bcn_report_handle(wapp, event->ifindex, &event->data);
		break;
	case WAPP_RCEV_BCN_REPORT_COMPLETE:
		wdev_bcn_report_complete_handle(wapp, event->ifindex, &event->data);
		break;
	case WAPP_BSSLOAD_RSP:
		wdev_bssload_query_rsp_handle(wapp, event->ifindex, &event->data);
		break;
	case WAPP_RCEV_MONITOR_INFO:
		wdev_mnt_info_query_rsp_handle(wapp, event->ifindex, &event->data);
		break;
	case WAPP_STA_RSSI_RSP:
		wdev_sta_rssi_query_rsp_handle(wapp, event->ifindex, &event->data);
		break;
#ifdef COSR_SUPPORT
	case WAPP_COSR_STA_RSSI_RSP:
		wdev_cosr_sta_rssi_query_rsp_handle(wapp, event->ifindex, &event->data);
		break;
#endif /* COSR_SUPPORT */
	case WAPP_CLI_ACTIVE_CHANGE:
		wdev_cli_active_change_rsp_handle(wapp, event->ifindex, &event->data);
		break;
	case WAPP_BSS_STATE_CHANGE:
		wdev_bss_stat_change_handle(wapp, event->ifindex, &event->data);
		break;
#ifdef WPS_UNCONFIG_FEATURE_SUPPORT
	/* Event used for jedi driver, Now handled in hostapd */
	case WAPP_CONFIG_WPS_EVENT:
		wdev_wps_configuration_handle(wapp, event->ifindex, &event->data);
		break;
#endif
	case WAPP_CH_CHANGE:
		wdev_chn_change_rsp_handle(wapp, event->ifindex, &event->data);
		map_operating_channel_info(wapp);
		break;
	case WAPP_SSID_CHANGE:
		wdev_ssid_change_rsp_handle(wapp, event->ifindex, &event->data);
		break;
	case WAPP_TX_POWER_CHANGE:
		/* TBD */
		break;
	case WAPP_APCLI_ASSOC_STATE_CHANGE:
	#ifndef STANDARD_NL_CMD
		wdev_apcli_assoc_stat_change_handle(wapp, event->ifindex, &event->data);
	#endif
		break;
	case WAPP_APCLI_ASSOC_STATE_CHANGE_VENDOR10:
		wdev_apcli_assoc_stat_change_handle_vendor10(wapp, event->ifindex, &event->data);
		break;
	case WAPP_BSSLOAD_CROSSING:
		wdev_bssload_crossing_handle(wapp, event->ifindex, &event->data);
		break;
	case WAPP_CSA_EVENT:
		wdev_csa_event_rsp_handle(wapp, event->ifindex, &event->data);
		if (!wapp->map->TurnKeyEnable)
			break;
		wapp->csa_notif_received = TRUE;

		if (wapp->map->quick_ch_change == FALSE) {
			struct wapp_dev *temp_wdev = NULL;
			struct dl_list *dev_list;

			dev_list = &wapp->dev_list;
			dl_list_for_each(temp_wdev, dev_list, struct wapp_dev, list)
			{
				if (!temp_wdev) {
					err(DEBUG_CAT_EVENT, "temp dev is NULL%s\n", __func__);
					break;
				}
				if (temp_wdev->dev_type == WAPP_DEV_TYPE_STA && temp_wdev->ifindex == event->ifindex) {
#if WEXT_SUPPORT
					u8 Enable = 0;

					wapp_set_apcli_mode(wapp, (const char *)temp_wdev->ifname, (char *)&Enable, 1);
#else
#ifdef MTK_HOSTAPD_SUPPORT
					if (wapp->drv_ops->drv_send_disable_network)
						wapp->drv_ops->drv_send_disable_network(wapp->drv_data, temp_wdev->ifname,
						temp_wdev->network_id);
#endif /* MTK_HOSTAPD_SUPPORT */
#endif
					break;
				}
			}
			eloop_register_timeout(10, 0, wapp_csa_time_out_handler, wapp, NULL);
		}
		break;
	case WAPP_STA_CNNCT_REJ:
		wdev_sta_cnnct_rej_handle(wapp, event->ifindex, &event->data);
		break;
	case WAPP_APCLI_RSSI_RSP:
		wdev_apcli_rssi_query_rsp_handle(wapp, event->ifindex, &event->data);
		break;
	case WAPP_WSC_SCAN_COMP_NOTIF:
		wdev_process_wsc_scan_comp(wapp, event->ifindex, &event->data);
		break;
	case WAPP_SCAN_RESULT_RSP:
		wdev = wapp_dev_list_lookup_by_ifindex(wapp, event->ifindex);
		if (wdev) {
			if ((wapp->map->off_ch_scan_state.ch_scan_state == CH_SCAN_IDLE) &&
				(wdev->dev_type == WAPP_DEV_TYPE_STA || wdev->dev_type == WAPP_DEV_TYPE_APCLI))
				wdev_handle_scan_results(wapp, event->ifindex, &event->data);
#ifndef STANDARD_NL_CMD
			else
				wdev_handle_off_ch_scan_results(wapp, event->ifindex, &event->data);
#endif
		}
		break;
	case WAPP_MAP_VENDOR_IE:
		wdev_handle_map_vend_ie_evt(wapp, event->ifindex, &event->data);
		break;
#ifdef DPP_SUPPORT
	case WAPP_DPP_ACTION_FRAME_RECEIVED:
		debug(DEBUG_CAT_EVENT, "action frame event\n");
		wdev_get_dpp_action_frame(wapp, event->ifindex, &event->data);
		break;
	case WAPP_DPP_ACTION_FRAME_STATUS:
		wdev_handle_dpp_frm_tx_status(wapp, event->ifindex, &event->data);
		break;
#endif /*DPP_SUPPORT */
#ifdef MAP_R3
	case WAPP_STA_INFO:
		debug(DEBUG_CAT_EVENT, "station connection event\n");
		wdev_handle_dpp_sta_info(wapp, event->ifindex, &event->data);
		break;
	case WAPP_R3_DPP_URI_INFO:
		debug(DEBUG_CAT_EVENT, "URI info event\n");
		wdev_handle_dpp_uri_info(wapp, event->ifindex, &event->data);
		break;
#endif /* MAP_R3 */
#ifdef QOS_R1
	case WAPP_QOS_ACTION_FRAME_EVENT:
		wapp_handle_qos_action_frame(wapp, event->ifindex, &event->data);
		break;
	case WAPP_MSCS_CLASSIFIER_PARAM_EVENT:
		wapp_handle_mscs_descriptor_element(wapp, event->ifindex, &event->data);
		break;
	case WAPP_VEND_SPEC_UP_TUPLE_EVENT:
		wdev_handle_vend_spec_up_tuple_event(wapp, event->ifindex, &event->data);
		break;
#endif /*QOS_R1 */
#ifndef MTK_MLO_MAP_SUPPORT
	case WAPP_MAP_WSC_CONFIG:
		wdev_handle_wsc_config_write(wapp, event->ifindex, &event->data);
		break;
#endif
	case WAPP_WSC_EAPOL_START_NOTIF:
		wdev_handle_wsc_eapol_notif(wapp, event->ifindex, &event->data);
		break;
	case WAPP_WSC_EAPOL_COMPLETE_NOTIF:
		wdev_handle_wsc_eapol_end_notif(wapp, event->ifindex, &event->data);
		break;
	case WAPP_SCAN_COMPLETE_NOTIF:
		if (wapp->map->off_ch_scan_state.ch_scan_state == CH_SCAN_IDLE)
			wdev_handle_scan_complete_notif(wapp, event->ifindex, &event->data);
		break;
	case WAPP_A4_ENTRY_MISSING_NOTIF:
		wdev_handle_a4_entry_missing_notif(wapp, event->ifindex, &event->data);
		break;
	case WAPP_RADAR_DETECT_NOTIF:
		wdev_handle_radar(wapp, event->ifindex, &event->data);
		break;
	case WAPP_CAC_STOP:
		notice(DEBUG_CAT_EVENT, "\n CAC stop received");
		wdev_handle_cac_stop(wapp, event->ifindex, &event->data.cac_info.channel, event->data.cac_info.ret, FALSE);
		break;
#ifdef MAP_R2
	case WAPP_STA_DISASSOC_EVENT:
		notice(DEBUG_CAT_MISC, "WAPP_STA_DISASSOC_EVENT\n");
		wdev_sta_disassoc_stats_handle(wapp, event->ifindex, &event->data);
		break;
#endif
	case WAPP_CAC_PERIOD_EVENT:
		notice(DEBUG_CAT_EVENT, "WAPP_CAC_PERIOD_EVENT\n");
		wdev_handle_cac_period(wapp, event->ifindex, &event->data);
		break;
#ifdef WIFI_MD_COEX_SUPPORT
	case WAPP_UNSAFE_CHANNEL_EVENT:
		notice(DEBUG_CAT_EVENT, "WAPP_UNSAFE_CHANNEL_EVENT\n");
		wdev_handle_unsafe_ch_event(wapp, &event->data);
		break;
	case WAPP_BAND_STATUS_CHANGE_EVENT:
		notice(DEBUG_CAT_EVENT, "WAPP_BAND_STATUS_CHANGE_EVENT\n");
		wdev_handle_band_status_change(wapp, event->ifindex, &event->data);
		break;
#endif
#ifdef DPP_R2_SUPPORT
	case WAPP_DPP_CCE_RSP:
		notice(DEBUG_CAT_EVENT, "WAPP_DPP_CCE_RSP\n");
		wapp_dpp_handle_cce_channel(wapp, event->ifindex, &event->data);
		break;
#endif
#ifdef MAP_R3_RECONFIG
	case WAPP_R3_RECONFIG_TRIGGER:
		wdev_handle_reconfig_trigger(wapp, event->ifindex, &event->data);
		break;
#endif
#ifdef LOW_POWER_SUPPORT
	case WAPP_NO_STA_CONNECT_TIMEOUT_EVENT:
		wdev_handle_no_sta_connect_timeout(wapp, event->ifindex, &event->data);
		break;
	case WAPP_NO_DATA_TRAFFIC_TIMEOUT_EVENT:
		wdev_handle_no_traffic_timeout(wapp, event->ifindex, &event->data);
		break;
	case WAPP_WIFI_UP_EVENT:
		wdev_handle_wifi_open(wapp, event->ifindex, &event->data);
		break;
	case WAPP_WIFI_DOWN_EVENT:
		wdev_handle_wifi_close(wapp, event->ifindex, &event->data);
		break;
#endif
#ifdef MAP_R3
	case WAPP_CH_CHANGE_R3:
		wapp->map->ch_change_done = 1;
		break;
#endif
#ifdef MAP_R4_SPT
	case WAPP_SELF_SRG_BITMAP_EVENT:
		debug(DEBUG_CAT_EVENT, GRN("bm event") "WAPP_SELF_SRG_BITMAP_EVENT %d\n", event->event_id);
		wdev_handle_self_srg_bm_event(wapp, event->ifindex, &event->data);
		break;

	case WAPP_UPLINK_TRAFFIC_EVENT:
		debug(DEBUG_CAT_EVENT, "WAPP_UPLINK_TRAFFIC_EVENT %d\n", event->event_id);
		wdev_handle_uplink_traffic_event(wapp, event->ifindex, &event->data);
		break;
#endif
#ifdef COSR_SUPPORT
	case WAPP_COSR_FOUND_COAP:
		debug(DEBUG_CAT_MISC, "WAPP_COSR_FOUND_COAP %d\n", event->event_id);
		wdev_handle_found_coap_event(wapp, event->ifindex, &event->data);
		break;
	case WAPP_COSR_ACTION_FRAME_RECEIVED:
		debug(DEBUG_CAT_MISC, "WAPP_COSR_ACTION_FRAME_RECEIVED %d\n", event->event_id);
		wdev_get_cosr_action_frame(wapp, event->ifindex, &event->data);
		break;
	case WAPP_COSR_STA_RSSI_CHANGE:
		debug(DEBUG_CAT_MISC, "WAPP_COSR_STA_RSSI_CHANGE %d\n", event->event_id);
		wdev_handle_cosr_sta_rssi_change(wapp, event->ifindex, &event->data);
		break;
	case WAPP_COSR_COAP_UPDATE:
		debug(DEBUG_CAT_MISC, "WAPP_COSR_STA_RSSI_CHANGE %d\n", event->event_id);
		break;
	case WAPP_SR_SUPPORT_MODE_RSP:
		debug(DEBUG_CAT_MISC, "WAPP_SR_SUPPORT_MODE_RSP\n");
		wdev_sr_support_mode_query_rsp_handle(wapp, event->ifindex, &event->data);
		break;
		/* TBD */
#endif /*COSR_SUPPORT*/
	case WAPP_AP_JOIN_EVENT:
		debug(DEBUG_CAT_EVENT, "WAPP_AP_JOIN_EVENT %d\n", event->event_id);
		wdev_ap_join_handle(wapp,  event->ifindex, &event->data);
		break;
	case WAPP_EHT_OP_PUNCTURED_BITMAP:
		debug(DEBUG_CAT_EVENT, "WAPP_EHT_OP_PUNCTURED_BITMAP %d\n", event->event_id);
		wdev_handle_wapp_eht_oper_punc_bitmap_info(wapp, event->ifindex, &event->data);
		break;
	case WAPP_T2LM_RESPONSE_REPORT:
		debug(DEBUG_CAT_EVENT, "WAPP_T2LM_RESPONSE_REPORT %d, len:%d\n", event->event_id, event->len);
		break;
	default:
		debug(DEBUG_CAT_EVENT, "unknown WAPP_EVENT_ID %d\n", event->event_id);
		break;
	}
}

int wapp_cmd_disconnect_sta(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	u8 mac_addr[MAC_ADDR_LEN];
	char *token;
	int i;

	if (!argv[1]) {
		err(DEBUG_CAT_MISC, "Invalid argument\n");
		return WAPP_INVALID_ARG;
	}

	i = 0;
	token = strtok(argv[1], ":");
	while (token != NULL) {
		AtoH(token, (char *)&mac_addr[i], 1);
		i++;
		if (i >= MAC_ADDR_LEN)
			break;
		token = strtok(NULL, ":");
	}

	notice(DEBUG_CAT_MISC,
		     "disconnect sta:\n"
		     "\t sta = " MACSTR "\n",
		     MAC2STR(mac_addr));

	// TODO: 1. search the sta from all ap_dev
	// TODO: 2. if the sta support btm, use btm (DISASSOC_STA case). else just send disconnect cmd
#if WEXT_SUPPORT
	struct wapp_dev *wdev = NULL;

	wdev = wapp_dev_list_lookup_by_ifname(wapp, argv[1]);
	if (wdev)
		wapp_set_DisConnectSta(wapp, (const char *)wdev->ifname, (char *)mac_addr, MAC_ADDR_LEN);
#else

#ifdef MTK_HOSTAPD_SUPPORT
	if (wapp->drv_ops->drv_send_sta_deauth)
		wapp->drv_ops->drv_send_sta_deauth(wapp->drv_data, iface, (char *)mac_addr);
#else
	int ret = 0;
	struct wapp_dev *wdev = NULL;

	wdev = wapp_dev_list_lookup_by_ifname(wapp, argv[1]);

	ret = wapp->drv_ops->drv_set_DisConnectSta(wapp->drv_data, wdev->ifname, mac_addr);
	if (ret < 0) {
		err(DEBUG_CAT_MISC, "set DisConnectSta, command failed.\n");
		return WAPP_INVALID_ARG;
	}
	debug(DEBUG_CAT_MISC, "set DisConnectSta = %02x:%02x:%02x:%02x:%02x:%02x\n", PRINT_MAC(mac_addr));
#endif /* MTK_HOSTAPD_SUPPORT */
#endif
	return WAPP_SUCCESS;
}

struct wapp_ctrl_cmd wapp_cmd[] = {
	{"acl", wapp_cmd_acl, "[arg1]:add [arg2:mac,mac,...], [arg1]:del [arg2:mac,mac,...], [arg1]:policy [arg2:0,1,2], [arg1]:clear_all"},
	{"blacl", wapp_cmd_blacl, "[arg1]:bladd [arg2:mac,mac,...], [arg1]:bldel [arg2:mac,mac,...]"},
	{"pmf", wapp_cmd_pmf, "[arg1]:enable,disable"},
	{"wdev_query",        wapp_cmd_wdev_query,                     "[arg1 interface]: query all wdev of the interface"},
	{"wdev_list",         wapp_cmd_wdev_list,                      "show wdev list"},
	{"query",             wapp_cmd_wdev_query_by_req_id,
				"[arg1]:interface [arg2]:req_id. Use req_id to send query to the specified interface"},
	{"ht_cap_query",      wapp_cmd_wdev_ht_cap_query,              "[arg1]:interface. query ht_cap of the interface"},
	{"vht_cap_query",     wapp_cmd_wdev_vht_cap_query,             "[arg1]:interface. query vht_cap of the interface"},
	{"cli",               wapp_cmd_query_cli,                      "[arg1]:interface. [arg2]: mac addr of the cli to be queried"},
	{"cli_list",          wapp_cmd_show_cli_list,                  "[arg1]:interface. show the cli_list of an ap_dev"},
	{"ap_info",           wapp_cmd_ap_info,                        "[arg1]:interface. show ap info of an ap_dev"},
	{"chn_list",          wapp_cmd_chn_list_info,                  "[arg1]:interface. show chn list info of an ap_dev"},
	{"apcli_info",		wapp_cmd_apcli_info,	"[arg1]:interface. show upstream ap info of an sta dev"},
	{"bss_info",          wapp_cmd_bss_info,                       "[arg1]:interface. show bss info of an ap_dev"},
	{"ap_metric",         wapp_cmd_ap_metric,                      "[arg1]:interface. show ap metric of an ap_dev"},
	{"set_sec",           wapp_cmd_set_sec,
				"[arg1]:interface. [argv2] auth. [arg3] encryp. [arg4] passphrase. set security and passphrases of a wdev"},
	{"set_ch",            wapp_cmd_set_ch,
				"[arg1]:interface. [argv2] channel. set op channel of the interface"},
	{"disconnect_sta",    wapp_cmd_disconnect_sta,                 "[arg1]:interface. [argv2] mac addr of the sta"},
	{"set_ssid",          wapp_cmd_set_ssid,                       "[arg1]:interface. [argv2] ssid. set ssid of the interface"},
	{"ra_info",           wapp_cmd_show_radio_info,                "show radio info"},
	{"probe_info",        wapp_cmd_show_probe_info,                "show probe info list"},
	{"block_list",        wapp_cmd_show_blocked_list,              "[arg1]:interface. show blocked list"},
	{"bcn_start",		  wapp_cmd_set_bss_start,                  "[arg1]:interface. start bss of this interface"},
	{"bcn_stop",		  wapp_cmd_set_bss_stop,                   "[arg1]:interface. stop bss of this interface"},
	{"txpwr_prctg",       wapp_cmd_set_txpwr_prctg,                "[arg1]:interface. [arg2] tx power percentage"},
	{"scan_request",      wapp_cmd_get_scan_result,                "send scan request"},
#ifdef CSA_BAND_SUPPORT
	{"csa_2g",      wapp_cmd_set_2g_csa_support,                "Channel switch 2G enable/disable 1/0"},
	{"csa",      wapp_cmd_set_csa_support,                "Channel switch 5G/6G enable/disable 1/0"},
#endif
#ifdef STANDARD_NL_CMD
	{"nl_events",		  wapp_nlevent_number_list,					"Just print NL event numbers"},
	{"set_partial_scan_count",		wapp_cmd_set_partial_scan_count,			"[arg1] partial scan count value"},
#endif
	{"set_load_thrd",	  wapp_cmd_set_load_thrd,
				"[arg1]:interface. [arg2] High bss load threshold. [arg3] Low bss load threshold."},
	{"log_level",		wapp_cmd_set_log_level,			"set log level"},
	{"set_log_option",		wapp_cmd_set_log_option,			"set log option"},
	{"get_log_info",		wapp_cmd_get_log_info,			"get log info"},
	{"set_log_category",		wapp_cmd_set_log_category,			"set log category"},
	{"air_mnt_file",	  wapp_cmd_set_air_mnt,
				"[arg1]:interface. [arg2] no of max packet to consider [arg3] no of sta to monitor"},
	{"bh_assoc_ctrl_set", wapp_cmd_set_bh_assoc_ctrl,
		"read file /etc/map/bh_assoc_ctrl.cfg in format <BSSID> <1or2 which profile disallow>"},
#ifdef ROAM_CALIB
	{"RoamStaCalib", wapp_cmd_roam_calib_sta,
		"Roaming Sta calibration Delete<0><MACAddr>;Add<1><MACAddr>;Display<2>;FeatureEnable<3><0/1>;Clear all<4>"},
#endif
#if 0 /* TODO */
	{"set_op_class", wapp_cmd_wdev_ht_cap_query, "[arg1]:interface. query ht_cap of the interface"},
	{"set_ssid", wapp_cmd_wdev_ht_cap_query, "[arg1]:interface. query ht_cap of the interface"},
#ifdef MAP_SUPPORT
	{"set_devrole", wapp_cmd_wdev_ht_cap_query, "[arg1]:interface. query ht_cap of the interface"},
	{"set_bh_type", wapp_cmd_wdev_ht_cap_query, "[arg1]:interface. query ht_cap of the interface"},
	{"set_bh_if", wapp_cmd_wdev_ht_cap_query, "[arg1]:interface. query ht_cap of the interface"},
#endif
#endif /* TODO */
	{"help", wapp_cmd_show_help, "show this help"},
	{NULL, wapp_cmd_show_help}};

int wapp_ctrl_interface_cmd_handle(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	int i, ret;

	if (!argv[0]) {
		err(DEBUG_CAT_MISC, "Invalid argument\n");
		return WAPP_INVALID_ARG;
	}

	for (i = 0; (wapp_cmd[i].cmd != NULL) && (i < ARRAY_SIZE(wapp_cmd)); i++) {
		if (os_strncmp(wapp_cmd[i].cmd, argv[0], os_strlen(argv[0])) == 0) {
			ret = wapp_cmd[i].cmd_proc(wapp, iface, argc, argv);
			if (ret != WAPP_SUCCESS)
				err(DEBUG_CAT_MISC, "cmd [%s] failed. ret = %d\n", wapp_cmd[i].cmd, ret);
			break;
		}
	}

	return WAPP_SUCCESS;
}

int wapp_cmd_show_help(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	u8 i = 0;

	printf("\033[1;36m available cmds: \033[0m\n");
	for (i = 0; (wapp_cmd[i].cmd != NULL); i++)
		printf("\033[1;36m %20s  \t -  %s\033[0m\n", wapp_cmd[i].cmd, wapp_cmd[i].help);

	return WAPP_SUCCESS;
}

int wapp_cmd_acl(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	int ret = -1, valid = 1;

	if (argc == 2) {
		if (os_strcasecmp(argv[1], "clear_all") == 0)
			ret = acl_cmd(wapp, iface, ACL_FLUSH);
		else
			valid = 0;
	} else if (argc == 3) {
		char *cmd = argv[1];
		char *value = argv[2];

		if (os_strcasecmp(cmd, "policy") == 0) {
			if (os_strcasecmp(value, "0") == 0)
				ret = acl_cmd(wapp, iface, ACL_POLICY_0);
			else if (os_strcasecmp(value, "1") == 0)
				ret = acl_cmd(wapp, iface, ACL_POLICY_1);
			else if (os_strcasecmp(value, "2") == 0)
				ret = acl_cmd(wapp, iface, ACL_POLICY_2);
			else
				valid = 0;
		} else if ((strlen(value) + 1) % 18 == 0) {
			char *token;
			int i = 0, n = (strlen(value) + 1) / 18;
			int addr_list_size = n * MAC_ADDR_LEN;
			u8 *addr_list = (u8 *)malloc(addr_list_size * sizeof(u8));

			if (addr_list == NULL) {
				valid = 0;
				return WAPP_RESOURCE_ALLOC_FAIL;
			}

			for (token = strtok(value, ":,"); token != NULL; token = strtok(NULL, ":,")) {
				if (strlen(token) != 2 || i >= addr_list_size) {
					valid = 0;
					break;
				}
				addr_list[i++] = (u8)strtol(token, NULL, 16);
			}

			if (valid) {
				if (os_strcasecmp(cmd, "add") == 0)
					ret = acl_cmd_data(wapp, iface, ACL_ADD, addr_list, addr_list_size);
				else if (os_strcasecmp(cmd, "del") == 0)
					ret = acl_cmd_data(wapp, iface, ACL_DEL, addr_list, addr_list_size);
				else
					valid = 0;
			}
			free(addr_list);
		} else {
			valid = 0;
		}
	} else {
		valid = 0;
	}

	if (!valid) {
		notice_np(DEBUG_CAT_MISC, "Usage:\n");
		notice_np(DEBUG_CAT_MISC, "\tadd <mac>,<mac>,...\n");
		notice_np(DEBUG_CAT_MISC, "\tdel <mac>,<mac>,...\n");
		notice_np(DEBUG_CAT_MISC, "\tpolicy [0,1,2]\n");
		notice_np(DEBUG_CAT_MISC, "\tclear_all\n");
		ret = WAPP_INVALID_ARG;
	}

	return ret;
}

int wapp_cmd_blacl(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	int ret = -1, valid = 1;

	if (argc == 3) {
		char *cmd = argv[1];
		char *value = argv[2];

		if ((strlen(value) + 1) % 18 == 0) {
			char *token;
			int i = 0, n = (strlen(value) + 1) / 18;
			int addr_list_size = n * MAC_ADDR_LEN;
			u8 *addr_list = (u8 *)malloc(addr_list_size * sizeof(u8));

			if (addr_list == NULL) {
				valid = 0;
				return WAPP_RESOURCE_ALLOC_FAIL;
			}

			for (token = strtok(value, ":,"); token != NULL; token = strtok(NULL, ":,")) {
				if (strlen(token) != 2 || i >= addr_list_size) {
					valid = 0;
					break;
				}
				addr_list[i++] = (u8)strtol(token, NULL, 16);
			}

			if (valid) {
				notice_np(DEBUG_CAT_MISC, "addr_list_size %d\n", addr_list_size);
				if (os_strcasecmp(cmd, "bladd") == 0)
					ret = acl_cmd_bldata(wapp, iface, BL_ADD, addr_list, addr_list_size);
				else if (os_strcasecmp(cmd, "bldel") == 0)
					ret = acl_cmd_bldata(wapp, iface, BL_DEL, addr_list, addr_list_size);
				else
					valid = 0;
			}
			free(addr_list);
		} else {
			valid = 0;
		}
	} else {
		valid = 0;
	}

	if (!valid) {
		notice_np(DEBUG_CAT_MISC, "Usage:\n");
		notice_np(DEBUG_CAT_MISC, "\tadd <mac>,<mac>,...\n");
		notice_np(DEBUG_CAT_MISC, "\tdel <mac>,<mac>,...\n");
		ret = WAPP_INVALID_ARG;
	}
	return ret;
}

int wapp_cmd_pmf(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	int ret = -1;

	if (argc == 2) {
		char *value = argv[1];
		struct wapp_dev *wdev = wapp_dev_list_lookup_by_ifname(wapp, iface);

		if (os_strcasecmp(value, "disable") == 0)
			ret = wdev_enable_pmf(wapp, wdev, FALSE);
		else if (os_strcasecmp(value, "enable") == 0)
			ret = wdev_enable_pmf(wapp, wdev, TRUE);
	}

	return ret;
}

int wapp_cmd_wdev_query(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	printf("\033[1;36m inf=%s \033[0m\n", argv[1]);
	wapp_query_wdev(wapp, argv[1]);
	return WAPP_SUCCESS;
}

int wapp_cmd_wdev_ht_cap_query(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	printf("\033[1;36m %s \033[0m\n", __FUNCTION__);
	wapp_query_wdev_ht_cap(wapp, argv[1]);
	return WAPP_SUCCESS;
}

int wapp_cmd_wdev_vht_cap_query(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	printf("\033[1;36m %s \033[0m\n", __FUNCTION__);
	wapp_query_wdev_vht_cap(wapp, argv[1]);
	return WAPP_SUCCESS;
}

int wapp_cmd_wdev_query_by_req_id(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	char *endptr = NULL;
	unsigned long reg_id = 0;

	errno = 0;
	reg_id = strtoul(argv[2], &endptr, 10);
	if (errno != 0 || endptr == argv[2] || *endptr != '\0' || reg_id > UINT8_MAX) {
		err(DEBUG_CAT_MISC, "Invalid reg_id: %s\n", argv[2]);
		return -1;
	}

	printf("\033[1;36m %s req_id = %u\033[0m\n", __func__, (u8)reg_id);
	wapp_query_wdev_by_req_id(wapp, argv[1], (u8)reg_id);
	return WAPP_SUCCESS;
}

int wapp_cmd_query_cli(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	u8 i;
	u8 mac_addr[MAC_ADDR_LEN];
	char str[3];
	struct wapp_dev *wdev = NULL;

	if (argc != 3)
		return WAPP_INVALID_ARG;

	wdev = wapp_dev_list_lookup_by_ifname(wapp, argv[1]);
	if (wdev && wdev->dev_type == WAPP_DEV_TYPE_AP) {
		for (i = 0; i < MAC_ADDR_LEN; i++) {
			str[0] = argv[2][i * 2];
			str[1] = argv[2][i * 2 + 1];
			str[2] = 0;
			mac_addr[i] = strtol(str, NULL, 16);
		}
		printf("\033[1;36m %s mac_addr = %s\033[0m\n", __FUNCTION__, argv[2]);
		wapp_query_cli(wapp, argv[1], mac_addr);
	}
	return WAPP_SUCCESS;
}

int wapp_cmd_set_bss_start(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	struct wapp_dev *wdev = NULL;

	if (!argv[1]) {
		err(DEBUG_CAT_MISC, "Invalid argument\n");
		return WAPP_INVALID_ARG;
	}

	wdev = wapp_dev_list_lookup_by_ifname(wapp, argv[1]);
	if (wdev && wdev->dev_type == WAPP_DEV_TYPE_AP) {
		notice(DEBUG_CAT_MISC, "inf = %s\n", argv[1]);
#ifndef MTK_HOSTAPD_SUPPORT
		wapp_set_bss_start(wapp, argv[1]);
#else
#ifdef MAP_R6
		wapp_set_no_bcn(wapp, wdev, 0);
#else
		if (wapp->drv_ops->drv_send_ap_intf_enable)
			wapp->drv_ops->drv_send_ap_intf_enable(wapp->drv_data, iface);
#endif
#endif /* MTK_HOSTAPD_SUPPORT */
	}
	return WAPP_SUCCESS;
}

#ifdef STANDARD_NL_CMD
int wapp_nl_Scan_dump(struct scan_bss_info *data)
{
	debug_np(DEBUG_CAT_MISC, "Bssid\t Chnl\t CChnl \t Rssi\t MinS\t Priv\t SSidL\t SSid\t Auth\t Encry\t ht_cap\t vht_cap\n");
	debug_np(DEBUG_CAT_MISC, ""MACSTR"\t", MAC2STR(data->Bssid));
	debug_np(DEBUG_CAT_MISC, " %d\t", data->Channel);
	debug_np(DEBUG_CAT_MISC, " %d\t", data->CentralChannel);
	debug_np(DEBUG_CAT_MISC, " %d\t", data->Rssi);
	debug_np(DEBUG_CAT_MISC, " %d\t", data->MinSNR);
	debug_np(DEBUG_CAT_MISC, " %d\t", data->Privacy);
	debug_np(DEBUG_CAT_MISC, " %d\t", data->SsidLen);
	debug_np(DEBUG_CAT_MISC, " %s\t", data->Ssid);
	debug_np(DEBUG_CAT_MISC, " %x\t", data->AuthMode);
	debug_np(DEBUG_CAT_MISC, " %x\t\n", data->EncrypType);
	return 0;
}

int wapp_nlevent_number_list(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{

	printf("===================== NL Events ================\n\n");
	printf("%d  NL80211_CMD_UNSPEC\n", NL80211_CMD_UNSPEC);
	printf("%d  NL80211_CMD_GET_WIPHY\n", NL80211_CMD_GET_WIPHY);
	printf("%d  NL80211_CMD_SET_WIPHY\n", NL80211_CMD_SET_WIPHY);
	printf("%d  NL80211_CMD_NEW_WIPHY\n", NL80211_CMD_NEW_WIPHY);
	printf("%d  NL80211_CMD_DEL_WIPHY\n", NL80211_CMD_DEL_WIPHY);
	printf("%d  NL80211_CMD_GET_INTERFACE\n", NL80211_CMD_GET_INTERFACE);
	printf("%d  NL80211_CMD_SET_INTERFACE\n", NL80211_CMD_SET_INTERFACE);
	printf("%d  NL80211_CMD_NEW_INTERFACE\n", NL80211_CMD_NEW_INTERFACE);
	printf("%d  NL80211_CMD_DEL_INTERFACE\n", NL80211_CMD_DEL_INTERFACE);
	printf("%d  NL80211_CMD_GET_KEY\n", NL80211_CMD_GET_KEY);
	printf("%d  NL80211_CMD_SET_KEY\n", NL80211_CMD_SET_KEY);
	printf("%d  NL80211_CMD_NEW_KEY\n", NL80211_CMD_NEW_KEY);
	printf("%d  NL80211_CMD_DEL_KEY\n", NL80211_CMD_DEL_KEY);
	printf("%d  NL80211_CMD_GET_BEACON\n", NL80211_CMD_GET_BEACON);
	printf("%d  NL80211_CMD_SET_BEACON\n", NL80211_CMD_SET_BEACON);
	printf("%d  NL80211_CMD_START_AP\n", NL80211_CMD_START_AP);
	printf("%d  NL80211_CMD_NEW_BEACON\n", NL80211_CMD_NEW_BEACON);
	printf("%d  NL80211_CMD_STOP_AP\n", NL80211_CMD_STOP_AP);
	printf("%d  NL80211_CMD_DEL_BEACON\n", NL80211_CMD_DEL_BEACON);
	printf("%d  NL80211_CMD_GET_STATION\n", NL80211_CMD_GET_STATION);
	printf("%d  NL80211_CMD_SET_STATION\n", NL80211_CMD_SET_STATION);
	printf("%d  NL80211_CMD_NEW_STATION\n", NL80211_CMD_NEW_STATION);
	printf("%d  NL80211_CMD_DEL_STATION\n", NL80211_CMD_DEL_STATION);
	printf("%d  NL80211_CMD_GET_MPATH\n", NL80211_CMD_GET_MPATH);
	printf("%d  NL80211_CMD_SET_MPATH\n", NL80211_CMD_SET_MPATH);
	printf("%d  NL80211_CMD_NEW_MPATH\n", NL80211_CMD_NEW_MPATH);
	printf("%d  NL80211_CMD_DEL_MPATH\n", NL80211_CMD_DEL_MPATH);
	printf("%d  NL80211_CMD_SET_BSS\n", NL80211_CMD_SET_BSS);
	printf("%d  NL80211_CMD_SET_REG\n", NL80211_CMD_SET_REG);
	printf("%d  NL80211_CMD_REQ_SET_REG\n", NL80211_CMD_REQ_SET_REG);
	printf("%d  NL80211_CMD_GET_MESH_CONFIG\n", NL80211_CMD_GET_MESH_CONFIG);
	printf("%d  NL80211_CMD_SET_MESH_CONFIG\n", NL80211_CMD_SET_MESH_CONFIG);
	printf("%d  NL80211_CMD_SET_MGMT_EXTRA_IE\n", NL80211_CMD_SET_MGMT_EXTRA_IE);
	printf("%d  NL80211_CMD_GET_REG\n", NL80211_CMD_GET_REG);
	printf("%d  NL80211_CMD_GET_SCAN\n", NL80211_CMD_GET_SCAN);
	printf("%d  NL80211_CMD_TRIGGER_SCAN\n", NL80211_CMD_TRIGGER_SCAN);
	printf("%d  NL80211_CMD_NEW_SCAN_RESULTS\n", NL80211_CMD_NEW_SCAN_RESULTS);
	printf("%d  NL80211_CMD_SCAN_ABORTED\n", NL80211_CMD_SCAN_ABORTED);
	printf("%d  NL80211_CMD_REG_CHANGE\n", NL80211_CMD_REG_CHANGE);
	printf("%d  NL80211_CMD_AUTHENTICATE\n", NL80211_CMD_AUTHENTICATE);
	printf("%d  NL80211_CMD_ASSOCIATE\n", NL80211_CMD_ASSOCIATE);
	printf("%d  NL80211_CMD_DEAUTHENTICATE\n", NL80211_CMD_DEAUTHENTICATE);
	printf("%d  NL80211_CMD_DISASSOCIATE\n", NL80211_CMD_DISASSOCIATE);
	printf("%d  NL80211_CMD_MICHAEL_MIC_FAILURE\n", NL80211_CMD_MICHAEL_MIC_FAILURE);
	printf("%d  NL80211_CMD_REG_BEACON_HINT\n", NL80211_CMD_REG_BEACON_HINT);
	printf("%d  NL80211_CMD_JOIN_IBSS\n", NL80211_CMD_JOIN_IBSS);
	printf("%d  NL80211_CMD_LEAVE_IBSS\n", NL80211_CMD_LEAVE_IBSS);
	printf("%d  NL80211_CMD_TESTMODE\n", NL80211_CMD_TESTMODE);
	printf("%d  NL80211_CMD_CONNECT\n", NL80211_CMD_CONNECT);
	printf("%d  NL80211_CMD_ROAM\n", NL80211_CMD_ROAM);
	printf("%d  NL80211_CMD_DISCONNECT\n", NL80211_CMD_DISCONNECT);
	printf("%d  NL80211_CMD_SET_WIPHY_NETNS\n", NL80211_CMD_SET_WIPHY_NETNS);
	printf("%d  NL80211_CMD_GET_SURVEY\n", NL80211_CMD_GET_SURVEY);
	printf("%d  NL80211_CMD_NEW_SURVEY_RESULTS\n", NL80211_CMD_NEW_SURVEY_RESULTS);
	printf("%d  NL80211_CMD_SET_PMKSA\n", NL80211_CMD_SET_PMKSA);
	printf("%d  NL80211_CMD_DEL_PMKSA\n", NL80211_CMD_DEL_PMKSA);
	printf("%d  NL80211_CMD_FLUSH_PMKSA\n", NL80211_CMD_FLUSH_PMKSA);
	printf("%d  NL80211_CMD_REMAIN_ON_CHANNEL\n", NL80211_CMD_REMAIN_ON_CHANNEL);
	printf("%d  NL80211_CMD_CANCEL_REMAIN_ON_CHANNEL\n", NL80211_CMD_CANCEL_REMAIN_ON_CHANNEL);
	printf("%d  NL80211_CMD_SET_TX_BITRATE_MASK\n", NL80211_CMD_SET_TX_BITRATE_MASK);
	printf("%d  NL80211_CMD_REGISTER_FRAME\n", NL80211_CMD_REGISTER_FRAME);
	printf("%d  NL80211_CMD_REGISTER_ACTION\n", NL80211_CMD_REGISTER_ACTION);
	printf("%d  NL80211_CMD_FRAME\n", NL80211_CMD_FRAME);
	printf("%d  NL80211_CMD_ACTION = NL80211_CMD_FRAME\n", NL80211_CMD_ACTION);
	printf("%d  NL80211_CMD_FRAME_TX_STATUS\n", NL80211_CMD_FRAME_TX_STATUS);
	printf("%d  NL80211_CMD_ACTION_TX_STATUS\n", NL80211_CMD_ACTION_TX_STATUS);
	printf("%d  NL80211_CMD_SET_POWER_SAVE\n", NL80211_CMD_SET_POWER_SAVE);
	printf("%d  NL80211_CMD_GET_POWER_SAVE\n", NL80211_CMD_GET_POWER_SAVE);
	printf("%d  NL80211_CMD_SET_CQM\n", NL80211_CMD_SET_CQM);
	printf("%d  NL80211_CMD_NOTIFY_CQM\n", NL80211_CMD_NOTIFY_CQM);
	printf("%d  NL80211_CMD_SET_CHANNEL\n", NL80211_CMD_SET_CHANNEL);
	printf("%d  NL80211_CMD_SET_WDS_PEER\n", NL80211_CMD_SET_WDS_PEER);
	printf("%d  NL80211_CMD_FRAME_WAIT_CANCEL\n", NL80211_CMD_FRAME_WAIT_CANCEL);
	printf("%d  NL80211_CMD_JOIN_MESH\n", NL80211_CMD_JOIN_MESH);
	printf("%d  NL80211_CMD_LEAVE_MESH\n", NL80211_CMD_LEAVE_MESH);
	printf("%d  NL80211_CMD_UNPROT_DEAUTHENTICATE\n", NL80211_CMD_UNPROT_DEAUTHENTICATE);
	printf("%d  NL80211_CMD_UNPROT_DISASSOCIATE\n", NL80211_CMD_UNPROT_DISASSOCIATE);
	printf("%d  NL80211_CMD_NEW_PEER_CANDIDATE\n", NL80211_CMD_NEW_PEER_CANDIDATE);
	printf("%d  NL80211_CMD_GET_WOWLAN\n", NL80211_CMD_GET_WOWLAN);
	printf("%d  NL80211_CMD_SET_WOWLAN\n", NL80211_CMD_SET_WOWLAN);
	printf("%d  NL80211_CMD_START_SCHED_SCAN\n", NL80211_CMD_START_SCHED_SCAN);
	printf("%d  NL80211_CMD_STOP_SCHED_SCAN\n", NL80211_CMD_STOP_SCHED_SCAN);
	printf("%d  NL80211_CMD_SCHED_SCAN_RESULTS\n", NL80211_CMD_SCHED_SCAN_RESULTS);
	printf("%d  NL80211_CMD_SCHED_SCAN_STOPPED\n", NL80211_CMD_SCHED_SCAN_STOPPED);
	printf("%d  NL80211_CMD_SET_REKEY_OFFLOAD\n", NL80211_CMD_SET_REKEY_OFFLOAD);
	printf("%d  NL80211_CMD_PMKSA_CANDIDATE\n", NL80211_CMD_PMKSA_CANDIDATE);
	printf("%d  NL80211_CMD_TDLS_OPER\n", NL80211_CMD_TDLS_OPER);
	printf("%d  NL80211_CMD_TDLS_MGMT\n", NL80211_CMD_TDLS_MGMT);
	printf("%d  NL80211_CMD_UNEXPECTED_FRAME\n", NL80211_CMD_UNEXPECTED_FRAME);
	printf("%d  NL80211_CMD_PROBE_CLIENT\n", NL80211_CMD_PROBE_CLIENT);
	printf("%d  NL80211_CMD_REGISTER_BEACONS\n", NL80211_CMD_REGISTER_BEACONS);
	printf("%d  NL80211_CMD_UNEXPECTED_4ADDR_FRAME\n", NL80211_CMD_UNEXPECTED_4ADDR_FRAME);
	printf("%d  NL80211_CMD_SET_NOACK_MAP\n", NL80211_CMD_SET_NOACK_MAP);
	printf("%d  NL80211_CMD_CH_SWITCH_NOTIFY\n", NL80211_CMD_CH_SWITCH_NOTIFY);
	printf("%d  NL80211_CMD_START_P2P_DEVICE\n", NL80211_CMD_START_P2P_DEVICE);
	printf("%d  NL80211_CMD_STOP_P2P_DEVICE\n", NL80211_CMD_STOP_P2P_DEVICE);
	printf("%d  NL80211_CMD_CONN_FAILED\n", NL80211_CMD_CONN_FAILED);
	printf("%d  NL80211_CMD_SET_MCAST_RATE\n", NL80211_CMD_SET_MCAST_RATE);
	printf("%d  NL80211_CMD_SET_MAC_ACL\n", NL80211_CMD_SET_MAC_ACL);
	printf("%d  NL80211_CMD_RADAR_DETECT\n", NL80211_CMD_RADAR_DETECT);
	printf("%d  NL80211_CMD_GET_PROTOCOL_FEATURES\n", NL80211_CMD_GET_PROTOCOL_FEATURES);
	printf("%d  NL80211_CMD_UPDATE_FT_IES\n", NL80211_CMD_UPDATE_FT_IES);
	printf("%d  NL80211_CMD_FT_EVENT\n", NL80211_CMD_FT_EVENT);
	printf("%d  NL80211_CMD_CRIT_PROTOCOL_START\n", NL80211_CMD_CRIT_PROTOCOL_START);
	printf("%d  NL80211_CMD_CRIT_PROTOCOL_STOP\n", NL80211_CMD_CRIT_PROTOCOL_STOP);
	printf("%d  NL80211_CMD_GET_COALESCE\n", NL80211_CMD_GET_COALESCE);
	printf("%d  NL80211_CMD_SET_COALESCE\n", NL80211_CMD_SET_COALESCE);
	printf("%d  NL80211_CMD_CHANNEL_SWITCH\n", NL80211_CMD_CHANNEL_SWITCH);
	printf("%d  NL80211_CMD_VENDOR\n", NL80211_CMD_VENDOR);
	printf("%d  NL80211_CMD_SET_QOS_MAP\n", NL80211_CMD_SET_QOS_MAP);
	printf("%d  NL80211_CMD_ADD_TX_TS\n", NL80211_CMD_ADD_TX_TS);
	printf("%d  NL80211_CMD_DEL_TX_TS\n", NL80211_CMD_DEL_TX_TS);
	printf("%d  NL80211_CMD_GET_MPP\n", NL80211_CMD_GET_MPP);
	printf("%d  NL80211_CMD_JOIN_OCB\n", NL80211_CMD_JOIN_OCB);
	printf("%d  NL80211_CMD_LEAVE_OCB\n", NL80211_CMD_LEAVE_OCB);
	printf("%d  NL80211_CMD_CH_SWITCH_STARTED_NOTIFY\n", NL80211_CMD_CH_SWITCH_STARTED_NOTIFY);
	printf("%d  NL80211_CMD_TDLS_CHANNEL_SWITCH\n", NL80211_CMD_TDLS_CHANNEL_SWITCH);
	printf("%d  NL80211_CMD_TDLS_CANCEL_CHANNEL_SWITCH\n", NL80211_CMD_TDLS_CANCEL_CHANNEL_SWITCH);
	printf("%d  NL80211_CMD_WIPHY_REG_CHANGE\n", NL80211_CMD_WIPHY_REG_CHANGE);
	printf("%d  NL80211_CMD_ABORT_SCAN\n", NL80211_CMD_ABORT_SCAN);
	printf("%d  NL80211_CMD_START_NAN\n", NL80211_CMD_START_NAN);
	printf("%d  NL80211_CMD_STOP_NAN\n", NL80211_CMD_STOP_NAN);
	printf("%d  NL80211_CMD_ADD_NAN_FUNCTION\n", NL80211_CMD_ADD_NAN_FUNCTION);
	printf("%d  NL80211_CMD_DEL_NAN_FUNCTION\n", NL80211_CMD_DEL_NAN_FUNCTION);
	printf("%d  NL80211_CMD_CHANGE_NAN_CONFIG\n", NL80211_CMD_CHANGE_NAN_CONFIG);
	printf("%d  NL80211_CMD_NAN_MATCH\n", NL80211_CMD_NAN_MATCH);
	printf("%d  NL80211_CMD_SET_MULTICAST_TO_UNICAST\n", NL80211_CMD_SET_MULTICAST_TO_UNICAST);
	printf("%d  NL80211_CMD_UPDATE_CONNECT_PARAMS\n", NL80211_CMD_UPDATE_CONNECT_PARAMS);
	printf("%d  NL80211_CMD_SET_PMK\n", NL80211_CMD_SET_PMK);
	printf("%d  NL80211_CMD_DEL_PMK\n", NL80211_CMD_DEL_PMK);
	printf("%d  NL80211_CMD_PORT_AUTHORIZED\n", NL80211_CMD_PORT_AUTHORIZED);
	printf("%d  NL80211_CMD_RELOAD_REGDB\n", NL80211_CMD_RELOAD_REGDB);
	printf("%d  NL80211_CMD_EXTERNAL_AUTH\n", NL80211_CMD_EXTERNAL_AUTH);
	printf("%d  NL80211_CMD_STA_OPMODE_CHANGED\n", NL80211_CMD_STA_OPMODE_CHANGED);
	printf("%d  NL80211_CMD_CONTROL_PORT_FRAME\n", NL80211_CMD_CONTROL_PORT_FRAME);
	printf("%d  NL80211_CMD_GET_FTM_RESPONDER_STATS\n", NL80211_CMD_GET_FTM_RESPONDER_STATS);
	printf("%d  NL80211_CMD_PEER_MEASUREMENT_START\n", NL80211_CMD_PEER_MEASUREMENT_START);
	printf("%d  NL80211_CMD_PEER_MEASUREMENT_RESULT\n", NL80211_CMD_PEER_MEASUREMENT_RESULT);
	printf("%d  NL80211_CMD_PEER_MEASUREMENT_COMPLETE\n", NL80211_CMD_PEER_MEASUREMENT_COMPLETE);
	printf("%d  NL80211_CMD_NOTIFY_RADAR\n", NL80211_CMD_NOTIFY_RADAR);
	printf("%d  NL80211_CMD_UPDATE_OWE_INFO\n", NL80211_CMD_UPDATE_OWE_INFO);
	printf("%d  NL80211_CMD_PROBE_MESH_LINK\n", NL80211_CMD_PROBE_MESH_LINK);
	printf("%d  NL80211_CMD_SET_TID_CONFIG\n", NL80211_CMD_SET_TID_CONFIG);
	printf("%d  NL80211_CMD_UNPROT_BEACON\n", NL80211_CMD_UNPROT_BEACON);
	printf("%d  NL80211_CMD_CONTROL_PORT_FRAME_TX_STATUS\n", NL80211_CMD_CONTROL_PORT_FRAME_TX_STATUS);
	printf("%d  NL80211_CMD_SET_SAR_SPECS\n", NL80211_CMD_SET_SAR_SPECS);
	printf("%d  NL80211_CMD_OBSS_COLOR_COLLISION\n", NL80211_CMD_OBSS_COLOR_COLLISION);
	printf("%d  NL80211_CMD_COLOR_CHANGE_REQUEST\n", NL80211_CMD_COLOR_CHANGE_REQUEST);
	printf("%d  NL80211_CMD_COLOR_CHANGE_STARTED\n", NL80211_CMD_COLOR_CHANGE_STARTED);
	printf("%d  NL80211_CMD_COLOR_CHANGE_ABORTED\n", NL80211_CMD_COLOR_CHANGE_ABORTED);
	printf("%d  NL80211_CMD_COLOR_CHANGE_COMPLETED\n", NL80211_CMD_COLOR_CHANGE_COMPLETED);
	printf("%d  __NL80211_CMD_AFTER_LAST\n", __NL80211_CMD_AFTER_LAST);
	printf("%d  NL80211_CMD_MAX\n", NL80211_CMD_MAX);

	return 0;
}
#endif

int wapp_cmd_get_scan_result(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	struct wapp_dev *wdev = NULL;


	if (!argv[1]) {
		err(DEBUG_CAT_MISC, "Invalid argument\n");
		return WAPP_INVALID_ARG;
	}

	wdev = wapp_dev_list_lookup_by_ifname(wapp, argv[1]);
	if (wdev && wdev->dev_type == WAPP_DEV_TYPE_AP) {
		notice(DEBUG_CAT_SCAN, BLUE("inf = %s\n"), argv[1]);
#ifdef STANDARD_NL_CMD
		notice(DEBUG_CAT_MISC, " Generic NL Scan");
		wapp_scan_trigger(wapp, wdev, 0, 0);
#else
		notice(DEBUG_CAT_MISC, " Vendor Scan");
		wapp_query_scan_result(wapp, wdev, 0);
#endif
	} else
		err(DEBUG_CAT_SCAN, RED("inf not found\n"));

	return WAPP_SUCCESS;
}

#ifdef CSA_BAND_SUPPORT
int wapp_cmd_set_2g_csa_support(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	struct wapp_dev *wdev = NULL;


	if (!argv[1]) {
		err(DEBUG_CAT_MISC, "Invalid argument\n");
		return WAPP_INVALID_ARG;
	}

	wdev = wapp_dev_list_lookup_by_ifname(wapp, argv[1]);
		notice(DEBUG_CAT_SCAN, BLUE("inf = %s\n"), argv[1]);
		wdev_set_static_2g_csa_support(wapp, wdev,  atoi(argv[2]));
	return WAPP_SUCCESS;
}

int wapp_cmd_set_csa_support(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	struct wapp_dev *wdev = NULL;


	if (!argv[1]) {
		err(DEBUG_CAT_MISC, "Invalid argument\n");
		return WAPP_INVALID_ARG;
	}

	wdev = wapp_dev_list_lookup_by_ifname(wapp, argv[1]);
		notice(DEBUG_CAT_SCAN, BLUE("inf = %s\n"), argv[1]);
		wdev_set_static_csa_support(wapp, wdev,  atoi(argv[2]));
	return WAPP_SUCCESS;
}
#endif

int wapp_cmd_set_bss_stop(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	struct wapp_dev *wdev = NULL;

#ifdef MTK_HOSTAPD_SUPPORT
#ifdef WPACTRL_SUPPORT
#ifdef MAP_SUPPORT
	char file_name[64] = {0};
	char value[128] = {0};
	char param[32] = {0};
	int ret = 0;
#endif /* MAP_SUPPORT */
#endif /* WPACTRL_SUPPORT */
#endif /* MTK_HOSTAPD_SUPPORT */

	if (!wapp || !wapp->map) {
		err(DEBUG_CAT_MISC, "Invalid argument\n");
		return -1;
	}

	if (!argv[1]) {
		err(DEBUG_CAT_MISC, "Invalid argument\n");
		return WAPP_INVALID_ARG;
	}

	wdev = wapp_dev_list_lookup_by_ifname(wapp, argv[1]);
	if (wdev && wdev->dev_type == WAPP_DEV_TYPE_AP) {
		notice(DEBUG_CAT_MISC, BLUE("inf = %s\n"), argv[1]);
#ifndef MTK_HOSTAPD_SUPPORT
		wapp_set_bss_stop(wapp, argv[1]);
#else
#ifdef WPACTRL_SUPPORT
#ifdef MAP_R6
		wapp_set_no_bcn(wapp, wdev, 1);
#else
		if (wapp->drv_ops->drv_send_ap_intf_stop)
			wapp->drv_ops->drv_send_ap_intf_stop(wapp->drv_data,  wdev->ifname);
#endif
#ifdef MAP_SUPPORT

		if (os_snprintf_error(sizeof(file_name), os_snprintf(file_name, sizeof(file_name), MAP_1905_CFG_FILE)))
			err(DEBUG_CAT_MISC, "os_snprintf fail\n");

		if (os_snprintf_error(sizeof(param), os_snprintf(param, sizeof(param), "map_controller_alid")))
			err(DEBUG_CAT_MISC, "os_snprintf fail\n");

		get_parameters(file_name, param, value, NON_DRIVER_PARAM, sizeof(value));
		ret = hwaddr_aton(value, wapp->map->ctrl_alid);
		if (ret != 0)
			err(DEBUG_CAT_MISC, "hwaddr_aton fails\n");

		os_memset(value, 0, sizeof(value));
		os_memset(param, 0, sizeof(param));

		if (os_snprintf_error(sizeof(param), os_snprintf(param, sizeof(param), "map_agent_alid")))
			err(DEBUG_CAT_MISC, "os_snprintf fail\n");

		get_parameters(file_name, param, value, NON_DRIVER_PARAM, sizeof(value));
		ret = hwaddr_aton(value, wapp->map->agnt_alid);
		if (ret != 0)
			err(DEBUG_CAT_MISC, "hwaddr_aton fails\n");
		if (os_memcmp(wdev->mac_addr, wapp->map->ctrl_alid, ETH_ALEN) == 0
			|| os_memcmp(wdev->mac_addr, wapp->map->agnt_alid, ETH_ALEN) == 0)
			wapp_add_intf_interface_bridge(wapp, wdev->ifname, wapp->map->br_iface);
#endif /* MAP_SUPPORT */
#endif /* WPACTRL_SUPPORT */

#endif /* MTK_HOSTAPD_SUPPORT */
	}
	return WAPP_SUCCESS;
}
void wapp_set_disallow_in_driver(
	struct wifi_app *wapp,
	struct wapp_dev *wdev,
	struct bh_assoc_disallow_info *bh_ctrl_info)
{
	notice(DEBUG_CAT_MISC, "wapp_set_disallow_in_driver going to driver\n");
	wapp_set_BhAssocCtrl(wapp, (const char *)wdev->ifname,
		(char *)bh_ctrl_info,
		(size_t)sizeof(struct bh_assoc_disallow_info));
}

int wapp_cmd_set_bh_assoc_ctrl(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	FILE *fp = NULL;
	char buf[256], *pos, *token, *endptr = NULL;
	char bssid[ETH_ALEN] = { 0 }, disallow_profile_type = 0;
	struct wapp_dev *wdev = NULL;
	struct bh_assoc_ctrl *bh_ctrl = NULL;
	int line = 0;
	long val = 0;

	fp = fopen("/etc/map/bh_assoc_ctrl.cfg", "r+");
	if (fp == NULL) {
		notice(DEBUG_CAT_MISC, "/etc/map/bh_assoc_ctrl open fail\n");
		return WAPP_INVALID_ARG;
	}
	while (wapp_config_get_line(buf, sizeof(buf), fp, &line, &pos)) {
		token = strtok(pos, " ");
		if (token) {
			notice(DEBUG_CAT_MISC, "bssid rcvd tmp_buf %s pos %s line %d\n", token, pos, line);
			if (hwaddr_aton(token, (u8 *)bssid) < 0) {
				notice(DEBUG_CAT_MISC, "bssid not rcvd %s %s %d\n", token, pos, line);
				if (fclose(fp) != 0)
					err(DEBUG_CAT_MISC, "Error in file close\n");
				return WAPP_INVALID_ARG;
			}
		}
		bh_ctrl = os_zalloc(sizeof(struct bh_assoc_ctrl));
		if (!bh_ctrl) {
			err(DEBUG_CAT_MISC, "mem alloc fail for bh_ctrl\n");
			if (fclose(fp) != 0)
				err(DEBUG_CAT_MISC, "Error in file close\n");
			return WAPP_INVALID_ARG;
		}
		os_memcpy(&bh_ctrl->bh_ctrl_info.bssid, bssid, ETH_ALEN);
		notice(DEBUG_CAT_MISC, "bssid" MACSTR " ", MAC2STR(bh_ctrl->bh_ctrl_info.bssid));
		token = strtok(NULL, "");
		if (token) {
			errno = 0;
			val = strtol(token, &endptr, 10);
			if (errno == ERANGE || *endptr != '\0' || val < CHAR_MIN || val > CHAR_MAX)
				err(DEBUG_CAT_MISC, "disallow_profile_type strtol fails\n");
			else
				disallow_profile_type = (char)val;
		}
		notice(DEBUG_CAT_MISC, "bh disallow for %d pos %s line %d\n", disallow_profile_type, pos, line);
		if (disallow_profile_type == 1)
			bh_ctrl->bh_ctrl_info.profile1_bh_assoc_disallow = 1;
		else if (disallow_profile_type == 2)
			bh_ctrl->bh_ctrl_info.profile2_bh_assoc_disallow = 1;
		else
			err(DEBUG_CAT_MISC, "disallow_profile_type error\n");
		dl_list_add_tail(&wapp->bh_assoc_ctrl_list, &bh_ctrl->list);
		wdev = wapp_dev_list_lookup_by_mac_and_type(wapp, bh_ctrl->bh_ctrl_info.bssid, WAPP_DEV_TYPE_AP);
		if (wdev)
			wapp_set_disallow_in_driver(wapp, wdev, &bh_ctrl->bh_ctrl_info);
		else
			err(DEBUG_CAT_MISC, "null wdev\n");
	}
	if (fclose(fp) != 0)
		err(DEBUG_CAT_MISC, "Error in file close\n");
	return WAPP_SUCCESS;
}

int wapp_cmd_set_air_mnt(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	FILE *fp = NULL;
	char buf[256], tmpbuf[18], *pos;
	long total_sta_to_monitor, mnt_max_pkt_per_sta = 0;
	char sta_mac[ETH_ALEN];
	struct wapp_dev *wdev = NULL;
	u8 unlink_query[180];
	struct unlink_metrics_query *query = (struct unlink_metrics_query *)unlink_query;
	int sta_cnt = 0, line = 0, ret = 0;
	char *endptr = NULL;

	if (!argv[1] && !argv[2]) {
		err(DEBUG_CAT_MISC, "Invalid argument\n");
		return WAPP_INVALID_ARG;
	}

	errno = 0;
	mnt_max_pkt_per_sta = strtol(argv[1], &endptr, 10);
	if (errno == ERANGE || *endptr != '\0' || mnt_max_pkt_per_sta > INT_MAX || mnt_max_pkt_per_sta < INT_MIN) {
		err(DEBUG_CAT_MISC, "Invalid number of packets per station\n");
		return WAPP_INVALID_ARG;
	}
	errno = 0;
	total_sta_to_monitor = strtol(argv[2], &endptr, 10);
	if (errno == ERANGE || *endptr != '\0' || total_sta_to_monitor > INT_MAX || total_sta_to_monitor < INT_MIN) {
		err(DEBUG_CAT_MISC, "Invalid total number of stations to monitor\n");
		return WAPP_INVALID_ARG;
	}

	fp = fopen("/etc/map/air_mnt_sta.cfg", "r+");
	if (fp == NULL) {
		err(DEBUG_CAT_MISC, "/etc/map/air_mnt_bss open fail\n");
		return WAPP_INVALID_ARG;
	}

	wdev = wapp_dev_list_lookup_by_ifname(wapp, iface);
	if (wdev && wdev->dev_type == WAPP_DEV_TYPE_AP) {
		query->ch_num = 1;
		query->ch_list[0] = wdev->radio->op_ch;
		query->oper_class = wdev->radio->opclass;
	} else {
		if (fclose(fp) != 0)
			err(DEBUG_CAT_MISC, "Error in file close\n");
		return WAPP_INVALID_ARG;
	}

	while (wapp_config_get_line(buf, sizeof(buf), fp, &line, &pos)) {
		ret = snprintf(tmpbuf, sizeof(tmpbuf), "%s", pos);
		notice(DEBUG_CAT_MISC, "sta_mac rcvd %s %s %d\n", tmpbuf, pos, line);
		if (os_snprintf_error(sizeof(tmpbuf), ret))
			err(DEBUG_CAT_MISC, "snprintf error\n");

		if (hwaddr_aton(tmpbuf, (u8 *)sta_mac) < 0) {
			err(DEBUG_CAT_MISC, "sta_mac not rcvd %s %s %d\n", tmpbuf, pos, line);
			if (fclose(fp) != 0)
				err(DEBUG_CAT_MISC, "Error in file close\n");
			return WAPP_INVALID_ARG;
		}
		os_memcpy(&query->sta_list[sta_cnt*ETH_ALEN], sta_mac, ETH_ALEN);
		notice(DEBUG_CAT_MISC, "sta_mac"MACSTR" %s %d\n", MAC2STR(&query->sta_list[sta_cnt]), pos, line);
		sta_cnt++;

		if (sta_cnt >= total_sta_to_monitor) {
			err(DEBUG_CAT_MISC, "more station in file than command");
			break;
		}
	}
	wapp->air_mnt_max_pkt = mnt_max_pkt_per_sta;
	query->sta_num = sta_cnt;

	if (fclose(fp) != 0)
		err(DEBUG_CAT_MISC, "Error in file close\n");

	map_receive_air_monitor_request(wapp, (unsigned char *)sta_mac, NULL, (char *)query);

	return WAPP_SUCCESS;
}


int wapp_cmd_set_txpwr_prctg(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	struct wapp_dev *wdev = NULL;
	char *endptr = NULL;
	long pwr_prctg = 0;


	if (!argv[1]) {
		err(DEBUG_CAT_MISC, "Invalid argument\n");
		return WAPP_INVALID_ARG;
	}

	errno = 0;
	pwr_prctg = strtol(argv[2], &endptr, 10);
	if (errno != 0 || *endptr != '\0' || pwr_prctg < 0 || pwr_prctg > UCHAR_MAX) {
		err(DEBUG_CAT_MISC, "Invalid power percentage value\n");
		return -1;
	}

	wdev = wapp_dev_list_lookup_by_ifname(wapp, argv[1]);
	if (wdev && wdev->dev_type == WAPP_DEV_TYPE_AP) {
		notice(DEBUG_CAT_MISC, BLUE("%s inf = %s, pwr_prctg = %u %%\n"), __func__, argv[1], (u8)pwr_prctg);
		wapp_set_tx_power_percentage(wapp, wdev, (u8)pwr_prctg);
	}
	return WAPP_SUCCESS;
}

int wapp_cmd_show_blocked_list(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	struct wapp_dev *wdev = NULL;

	if (!argv[1]) {
		err(DEBUG_CAT_MISC, "Invalid argument\n");
		return WAPP_INVALID_ARG;
	}

	wdev = wapp_dev_list_lookup_by_ifname(wapp, argv[1]);
	if (wdev && wdev->dev_type == WAPP_DEV_TYPE_AP)
		wdev_ap_show_block_list(wapp, (struct ap_dev *)wdev->p_dev);

	return WAPP_SUCCESS;
}

int wapp_cmd_apcli_info(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	struct wapp_dev *wdev = NULL;

	if (!argv[1]) {
		err(DEBUG_CAT_MISC, "Invalid argument\n");
		return WAPP_INVALID_ARG;
	}

	wdev = wapp_dev_list_lookup_by_ifname(wapp, argv[1]);
	if (wdev && wdev->dev_type == WAPP_DEV_TYPE_STA)
		wdev_apcli_show_info(wapp, (struct wapp_sta *)wdev->p_dev);

	return WAPP_SUCCESS;
}


int wapp_cmd_show_cli_list(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	struct wapp_dev *wdev = NULL;

	if (!argv[1]) {
		err(DEBUG_CAT_MISC, "Invalid argument\n");
		return WAPP_INVALID_ARG;
	}

	wdev = wapp_dev_list_lookup_by_ifname(wapp, argv[1]);
	if (wdev && wdev->dev_type == WAPP_DEV_TYPE_AP)
		wdev_ap_show_cli_list(wapp, (struct ap_dev *)wdev->p_dev);

	return WAPP_SUCCESS;
}

int wapp_cmd_chn_list_info(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	struct wapp_dev *wdev = NULL;


	if (!argv[1]) {
		err(DEBUG_CAT_CHANNEL, "Invalid argument\n");
		return WAPP_INVALID_ARG;
	}

	wdev = wapp_dev_list_lookup_by_ifname(wapp, argv[1]);
	if (wdev && wdev->dev_type == WAPP_DEV_TYPE_AP)
		wdev_ap_show_chn_list(wapp, (struct ap_dev *)wdev->p_dev);

	return WAPP_SUCCESS;
}

int wapp_cmd_bss_info(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	struct wapp_dev *wdev = NULL;

	if (!argv[1]) {
		err(DEBUG_CAT_CHANNEL, "Invalid argument\n");
		return WAPP_INVALID_ARG;
	}

	wdev = wapp_dev_list_lookup_by_ifname(wapp, argv[1]);
	if (wdev && wdev->dev_type == WAPP_DEV_TYPE_AP)
		wdev_ap_show_bss_info(wapp, (struct ap_dev *)wdev->p_dev);

	return WAPP_SUCCESS;
}

int wapp_cmd_ap_metric(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	struct wapp_dev *wdev = NULL;
	char buf[512] = {0};

	if (!argv[1]) {
		err(DEBUG_CAT_CHANNEL, "Invalid argument\n");
		return WAPP_INVALID_ARG;
	}

	wdev = wapp_dev_list_lookup_by_ifname(wapp, argv[1]);
	if (wdev && wdev->dev_type == WAPP_DEV_TYPE_AP) {
		err(DEBUG_CAT_STATS, "bss_info:\n");
		wdev_ap_show_ap_metric(wapp, buf, 512);
	}

	return WAPP_SUCCESS;
}

int wapp_cmd_set_sec(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	struct wapp_dev *wdev = NULL;
	struct sec_info sec;
	int ret = 0;

	if (argc != 5 || !argv[1] || !argv[2] || !argv[3] || !argv[4]) {
		err(DEBUG_CAT_WIFI_CONFIG, "Invalid argument\n");
		return WAPP_INVALID_ARG;
	}

	notice(DEBUG_CAT_WIFI_CONFIG,
		 "\033[1;36m:"
		 "inf = %s \n"
		 "auth = %s \n"
		 "encryp = %s \n"
		 "psphr = %s \033[0m\n",
		 argv[1], argv[2], argv[3], argv[4]);

	ret = os_snprintf(sec.auth, sizeof(sec.auth), "%s", argv[2]);
	if (os_snprintf_error(sizeof(sec.auth), ret)) {
		err(DEBUG_CAT_WIFI_CONFIG, "[%s] (%d): os_snprintf fail\n", __func__, __LINE__);
		return WAPP_INVALID_ARG;
	}
	ret = os_snprintf(sec.encryp, sizeof(sec.encryp), "%s", argv[3]);
	if (os_snprintf_error(sizeof(sec.encryp), ret)) {
		err(DEBUG_CAT_WIFI_CONFIG, "[%s] (%d): os_snprintf fail\n", __func__, __LINE__);
		return WAPP_INVALID_ARG;
	}
	if (argv[4]) {
		ret = os_snprintf(sec.psphr, sizeof(sec.psphr), "%s", argv[4]);
		if (os_snprintf_error(sizeof(sec.psphr), ret)) {
			err(DEBUG_CAT_WIFI_CONFIG, "[%s] (%d): os_snprintf fail\n", __func__, __LINE__);
			return WAPP_INVALID_ARG;
		}
	}

	wdev = wapp_dev_list_lookup_by_ifname(wapp, argv[1]);
	if (wdev)
		wdev_set_sec_and_ssid2(wapp, wdev, &sec, NULL);

	return WAPP_SUCCESS;
}

int wapp_cmd_set_ch(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	struct wapp_dev *wdev = NULL;
	int channel = 0;
	long val = 0;
	char *endptr = NULL;

	if (argc != 3 || !argv[1] || !argv[2]) {
		err(DEBUG_CAT_CHANNEL, "Invalid argument\n");
		return WAPP_INVALID_ARG;
	}

	notice(DEBUG_CAT_CHANNEL,
		 "\033[1;36m:"
		 "inf = %s \n"
		 "ch = %s \033[0m\n",
		 argv[1], argv[2]);

	wdev = wapp_dev_list_lookup_by_ifname(wapp, argv[1]);

	val = strtol(argv[2], &endptr, 10);
	if (errno == ERANGE || *endptr != '\0' || val < INT_MIN || val > INT_MAX)
		err(DEBUG_CAT_CHANNEL, "channel strtol fails\n");
	else
		channel = (int)val;
#ifdef MAP_6E_SUPPORT
	if (wdev)
		wdev_set_ch(wapp, wdev, channel, 0, 0, 1);
#else
	if (wdev)
		wdev_set_ch(wapp, wdev, channel, 0);
#endif

	return WAPP_SUCCESS;
}

int wapp_cmd_set_ssid(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	struct wapp_dev *wdev = NULL;

	if (argc != 3 || !argv[1] || !argv[2]) {
		err(DEBUG_CAT_WIFI_CONFIG, "Invalid argument\n");
		return WAPP_INVALID_ARG;
	}

	notice(DEBUG_CAT_WIFI_CONFIG,
		 "\033[1;36m:"
		 "inf = %s \n"
		 "ssid = %s \033[0m\n",
		 argv[1], argv[2]);

	wdev = wapp_dev_list_lookup_by_ifname(wapp, argv[1]);
	if (wdev) {
		wdev_set_ssid(wapp, wdev, argv[2]);
		if (wapp->drv_ops->drv_send_reload)
			wapp->drv_ops->drv_send_reload(wapp->drv_data, wdev->ifname);
	}

	return WAPP_SUCCESS;
}

int wapp_cmd_show_radio_info(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	int i;
	struct wapp_radio *ra = NULL;
#ifdef MAP_SUPPORT
	u8 idfr[MAC_ADDR_LEN];
	static const char * const RADIO_BAND[] = {"24G", "5GL", "5GH", "5G", "6G"};
#endif

	for (i = 0; i < MAX_NUM_OF_RADIO; i++) {
		ra = &wapp->radio[i];
		if (ra->adpt_id) {
			notice(DEBUG_CAT_MISC,
				 "\n===============\n"
				 "ra index = %u\n"
				 "adpt_id  = %u\n"
				 "card_id  = %u\n"
				 "ra_id  =   %u\n"
				 "op_ch  =   %u\n",
				 ra->index, ra->adpt_id, ra->card_id, ra->radio_id, ra->op_ch);
#ifdef MAP_SUPPORT
			MAP_GET_RADIO_IDNFER(ra, idfr);
			notice(DEBUG_CAT_WIFI_CONFIG,
				 "idfer  =   %02x%02x%02x%02x%02x%02x\n"
				 "conf_stat = %u\n"
				 "metric policy sta_rssi_thres = %d\n"
				 "metric policy sta_hysteresis_margin = %d\n"
				 "metric policy ch_util_thres = %d\n"
				 "radio_band = %s (%p)\n",
				 PRINT_RA_IDENTIFIER(idfr), ra->conf_state.state, ra->metric_policy.sta_rssi_thres,
				 ra->metric_policy.sta_hysteresis_margin, ra->metric_policy.ch_util_thres,
				 ra->radio_band ? RADIO_BAND[*ra->radio_band] : "NULL", ra->radio_band);
#endif /* MAP_SUPPORT */
			notice(DEBUG_CAT_MISC, "\n===============\n");
		}
	}

	return WAPP_SUCCESS;
}

int wapp_cmd_wdev_list(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	printf("\033[1;36m  \033[0m\n");
	wapp_show_dev_list(wapp);
	return WAPP_SUCCESS;
}

int wapp_cmd_ap_info(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	struct wapp_dev *wdev = NULL;


	if (!argv[1]) {
		err(DEBUG_CAT_WIFI_CONFIG, "Invalid argument\n");
		return WAPP_INVALID_ARG;
	}

	wdev = wapp_dev_list_lookup_by_ifname(wapp, argv[1]);
	if (wdev && wdev->dev_type == WAPP_DEV_TYPE_AP)
		wdev_ap_show_ap_info(wapp, wdev, (struct ap_dev *)wdev->p_dev);

	return WAPP_SUCCESS;
}

int wapp_cmd_set_load_thrd(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	map_config_bssload_thrd_setting_msg(wapp, argv[1], argv[2], argv[3]); /*For now, this func is called by wappctrl */
	return WAPP_SUCCESS;
}

int wapp_cmd_set_log_level(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	int log_level = 0;
	char *endptr = NULL;

	errno = 0;
	log_level = strtol(argv[1], &endptr, 10);
	if (errno != 0 || endptr == argv[1] || *endptr != '\0') {
		printf("Invalid log level input: %s\n", argv[1]);
		return -1;
	}

	printf("%s set log level %d\n", __func__, log_level);
	if (log_level >= RT_DEBUG_OFF && log_level <= RT_DEBUG_INFO)
		RTDebugLevel = log_level;
	else {
		printf("invalid log level %d\n", log_level);
	return -1;
	}

	return WAPP_SUCCESS;
}

int wapp_cmd_set_log_option(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	if (argc != 2)
		return WAPP_INVALID_ARG;
	set_log_option_str(argv[1]);

	return WAPP_SUCCESS;
}
#ifdef STANDARD_NL_CMD
int wapp_cmd_set_partial_scan_count(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	if (argc != 2)
		return WAPP_INVALID_ARG;

	wapp->partial_scan_count = 0;
	char *endptr = NULL;

	errno = 0;
	wapp->partial_scan_count = strtol(argv[1], &endptr, 10);
	if (errno != 0 || endptr == argv[1] || *endptr != '\0') {
		printf("Invalid log level input: %s\n", argv[1]);
		return -1;
	}

	printf("%s set partial count value %d\n", __func__, wapp->partial_scan_count);

	return WAPP_SUCCESS;
}
#endif
int wapp_cmd_get_log_info(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	char buf[1024] = {0};
	unsigned int len = 1024;
	int ret = 0;

	ret = get_log_info(buf, len);
	if (ret <= 0) {
		printf("%s fail\n", __func__);
		return WAPP_UNEXP;
	}
	printf("%s\n", buf);

	return WAPP_SUCCESS;
}

int wapp_cmd_set_log_category(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
#define BUF_LEN 1024
	unsigned char i = 0;
	char buf[BUF_LEN] = {0};
	unsigned int len = 0;
	int ret = 0;

	for (i = 1; i < argc; i++) {
		ret = snprintf(buf + len, BUF_LEN - len, "%s ", argv[i]);
		if (os_snprintf_error(BUF_LEN - len, ret)) {
			printf("os_snprintf_error fail\n");
			return WAPP_UNEXP;
		}
		len += ret;
	}

	set_log_category_str(buf);

	return WAPP_SUCCESS;
}

char *wapp_config_get_line(char *s, int size, FILE *stream, int *line, char **_pos)
{
	char *pos, *end, *sstart;

	while (fgets(s, size, stream)) {
		(*line)++;
		s[size - 1] = '\0';
		pos = s;

		/* Skip white space from the beginning of line. */
		while (*pos == ' ' || *pos == '\t' || *pos == '\r')
			pos++;

		/* Skip comment lines and empty lines */
		if (*pos == '#' || *pos == '\n' || *pos == '\0')
			continue;

		/* Remove # comments unless they are within a double quoted*/
		/* string. */
		sstart = os_strchr(pos, '"');
		if (sstart)
			sstart = os_strrchr(sstart + 1, '"');
		if (!sstart)
			sstart = pos;
		end = os_strchr(sstart, '#');
		if (end)
			*end-- = '\0';
		else
			end = pos + os_strlen(pos) - 1;

		/* Remove trailing white space. */
		while (end > pos && (*end == '\n' || *end == ' ' || *end == '\t' || *end == '\r'))
			*end-- = '\0';

		if (*pos == '\0')
			continue;

		if (_pos)
			*_pos = pos;
		return pos;
	}

	if (_pos)
		*_pos = NULL;
	return NULL;
}

/* wapp parameter setting */
static int wapp_cmm_param_setting(struct wifi_app *wapp, struct wapp_conf *conf, u32 param, u32 value)
{
	int ret;

	ret = wapp->drv_ops->drv_wapp_param_setting(wapp->drv_data, conf->iface, param, value);
	return ret;
}

static int wapp_init_param_setting(struct wifi_app *wapp, struct wapp_conf *conf)
{
	int ret;

	/* MMPDU Size */
	ret = wapp_cmm_param_setting(wapp, conf, PARAM_MMPDU_SIZE, conf->mmpdu_size);

	/* GAS come back delay */
	ret += wapp_cmm_param_setting(wapp, conf, PARAM_GAS_COME_BACK_DELAY, conf->gas_cb_delay);

	/* set WNM BSS transition management */
	ret += wapp_cmm_param_setting(wapp, conf, PARAM_WNM_BSS_TRANSITION_MANAGEMENT, 1);

	/* set WNM Notification */
	ret += wapp_cmm_param_setting(wapp, conf, PARAM_WNM_NOTIFICATION, 1);

	/* TODO: below setting just use in hotspot and mbo feature*/
	/* Qos map */
	ret += wapp_cmm_param_setting(wapp, conf, PARAM_QOSMAP, conf->qosmap_enable);
	if (ret)
		err(DEBUG_CAT_MISC, "WAPP_cmm_param_setting FAILED, please check if driver compiled WAPP\n");
#ifdef MBO_SUPPORT
	/* mbo assoc disallow */
	ret = mbo_param_setting(wapp, conf->iface, PARAM_MBO_AP_ASSOC_DISALLOW, wapp->mbo->assoc_disallow_reason);

	/* mbo_ap_capability */
	ret += mbo_param_setting(wapp, conf->iface, PARAM_MBO_AP_CAP, wapp->mbo->ap_capability);

	/* mbo_ap_cdcp */
	ret += mbo_param_setting(wapp, conf->iface, PARAM_MBO_AP_CDCP, wapp->mbo->cdcp);
	if (ret)
		err(DEBUG_CAT_MISC, "mbo_param_setting FAILED, please check if driver compiled MBO\n");

#endif /* MBO_SUPPORT */
#ifdef PASSPOINT_SUPPORT
	ret = hotspot_init_param(wapp, conf);
	if (ret) {
		err(DEBUG_CAT_MISC, "hotspot_param_setting FAILED, please check if driver compiled hotspot\n");
		ret = 0;
	}

#endif /* PASSPOINT SUPPORT */
	return 0;
}

int wapp_init_ap_config(struct wifi_app *wapp, const char *confname)
{
	int ret = 0;
	FILE *file = NULL;
	char buf[256], *pos, *token, *token1, *endptr = NULL;
	char tmpbuf[256], tmp1buf[256], tmp2buf[256];
	int line = 0, i = 0;
	long val = 0;
	struct wapp_conf *conf = NULL;
	int varlen;
	struct anqp_capability *capability_info;
	struct nai_realm_data *realm_data = NULL, *realm_data_new = NULL;
	struct eap_method *eapmethod = NULL;
	struct auth_param *authparam = NULL, *authparam_new = NULL;
	struct anqp_hs_capability *hs_capability_subtype;
	struct plmn *plmn_unit = NULL;
	struct proto_port_tuple *proto_port_unit = NULL;
	struct advice_of_charge_data *charge_data = NULL;
	struct aoc_plan_tuple_data *plan_tuple_data = NULL;
	u8 IsNAIRealmData = 0, IsPLMN = 0, IsProtoPort = 0, IsWanMetrics = 0, IsAOCData = 0;

	struct osu_providers *providers_list = NULL;
	u8 IsProviderList = 0;
	u8 qos_cnt = 0;

	os_memset(buf, 0, 256);
	os_memset(tmpbuf, 0, 256);
	os_memset(tmp1buf, 0, 256);
	os_memset(tmp2buf, 0, 256);

	conf = os_zalloc(sizeof(struct wapp_conf));
	if (!conf) {
		err(DEBUG_CAT_MISC, "alloc struct wapp_conf fail\n");
		return -1;
	}

	ret = os_snprintf(conf->confname, sizeof(conf->confname), "%s", confname);
	if (os_snprintf_error(sizeof(conf->confname), ret)) {
		err(DEBUG_CAT_INIT, "os_snprintf fail\n");
		goto error;
	}

	dl_list_init(&conf->anqp_capability_list);
	dl_list_init(&conf->venue_name_list);
	dl_list_init(&conf->emergency_call_number_list);
	dl_list_init(&conf->network_auth_type_list);
	dl_list_init(&conf->oi_duple_list);
	dl_list_init(&conf->nai_realm_list);
	dl_list_init(&conf->plmn_list);
	dl_list_init(&conf->domain_name_list);

	/* Following are HS2.0 elemets list */
	dl_list_init(&conf->hs_capability_list);
	dl_list_init(&conf->operator_friendly_duple_list);
	dl_list_init(&conf->connection_capability_list);
	dl_list_init(&conf->nai_home_realm_name_query_list);
	dl_list_init(&conf->operating_class_list);
	dl_list_init(&conf->bss_transition_candi_list);
	dl_list_init(&conf->osu_providers_list);
	dl_list_init(&conf->icon_file_list);
	dl_list_init(&conf->advice_of_charge_list);
	dl_list_init(&conf->venue_url_list);
	dl_list_init(&conf->osu_providers_nai_duple_list);
	dl_list_init(&conf->icon_metadata_list);

	file = fopen(confname, "r");
	if (!file) {
		err(DEBUG_CAT_INIT, "fopen fail; errno=%s\n", strerror(errno));
		goto error;
	}

	while (wapp_config_get_line(buf, sizeof(buf), file, &line, &pos)) {
		ret = os_snprintf(tmpbuf, sizeof(tmpbuf), "%s", pos);
		if (os_snprintf_error(sizeof(tmpbuf), ret)) {
			err(DEBUG_CAT_INIT, "os_snprintf fail\n");
			continue;
		}
		varlen = 0;
		token = strtok(pos, "=");
		if (token != NULL) {
			if (os_strcmp(token, "interface") == 0) {
				token = strtok(NULL, "");
				if (!token) {
					err(DEBUG_CAT_INIT, "strtok fail\n");
					continue;
				}
				ret = os_snprintf(conf->iface, sizeof(conf->iface), "%s", token);
				if (os_snprintf_error(sizeof(conf->iface), ret)) {
					err(DEBUG_CAT_INIT, "os_snprintf fail\n");
					continue;
				}
			} else if (os_strcmp(token, "interworking") == 0) {
				token = strtok(NULL, "");
				if (!token) {
					err(DEBUG_CAT_INIT, "strtok fail\n");
					continue;
				}
				errno = 0;
				val = strtol(token, &endptr, 10);
				if (errno == ERANGE || *endptr != '\0' || val < 0 || val > UCHAR_MAX)
					err(DEBUG_CAT_INIT, "strtol fails\n");
				else
					conf->interworking = (char)val;
			} else if (os_strcmp(token, "access_network_type") == 0) {
				token = strtok(NULL, "");
				if (!token) {
					err(DEBUG_CAT_INIT, "strtok fail\n");
					continue;
				}
				errno = 0;
				val = strtol(token, &endptr, 10);
				if (errno == ERANGE || *endptr != '\0' || val < INT_MIN || val > INT_MAX)
					err(DEBUG_CAT_INIT, "strtol fails\n");
				else
					conf->access_network_type = (int)val;
			} else if (os_strcmp(token, "internet") == 0) {
				token = strtok(NULL, "");
				if (!token) {
					err(DEBUG_CAT_INIT, "strtok fail\n");
					continue;
				}
				errno = 0;
				val = strtol(token, &endptr, 10);
				if (errno == ERANGE || *endptr != '\0' || val < INT_MIN || val > INT_MAX)
					err(DEBUG_CAT_INIT, "strtol fail\n");
				else
					conf->internet = (int)val;
			} else if (os_strcmp(token, "venue_group") == 0) {
				token = strtok(NULL, "");
				if (!token) {
					err(DEBUG_CAT_INIT, "strtok fail\n");
					continue;
				}
				if (os_strcmp(token, "n/a") != 0) {
					errno = 0;
					val = strtol(token, &endptr, 10);
					if (errno == ERANGE || *endptr != '\0' || val < INT_MIN || val > INT_MAX)
						err(DEBUG_CAT_INIT, "strtol fail\n");
					else
						conf->venue_group = (int)val;
					conf->is_venue_group = 1;
				}
			} else if (os_strcmp(token, "venue_type") == 0) {
				token = strtok(NULL, "");
				if (!token) {
					err(DEBUG_CAT_INIT, "strtok fail\n");
					continue;
				}
				if (os_strcmp(token, "n/a") != 0) {
					errno = 0;
					val = strtol(token, &endptr, 10);
					if (errno == ERANGE || *endptr != '\0' || val < INT_MIN || val > INT_MAX)
						err(DEBUG_CAT_INIT, "strtol fail\n");
					else
						conf->venue_type = (int)val;
					conf->is_venue_type = 1;
				}
			} else if (os_strcmp(token, "anqp_query") == 0) {
				token = strtok(NULL, "");
				if (!token) {
					err(DEBUG_CAT_INIT, "strtok fail\n");
					continue;
				}
				errno = 0;
				val = strtol(token, &endptr, 10);
				if (errno == ERANGE || *endptr != '\0' || val < 0 || val > UCHAR_MAX)
					err(DEBUG_CAT_INIT, "strtol fail\n");
				else
					conf->anqp_query = (u8)val;
			} else if (os_strcmp(token, "anqp_domain_id") == 0) {
				token = strtok(NULL, "");
				if (!token) {
					err(DEBUG_CAT_INIT, "strtok fail\n");
					continue;
				}
				errno = 0;
				val = strtol(token, &endptr, 10);
				if (errno == ERANGE || *endptr != '\0' || val < 0 || val > USHRT_MAX)
					err(DEBUG_CAT_INIT, "strtol fail\n");
				else
					conf->anqp_domain_id = (u16)val;
			} else if (os_strcmp(token, "cosr_support") == 0) {
				token = strtok(NULL, "");
				if (!token) {
					err(DEBUG_CAT_INIT, "strtok fail\n");
					continue;
				}

				errno = 0;
				val = strtol(token, &endptr, 10);
				if (errno == ERANGE || *endptr != '\0' || val < 0 || val > UCHAR_MAX)
					err(DEBUG_CAT_INIT, "strtol fail\n");
				else
					conf->cosr_support = (u8)val;
			} else if (os_strcmp(token, "mih_support") == 0) {
				token = strtok(NULL, "");
				if (!token) {
					err(DEBUG_CAT_INIT, "strtok fail\n");
					continue;
				}
				errno = 0;
				val = strtol(token, &endptr, 10);
				if (errno == ERANGE || *endptr != '\0' || val < 0 || val > UCHAR_MAX)
					err(DEBUG_CAT_INIT, "strtol fail\n");
				else
					conf->mih_support = (u8)val;
			} else if (os_strcmp(token, "hessid") == 0) {
				token = strtok(NULL, ",");
				if (!token) {
					err(DEBUG_CAT_INIT, "strtok fail\n");
					continue;
				}
				if (os_strcmp(token, "bssid") == 0) {
					/* TODO: just use in hotspot */
					if (wapp->drv_mode == WEXT)
						hotspot_get_bssid(wapp, conf);
					conf->is_hessid = 1;
				} else if (os_strcmp(token, "n/a") != 0) {
					ret = os_snprintf(tmp1buf, sizeof(tmp1buf), "%s", token);
					if (os_snprintf_error(sizeof(tmp1buf), ret)) {
						err(DEBUG_CAT_INIT, "os_snprintf fail\n");
						continue;
					}
					token1 = strtok(tmp1buf, ":");
					i = 0;
					while (token1 != NULL) {
						// i = 0;
						AtoH(token1, &conf->hessid[i], 1);
						i++;
						token1 = strtok(NULL, ":");
					}
					if (i == 6)
						conf->is_hessid = 1;
				}
			} else if (os_strcmp(token, "roaming_consortium_oi") == 0) {
				struct oi_duple *oiduple;
				token = strtok(NULL, ",");
				if (!token) {
					err(DEBUG_CAT_INIT, "strtok fail\n");
					continue;
				}
				if (os_strcmp(token, "n/a") != 0) {
					while (token != NULL) {
						i = 0;
						varlen = 0;
						ret = snprintf(tmp1buf, sizeof(tmp1buf), "%s", token);
						if (os_snprintf_error(sizeof(tmp1buf), ret)) {
							err(DEBUG_CAT_INIT, "snprintf fail\n");
							continue;
						}
						ret = snprintf(tmp2buf, sizeof(tmp2buf), "%s", token);
						if (os_snprintf_error(sizeof(tmp2buf), ret)) {
							err(DEBUG_CAT_INIT, "snprintf fail\n");
							continue;
						}
						token1 = strtok(tmp1buf, "-");
						while (token1 != NULL) {
							varlen += 1;
							token1 = strtok(NULL, "-");
						}
						oiduple = os_zalloc(sizeof(struct oi_duple) + varlen);
						oiduple->length = varlen;

						token1 = strtok(tmp2buf, "-");
						while (token1 != NULL) {
							AtoH(token1, &oiduple->oi[i], 1);
							token1 = strtok(NULL, "-");
							i++;
						}
						dl_list_add_tail(&conf->oi_duple_list, &oiduple->list);
						token = strtok(token + (varlen * 3), ",");
					}
					if (!dl_list_empty(&conf->oi_duple_list))
						conf->have_roaming_consortium_list = 1;
				}
			} else if (os_strcmp(token, "advertisement_proto_id") == 0) {
				token = strtok(NULL, ":");
				while (token != NULL) {
					conf->advertisement_proto_num++;
					token = strtok(NULL, ":");
				}
				if (conf->advertisement_proto_num > 0) {
					conf->advertisement_proto = os_zalloc(conf->advertisement_proto_num);
					if (!conf->advertisement_proto) {
						err(DEBUG_CAT_MISC, "alloc advertisement_proto_num fail\n");
						goto error;
					}
					token = strtok(tmpbuf, "=");
					if (!token) {
						err(DEBUG_CAT_INIT, "strtok fail\n");
						continue;
					}
					token = strtok(NULL, ":");
					i = 0;

					while (token != NULL && i < conf->advertisement_proto_num) {
						errno = 0;
						val = strtol(token, &endptr, 10);
						if (errno == ERANGE || *endptr != '\0' || val < CHAR_MIN || val > CHAR_MAX)
							err(DEBUG_CAT_INIT, "strtol fail\n");
						else
							conf->advertisement_proto[i] = (char)val;
						i++;
						token = strtok(NULL, ":");
					}
				}
			} else if (os_strcmp(token, "domain_name") == 0) {
				struct domain_name_field *dname_field;
				token = strtok(NULL, ";");
				if (!token) {
					err(DEBUG_CAT_INIT, "strtok fail\n");
					continue;
				}

				if (os_strcmp(token, "n/a") != 0) {
					while (token != NULL) {
						dname_field = os_zalloc(sizeof(struct domain_name_field) + os_strlen(token));
						dname_field->length = os_strlen(token);
						ret = os_snprintf(dname_field->domain_name, dname_field->length+1, "%s", token);
						if (os_snprintf_error(os_strlen(dname_field->domain_name) + 1, ret)) {
							err(DEBUG_CAT_INIT, "os_snprintf fail\n");
							os_free(dname_field);
							continue;
						}
						dl_list_add_tail(&conf->domain_name_list, &dname_field->list);
						token = strtok(NULL, ";");
					}

					if (!dl_list_empty(&conf->domain_name_list))
						conf->have_domain_name_list = 1;
				}

			} else if (os_strncmp(token, "venue_name", 10) == 0) {
				struct venue_name_duple *vname_duple;
				token = strtok(NULL, "%");
				if (!token) {
					err(DEBUG_CAT_INIT, "strtok fail\n");
					continue;
				}
				if (os_strcmp(token, "n/a") != 0) {
					int max_venue_len = 255, copy_len = 0;
					char *venue_ptr;
					token = strtok(NULL, "%");
					if (!token) {
						err(DEBUG_CAT_INIT, "strtok fail\n");
						continue;
					}
					vname_duple = os_zalloc(sizeof(struct venue_name_duple) + 256);
					token = strtok(tmpbuf, "=");
					if (!token) {
						err(DEBUG_CAT_INIT, "strtok fail\n");
						os_free(vname_duple);
						continue;
					}
					token = strtok(NULL, "%");
					if (!token) {
						err(DEBUG_CAT_INIT, "strtok fail\n");
						os_free(vname_duple);
						continue;
					}
					vname_duple->length += 3;
					os_strncpy(vname_duple->language, token, 3);
					token = strtok(NULL, "%");
					if (!token) {
						err(DEBUG_CAT_INIT, "strtok fail\n");
						os_free(vname_duple);
						continue;
					}
					if (token[0] == '{') {
						token++;
						venue_ptr = vname_duple->venue_name;

						while (1) {
							if (token[os_strlen(token) - 1] == '}') {
								if ((vname_duple->length) + (os_strlen(token) - 1) > max_venue_len)
									copy_len = max_venue_len - vname_duple->length;
								else
									copy_len = os_strlen(token) - 1;

								vname_duple->length += copy_len;
								os_strncpy(venue_ptr, token, copy_len);
								venue_ptr += copy_len;
								break;
							} else {
								if ((vname_duple->length) + (os_strlen(token) + 1) > max_venue_len) {
									copy_len = max_venue_len - vname_duple->length;
									vname_duple->length += copy_len;
									os_strncpy(venue_ptr, token, copy_len);
									venue_ptr += copy_len;
									break;
								} else {
									copy_len = os_strlen(token) + 1;
									vname_duple->length += copy_len;
									os_strncpy(venue_ptr, token, copy_len - 1);
									venue_ptr += copy_len - 1;
									*venue_ptr = 0x0a;
									venue_ptr += 1;
								}
							}
							if (wapp_config_get_line(buf, sizeof(buf), file, &line, &pos)) {
								ret = os_snprintf(tmpbuf, sizeof(tmpbuf), "%s", token);
								if (os_snprintf_error(sizeof(tmpbuf), ret))
									err(DEBUG_CAT_INIT, "os_snprintf fail\n");
								varlen = 0;
								token = strtok(pos, "=");
							}
						}
					} else {
						err(DEBUG_CAT_INIT, "venue name format error!! no { start\n");
					}

					dl_list_add_tail(&conf->venue_name_list, &vname_duple->list);
					conf->venue_name_nums++;

					if (!dl_list_empty(&conf->venue_name_list))
						conf->have_venue_name = 1;
				}
			} else if (os_strncmp(token, "network_auth_type", 17) == 0) {
				struct net_auth_type_unit *auth_type_unit;
				token = strtok(NULL, ",");
				if (!token) {
					err(DEBUG_CAT_INIT, "strtok fail\n");
					continue;
				}
				if (os_strcmp(token, "n/a") != 0) {
					token = strtok(NULL, ",");

					if (token)
						auth_type_unit = os_zalloc(sizeof(struct net_auth_type_unit) + os_strlen(token));
					else
						auth_type_unit = os_zalloc(sizeof(struct net_auth_type_unit));

					token = strtok(tmpbuf, "=");
					if (!token) {
						err(DEBUG_CAT_INIT, "strtok fail\n");
						os_free(auth_type_unit);
						continue;
					}
					token = strtok(NULL, ",");
					if (!token) {
						err(DEBUG_CAT_INIT, "strtok fail\n");
						os_free(auth_type_unit);
						continue;
					}
					errno = 0;
					val = strtol(token, &endptr, 10);
					if (errno == ERANGE || *endptr != '\0' || val < 0 || val > UCHAR_MAX)
						err(DEBUG_CAT_INIT, "strtol fail\n");
					else
						auth_type_unit->net_auth_type_indicator = (u8)val;
					token = strtok(NULL, ",");

					if (token)
						auth_type_unit->re_direct_URL_len = os_strlen(token);
					else
						auth_type_unit->re_direct_URL_len = 0;

					if (token) {
						os_snprintf(auth_type_unit->re_direct_URL,
							auth_type_unit->re_direct_URL_len+1, "%s", token);
					}

					dl_list_add_tail(&conf->network_auth_type_list, &auth_type_unit->list);
					conf->network_auth_type_nums++;

					if (!dl_list_empty(&conf->network_auth_type_list))
						conf->have_network_auth_type = 1;
				}
			} else if (os_strcmp(token, "ipv4_type") == 0) {
				token = strtok(NULL, "");
				if (!token) {
					err(DEBUG_CAT_INIT, "strtok fail\n");
					continue;
				}
				if (os_strcmp(token, "n/a") != 0) {
					char *endptr = NULL;
					long val = strtol(token, &endptr, 10);

					if (endptr == token || *endptr != '\0' || val < 0 || val > INT_MAX) {
						err(DEBUG_CAT_INIT, "strtol fail\n");
						continue;
					}
					conf->ipv4_address_type = (int)val;
					conf->have_ip_address_type = 1;
				}
			} else if (os_strcmp(token, "ipv6_type") == 0) {
				token = strtok(NULL, "");
				if (!token) {
					err(DEBUG_CAT_INIT, "strtok fail\n");
					continue;
				}
				if (os_strcmp(token, "n/a") != 0) {
					errno = 0;
					val = strtol(token, &endptr, 10);
					if (errno == ERANGE || *endptr != '\0' || val < 0 || val > UCHAR_MAX)
						err(DEBUG_CAT_INIT, "strtol fail\n");
					else
						conf->ipv6_address_type = (u8)val;
					conf->have_ip_address_type = 1;
				}
			} else if (os_strncmp(token, "osu_providers_list", 18) == 0) {
				token = strtok(NULL, "");
				if (!token) {
					err(DEBUG_CAT_INIT, "strtok fail\n");
					continue;
				}
				if (os_strcmp(token, "n/a") != 0) {
					if (os_strcmp(token, "{") == 0) {
						IsProviderList = 1;
						providers_list = os_zalloc(sizeof(*providers_list));
						/* 5:osu_server_uri_len + osu_method_list_len + osu_nai_len + icon_avail_len */
						/* 4:osu_friendly_name_len + osu_service_len */
						providers_list->osu_providers_list_field_len = 5 + 4;
						dl_list_init(&providers_list->osu_friendly_name_list);
						dl_list_init(&providers_list->osu_method_list);
						dl_list_init(&providers_list->icon_list);
						dl_list_init(&providers_list->osu_nai_list);
						dl_list_init(&providers_list->osu_service_desc_list);
						dl_list_add_tail(&conf->osu_providers_list, &providers_list->list);
					}
				} else
					conf->osu_providers_list_nums = 0;
			} else if (os_strcmp(token, "osu_friendly_name") == 0) {
				struct osu_friendly_name *friendly_name;
				token = strtok(NULL, "");
				if (os_strcmp(token, "n/a") != 0) {
					friendly_name = os_zalloc(sizeof(struct osu_friendly_name) + os_strlen(token));
					token = strtok(tmpbuf, "=");
					if (!token) {
						err(DEBUG_CAT_INIT, "strtok fail\n");
						os_free(friendly_name);
						continue;
					}
					token = strtok(NULL, ":");
					if (!token) {
						err(DEBUG_CAT_INIT, "strtok fail\n");
						os_free(friendly_name);
						continue;
					}
					friendly_name->len += 3;
					os_strncpy(friendly_name->language, token, 3);
					token = strtok(NULL, ":");
					friendly_name->len += os_strlen(token);
					os_strncpy(friendly_name->osu_friendly_name_value, token, os_strlen(token));

					if (providers_list) {
						providers_list->osu_providers_list_field_len += 4 + os_strlen(token);
						dl_list_add_tail(&providers_list->osu_friendly_name_list, &friendly_name->list);
						providers_list->osu_friendly_name_len += 4 + os_strlen(token);
					} else {
						err(DEBUG_CAT_INIT, "osu_friendly_name unexpected NULL\n");
						os_free(friendly_name);
					}
				}
			} else if (os_strcmp(token, "osu_server_uri") == 0) {
				token = strtok(NULL, "");
				if (!token) {
					err(DEBUG_CAT_INIT, "strtok fail\n");
					continue;
				}
				if (os_strcmp(token, "n/a") != 0) {
					if (providers_list) {
						providers_list->osu_server_uri = os_zalloc(os_strlen(token));
						os_memcpy(providers_list->osu_server_uri, token, os_strlen(token));
						providers_list->osu_server_uri_len = os_strlen(token);
						providers_list->osu_providers_list_field_len += os_strlen(token);
					} else {
						err(DEBUG_CAT_INIT, "osu_server_uri unexpected NULL\n");
					}
				}
			} else if (os_strcmp(token, "osu_method") == 0) {
				struct osu_method *method;
				token = strtok(NULL, "");
				if (!token) {
					err(DEBUG_CAT_INIT, "strtok fail\n");
					continue;
				}
				if (os_strcmp(token, "n/a") != 0) {
					method = os_zalloc(sizeof(struct osu_method));
					token = strtok(tmpbuf, "=");
					if (!token) {
						err(DEBUG_CAT_INIT, "strtok fail\n");
						os_free(method);
						continue;
					}
					token = strtok(NULL, " ");
					if (!token) {
						err(DEBUG_CAT_INIT, "strtok fail\n");
						os_free(method);
						continue;
					}
					errno = 0;
					val = strtol(token, &endptr, 10);
					if (errno == ERANGE || *endptr != '\0' || val < CHAR_MIN || val > CHAR_MAX)
						err(DEBUG_CAT_INIT, "strtol fail\n");
					else
						method->osu_method_value = (char)val;
					if (providers_list) {
						dl_list_add_tail(&providers_list->osu_method_list, &method->list);
						providers_list->osu_method_len++;
						providers_list->osu_providers_list_field_len += 1;
					} else {
						err(DEBUG_CAT_INIT, "osu_method unexpected NULL\n");
						os_free(method);
					}
				}
			} else if (os_strcmp(token, "icon") == 0) {
				struct icon_available *icon;
				char *type, *name;
				char *lang;
				int weight = 0, height = 0;
				token = strtok(NULL, "");
				if (os_strcmp(token, "n/a") != 0) {
					token = strtok(tmpbuf, "=");
					if (!token) {
						err(DEBUG_CAT_INIT, "strtok fail\n");
						continue;
					}
					token = strtok(NULL, ":");
					if (!token) {
						err(DEBUG_CAT_INIT, "strtok fail\n");
						continue;
					}
					errno = 0;
					val = strtol(token, &endptr, 10);
					if (errno == ERANGE || *endptr != '\0' || val < INT_MIN || val > INT_MAX)
						err(DEBUG_CAT_INIT, "strtol fail\n");
					else
						weight = (int)val;
					token = strtok(NULL, ":");
					if (!token) {
						err(DEBUG_CAT_INIT, "strtok fail\n");
						continue;
					}
					errno = 0;
					val = strtol(token, &endptr, 10);
					if (errno == ERANGE || *endptr != '\0' || val < INT_MIN || val > INT_MAX)
						err(DEBUG_CAT_INIT, "strtol fail\n");
					else
						height = (int)val;
					lang = strtok(NULL, ":");
					if (!lang) {
						err(DEBUG_CAT_INIT, "strtok fail\n");
						continue;
					}
					type = strtok(NULL, ":");
					if (!type) {
						err(DEBUG_CAT_INIT, "strtok fail\n");
						continue;
					}
					name = strtok(NULL, ":");
					if (!name) {
						err(DEBUG_CAT_INIT, "strtok fail\n");
						continue;
					}
					icon = os_zalloc(sizeof(*icon) + os_strlen(type) + os_strlen(name));

					icon->weight = weight;
					icon->height = height;
					os_memcpy(icon->language, lang, 3);
					os_memcpy(icon->icon_buf, type, os_strlen(type));
					icon->type_len = os_strlen(type);

					os_memcpy(&icon->icon_buf[icon->type_len], name, os_strlen(name));
					icon->filename_len = os_strlen(name);

					if (providers_list) {
						dl_list_add_tail(&providers_list->icon_list, &icon->list);
						providers_list->icon_len += 9 + os_strlen(type) + os_strlen(name);
						providers_list->osu_providers_list_field_len += 9 + os_strlen(type) + os_strlen(name);
					} else {
						err(DEBUG_CAT_INIT, "icon unexpected NULL\n");
						os_free(icon);
					}
				}
			} else if (os_strncmp(token, "advice_of_charge_data", 21) == 0) {
				token = strtok(NULL, "");
				if (os_strcmp(token, "n/a") != 0) {
					if (os_strcmp(token, "{") == 0) {
						IsAOCData = 1;
						charge_data = os_zalloc(sizeof(*charge_data));
						dl_list_init(&charge_data->aoc_plan_tuples_list);
					}
				} else {
					conf->advice_of_charge_data_nums = 0;
					conf->have_advice_of_charge = 0;
				}
			} else if ((os_strcmp(token, "}") == 0) && IsAOCData) {
				if (charge_data)
					dl_list_add_tail(&conf->advice_of_charge_list, &charge_data->list);
				else
					err(DEBUG_CAT_INIT, "AdviceOfChargeData unexpected NULL, error in file parsing\n");
				conf->advice_of_charge_data_nums++;
				IsAOCData = 0;
				charge_data = NULL;
			} else if (os_strcmp(token, "advice_of_charge_type") == 0) {
				token = strtok(NULL, "");

				if (!charge_data) {
					err(DEBUG_CAT_INIT, "advice_of_charge_type unexpected NULL\n");
					continue;
				}

				errno = 0;
				val = strtol(token, &endptr, 10);
				if (errno == ERANGE || *endptr != '\0' || val < INT_MIN || val > INT_MAX)
					err(DEBUG_CAT_INIT, "strtol fails\n");
				else
					switch (val) {
					case TIME_BASED:
						charge_data->advice_of_charge_type = TIME_BASED;
						break;
					case DATA_VOLUME_BASED:
						charge_data->advice_of_charge_type = DATA_VOLUME_BASED;
						break;
					case TIME_AND_DATA_VOLUME_BASED:
						charge_data->advice_of_charge_type = TIME_AND_DATA_VOLUME_BASED;
						break;
					case UNLIMITED:
						charge_data->advice_of_charge_type = UNLIMITED;
						break;
					default:
						err(DEBUG_CAT_INIT, "UNKNOWN ADVICE of CHARGE TYPE.\n");
						break;
					}
			} else if (os_strcmp(token, "aoc_realm_encoding") == 0) {
				token = strtok(NULL, "");
				if ((charge_data != NULL) && (token != NULL)) {
					errno = 0;
					val = strtol(token, &endptr, 10);
					if (errno == ERANGE || *endptr != '\0' || val < 0 || val > UCHAR_MAX)
						err(DEBUG_CAT_INIT, "strtol fail\n");
					else
						charge_data->aoc_realm_encoding = (u8)val;
				} else
					err(DEBUG_CAT_INIT,
						 "ADVICE OF CHARGE Element incomplete, charge_data: [%p], aoc_realm_encoding: [%s]\n",
						 charge_data, token);
			} else if (os_strcmp(token, "aoc_realm") == 0) {
				token = strtok(NULL, "");
				if ((charge_data != NULL) && (token != NULL) && os_strcmp(token, "n/a") != 0) {
					charge_data->aoc_realm_len = os_strlen(token);
					charge_data->aoc_realm = os_zalloc(charge_data->aoc_realm_len);
					os_strncpy(charge_data->aoc_realm, token, charge_data->aoc_realm_len);
				} else if ((charge_data != NULL)) {
					charge_data->aoc_realm_len = 0;
				} else
					err(DEBUG_CAT_INIT,
						 "ADVICE OF CHARGE Element incomplete, charge_data: [%p], aoc_realm: [%s]\n", charge_data,
						 token);
			} else if (os_strcmp(token, "aoc_language") == 0) {
				token = strtok(NULL, "");
				plan_tuple_data = os_zalloc(sizeof(*plan_tuple_data));
				if ((plan_tuple_data != NULL) && (token != NULL))
					os_strncpy(plan_tuple_data->language, token, 3);
				else
					err(DEBUG_CAT_INIT,
						 "ADVICE OF CHARGE Element incomplete, plan_tuple_data: [%p], aoc_language: [%s]\n",
						 plan_tuple_data, token);
			} else if (os_strcmp(token, "aoc_currency_code") == 0) {
				token = strtok(NULL, "");
				if ((plan_tuple_data != NULL) && (token != NULL))
					os_strncpy(plan_tuple_data->currency_code, token, 3);
				else
					err(DEBUG_CAT_INIT,
						 "ADVICE OF CHARGE Element incomplete, plan_tuple_data: [%p], aoc_currency_code: "
						 "[%s]\n",
						 plan_tuple_data, token);
			} else if (os_strcmp(token, "aoc_plan_info") == 0) {
				token = strtok(NULL, "");
				if ((plan_tuple_data != NULL) && (token != NULL)) {
					plan_tuple_data->plan_information_len = os_strlen(token);
					plan_tuple_data->plan_information = os_zalloc(plan_tuple_data->plan_information_len);
					os_strncpy(plan_tuple_data->plan_information, token, plan_tuple_data->plan_information_len);
					conf->have_advice_of_charge = 1;
					dl_list_add_tail(&charge_data->aoc_plan_tuples_list, &plan_tuple_data->list);
				} else {
					if (plan_tuple_data != NULL)
						plan_tuple_data->plan_information_len = 0;
					err(DEBUG_CAT_INIT,
						 "ADVICE OF CHARGE Element incomplete, plan_tuple_data: [%p], aoc_plan_info: [%s]\n",
						 plan_tuple_data, token);
				}
				plan_tuple_data = NULL;
			} else if (os_strcmp(token, "venue_url") == 0) {
				struct venue_url_duple *vurl_duple;
				int ven_num = 0;
				token = strtok(NULL, ",");
				if ((os_strcmp(token, "n/a") != 0) && (token != NULL)) {
					errno = 0;
					val = strtol(token, &endptr, 10);
					if (errno == ERANGE || *endptr != '\0' || val < INT_MIN || val > INT_MAX)
						err(DEBUG_CAT_INIT, "strtol fail\n");
					else
						ven_num = (int)val;
					token = strtok(NULL, ",");
					vurl_duple = os_zalloc(sizeof(*vurl_duple) + os_strlen(token));

					vurl_duple->venue_number = ven_num;
					vurl_duple->url_length = os_strlen(token);
					os_strncpy(vurl_duple->venue_url, token, vurl_duple->url_length);
					dl_list_add_tail(&conf->venue_url_list, &vurl_duple->list);
					conf->venue_url_nums++;

					if (!dl_list_empty(&conf->venue_url_list))
						conf->have_venue_url = 1;
					else
						conf->have_venue_url = 0;
				}
			} else if (os_strcmp(token, "t_c_filename") == 0) {
				token = strtok(NULL, "");
				conf->have_t_c_filename = 1;
				conf->t_c_filename = os_zalloc(os_strlen(token)+1);
				if (!conf->t_c_filename) {
					err(DEBUG_CAT_MISC, "alloc t_c_filename fail\n");
					continue;
				}
				os_strncpy(conf->t_c_filename, token, os_strlen(token));
				conf->t_c_filename[os_strlen(token)] = '\0';
			} else if (os_strcmp(token, "t_c_server_url") == 0) {
				token = strtok(NULL, "");
				conf->have_t_c_server_url = 1;
				conf->t_c_server_url = os_zalloc(os_strlen(token)+1);
				os_strncpy(conf->t_c_server_url, token, os_strlen(token));
				conf->t_c_server_url[os_strlen(token)] = '\0';
			} else if (os_strcmp(token, "t_c_timestamp") == 0) {
				token = strtok(NULL, "");
				conf->have_t_c_timestamp = 1;
				conf->t_c_timestamp = os_zalloc(os_strlen(token)+1);
				os_strncpy(conf->t_c_timestamp, token,
					os_strlen(token) < sizeof(conf->t_c_timestamp) ?
					os_strlen(token) : sizeof(conf->t_c_timestamp) - 1);
				conf->t_c_timestamp[os_strlen(token)] = '\0';
			} else if (os_strcmp(token, "osu_providers_nai_list") == 0) {
				struct osu_providers_nai_duple *osu_prov_nai_duple;
				int len = 0;
				token = strtok(NULL, ",");
				if ((os_strcmp(token, "n/a") != 0) && (token != NULL)) {
					errno = 0;
					val = strtol(token, &endptr, 10);
					if (errno == ERANGE || *endptr != '\0' || val < INT_MIN || val > INT_MAX)
						err(DEBUG_CAT_INIT, "strtol fail\n");
					else
						len = (int)val;
					token = strtok(NULL, ",");

					osu_prov_nai_duple = os_zalloc(sizeof(*osu_prov_nai_duple) + len);
					osu_prov_nai_duple->length = len;
					os_strncpy(osu_prov_nai_duple->osu_providers_nai_list, token, len);
					dl_list_add_tail(&conf->osu_providers_nai_duple_list, &osu_prov_nai_duple->list);
					conf->osu_providers_nai_nums++;

					if (!dl_list_empty(&conf->osu_providers_nai_duple_list))
						conf->have_osu_providers_nai_list = 1;
					else
						conf->have_osu_providers_nai_list = 0;
				}
			} else if (os_strcmp(token, "icon_metadata") == 0) {
				struct operator_icon_metadata *oim_data;
				char *type, *name;
				char *lang;
				int weight = 0, height = 0;
				token = strtok(NULL, "");
				if (os_strcmp(token, "n/a") != 0) {
					token = strtok(tmpbuf, "=");
					if (!token) {
						err(DEBUG_CAT_INIT, "strtok fail\n");
						continue;
					}
					token = strtok(NULL, ":");
					if (!token) {
						err(DEBUG_CAT_INIT, "strtok fail\n");
						continue;
					}
					errno = 0;
					val = strtol(token, &endptr, 10);
					if (errno == ERANGE || *endptr != '\0' || val < INT_MIN || val > INT_MAX)
						err(DEBUG_CAT_INIT, "strtol fail\n");
					else
						weight = (int)val;
					token = strtok(NULL, ":");
					if (!token) {
						err(DEBUG_CAT_INIT, "strtok fail\n");
						continue;
					}
					errno = 0;
					val = strtol(token, &endptr, 10);
					if (errno == ERANGE || *endptr != '\0' || val < INT_MIN || val > INT_MAX)
						err(DEBUG_CAT_INIT, "strtol fail\n");
					else
						height = (int)val;
					lang = strtok(NULL, ":");
					if (!lang) {
						err(DEBUG_CAT_INIT, "strtok fail\n");
						continue;
					}
					type = strtok(NULL, ":");
					if (!type) {
						err(DEBUG_CAT_INIT, "strtok fail\n");
						continue;
					}
					name = strtok(NULL, ":");
					if (!name) {
						err(DEBUG_CAT_INIT, "strtok fail\n");
						continue;
					}
					oim_data = os_zalloc(sizeof(*oim_data) + os_strlen(type) + os_strlen(name));

					oim_data->weight = weight;
					oim_data->height = height;
					os_memcpy(oim_data->language, lang, 3);
					os_memcpy(oim_data->icon_buf, type, os_strlen(type));
					oim_data->type_len = os_strlen(type);

					os_memcpy(&oim_data->icon_buf[oim_data->type_len], name, os_strlen(name));
					oim_data->filename_len = os_strlen(name);
					dl_list_add_tail(&conf->icon_metadata_list, &oim_data->list);

					if (!dl_list_empty(&conf->icon_metadata_list))
						conf->have_icon_metadata = 1;
					else
						conf->have_icon_metadata = 0;
				}
			} else if (os_strcmp(token, "osu_nai") == 0) {
				struct osu_nai *nai;
				token = strtok(NULL, "");
				if (!token) {
					err(DEBUG_CAT_INIT, "strtok fail\n");
					continue;
				}
				if (os_strcmp(token, "n/a") != 0) {
					nai = os_zalloc(sizeof(*nai) + os_strlen(token));
					nai->len = os_strlen(token);
					os_memcpy(nai->osu_nai_value, token, os_strlen(token));

					if (providers_list) {
						providers_list->osu_providers_list_field_len += nai->len;
						dl_list_add_tail(&providers_list->osu_nai_list, &nai->list);
						providers_list->osu_nai_len += nai->len;
					} else {
						err(DEBUG_CAT_INIT, "osu_nai unexpected NULL\n");
						os_free(nai);
					}
				}
			} else if (os_strcmp(token, "osu_service_desc") == 0) {
				struct osu_service_desc *service_desc;
				token = strtok(NULL, "");
				if (!token) {
					err(DEBUG_CAT_INIT, "strtok fail\n");
					continue;
				}
				if (os_strcmp(token, "n/a") != 0) {
					service_desc = os_zalloc(sizeof(*service_desc) + os_strlen(token));
					token = strtok(tmpbuf, "=");
					if (!token) {
						err(DEBUG_CAT_INIT, "strtok fail\n");
						os_free(service_desc);
						continue;
					}
					token = strtok(NULL, ":");
					if (!token) {
						err(DEBUG_CAT_INIT, "strtok fail\n");
						os_free(service_desc);
						continue;
					}
					service_desc->len += 3;
					os_strncpy(service_desc->language, token, 3);
					token = strtok(NULL, ":");
					if (!token) {
						err(DEBUG_CAT_INIT, "strtok fail\n");
						os_free(service_desc);
						continue;
					}
					service_desc->len += os_strlen(token);
					os_strncpy(service_desc->osu_service_desc_value, token, os_strlen(token));

					if (providers_list) {
						providers_list->osu_providers_list_field_len += 4 + os_strlen(token);
						dl_list_add_tail(&providers_list->osu_service_desc_list, &service_desc->list);
						providers_list->osu_service_len += 4 + os_strlen(token);
					} else {
						err(DEBUG_CAT_INIT, "osu_service_desc unexpected NULL\n");
						os_free(service_desc);
					}
				}
			} else if ((os_strcmp(token, "}") == 0) && IsProviderList) {
				conf->osu_providers_list_nums++;
				conf->have_osu_providers_list = 1;
				IsProviderList = 0;
			} else if (os_strncmp(token, "nai_realm_data", 14) == 0) {
				token = strtok(NULL, "");
				if (!token) {
					err(DEBUG_CAT_INIT, "strtok fail\n");
					continue;
				}
				if (os_strcmp(token, "n/a") != 0) {
					if (os_strcmp(token, "{") == 0) {
						IsNAIRealmData = 1;
						realm_data = os_zalloc(sizeof(*realm_data));
						realm_data->nai_realm_data_field_len = 3;
						realm_data->nai_realm_encoding = 0;
						dl_list_init(&realm_data->eap_method_list);
					}
				} else
					conf->nai_realm_data_nums = 0;
			} else if ((os_strcmp(token, "}") == 0) && IsNAIRealmData) {
				dl_list_for_each(eapmethod, &realm_data_new->eap_method_list, struct eap_method, list)
				{
					realm_data_new->nai_realm_data_field_len += 1;
					realm_data_new->nai_realm_data_field_len += eapmethod->len;
				}
				conf->nai_realm_data_nums++;
				IsNAIRealmData = 0;
			} else if (os_strcmp(token, "nai_realm") == 0) {
				token = strtok(NULL, "");
				if (!token) {
					err(DEBUG_CAT_INIT, "strtok fail\n");
					continue;
				}
				varlen = os_strlen(token);
				realm_data_new = os_realloc(realm_data, sizeof(*realm_data) + varlen);
				if (!realm_data_new) {
					os_free(realm_data);
					err(DEBUG_CAT_INIT, "os_realloc fail\n");
					continue;
				}

				dl_list_init(&realm_data_new->eap_method_list);
				os_memcpy(realm_data_new->nai_realm, token, varlen);
				realm_data_new->nai_realm_len = varlen;
				realm_data_new->nai_realm_data_field_len += varlen;
				conf->have_nai_realm_list = 1;
				dl_list_add_tail(&conf->nai_realm_list, &realm_data_new->list);
			} else if (os_strncmp(token, "eap_method", 10) == 0) {
				token = strtok(NULL, "");

				if (!realm_data_new) {
					err(DEBUG_CAT_INIT, "eap_method unexpected NULL\n");
					continue;
				}

				if (os_strcmp(token, "eap-ttls") == 0) {
					realm_data_new->eap_method_count++;
					eapmethod = os_zalloc(sizeof(*eapmethod));
					eapmethod->len = 2;
					eapmethod->eap_method = EAP_TTLS;
					dl_list_init(&eapmethod->auth_param_list);
					dl_list_add_tail(&realm_data_new->eap_method_list, &eapmethod->list);
				} else if (os_strcmp(token, "eap-tls") == 0) {
					realm_data_new->eap_method_count++;
					eapmethod = os_zalloc(sizeof(*eapmethod));
					eapmethod->len = 2;
					eapmethod->eap_method = EAP_TLS;
					dl_list_init(&eapmethod->auth_param_list);
					dl_list_add_tail(&realm_data_new->eap_method_list, &eapmethod->list);
				} else if (os_strcmp(token, "eap-sim") == 0) {
					realm_data_new->eap_method_count++;
					eapmethod = os_zalloc(sizeof(*eapmethod));
					eapmethod->len = 2;
					eapmethod->eap_method = EAP_SIM;
					dl_list_init(&eapmethod->auth_param_list);
					dl_list_add_tail(&realm_data_new->eap_method_list, &eapmethod->list);
				} else if (os_strcmp(token, "eap-aka") == 0) {
					realm_data_new->eap_method_count++;
					eapmethod = os_zalloc(sizeof(*eapmethod));
					eapmethod->len = 2;
					eapmethod->eap_method = EAP_AKA;
					dl_list_init(&eapmethod->auth_param_list);
					dl_list_add_tail(&realm_data_new->eap_method_list, &eapmethod->list);
				}
			} else if (os_strncmp(token, "auth_param", 9) == 0) {
				token = strtok(NULL, ":");

				if (!eapmethod) {
					err(DEBUG_CAT_INIT, "auth_param unexpected NULL\n");
					continue;
				}

				authparam = os_zalloc(sizeof(*authparam));
				eapmethod->auth_param_count++;
				errno = 0;
				val = strtol(token, &endptr, 10);
				if (errno == ERANGE || *endptr != '\0' || val < INT_MIN || val > INT_MAX)
					err(DEBUG_CAT_INIT, "strtol fail\n");
				else
					switch (val) {
					case EXPANDED_EAP_METHOD:
						authparam->id = EXPANDED_EAP_METHOD;
						authparam->len = 7;
						varlen = 7;
						eapmethod->len += 9;
						break;
					case NON_EAP_INNER_AUTH_TYPE:
						authparam->id = NON_EAP_INNER_AUTH_TYPE;
						authparam->len = 1;
						varlen = 1;
						eapmethod->len += 3;
						break;
					case INNER_AUTH_EAP_METHOD_TYPE:
						authparam->id = INNER_AUTH_EAP_METHOD_TYPE;
						authparam->len = 1;
						varlen = 1;
						eapmethod->len += 3;
						break;
					case EXPANDED_INNER_EAP_METHOD:
						authparam->id = EXPANDED_INNER_EAP_METHOD;
						authparam->len = 7;
						varlen = 7;
						eapmethod->len += 9;
						break;
					case CREDENTIAL_TYPE:
						authparam->id = CREDENTIAL_TYPE;
						authparam->len = 1;
						varlen = 1;
						eapmethod->len += 3;
						break;
					case TUNNELED_EAP_METHOD_CREDENTIAL_TYPE:
						authparam->id = TUNNELED_EAP_METHOD_CREDENTIAL_TYPE;
						authparam->len = 1;
						varlen = 1;
						eapmethod->len += 3;
						break;
					case VENDOR_SPECIFIC:
						/* TODO: varlen is variable */
					default:
						err(DEBUG_CAT_INIT, "Unknown authentication parameter types\n");
						break;
					}

				authparam_new = os_realloc(authparam, sizeof(*authparam) + varlen);
				if (!authparam_new) {
					err(DEBUG_CAT_INIT, "os_realloc fail\n");
					os_free(authparam);
					continue;
				}
				token = strtok(NULL, ":");
				if (!token) {
					err(DEBUG_CAT_INIT, "strtok fail\n");
					os_free(authparam_new);
					continue;
				}

				while (token) {
					if (varlen == 1) {
						errno = 0;
						val = strtol(token, &endptr, 10);
						if (errno == ERANGE || *endptr != '\0' || val < CHAR_MIN || val > CHAR_MAX)
							err(DEBUG_CAT_INIT, "strtol fail\n");
						else
							*authparam_new->auth_param_value = val;
					} else if (varlen == 7) {
						/* TODO */
					}
					token = strtok(NULL, ":");
				}

				dl_list_add_tail(&eapmethod->auth_param_list, &authparam_new->list);

			} else if (os_strncmp(token, "op_friendly_name", 16) == 0) {
				struct operator_name_duple *op_name_duple;
				token = strtok(NULL, ",");
				if (!token) {
					err(DEBUG_CAT_INIT, "strtok fail\n");
					continue;
				}
				if (os_strcmp(token, "n/a") != 0) {
					token = strtok(NULL, ",");
					if (!token) {
						err(DEBUG_CAT_INIT, "strtok fail\n");
						continue;
					}
					op_name_duple = os_zalloc(sizeof(struct operator_name_duple) + os_strlen(token));
					token = strtok(tmpbuf, "=");
					if (!token) {
						err(DEBUG_CAT_INIT, "strtok fail\n");
						os_free(op_name_duple);
						continue;
					}
					token = strtok(NULL, ",");
					if (!token) {
						err(DEBUG_CAT_INIT, "strtok fail\n");
						os_free(op_name_duple);
						continue;
					}
					op_name_duple->length += 3;
					os_strncpy(op_name_duple->language, token, 3);
					token = strtok(NULL, ",");
					if (!token) {
						err(DEBUG_CAT_INIT, "strtok fail\n");
						os_free(op_name_duple);
						continue;
					}
					op_name_duple->length += os_strlen(token);
					os_strncpy(op_name_duple->operator_name, token, os_strlen(token));
					dl_list_add_tail(&conf->operator_friendly_duple_list, &op_name_duple->list);
					conf->op_friendly_name_nums++;

					if (!dl_list_empty(&conf->operator_friendly_duple_list))
						conf->have_operator_friendly_name = 1;
				}
			} else if (os_strncmp(token, "plmn", 4) == 0) {
				token = strtok(NULL, "");
				if (os_strcmp(token, "n/a") != 0) {
					if (os_strcmp(token, "{") == 0) {
						IsPLMN = 1;
						plmn_unit = os_zalloc(sizeof(*plmn_unit));
					}
				} else
					conf->plmn_nums = 0;
			} else if ((os_strcmp(token, "}") == 0) && IsPLMN) {
				dl_list_add_tail(&conf->plmn_list, &plmn_unit->list);
				conf->plmn_nums++;
				if (!dl_list_empty(&conf->plmn_list)) {
					conf->have_3gpp_network_info = 1;
				}
				IsPLMN = 0;
			} else if (os_strcmp(token, "mcc") == 0) {
				token = strtok(NULL, "");

				if (!plmn_unit) {
					err(DEBUG_CAT_INIT, "mcc unexpected NULL\n");
					continue;
				}

				for (i = 0; i < 3; i++)
					plmn_unit->mcc[i] = token[i] - '0';
			} else if (os_strcmp(token, "mnc") == 0) {
				token = strtok(NULL, "");

				if (!plmn_unit) {
					err(DEBUG_CAT_INIT, "mnc unexpected NULL\n");
					continue;
				}

				for (i = 0; i < 3; i++) {
					if (i == 2 && os_strlen(token) == 2)
						plmn_unit->mnc[i] = 0x0f;
					else
						plmn_unit->mnc[i] = token[i] - '0';
				}

			} else if (os_strncmp(token, "proto_port", 10) == 0) {
				token = strtok(NULL, "");
				if (os_strcmp(token, "{") == 0) {
					IsProtoPort = 1;
					proto_port_unit = os_zalloc(sizeof(*proto_port_unit));
				}
			} else if ((os_strcmp(token, "}") == 0) && IsProtoPort) {
				dl_list_add_tail(&conf->connection_capability_list, &proto_port_unit->list);
				conf->proto_port_nums++;
				if (!dl_list_empty(&conf->connection_capability_list))
					conf->have_connection_capability_list = 1;
				IsProtoPort = 0;
			} else if (os_strcmp(token, "operating_class") == 0) {
				struct operating_class_unit *operating_class;
				token = strtok(NULL, ",");

				if (os_strcmp(token, "n/a") != 0) {
					while (token != NULL) {
						operating_class = os_zalloc(sizeof(struct operating_class_unit));
						errno = 0;
						val = strtol(token, &endptr, 10);
						if (errno == ERANGE || *endptr != '\0' || val < 0 || val > UCHAR_MAX)
							err(DEBUG_CAT_INIT, "strtol fail\n");
						else
							operating_class->op_class = (u8)val;
						dl_list_add_tail(&conf->operating_class_list, &operating_class->list);
						token = strtok(NULL, ",");
					}

					if (!dl_list_empty(&conf->operating_class_list))
						conf->have_operating_class = 1;
				}
			} else if (os_strcmp(token, "ip_protocol") == 0) {
				token = strtok(NULL, "");

				if (!proto_port_unit) {
					err(DEBUG_CAT_INIT, "ip_protocol unexpected NULL\n");
					continue;
				}
				errno = 0;
				val = strtol(token, &endptr, 10);
				if (errno == ERANGE || *endptr != '\0' || val < 0 || val > UCHAR_MAX)
					err(DEBUG_CAT_INIT, "strtol fail\n");
				else
					proto_port_unit->ip_protocol = (u8)val;
			} else if (os_strcmp(token, "port") == 0) {
				token = strtok(NULL, "");

				if (!proto_port_unit) {
					err(DEBUG_CAT_INIT, "proto_port_unit unexpected NULL\n");
					continue;
				}
				errno = 0;
				val = strtol(token, &endptr, 10);
				if (errno == ERANGE || *endptr != '\0' || val < 0 || val > USHRT_MAX)
					err(DEBUG_CAT_INIT, "strtol fail\n");
				else
					proto_port_unit->port = (u16)val;
			} else if (os_strcmp(token, "status") == 0) {
				token = strtok(NULL, "");

				if (!proto_port_unit) {
					err(DEBUG_CAT_INIT, "proto_port_unit unexpected NULL\n");
					continue;
				}

				errno = 0;
				val = strtol(token, &endptr, 10);
				if (errno == ERANGE || *endptr != '\0' || val < 0 || val > UCHAR_MAX)
					err(DEBUG_CAT_INIT, "strtol fail\n");
				else
					proto_port_unit->status = (u8)val;

			} else if (os_strcmp(token, "wan_metrics") == 0) {
				token = strtok(NULL, "");
				if (os_strcmp(token, "{") == 0)
					IsWanMetrics = 1;
			} else if ((os_strcmp(token, "}") == 0) && IsWanMetrics) {
				conf->wan_metrics_nums++;
				conf->have_wan_metrics = 1;
				IsWanMetrics = 0;
			} else if (os_strcmp(token, "link_status") == 0) {
				token = strtok(NULL, "");
				errno = 0;
				if (token) {
					val = strtol(token, &endptr, 10);
					if (errno == ERANGE || *endptr != '\0' || endptr == token
						|| val < 0 || val > UCHAR_MAX)
						err(DEBUG_CAT_INIT, "strtol fail\n");
					else
						conf->metrics.link_status = (u8)val;
				} else
					err(DEBUG_CAT_INIT, "strtok is null.\n");
			} else if (os_strcmp(token, "at_capacity") == 0) {
				token = strtok(NULL, "");
				errno = 0;
				val = strtol(token, &endptr, 10);
				if (errno == ERANGE || *endptr != '\0' || val < 0 || val > UCHAR_MAX)
					err(DEBUG_CAT_INIT, "strtol fail\n");
				else
					conf->metrics.at_capacity = (u8)val;
			} else if (os_strcmp(token, "dl_speed") == 0) {
				token = strtok(NULL, "");
				errno = 0;
				val = strtol(token, &endptr, 10);
				if (errno == ERANGE || *endptr != '\0' || val < 0 || val > UINT_MAX)
					err(DEBUG_CAT_INIT, "strtol fail\n");
				else
					conf->metrics.dl_speed = (u32)val;
			} else if (os_strcmp(token, "ul_speed") == 0) {
				token = strtok(NULL, "");
				errno = 0;
				val = strtol(token, &endptr, 10);
				if (errno == ERANGE || *endptr != '\0' || val < 0 || val > UINT_MAX)
					err(DEBUG_CAT_INIT, "strtol fail\n");
				else
					conf->metrics.ul_speed = (u32)val;
			} else if (os_strcmp(token, "dl_load") == 0) {
				token = strtok(NULL, "");
				errno = 0;
				val = strtol(token, &endptr, 10);
				if (errno == ERANGE || *endptr != '\0' || val < 0 || val > UCHAR_MAX)
					err(DEBUG_CAT_INIT, "strtol fail\n");
				else
					conf->metrics.dl_load = (u8)val;
			} else if (os_strcmp(token, "up_load") == 0) {
				token = strtok(NULL, "");
				errno = 0;
				val = strtol(token, &endptr, 10);
				if (errno == ERANGE || *endptr != '\0' || val < 0 || val > UCHAR_MAX)
					err(DEBUG_CAT_INIT, "strtol fail\n");
				else
					conf->metrics.ul_load = (u8)val;
			} else if (os_strcmp(token, "lmd") == 0) {
				token = strtok(NULL, "");
				errno = 0;
				val = strtol(token, &endptr, 10);
				if (errno == ERANGE || *endptr != '\0' || val < 0 || val > USHRT_MAX)
					err(DEBUG_CAT_INIT, "strtol fail\n");
				else
					conf->metrics.lmd = (u16)val;
			} else if (os_strcmp(token, "preferred_candi_list_included") == 0) {
				token = strtok(NULL, "");
				errno = 0;
				val = strtol(token, &endptr, 10);
				if (errno == ERANGE || *endptr != '\0' || val < 0 || val > UCHAR_MAX)
					err(DEBUG_CAT_INIT, "strtol fail\n");
				else
					conf->preferred_candi_list_included = (u8)val;
			} else if (os_strcmp(token, "abridged") == 0) {
				token = strtok(NULL, "");
				errno = 0;
				val = strtol(token, &endptr, 10);
				if (errno == ERANGE || *endptr != '\0' || val < 0 || val > UCHAR_MAX)
					err(DEBUG_CAT_INIT, "strtol fail\n");
				else
					conf->abridged = (u8)val;
			} else if (os_strcmp(token, "disassociation_imminent") == 0) {
				token = strtok(NULL, "");
				errno = 0;
				val = strtol(token, &endptr, 10);
				if (errno == ERANGE || *endptr != '\0' || val < 0 || val > UCHAR_MAX)
					err(DEBUG_CAT_INIT, "strtol fail\n");
				else
					conf->disassociation_imminent = (u8)val;
			} else if (os_strcmp(token, "bss_termination_included") == 0) {
				token = strtok(NULL, "");
				errno = 0;
				val = strtol(token, &endptr, 10);
				if (errno == ERANGE || *endptr != '\0' || val < 0 || val > UCHAR_MAX)
					err(DEBUG_CAT_INIT, "strtol fail\n");
				else
					conf->bss_termination_included = (u8)val;
			} else if (os_strcmp(token, "ess_disassociation_imminent") == 0) {
				token = strtok(NULL, "");
				errno = 0;
				val = strtol(token, &endptr, 10);
				if (errno == ERANGE || *endptr != '\0' || val < 0 || val > UCHAR_MAX)
					err(DEBUG_CAT_INIT, "strtol fail\n");
				else
					conf->ess_disassociation_imminent = (u8)val;
			} else if (os_strcmp(token, "disassociation_timer") == 0) {
				token = strtok(NULL, "");
				errno = 0;
				val = strtol(token, &endptr, 10);
				if (errno == ERANGE || *endptr != '\0' || val < 0 || val > USHRT_MAX)
					err(DEBUG_CAT_INIT, "strtol fail\n");
				else
					conf->disassociation_timer = (u16)val;
			} else if (os_strcmp(token, "validity_interval") == 0) {
				token = strtok(NULL, "");
				errno = 0;
				val = strtol(token, &endptr, 10);
				if (errno == ERANGE || *endptr != '\0' || val < 0 || val > UCHAR_MAX)
					err(DEBUG_CAT_INIT, "strtol fail\n");
				else
					conf->validity_interval = (u8)val;
			} else if (os_strcmp(token, "bss_termination_duration") == 0) {
				token = strtok(NULL, "");
				if (os_strcmp(token, "n/a") != 0) {
					conf->have_bss_termination_duration = 1;
					token = strtok(NULL, ",");
					if (!token) {
						err(DEBUG_CAT_INIT, "strtok fail\n");
						continue;
					}
					errno = 0;
					val = strtol(token, &endptr, 10);
					if (errno == ERANGE || *endptr != '\0')
						err(DEBUG_CAT_INIT, "strtol fail\n");
					else
						conf->bss_termination_tsf = (u64)val;

					token = strtok(NULL, "");
					errno = 0;
					val = strtol(token, &endptr, 10);
					if (errno == ERANGE || *endptr != '\0' || val < 0 || val > USHRT_MAX)
						err(DEBUG_CAT_INIT, "strtol fail\n");
					else
						conf->bss_termination_duration = (u16)val;
				}
			} else if (os_strcmp(token, "session_information_url") == 0) {
				token = strtok(NULL, "");
				conf->have_session_info_url = 1;
				conf->session_info_url_len = os_strlen(token);
				conf->session_info_url = os_zalloc(conf->session_info_url_len);
				os_memcpy(conf->session_info_url, token, conf->session_info_url_len);
			} else if (os_strcmp(token, "bss_transisition_candi_list_preferences") == 0) {
				token = strtok(NULL, ",");
				if (os_strcmp(token, "n/a") != 0) {
					token = strtok(NULL, ",");

					while (token != NULL) {
						struct bss_transition_candi_preference_unit *preference_unit;
						preference_unit = os_zalloc(sizeof(*preference_unit));
						errno = 0;
						val = strtol(token, &endptr, 10);
						if (errno == ERANGE || *endptr != '\0' || val < 0 || val > UCHAR_MAX)
							err(DEBUG_CAT_INIT, "strtol fail\n");
						else
							preference_unit->preference = (u8)val;
						dl_list_add_tail(&conf->bss_transition_candi_list, &preference_unit->list);
						conf->have_bss_transition_candi_list = 1;
						token = strtok(NULL, ",");
					}
				}
			} else if (os_strcmp(token, "timezone") == 0) {
				token = strtok(NULL, "");
				if (!token) {
					err(DEBUG_CAT_INIT, "strtok fail\n");
					continue;
				}
				conf->time_zone_len = os_strlen(token);
				if (conf->time_zone_len > 0) {
					char time_zone[50];
					conf->time_zone = os_zalloc(conf->time_zone_len + 1);
					conf->have_time_zone = 1;
					os_memcpy(conf->time_zone, token, conf->time_zone_len);
					conf->time_zone[conf->time_zone_len] = '\0';
					/* Set time zone in TZ Environement */
					if (conf->time_zone_len <= sizeof(time_zone)) {
						ret = snprintf(time_zone, sizeof(time_zone), "TZ=%s", token);
						if (os_snprintf_error(sizeof(time_zone), ret)) {
							err(DEBUG_CAT_INIT, "snprintf fail\n");
							continue;
						}
						putenv(time_zone);
					}
				}
			} else if (os_strcmp(token, "dgaf_disabled") == 0) {
				token = strtok(NULL, "");
				errno = 0;
				val = strtol(token, &endptr, 10);
				if (errno == ERANGE || *endptr != '\0' || val < 0 || val > UCHAR_MAX)
					err(DEBUG_CAT_INIT, "strtol fail\n");
				else
					conf->DGAF_disabled = (u8)val;
			} else if (os_strcmp(token, "proxy_arp") == 0) {
				token = strtok(NULL, "");
				errno = 0;
				val = strtol(token, &endptr, 10);
				if (errno == ERANGE || *endptr != '\0' || val < 0 || val > UCHAR_MAX)
					err(DEBUG_CAT_INIT, "strtol fail\n");
				else
					conf->proxy_arp = (u8)val;
			} else if (os_strcmp(token, "l2_filter") == 0) {
				token = strtok(NULL, "");
				errno = 0;
				val = strtol(token, &endptr, 10);
				if (errno == ERANGE || *endptr != '\0' || val < 0 || val > UCHAR_MAX)
					err(DEBUG_CAT_INIT, "strtol fail\n");
				else
					conf->l2_filter = (u8)val;
			} else if (os_strcmp(token, "icmpv4_deny") == 0) {
				token = strtok(NULL, "");
				errno = 0;
				val = strtol(token, &endptr, 10);
				if (errno == ERANGE || *endptr != '\0' || val < 0 || val > UCHAR_MAX)
					err(DEBUG_CAT_INIT, "strtol fail\n");
				else
					conf->icmpv4_deny = (u8)val;
			} else if (os_strcmp(token, "p2p_cross_connect_permitted") == 0) {
				token = strtok(NULL, "");
				errno = 0;
				val = strtol(token, &endptr, 10);
				if (errno == ERANGE || *endptr != '\0' || val < 0 || val > UCHAR_MAX)
					err(DEBUG_CAT_INIT, "strtol fail\n");
				else
					conf->p2p_cross_connect_permitted = (u8)val;
			} else if (os_strcmp(token, "mmpdu_size") == 0) {
				token = strtok(NULL, "");
				errno = 0;
				val = strtol(token, &endptr, 10);
				if (errno == ERANGE || *endptr != '\0' || val < 0 || val > UINT_MAX)
					err(DEBUG_CAT_INIT, "strtol fail\n");
				else
					conf->mmpdu_size = (u32)val;
			} else if (os_strcmp(token, "external_anqp_server_test") == 0) {
				token = strtok(NULL, "");
				errno = 0;
				val = strtol(token, &endptr, 10);
				if (errno == ERANGE || *endptr != '\0' || val < 0 || val > UINT_MAX)
					err(DEBUG_CAT_INIT, "strtol fail\n");
				else
					conf->external_anqp_server_test = (u32)val;
			} else if (os_strcmp(token, "gas_cb_delay") == 0) {
				token = strtok(NULL, "");
				errno = 0;
				val = strtol(token, &endptr, 10);
				if (errno == ERANGE || *endptr != '\0' || val < 0 || val > UINT_MAX)
					err(DEBUG_CAT_INIT, "strtol fail\n");
				else
					conf->gas_cb_delay = (u32)val;
			} else if (os_strcmp(token, "hs2_openmode_test") == 0) {
				token = strtok(NULL, "");
				errno = 0;
				val = strtol(token, &endptr, 10);
				if (errno == ERANGE || *endptr != '\0' || val < 0 || val > UINT_MAX)
					err(DEBUG_CAT_INIT, "strtol fail\n");
				else
					conf->hs2_openmode_test = (u32)val;
			} else if (os_strcmp(token, "anonymous_nai") == 0) {
				token = strtok(NULL, "");
				if (os_strcmp(token, "n/a") != 0) {
					conf->have_anonymous_nai = 1;
					conf->anonymous_nai_len = os_strlen(token);
					conf->anonymous_nai = os_zalloc(conf->anonymous_nai_len);
					os_memcpy(conf->anonymous_nai, token, conf->anonymous_nai_len);
				}
			} else if (os_strcmp(token, "osu_interface") == 0) {
				token = strtok(NULL, "");
				if (!token) {
					err(DEBUG_CAT_INIT, "strtok fail\n");
					continue;
				}
				ret = os_snprintf(conf->osu_iface, sizeof(conf->osu_iface), "%s", token);
				if (os_snprintf_error(sizeof(conf->osu_iface), ret)) {
					err(DEBUG_CAT_INIT, "os_snprintf fail\n");
					continue;
				}
			} else if (os_strcmp(token, "legacy_osu") == 0) {
				token = strtok(NULL, "");
				errno = 0;
				val = strtol(token, &endptr, 10);
				if (errno == ERANGE || *endptr != '\0' || val < 0 || val > UCHAR_MAX)
					err(DEBUG_CAT_INIT, "strtol fail\n");
				else
					conf->legacy_osu_exist = (u32)val;
			} else if (os_strcmp(token, "icon_path") == 0) {
				token = strtok(NULL, "");
				conf->have_iconfile_path = 1;
				conf->iconfile_path_len = os_strlen(token);
				conf->iconfile_path = os_zalloc(conf->iconfile_path_len);
				os_memcpy(conf->iconfile_path, token, conf->iconfile_path_len);
			} else if (os_strcmp(token, "qosmap") == 0) {
				token = strtok(NULL, "");
				if (os_strcmp(token, "n/a") != 0) {
					errno = 0;
					val = strtol(token, &endptr, 10);
					if (errno == ERANGE || *endptr != '\0' || val < 0 || val > UCHAR_MAX)
						err(DEBUG_CAT_INIT, "strtol fail\n");
					else
						conf->qosmap_enable = (u32)val;
				}
			} else if (os_strcmp(token, "dscp_range") == 0) {
				qos_cnt = 0;
				token = strtok(NULL, ":");
				if (!token) {
					err(DEBUG_CAT_INIT, "strtok fail\n");
					continue;
				}
				if (os_strcmp(token, "n/a") != 0) {
					while (token != NULL) {
						errno = 0;
						val = strtol(token, &endptr, 10);
						if (errno == ERANGE || *endptr != '\0' || val < 0 || val > UINT_MAX)
							err(DEBUG_CAT_INIT, "strtol fail\n");
						else
							conf->dscp_range[qos_cnt] = (u16)val;
						token = strtok(NULL, ":");
						if (!token) {
							err(DEBUG_CAT_INIT, "strtok fail\n");
							continue;
						}
						errno = 0;
						val = strtol(token, &endptr, 10);
						if (errno == ERANGE || *endptr != '\0' || val < 0 || val > UINT_MAX)
							err(DEBUG_CAT_INIT, "strtol fail\n");
						else
							conf->dscp_range[qos_cnt++] |= (val << 8);
						token = strtok(NULL, ":");
					}
				}
			} else if (os_strcmp(token, "dscp_exception") == 0) {
				qos_cnt = 0;
				token = strtok(NULL, ":");
				if (!token) {
					err(DEBUG_CAT_INIT, "strtok fail\n");
					continue;
				}
				if (os_strcmp(token, "n/a") != 0) {
					u16 dscp_val = 0;
					while (token != NULL) {
						errno = 0;
						val = strtol(token, &endptr, 10);
						if (errno == ERANGE || *endptr != '\0' || val > INT_MAX || val < INT_MIN) {
							err(DEBUG_CAT_INIT, "strtol fail\n");
							continue;
						}
						dscp_val = (u16)val;
						conf->dscp_exception[qos_cnt] = dscp_val;
						token = strtok(NULL, ":");
						if (!token) {
							err(DEBUG_CAT_INIT, "strtok fail\n");
							continue;
						}
						conf->dscp_exception[qos_cnt++] |= (dscp_val << 8);
						token = strtok(NULL, ":");
						conf->dscp_field++;
					}
				}
			} else if (os_strcmp(token, "qload_test") == 0) {
				token = strtok(NULL, "");
				if (os_strcmp(token, "n/a") != 0) {
					errno = 0;
					val = strtol(token, &endptr, 10);
					if (errno == ERANGE || *endptr != '\0' || val < 0 || val > UCHAR_MAX)
						err(DEBUG_CAT_INIT, "strtol fail\n");
					else
						conf->qload_mode = (u8)val;
				}
			} else if (os_strcmp(token, "qload_cu") == 0) {
				token = strtok(NULL, "");
				if (os_strcmp(token, "n/a") != 0) {
					errno = 0;
					val = strtol(token, &endptr, 10);
					if (errno == ERANGE || *endptr != '\0' || val < 0 || val > UCHAR_MAX)
						err(DEBUG_CAT_INIT, "strtol fail\n");
					else
						conf->qload_cu = (u8)val;
				}
			} else if (os_strcmp(token, "qload_sta_cnt") == 0) {
				token = strtok(NULL, "");
				if (os_strcmp(token, "n/a") != 0) {
					errno = 0;
					val = strtol(token, &endptr, 10);
					if (errno == ERANGE || *endptr != '\0' || val < 0 || val > USHRT_MAX)
						err(DEBUG_CAT_INIT, "strtol fail\n");
					else
						conf->qload_sta_cnt = (u16)val;
				}
			} else if (os_strcmp(token, "mbo_cdcp") == 0) {
				token = strtok(NULL, "");
				if (os_strcmp(token, "n/a") != 0) {
					errno = 0;
					val = strtol(token, &endptr, 10);
					if (errno == ERANGE || *endptr != '\0' || val < 0 || val > UCHAR_MAX)
						err(DEBUG_CAT_INIT, "strtol fail\n");
					else
						wapp->mbo->cdcp = (u8)val;
				}
			} else if (os_strcmp(token, "mbo_ap_assoc_disallow_reason") == 0) {
				token = strtok(NULL, "");
				if (os_strcmp(token, "n/a") != 0) {
					errno = 0;
					val = strtol(token, &endptr, 10);
					if (errno == ERANGE || *endptr != '\0' || val < 0 || val > UCHAR_MAX)
						err(DEBUG_CAT_INIT, "strtol fail\n");
					else
						wapp->mbo->assoc_disallow_reason = (u8)val;
				}
			} else if (os_strcmp(token, "mbo_default_assoc_retry_delay") == 0) {
				token = strtok(NULL, "");
				if (os_strcmp(token, "n/a") != 0) {
					errno = 0;
					val = strtol(token, &endptr, 10);
					if (errno == ERANGE || *endptr != '\0' || val < 0 || val > USHRT_MAX)
						err(DEBUG_CAT_INIT, "strtol fail\n");
					else
						wapp->mbo->assoc_retry_delay = (u16)val;
				}
			} else if (os_strcmp(token, "mbo_default_trans_reason") == 0) {
				token = strtok(NULL, "");
				if (os_strcmp(token, "n/a") != 0) {
					errno = 0;
					val = strtol(token, &endptr, 10);
					if (errno == ERANGE || *endptr != '\0' || val < 0 || val > UCHAR_MAX)
						err(DEBUG_CAT_INIT, "strtol fail\n");
					else
						wapp->mbo->dft_trans_reason = (u8)val;
				}
			} else if (os_strcmp(token, "mbo_ap_capability") == 0) {
				token = strtok(NULL, "");
				if (os_strcmp(token, "n/a") != 0) {
					errno = 0;
					val = strtol(token, &endptr, 10);
					if (errno == ERANGE || *endptr != '\0' || val < 0 || val > UCHAR_MAX)
						err(DEBUG_CAT_INIT, "strtol fail\n");
					else
						wapp->mbo->ap_capability = (u8)val;
				}
			}
		}
	}

	conf->have_anqp_capability_list = 1;
	conf->have_hs_capability_list = 1;

	capability_info = os_zalloc(sizeof(*capability_info));
	capability_info->info_id = ANQP_CAPABILITY;
	dl_list_add_tail(&conf->anqp_capability_list, &capability_info->list);

	if (conf->have_venue_name) {
		capability_info = os_zalloc(sizeof(*capability_info));
		capability_info->info_id = VENUE_NAME_INFO;
		dl_list_add_tail(&conf->anqp_capability_list, &capability_info->list);
	}

	if (conf->have_network_auth_type) {
		capability_info = os_zalloc(sizeof(*capability_info));
		capability_info->info_id = NETWORK_AUTH_TYPE_INFO;
		dl_list_add_tail(&conf->anqp_capability_list, &capability_info->list);
	}

	if (conf->have_roaming_consortium_list) {
		capability_info = os_zalloc(sizeof(*capability_info));
		capability_info->info_id = ROAMING_CONSORTIUM_LIST;
		dl_list_add_tail(&conf->anqp_capability_list, &capability_info->list);
	}

	if (conf->have_ip_address_type) {
		capability_info = os_zalloc(sizeof(*capability_info));
		capability_info->info_id = IP_ADDRESS_TYPE_AVAILABILITY_INFO;
		dl_list_add_tail(&conf->anqp_capability_list, &capability_info->list);
	}

	if (conf->have_nai_realm_list) {
		capability_info = os_zalloc(sizeof(*capability_info));
		capability_info->info_id = NAI_REALM_LIST;
		dl_list_add_tail(&conf->anqp_capability_list, &capability_info->list);
		conf->have_nai_home_realm_query = 1;
	}

	if (conf->have_3gpp_network_info) {
		capability_info = os_zalloc(sizeof(*capability_info));
		capability_info->info_id = ThirdGPP_CELLULAR_NETWORK_INFO;
		dl_list_add_tail(&conf->anqp_capability_list, &capability_info->list);
	}

	if (conf->have_domain_name_list) {
		capability_info = os_zalloc(sizeof(*capability_info));
		capability_info->info_id = DOMAIN_NAME_LIST;
		dl_list_add_tail(&conf->anqp_capability_list, &capability_info->list);
	}

	if (conf->have_advice_of_charge) {
		capability_info = os_zalloc(sizeof(*capability_info));
		capability_info->info_id = ADVICE_OF_CHARGE;
		dl_list_add_tail(&conf->anqp_capability_list, &capability_info->list);
	}

	/* Following are HS2.0 capability list */
	hs_capability_subtype = os_zalloc(sizeof(*hs_capability_subtype));
	hs_capability_subtype->subtype = HS_CAPABILITY;
	dl_list_add_tail(&conf->hs_capability_list, &hs_capability_subtype->list);

	if (conf->have_operator_friendly_name) {
		hs_capability_subtype = os_zalloc(sizeof(*hs_capability_subtype));
		hs_capability_subtype->subtype = OPERATOR_FRIENDLY_NAME;
		dl_list_add_tail(&conf->hs_capability_list, &hs_capability_subtype->list);
	}

	if (conf->have_wan_metrics) {
		hs_capability_subtype = os_zalloc(sizeof(*hs_capability_subtype));
		hs_capability_subtype->subtype = WAN_METRICS;
		dl_list_add_tail(&conf->hs_capability_list, &hs_capability_subtype->list);
	}

	if (conf->have_connection_capability_list) {
		hs_capability_subtype = os_zalloc(sizeof(*hs_capability_subtype));
		hs_capability_subtype->subtype = CONNECTION_CAPABILITY;
		dl_list_add_tail(&conf->hs_capability_list, &hs_capability_subtype->list);
	}

	if (conf->have_nai_realm_list) {
		hs_capability_subtype = os_zalloc(sizeof(*hs_capability_subtype));
		hs_capability_subtype->subtype = NAI_HOME_REALM_QUERY;
		dl_list_add_tail(&conf->hs_capability_list, &hs_capability_subtype->list);
	}

	if (conf->have_operating_class) {
		hs_capability_subtype = os_zalloc(sizeof(*hs_capability_subtype));
		hs_capability_subtype->subtype = OPERATING_CLASS;
		dl_list_add_tail(&conf->hs_capability_list, &hs_capability_subtype->list);
	}

	if (conf->have_osu_providers_list) {
		hs_capability_subtype = os_zalloc(sizeof(*hs_capability_subtype));
		hs_capability_subtype->subtype = OSU_PROVIDE_LIST;
		dl_list_add_tail(&conf->hs_capability_list, &hs_capability_subtype->list);
	}

	if (conf->have_anonymous_nai) {
		hs_capability_subtype = os_zalloc(sizeof(*hs_capability_subtype));
		hs_capability_subtype->subtype = ANONYMOUS_NAI;
		dl_list_add_tail(&conf->hs_capability_list, &hs_capability_subtype->list);
	}

	if (conf->have_osu_providers_list) {
		hs_capability_subtype = os_zalloc(sizeof(*hs_capability_subtype));
		hs_capability_subtype->subtype = ICON_REQUEST;
		dl_list_add_tail(&conf->hs_capability_list, &hs_capability_subtype->list);

		hs_capability_subtype = os_zalloc(sizeof(*hs_capability_subtype));
		hs_capability_subtype->subtype = ICON_BINARY_FILE;
		dl_list_add_tail(&conf->hs_capability_list, &hs_capability_subtype->list);
	}

	dl_list_add_tail(&wapp->conf_list, &conf->list);

	ret = fclose(file);
	if (ret != 0) {
		err(DEBUG_CAT_INIT, "fclose fail\n");
		goto error1;
	}
	if (wapp->wapp_default_config == NULL)
		wapp->wapp_default_config = conf;

	/* WNM feature: Set interworking capability to driver */
	if (wapp->drv_mode == WEXT) {
		wapp_set_interworking_enable(wapp, conf->iface, (char *)&conf->interworking);
		/* Set parameter to driver */
		if (conf->interworking)
			ret = wapp_init_param_setting(wapp, conf);
	}

error1:
	if (IsAOCData)
		os_free(charge_data);
	if (IsNAIRealmData)
		os_free(realm_data);
	if (IsPLMN)
		os_free(plmn_unit);
	if (IsProtoPort)
		os_free(proto_port_unit);
	if (plan_tuple_data != NULL)
		os_free(plan_tuple_data);

	return ret;

error:
	if (file) {
		ret = fclose(file);
		if (ret != 0)
			err(DEBUG_CAT_MISC, "fclose fail\n");
	}
	if (conf)
		os_free(conf);
	return -1;
}

static int wapp_init_sta_config(struct wifi_app *wapp, const char *confname)
{
	int ret = 0;
	FILE *file;
	char buf[256], *pos, *token, *endptr = NULL;
	char tmpbuf[256], tmp1buf[256], tmp2buf[256];
	int line = 0, i;
	struct wapp_conf *conf;
	int query_id;
	int tmp = 0;
	long val = 0;

	os_memset(buf, 0, 256);
	os_memset(tmpbuf, 0, 256);
	os_memset(tmp1buf, 0, 256);
	os_memset(tmp2buf, 0, 256);

	conf = os_zalloc(sizeof(struct wapp_conf));
	if (!conf) {
		err(DEBUG_CAT_MISC, "alloc struct wapp_conf fail\n");
		return -1;
	}

	/* Following are 802.11u element list */
	dl_list_init(&conf->anqp_capability_list);
	dl_list_init(&conf->venue_name_list);
	dl_list_init(&conf->emergency_call_number_list);
	dl_list_init(&conf->network_auth_type_list);
	dl_list_init(&conf->oi_duple_list);
	dl_list_init(&conf->nai_realm_list);
	dl_list_init(&conf->plmn_list);
	dl_list_init(&conf->domain_name_list);

	/* Following are HS2.0 elemets list */
	dl_list_init(&conf->hs_capability_list);
	dl_list_init(&conf->operator_friendly_duple_list);
	dl_list_init(&conf->connection_capability_list);
	dl_list_init(&conf->nai_home_realm_name_query_list);

	file = fopen(confname, "r");
	if (!file) {
		err(DEBUG_CAT_INIT, "fopen fail; errno=%s\n", strerror(errno));
		goto error;
	}

	while (wapp_config_get_line(buf, sizeof(buf), file, &line, &pos)) {
		(void)os_snprintf(tmpbuf, sizeof(tmpbuf), "%s", pos);
		token = strtok(pos, "=");
		if (token != NULL) {
			if (os_strcmp(token, "interface") == 0) {
				token = strtok(NULL, "");
				if (!token) {
					warn(DEBUG_CAT_INIT, "strtok fail\n");
					continue;
				}
				tmp = os_snprintf(conf->iface, sizeof(conf->iface), "%s", token);
				if (os_snprintf_error(sizeof(conf->iface), tmp)) {
					warn(DEBUG_CAT_INIT, "os_snprintf fail\n");
					continue;
				}
			} else if (os_strcmp(token, "hs_peer_mac") == 0) {
				i = 0;
				token = strtok(NULL, ":");
				while (token != NULL) {
					if (i >= 0 && i < MAC_ADDR_LEN)
						AtoH(token, &conf->hs_peer_mac[i], 1);
					i++;
					token = strtok(NULL, ":");
				}
			} else if (os_strcmp(token, "ANQPQueryID") == 0) {
				token = strtok(NULL, ";");
				while (token != NULL) {
					char *endptr;
					long query_id = strtol(token, &endptr, 10);

					if (*endptr != '\0' || query_id < INT_MIN || query_id > INT_MAX) {
						token = strtok(NULL, ";");
						continue;
					}
					switch ((int)query_id) {
					case ANQP_CAPABILITY:
						conf->query_anqp_capability_list = 1;
						break;
					case VENUE_NAME_INFO:
						conf->query_venue_name = 1;
						break;
					case EMERGENCY_CALL_NUMBER_INFO:
						conf->query_emergency_call_number = 1;
						break;
					case NETWORK_AUTH_TYPE_INFO:
						conf->query_network_auth_type = 1;
						break;
					case ROAMING_CONSORTIUM_LIST:
						conf->query_roaming_consortium_list = 1;
						break;
					case IP_ADDRESS_TYPE_AVAILABILITY_INFO:
						conf->query_ip_address_type = 1;
						break;
					case NAI_REALM_LIST:
						conf->query_nai_realm_list = 1;
						break;
					case ThirdGPP_CELLULAR_NETWORK_INFO:
						conf->query_3gpp_network_info = 1;
						break;
					case AP_GEOSPATIAL_LOCATION:
						conf->query_ap_geospatial_location = 1;
						break;
					case AP_CIVIC_LOCATION:
						conf->query_ap_civic_location = 1;
						break;
					case AP_LOCATION_PUBLIC_IDENTIFIER_URI:
						conf->query_ap_location_public_uri = 1;
						break;
					case DOMAIN_NAME_LIST:
						conf->query_domain_name_list = 1;
						break;
					case EMERGENCY_ALERT_IDENTIFIER_URI:
						conf->query_emergency_alert_uri = 1;
						break;
					case EMERGENCY_NAI:
						conf->query_emergency_nai = 1;
						break;
					default:
						err(DEBUG_CAT_INIT, "Unknown QueryID\n");
						break;
					}
					token = strtok(NULL, ";");
				}
			} else if (os_strcmp(token, "ANQPQueryType") == 0) {
				token = strtok(NULL, ";");
				if (token != NULL) {
					char *endptr;
					long val = 0;

					errno = 0;
					val = strtol(token, &endptr, 10);
					if (*endptr != '\0' || errno == ERANGE || val > INT_MAX || val < INT_MIN)
						err(DEBUG_CAT_INIT, "strtol fail\n");
					else
						conf->anqp_req_type = val;
				}
			} else if (os_strcmp(token, "HSANQPQueryID") == 0) {
				token = strtok(NULL, ";");
				while (token != NULL) {
					errno = 0;
					val = strtol(token, &endptr, 10);
					if (errno == ERANGE || *endptr != '\0' || val < INT_MIN || val > INT_MAX) {
						err(DEBUG_CAT_INIT, "strtol fail\n");
					} else {
						query_id = (int)val;
						switch (query_id) {
						case HS_CAPABILITY:
							conf->query_hs_capability_list = 1;
							break;
						case OPERATOR_FRIENDLY_NAME:
							conf->query_operator_friendly_name = 1;
							break;
						case WAN_METRICS:
							conf->query_wan_metrics = 1;
							break;
						case CONNECTION_CAPABILITY:
							conf->query_connection_capability_list = 1;
							break;
						case NAI_HOME_REALM_QUERY:
							conf->query_nai_home_realm = 1;
							break;
						default:
							err(DEBUG_CAT_INIT, "Unknown HS2.0 QueryID\n");
							break;
						}
					}
					token = strtok(NULL, ";");
				}
			}
		}
	}

	dl_list_add_tail(&wapp->conf_list, &conf->list);

	ret = fclose(file);
	if (ret != 0)
		err(DEBUG_CAT_INIT, "fclose fail\n");
	return ret;

error:
	os_free(conf);
	return -1;
}

int wapp_init_all_config(struct wifi_app *wapp, const char *confname)
{
	FILE *file;
	char buf[256], *pos, *token, *tokentmp;
	int line = 0, ret = 0;
	int tmp = 0;

	notice(DEBUG_CAT_INIT, "conf_file=%s\n", confname);

	os_memset(buf, 0, 256);
	file = fopen(confname, "r");
	if (!file) {
		err(DEBUG_CAT_INIT, "fopen fail; errno=%s\n", strerror(errno));
		return -1;
	}

	wapp->wapp_default_config = NULL;
	dl_list_init(&wapp->conf_list);
	while (wapp_config_get_line(buf, sizeof(buf), file, &line, &pos)) {
		token = strtok(pos, "=");
		if (token != NULL) {
			if (os_strcmp(token, "conf_list") == 0) {
				token = strtok(NULL, ";");
				while (token != NULL) {
					tokentmp = token + os_strlen(token) + 1;
					if (wapp->opmode == OPMODE_STA) {
						ret = wapp_init_sta_config(wapp, token);
						if (ret == -1) {
							err(DEBUG_CAT_INIT, "wapp_init_sta_config fail\n");
							goto error;
						}

					} else {
						ret = wapp_init_ap_config(wapp, token);
						if (ret == -1) {
							err(DEBUG_CAT_INIT, "wapp_init_ap_config fail\n");
							goto error;
						}
					}
					token = strtok(tokentmp, ";");
				}
			}
		}
	}

	/* init location IE */
	os_memset(wapp->hs->civic_IE, 0, LOCATION_IE_LEN);
	wapp->hs->civic_IE_len = 0;
	os_memset(wapp->hs->lci_IE, 0, LOCATION_IE_LEN);
	wapp->hs->lci_IE_len = 0;
	os_memset(wapp->hs->public_id_uri, 0, LOCATION_IE_LEN);
	wapp->hs->public_id_uri_len = 0;

error:
	tmp = fclose(file);
	if (tmp != 0) {
		err(DEBUG_CAT_INIT, "fclose fail\n");
		return tmp;
	}
	return ret;
}

int wapp_deinit_config(struct wifi_app *wapp, struct wapp_conf *conf)
{
	int ret = 0;

	if (conf->have_anqp_capability_list) {
		struct anqp_capability *capability_info, *capability_info_tmp;
		dl_list_for_each_safe(capability_info, capability_info_tmp, &conf->anqp_capability_list, struct anqp_capability, list)
		{
			dl_list_del(&capability_info->list);
			os_free(capability_info);
		}
	}

	if (conf->have_venue_name) {
		struct venue_name_duple *vname_duple, *vname_duple_tmp;
		dl_list_for_each_safe(vname_duple, vname_duple_tmp, &conf->venue_name_list, struct venue_name_duple, list)
		{
			dl_list_del(&vname_duple->list);
			os_free(vname_duple);
		}
	}

	if (conf->have_roaming_consortium_list) {
		struct oi_duple *oiduple, *oiduple_tmp;
		dl_list_for_each_safe(oiduple, oiduple_tmp, &conf->oi_duple_list, struct oi_duple, list)
		{
			dl_list_del(&oiduple->list);
			os_free(oiduple);
		}
	}

	if (conf->have_nai_realm_list) {
		struct nai_realm_data *nai_realm, *nai_realm_tmp;
		struct eap_method *eapmethod, *eapmethod_tmp;
		struct auth_param *authparam, *authparam_tmp;
		dl_list_for_each_safe(nai_realm, nai_realm_tmp, &conf->nai_realm_list, struct nai_realm_data, list)
		{
			dl_list_del(&nai_realm->list);
			dl_list_for_each_safe(eapmethod, eapmethod_tmp, &nai_realm->eap_method_list, struct eap_method, list)
			{
				dl_list_del(&eapmethod->list);
				dl_list_for_each_safe(authparam, authparam_tmp, &eapmethod->auth_param_list, struct auth_param, list)
				{
					dl_list_del(&authparam->list);
					os_free(authparam);
				}

				os_free(eapmethod);
			}
			os_free(nai_realm);
		}
	}

	if (conf->have_3gpp_network_info) {
		struct plmn *plmn_unit, *plmn_unit_tmp;
		dl_list_for_each_safe(plmn_unit, plmn_unit_tmp, &conf->plmn_list, struct plmn, list)
		{
			dl_list_del(&plmn_unit->list);
			os_free(plmn_unit);
		}
	}

	if (conf->have_domain_name_list) {
		struct domain_name_field *dname_field, *dname_field_tmp;
		dl_list_for_each_safe(dname_field, dname_field_tmp, &conf->domain_name_list, struct domain_name_field, list)
		{
			dl_list_del(&dname_field->list);
			os_free(dname_field);
		}
	}

	if (conf->have_network_auth_type) {
		struct net_auth_type_unit *auth_type_unit, *auth_type_unit_tmp;
		dl_list_for_each_safe(auth_type_unit, auth_type_unit_tmp, &conf->network_auth_type_list, struct net_auth_type_unit, list)
		{
			dl_list_del(&auth_type_unit->list);
			os_free(auth_type_unit);
		}
	}

	/* Following are hotspot2.0 elements */
	if (conf->have_hs_capability_list) {
		struct anqp_hs_capability *hs_capability_subtype, *hs_capability_subtype_tmp;
		dl_list_for_each_safe(hs_capability_subtype, hs_capability_subtype_tmp, &conf->hs_capability_list,
				      struct anqp_hs_capability, list)
		{
			dl_list_del(&hs_capability_subtype->list);
			os_free(hs_capability_subtype);
		}
	}

	if (conf->have_operator_friendly_name) {
		struct operator_name_duple *op_name_duple, *op_name_duple_tmp;
		dl_list_for_each_safe(op_name_duple, op_name_duple_tmp, &conf->operator_friendly_duple_list, struct operator_name_duple,
				      list)
		{
			dl_list_del(&op_name_duple->list);
			os_free(op_name_duple);
		}
	}

	if (conf->have_connection_capability_list) {
		struct proto_port_tuple *proto_port, *proto_port_tmp;
		dl_list_for_each_safe(proto_port, proto_port_tmp, &conf->connection_capability_list, struct proto_port_tuple, list)
		{
			dl_list_del(&proto_port->list);
			os_free(proto_port);
		}
	}

	if (conf->have_operating_class) {
		struct operating_class_unit *operating_class, *operating_class_tmp;
		dl_list_for_each_safe(operating_class, operating_class_tmp, &conf->operating_class_list, struct operating_class_unit, list)
		{
			dl_list_del(&operating_class->list);
			os_free(operating_class);
		}
	}

	if (conf->have_osu_providers_list) {
		struct osu_providers *providers_list, *providers_list_tmp;
		struct osu_friendly_name *friendly_name_list, *friendly_name_list_tmp;
		struct osu_method *method_list, *method_list_tmp;
		struct icon_available *icon_list, *icon_list_tmp;
		struct osu_nai *nai_list, *nai_list_tmp;
		struct osu_service_desc *service_desc_list, *service_desc_list_tmp;

		dl_list_for_each_safe(providers_list, providers_list_tmp, &conf->osu_providers_list, struct osu_providers, list)
		{
			dl_list_del(&providers_list->list);

			dl_list_for_each_safe(friendly_name_list, friendly_name_list_tmp, &providers_list->osu_friendly_name_list,
					      struct osu_friendly_name, list)
			{
				dl_list_del(&friendly_name_list->list);
				os_free(friendly_name_list);
			}

			dl_list_for_each_safe(method_list, method_list_tmp, &providers_list->osu_method_list, struct osu_method, list)
			{
				dl_list_del(&method_list->list);
				os_free(method_list);
			}

			dl_list_for_each_safe(icon_list, icon_list_tmp, &providers_list->icon_list, struct icon_available, list)
			{
				dl_list_del(&icon_list->list);
				os_free(icon_list);
			}

			dl_list_for_each_safe(nai_list, nai_list_tmp, &providers_list->osu_nai_list, struct osu_nai, list)
			{
				dl_list_del(&nai_list->list);
				os_free(nai_list);
			}

			dl_list_for_each_safe(service_desc_list, service_desc_list_tmp, &providers_list->osu_service_desc_list,
					      struct osu_service_desc, list)
			{
				dl_list_del(&service_desc_list->list);
				os_free(service_desc_list);
			}

			if (providers_list->osu_server_uri_len != 0)
				os_free(providers_list->osu_server_uri);

			os_free(providers_list);
		}
	}

	if (conf->have_osu_providers_nai_list) {
		struct osu_providers_nai_duple *osu_prov_nai_duple, *osu_prov_nai_duple_tmp;
		dl_list_for_each_safe(osu_prov_nai_duple, osu_prov_nai_duple_tmp, &conf->osu_providers_nai_duple_list,
				      struct osu_providers_nai_duple, list)
		{
			dl_list_del(&osu_prov_nai_duple->list);
			os_free(osu_prov_nai_duple);
		}
	}

	if (conf->have_icon_metadata) {
		struct operator_icon_metadata *oim_data, *oim_data_tmp;
		dl_list_for_each_safe(oim_data, oim_data_tmp, &conf->icon_metadata_list, struct operator_icon_metadata, list)
		{
			dl_list_del(&oim_data->list);
			os_free(oim_data);
		}
	}

	if (conf->have_anonymous_nai)
		os_free(conf->anonymous_nai);

	if (conf->have_iconfile_path)
		os_free(conf->iconfile_path);

	if (conf->have_session_info_url)
		os_free(conf->session_info_url);

	if (conf->have_t_c_filename)
		os_free(conf->t_c_filename);

	if (conf->have_t_c_server_url)
		os_free(conf->t_c_server_url);

	if (conf->have_t_c_timestamp)
		os_free(conf->t_c_timestamp);

	if (conf->have_bss_transition_candi_list) {
		struct bss_transition_candi_preference_unit *preference_unit, *preference_unit_tmp;
		dl_list_for_each_safe(preference_unit, preference_unit_tmp, &conf->bss_transition_candi_list,
				      struct bss_transition_candi_preference_unit, list)
		{
			dl_list_del(&preference_unit->list);
			os_free(preference_unit);
		}
	}

	if (conf->have_venue_url) {
		struct venue_url_duple *vurl_duple, *vurl_duple_tmp;
		dl_list_for_each_safe(vurl_duple, vurl_duple_tmp, &conf->venue_url_list, struct venue_url_duple, list)
		{
			dl_list_del(&vurl_duple->list);
			os_free(vurl_duple);
		}
	}

	if (conf->have_advice_of_charge) {
		struct advice_of_charge_data *charge_data, *charge_data_tmp;
		struct aoc_plan_tuple_data *plan_tuple_data, *plan_tuple_data_tmp;
		dl_list_for_each_safe(charge_data, charge_data_tmp, &conf->advice_of_charge_list, struct advice_of_charge_data, list)
		{
			dl_list_del(&charge_data->list);
			dl_list_for_each_safe(plan_tuple_data, plan_tuple_data_tmp, &charge_data->aoc_plan_tuples_list,
					      struct aoc_plan_tuple_data, list)
			{
				dl_list_del(&plan_tuple_data->list);
				os_free(plan_tuple_data);
			}
			os_free(charge_data);
		}
	}

	if (conf->have_time_zone)
		os_free(conf->time_zone);

	return ret;
}

int wapp_deinit_all_config(struct wifi_app *wapp)
{
	struct wapp_conf *conf, *conf_tmp;
#ifdef MAP_SUPPORT
	struct air_monitor_query_rsp *mntr, *mntr_tmp;
	struct sta_mnt_stat *sta_stat, *sta_stat_tmp;
	struct bh_link *bh_links = NULL, *bh_links_tmp = NULL;
#endif

	dl_list_for_each_safe(conf, conf_tmp, &wapp->conf_list, struct wapp_conf, list)
	{
		wapp_deinit_config(wapp, conf);
		dl_list_del(&conf->list);
		os_free(conf);
	}
#ifdef MAP_SUPPORT
	dl_list_for_each_safe(mntr, mntr_tmp, &wapp->air_monitor_query_list, struct air_monitor_query_rsp, list)
	{
		dl_list_del(&mntr->list);
		os_free(mntr);
	}

	dl_list_for_each_safe(sta_stat, sta_stat_tmp, &wapp->sta_mntr_list, struct sta_mnt_stat, list)
	{
		dl_list_del(&sta_stat->list);
		os_free(sta_stat);
	}

	if (!dl_list_empty(&(wapp->map->bh_link_list))) {
		dl_list_for_each_safe(bh_links, bh_links_tmp, &wapp->map->bh_link_list, struct bh_link, list)
		{
			dl_list_del(&bh_links->list);
			os_free(bh_links);
		}
	}
	wapp->map->bh_link_num = 0;
#endif
	if (wapp->map_wapp_buffer) {
		os_free(wapp->map_wapp_buffer);
		wapp->map_wapp_buffer = NULL;
	}

#ifdef EM_PLUS_SUPPORT
	//Clear up and relased the lock
	wapp->lock_fl.l_type = F_UNLCK;
	fcntl(wapp->lock_fd, F_SETLK, &wapp->lock_fl);
	close(wapp->lock_fd);
#endif /* EM_PLUS_SUPPORT */
	return 0;
}

int wapp_set_ie(struct wifi_app *wapp, const char *iface, char *ie, size_t ie_len)
{
	int ret = 0;

	ret = wapp->drv_ops->drv_set_ie(wapp->drv_data, iface, ie, ie_len);

	return ret;
}

u8 wapp_aquire_card_id(struct wifi_app *wapp, u32 adpt_id)
{
	u8 i = 0, max_card_id = 0, new_card_id = 0;
	struct wapp_radio *ra = NULL;

	/* base on the fact that each card have its own adpt_id */
	for (i = 0; i < MAX_NUM_OF_RADIO; i++) {
		/* check if adpt exsits */
		ra = &wapp->radio[i];
		if (ra->adpt_id != 0) {
			if (ra->adpt_id == adpt_id)
				/* adpt exist, return the card id */
				return ra->card_id;
			else
				/* record the max card_id */
				max_card_id = (ra->card_id > max_card_id) ? ra->card_id : max_card_id;
		}
	}

	new_card_id = (max_card_id + 1);

	/* no existing adpt_id, so this is a new card */
	notice(DEBUG_CAT_MISC, "adpt_id(%u) acquired a new_card_id(%u)\n", adpt_id, new_card_id);

	return new_card_id;
}

struct wapp_radio *wapp_radio_create(struct wifi_app *wapp, u32 adpt_id, u8 ra_id)
{
	u8 i;
	struct wapp_radio *ra = NULL;

	for (i = 0; i < MAX_NUM_OF_RADIO; i++) {
		ra = &wapp->radio[i];
		if (ra->adpt_id == 0) {
			ra->index = i;
			ra->card_id = wapp_aquire_card_id(wapp, adpt_id);
			ra->adpt_id = adpt_id;
			ra->radio_id = ra_id;
			ra->onoff = RADIO_ON;
#ifdef WIFI_MD_COEX_SUPPORT
			ra->operatable = 1;
#endif
			break;
		}
	}

	return ra;
}

#ifdef MAP_RADIO_TEARDOWN
struct wapp_radio *wapp_radio_delete(
	struct wifi_app *wapp,
	char *idtfer)
{
	u8 i;
	struct wapp_radio *ra = NULL;
	u8 idfr[MAC_ADDR_LEN];

	for (i = 0; i < MAX_NUM_OF_RADIO; i++) {
		ra = &wapp->radio[i];
		if (ra->adpt_id) {
			MAP_GET_RADIO_IDNFER(ra, idfr);
			if (!os_memcmp(idfr, idtfer, ETH_ALEN))
				break;
		}
	}
	if (!dl_list_empty(&wapp->dev_list)) {
		struct wapp_dev *wdev = NULL, *wdev_tmp = NULL;

		dl_list_for_each_safe(wdev, wdev_tmp,
				&wapp->dev_list, struct wapp_dev, list) {
			if (wdev->radio) {
				if (ra->radio_band == wdev->radio->radio_band)
					wapp_dev_del(wapp, wdev, wdev->mac_addr, wdev->dev_type);
			}
		}
	}
	os_memset(ra, 0, sizeof(struct wapp_radio));
	return 0;
}
#endif
#ifdef EM_PLUS_SUPPORT
struct wapp_radio *wapp_radio_lookup_by_id(struct wifi_app *wapp, char *ra_identifier)
{
	u8 i;
	struct wapp_radio *ra = NULL;
	struct wapp_radio *tmp_ra = NULL;
	unsigned char wdev_identifier[ETH_ALEN];

	for (i = 0; i < MAX_NUM_OF_RADIO; i++) {
		tmp_ra = &wapp->radio[i];
		if (tmp_ra->adpt_id) {
			MAP_GET_RADIO_IDNFER(tmp_ra, wdev_identifier);
			if (!os_memcmp(wdev_identifier, ra_identifier, ETH_ALEN)) {
				ra = &wapp->radio[i];
				break;
			}
		}
	}

	return ra;
}

int wapp_process_running(struct wifi_app *wapp, const char *lock_file)
{
	int fd;
	struct flock fl;
	char pid_str[10];

	// Open the lock file
	fd = open(lock_file, O_RDWR | O_CREAT);
	if (fd < 0) {
		perror("open");
		return -1;
	}

	// Initialize the flock structure
	fl.l_type = F_WRLCK;   // Write lock
	fl.l_whence = SEEK_SET;
	fl.l_start = 0;
	fl.l_len = 0;          // Lock the whole file

	// Try to acquire the lock
	if (fcntl(fd, F_SETLK, &fl) < 0) {
		if (errno == EACCES || errno == EAGAIN) {
			err(DEBUG_CAT_INIT, "Another instance of the wapp is already running %s\n",
					strerror(errno));
			close(fd);
			return -1;
		}
	}

	// Write the current PID to the lock file
	if (ftruncate(fd, 0) == -1) {
		perror("ftruncate");
		close(fd);
		return -1;
	}
	snprintf(pid_str, sizeof(pid_str), "%d\n", getpid());
	if (write(fd, pid_str, strlen(pid_str)) == -1) {
		perror("write");
		close(fd);
		return -1;
	}

	wapp->lock_fd = fd;
	wapp->lock_fl = fl;
	// The process is now running with the lock acquired
	notice(DEBUG_CAT_INIT, "wapp is running with PID: %d\n", getpid());

	// Keep the lock file descriptor open to maintain the lock
	return 0;
}
#endif
struct wapp_radio *wapp_radio_lookup(struct wifi_app *wapp, u32 adpt_id, u8 ra_id)
{
	u8 i;
	struct wapp_radio *ra = NULL;

	for (i = 0; i < MAX_NUM_OF_RADIO; i++) {
		if (adpt_id == wapp->radio[i].adpt_id && ra_id == wapp->radio[i].radio_id) {
			ra = &wapp->radio[i];
			break;
		}
	}

	return ra;
}

struct wapp_radio *wapp_radio_update_or_create(struct wifi_app *wapp, u32 adpt_id, u8 radio_id)
{
	struct wapp_radio *ra = NULL;

	ra = wapp_radio_lookup(wapp, adpt_id, radio_id);
	if (ra == NULL) {
		ra = wapp_radio_create(wapp, adpt_id, radio_id);
		if (ra == NULL)
			notice(DEBUG_CAT_MISC, "ra table full\n");
		wapp->radio_count++;
	} else {
		ra->adpt_id = adpt_id;
		ra->radio_id = radio_id;
	}

#ifdef DPP_SUPPORT
	/* TODO initialize radio DPP variables here, sepcifically for MAP-R3 */
	ra->ongoing_dpp_cnt = 0;
#endif
	return ra;
}

#ifdef MAP_EHT_SUPPORT
int wapp_radio_update_eht_cap(struct wifi_app *wapp, struct wapp_dev *wdev)
{
	struct wdev_eht_cap eht_cap;

	wapp_get_eht_cap(wapp, wdev->ifname, (char *)&eht_cap, sizeof(struct wdev_eht_cap));

	return WAPP_SUCCESS;
}
#endif
int wapp_radio_update_ch(struct wifi_app *wapp, struct wapp_radio *ra, u8 ch)
{
	ra->op_ch = ch;
#ifdef MAP_SUPPORT
	map_update_radio_band(wapp, ra, ch);
#endif /* MAP_SUPPORT */

	return WAPP_SUCCESS;
}

u8 is_all_zero_mac(u8 *mac_addr)
{
	char all_zero_mac[6] = {0};
	if (NdisCompareMemory(mac_addr, all_zero_mac, ETH_ALEN) == 0)
		return TRUE;
	else
		return FALSE;
}

struct probe_info *wapp_probe_lookup(struct wifi_app *wapp, u8 *mac_addr)
{
	int i;
	struct probe_info *probe = NULL;

	for (i = 0; i < PROBE_TABLE_SIZE; i++) {
		probe = &wapp->probe_entry[i];
		if (NdisCompareMemory(probe->mac_addr, mac_addr, ETH_ALEN) == 0)
			break;
	}

	if (i == PROBE_TABLE_SIZE)
		return NULL;

	return probe;
}

struct probe_info *wapp_probe_create(struct wifi_app *wapp, u8 *mac_addr)
{
	struct probe_info *info;
	int i;
	static u8 oldest_idx;

	for (i = 0; i < PROBE_TABLE_SIZE; i++) {
		if (wapp->probe_entry[i].valid == 0)
			break;
	}

	if (i == PROBE_TABLE_SIZE) {
		info = &wapp->probe_entry[oldest_idx++];
		oldest_idx = oldest_idx % PROBE_TABLE_SIZE;
	} else {
		info = &wapp->probe_entry[i];
	}

	info->valid = 1;
	COPY_MAC_ADDR(info->mac_addr, mac_addr);
	return info;
}

int wapp_cmd_show_probe_info(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	int i, num = 0;
	struct probe_info *info = NULL;

	for (i = 0; i < PROBE_TABLE_SIZE; i++) {
		info = &wapp->probe_entry[i];
		if (info->valid == 1) {
			notice(DEBUG_CAT_MISC,
				 "\n [%d]"
				 "\t mac_addr = " MACSTR "\n"
				 "\t channel = %u\n"
				 "\t rssi = %u\n"
				 "\t last_update_time = %lu Sec\n",
				 num, MAC2STR(info->mac_addr), info->channel, info->rssi, info->last_update_time.sec);
			num++;
		}
	}
	return WAPP_SUCCESS;
}

int wapp_driver_version(struct wifi_app *wapp, const char *iface, char *ver, size_t *len)
{
	int ret;

	ret = wapp->drv_ops->drv_wifi_version(wapp->drv_data, iface, ver, len);

	return ret;
}

void wapp_reset_map_params(struct wifi_app *wapp, struct wapp_dev *wdev)
{
#if WEXT_SUPPORT
	u8 enable = 0;

	wapp_set_map_enable(wapp, (const char *)wdev->ifname, (char *)&enable, 1);
	wapp_set_map_enable(wapp, (const char *)wdev->ifname, (char *)&wapp->map->MapMode, (size_t)sizeof(wapp->map->MapMode));
#else
	int ret = 0;

	ret = wdev_set_map_enable(wapp, wdev, 0);
	if (ret != WAPP_SUCCESS) {
		err(DEBUG_CAT_MISC, "wdev_set_map_enable fail\n");
		return;
	}

	ret = wdev_set_map_enable(wapp, wdev, (const u8)wapp->map->MapMode);
	if (ret != WAPP_SUCCESS) {
		err(DEBUG_CAT_MISC, "wdev_set_map_enable fail\n");
		return;
	}
#endif /* WEXT_SUPPORT */
}

void wapp_soft_reset_scan_states(struct wifi_app *wapp)
{
	struct wapp_dev *wdev = NULL, *wdev_temp = NULL;
	struct dl_list *dev_list;

	dev_list = &wapp->dev_list;
	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list)
	{
		if (!wdev) {
			err(DEBUG_CAT_MISC, "wdev is NULL\n");
			break;
		}
		if (wdev->dev_type == WAPP_DEV_TYPE_STA) {
			notice(DEBUG_CAT_MISC, "attempt disconnection for: %s\n", wdev->ifname);
			notice(DEBUG_CAT_MISC, "trigger disconnection %s\n", wdev->ifname);
			wdev->wps_triggered = FALSE;
			wdev->scan_cookie = 0;
#if WEXT_SUPPORT
			u8 Enable = 0;

			wapp_set_apcli_mode(wapp, (const char *)wdev->ifname, (char *)&Enable, 1);
#else
#ifdef MTK_HOSTAPD_SUPPORT
			if (wapp->drv_ops->drv_send_disable_network)
				wapp->drv_ops->drv_send_disable_network(wapp->drv_data, wdev->ifname, wdev->network_id);
#endif /* MTK_HOSTAPD_SUPPORT */
#endif
		}
	}
}

void wapp_reset_scan_states(struct wifi_app *wapp)
{
	wsc_apcli_config_msg apcli_config_msg;
	struct wapp_dev *wdev = NULL, *wdev_temp = NULL;
	struct dl_list *dev_list;
	int i = 0;

	dev_list = &wapp->dev_list;

	save_map_parameters(wapp, "BhProfile0Valid", "0", NON_DRIVER_PARAM);
	save_map_parameters(wapp, "BhProfile1Valid", "0", NON_DRIVER_PARAM);
	save_map_parameters(wapp, "BhProfile2Valid", "0", NON_DRIVER_PARAM);
	save_map_parameters(wapp, "BhProfile3Valid", "0", NON_DRIVER_PARAM);
	save_map_parameters(wapp, "BhProfile4Valid", "0", NON_DRIVER_PARAM);
	save_map_parameters(wapp, "BhProfile5Valid", "0", NON_DRIVER_PARAM);
	for (i = 0; i < MAX_NUM_OF_RADIO; i++) {
		wapp->map->apcli_configs[i].config_valid = FALSE;
	}

	if (wapp->wsc_save_bh_profile == TRUE)
		apcli_config_msg.profile_count = WSC_APCLI_CONFIG_MSG_SAVE_PROFILE;
	else
		apcli_config_msg.profile_count = 0;

	wapp_send_1905_msg(wapp, WAPP_MAP_BH_CONFIG, sizeof(apcli_config_msg), (void *)&apcli_config_msg);

	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list)
	{
		if (!wdev) {
			err(DEBUG_CAT_MISC, "wdev is NULL\n");
			break;
		}
		if (wdev->dev_type == WAPP_DEV_TYPE_STA) {
			wdev->wps_triggered = FALSE;
			wdev->scan_cookie = 0;
#if WEXT_SUPPORT
			u8 Enable = 0;
			wapp_set_apcli_mode(wapp, (const char *)wdev->ifname, (char *)&Enable, 1);
#else
#ifdef MTK_HOSTAPD_SUPPORT
			if (wapp->drv_ops->drv_send_disable_network)
				wapp->drv_ops->drv_send_disable_network(wapp->drv_data, wdev->ifname, wdev->network_id);
#endif /* MTK_HOSTAPD_SUPPORT */
#endif
			eloop_cancel_timeout(map_get_scan_result, wapp, wdev);
		}
	}

	if (wapp->wsc_save_bh_profile)
		wapp->map->bh_link_ready = 0;
}

void apcli_reset_before_wps(struct wifi_app *wapp)
{
	struct wapp_dev *wdev = NULL, *wdev_temp = NULL;
	struct dl_list *dev_list;

	if (!wapp) {
		err(DEBUG_CAT_MISC, "null wapp\n");
		return;
	}
	dev_list = &wapp->dev_list;
	if (!dl_list_empty(dev_list)) {
		dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list)
		{
			if ((wdev->dev_type == WAPP_DEV_TYPE_APCLI || wdev->dev_type == WAPP_DEV_TYPE_STA)) {
				wdev_bh_sta_reset_default(wapp, wdev);
				continue;
			}
		}
	}
}

int wapp_wps_pbc_trigger(struct wifi_app *wapp, const char *iface, char *ver, size_t *len)
{
#ifdef MAP_SUPPORT
	int ret = TRUE;
	BOOLEAN is_map_device_configured = FALSE;

	wapp_device_status *device_status = &wapp->map->device_status;
	os_memset(device_status, 0, sizeof(wapp_device_status));
	if (!wapp->wps_on_controller_cli) {
		if (wapp->map->bh_link_ready) {
			if (wapp->map->ctrler_found || wapp->map->my_map_dev_role == DEVICE_ROLE_CONTROLLER)
				is_map_device_configured = TRUE;
			else
				return FALSE;
		}
		if (!wapp->map->bh_link_ready && (wapp->map->ctrler_found || wapp->map->my_map_dev_role == DEVICE_ROLE_CONTROLLER))
			is_map_device_configured = TRUE;
	}
	if ((!is_map_device_configured) || (wapp->wps_on_controller_cli)) {
		device_status->status_bhsta = STATUS_BHSTA_WPS_TRIGGERED;
		device_status->status_fhbss = STATUS_FHBSS_UNCONFIGURED;
		if (wapp->map->bh_link_ready)
			wapp->wsc_save_bh_profile = TRUE;
		wapp_reset_scan_states(wapp);
		apcli_reset_before_wps(wapp);
		wapp->wsc_trigger_wdev = wps_ctrl_run_cli_wps(wapp, NULL);
		wapp->map->conf = MAP_CONN_STATUS_UNCONF;
	} else {
		device_status->status_bhsta = STATUS_BHSTA_CONFIGURED;
		device_status->status_fhbss = STATUS_FHBSS_WPS_TRIGGERED;
		if (wapp->map->off_ch_scan_state.ch_scan_state == CH_SCAN_IDLE) {
#ifdef MTK_HOSTAPD_SUPPORT
			wapp->is_mesh_wps_onboarding = TRUE;
			wapp->wps_per_band = 0;
#ifdef MAP_6E_SUPPORT
			wapp->no_wps_on_6G = 0;
#endif
#endif
			wps_ctrl_run_ap_wps(wapp);
		} else {
			wapp->map->wps_after_scan = 1;
			return ret;
		}
	}
#ifndef MTK_HOSTAPD_SUPPORT
	eloop_cancel_timeout(map_wps_timeout, wapp, device_status);
	eloop_register_timeout(WPS_TIMEOUT, 0, map_wps_timeout, wapp, device_status);
#endif /* MTK_HOSTAPD_SUPPORT */
	wapp_send_1905_msg(wapp, WAPP_DEVICE_STATUS, sizeof(wapp_device_status), (char *)device_status);
	return ret;
#else
	return FALSE;
#endif
}

int wapp_set_bh_type_eth(struct wifi_app *wapp, const char *iface, char *ver, size_t *len)
{
	struct map_info *map = wapp->map;
	u8 mac_addr[MAC_ADDR_LEN] = {0};

	notice(DEBUG_CAT_AUTOCONFIG, "\033[1;36m %s = type = %s\033[0m\n", __func__, "eth");

	map->bh_type = MAP_BH_ETH;
	wapp_get_mac_addr_by_ifname(MAP_DEFAULT_ETH_BH, mac_addr);
	if (wapp->map->TurnKeyEnable) {
		struct bh_type_info bh;

		bh.type = MAP_BH_ETH;
		wapp_send_1905_msg(
			wapp,
			WAPP_SET_BH_TYPE,
			sizeof(struct bh_type_info),
			(char *) &bh);
	}
	map_bh_ready(wapp, MAP_BH_ETH, (u8 *) MAP_DEFAULT_ETH_BH, mac_addr, mac_addr
#ifdef MTK_MLO_MAP_SUPPORT
		,
		0,
		NULL
#ifdef MAP_R6
,		NULL
#endif
#endif
);
	return WAPP_SUCCESS;
}

int wapp_drv_support_version_check(struct wifi_app *wapp, const char *iface)
{
	int ret;

	ret = wapp->drv_ops->drv_wapp_version_check(wapp->drv_data, iface);

	return ret;
}

int wapp_get_bss_coex(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;


	ret = wapp->drv_ops->drv_get_bss_coex(wapp->drv_data, iface, buf, &buf_len);

	return ret;
}

int wapp_get_misc_cap(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_get_misc_cap(wapp->drv_data, iface, buf, &buf_len);

	return ret;
}

int wapp_get_ht_cap(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_get_ht_cap(wapp->drv_data, iface, buf, &buf_len);

	return ret;
}

int wapp_get_vht_cap(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_get_vht_cap(wapp->drv_data, iface, buf, &buf_len);

	return ret;
}

int wapp_get_chan_list(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_get_chan_list(wapp->drv_data, iface, buf, &buf_len);

	return ret;
}

int wapp_get_nop_channels(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_get_nop_channels(wapp->drv_data, iface, buf, &buf_len);

	return ret;
}

int wapp_get_op_class(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_get_op_class(wapp->drv_data, iface, buf, &buf_len);

	return ret;
}

int wapp_get_bss_info(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_get_bss_info(wapp->drv_data, iface, buf, &buf_len);

	return ret;
}

int wapp_get_ap_metrics(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_get_ap_metrics(wapp->drv_data, iface, buf, &buf_len);

	return ret;
}

int wapp_get_chip_id(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_get_chip_id(wapp->drv_data, iface, buf, &buf_len);

	return ret;
}

int wapp_get_max_sta_num(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_get_max_sta_num(wapp->drv_data, iface, buf, &buf_len);

	return ret;
}

int wapp_get_assoc_req_frame(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	if (wapp->drv_ops->drv_get_assoc_req_frame)
		return wapp->drv_ops->drv_get_assoc_req_frame(wapp->drv_data, iface, buf, buf_len);

	return -1;
}

#if WEXT_SUPPORT
int wapp_set_authtype(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_set_authtype(wapp->drv_data, iface, buf, buf_len);

	return ret;
}

int wapp_set_htbw(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_set_htbw(wapp->drv_data, iface, buf, &buf_len);

	return ret;
}

int wapp_set_key1(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_set_key1(wapp->drv_data, iface, buf, &buf_len);

	return ret;
}

int wapp_set_map_channel(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_set_map_channel(wapp->drv_data, iface, buf, &buf_len);

	return ret;
}

int wapp_set_channel(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_set_channel(wapp->drv_data, iface, buf, &buf_len);

	return ret;
}

int wapp_set_map_channel_enable(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_set_map_channel_enable(wapp->drv_data, iface, buf, &buf_len);

	return ret;
}

int wapp_set_map_enable(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_set_map_enable(wapp->drv_data, iface, buf, &buf_len);

	return ret;
}
#endif /* WEXT_SUPPORT */
int wapp_set_anqp_elem(struct wifi_app *wapp, const char *iface, int id, u8 *buf, size_t buf_len)
{
	int ret = -1;

	if (wapp->drv_ops->drv_set_anqp_elem)
		ret = wapp->drv_ops->drv_set_anqp_elem(wapp->drv_data, iface, id, buf, buf_len);

	return ret;
}

int wapp_set_pmfmfpc(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret = -1;

	if (wapp->drv_ops->drv_set_pmfmfpc)
		ret = wapp->drv_ops->drv_set_pmfmfpc(wapp->drv_data, iface, buf, buf_len);

	return ret;
}

#ifdef WEXT_SUPPORT
int wapp_set_radio_on(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_set_radio_on(wapp->drv_data, iface, buf, &buf_len);

	return ret;
}

int wapp_set_ts_bh_primary_vid(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_set_ts_bh_primary_vid(wapp->drv_data, iface, buf, &buf_len);

	return ret;
}

int wapp_set_ts_bh_primary_pcp(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_set_ts_bh_primary_pcp(wapp->drv_data, iface, buf, &buf_len);

	return ret;
}

int wapp_set_vhtbw(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_set_vhtbw(wapp->drv_data, iface, buf, &buf_len);

	return ret;
}

int wapp_set_v10converter(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_set_v10converter(wapp->drv_data, iface, buf, &buf_len);

	return ret;
}

int wapp_set_wsc_stop(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_set_wsc_stop(wapp->drv_data, iface, buf, &buf_len);

	return ret;
}

int wapp_set_wsc_conf_mode(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_set_wsc_conf_mode(wapp->drv_data, iface, buf, &buf_len);

	return ret;
}

int wapp_set_wsc_mode(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_set_wsc_mode(wapp->drv_data, iface, buf, &buf_len);

	return ret;
}

int wapp_set_wsc_get_conf(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_set_wsc_get_conf(wapp->drv_data, iface, buf, &buf_len);

	return ret;
}

int wapp_set_wsc_conf_status(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_set_wsc_conf_status(wapp->drv_data, iface, buf, &buf_len);

	return ret;
}

int wapp_set_apcli_mode(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_set_apcli_mode(wapp->drv_data, iface, buf, buf_len);

	return ret;
}

int wapp_set_autoroam(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_set_autoroam(wapp->drv_data, iface, buf, buf_len);

	return ret;
}

int wapp_set_bssid(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_set_bssid(wapp->drv_data, iface, buf, buf_len);

	return ret;
}

int wapp_set_APproxy_refresh(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_set_APproxy_refresh(wapp->drv_data, iface, buf, buf_len);

	return ret;
}

int wapp_set_auth_mode(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_set_auth_mode(wapp->drv_data, iface, buf, buf_len);

	return ret;
}

int wapp_set_apcli_ssid(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_set_apcli_ssid(wapp->drv_data, iface, buf, buf_len);

	return ret;
}

int wapp_set_apcli_wpapsk(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_set_apcli_wpapsk(wapp->drv_data, iface, buf, buf_len);

	return ret;
}
#endif /* WEXT_SUPPORT */
int wapp_set_apcli_PMFMFPC(struct wifi_app *wapp, const char *iface, int network_id, char *buf, size_t buf_len)
{
	int ret = -1;

	if (wapp->drv_ops->drv_set_apcli_PMFMFPC)
		ret = wapp->drv_ops->drv_set_apcli_PMFMFPC(wapp->drv_data, iface, network_id, buf, buf_len);

	return ret;
}

int wapp_set_apcli_dpp_pfs(struct wifi_app *wapp, const char *iface, int network_id, int value)
{
	int ret = -1;

	if (wapp->drv_ops->drv_set_apcli_dpp_pfs)
		ret = wapp->drv_ops->drv_set_apcli_dpp_pfs(wapp->drv_data, iface, network_id, value);

	return ret;
}

#ifdef WEXT_SUPPORT
int wapp_set_apcli_EncrypType(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_set_apcli_EncrypType(wapp->drv_data, iface, buf, buf_len);

	return ret;
}

int wapp_set_EncrypType(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_set_EncrypType(wapp->drv_data, iface, buf, buf_len);

	return ret;
}
#endif /* WEXT_SUPPORT */
int wapp_set_ACLAddEntry(struct wifi_app *wapp, const char *iface, u8 *buf, size_t buf_len)
{
	int ret = -1;

	if (wapp->drv_ops->drv_set_ACLAddEntry)
		ret = wapp->drv_ops->drv_set_ACLAddEntry(wapp->drv_data, iface, buf, buf_len);

	return ret;
}

int wapp_set_ACLDelEntry(struct wifi_app *wapp, const char *iface, u8 *buf, size_t buf_len)
{
	int ret = -1;

	if (wapp->drv_ops->drv_set_ACLDelEntry)
		ret = wapp->drv_ops->drv_set_ACLDelEntry(wapp->drv_data, iface, buf, buf_len);

	return ret;
}

int wapp_set_ACLClearAll(struct wifi_app *wapp, const char *iface, u8 *buf, size_t buf_len)
{
	int ret = -1;

	if (wapp->drv_ops->drv_set_ACLClearAll)
		ret = wapp->drv_ops->drv_set_ACLClearAll(wapp->drv_data, iface, buf, buf_len);

	return ret;
}

int wapp_set_AccessPolicy(struct wifi_app *wapp, const char *iface, u8 *buf, size_t buf_len)
{
	int ret = -1;

	if (wapp->drv_ops->drv_set_AccessPolicy)
		ret = wapp->drv_ops->drv_set_AccessPolicy(wapp->drv_data, iface, buf, buf_len);

	return ret;
}

int wapp_set_BlAdd(struct wifi_app *wapp, const char *iface, u8 *buf, size_t buf_len)
{
	int ret = -1;

	if (wapp->drv_ops->drv_set_BLAdd)
		ret = wapp->drv_ops->drv_set_BLAdd(wapp->drv_data, iface, buf, buf_len);

	return ret;
}

int wapp_set_BlDel(struct wifi_app *wapp, const char *iface, u8 *buf, size_t buf_len)
{
	int ret = -1;

	if (wapp->drv_ops->drv_set_BLDel)
		ret = wapp->drv_ops->drv_set_BLDel(wapp->drv_data, iface, buf, buf_len);

	return ret;
}

#ifdef WEXT_SUPPORT
int wapp_set_apcli_AutoConnect(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_set_AutoConnect(wapp->drv_data, iface, buf, buf_len);

	return ret;
}

int wapp_set_BlAdd(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_set_BLAdd(wapp->drv_data, iface, buf, buf_len);

	return ret;
}

int wapp_set_BlDel(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_set_BLDel(wapp->drv_data, iface, buf, buf_len);

	return ret;
}

int wapp_set_bhbss(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_set_bhbss(wapp->drv_data, iface, buf, buf_len);

	return ret;
}

int wapp_set_DppEnable(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_set_DppEnable(wapp->drv_data, iface, buf, buf_len);

	return ret;
}

int wapp_set_DisConnectSta(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_set_DisConnectSta(wapp->drv_data, iface, buf, buf_len);

	return ret;
}

int wapp_set_DisConnectAllSta(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_set_DisConnectAllSta(wapp->drv_data, iface, buf, buf_len);

	return ret;
}

int wapp_set_fhbss(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_set_fhbss(wapp->drv_data, iface, buf, buf_len);

	return ret;
}

int wapp_set_HtBssCoex(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_set_HtBssCoex(wapp->drv_data, iface, buf, buf_len);

	return ret;
}

int wapp_set_HideSSID(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_set_HideSSID(wapp->drv_data, iface, buf, buf_len);

	return ret;
}

int wapp_set_BcnReq(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_set_BcnReq(wapp->drv_data, iface, buf, buf_len);

	return ret;
}

int wapp_set_mnt_en(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_set_mnt_en(wapp->drv_data, iface, buf, buf_len);

	return ret;
}

int wapp_set_mnt_rule(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_set_mnt_rule(wapp->drv_data, iface, buf, buf_len);

	return ret;
}

int wapp_set_mnt_sta0(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_set_mnt_sta0(wapp->drv_data, iface, buf, buf_len);

	return ret;
}

int wapp_set_ts_bh_vid(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_set_ts_bh_vid(wapp->drv_data, iface, buf, buf_len);

	return ret;
}

int wapp_set_ts_fh_vid(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_set_ts_fh_vid(wapp->drv_data, iface, buf, buf_len);

	return ret;
}

int wapp_set_transparent_vid(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_set_transparent_vid(wapp->drv_data, iface, buf, buf_len);

	return ret;
}
#endif /* WEXT_SUPPORT */

int wapp_set_scan_BH_ssids(struct wifi_app *wapp, struct wapp_dev *wdev, struct scan_BH_ssids *scan_ssids)
{
	int ret;
	struct wapp_req req;

	os_memset(&req, 0, sizeof(struct wapp_req));
	if (!wapp || !wdev) {
		return WAPP_INVALID_ARG;
	}
	req.req_id = WAPP_SET_SCAN_BH_SSIDS;
	req.data.ifindex = wdev->ifindex;
	os_memcpy(&req.data.scan_bh_ssids, scan_ssids, sizeof(struct scan_BH_ssids));
	ret = wapp_req_send(wapp, wdev->ifname, &req);
	return ret;
}

int wapp_create_arp_socket(struct wifi_app *wapp)
{
	struct br_dev *pbr = NULL;
	struct wapp_dev *wdev = NULL, *wdev_temp = NULL;
	int ret = -1, err = 0;
	/*create arp socket for bridge */
	pbr = &wapp->map->br;
	err = get_if_info(wapp->map->br_iface, &pbr->ip, pbr->mac_addr, &pbr->ifindex);
	if (err < 0) {
		if (err == -2) {
			warn(DEBUG_CAT_INIT, "get ip for %s fail; continue\n", wapp->map->br_iface);
		} else {
			err(DEBUG_CAT_INIT, "get_if_info for %s fail\n", wapp->map->br_iface);
			goto out;
		}
	}
	pbr->arp_sock = 0;
	if (bind_arp(pbr->ifindex, &pbr->arp_sock)) {
		err(DEBUG_CAT_INIT, "bind_arp for %s fail\n", wapp->map->br_iface);
		goto out;
	}

	/*create arp socket for wifi interface */
	dl_list_for_each_safe(wdev, wdev_temp, &wapp->dev_list, struct wapp_dev, list)
	{
		wdev->arp_sock = 0;
		if (bind_arp(wdev->ifindex, &wdev->arp_sock)) {
			err(DEBUG_CAT_INIT, "bind_arp for %s fail\n", wdev->ifname);
			goto out;
		}
	}

	ret = 0;
out:
	if (ret) {
		if (pbr->arp_sock > 0)
			close(pbr->arp_sock);
		wdev_temp = NULL;
		dl_list_for_each_safe(wdev, wdev_temp, &wapp->dev_list, struct wapp_dev, list)
		{
			if (wdev->arp_sock > 0)
				close(wdev->arp_sock);
		}
	}
	return ret;
}

int wapp_set_AvoidScanDuringCAC(struct wifi_app *wapp, struct wapp_dev *wdev, unsigned char enable)
{
	int ret;
	struct wapp_req req;

	if (!wapp || !wdev)
		return WAPP_INVALID_ARG;
	req.req_id = WAPP_SET_AVOID_SCAN_CAC;
	req.data.ifindex = wdev->ifindex;
	req.data.value = enable;
	ret = wapp_req_send(wapp, wdev->ifname, &req);
	return ret;
}

int wapp_get_he_cap(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_get_he_cap(wapp->drv_data, iface, buf, &buf_len);

	return ret;
}
#ifdef MAP_EHT_SUPPORT
int wapp_get_eht_cap(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_get_eht_cap(wapp->drv_data, iface, buf, &buf_len);

	return ret;
}
#endif
#ifdef MTK_MLO_MAP_SUPPORT
int wapp_get_mlo_cap(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_get_mlo_cap(wapp->drv_data, iface, buf, &buf_len);

	return ret;
}
#endif
int wapp_get_tx_pwr(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_get_tx_pwr(wapp->drv_data, iface, buf, &buf_len);

	return ret;
}

#ifdef MAP_R3_WF6
int wapp_get_wf6_cap(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_get_wf6_cap(wapp->drv_data, iface, buf, &buf_len);

	return ret;
}
#endif /*MAP_R3_WF6 */

int wapp_get_valid_radio_count(struct wifi_app *wapp)
{
	int i = 0;
	int radio_count = 0;

	for (i = 0; i < MAX_NUM_OF_RADIO; i++) {
		if (wapp->radio[i].adpt_id)
			radio_count++;
	}
	return radio_count;
}

#ifdef DPP_SUPPORT
int wapp_get_dpp_frame(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{

	if (wapp->drv_ops->drv_get_dpp_frame)
		return wapp->drv_ops->drv_get_dpp_frame(wapp->drv_data, iface, buf, buf_len);

	return -1;
}
#endif /* DPP_SUPPORT */

#ifdef DPP_R2_SUPPORT
int wapp_get_cce_result(struct wifi_app *wapp, struct wapp_dev *wdev)
{
	int ret = 0;
	struct wapp_req req;

	if (!wapp || !wdev)
		return WAPP_INVALID_ARG;

	req.req_id = WAPP_GET_CCE_RESULT;
	req.data.ifindex = wdev->ifindex;
	debug(DEBUG_CAT_DPP, "%s ,cce query for ifname:%s\n", __func__, wdev->ifname);

	ret = wapp_req_send(wapp, wdev->ifname, &req);
	return ret;
}
#endif

int get_parameters(char *name, char *param, char *value, param_type type, size_t val_len)
{
#ifdef OPENWRT_SUPPORT
	const char *tmp_value = NULL;
	unsigned int len = 0;
	struct kvc_context *dat_ctx = NULL;
	const char *file = NULL;
	int ret = 0;

	debug(DEBUG_CAT_MISC, "param(%s) from file(%s)\n", param, name);

	os_memset(value, 0, val_len);

	if (type == NON_DRIVER_PARAM)
		file = name;
	else
		file = get_dat_path_by_ord(0);

	if (!file) {
		err(DEBUG_CAT_MISC, "invalid file!!! type(%d)\n", type);
		return -1;
	}

	dat_ctx = dat_load(file);
	if (!dat_ctx) {
		err(DEBUG_CAT_MISC, "load file(%s) fail\n", file);
		ret = -1;
		goto out;
	}

	tmp_value = kvc_get(dat_ctx, (const char *)param);
	if (!tmp_value) {
		err(DEBUG_CAT_MISC, "get param(%s) fail\n", param);
		ret = -1;
		goto out;
	}
	len = os_min(os_strlen(tmp_value), val_len - 1);
	os_memcpy(value, tmp_value, len);

	debug(DEBUG_CAT_MISC, "value(%s)\n", value);
out:
	if (file && (type != NON_DRIVER_PARAM))
		free_dat_path(file);
	if (dat_ctx)
		kvc_unload(dat_ctx);

	return ret;
#else
	return 0;
#endif
}

int set_parameters(char *name, char *param, char *value, param_type type)
{
#ifdef OPENWRT_SUPPORT
	struct kvc_context *dat_ctx = NULL;
	int ret = 0;
	const char *file = NULL;

	debug(DEBUG_CAT_MISC, "param(%s) value(%s) to file(%s)\n", param, value, name);

	if (type == NON_DRIVER_PARAM)
		file = name;
	else
		file = get_dat_path_by_ord(0);

	if (!file) {
		err(DEBUG_CAT_MISC, "invalid file!!! type(%d)\n", type);
		return -1;
	}

	dat_ctx = dat_load((const char *)file);
	if (!dat_ctx) {
		err(DEBUG_CAT_MISC, "load file(%s) fail\n", file);
		ret = -1;
		goto out;
	}

	ret = kvc_set(dat_ctx, (const char *)param, (const char *)value);
	if (ret) {
		err(DEBUG_CAT_MISC, "set param(%s) fail\n", param);
		goto out;
	}
	ret = kvc_commit(dat_ctx);
	if (ret) {
		err(DEBUG_CAT_MISC, "write param(%s) fail\n", param);
		goto out;
	}
out:
	if (file && (type != NON_DRIVER_PARAM))
		free_dat_path(file);
	if (dat_ctx)
		kvc_unload(dat_ctx);
	if (ret)
		return -1;
	else
		return 0;
#else
	return 0;
#endif
}

int set_indexed_parameters(char *file_name, char *param, char *value,
		u32 index, param_type type)
{
#ifdef OPENWRT_SUPPORT
	struct kvc_context *dat_ctx = NULL;
	int ret = 0;
	const char *file = NULL;


	if (type == NON_DRIVER_PARAM)
		file = file_name;
	else
		file = get_dat_path_by_ord(0);

	if (!file) {
		err(DEBUG_CAT_MISC, "invalid file!!! type(%d)\n", type);
		return -1;
	}

	dat_ctx = dat_load(file);
	if (!dat_ctx) {
		err(DEBUG_CAT_MISC, DPP_MAP_PREX"load file(%s) fail\n", file);
		ret = -1;
		goto out;
	}
	ret = kvc_set_indexed(dat_ctx, (const char *)param,
		(uint32_t)index, (const char *)value);
	if (ret) {
		err(DEBUG_CAT_MISC, DPP_MAP_PREX"set param(%s) fail\n", param);
		goto out;
	}
	ret = kvc_commit(dat_ctx);
	if (ret) {
		err(DEBUG_CAT_MISC, DPP_MAP_PREX"write param(%s) fail\n", param);
		goto out;
	}
out:
	if (file && (type != NON_DRIVER_PARAM))
		free_dat_path(file);
	if (dat_ctx)
		kvc_unload(dat_ctx);
	if (ret)
		return -1;
	else
		return 0;
#else
		return 0;
#endif /* OPENWRT_SUPPORT */
}

int get_indexed_parameter(char *file_name, char *param, char *value,
		size_t val_len, u32 index, param_type type)
{
#ifdef OPENWRT_SUPPORT
	const char *tmp_value = NULL;
	unsigned int len = 0;
	struct kvc_context *dat_ctx = NULL;
	const char *file = NULL;
	int ret = 0;

	debug(DEBUG_CAT_MISC, "param(%s) from file(%s)\n", param, file_name);

	os_memset(value, 0, val_len);

	if (type == NON_DRIVER_PARAM)
		file = file_name;
	else
		file = get_dat_path_by_ord(0);

	if (!file) {
		err(DEBUG_CAT_MISC, "invalid file!!! type(%d)\n", type);
		return -1;
	}

	dat_ctx = dat_load(file);
	if (!dat_ctx) {
		err(DEBUG_CAT_MISC, "load file(%s) fail\n", file);
		ret = -1;
		goto out;
	}

	tmp_value = kvc_get(dat_ctx, (const char *)param);
	if (!tmp_value) {
		err(DEBUG_CAT_MISC, "get param(%s) fail\n", param);
		ret = -1;
		goto out;
	}
	tmp_value = kvc_get_indexed(dat_ctx, (const char *)param, (uint32_t)index);
	if (!tmp_value) {
		err(DEBUG_CAT_MISC, "get param(%s) fail\n", param);
		ret = -1;
		goto out;
	}
	len = os_min(os_strlen(tmp_value), val_len - 1);
	os_memcpy(value, tmp_value, len);

	debug(DEBUG_CAT_MISC, "value(%s)\n", value);
out:
	if (file && (type != NON_DRIVER_PARAM))
		free_dat_path(file);
	if (dat_ctx)
		kvc_unload(dat_ctx);

	return ret;
#else
	return 0;
#endif
}

#ifdef MTK_HOSTAPD_SUPPORT
#ifdef MAP_R6
char *SupplicantGetEncryTypeStr(unsigned short encryFlag, short authmode)
#else
char *SupplicantGetEncryTypeStr(unsigned short encryFlag)
#endif /* MAP_R6 */
{
	switch (encryFlag) {
	case WSC_ENCRTYPE_NONE:
		return "NONE";

	case WSC_ENCRTYPE_WEP:
		return "WEP40 WEP104";

	case WSC_ENCRTYPE_TKIP:
		return "TKIP";
#ifndef MAP_R6
	case (WSC_ENCRTYPE_TKIP | WSC_ENCRTYPE_AES):
#ifdef EM_PLUS_SUPPORT
		return "CCMP";
#else
		return "TKIP CCMP";
#endif

	case WSC_ENCRTYPE_AES:
		return "CCMP";
#else
	case (WSC_ENCRTYPE_TKIP | WSC_ENCRTYPE_AES):
		if (authmode & AUTH_SAE_AKM24)
			return "TKIP CCMP GCMP-256";
		else
			return "TKIP CCMP";

	case WSC_ENCRTYPE_AES:
		if (authmode & AUTH_SAE_AKM24)
			return "CCMP GCMP-256";
		else
			return "CCMP";
#endif
	default:
		return "CCMP";
	}
}

uint32_t wapp_strtol(const char *ifname)
{
	int i = 0;
	char cval = 0;
	uint32_t val = 0;
	uint32_t ret = 0;

	while (ifname[i] != '\n' && ifname[i] != '\0') {
		if (ifname[i] >= '0' && ifname[i] <= '9') {
			cval = ifname[i];
			val = cval - '0';
			ret = (ret * 10) + val;
		}
		i++;
	}
	return ret;
}

u8 wapp_find_base_intf_name(char *ifname, char *base_intf)
{
	int i = 0;
	u8 len = 0;

	os_memset(base_intf, 0, IFNAMSIZ);
	while (ifname[i] != '\n' && ifname[i] != '\0') {
		if (ifname[i] >= 'a' && ifname[i] <= 'z') {
			base_intf[len] = ifname[i];
			len++;
		}
		i++;
	}

	return len;
}

int wapp_uci_update(char *config_name, char *option, char *value)
{
	struct uci_context *ctx;

	ctx = uci_alloc_context();
	if (!ctx) {
		printf("failed to alloc uci ctx\n");
		return 1;
	}

	struct uci_ptr config;
	char section_name[100];
	int ret = 0;

#ifdef WPS_UNCONFIG_FEATURE_SUPPORT
	if (os_strlen(config_name) >= sizeof(section_name)) {
		printf("invalid config, Do not copy\n");
		uci_free_context(ctx);
		return -1;
	}
	os_memset(section_name, 0, sizeof(section_name));
	if (os_strncmp(config_name, "mapd.", 5) == 0) {
		os_strncpy(section_name, config_name, os_strlen(config_name));
	} else
#endif
		ret = os_snprintf(section_name, sizeof(section_name), "wireless.%s", config_name);


	if (ret < 0) {
		err(DEBUG_CAT_MISC, "os_snprintf fail\n");
		uci_free_context(ctx);
		return -1;
	}

	if (uci_lookup_ptr(ctx, &config, section_name, true) != UCI_OK || !config.s) {
		printf("failed to find the specified section\n");
		uci_free_context(ctx);
		return 1;
	}

	config.option = option;
	config.value = value;

	if (uci_set(ctx, &config) != UCI_OK) {
		printf("failed to set new option\n");
		uci_free_context(ctx);
		return 1;
	}

	if (uci_commit(ctx, &config.p, false) != UCI_OK) {
		printf("failed to commit changes\n");
		uci_free_context(ctx);
		return 1;
	}

	uci_free_context(ctx);
	return 0;
}

int wapp_uci_get_param(char *config_name, char *option, char *value)
{

	struct uci_context *ctx;

	ctx = uci_alloc_context();
	if (!ctx) {
		printf("failed to alloc uci ctx\n");
		return 1;
	}

	struct uci_ptr config;
	char section_name[100];
	int ret = 0;

	ret = os_snprintf(section_name, sizeof(section_name), "wireless.%s.%s", config_name, option);
	if (ret < 0) {
		err(DEBUG_CAT_MISC, "os_snprintf fail\n");
		uci_free_context(ctx);
		return -1;
	}

	if (uci_lookup_ptr(ctx, &config, section_name, true) != UCI_OK || !config.s) {
		printf("failed to find the specified section\n");
		uci_free_context(ctx);
		return 1;
	}

	os_strlcpy(value, config.o->v.string, MAX_SIZE_UCI_VALUE);
	uci_free_context(ctx);
	return 0;
}

int wdev_set_hapd_wifi_profile(struct wifi_app *wapp, struct wapp_dev *wdev,
		struct wireless_setting *wifi_profile)
{
	uint32_t wdev_index = 0;
	u8 i_am_fh_bss = 0;
	u8 i_am_bh_bss = 0;
	int ret = 0;
	char value[20] = {0};
	char param[64] = {0};
	char auth_str[50] = {0};
	char encryp_str[50] = {0};
	char base_intf[IFNAMSIZ] = {0};
	u8 wpa_val = 0;
	u8 devrole_val = 0;
	struct dl_list *dev_list = NULL;
	struct wapp_dev *loop_wdev = NULL;
	u8 is_6g_authmode = 0;
	u8 base_len = 0;
#ifdef MAP_R6
	char param2[64] = {0};
#endif
	struct ap_dev *ap = NULL;

	if (wdev == NULL) {
		err(DEBUG_CAT_WIFI_CONFIG, "Wdev is NULL\n");
		return -1;
	}

	wdev_index = wapp_strtol(wdev->ifname);

	notice(DEBUG_CAT_WIFI_CONFIG, "%s Wdev %s with index(%u)\n",
		__func__, wdev->ifname, wdev_index);

	i_am_fh_bss = (wifi_profile->map_vendor_extension & (1 << MAP_ROLE_FRONTHAUL_BSS)) ? 1 : 0;
	i_am_bh_bss = (wifi_profile->map_vendor_extension & (1 << MAP_ROLE_BACKHAUL_BSS)) ? 1 : 0;

	/*
	 * Extract hostapd file name from wdev name
	 */
	base_len = wapp_find_base_intf_name(wdev->ifname, base_intf);
	base_intf[base_len] = '0';

	if (wdev->radio == NULL) {
		err(DEBUG_CAT_MISC, "Wdev radio is NULL\n");
		return -1;
	}

#ifdef MAP_6E_SUPPORT
	if (!wdev->radio->radio_band) {
		err(DEBUG_CAT_WIFI_CONFIG, "wdev->radio->radio_band is NULL.\n");
		return -1;
	}

	if (IS_OP_CLASS_6G(wdev->radio->opclass) &&
		OP_CLASS_MATCH_RADIO_CONF(*wdev->radio->radio_band, wdev->radio->opclass))
		is_6g_authmode = 1;
#endif /* MAP_6E_SUPPORT */
/* OWE  To skip owe transition for 6g wdev */
	if ((wifi_profile->AuthMode == AUTH_OWE_TRANSITION) && (is_6g_authmode == 1)) {
		err(DEBUG_CAT_WIFI_CONFIG,
			"config received for 6g wdev having authentication type as OWE TRANSITIION [%s] (%d): os_snprintf fail\n",
			__func__, __LINE__);
		return 0;
	}

	/* Set SSID as per wireless setting */
	ret = os_snprintf(param, sizeof(param), "ssid");
	if (os_snprintf_error(sizeof(param), ret)) {
		err(DEBUG_CAT_WIFI_CONFIG, "[%s] (%d): os_snprintf fail\n", __func__, __LINE__);
		return -1;
	}

	wapp_uci_update(wdev->ifname, param, (char *)wifi_profile->Ssid);
	NdisZeroMemory(param, sizeof(param));

#ifdef MAP_R6
	if (wifi_profile->AuthMode & AUTH_SAE_AKM24 && (!is_6g_authmode))
		hapd_get_auth_string_akm_sae24(wifi_profile->AuthMode, auth_str);
#ifdef MAP_6E_SUPPORT
	else if (wifi_profile->AuthMode & AUTH_SAE_AKM24 && (is_6g_authmode))
		hapd_get_auth_string_akm_sae24_6g(wifi_profile->AuthMode, auth_str);
	else if (is_6g_authmode)
		hapd_get_auth_string_6g(wifi_profile->AuthMode, auth_str);
#endif /* MAP_6E_SUPPORT */
	else
		hapd_get_auth_string(wifi_profile->AuthMode, auth_str);
#endif /* MAP_R6 */

	/* Update BH SSID to all the BSSs in band */
	if (i_am_bh_bss) {
		ret = os_snprintf(param, sizeof(param), "multi_ap_backhaul_ssid");
		if (os_snprintf_error(sizeof(param), ret)) {
			err(DEBUG_CAT_WIFI_CONFIG, "[%s] (%d): os_snprintf fail\n", __func__, __LINE__);
			return -1;
		}

#ifdef MAP_R6
		ret = os_snprintf(param2, sizeof(param2), "multi_ap_backhaul_key_mgmt");
		if (os_snprintf_error(sizeof(param2), ret)) {
			err(DEBUG_CAT_WIFI_CONFIG, "[%s] (%d): os_snprintf fail\n", __func__, __LINE__);
			return -1;
		}
#endif /* MAP_R6 */

		dev_list = &wapp->dev_list;

		dl_list_for_each(loop_wdev, dev_list, struct wapp_dev, list)
		{
			if (loop_wdev->dev_type == WAPP_DEV_TYPE_AP
			&& (loop_wdev->radio) && (wdev->radio) && (wdev->radio->radio_id == loop_wdev->radio->radio_id)
			) {
				wdev_set_hapd_map_param(wapp, loop_wdev, HAPD_MAP_BH_SSID, (char *)wifi_profile->Ssid,
						strlen((char *)wifi_profile->Ssid));
				/*Autotest suite case when M8 does not send latest BH profile.*/
				loop_wdev->i_need_hostapd_reload = TRUE;
				wapp_uci_update(loop_wdev->ifname, param, (char *)wifi_profile->Ssid);
#ifdef MAP_R6
				if (!is_str_null(auth_str)) {
					err(DEBUG_CAT_WIFI_CONFIG, "[%s] (%d): not used\n", __func__, __LINE__);
#ifdef NOT_USED
					wdev_set_hapd_map_param(wapp, loop_wdev, HAPD_MAP_BH_KEY_MGMT, (char *)auth_str,
						sizeof(auth_str));
					wapp_uci_update(loop_wdev->ifname, param2, (char *)auth_str);
#endif /* MAP_R6 */
				}
#endif /* MAP_R6 */
			}
		}

		NdisZeroMemory(param, sizeof(param));
	}

#ifndef MAP_R6
	/* Set Authmode */
#ifdef MAP_6E_SUPPORT
	if (is_6g_authmode) {
		hapd_get_auth_string_6g(wifi_profile->AuthMode, auth_str);
	} else {
#endif
		hapd_get_auth_string(wifi_profile->AuthMode, auth_str);
#ifdef MAP_6E_SUPPORT
	}
#endif
#endif /* MAP_R6 */

	if (!is_str_null(auth_str)) {
		ret = os_snprintf(param, sizeof(param), "wpa_key_mgmt");
		if (os_snprintf_error(sizeof(param), ret)) {
			err(DEBUG_CAT_WIFI_CONFIG, "[%s] (%d): os_snprintf fail\n", __func__, __LINE__);
			return -1;
		}
		if (wifi_profile->AuthMode != WPS_AUTH_OPEN)
			wdev_set_hapd_map_param(wapp, wdev, HAPD_AUTHMODE, (char *)auth_str,
					sizeof(auth_str));
	}
	NdisZeroMemory(param, sizeof(param));

	if (wifi_profile->AuthMode == WPS_AUTH_OPEN)
		wdev->is_auth_open = 1;

	if (wifi_profile->AuthMode == AUTH_OWE_ONLY)
		wdev->is_auth_owe = 1;

	if (wifi_profile->AuthMode == AUTH_OWE_TRANSITION)
		wdev->is_auth_owe_transtn = 1;

	/* Set auth_algs for shared authmode */
	ret = os_snprintf(param, sizeof(param), "auth_algs");
	if (os_snprintf_error(sizeof(param), ret)) {
		err(DEBUG_CAT_WIFI_CONFIG, "[%s] (%d): os_snprintf fail\n", __func__, __LINE__);
		return -1;
	}
	if (wifi_profile->AuthMode & WPS_AUTH_SHARED) {
		wdev_set_hapd_map_param(wapp, wdev, HAPD_AUTH_ALGS, HAPD_CONF_AUTH_ALGS_EN, 2);
		wapp_uci_update(wdev->ifname, param, HAPD_CONF_AUTH_ALGS_EN);
	} else {
		wdev_set_hapd_map_param(wapp, wdev, HAPD_AUTH_ALGS, HAPD_CONF_AUTH_ALGS_DIS, 1);
		wapp_uci_update(wdev->ifname, param, HAPD_CONF_AUTH_ALGS_DIS);
	}
	NdisZeroMemory(param, sizeof(param));

	/* For WPA3 set ieee80211w mode to hostapd */
	if ((wifi_profile->AuthMode == WPS_AUTH_SAE)
		|| (wifi_profile->AuthMode == AUTH_OWE_ONLY)
		|| (wifi_profile->AuthMode == AUTH_OWE_TRANSITION)) {
		ret = os_snprintf(param, sizeof(param), "ieee80211w");
		if (os_snprintf_error(sizeof(param), ret)) {
			err(DEBUG_CAT_WIFI_CONFIG, "[%s] (%d): os_snprintf fail\n", __func__, __LINE__);
			return -1;
		}

		wdev_set_hapd_map_param(wapp, wdev, HAPD_PMF_6G, HAPD_CONF_PMF_6G, 1);
		wapp_uci_update(wdev->ifname, param, HAPD_CONF_PMF_6G);
		NdisZeroMemory(param, sizeof(param));
	}
	if ((wifi_profile->AuthMode & AUTH_DPP_ONLY)
		|| (wifi_profile->AuthMode & WPS_AUTH_WPA2PSK)
		|| (wifi_profile->AuthMode == 0x0060)
		|| (wifi_profile->AuthMode == 0x00C0)
		|| (wifi_profile->AuthMode == 0x00E0)
#ifdef MAP_R6
		|| (wifi_profile->AuthMode & AUTH_SAE_AKM24)
#endif /* MAP_R6 */
	) {
		ret = os_snprintf(param, sizeof(param), "ieee80211w");
		if (os_snprintf_error(sizeof(param), ret)) {
			err(DEBUG_CAT_WIFI_CONFIG, "[%s] (%d): os_snprintf fail\n", __func__, __LINE__);
			return -1;
		}

#ifdef MAP_6E_SUPPORT
	if (is_6g_authmode || (wifi_profile->AuthMode == AUTH_SAE_AKM24) ||
				(wifi_profile->AuthMode ==  AUTH_SAE_AKM24_SAE_MIX)) {
		/* PMF Reqd for 6G wdev*/
		wdev_set_hapd_map_param(wapp, wdev, HAPD_PMF_6G, HAPD_CONF_PMF_6G, 1);
		wapp_uci_update(wdev->ifname, param, HAPD_CONF_PMF_6G);
#ifdef EM_PLUS_SUPPORT
#ifndef EM_PLUS_EXT_SUPPORT
	} else if (wifi_profile->AuthMode == WPS_AUTH_OPEN || (wifi_profile->AuthMode == WPS_AUTH_WPAPSK)
		|| (wifi_profile->AuthMode == WPS_AUTH_WPA2PSK) || (wifi_profile->AuthMode == WPS_AUTH_SHARED)
		|| (wifi_profile->AuthMode == WPS_AUTH_WPA) || (wifi_profile->AuthMode == WPS_AUTH_WPA2)) {
		err(DEBUG_CAT_WIFI_CONFIG, "PMF DISABLE for WPA2 Only mode\n");
		wdev_enable_pmf(wapp, wdev, FALSE);
#endif
#endif
	} else {
#endif
		/* PMF optional  for Non 6G wdev*/
		wdev_enable_pmf(wapp, wdev, TRUE);
		wapp_uci_update(wdev->ifname, param, HAPD_CONF_PMF_NON_6G);
#ifdef MAP_6E_SUPPORT
	}
#endif
		NdisZeroMemory(param, sizeof(param));
	}

	/* Based on Authmode set wpa type in hostapd config file */
	if (((wifi_profile->AuthMode & WPS_AUTH_WPAPSK)
		|| (wifi_profile->AuthMode & WPS_AUTH_WPA)) && (!is_6g_authmode))
		wpa_val |= WPA_PROTO_WPA;

	if ((wifi_profile->AuthMode & WPS_AUTH_WPA2PSK)
		|| (wifi_profile->AuthMode & WPS_AUTH_WPA2)
		|| (wifi_profile->AuthMode & WPS_AUTH_SAE)
		|| (wifi_profile->AuthMode & AUTH_DPP_ONLY)
#ifdef MAP_R6
		|| (wifi_profile->AuthMode & AUTH_SAE_AKM24)
#endif /* MAP_R6 */
		|| (wifi_profile->AuthMode & AUTH_OWE_ONLY)
		|| (wifi_profile->AuthMode & AUTH_OWE_TRANSITION)
		)
		wpa_val |= WPA_PROTO_RSN;

	if (wifi_profile->AuthMode & WPS_AUTH_OPEN)
		wpa_val = 0;

	ret = os_snprintf(value, sizeof(value), "%d", wpa_val);
	if (os_snprintf_error(sizeof(value), ret)) {
		err(DEBUG_CAT_WIFI_CONFIG, "[%s] (%d): os_snprintf fail\n", __func__, __LINE__);
		return -1;
	}

	wdev_set_hapd_map_param(wapp, wdev, HAPD_WPA, value, sizeof(value));
	NdisZeroMemory(param, sizeof(param));
	NdisZeroMemory(value, sizeof(value));

	/* Set EncrypType */
#ifdef MAP_R6
	ret = os_snprintf(encryp_str, sizeof(encryp_str), "%s",
		SupplicantGetEncryTypeStr(wifi_profile->EncrypType, wifi_profile->AuthMode));
#else
	ret = os_snprintf(encryp_str, sizeof(encryp_str), "%s",
		SupplicantGetEncryTypeStr(wifi_profile->EncrypType));
#endif

	if (os_snprintf_error(sizeof(value), ret)) {
		err(DEBUG_CAT_WIFI_CONFIG, "[%s] (%d): os_snprintf fail\n", __func__, __LINE__);
		return -1;
	}
	if (((wifi_profile->AuthMode & WPS_AUTH_WPAPSK)
				|| (wifi_profile->AuthMode & WPS_AUTH_WPA)) && (!is_6g_authmode)) {
		wdev_set_hapd_map_param(wapp, wdev, HAPD_WPA_PAIRWISE, (char *)encryp_str, sizeof(encryp_str));
		if (wifi_profile->AuthMode == WPS_AUTH_MIXED)
			wdev_set_hapd_map_param(wapp, wdev, HAPD_RSN_PAIRWISE, (char *)encryp_str, sizeof(encryp_str));
	} else if (wifi_profile->AuthMode != WPS_AUTH_OPEN) {
		wdev_set_hapd_map_param(wapp, wdev, HAPD_RSN_PAIRWISE, (char *)encryp_str, sizeof(encryp_str));
	}

	/* For WEP Encryptype set WEP key on index1 */
	if (wifi_profile->EncrypType & WSC_ENCRTYPE_WEP) {
		wdev_send_wep_key(wapp, wdev, wdev_index, (char *) wifi_profile->WPAKey);
		NdisZeroMemory(param, sizeof(param));
	}
	/* Set password as per wireless setting */
	if (((wifi_profile->AuthMode & WPS_AUTH_WPAPSK)
			|| (wifi_profile->AuthMode & WPS_AUTH_WPA2PSK)) && (!is_6g_authmode)) {
		wdev_set_hapd_map_param(wapp, wdev, HAPD_WPA_PASSPHRASE,
				(char *)wifi_profile->WPAKey,
				sizeof(wifi_profile->WPAKey));
	}

	if (wifi_profile->AuthMode & WPS_AUTH_SAE
#ifdef MAP_R6
	|| (wifi_profile->AuthMode & AUTH_SAE_AKM24)
#endif
	) {

		wdev_set_hapd_map_param(wapp, wdev, HAPD_SAE_PASSPHRASE,
				(char *)wifi_profile->WPAKey,
				sizeof(wifi_profile->WPAKey));
		wdev_set_hapd_map_param(wapp, wdev, HAPD_SAE_PWE, HAPD_CONF_SAE_PWE, 1);
	}
#ifdef MAP_R6
		/* if SAE AKM100 supported*/
		if (wifi_profile->AuthMode & AUTH_SAE_AKM24) {
			wdev_set_hapd_map_param(wapp, wdev, HAPD_MAP_SAE_GROUPS, "19", sizeof("19"));
			/*default value is 19, as well need to develop method for writing list in uci*/
			/*wapp_uci_update(wdev->ifname, "sae_groups", "19");*/
			wdev_set_hapd_map_param(wapp, wdev, HAPD_MAP_GROUP_CIPHER, "CCMP", sizeof("CCMP"));
			wapp_uci_update(wdev->ifname, "group_cipher", "CCMP");
			wdev_set_hapd_map_param(wapp, wdev, HAPD_MAP_GROUP_MGMT_CIPHER, "AES-128-CMAC", sizeof("AES-128-CMAC"));
			wapp_uci_update(wdev->ifname, "group_mgmt_cipher", "AES-128-CMAC");
			wdev_set_hapd_map_param(wapp, wdev, HAPD_MAP_BEACON_PROT, "1", 1);
			wapp_uci_update(wdev->ifname, "beacon_prot", "1");
			wapp_uci_update(wdev->ifname, "sae_password", (char *)wifi_profile->WPAKey);
		}
#endif /* MAP_R6 */
		if (wifi_profile->AuthMode & AUTH_OWE_ONLY)
			wdev_set_hapd_map_param(wapp, wdev, HAPD_MAP_OWE_GROUPS, "19", sizeof("19"));

	/* Update BH password to all the BSSs in band */
	if (i_am_bh_bss) {
		ret = os_snprintf(param, sizeof(param), "multi_ap_backhaul_wpa_passphrase");
		if (os_snprintf_error(sizeof(param), ret)) {
			err(DEBUG_CAT_WIFI_CONFIG, "[%s] (%d): os_snprintf fail\n", __func__, __LINE__);
			return -1;
		}

		dev_list = &wapp->dev_list;

		dl_list_for_each(loop_wdev, dev_list, struct wapp_dev, list)
		{
			if (loop_wdev->dev_type == WAPP_DEV_TYPE_AP
			&& (loop_wdev->radio) && (wdev->radio) && (wdev->radio->radio_id == loop_wdev->radio->radio_id)
			) {
				if (loop_wdev->is_auth_open != 1)
					wdev_set_hapd_map_param(wapp, loop_wdev, HAPD_MAP_BACKHAUL_WPA_PASSPHRASE,
								(char *)wifi_profile->WPAKey,
								sizeof(wifi_profile->WPAKey));
				/*Autotest suite case when M8 does not send latest BH profile.*/
				loop_wdev->i_need_hostapd_reload = TRUE;
				wapp_uci_update(loop_wdev->ifname, param, (char *)wifi_profile->WPAKey);
			}
		}

		NdisZeroMemory(param, sizeof(param));
	}

	/* Reload to all the FH BSSs in band */
	if (i_am_bh_bss) {
		dev_list = &wapp->dev_list;

		dl_list_for_each(loop_wdev, dev_list, struct wapp_dev, list)
		{
			if (loop_wdev->dev_type == WAPP_DEV_TYPE_AP && loop_wdev->i_am_fh_bss
			&& (loop_wdev->radio) && (wdev->radio) &&
			(wdev->radio->radio_id == loop_wdev->radio->radio_id)) {
				err(DEBUG_CAT_WIFI_CONFIG, "set hapd reload for %s\n",
					loop_wdev->ifname);
				loop_wdev->i_need_hostapd_reload = TRUE;
			}
		}
	}

/*after tear down backhaul bss up first so backhaul configuration is not applying on fh bss*/
	if (i_am_fh_bss) {
		dev_list = &wapp->dev_list;
		dl_list_for_each(loop_wdev, dev_list, struct wapp_dev, list)
		{
			if (loop_wdev->dev_type == WAPP_DEV_TYPE_AP && loop_wdev->i_am_bh_bss
			&& (loop_wdev->radio) && (wdev->radio) && (wdev->radio->radio_id == loop_wdev->radio->radio_id)) {
				ap = (struct ap_dev *)loop_wdev->p_dev;
				if (ap) {
					wdev_set_hapd_map_param(wapp, wdev, HAPD_MAP_BH_SSID, (char *)ap->bss_info.ssid,
						ap->bss_info.SsidLen);
					if (loop_wdev->is_auth_open != 1)
						wdev_set_hapd_map_param(wapp, wdev, HAPD_MAP_BACKHAUL_WPA_PASSPHRASE,
							(char *)ap->bss_info.key, ap->bss_info.key_len);
					/*Autotest suite case when M8 does not send latest BH profile.*/
					wdev->i_need_hostapd_reload = TRUE;
				}
			}
		}
	}

	/* Set vendor extension FH or BH bit in BSS */
	if (i_am_fh_bss)
		devrole_val |= FRONTHAUL_BSS;

	if (i_am_bh_bss)
		devrole_val |= BACKHAUL_BSS;

	ret = os_snprintf(value, sizeof(value), "%d", devrole_val);
	if (os_snprintf_error(sizeof(value), ret)) {
		err(DEBUG_CAT_WIFI_CONFIG, "[%s] (%d): os_snprintf fail\n", __func__, __LINE__);
		return -1;
	}

	ret = os_snprintf(param, sizeof(param), "multi_ap");
	if (os_snprintf_error(sizeof(param), ret)) {
		err(DEBUG_CAT_WIFI_CONFIG, "[%s] (%d): os_snprintf fail\n", __func__, __LINE__);
		return -1;
	}

	wdev_set_hapd_map_param(wapp, wdev, HAPD_MAP, value, sizeof(value));
	wapp_uci_update(wdev->ifname, param, value);
	NdisZeroMemory(param, sizeof(param));
	NdisZeroMemory(value, sizeof(value));

	/* Set Hidden SSID */
	ret = os_snprintf(value, sizeof(value), "%d", wifi_profile->hidden_ssid);
	if (os_snprintf_error(sizeof(value), ret)) {
		err(DEBUG_CAT_WIFI_CONFIG, "[%s] (%d): os_snprintf fail\n", __func__, __LINE__);
		return -1;
	}
	ret = os_snprintf(param, sizeof(param), "ignore_broadcast_ssid");
	if (os_snprintf_error(sizeof(param), ret)) {
		err(DEBUG_CAT_WIFI_CONFIG, "[%s] (%d): os_snprintf fail\n", __func__, __LINE__);
		return -1;
	}
	wdev_set_hapd_map_param(wapp, wdev, HAPD_IGNORE_BROADCAST_SSID, value, sizeof(value));
	wapp_uci_update(wdev->ifname, param, value);
	NdisZeroMemory(param, sizeof(param));
	NdisZeroMemory(value, sizeof(value));
	wapp_uci_update(wdev->ifname, "ssid", (char *)wifi_profile->Ssid);
#ifdef MAP_6E_SUPPORT
	if (is_6g_authmode)
		wapp_uci_update(wdev->ifname, "wps_state", "0");
	else
#endif
		{
			if (i_am_bh_bss) {
				wapp_uci_update(wdev->ifname, "wps_state", "0");
				wdev_set_hapd_map_param(wapp, wdev, HAPD_MAP_WPS_STATE, "0", 1);
			} else {
				wapp_uci_update(wdev->ifname, "wps_state", "2");
				wdev_set_hapd_map_param(wapp, wdev, HAPD_MAP_WPS_STATE, "2", 1);
			}
		}
	wapp_uci_update(wdev->ifname, "wps_cred_add_sae", "1");
	wapp_uci_update(wdev->ifname, "wps_independent", "0");
	wapp_uci_update(wdev->ifname, "mbo", "1");
	wapp_uci_update(wdev->ifname, "dpp_pfs", "0");
	wapp_uci_update(wdev->ifname, "interworking", "1");

#ifdef MAP_6E_SUPPORT
	if (is_6g_authmode) {
#ifdef MAP_R3
		if ((wifi_profile->AuthMode & WPS_AUTH_SAE) && (wifi_profile->AuthMode & WPS_AUTH_WPA2PSK)
				&& (wifi_profile->AuthMode & AUTH_DPP_ONLY)) {
#ifdef MAP_R6
			if (wifi_profile->AuthMode & AUTH_SAE_AKM24)
				wapp_uci_update(wdev->ifname, "encryption", "sae-sae-ext-dpp");
			else
				wapp_uci_update(wdev->ifname, "encryption", "sae-dpp");
#else
			wapp_uci_update(wdev->ifname, "encryption", "sae-dpp");
#endif
			wapp_uci_update(wdev->ifname, "key", (char *)wifi_profile->WPAKey);
			wapp_uci_update(wdev->ifname, "key1", "");
			wapp_uci_update(wdev->ifname, "sae_pwe", HAPD_CONF_SAE_PWE);
		} else if ((wifi_profile->AuthMode & WPS_AUTH_SAE) && (wifi_profile->AuthMode & AUTH_DPP_ONLY)) {
#ifdef MAP_R6
			if (wifi_profile->AuthMode & AUTH_SAE_AKM24)
				wapp_uci_update(wdev->ifname, "encryption", "sae-sae-ext-dpp");
			else
				wapp_uci_update(wdev->ifname, "encryption", "sae-dpp");
#else
			wapp_uci_update(wdev->ifname, "encryption", "sae-dpp");
#endif
			wapp_uci_update(wdev->ifname, "key", (char *)wifi_profile->WPAKey);
			wapp_uci_update(wdev->ifname, "key1", "");
			wapp_uci_update(wdev->ifname, "sae_pwe", HAPD_CONF_SAE_PWE);
		} else if ((wifi_profile->AuthMode & WPS_AUTH_WPA2PSK) && (wifi_profile->AuthMode & AUTH_DPP_ONLY)) {
#ifdef MAP_R6
			if (wifi_profile->AuthMode & AUTH_SAE_AKM24) {
				wapp_uci_update(wdev->ifname, "encryption", "sae-ext-dpp");
				wapp_uci_update(wdev->ifname, "sae_pwe", HAPD_CONF_SAE_PWE);
			} else {
				wapp_uci_update(wdev->ifname, "encryption", "dpp");
				wapp_uci_update(wdev->ifname, "sae_pwe", "");
			}
#else
			wapp_uci_update(wdev->ifname, "encryption", "dpp");
			wapp_uci_update(wdev->ifname, "sae_pwe", "");
#endif
			wapp_uci_update(wdev->ifname, "key", (char *)wifi_profile->WPAKey);
			wapp_uci_update(wdev->ifname, "key1", "");
		} else if (wifi_profile->AuthMode & AUTH_DPP_ONLY) {
#ifdef MAP_R6
			if (wifi_profile->AuthMode & AUTH_SAE_AKM24) {
				wapp_uci_update(wdev->ifname, "encryption", "sae-ext-dpp");
				wapp_uci_update(wdev->ifname, "sae_pwe", HAPD_CONF_SAE_PWE);
			} else {
				wapp_uci_update(wdev->ifname, "encryption", "dpp");
				wapp_uci_update(wdev->ifname, "sae_pwe", "");
			}
#else
			wapp_uci_update(wdev->ifname, "encryption", "dpp");
			wapp_uci_update(wdev->ifname, "sae_pwe", "");
#endif
			wapp_uci_update(wdev->ifname, "key", (char *)wifi_profile->WPAKey);
			wapp_uci_update(wdev->ifname, "key1", "");
		} else
#endif
			if ((wifi_profile->AuthMode & WPS_AUTH_SAE) && (wifi_profile->AuthMode & WPS_AUTH_WPA2PSK)) {
#ifdef MAP_R6
				if (wifi_profile->AuthMode & AUTH_SAE_AKM24)
					wapp_uci_update(wdev->ifname, "encryption", "sae-sae-ext");
				else
					wapp_uci_update(wdev->ifname, "encryption", "sae");
#else
				wapp_uci_update(wdev->ifname, "encryption", "sae");
#endif
				wapp_uci_update(wdev->ifname, "key", (char *)wifi_profile->WPAKey);
				wapp_uci_update(wdev->ifname, "key1", "");
				wapp_uci_update(wdev->ifname, "sae_pwe", HAPD_CONF_SAE_PWE);
			} else if (wifi_profile->AuthMode & WPS_AUTH_SAE) {
#ifdef MAP_R6
				if (wifi_profile->AuthMode & AUTH_SAE_AKM24)
					wapp_uci_update(wdev->ifname, "encryption", "sae-sae-ext");
				else
					wapp_uci_update(wdev->ifname, "encryption", "sae");
#else
				wapp_uci_update(wdev->ifname, "encryption", "sae");
#endif
				wapp_uci_update(wdev->ifname, "key", (char *)wifi_profile->WPAKey);
				wapp_uci_update(wdev->ifname, "key1", "");
				wapp_uci_update(wdev->ifname, "sae_pwe", HAPD_CONF_SAE_PWE);
			}
		wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_6G);
	} else {
#endif
#ifdef MAP_R3
		if ((wifi_profile->AuthMode & WPS_AUTH_SAE) && (wifi_profile->AuthMode & WPS_AUTH_WPA2PSK)
				&& (wifi_profile->AuthMode & AUTH_DPP_ONLY)) {
#ifdef MAP_R6
			if (wifi_profile->AuthMode & AUTH_SAE_AKM24)
				wapp_uci_update(wdev->ifname, "encryption", "psk2-sae-sae-ext-dpp");
			else
				wapp_uci_update(wdev->ifname, "encryption", "psk2-sae-dpp");
#else
			wapp_uci_update(wdev->ifname, "encryption", "psk2-sae-dpp");
#endif
			wapp_uci_update(wdev->ifname, "key1", "");
			wapp_uci_update(wdev->ifname, "key", (char *)wifi_profile->WPAKey);
			wapp_uci_update(wdev->ifname, "sae_pwe", HAPD_CONF_SAE_PWE);
			wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_NON_6G);
		} else if ((wifi_profile->AuthMode & WPS_AUTH_SAE) && (wifi_profile->AuthMode & AUTH_DPP_ONLY)) {
#ifdef MAP_R6
			if (wifi_profile->AuthMode & AUTH_SAE_AKM24)
				wapp_uci_update(wdev->ifname, "encryption", "sae-sae-ext-dpp");
			else
				wapp_uci_update(wdev->ifname, "encryption", "sae-dpp");
#else
			wapp_uci_update(wdev->ifname, "encryption", "sae-dpp");
#endif
			wapp_uci_update(wdev->ifname, "key", (char *)wifi_profile->WPAKey);
			wapp_uci_update(wdev->ifname, "key1", "");
			wapp_uci_update(wdev->ifname, "sae_pwe", HAPD_CONF_SAE_PWE);
			wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_6G);
		} else if ((wifi_profile->AuthMode & WPS_AUTH_WPA2PSK) && (wifi_profile->AuthMode & AUTH_DPP_ONLY)) {
#ifdef MAP_R6
			if (wifi_profile->AuthMode & AUTH_SAE_AKM24) {
				wapp_uci_update(wdev->ifname, "encryption", "psk2-sae-ext-dpp");
				wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_6G);
				wapp_uci_update(wdev->ifname, "sae_pwe", HAPD_CONF_SAE_PWE);
			} else {
				wapp_uci_update(wdev->ifname, "encryption", "psk2-dpp");
				wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_NON_6G);
				wapp_uci_update(wdev->ifname, "sae_pwe", "");
			}
#else
			wapp_uci_update(wdev->ifname, "encryption", "psk2-dpp");
			wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_NON_6G);
			wapp_uci_update(wdev->ifname, "sae_pwe", "");
#endif
			wapp_uci_update(wdev->ifname, "key", (char *)wifi_profile->WPAKey);
			wapp_uci_update(wdev->ifname, "key1", "");
		} else if (wifi_profile->AuthMode & AUTH_DPP_ONLY) {
#ifdef MAP_R6
			if (wifi_profile->AuthMode & AUTH_SAE_AKM24) {
				wapp_uci_update(wdev->ifname, "encryption", "sae-ext-dpp");
				wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_6G);
				wapp_uci_update(wdev->ifname, "sae_pwe", HAPD_CONF_SAE_PWE);
			} else {
				wapp_uci_update(wdev->ifname, "encryption", "dpp");
				wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_NON_6G);
				wapp_uci_update(wdev->ifname, "sae_pwe", "");
			}
#else
			wapp_uci_update(wdev->ifname, "encryption", "dpp");
			wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_NON_6G);
			wapp_uci_update(wdev->ifname, "sae_pwe", "");
#endif
			wapp_uci_update(wdev->ifname, "key", (char *)wifi_profile->WPAKey);
			wapp_uci_update(wdev->ifname, "key1", "");
		} else
#endif /* MAP_R3 */

			if ((wifi_profile->AuthMode & WPS_AUTH_SAE) && (wifi_profile->AuthMode & WPS_AUTH_WPA2PSK)) {
				os_strlcpy(auth_str, "WPA-PSK SAE", sizeof("WPA-PSK SAE"));
#ifdef MAP_R6
			if (wifi_profile->AuthMode & AUTH_SAE_AKM24)
				wapp_uci_update(wdev->ifname, "encryption", "psk2-sae-sae-ext");
			else
				wapp_uci_update(wdev->ifname, "encryption", "sae-mixed");
#else
				wapp_uci_update(wdev->ifname, "encryption", "sae-mixed");
#endif
				wapp_uci_update(wdev->ifname, "key", (char *)wifi_profile->WPAKey);
				wapp_uci_update(wdev->ifname, "key1", "");
				wapp_uci_update(wdev->ifname, "sae_pwe", HAPD_CONF_SAE_PWE);
				wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_NON_6G);
			} else if (wifi_profile->AuthMode & WPS_AUTH_SAE) {
#ifdef MAP_R6
				if (wifi_profile->AuthMode & AUTH_SAE_AKM24)
					wapp_uci_update(wdev->ifname, "encryption", "sae-sae-ext");
				else
					wapp_uci_update(wdev->ifname, "encryption", "sae");
#else
				wapp_uci_update(wdev->ifname, "encryption", "sae");
#endif
				wapp_uci_update(wdev->ifname, "key", (char *)wifi_profile->WPAKey);
				wapp_uci_update(wdev->ifname, "key1", "");
				wapp_uci_update(wdev->ifname, "sae_pwe", HAPD_CONF_SAE_PWE);
				wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_6G);
			} else if ((wifi_profile->AuthMode & WPS_AUTH_WPA2PSK) && (wifi_profile->AuthMode & WPS_AUTH_WPAPSK)) {
				switch (wifi_profile->EncrypType & (WSC_ENCRTYPE_TKIP | WSC_ENCRTYPE_AES)) {
				case WSC_ENCRTYPE_TKIP:
					wapp_uci_update(wdev->ifname, "encryption", "psk-mixed+tkip");
					break;
				case (WSC_ENCRTYPE_TKIP | WSC_ENCRTYPE_AES):
					wapp_uci_update(wdev->ifname, "encryption", "psk-mixed+tkip+ccmp");
					break;
				case WSC_ENCRTYPE_AES:
				default:
					wapp_uci_update(wdev->ifname, "encryption", "psk-mixed+ccmp");
					break;
				}
				wapp_uci_update(wdev->ifname, "key", (char *)wifi_profile->WPAKey);
				wapp_uci_update(wdev->ifname, "key1", "");
				wapp_uci_update(wdev->ifname, "sae_pwe", "");
				wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_NON_6G);
			} else if (wifi_profile->AuthMode & WPS_AUTH_WPA2PSK) {
				switch (wifi_profile->EncrypType & (WSC_ENCRTYPE_TKIP | WSC_ENCRTYPE_AES)) {
				case WSC_ENCRTYPE_TKIP:
					wapp_uci_update(wdev->ifname, "encryption", "psk2+tkip");
					break;
				case (WSC_ENCRTYPE_TKIP | WSC_ENCRTYPE_AES):
					wapp_uci_update(wdev->ifname, "encryption", "psk2+tkip+ccmp");
					break;
				case WSC_ENCRTYPE_AES:
				default:
					wapp_uci_update(wdev->ifname, "encryption", "psk2+ccmp");
					break;
				}
				wapp_uci_update(wdev->ifname, "key", (char *)wifi_profile->WPAKey);
				wapp_uci_update(wdev->ifname, "key1", "");
				wapp_uci_update(wdev->ifname, "sae_pwe", "");
				wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_NON_6G);
			} else if ((wifi_profile->AuthMode & WPS_AUTH_WPA2) && (wifi_profile->AuthMode & WPS_AUTH_WPA)) {
				switch (wifi_profile->EncrypType & (WSC_ENCRTYPE_TKIP | WSC_ENCRTYPE_AES)) {
				case WSC_ENCRTYPE_TKIP:
					wapp_uci_update(wdev->ifname, "encryption", "wpa-mixed+tkip");
					break;
				case (WSC_ENCRTYPE_TKIP | WSC_ENCRTYPE_AES):
					wapp_uci_update(wdev->ifname, "encryption", "wpa-mixed+tkip+ccmp");
					break;
				case WSC_ENCRTYPE_AES:
				default:
					wapp_uci_update(wdev->ifname, "encryption", "wpa-mixed+ccmp");
					break;
				}
				wapp_uci_update(wdev->ifname, "key", "");
				wapp_uci_update(wdev->ifname, "key1", "");
				wapp_uci_update(wdev->ifname, "sae_pwe", "");
				wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_NON_6G);
			} else if (wifi_profile->AuthMode & WPS_AUTH_WPA2) {
				switch (wifi_profile->EncrypType & (WSC_ENCRTYPE_TKIP | WSC_ENCRTYPE_AES)) {
				case WSC_ENCRTYPE_TKIP:
					wapp_uci_update(wdev->ifname, "encryption", "wpa2+tkip");
					break;
				case (WSC_ENCRTYPE_TKIP | WSC_ENCRTYPE_AES):
					wapp_uci_update(wdev->ifname, "encryption", "wpa2+tkip+ccmp");
					break;
				case WSC_ENCRTYPE_AES:
				default:
					wapp_uci_update(wdev->ifname, "encryption", "wpa2+ccmp");
					break;
				}
				wapp_uci_update(wdev->ifname, "key", "");
				wapp_uci_update(wdev->ifname, "key1", "");
				wapp_uci_update(wdev->ifname, "sae_pwe", "");
				wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_NON_6G);
			} else if (wifi_profile->AuthMode & WPS_AUTH_WPA) {
				switch (wifi_profile->EncrypType & (WSC_ENCRTYPE_TKIP | WSC_ENCRTYPE_AES)) {
				case WSC_ENCRTYPE_TKIP:
					wapp_uci_update(wdev->ifname, "encryption", "wpa+tkip");
					break;
				case (WSC_ENCRTYPE_TKIP | WSC_ENCRTYPE_AES):
					wapp_uci_update(wdev->ifname, "encryption", "wpa+tkip+ccmp");
					break;
				case WSC_ENCRTYPE_AES:
				default:
					wapp_uci_update(wdev->ifname, "encryption", "wpa+ccmp");
					break;
				}
				wapp_uci_update(wdev->ifname, "key", "");
				wapp_uci_update(wdev->ifname, "key1", "");
				wapp_uci_update(wdev->ifname, "sae_pwe", "");
				wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_NON_6G);
			} else if (wifi_profile->AuthMode & WPS_AUTH_WPAPSK) {
				switch (wifi_profile->EncrypType & (WSC_ENCRTYPE_TKIP | WSC_ENCRTYPE_AES)) {
				case WSC_ENCRTYPE_TKIP:
					wapp_uci_update(wdev->ifname, "encryption", "psk+tkip");
					break;
				case (WSC_ENCRTYPE_TKIP | WSC_ENCRTYPE_AES):
					wapp_uci_update(wdev->ifname, "encryption", "psk+tkip+ccmp");
					break;
				case WSC_ENCRTYPE_AES:
				default:
					wapp_uci_update(wdev->ifname, "encryption", "psk+ccmp");
					break;
				}
				wapp_uci_update(wdev->ifname, "key", (char *)wifi_profile->WPAKey);
				wapp_uci_update(wdev->ifname, "key1", "");
				wapp_uci_update(wdev->ifname, "sae_pwe", "");
				wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_NON_6G);
			} else if (wifi_profile->AuthMode & (WPS_AUTH_OPEN | WPS_AUTH_SHARED)) {
				if (wifi_profile->EncrypType & WSC_ENCRTYPE_WEP) {
					wapp_uci_update(wdev->ifname, "encryption", "wep+auto");
					wapp_uci_update(wdev->ifname, "key", "1");
					wapp_uci_update(wdev->ifname, "key1", (char *)wifi_profile->WPAKey);
				}
				wapp_uci_update(wdev->ifname, "sae_pwe", "");
				wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_NON_6G);
			} else if (wifi_profile->AuthMode & WPS_AUTH_OPEN) {
				if (wifi_profile->EncrypType & WSC_ENCRTYPE_WEP) {
					wapp_uci_update(wdev->ifname, "encryption", "wep+open");
					wapp_uci_update(wdev->ifname, "key", "1");
					wapp_uci_update(wdev->ifname, "key1", (char *)wifi_profile->WPAKey);
				} else {
					wapp_uci_update(wdev->ifname, "encryption", "none");
					wapp_uci_update(wdev->ifname, "key", "");
					wapp_uci_update(wdev->ifname, "key1", "");
				}
				wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_NON_6G);
				wapp_uci_update(wdev->ifname, "sae_pwe", "");
			} else if (wifi_profile->AuthMode & WPS_AUTH_SHARED) {
				if (wifi_profile->EncrypType & WSC_ENCRTYPE_WEP) {
					wapp_uci_update(wdev->ifname, "encryption", "wep+shared");
					wapp_uci_update(wdev->ifname, "key", "1");
					wapp_uci_update(wdev->ifname, "key1", (char *)wifi_profile->WPAKey);
				}
				wapp_uci_update(wdev->ifname, "sae_pwe", "");
				wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_NON_6G);
			} else {
				wapp_uci_update(wdev->ifname, "ieee80211w", HAPD_CONF_PMF_NON_6G);
				wapp_uci_update(wdev->ifname, "encryption", "none");
				wapp_uci_update(wdev->ifname, "key", "");
				wapp_uci_update(wdev->ifname, "key1", "");
				wapp_uci_update(wdev->ifname, "sae_pwe", "");
			}
#ifdef MAP_6E_SUPPORT
	}
#endif
	return 0;
}

int wdev_set_hapd_param(struct wifi_app *wapp, struct wapp_dev *wdev,
		char *param, char *val)
{
	int ret = 0;

	notice(DEBUG_CAT_WIFI_CONFIG, "%sWdev =%s\n", __func__, wdev->ifname);
	ret = wapp_uci_update(wdev->ifname, param, val);
	return ret;
}
#endif /* MTK_HOSTAPD_SUPPORT */

#ifdef MTK_MLO_MAP_SUPPORT
int wapp_get_mlo_info(struct wifi_app *wapp, const char *iface, char *msg, size_t msg_len)
{
	if (wapp->drv_ops->drv_get_mlo_info)
		return wapp->drv_ops->drv_get_mlo_info(wapp->drv_data, iface, msg, &msg_len);

	return -1;
}
#endif

int wapp_get_wsc_profiles(struct wifi_app *wapp, const char *iface, char *msg, int *msg_len)
{

	if (wapp->drv_ops->drv_get_wsc_profiles)
		return wapp->drv_ops->drv_get_wsc_profiles(wapp->drv_data, iface, msg, msg_len);
	return -1;
}

int wapp_get_wdev_from_driver(struct wifi_app *wapp, const char *iface, char *msg, size_t msg_len)
{

	if (wapp->drv_ops->drv_get_wdev)
		return wapp->drv_ops->drv_get_wdev(wapp->drv_data, iface, msg, msg_len);
	return -1;
}
#ifdef MAP_R2
#ifdef DFS_CAC_R2

int wapp_get_cac_cap(struct wifi_app *wapp, const char *iface, char *msg, size_t msg_len)
{

	if (wapp->drv_ops->drv_get_cac_cap)
		return wapp->drv_ops->drv_get_cac_cap(wapp->drv_data, iface, msg, msg_len);
	return -1;
}

int wapp_set_channel_monitor_assign(struct wifi_app *wapp, const char *iface, char *msg, size_t msg_len)
{
	int ret = 0;


	ret = wapp->drv_ops->drv_set_monitor_ch_assign(wapp->drv_data, iface, msg, msg_len);

	return ret;
}

int wapp_get_channel_avail_ch_list(struct wifi_app *wapp, const char *iface, char *msg, size_t msg_len)
{
	int ret = 0;


	ret = wapp->drv_ops->drv_get_ch_avail_list(wapp->drv_data, iface, msg, msg_len);

	return ret;
}

#endif
#endif

#ifdef MAP_R4_SPT
int wapp_get_spt_reuse_req(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_get_spt_reuse_req(wapp->drv_data, iface, buf, &buf_len);

	return ret;
}
#endif/* MAP_R4_SPT*/

int wapp_set_air_mnt_en(struct wifi_app *wapp, const char *iface, const u8 flag)
{
	int ret = 0;

	if (wapp->drv_ops->drv_set_air_mnt_en)
		ret = wapp->drv_ops->drv_set_air_mnt_en(wapp->drv_data, iface, flag);

	return ret;
}

int wapp_set_air_mnt_rule(struct wifi_app *wapp, const char *iface, const char *buf,
		size_t buf_len)
{
	int ret = 0;

	if (wapp->drv_ops->drv_set_air_mnt_rule)
		ret = wapp->drv_ops->drv_set_air_mnt_rule(wapp->drv_data, iface, buf, buf_len);

	return ret;
}

int wapp_set_air_mnt_sta_id(struct wifi_app *wapp, const char *iface, const u8 id,
		const char *sta_mac)
{
	int ret = 0;

	if (wapp->drv_ops->drv_set_air_mnt_sta_id)
		ret = wapp->drv_ops->drv_set_air_mnt_sta_id(wapp->drv_data, iface, id, sta_mac);

	return ret;
}

int wapp_get_air_mnt_results(struct wifi_app *wapp, const char *iface, char *buf,
		size_t buf_len)
{
	int ret = 0;

	if (wapp->drv_ops->drv_get_air_mnt_result)
		ret = wapp->drv_ops->drv_get_air_mnt_result(wapp->drv_data, iface, buf, &buf_len);

	return ret;
}

int wapp_set_air_mnt_max_pkt(struct wifi_app *wapp, const char *iface, const u32 pkt_num)
{
	int ret = 0;

	if (wapp->drv_ops->drv_set_air_mnt_max_pkt)
		ret = wapp->drv_ops->drv_set_air_mnt_max_pkt(wapp->drv_data, iface, pkt_num);

	return ret;
}

/* Send Beacon Req to hostapd */
int wapp_send_beacon_req(struct wifi_app *wapp, const char *iface,
		const u8 *peer_mac_addr, const u8 req_mode,
		const char *bcn_req, size_t bcn_req_len)
{
	int ret = 0;

	notice(DEBUG_CAT_MISC, "peer_mac_addr " MACSTR " len %d\n", MAC2STR(peer_mac_addr), (UINT32)bcn_req_len);

	if (wapp->drv_ops->drv_send_bcn_req)
		ret = wapp->drv_ops->drv_send_bcn_req(wapp->drv_data, iface, peer_mac_addr,
				req_mode, bcn_req, bcn_req_len);

	return ret;
}

#ifdef MTK_HOSTAPD_SUPPORT
int wapp_send_dpp_peer_mac(struct wifi_app *wapp, const char *iface, struct dpp_authentication *auth)
{
	int ret = 0;


	if (wapp->drv_ops->drv_set_dpp_peermac)
		ret = wapp->drv_ops->drv_set_dpp_peermac(wapp->drv_data, iface, auth);

	return ret;
}

int wdev_send_get_pmk(struct wifi_app *wapp, struct wapp_dev *wdev, const u8 *peer_mac_addr, u8 *buf)
{
	int ret = -1;

	if (!wapp || !wdev)
		return WAPP_INVALID_ARG;

	notice(DEBUG_CAT_DPP,
		     "\t ifname = %s\n",
		     wdev->ifname);
	debug(DEBUG_CAT_DPP, "peer_mac_addr " MACSTR "\n", MAC2STR(peer_mac_addr));

	if (wapp->drv_ops->drv_send_get_pmk) {
		ret = wapp->drv_ops->drv_send_get_pmk(wapp->drv_data, wdev->ifname, (char *)peer_mac_addr, (char *)buf);
		if (ret < 0)
			err(DEBUG_CAT_DPP, "get pmk, command failed.\n");
		notice(DEBUG_CAT_DPP, "pmk queried for connected STA  = %02x:%02x:%02x:%02x:%02x:%02x\n", PRINT_MAC(peer_mac_addr));
	}

	return ret;
}

#endif /* MTK_HOSTAPD_SUPPORT */

int wapp_set_BhAssocCtrl(struct wifi_app *wapp, const char *iface, char *buf,
		size_t buf_len)
{
	int ret;

	ret = wapp->drv_ops->drv_set_BhAssocCtrl(wapp->drv_data, iface, buf, &buf_len);
	return ret;
}

#ifdef DFS_SLAVE_SUPPORT
void wapp_bhstatus_event(struct wifi_app *wapp, char *data)
{
	struct BH_STATUS_MSG *pBhStatus = (struct BH_STATUS_MSG *)data;

	notice(DEBUG_CAT_MISC, "[DFS-SLAVE]BH-Status:%d inf_name:%s\n",
		pBhStatus->fBhStatus, pBhStatus->inf_name);

	/* In MAP mode, beacon control done based on MAP connection */
	if (wapp->map && wapp->map->TurnKeyEnable) {
		err(DEBUG_CAT_MISC,
			"[DFS-SLAVE]MAP enable ignore event from driver\n");
		return;
	}

	if (pBhStatus->fBhStatus)
		wapp_update_beacon(wapp, TRUE);
	else
		wapp_update_beacon(wapp, FALSE);
}

void wapp_update_beacon(struct wifi_app *wapp, char enable)
{
	struct wapp_dev *wdev, *wdev_temp = NULL;
	struct dl_list *dev_list = &wapp->dev_list;
	u8 prev_radio_id = 0xff;  /* same as band_idx in driver */
	u32 prev_adpt_id = 0xffffffff;
	struct BH_STATUS_MSG bh_status = {0};

	notice(DEBUG_CAT_MISC, "[DFS-SLAVE]enable:%d\n", enable);

	bh_status.fBhStatus = enable;

	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
		if (wdev->dev_type == WAPP_DEV_TYPE_AP &&
			(wdev->radio->radio_id != prev_radio_id ||
			wdev->radio->adpt_id != prev_adpt_id)) {
			notice(DEBUG_CAT_MISC, "[DFS-SLAVE]send oid on inf:%s radio_id:%d adpt_idx:0x%x\n",
				wdev->ifname, wdev->radio->radio_id, wdev->radio->adpt_id);
			wapp->drv_ops->drv_update_BhStatus(wapp->drv_data, wdev->ifname, (char *)&bh_status, sizeof(struct BH_STATUS_MSG));
			prev_radio_id = wdev->radio->radio_id;
			prev_adpt_id = wdev->radio->adpt_id;
		}
	}
}
#endif /* DFS_SLAVE_SUPPORT */
int wapp_get_radio_temperature(struct wifi_app *wapp, const char *iface,
						char *msg, size_t msg_len)
{
	int ret = 0;

	ret = wapp->drv_ops->drv_get_radio_cpu_temperature(wapp->drv_data, iface, msg, &msg_len);
	if (ret < 0)
		err(DEBUG_CAT_MISC, "%s get band temperature fail\n", __func__);
	return ret;
}

#ifdef MAP_VENDOR_SUPPORT
int wapp_set_map_vendor_ch_prio(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret = -1;

	if (wapp->drv_ops->drv_set_vendor_ch_pref_state)
		ret = wapp->drv_ops->drv_set_vendor_ch_pref_state(wapp->drv_data, iface, buf, &buf_len);

	return ret;
}

int wapp_set_map_vendor_nop_state(struct wifi_app *wapp, const char *iface, char *buf, size_t buf_len)
{
	int ret = -1;

	if (wapp->drv_ops->drv_set_vendor_nop_state)
		ret = wapp->drv_ops->drv_set_vendor_nop_state(wapp->drv_data, iface, buf, &buf_len);

	return ret;
}
#endif /* MAP_VENDOR_SUPPORT */

#ifdef STANDARD_NL_CMD
/*standard interface*/

unsigned char is_bit_set(unsigned int flag, unsigned int bit)
{
	return (flag & bit) == bit;
}


struct phy_info *wapp_get_hw_info(struct wifi_app *wapp, unsigned char *num_phys)
{
	if (!wapp->drv_ops ||
	    !wapp->drv_ops->drv_get_hw_info)
		return NULL;

	return wapp->drv_ops->drv_get_hw_info(wapp->drv_data, num_phys);
}

struct dev_info *wapp_get_devs(struct wifi_app *wapp, u8 *num_devs)
{
	if (!wapp->drv_ops ||
	    !wapp->drv_ops->drv_get_devs)
		return NULL;

	return wapp->drv_ops->drv_get_devs(wapp->drv_data, num_devs);
}

int wapp_get_dev(struct wifi_app *wapp, struct dev_info *dev)
{
	if (!wapp || !wapp->drv_ops || !wapp->drv_ops->drv_get_dev)
		return -1;

	return wapp->drv_ops->drv_get_dev(wapp->drv_data, dev);
}

char *get_phy_bw_str(unsigned int bw, char *buf, int max_len)
{
	int ret = 0, len = 0;
	unsigned char i = 0;

	if (bw == 0)
		return "INVALID";

	while (1) {
		if ((bw & BIT(i)) == 0) {
			i++;
			if (i == 5)
				break;
			continue;
		}
		switch (BIT(i)) {
		case PHY_BW_20:
			ret = snprintf(buf + len, max_len - len, "|%s", "20");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf error\n");
				return "INVALID";
			}
			len += ret;
			break;
		case PHY_BW_40:
			ret = snprintf(buf + len, max_len - len, "|%s", "40");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf error\n");
				return "INVALID";
			}
			len += ret;
			break;
		case PHY_BW_80:
			ret = snprintf(buf + len, max_len - len, "|%s", "80");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf error\n");
				return "INVALID";
			}
			len += ret;
			break;
		case PHY_BW_160:
			ret = snprintf(buf + len, max_len - len, "|%s", "160");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf error\n");
				return "INVALID";
			}
			len += ret;
			break;
		case PHY_BW_320:
			ret = snprintf(buf + len, max_len - len, "|%s", "320");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf error\n");
				return "INVALID";
			}
			len += ret;
			break;
		default:
			return "INVALID";
		}
		i++;
		if (i == 5)
			break;
	}

	return buf;
}

char *get_chan_bw_str(unsigned int bw, char *buf, int max_len)
{
	int ret = 0, len = 0;
	unsigned char i = 0;

	if (bw == 0)
		return "INVALID";

	while (1) {
		if ((bw & BIT(i)) == 0) {
			i++;
			if (i == 6)
				break;
			continue;
		}
		switch (BIT(i)) {
		case CHAN_WIDTH_20:
			ret = snprintf(buf + len, max_len - len, "|%s", "20");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf error\n");
				return "INVALID";
			}
			len += ret;
			break;
		case CHAN_WIDTH_40P:
			ret = snprintf(buf + len, max_len - len, "|%s", "40P");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf error\n");
				return "INVALID";
			}
			len += ret;
			break;
		case CHAN_WIDTH_40M:
			ret = snprintf(buf + len, max_len - len, "|%s", "40M");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf error\n");
				return "INVALID";
			}
			len += ret;
			break;
		case CHAN_WIDTH_80:
			ret = snprintf(buf + len, max_len - len, "|%s", "80");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf error\n");
				return "INVALID";
			}
			len += ret;
			break;
		case CHAN_WIDTH_160:
			ret = snprintf(buf + len, max_len - len, "|%s", "160");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf error\n");
				return "INVALID";
			}
			len += ret;
			break;
		case CHAN_WIDTH_320:
			ret = snprintf(buf + len, max_len - len, "|%s", "320");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf error\n");
				return "INVALID";
			}
			len += ret;
			break;
		default:
			return "INVALID";
		}
		i++;
		if (i == 6)
			break;
	}

	return buf;
}

char *get_phy_mode_str(unsigned int mode, char *buf, int max_len)
{
	int ret = 0, len = 0;
	unsigned char i = 0;

	if (mode == 0)
		return "INVALID";

	while (1) {
		if ((mode & BIT(i)) == 0) {
			i++;
			if (i == 12)
				break;
			continue;
		}
		switch (BIT(i)) {
		case WMODE_A:
			ret = snprintf(buf + len, max_len - len, "|%s", "A");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf error\n");
				return "INVALID";
			}
			len += ret;
			break;
		case WMODE_B:
			ret = snprintf(buf + len, max_len - len, "|%s", "B");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf error\n");
				return "INVALID";
			}
			len += ret;
			break;
		case WMODE_G:
			ret = snprintf(buf + len, max_len - len, "|%s", "G");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf error\n");
				return "INVALID";
			}
			len += ret;
			break;
		case WMODE_GN:
			ret = snprintf(buf + len, max_len - len, "|%s", "GN");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf error\n");
				return "INVALID";
			}
			len += ret;
			break;
		case WMODE_AN:
			ret = snprintf(buf + len, max_len - len, "|%s", "AN");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf error\n");
				return "INVALID";
			}
			len += ret;
			break;
		case WMODE_AC:
			ret = snprintf(buf + len, max_len - len, "|%s", "AC");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf error\n");
				return "INVALID";
			}
			len += ret;
			break;
		case WMODE_AX_24G:
			ret = snprintf(buf + len, max_len - len, "|%s", "AX_24G");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf error\n");
				return "INVALID";
			}
			len += ret;
			break;
		case WMODE_AX_5G:
			ret = snprintf(buf + len, max_len - len, "|%s", "AX_5G");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf error\n");
				return "INVALID";
			}
			len += ret;
			break;
		case WMODE_AX_6G:
			ret = snprintf(buf + len, max_len - len, "|%s", "AX_6G");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf error\n");
				return "INVALID";
			}
			len += ret;
			break;
#if defined(MTK_HOSTAPD_SUPPORT) || defined(MTK_MLO_MAP_SUPPORT)
		case WMODE_BE_24G:
			ret = snprintf(buf + len, max_len - len, "|%s", "BE_24G");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf error\n");
				return "INVALID";
			}
			len += ret;
			break;
		case WMODE_BE_5G:
			ret = snprintf(buf + len, max_len - len, "|%s", "BE_5G");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf error\n");
				return "INVALID";
			}
			len += ret;
			break;
		case WMODE_BE_6G:
			ret = snprintf(buf + len, max_len - len, "|%s", "BE_6G");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf error\n");
				return "INVALID";
			}
			len += ret;
			break;
#endif
		default:
			return "INVALID";
		}
		i++;
		if (i == 12)
			break;
	}

	return buf;
}

int dump_phy_info(struct wifi_app *wapp, char *buf, size_t max_len)
{
	struct channel_data *chan = NULL;
	unsigned char i = 0;
	struct phy_info *phy = NULL;
	int ret = 0, len = 0;
	char buf1[256] = {0};
	char buf2[256] = {0};

	ret = snprintf(buf + len, max_len - len, "\nphy info:");
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	dl_list_for_each(phy, &wapp->phy_head, struct phy_info, list) {
		ret = snprintf(buf + len, max_len - len,
			"\n\tphy_id=%d; ch_num=%d; ht_capab=%04x; ht_set=%d; vht_capab=%04x; vht_set=%d\n"
			"\t flags=0x%08x; bw=0x%08x(%s); mode=%04x(%s)\n",
			phy->phy_id, phy->num_channels,
			phy->ht_capab, phy->ht_set, phy->vht_capab, phy->vht_set,
			phy->flags,
			phy->bw, get_phy_bw_str(phy->bw, buf1, 256),
			phy->mode, get_phy_mode_str(phy->bw, buf2, 256));
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;

		ret = snprintf(buf + len, max_len - len, "\t mcs_set=");
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;
		for (i = 0; i < ARRAY_SIZE(phy->mcs_set); i++) {
			ret = snprintf(buf + len, max_len - len, "0x%02x ", phy->mcs_set[i]);
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf fail\n");
				return -1;
			}
			len += ret;
		}
		ret = snprintf(buf + len, max_len - len, "\n");
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;

		ret = snprintf(buf + len, max_len - len, "\t vht_mcs_set=");
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;
		for (i = 0; i < ARRAY_SIZE(phy->vht_mcs_set); i++) {
			ret = snprintf(buf + len, max_len - len, "0x%02x ", phy->vht_mcs_set[i]);
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf fail\n");
				return -1;
			}
			len += ret;
		}
		ret = snprintf(buf + len, max_len - len, "\n");
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;

		for (i = 0; i < phy->num_channels; i++) {
			chan = &phy->channels[i];
			ret = snprintf(buf + len, max_len - len,
					"\t ch=%d; freq=%d; flag=0x%08x; allowed_bw=0x%08x(%s); dfs_cac=%ds; dfs=%ds\n",
					chan->chan, chan->freq, chan->flag,
					chan->allowed_bw, get_chan_bw_str(chan->allowed_bw, buf1, 256),
					chan->dfs_cac_ms / 1000, chan->dfs_ms / 1000);
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf fail\n");
				return -1;
			}
			len += ret;
		}
	}

	return len;
}

char *get_dev_bw_str(unsigned char bw)
{
	switch (bw) {
	case CHAN_WIDTH_20:
		return "CHAN_WIDTH_20";
	case CHAN_WIDTH_40P:
		return "CHAN_WIDTH_40P";
	case CHAN_WIDTH_40M:
		return "CHAN_WIDTH_40M";
	case CHAN_WIDTH_80:
		return "CHAN_WIDTH_80";
	case CHAN_WIDTH_160:
		return "CHAN_WIDTH_160";
	case CHAN_WIDTH_320:
		return "CHAN_WIDTH_320";
	default:
		return "CHAN_WIDTH_INVALID";
	}
}

char *get_dev_iftype_str(int iftype)
{
	switch (iftype) {
	case NL80211_IFTYPE_STATION:
		return "NL80211_IFTYPE_STATION";
	case NL80211_IFTYPE_AP:
		return "NL80211_IFTYPE_AP";
	case NL80211_IFTYPE_AP_VLAN:
		return "NL80211_IFTYPE_AP_VLAN";
	default:
		return "UNKNOWN_NL80211_IFTYPE";
	}
}


int dump_dev_info(struct wifi_app *wapp, char *buf, size_t max_len)
{
	struct dev_info *dev = NULL;
	int ret = 0, len = 0;

	ret = snprintf(buf + len, max_len - len, "\ndev info:");
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	dl_list_for_each(dev, &wapp->hdev_head, struct dev_info, list) {
		ret = snprintf(buf + len, max_len - len,
			"\n\tifname=%s; ssid=%s; mac="MACSTR"; valid=%d; phy_id=%d; ifindex=%d; iftype=%d(%s)\n"
			"\t ch=%d; freq=%d; center1=%d; center2=%d; bw=%d(%s);"
			" txpower=%ddbm; use_4addr=%d; mesh_disable=%d ssid_len=%d\n",
			dev->ifname, dev->ssid, MAC2STR(dev->mac), dev->valid, dev->phy_id, dev->ifindex,
			dev->iftype, get_dev_iftype_str(dev->iftype),
			dev->ch, dev->freq, dev->center1, dev->center2,
			dev->bw, get_dev_bw_str(dev->bw),
			dev->txpower, dev->use_4addr, dev->mesh_disable, dev->ssid_len);
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;
	}

	return len;
}

int check_6G_by_freq(unsigned int freq)
{
	if (freq < MIN_6G_FREQ || freq > MAX_6G_FREQ)
		return 0;
	else
		return 1;
}

int check_5G_by_freq(unsigned int freq)
{
	if (freq < MIN_5GL_FREQ || freq > MAX_5GH_FREQ)
		return 0;
	else
		return 1;
}

int check_5GL_by_freq(unsigned int freq)
{
	if (freq < MIN_5GL_FREQ || freq > MAX_5GL_FREQ)
		return 0;
	else
		return 1;
}

int check_5GH_by_freq(unsigned int freq)
{
	if (freq < MIN_5GH_FREQ || freq > MAX_5GH_FREQ)
		return 0;
	else
		return 1;
}

int check_2G_by_freq(unsigned int freq)
{
	if (freq < MIN_2G_FREQ || freq > MAX_2G_FREQ)
		return 0;
	else
		return 1;
}

unsigned char check_freq_valid(int freq, int freq_min, int freq_max)
{
	if (check_5GL_by_freq(freq)) {
		if (freq_min < MIN_5GL_FREQ ||
			freq_max > MAX_5GL_FREQ)
			return 0;
	} else if (check_5GH_by_freq(freq)) {
		if (freq_min < MIN_5GH_FREQ ||
			freq_max > MAX_5GH_FREQ)
			return 0;
	} else if (check_2G_by_freq(freq)) {
		if (freq_min < MIN_2G_FREQ ||
			freq_max > MAX_2G_FREQ)
			return 0;
	} else if (check_6G_by_freq(freq)) {
		if (freq_min < MIN_6G_FREQ ||
			freq_max > MAX_6G_FREQ)
			return 0;
	}

	return 1;
}

int get_cent_freq(int freq, int cent_ch[], int size)
{
	int chan = 0, index = 0, i = 0;
	int min_diff = 0, current_diff = 0;

	ieee80211_freq_to_chan(freq, (u8 *)&chan);

	min_diff = abs(chan - cent_ch[0]);
	for (i = 1; i < size; i++) {
		current_diff = abs(chan - cent_ch[i]);
		if (current_diff < min_diff) {
			min_diff = current_diff;
			index = i;
		}
	}
	return cent_ch[index];
}

unsigned char check_freq_bw_allow(struct phy_info *phy, int freq, unsigned int bw)
{
	int freq_min = 0, freq_max = 0;
	int cfreq = 0, cchan = 0;
	unsigned int ret = 0;
	unsigned short chan = 0;
	unsigned char i = 0;
	char buf[256] = {0};

	if (bw == CHAN_WIDTH_40P) {
		freq_min = freq;
		freq_max = freq + 4 * 5;
		ret = check_freq_valid(freq, freq_min, freq_max);
		if (ret == 0)
			goto fail;
		for (i = 0; i < phy->num_channels; i++) {
			if (phy->channels[i].freq >= freq_min &&
				phy->channels[i].freq <= freq_max) {
				if (is_bit_set(phy->channels[i].flag, CHAN_DISABLED))
					goto fail;
			}
		}
	} else if (bw == CHAN_WIDTH_40M) {
		freq_min = freq - 4 * 5;
		freq_max = freq;
		ret = check_freq_valid(freq, freq_min, freq_max);
		if (ret == 0)
			goto fail;
		for (i = 0; i < phy->num_channels; i++) {
			if (phy->channels[i].freq >= freq_min &&
				phy->channels[i].freq <= freq_max) {
				if (is_bit_set(phy->channels[i].flag, CHAN_DISABLED))
					goto fail;
			}
		}
	} else if (bw == (CHAN_WIDTH_40M | CHAN_WIDTH_40P)) {
		int cent_6g[29] = {3, 11, 19, 27, 35, 43,
			51, 59, 67, 75, 83, 91, 99, 107, 115, 123, 131, 139, 147, 155, 163, 171,
			179, 187, 195, 203, 211, 219, 227};

		cchan = get_cent_freq(freq, cent_6g, 29);
		cfreq = (cchan - 1) * 5 + MIN_6G_FREQ;
		for (i = 0; i < phy->num_channels; i++) {
			if (abs(phy->channels[i].freq - cfreq) <= 2 * 5) {
				if (is_bit_set(phy->channels[i].flag, CHAN_DISABLED))
					goto fail;
			}
		}
	} else if (bw == CHAN_WIDTH_80) {
		int cent_5g[7] = {42, 58, 106, 122, 138, 155, 171};
		int cent_6g[14] = {7, 23, 39, 55, 71, 87, 103, 119, 135, 151, 167, 183, 199, 215};

		if (check_5G_by_freq(freq)) {
			cchan = get_cent_freq(freq, cent_5g, 7);
			cfreq = (cchan - 36) * 5 + MIN_5GL_FREQ;
		} else {
			cchan = get_cent_freq(freq, cent_6g, 14);
			cfreq = (cchan - 1) * 5 + MIN_6G_FREQ;
		}

		for (i = 0; i < phy->num_channels; i++) {
			if (abs(phy->channels[i].freq - cfreq) <= 6 * 5) {
				if (is_bit_set(phy->channels[i].flag, CHAN_DISABLED))
					goto fail;
			}
		}
	} else if (bw == CHAN_WIDTH_160) {
		int cent_5g[3] = {50, 114, 163};
		int cent_6g[7] = {15, 47, 79, 111, 143, 175, 207};

		if (check_5G_by_freq(freq)) {
			cchan = get_cent_freq(freq, cent_5g, 3);
			cfreq = (cchan - 36) * 5 + MIN_5GL_FREQ;
		} else {
			cchan = get_cent_freq(freq, cent_6g, 7);
			cfreq = (cchan - 1) * 5 + MIN_6G_FREQ;
		}

		for (i = 0; i < phy->num_channels; i++) {
			if (abs(phy->channels[i].freq - cfreq) <= 14 * 5) {
				if (is_bit_set(phy->channels[i].flag, CHAN_DISABLED))
					goto fail;
			}
		}
	} else if (bw == CHAN_WIDTH_320) {
		int cent_6g[6] = {31, 63, 95, 127, 159, 191};

		cchan = get_cent_freq(freq, cent_6g, 6);
		cfreq = (cchan - 1) * 5 + MIN_6G_FREQ;
		for (i = 0; i < phy->num_channels; i++) {
			if (abs(phy->channels[i].freq - cfreq) <= 30 * 5) {
				if (is_bit_set(phy->channels[i].flag, CHAN_DISABLED))
					goto fail;
			}
		}
	}

	return 1;
fail:
	ieee80211_freq_to_chan(freq, (u8 *)&chan);
	info(DEBUG_CAT_MISC, "freq=%d(chan=%d) not support bw=%d(%s)\n",
		freq, chan, bw, get_chan_bw_str(bw, buf, 256));

	return 0;
}

void phy_bw_reset(struct phy_info *phy)
{
	unsigned char i = 0;
	unsigned char ret = 0;

	if (check_5G_by_freq(phy->channels[0].freq)) {
		for (i = 0; i < phy->num_channels; i++) {
			if (is_bit_set(phy->channels[i].flag, CHAN_DISABLED))
				continue;
			phy->channels[i].allowed_bw &= ~CHAN_WIDTH_320;
			ret = check_freq_bw_allow(phy, phy->channels[i].freq, CHAN_WIDTH_40P);
			if (ret == 0)
				phy->channels[i].allowed_bw &= ~CHAN_WIDTH_40P;
			ret = check_freq_bw_allow(phy, phy->channels[i].freq, CHAN_WIDTH_40M);
			if (ret == 0)
				phy->channels[i].allowed_bw &= ~CHAN_WIDTH_40M;
			ret = check_freq_bw_allow(phy, phy->channels[i].freq, CHAN_WIDTH_80);
			if (ret == 0)
				phy->channels[i].allowed_bw &= ~CHAN_WIDTH_80;
			ret = check_freq_bw_allow(phy, phy->channels[i].freq, CHAN_WIDTH_160);
			if (ret == 0)
				phy->channels[i].allowed_bw &= ~CHAN_WIDTH_160;
		}
	} else if (check_6G_by_freq(phy->channels[0].freq)) {
		for (i = 0; i < phy->num_channels; i++) {
			if (is_bit_set(phy->channels[i].flag, CHAN_DISABLED))
				continue;
			ret = check_freq_bw_allow(phy, phy->channels[i].freq, CHAN_WIDTH_40P | CHAN_WIDTH_40M);
			if (ret == 0)
				phy->channels[i].allowed_bw &= ~(CHAN_WIDTH_40P | CHAN_WIDTH_40M);
			ret = check_freq_bw_allow(phy, phy->channels[i].freq, CHAN_WIDTH_80);
			if (ret == 0)
				phy->channels[i].allowed_bw &= ~CHAN_WIDTH_80;
			ret = check_freq_bw_allow(phy, phy->channels[i].freq, CHAN_WIDTH_160);
			if (ret == 0)
				phy->channels[i].allowed_bw &= ~CHAN_WIDTH_160;
			ret = check_freq_bw_allow(phy, phy->channels[i].freq, CHAN_WIDTH_320);
			if (ret == 0)
				phy->channels[i].allowed_bw &= ~CHAN_WIDTH_320;
		}
	} else {
		for (i = 0; i < phy->num_channels; i++) {
			if (is_bit_set(phy->channels[i].flag, CHAN_DISABLED))
				continue;
			phy->channels[i].allowed_bw &= ~(CHAN_WIDTH_320 | CHAN_WIDTH_160 | CHAN_WIDTH_80);
			ret = check_freq_bw_allow(phy, phy->channels[i].freq, CHAN_WIDTH_40P);
			if (ret == 0)
				phy->channels[i].allowed_bw &= ~CHAN_WIDTH_40P;
			ret = check_freq_bw_allow(phy, phy->channels[i].freq, CHAN_WIDTH_40M);
			if (ret == 0)
				phy->channels[i].allowed_bw &= ~CHAN_WIDTH_40M;
		}
	}

}

void phy_radar_freq_reset(struct phy_info *phy)
{
	unsigned char i = 0;

	if (check_5G_by_freq(phy->channels[0].freq)) {
		for (i = 0; i < phy->num_channels; i++) {
			if (phy->channels[i].freq >= 5260 &&
				phy->channels[i].freq <= 5720)
				phy->channels[i].flag |= CHAN_RADAR;
		}
	}
}

int wapp_init_phy_devs(struct wifi_app *wapp, struct phy_info *phy, u8 num_phys,
		struct dev_info *dev, u8 num_devs)
{
	int ret = 0;
	int max_bw = 0, dev_exist = 0;
	unsigned char i = 0, j = 0, k = 0;
	char value[256] = {0};
	char *rem_strng = value, *token = NULL;

	for (i = 0; i < num_devs; i++) {
		if (dev[i].freq == 0) {
			warn(DEBUG_CAT_INIT, "no freq info for %s\n", dev[i].ifname);
			dev[i].valid = 0;
			continue;
		}
		dev[i].ch = ieee80211_frequency_to_channel(dev[i].freq);
		dev[i].bw = nl80211_bw_to_wifi_bw(dev[i].bw, dev[i].freq, dev[i].center1);
		if (dev[i].ch == 0 || dev[i].bw == CHAN_WIDTH_INVALID) {
			err(DEBUG_CAT_INIT, "can't find correct ch-%d and bw-%d for freq-%d for dev-%s\n",
				dev[i].ch, dev[i].bw, dev[i].freq, dev[i].ifname);
			return -1;
		}
	}
	for (j = 0; j < num_phys; j++) {
		phy_bw_reset(&phy[j]);
		phy_radar_freq_reset(&phy[j]);
		max_bw = 0;
		for (k = 0; k < phy[j].num_channels; k++) {
			dl_list_init(&phy[j].channels[k].scan_res_list);
			ieee80211_freq_to_chan(phy[j].channels[k].freq, (u8 *)&phy[j].channels[k].chan);
			if (!is_bit_set(phy[j].channels[k].flag, CHAN_DISABLED))
				max_bw |= phy[j].channels[k].allowed_bw;
		}
		if (max_bw & CHAN_WIDTH_320)
			phy[j].bw |= PHY_BW_320;
		if (max_bw & CHAN_WIDTH_160)
			phy[j].bw |= PHY_BW_160;
		if (max_bw & CHAN_WIDTH_80)
			phy[j].bw |= PHY_BW_80;
		if (max_bw & (CHAN_WIDTH_40P | CHAN_WIDTH_40M))
			phy[j].bw |= PHY_BW_40;
		if (max_bw & CHAN_WIDTH_20)
			phy[j].bw |= PHY_BW_20;
	}

	/* get all local interfaces */
	get_map_parameters(wapp->map, "bss_config_priority", value, NON_DRIVER_PARAM, sizeof(value));

	if (!strlen(value)) {
		for (i = 0; i < num_devs; i++) {
			if (strlen(dev[i].ifname)) {
				ret = snprintf(value + strlen(value),
					sizeof(value) - strlen(value), "%s;", dev[i].ifname);
				if (os_snprintf_error(sizeof(value) - strlen(value), ret)) {
					err(DEBUG_CAT_MISC, "snprintf bss interface name failed.\n");
					return -1;
				}
			}
		}
	}

	notice(DEBUG_CAT_INIT, "rem_strng: %s\n", rem_strng);

	if (strlen(value) > 0) {
		token = strtok_r(rem_strng, ";", &rem_strng);
		while (token) {
			dev_exist = 0;
			for (i = 0; i < num_devs; i++) {
				if (os_strncmp(token, dev[i].ifname, 16) == 0) {
					dev_exist = 1;
					break;
				}
			}
			if (!dev_exist)
				goto end;

			for (j = 0; j < num_phys; j++) {
				if (dev[i].phy_id == phy[j].phy_id)
					break;
			}

			if (j >= num_phys) {
				err(DEBUG_CAT_INIT, "init %s fail; can't get phy info\n", dev[i].ifname);
				goto end;
			}

			wapp_dev_create(wapp, dev[i].ifname, dev[i].ifindex, dev[i].mac);
#ifdef MAP_R5
			map_update_device_info_sd_nl(wapp, &dev[i]);
#endif
			switch (dev[i].iftype) {
			case NL80211_IFTYPE_AP:
				ret = wdev_ap_create_sd_nl(wapp, &dev[i], &phy[j]);
				if (ret < 0)
					return -1;
				break;
			case NL80211_IFTYPE_STATION:
				ret = wdev_sta_create_sd_nl(wapp, &dev[i], &phy[j]);
				if (ret < 0)
					return -1;
				break;
			default:
				err(DEBUG_CAT_INIT, "dev_type(%u) incorrect for %s\n", dev->iftype,
					dev->ifname);
				return -1;
			}
#if defined(DPP_SUPPORT) && !defined(MAP_R3)
			dpp_conf_init(wapp, dev[i].ifindex);
#endif /* DPP_SUPPORT && !MAP_R3*/

end:
			token = strtok_r(rem_strng, ";", &rem_strng);
		}
	}

	return 0;
}

int wapp_refine_phy_channels(struct wifi_app *wapp,
		struct wapp_radio *ra, struct phy_info *phy)
{
	unsigned char i = 0;

	if (!ra || !ra->radio_band || !phy) {
		err(DEBUG_CAT_MISC, "invalid input params\n");
		return -1;
	}

	if (!check_5G_by_freq(phy->channels[0].freq))
		return 0;

	for (i = 0; i < phy->num_channels; i++) {
		if (is_bit_set(phy->channels[i].flag, CHAN_DISABLED))
			continue;
		if (*ra->radio_band == RADIO_5GL &&
			phy->channels[i].chan >= 100) {
			phy->channels[i].flag |= CHAN_DISABLED;
		} else if (*ra->radio_band == RADIO_5GH &&
			phy->channels[i].chan < 100) {
			phy->channels[i].flag |= CHAN_DISABLED;
		}
	}

	return 0;
}


/**
 * ieee80211_freq_to_channel_ext - Convert frequency into channel info
 * for HT40, VHT, and HE. DFS channels are not covered.
 * @freq: Frequency (MHz) to convert
 * @sec_channel: 0 = non-HT40, 1 = sec. channel above, -1 = sec. channel below
 * @chanwidth: VHT/EDMG/etc. channel width
 * @op_class: Buffer for returning operating class
 * @channel: Buffer for returning channel number
 * Returns: hw_mode on success, NUM_MODES on failure
 */
u16 ieee80211_freq_to_channel_ext(unsigned int freq, int sec_channel,
			      enum oper_chan_width chanwidth,
			      u8 *op_class, u8 *channel)
{
	u8 vht_opclass = 0;

	/* TODO: more operating classes */

	if (sec_channel > 1 || sec_channel < -1)
		return WMODE_INVALID;

	if (freq >= 2412 && freq <= 2472) {
		if ((freq - 2407) % 5)
			return WMODE_INVALID;

		if (chanwidth != CONF_OPER_CHWIDTH_USE_HT)
			return WMODE_INVALID;

		/* 2.407 GHz, channels 1..13 */
		if (sec_channel == 1)
			*op_class = 83;
		else if (sec_channel == -1)
			*op_class = 84;
		else
			*op_class = 81;

		*channel = (freq - 2407) / 5;

		return WMODE_G;
	}

	if (freq == 2484) {
		if (sec_channel || chanwidth != CONF_OPER_CHWIDTH_USE_HT)
			return WMODE_INVALID;

		*op_class = 82; /* channel 14 */
		*channel = 14;

		return WMODE_B;
	}

	if (freq >= 4900 && freq < 5000) {
		if ((freq - 4000) % 5)
			return WMODE_INVALID;
		*channel = (freq - 4000) / 5;
		*op_class = 0; /* TODO */
		return WMODE_A;
	}

	switch (chanwidth) {
	case CONF_OPER_CHWIDTH_80MHZ:
		vht_opclass = 128;
		break;
	case CONF_OPER_CHWIDTH_160MHZ:
		vht_opclass = 129;
		break;
	case CONF_OPER_CHWIDTH_80P80MHZ:
		vht_opclass = 130;
		break;
	default:
		vht_opclass = 0;
		break;
	}

	/* 5 GHz, channels 36..48 */
	if (freq >= 5180 && freq <= 5240) {
		if ((freq - 5000) % 5)
			return WMODE_INVALID;

		if (vht_opclass)
			*op_class = vht_opclass;
		else if (sec_channel == 1)
			*op_class = 116;
		else if (sec_channel == -1)
			*op_class = 117;
		else
			*op_class = 115;

		*channel = (freq - 5000) / 5;

		return WMODE_A;
	}

	/* 5 GHz, channels 52..64 */
	if (freq >= 5260 && freq <= 5320) {
		if ((freq - 5000) % 5)
			return WMODE_INVALID;

		if (vht_opclass)
			*op_class = vht_opclass;
		else if (sec_channel == 1)
			*op_class = 119;
		else if (sec_channel == -1)
			*op_class = 120;
		else
			*op_class = 118;

		*channel = (freq - 5000) / 5;

		return WMODE_A;
	}

	/* 5 GHz, channels 149..177 */
	if (freq >= 5745 && freq <= 5885) {
		if ((freq - 5000) % 5)
			return WMODE_INVALID;

		if (vht_opclass)
			*op_class = vht_opclass;
		else if (sec_channel == 1)
			*op_class = 126;
		else if (sec_channel == -1)
			*op_class = 127;
		else if (freq <= 5805)
			*op_class = 124;
		else
			*op_class = 125;

		*channel = (freq - 5000) / 5;

		return WMODE_A;
	}

	/* 5 GHz, channels 100..144 */
	if (freq >= 5500 && freq <= 5720) {
		if ((freq - 5000) % 5)
			return WMODE_INVALID;

		if (vht_opclass)
			*op_class = vht_opclass;
		else if (sec_channel == 1)
			*op_class = 122;
		else if (sec_channel == -1)
			*op_class = 123;
		else
			*op_class = 121;

		*channel = (freq - 5000) / 5;

		return WMODE_A;
	}

	if (freq >= 5000 && freq < 5900) {
		if ((freq - 5000) % 5)
			return WMODE_INVALID;
		*channel = (freq - 5000) / 5;
		*op_class = 0; /* TODO */
		return WMODE_A;
	}

	if (freq > 5950 && freq <= 7115) {
		if ((freq - 5950) % 5)
			return WMODE_INVALID;

		switch (chanwidth) {
		case CONF_OPER_CHWIDTH_80MHZ:
			*op_class = 133;
			break;
		case CONF_OPER_CHWIDTH_160MHZ:
			*op_class = 134;
			break;
		case CONF_OPER_CHWIDTH_80P80MHZ:
			*op_class = 135;
			break;
		case CONF_OPER_CHWIDTH_320MHZ:
			*op_class = 137;
			break;
		default:
			if (sec_channel)
				*op_class = 132;
			else
				*op_class = 131;
			break;
		}

		*channel = (freq - 5950) / 5;
		return WMODE_A;
	}

	if (freq == 5935) {
		*op_class = 136;
		*channel = (freq - 5925) / 5;
		return WMODE_A;
	}

	return WMODE_INVALID;
}

u16 ieee80211_freq_to_chan(int freq, u8 *channel)
{
	u8 op_class = 0;

	return ieee80211_freq_to_channel_ext(freq, 0, CONF_OPER_CHWIDTH_USE_HT,
					     &op_class, channel);
}


int ieee80211_frequency_to_channel(int freq)
{
	/* see 802.11-2007 17.3.8.3.2 and Annex J */
	if (freq == 2484)
		return 14;
	/* see 802.11ax D6.1 27.3.23.2 and Annex E */
	else if (freq == 5935)
		return 2;
	else if (freq < 2484)
		return (freq - 2407) / 5;
	else if (freq >= 4910 && freq <= 4980)
		return (freq - 4000) / 5;
	else if (freq < 5950)
		return (freq - 5000) / 5;
	else if (freq <= 45000) /* DMG band lower limit */
		/* see 802.11ax D6.1 27.3.23.2 */
		return (freq - 5950) / 5;
	else if (freq >= 58320 && freq <= 70200)
		return (freq - 56160) / 2160;
	else
		return 0;
}


unsigned char nl80211_bw_to_wifi_bw(unsigned char bw,
	unsigned int freq, unsigned int cent_freq)
{
	switch (bw) {
	case NL80211_CHAN_WIDTH_20_NOHT:
	case NL80211_CHAN_WIDTH_20:
		return CHAN_WIDTH_20;
	case NL80211_CHAN_WIDTH_40:
		return get_40bw_by_freq(freq, cent_freq);
	case NL80211_CHAN_WIDTH_80:
		return CHAN_WIDTH_80;
	case NL80211_CHAN_WIDTH_80P80:
	case NL80211_CHAN_WIDTH_160:
		return CHAN_WIDTH_160;
	case NL80211_CHAN_WIDTH_320:
		return CHAN_WIDTH_320;
	default:
		err(DEBUG_CAT_MISC, "invalid 80211 bw(0x%02x)\n", bw);
		return CHAN_WIDTH_INVALID;
	}
}

#ifndef MAP_6E_SUPPORT
wdev_op_class_info *get_opclass_by_phy(struct wifi_app *wapp, unsigned char phy_id)
#else
struct _wdev_op_class_info_ext *get_opclass_by_phy(struct wifi_app *wapp,
	 unsigned char phy_id)
#endif
{
	struct dev_info *dev = NULL;
	struct wapp_dev *wdev = NULL;
	struct ap_dev *ap = NULL;

	dl_list_for_each(dev, &wapp->hdev_head, struct dev_info, list) {
		if (dev->phy_id == phy_id) {
			wdev = wapp_dev_list_lookup_by_ifname(wapp, dev->ifname);
			if (!wdev)
				return NULL;
			ap = (struct ap_dev *)wdev->p_dev;
			if (!ap)
				return NULL;
			if (ap->isActive != WAPP_BSS_START)
				continue;
			return &ap->op_class;
		}
	}

	return NULL;
}

unsigned char get_phy_id_by_radio_id(unsigned char *radio_id)
{
	if (!radio_id) {
		err(DEBUG_CAT_MISC, "invalid input parameter\n");
		return 0xff;
	}

	return radio_id[5];
}

struct phy_info *get_phy_by_phy_id(struct wifi_app *wapp, unsigned char phy_id)
{
	struct phy_info *phy = NULL;

	dl_list_for_each(phy, &wapp->phy_head, struct phy_info, list)
	{
		if (phy->phy_id == phy_id)
			return phy;
	}

	return NULL;
}

unsigned short wapp_get_freq_by_chan(struct wifi_app *wapp,
	unsigned char ch, unsigned char phy_id)
{
	struct phy_info *phy = NULL;
	unsigned char i = 0;

	if (!wapp) {
		err(DEBUG_CAT_MISC, "invalid input parameter\n");
		return 0;
	}

	dl_list_for_each(phy, &wapp->phy_head, struct phy_info, list)
	{
		if (phy->phy_id != phy_id)
			continue;
		for (i = 0; i < phy->num_channels; i++) {
			if (phy->channels[i].chan == ch)
				return phy->channels[i].freq;
		}
	}

	return 0;
}

struct phy_info *wapp_get_phy_by_freq(struct wifi_app *wapp,
	unsigned int freq)
{
	struct phy_info *phy = NULL;
	unsigned char i = 0;

	dl_list_for_each(phy, &wapp->phy_head, struct phy_info, list)
	{
		for (i = 0; i < phy->num_channels; i++) {
			if (phy->channels[i].freq == freq)
				return phy;
		}
	}

	return NULL;
}

struct phy_info *wapp_get_phy_by_ch(struct wifi_app *wapp,
	unsigned char ch)
{
	struct phy_info *phy = NULL;
	unsigned char i = 0;

	dl_list_for_each(phy, &wapp->phy_head, struct phy_info, list)
	{
		for (i = 0; i < phy->num_channels; i++)  {
			if (phy->channels[i].chan == ch)
				return phy;
		}
	}

	return NULL;
}
#endif

char *get_wdev_type_str(unsigned char type)
{
	switch (type) {
	case WAPP_DEV_TYPE_AP:
		return "AP";
	case WAPP_DEV_TYPE_STA:
		return "STA";
	case WAPP_DEV_TYPE_APCLI:
		return "APCLI";
	default:
		return "INVALID";
	}
}

int dump_wdev_info(struct wifi_app *wapp, char *buf, size_t max_len)
{
	struct wapp_dev *wdev = NULL;
	int ret = 0, len = 0;
	struct ap_dev *ap = NULL;
	unsigned char i = 0;
	char raid[6] = {0};

	ret = snprintf(buf + len, max_len - len, "\nwdev info:");
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	dl_list_for_each(wdev, &wapp->dev_list, struct wapp_dev, list) {
		if (wdev->radio) {
			MAP_GET_RADIO_IDNFER(wdev->radio, raid);
			ret = snprintf(buf + len, max_len - len,
				"\n\tifname=%s; mac_addr="MACSTR"; raid="MACSTR"; type=%d(%s);"
				" valid=%d; ifid=%d; op_ch=%d; opclass=%d; radio_band=%d\n"
				"\t kv info: wnm_enbale=%d; rrm_enable=%d\n",
				wdev->ifname, MAC2STR(wdev->mac_addr), MAC2STR(raid),
				wdev->dev_type, get_wdev_type_str(wdev->dev_type),
				wdev->valid, wdev->ifindex,
				wdev->radio->op_ch, wdev->radio->opclass, wdev->radio->radio_band ? *wdev->radio->radio_band : 0,
				wdev->wnm_enbale, wdev->rrm_enable);
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf fail\n");
				return -1;
			}
			len += ret;
		}
		if (wdev->dev_type != WAPP_DEV_TYPE_AP)
			continue;
		ap = (struct ap_dev *)wdev->p_dev;
		if (!ap) {
			err(DEBUG_CAT_MISC, "ap is NULL for raid "MACSTR"\n", MAC2STR(raid));
			return -1;
		}
		ret = snprintf(buf + len, max_len - len, "\t ap info: "
			"max_num_of_cli=%d; max_num_of_bss=%d; num_of_bss=%d; max_num_of_block_cli=%d\n",
			ap->max_num_of_cli, ap->max_num_of_bss, ap->num_of_bss, ap->max_num_of_block_cli);
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf fail\n");
				return -1;
			}
			len += ret;

		ret = snprintf(buf + len, max_len - len, "\t ht info: "
			"tx_stream=%d; rx_stream=%d; sgi_20=%d; sgi_40=%d; ht_40=%d\n",
			ap->ht_cap.tx_stream, ap->ht_cap.rx_stream, ap->ht_cap.sgi_20,
			ap->ht_cap.sgi_40, ap->ht_cap.ht_40);
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;

		ret = snprintf(buf + len, max_len - len, "\t vht info: "
			"tx_stream=%d; rx_stream=%d; sgi_80=%d; sgi_160=%d; vht_160=%d; "
			"vht_8080=%d; su_bf=%d; mu_bf=%d;"
			" sup_tx_mcs=%02x %02x; sup_rx_mcs=%02x %02x\n",
			ap->vht_cap.tx_stream, ap->vht_cap.rx_stream, ap->vht_cap.sgi_80,
			ap->vht_cap.sgi_160, ap->vht_cap.vht_160, ap->vht_cap.vht_8080,
			ap->vht_cap.su_bf, ap->vht_cap.mu_bf,
			ap->vht_cap.sup_tx_mcs[0], ap->vht_cap.sup_tx_mcs[1],
			ap->vht_cap.sup_rx_mcs[0], ap->vht_cap.sup_rx_mcs[1]);
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;

		ret = snprintf(buf + len, max_len - len, "\t he info: "
			"tx_stream=%d; rx_stream=%d; he_8080=%d; he_160=%d; su_bf_cap=%d; "
			"mu_bf_cap=%d\n\t  ul_mu_mimo_cap=%d; ul_mu_mimo_ofdma_cap=%d;"
			" dl_mu_mimo_ofdma_cap=%d; ul_ofdma_cap=%d; dl_ofdma_cap=%d; gi=%d\n",
			ap->he_cap.tx_stream, ap->he_cap.rx_stream, ap->he_cap.he_8080,
			ap->he_cap.he_160, ap->he_cap.su_bf_cap, ap->he_cap.mu_bf_cap,
			ap->he_cap.ul_mu_mimo_cap, ap->he_cap.ul_mu_mimo_ofdma_cap,
			ap->he_cap.dl_mu_mimo_ofdma_cap, ap->he_cap.ul_ofdma_cap,
			ap->he_cap.dl_ofdma_cap, ap->he_cap.gi);
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;

		ret = snprintf(buf + len, max_len - len, "\t  he_mcs=");
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;
		for (i = 0; i < ap->he_cap.he_mcs_len; i++) {
			ret = snprintf(buf + len, max_len - len, "%d ", ap->he_cap.he_mcs[i]);
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf fail\n");
				return -1;
			}
			len += ret;
		}
		ret = snprintf(buf + len, max_len - len, "\n");
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;
#ifdef MAP_R3_WF6
		ret = snprintf(buf + len, max_len - len, "\t wifi6 info:");
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;
		for (i = 0; i < ap->wf6_cap.role_supp; i++) {
			ret = snprintf(buf + len, max_len - len,
				"\n\t  agent_role=%d; su_beamformee_status=%d; beamformee_sts_less80=%d; "
				"beamformee_sts_more80=%d; max_user_dl_tx_mu_mimo=%d; max_user_ul_rx_mu_mimo=%d\n"
				"\t  max_user_dl_tx_ofdma=%d; max_user_ul_rx_ofdma=%d; rts_status=%d; "
				"mu_rts_status=%d; m_bssid_status=%d; mu_edca_status=%d; twt_requester_status=%d\n"
				"\t  twt_responder_status=%d\n",
				ap->wf6_cap.wf6_role[i].agent_role, ap->wf6_cap.wf6_role[i].su_beamformee_status,
				ap->wf6_cap.wf6_role[i].beamformee_sts_less80,
				ap->wf6_cap.wf6_role[i].beamformee_sts_more80, ap->wf6_cap.wf6_role[i].max_user_dl_tx_mu_mimo,
				ap->wf6_cap.wf6_role[i].max_user_ul_rx_mu_mimo,
				ap->wf6_cap.wf6_role[i].max_user_dl_tx_ofdma, ap->wf6_cap.wf6_role[i].max_user_ul_rx_ofdma,
				ap->wf6_cap.wf6_role[i].rts_status, ap->wf6_cap.wf6_role[i].mu_rts_status,
				ap->wf6_cap.wf6_role[i].m_bssid_status, ap->wf6_cap.wf6_role[i].mu_edca_status,
				ap->wf6_cap.wf6_role[i].twt_requester_status, ap->wf6_cap.wf6_role[i].twt_responder_status);
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf fail\n");
				return -1;
			}
			len += ret;
		}
#endif
#ifdef MAP_EHT_SUPPORT
		ret = snprintf(buf + len, max_len - len, "\t eht info: "
			"tx_stream=%d; rx_stream=%d; eht_ch_width=%d; ccfs0=%d; ccfs1=%d\n",
			ap->eht_cap.tx_stream, ap->eht_cap.rx_stream, ap->eht_cap.eht_ch_width,
			ap->eht_cap.ccfs0, ap->eht_cap.ccfs1);
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;
#ifdef MAP_R6
		ret = snprintf(buf + len, max_len - len,
			"\t  interface_index=%d; eht_operation_information_valid=%d;"
			" eht_default_pe_duration=%d; group_addressed_BU_indication_limit=%d\n"
			"\t  group_addressed_BU_indication_exponent=%d\n",
			ap->eht_cap.interface_index, ap->eht_cap.eht_operation_information_valid,
			ap->eht_cap.eht_default_pe_duration, ap->eht_cap.group_addressed_BU_indication_limit,
			ap->eht_cap.group_addressed_BU_indication_exponent);
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;
#endif
#endif
#ifdef MTK_MLO_MAP_SUPPORT
		ret = snprintf(buf + len, max_len - len, "\t mlo_cap info:");
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;
		for (i = 0; i < ap->mlo_cap.RoleNum; i++) {
			ret = snprintf(buf + len, max_len - len,
				"\n\t  DeviceRole=%d; StatPunctureSupport=%d; MloEnable=%d; "
				"emlsr_supp=%d; emlmr_delay=%d; trans_to=%d\n"
				"\t  max_simul_link=%d; srs_supp=%d; t2l_nego_supp=%d; "
				"freq_sep_str=%d; aar_supp=%d\n",
				ap->mlo_cap.MloCapPerRole[i].DeviceRole,
				ap->mlo_cap.MloCapPerRole[i].StatPunctureSupport,
				ap->mlo_cap.MloCapPerRole[i].MloEnable,
				ap->mlo_cap.MloCapPerRole[i].EmlCap.emlsr_supp,
				ap->mlo_cap.MloCapPerRole[i].EmlCap.emlmr_delay,
				ap->mlo_cap.MloCapPerRole[i].EmlCap.trans_to,
				ap->mlo_cap.MloCapPerRole[i].MldCap.max_simul_link,
				ap->mlo_cap.MloCapPerRole[i].MldCap.srs_supp,
				ap->mlo_cap.MloCapPerRole[i].MldCap.t2l_nego_supp,
				ap->mlo_cap.MloCapPerRole[i].MldCap.freq_sep_str,
				ap->mlo_cap.MloCapPerRole[i].MldCap.aar_supp);
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf fail\n");
				return -1;
			}
			len += ret;
		}
#endif
#ifdef MAP_R4_SPT
		ret = snprintf(buf + len, max_len - len, "\t spt_reuse info: "
				"sr_mode=%d; ul_traffic_status=%d; bss_color=%d; color_31_0=%d;"
				" color_63_32=%d; bssid_31_0=%d; bssid_63_32=%d\n",
				ap->sr_info.sr_mode, ap->sr_info.ul_traffic_status,
				ap->sr_info.bss_color,
				ap->sr_info.bm_info.color_31_0, ap->sr_info.bm_info.color_63_32,
				ap->sr_info.bm_info.bssid_31_0, ap->sr_info.bm_info.bssid_63_32);
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;
#endif
#ifdef MTK_MLO_MAP_SUPPORT
		ret = snprintf(buf + len, max_len - len, "\t mlo info: "
			"mld_addr="MACSTR"; mld_idx=%d; link_id=%d; ap_str_support=%d;"
			" ap_nstr_support=%d; ap_emlsr_support=%d; ap_emlmr_support=%d\n",
			MAC2STR(ap->mlo_info.mld_addr), ap->mlo_info.mld_idx,
			ap->mlo_info.link_id,
			ap->mlo_info.ap_str_support, ap->mlo_info.ap_nstr_support,
			ap->mlo_info.ap_emlsr_support, ap->mlo_info.ap_emlmr_support);
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;
#endif
	}

	return len;
}


int dump_txpower_info(struct wifi_app *wapp, char *buf, size_t max_len)
{
	struct wapp_dev *wdev = NULL;
	int ret = 0, len = 0;
	struct ap_dev *ap = NULL;
	unsigned char i = 0, j = 0;
	struct wapp_radio *ra = NULL;
	unsigned char id[MAC_ADDR_LEN] = {0};

	ret = snprintf(buf + len, max_len - len, "\ntx_power info:");
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	for (i = 0; i < MAX_NUM_OF_RADIO; i++) {
		ra = &wapp->radio[i];
		if (!ra->adpt_id)
			continue;
		MAP_GET_RADIO_IDNFER(ra, id);
		dl_list_for_each(wdev, &wapp->dev_list, struct wapp_dev, list) {
			if (ra == wdev->radio && wdev->valid == 1 &&
				wdev->dev_type == WAPP_DEV_TYPE_AP)
				break;
		}
		if (!wdev) {
			err(DEBUG_CAT_MISC, "no valid ap wdev for raid "MACSTR"\n",
				MAC2STR(id));
			return -1;
		}
		ap = (struct ap_dev *)wdev->p_dev;
		if (!ap) {
			err(DEBUG_CAT_MISC, "ap is NULL for raid "MACSTR"\n", MAC2STR(id));
			return -1;
		}

		ret = snprintf(buf + len, max_len - len,
			"\n\traid="MACSTR"; tx_pwr=%d; num_of_op_class=%d",
			MAC2STR(id), ap->pwr.tx_pwr, ap->pwr.num_of_op_class);
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;
		for (j = 0; j < ap->tx_pwr_ext.num_of_op_class; j++) {
			ret = snprintf(buf + len, max_len - len,
				"\n\t op_class=%d; max_pwr=%d\n",
				ap->tx_pwr_ext.tx_pwr_limit[j].op_class,
				ap->tx_pwr_ext.tx_pwr_limit[j].max_pwr);
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf fail\n");
				return -1;
			}
			len += ret;
		}
	}

	return len;
}


#ifdef ROAM_CALIB
int roam_get_timestamp(struct os_time *t)
{
	int res;
	struct timeval tv;

	res = gettimeofday(&tv, NULL);
	t->sec = tv.tv_sec;
	t->usec = tv.tv_usec;
	return res;
}
int RoamingCaldata(struct wifi_app *wapp, u8 *macAddr, u8 *Bssid, char *desc, const char *func_name)
{
	int i = 0;

	for (i = 0; i < ROAM_CAL_STA_CNT; i++) {
		if (os_memcmp(wapp->RoamingSta[i].StaAddr, macAddr, ETH_ALEN) == 0) {
			if (Bssid)
				os_memcpy(wapp->RoamingSta[i].Bssid, Bssid, ETH_ALEN);
			if (wapp->RoamingSta[i].data_cnt < 100) {
				os_memcpy(wapp->RoamingSta[i].data[wapp->RoamingSta[i].data_cnt].functionName,
					func_name, strlen(func_name));
				os_memcpy(wapp->RoamingSta[i].data[wapp->RoamingSta[i].data_cnt].desc,
					desc, strlen(desc));
				roam_get_timestamp(&wapp->RoamingSta[i].data[wapp->RoamingSta[i].data_cnt].timestamp);
				wapp->RoamingSta[i].data_cnt++;
			} else
				err(DEBUG_CAT_MISC, "Max data cnt reached= %d\n", wapp->RoamingSta[i].data_cnt);
			return 0;
		}
	}
	if (i >= 3)
		err(DEBUG_CAT_MISC, "FAIL! Station Do not exists\n");
	return 0;
}
int RoamCalStatsDisplay(struct wifi_app *wapp)
{
	int i = 0, j = 0;
	u64 timestamp;
	FILE *file = NULL;

	file = fopen(ROAM_DATA_DISP_WAPP, "w");
	if (!file) {
		err(DEBUG_CAT_MISC, "open /tmp/roam_cal_wapp.txt fail");
		return -1;
	}
	notice(DEBUG_CAT_MISC, "Current Roam loss sta list::\n");
	fprintf(file, "Current Roam loss sta list::\n");
	for (i = 0; i < ROAM_CAL_STA_CNT; i++) {
		notice(DEBUG_CAT_MISC, "index %d\nMAC: "MACSTR"\nBSSID: "MACSTR"\n", i,
				MAC2STR(wapp->RoamingSta[i].StaAddr), MAC2STR(wapp->RoamingSta[i].Bssid));
		fprintf(file, "index %d\nMAC: "MACSTR"\nBSSID: "MACSTR"\n", i,
				MAC2STR(wapp->RoamingSta[i].StaAddr), MAC2STR(wapp->RoamingSta[i].Bssid));
		for (j = 0; j < wapp->RoamingSta[i].data_cnt; j++) {
			timestamp = (u64)((wapp->RoamingSta[i].data[j].timestamp.sec * 1000000) +
					(wapp->RoamingSta[i].data[j].timestamp.usec));
			fprintf(file, "\n[WAPPD];%s;%s;%lu\n", wapp->RoamingSta[i].data[j].desc,
					wapp->RoamingSta[i].data[j].functionName, timestamp);
			notice(DEBUG_CAT_MISC, "\n[WAPPD];%s;%s;%lu\n", wapp->RoamingSta[i].data[j].desc,
					wapp->RoamingSta[i].data[j].functionName, timestamp);
		}
	}
	if (fclose(file) < 0)
		err(DEBUG_CAT_MISC, "close file /tmp/roam_cal_wapp.txt fail\n");
	return 0;
}
int RoamCalStaDel(struct wifi_app *wapp, char *macAddr)
{
	int ret = -1;
	int i = 0;

	for (i = 0; i < ROAM_CAL_STA_CNT; i++) {
		if (os_memcmp(wapp->RoamingSta[i].StaAddr, macAddr, ETH_ALEN) == 0) {
			notice(DEBUG_CAT_MISC, "Remove RoamSta at index:%d\n", i);
			os_memset(wapp->RoamingSta[i].StaAddr, 0, ETH_ALEN);
			os_memset(wapp->RoamingSta[i].Bssid, 0, ETH_ALEN);
			os_memset(wapp->RoamingSta[i].data, 0, sizeof(wapp->RoamingSta[i].data));
			wapp->RoamingSta[i].data_cnt = 0;
			ret = 0;
			return ret;
		}
	}
	if (i >= ROAM_CAL_STA_CNT) {
		ret = -1;
		err(DEBUG_CAT_MISC, "FAIL:STA not found\n");
	}
	return ret;
}
int RoamCalStaAdd(struct wifi_app *wapp, char *macAddr)
{
	int ret = -1;
	int i = 0;

	notice(DEBUG_CAT_MISC, "station MAC "MACSTR"\n", MAC2STR(macAddr));
	for (i = 0; i < ROAM_CAL_STA_CNT; i++) {
		if (os_memcmp(wapp->RoamingSta[i].StaAddr, macAddr, ETH_ALEN) == 0) {
			err(DEBUG_CAT_MISC, "Roaming Sta already present at index:%d\n", i);
			ret = 0;
			return ret;
		}
	}
	for (i = 0; i < ROAM_CAL_STA_CNT; i++) {
		if (is_zero_ether_addr(wapp->RoamingSta[i].StaAddr)) {
			os_memcpy(wapp->RoamingSta[i].StaAddr, macAddr, ETH_ALEN);
			ret = 0;
			break;
		}
	}
	if (i >= ROAM_CAL_STA_CNT) {
		ret = -1;
		err(DEBUG_CAT_MISC, "FAIL:::Roaming Sta list full\n");
	}
	return ret;
}
void RoamCalMemoryClear(struct wifi_app *wapp)
{
	int i = 0;
	struct _ROAM_STA *p = NULL;

	for (i = 0; i < ROAM_CAL_STA_CNT; i++) {
		p = &wapp->RoamingSta[i];
		os_memset(p->StaAddr, 0, ETH_ALEN);
		os_memset(p->Bssid, 0, ETH_ALEN);
		p->data_cnt = 0;
	}


}
int wapp_cmd_roam_calib_sta(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	char action;/*0 - Delete mac , 1 - Add mac , 2 - Display info , 3 - Feature ON/OFF*/
	char feature_on_off;
	char macAddr[ETH_ALEN];
	int ret = 0, i = 0;

	if (!argv[1]) {
		err(DEBUG_CAT_MISC, "Invalid argument\n");
		return WAPP_INVALID_ARG;
	}
	action = strtol(argv[1], NULL, 10);
	notice(DEBUG_CAT_MISC, "action in cmd is %d\n", action);
	if (action == FEATURE_ON_OFF) {
		feature_on_off = strtol(argv[2], NULL, 10);
		wapp->RoamCalibEnable = feature_on_off;
		notice(DEBUG_CAT_MISC, "Calib Feature is now %d\n", wapp->RoamCalibEnable);
		return ret;
	}
	if (action == DATA_CLEAR) {
		RoamCalMemoryClear(wapp);
		notice(DEBUG_CAT_MISC, "All sta and data clear done\n");
		return ret;
	}
	if (action == DISPLAY) {
		RoamCalStatsDisplay(wapp);
		return ret;
	}
	if (hwaddr_aton(argv[2], (unsigned char *)macAddr) < 0)
		return -1;
	if (action == ADD_MAC)
		ret = RoamCalStaAdd(wapp, macAddr);
	else if (action == DEL_MAC)
		ret = RoamCalStaDel(wapp, macAddr);
	notice(DEBUG_CAT_MISC, "current roaming sta list::\n");
	for (i = 0; i < ROAM_CAL_STA_CNT; i++) {
		notice(DEBUG_CAT_MISC, "index %d: addr:%02x:%02x:%02x:%02x:%02x:%02x\n", i,
			MAC2STR(wapp->RoamingSta[i].StaAddr));
	}
	return ret;
}
#endif

char *get_opmode_str(int mode)
{
	switch (mode) {
	case OPMODE_STA:
		return "STA";
	case OPMODE_AP:
		return "AP";
	default:
		return "INVALID";
	}
}

char *get_driver_mode_str(unsigned char mode)
{
	switch (mode) {
	case WEXT:
		return "WEXT";
	case NL80211:
		return "NL80211";
	default:
		return "INVALID";
	}
}

int dump_wapp_info(struct wifi_app *wapp, char *buf, size_t max_len)
{
	int ret = 0, len = 0;

	ret = snprintf(buf + len, max_len - len, "\nwapp info:\n");
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	ret = snprintf(buf + len, max_len - len,
		"\twapp_version=%s; ver_wapp_cmm=%s opmode=%d(%s); drv_mode=%d(%s)\n"
		"\t map_wapp_buffer_size=%d\n",
		WAPP_VERSION, VERSION_WAPP_CMM,
		wapp->opmode, get_opmode_str(wapp->opmode),
		wapp->drv_mode, get_driver_mode_str(wapp->drv_mode),
		wapp->map_wapp_buffer_size);
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;
#ifdef MAP_R6
	ret = snprintf(buf + len, max_len - len, "\t afc_mode=%d\n", wapp->afc_mode);
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;
#endif
#ifdef STANDARD_NL_CMD
	ret = snprintf(buf + len, max_len - len,
		"\t country_code=%s\n", wapp->country_code);
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;
#endif

	return len;
}

