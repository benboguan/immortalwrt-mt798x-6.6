/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#include "debug.h"
#include "hotspot.h"
#include "priv_netlink.h"
#include "wireless_copy.h"
#include "netlink.h"
#include <sys/ioctl.h>
#include <netlink/netlink.h>
#include "wapp_cmm.h"
#include "driver_nl80211.h"
#include "mtk_vendor_nl80211.h"

#include <ieee80211v_defs.h>
#include "ieee80211_comm.h"
#include "ieee80211_defs.h"
#ifdef WPACTRL_SUPPORT
#include <libwpactrl.h>
#endif /* WPACTRL_SUPPORT */

#define MTK_OUI 0x000ce7
#define MAX_SCAN_PARAM_LEN 64

#ifdef STANDARD_NL_CMD

/* --------------------EddySEC Start---------------- */

unsigned char SES_OUI[] = {0x00, 0x90, 0x4c};
unsigned char CISCO_OUI[]       = {0x00, 0x40, 0x96};
unsigned char RALINK_OUI[]      = {0x00, 0x0c, 0x43};
unsigned char WPA_OUI[]         = {0x00, 0x50, 0xf2, 0x01};
unsigned char RSN_OUI[]         = {0x00, 0x0f, 0xac};
unsigned char WAPI_OUI[]        = {0x00, 0x14, 0x72};
unsigned char WME_INFO_ELEM[]   = {0x00, 0x50, 0xf2, 0x02, 0x00, 0x01};
unsigned char WME_PARM_ELEM[]   = {0x00, 0x50, 0xf2, 0x02, 0x01, 0x01};
unsigned char BROADCOM_OUI[]    = {0x00, 0x90, 0x4c};
unsigned char MARVELL_OUI[]     = {0x00, 0x50, 0x43};
unsigned char METALINK_OUI[]    = {0x00, 0x09, 0x86};
unsigned char WPS_OUI[]         = {0x00, 0x50, 0xf2, 0x04};
/* WPA OUI*/
unsigned char OUI_WPA[3]                           = {0x00, 0x50, 0xF2};
unsigned char OUI_WPA_NONE_AKM[4]     = {0x00, 0x50, 0xF2, 0x00};
unsigned char OUI_WPA_VERSION[4]          = {0x00, 0x50, 0xF2, 0x01};
unsigned char OUI_WPA_WEP40[4]             = {0x00, 0x50, 0xF2, 0x01};
unsigned char OUI_WPA_TKIP[4]                  = {0x00, 0x50, 0xF2, 0x02};
unsigned char OUI_WPA_CCMP[4]               = {0x00, 0x50, 0xF2, 0x04};
unsigned char OUI_WPA_WEP104[4]           = {0x00, 0x50, 0xF2, 0x05};
unsigned char OUI_WPA_8021X_AKM[4]     = {0x00, 0x50, 0xF2, 0x01};
unsigned char OUI_WPA_PSK_AKM[4]         = {0x00, 0x50, 0xF2, 0x02};

/* WPA2 OUI*/
unsigned char OUI_WPA2[3]					   = {0x00, 0x0F, 0xAC};
unsigned char OUI_WPA2_CIPHER[3]                        = {0x00, 0x0F, 0xAC};
unsigned char OUI_WPA2_CIPHER_WEP40[4]          = {0x00, 0x0F, 0xAC, 0x01};
unsigned char OUI_WPA2_CIPHER_TKIP[4]               = {0x00, 0x0F, 0xAC, 0x02};
unsigned char OUI_WPA2_CIPHER_CCMP128[4]       = {0x00, 0x0F, 0xAC, 0x04};
unsigned char OUI_WPA2_CIPHER_WEP104[4]         = {0x00, 0x0F, 0xAC, 0x05};
unsigned char OUI_WPA2_CIPHER_BIPCMAC128[4]  = {0x00, 0x0F, 0xAC, 0x06};
unsigned char OUI_WPA2_CIPHER_GCMP128[4]       = {0x00, 0x0F, 0xAC, 0x08};
unsigned char OUI_WPA2_CIPHER_GCMP256[4]       = {0x00, 0x0F, 0xAC, 0x09};
unsigned char OUI_WPA2_CIPHER_CCMP256[4]       = {0x00, 0x0F, 0xAC, 0x0A};
unsigned char OUI_WPA2_CIPHER_BIPGMAC128[4] = {0x00, 0x0F, 0xAC, 0x0B};
unsigned char OUI_WPA2_CIPHER_BIPGMAC256[4] = {0x00, 0x0F, 0xAC, 0x0C};
unsigned char OUI_WPA2_CIPHER_BIPCMAC256[4]  = {0x00, 0x0F, 0xAC, 0x0D};

unsigned char OUI_WPA2_AKM_8021X[4]                      = {0x00, 0x0F, 0xAC, 0x01};
unsigned char OUI_WPA2_AKM_PSK[4]                          = {0x00, 0x0F, 0xAC, 0x02};
unsigned char OUI_WPA2_AKM_FT_8021X[4]                = {0x00, 0x0F, 0xAC, 0x03};
unsigned char OUI_WPA2_AKM_FT_PSK[4]                    = {0x00, 0x0F, 0xAC, 0x04};
unsigned char OUI_WPA2_AKM_8021X_SHA256[4]       = {0x00, 0x0F, 0xAC, 0x05};
unsigned char OUI_WPA2_AKM_PSK_SHA256[4]           = {0x00, 0x0F, 0xAC, 0x06};
unsigned char OUI_WPA2_AKM_TDLS[4]                        = {0x00, 0x0F, 0xAC, 0x07};
unsigned char OUI_WPA2_AKM_SAE_SHA256[4]           = {0x00, 0x0F, 0xAC, 0x08};
unsigned char OUI_WPA2_AKM_FT_SAE_SHA256[4]     = {0x00, 0x0F, 0xAC, 0x09};
unsigned char OUI_WPA2_AKM_SUITEB_SHA256[4]      = {0x00, 0x0F, 0xAC, 0x0B};
unsigned char OUI_WPA2_AKM_SUITEB_SHA384[4]      = {0x00, 0x0F, 0xAC, 0x0C};
unsigned char OUI_WPA2_AKM_FT_8021X_SHA384[4]  = {0x00, 0x0F, 0xAC, 0x0D};
unsigned char OUI_WPA2_AKM_FILS_SHA256[4]       = {0x00, 0x0F, 0xAC, 0x0E};
unsigned char OUI_WPA2_AKM_FILS_SHA384[4]       = {0x00, 0x0F, 0xAC, 0x0F};
unsigned char OUI_WPA2_AKM_OWE[4]  = {0x00, 0x0F, 0xAC, 0x12/*d'18*/};
unsigned char OUI_WPA2_AKM_SAE_EXT[4]      = {0x00, 0x0F, 0xAC, 0x18/*d'24*/};
unsigned char OUI_WPA2_AKM_FT_SAE_EXT[4]      = {0x00, 0x0F, 0xAC, 0x19/*d'25*/};
unsigned char DPP_OUI[]     = {0x50, 0x6f, 0x9a, 0x02};
/* --------------------EddySEC END---------------- */

#endif

struct scan_type_option  {
	char type_name[MAX_SCAN_PARAM_LEN];
	enum mtk_vendor_attr_scantype type;
};

struct scan_type_option type_opt[] = {
	{"full", NL80211_FULL_SCAN},
	{"partial", NL80211_PARTIAL_SCAN},
	{"offch", NL80211_OFF_CH_SCAN},
	{"overlap", NL80211_2040_OVERLAP_SCAN},
};

char *get_vendor_nl80211_cmd_str(unsigned short cmd)
{
	switch (cmd) {
	case MTK_NL80211_VENDOR_SUBCMD_GET_STATIC_INFO:
		return "MTK_NL80211_VENDOR_SUBCMD_GET_STATIC_INFO";
	case MTK_NL80211_VENDOR_SUBCMD_GET_RUNTIME_INFO:
		return "MTK_NL80211_VENDOR_SUBCMD_GET_RUNTIME_INFO";
	case MTK_NL80211_VENDOR_SUBCMD_GET_CAP:
		return "MTK_NL80211_VENDOR_SUBCMD_GET_CAP";
	case MTK_NL80211_VENDOR_SUBCMD_GET_STATISTIC:
		return "MTK_NL80211_VENDOR_SUBCMD_GET_STATISTIC";
	case MTK_NL80211_VENDOR_SUBCMD_QOS:
		return "MTK_NL80211_VENDOR_SUBCMD_QOS";
	case MTK_NL80211_VENDOR_SUBCMD_DFS:
		return "MTK_NL80211_VENDOR_SUBCMD_DFS";
	case MTK_NL80211_VENDOR_SUBCMD_EASYMESH:
		return "MTK_NL80211_VENDOR_SUBCMD_EASYMESH";
	case MTK_NL80211_VENDOR_SUBCMD_SET_AP_MONITOR:
		return "MTK_NL80211_VENDOR_SUBCMD_SET_AP_MONITOR";
	case MTK_NL80211_VENDOR_SUBCMD_GET_RADIO_STATS:
		return "MTK_NL80211_VENDOR_SUBCMD_GET_RADIO_STATS";
	default:
		return "UNKNOWN_CMD";
	}
}

static void process_vendor_attr_event_test(struct wifi_app *wapp, struct nlattr *attr_vendor_data_tb)
{
	struct nlattr *tb_vendor[MTK_NL80211_VENDOR_ATTR_EVENT_TEST_MAX + 1];
	u32 val;
	int ret;

	ret = nla_parse_nested(tb_vendor, MTK_NL80211_VENDOR_ATTR_EVENT_TEST_MAX, attr_vendor_data_tb, NULL);
	if (ret) {
		err(DEBUG_CAT_NL80211, "nla_parse_nested fail\n");
		return;
	}

	if (!tb_vendor[MTK_NL80211_VENDOR_ATTR_EVENT_TEST])
		err(DEBUG_CAT_NL80211, "no vendor attr\n");

	val = nla_get_u32(tb_vendor[MTK_NL80211_VENDOR_ATTR_EVENT_TEST]);

	notice(DEBUG_CAT_NL80211, "val=%d\n", val);
}

static void process_vendor_attr_event_rsp(struct wifi_app *wapp, struct nlattr *attr_vendor_data_tb)
{
	struct nlattr *tb_vendor[MTK_NL80211_VENDOR_ATTR_EVENT_RSP_WAPP_EVENT_MAX + 1];
	struct wapp_event *event;
	int ret;

	ret = nla_parse_nested(tb_vendor, MTK_NL80211_VENDOR_ATTR_EVENT_RSP_WAPP_EVENT_MAX, attr_vendor_data_tb, NULL);
	if (ret) {
		err(DEBUG_CAT_NL80211, "nla_parse_nested fail\n");
		return;
	}

	if (tb_vendor[MTK_NL80211_VENDOR_ATTR_EVENT_RSP_WAPP_EVENT]) {
		event = (struct wapp_event *)nla_data(tb_vendor[MTK_NL80211_VENDOR_ATTR_EVENT_RSP_WAPP_EVENT]);
		wapp->event_ops->event_handle(wapp, event);
	}
}

static void process_vendor_attr_event_offchannel_info(struct wifi_app *wapp, struct nlattr *attr_vendor_data_tb)
{
	struct nlattr *tb_vendor[MTK_NL80211_VENDOR_ATTR_EVENT_OFF_CHANNEL_INFO_MAX + 1];
	u8 *data;
	int ret;

	ret = nla_parse_nested(tb_vendor, MTK_NL80211_VENDOR_ATTR_EVENT_OFF_CHANNEL_INFO_MAX, attr_vendor_data_tb, NULL);
	if (ret) {
		err(DEBUG_CAT_NL80211, "nla_parse_nested fail\n");
		return;
	}

	if (tb_vendor[MTK_NL80211_VENDOR_ATTR_EVENT_OFF_CHANNEL_INFO]) {
		data = (u8 *)nla_data(tb_vendor[MTK_NL80211_VENDOR_ATTR_EVENT_OFF_CHANNEL_INFO]);
		wapp->event_ops->event_offch_info(wapp, data);
	}
}

static void process_vendor_attr_event_cosr(struct wifi_app *wapp, struct nlattr *attr_vendor_data_tb)
{
	struct nlattr *tb_vendor[MTK_NL80211_VENDOR_ATTR_COSR_MAX + 1];
	struct wapp_event *event;
	int ret;

	ret = nla_parse_nested(tb_vendor, MTK_NL80211_VENDOR_ATTR_COSR_MAX, attr_vendor_data_tb, NULL);
	if (ret) {
		err(DEBUG_CAT_NL80211, "nla_parse_nested fail!\n");
		return;
	}

	if (tb_vendor[MTK_NL80211_VENDOR_ATTR_STA_RSSI_CHANGE]) {
		event = (struct wapp_event *)nla_data(tb_vendor[MTK_NL80211_VENDOR_ATTR_STA_RSSI_CHANGE]);
		wapp->event_ops->event_handle(wapp, event);
	}

	if (tb_vendor[MTK_NL80211_VENDOR_ATTR_COAP_UPDATED]) {
		event = (struct wapp_event *)nla_data(tb_vendor[MTK_NL80211_VENDOR_ATTR_COAP_UPDATED]);
		wapp->event_ops->event_handle(wapp, event);
	}

	if (tb_vendor[MTK_NL80211_VENDOR_ATTR_COAP_FOUND]) {
		event = (struct wapp_event *)nla_data(tb_vendor[MTK_NL80211_VENDOR_ATTR_COAP_FOUND]);
		wapp->event_ops->event_handle(wapp, event);
	}

	if (tb_vendor[MTK_NL80211_VENDOR_ATTR_COSR_FRAME]) {
		event = (struct wapp_event *)nla_data(tb_vendor[MTK_NL80211_VENDOR_ATTR_COSR_FRAME]);
		wapp->event_ops->event_handle(wapp, event);
	}
}

#ifdef DFS_SLAVE_SUPPORT
static void process_vendor_attr_event_bhstatus(struct wifi_app *wapp, struct nlattr *attr_vendor_data_tb)
{
	struct nlattr *tb_vendor[MTK_NL80211_VENDOR_ATTR_DFS_SLAVE_MAX + 1];
	char *data = NULL;
	int ret;

	ret = nla_parse_nested(tb_vendor, MTK_NL80211_VENDOR_ATTR_DFS_SLAVE_MAX, attr_vendor_data_tb, NULL);
	if (ret) {
		err(DEBUG_CAT_NL80211, "nla_parse_nested fail\n");
		return;
	}

	if (tb_vendor[MTK_NL80211_VENDOR_ATTR_DFS_SLAVE_BH_STATUS]) {
		data = nla_data(tb_vendor[MTK_NL80211_VENDOR_ATTR_DFS_SLAVE_BH_STATUS]);
		wapp->event_ops->event_bhstatus(wapp, data);
	}
}
#endif /* DFS_SLAVE_SUPPORT */

#ifdef STANDARD_NL_CMD

unsigned short WscGetAuthTypeAtWapp(uint32_t authType)
{
#ifdef MAP_R6
	if (IS_AKM_SAE_EXT(authType) && IS_AKM_WPA2PSK(authType) && IS_AKM_DPP(authType) && IS_AKM_WPA3PSK(authType))
		return WSC_AUTHTYPE_SAE_AKM24_D | WSC_AUTHTYPE_WPA2PSK | WSC_AUTHTYPE_DPP | WSC_AUTHTYPE_SAE;
	else if (IS_AKM_SAE_EXT(authType) && IS_AKM_WPA2PSK(authType) && IS_AKM_DPP(authType))
		return WSC_AUTHTYPE_SAE_AKM24_D | WSC_AUTHTYPE_WPA2PSK | WSC_AUTHTYPE_DPP;
	else if (IS_AKM_SAE_EXT(authType) && IS_AKM_WPA3PSK(authType) && IS_AKM_DPP(authType))
		return WSC_AUTHTYPE_SAE_AKM24_D | WSC_AUTHTYPE_SAE | WSC_AUTHTYPE_DPP;
	else if (IS_AKM_SAE_EXT(authType) && IS_AKM_WPA3PSK(authType) && IS_AKM_WPA2PSK(authType))
		return WSC_AUTHTYPE_SAE_AKM24_D | WSC_AUTHTYPE_SAE | WSC_AUTHTYPE_WPA2PSK;
	else if (IS_AKM_SAE_EXT(authType) && IS_AKM_WPA2PSK(authType))
		return WSC_AUTHTYPE_SAE_AKM24_D | WSC_AUTHTYPE_WPA2PSK;
	else if (IS_AKM_SAE_EXT(authType) && IS_AKM_WPA3PSK(authType))
		return WSC_AUTHTYPE_SAE_AKM24_D | WSC_AUTHTYPE_SAE;
	else if (IS_AKM_SAE_EXT(authType) && IS_AKM_DPP(authType))
		return WSC_AUTHTYPE_SAE_AKM24_D | WSC_AUTHTYPE_DPP;
	else if (IS_AKM_SAE_EXT(authType))
		return WSC_AUTHTYPE_SAE_AKM24_D;
#endif
	if (IS_AKM_OPEN(authType))
		return WSC_AUTHTYPE_OPEN;
	else if (IS_AKM_SHARED(authType))
		return WSC_AUTHTYPE_SHARED;
	else if (IS_AKM_WPANONE(authType))
		return WSC_AUTHTYPE_WPANONE;
#if (defined(MAP_R3) || defined(DPP_SUPPORT))
	else if (IS_AKM_DPP(authType) && IS_AKM_WPA3PSK(authType) && IS_AKM_WPA2PSK(authType))
		return WSC_AUTHTYPE_DPP | WSC_AUTHTYPE_SAE | WSC_AUTHTYPE_WPA2PSK;
	else if (IS_AKM_DPP(authType) && IS_AKM_WPA2PSK(authType))
		return WSC_AUTHTYPE_DPP | WSC_AUTHTYPE_WPA2PSK;
	else if (IS_AKM_DPP(authType) && IS_AKM_WPA3PSK(authType))
		return WSC_AUTHTYPE_DPP | WSC_AUTHTYPE_SAE;
	else if (IS_AKM_DPP(authType))
		return WSC_AUTHTYPE_DPP;
#endif
	else if (IS_AKM_WPA1(authType) && IS_AKM_WPA2(authType))
		return WSC_AUTHTYPE_WPA | WSC_AUTHTYPE_WPA2;
	else if (IS_AKM_WPA1PSK(authType) && IS_AKM_WPA2PSK(authType))
		return WSC_AUTHTYPE_WPAPSK | WSC_AUTHTYPE_WPA2PSK;
	else if (IS_AKM_WPA1(authType))
		return WSC_AUTHTYPE_WPA;
	else if (IS_AKM_WPA1PSK(authType))
		return WSC_AUTHTYPE_WPAPSK;
	else if (IS_AKM_WPA2PSK(authType) && IS_AKM_WPA3PSK(authType))
		return WSC_AUTHTYPE_WPA2PSK | WSC_AUTHTYPE_SAE;
	else if (IS_AKM_WPA2(authType))
		return WSC_AUTHTYPE_WPA2;
	else if (IS_AKM_WPA2PSK(authType))
		return WSC_AUTHTYPE_WPA2PSK;
	else if (IS_AKM_WPA3PSK(authType))
		return WSC_AUTHTYPE_SAE;
	else
		return WSC_AUTHTYPE_OPEN;
}

static int eht_get_op_ie(const u8 *pos, size_t elen, struct Scan_data *scan_info)
{
	UINT32 partial_ie_len = 0;
	const u8 *ie_ptr = pos;
	UCHAR left_len = elen;

	if (elen < EHT_OP_IE_BASIC_LEN) {
		err(DEBUG_CAT_NL80211, "EHT OP IE less than the minimum length!\n");
		return -1;
	} else if (elen > EHT_OP_IE_MAX_LEN) {
		err(DEBUG_CAT_NL80211, "EHT OP IE exceed the maximum length!\n");
		return -1;
	}

	if (GET_DOT11BE_OP_PARAM_HAS_OP_INFO(pos[0])) {
		partial_ie_len = sizeof(struct eht_op_ie);
		debug(DEBUG_CAT_NL80211, "Operation information present\n");
		if (partial_ie_len <= left_len) {
			os_memcpy(&scan_info->eht_op, ie_ptr, partial_ie_len);
			scan_info->EHT_OP_INFO_EXISTS = TRUE;
		} else {
			err(DEBUG_CAT_NL80211, "the length of EHT OP IE is abnormal!\n");
			return -1;
		}
		left_len -= partial_ie_len;
		if (GET_DOT11BE_OP_PARAM_HAS_DIS_SUB_CH_BITMAP(pos[0])) {
			ie_ptr += partial_ie_len;
			partial_ie_len = sizeof(scan_info->dis_subch_bitmap);
			if (partial_ie_len <= left_len) {
				os_memcpy(&scan_info->dis_subch_bitmap, ie_ptr, partial_ie_len);
				scan_info->dscb_enable = TRUE;
			} else {
				err(DEBUG_CAT_NL80211, "the length of EHT OP IE is abnormal!\n");
				return -1;
			}
		} else {
			scan_info->dis_subch_bitmap = 0;
			scan_info->dscb_enable = FALSE;
		}
	} else {
		/* EHT Operation Parameters exists only */
		partial_ie_len = EHT_OP_IE_BASIC_LEN;
		debug(DEBUG_CAT_NL80211, "Operation information not present\n");
		if (partial_ie_len <= left_len) {
			os_memcpy(&scan_info->eht_op, ie_ptr, partial_ie_len);
			scan_info->EHT_OP_INFO_EXISTS = FALSE;
		} else {
			err(DEBUG_CAT_NL80211, "the length of EHT OP IE is abnormal!\n");
			return -1;
		}
		left_len -= partial_ie_len;
		if (GET_DOT11BE_OP_PARAM_HAS_DIS_SUB_CH_BITMAP(pos[0])) {
			ie_ptr += partial_ie_len;
			partial_ie_len = sizeof(scan_info->dis_subch_bitmap);
			if (partial_ie_len <= left_len) {
				os_memcpy(&scan_info->dis_subch_bitmap, ie_ptr, partial_ie_len);
				scan_info->dscb_enable = TRUE;
			} else {
				err(DEBUG_CAT_NL80211, "the length of EHT OP IE is abnormal!\n");
				return -1;
			}
		} else {
			scan_info->dis_subch_bitmap = 0;
			scan_info->dscb_enable = FALSE;
		}
	}
	scan_info->EHT_OP_IE_EXISTS = TRUE;
	return 0;
}


unsigned short WscGetEncryTypeAtWapp(uint32_t encryType)
{
	if (IS_CIPHER_NONE(encryType))
		return WSC_ENCRTYPE_NONE;
	else if (IS_CIPHER_WEP(encryType))
		return WSC_ENCRTYPE_WEP;
	else if (IS_CIPHER_TKIP(encryType) && IS_CIPHER_CCMP128(encryType))
		return WSC_ENCRTYPE_AES | WSC_ENCRTYPE_TKIP;
	else if (IS_CIPHER_TKIP(encryType))
		return WSC_ENCRTYPE_TKIP;
	else if (IS_CIPHER_CCMP128(encryType))
		return WSC_ENCRTYPE_AES;
	else
		return WSC_ENCRTYPE_AES;
}


static bool wpa_rsne_sanity(const unsigned char *rsnie_ptr, unsigned char rsnie_len, unsigned char *end_field)
{
	struct COSR_EID_STRUCT  *eid_ptr;
	unsigned char *pStaTmp;
	unsigned short ver;
	unsigned short Count;
	uint32_t len = 0;

	eid_ptr = (struct COSR_EID_STRUCT *)rsnie_ptr;

	if ((rsnie_len < 2) || (eid_ptr->Len + 2) != rsnie_len) {
		err(DEBUG_CAT_NL80211, "the len is invalid; rsnie_len=%d, eid_ptr->Len=%d\n", rsnie_len, eid_ptr->Len);
		return FALSE;
	}

	if (eid_ptr->Len < MIN_LEN_OF_RSNIE) {
		err(DEBUG_CAT_NL80211, "eid_ptr->Len(%d) < MIN_LEN_OF_RSNIE(%d)\n", eid_ptr->Len, MIN_LEN_OF_RSNIE);
		return FALSE;
	}

	/* Store STA RSN_IE capability */
	pStaTmp = (unsigned char *)&eid_ptr->Octet[0];

	/* check Element ID */
	if (eid_ptr->Eid == WLAN_EID_RSN) {
		/*RSN*/
	} else if (eid_ptr->Eid == WLAN_EID_VENDOR_SPECIFIC) {
		/* skip OUI(4) */
		pStaTmp += 4;
		len += 4;
	} else if (eid_ptr->Eid == WLAN_EID_BSS_AC_ACCESS_DELAY)
		return TRUE;

	/* check version */
	len += 2;
	if (eid_ptr->Len < len) {
		err(DEBUG_CAT_NL80211, "no version(len = %d)\n", eid_ptr->Len);
		return FALSE;
	}
	NdisMoveMemory(&ver, pStaTmp, sizeof(ver));
	ver = cpu2le16(ver);

	if (ver != 1) {
		err(DEBUG_CAT_NL80211, "unknown version(%d)\n", ver);
		return FALSE;
	}

	if (eid_ptr->Len == len) {
		/* None of the optional fields are included in the RSNE */
		*end_field = RSN_FIELD_NONE;
		return TRUE;
	}

	pStaTmp += sizeof(unsigned short);

	/* check group cipher suite */
	len += LEN_OUI_SUITE;
	if (eid_ptr->Len < len) {
		err(DEBUG_CAT_NL80211, "group cipher is truncated(len = %d)\n", eid_ptr->Len);
		return FALSE;
	} else if (eid_ptr->Len == len) {
		/* Group Data Cipher Suite are included in the RSNE */
		*end_field = RSN_FIELD_GROUP_CIPHER;
		return TRUE;
	}

	pStaTmp += LEN_OUI_SUITE;

	/* check pairwise cipher suite */
	len += 2;
	if (eid_ptr->Len < len) {
		err(DEBUG_CAT_NL80211, "pairwise cipher suite cnt is truncated(%d)\n", eid_ptr->Len);
		return FALSE;
	}

	/* Store pairwise cipher count */
	NdisMoveMemory(&Count, pStaTmp, sizeof(unsigned short));
	Count = cpu2le16(Count);

	len += Count * LEN_OUI_SUITE;

	if (eid_ptr->Len < len) {
		err(DEBUG_CAT_NL80211, "Pairwise Cipher Suite is truncated(len %d)\n", eid_ptr->Len);
		return FALSE;
	} else if (eid_ptr->Len == len) {
		/* Pairwise Cipher Suite are included in the RSNE */
		*end_field = RSN_FIELD_PAIRWISE_CIPHER;
		return TRUE;
	}

	pStaTmp += sizeof(unsigned short) + Count * LEN_OUI_SUITE;

	/* check akm suite */
	len += 2;
	if (eid_ptr->Len < len) {
		err(DEBUG_CAT_NL80211, "akm suite cnt is truncated(%d)\n", eid_ptr->Len);
		return FALSE;
	}

	/* Store akm count */
	NdisMoveMemory(&Count, pStaTmp, sizeof(unsigned short));
	Count = cpu2le16(Count);

	len += Count * LEN_OUI_SUITE;
	if (eid_ptr->Len < len) {
		err(DEBUG_CAT_NL80211, "Akm Suite is truncated(len %d)\n", eid_ptr->Len);
		return FALSE;
	} else if (eid_ptr->Len == len) {
		/* akm Suite are included in the RSNE */
		*end_field = RSN_FIELD_AKM;
		return TRUE;
	}

	pStaTmp += sizeof(unsigned short) + Count * LEN_OUI_SUITE;

	/* check rsn capabilities */
	len += 2;
	if (eid_ptr->Len < len) {
		err(DEBUG_CAT_NL80211, "RSN capabilities is truncated(len %d)\n",  eid_ptr->Len);
		return FALSE;
	} else if (eid_ptr->Len == len) {
		if (eid_ptr->Eid == WLAN_EID_VENDOR_SPECIFIC) {
			*end_field = RSN_FIELD_AKM;
		} else {
			/* rsn capabilities are included in the RSNE */
			*end_field = RSN_FIELD_RSN_CAP;
		}
		return TRUE;
	}

	pStaTmp += 2;

	/* check PMKID */
	len += 2;
	if (eid_ptr->Len < len) {
		err(DEBUG_CAT_NL80211, "pmkid cnt is truncated(%d)\n",  eid_ptr->Len);
		return FALSE;
	}

	/* Store pmkid count */
	NdisMoveMemory(&Count, pStaTmp, sizeof(unsigned short));
	Count = cpu2le16(Count);

	len += Count * 16;

	if (eid_ptr->Len < len) {
		err(DEBUG_CAT_NL80211, "PMKID is truncated(len %d)\n",  eid_ptr->Len);
		return FALSE;
	} else if (eid_ptr->Len == len) {
		/* PMKID are included in the RSNE */
		*end_field = RSN_FIELD_PMKID;
		return TRUE;
	}

	pStaTmp += 2 + Count * 16;


	/* check Group Management Cipher Suite*/
	len += LEN_OUI_SUITE;
	if (eid_ptr->Len < len) {
		err(DEBUG_CAT_NL80211, "Group Management Cipher Suite is truncated(len %d)\n",  eid_ptr->Len);
		return FALSE;
	} else if (eid_ptr->Len == len) {
		/* PMKID are included in the RSNE */
		*end_field = RSN_FIELD_GROUP_MGMT_CIPHER;
		return TRUE;
	}

	pStaTmp += LEN_OUI_SUITE;

	*end_field = RSN_FIELD_EXTENSIBLE_ELE;

	return TRUE;
}
static void BssCipherParse(struct Scan_data *pBss, const struct COSR_EID_STRUCT *pEid, const u8 *pTmp)
{

	struct _RSN_IE_HEADER_STRUCT *pRsnHeader;
	struct akm_capabe *pCipher;
	struct akm_capabe *pAKM;
	unsigned short Count;
	short Length;
	unsigned char end_field = 0;
	unsigned char res;
	/* WepStatus will be reset later, if AP announce TKIP or AES on the beacon frame.*/

	Length = pEid->Len + 2;

	while (Length > 0) {
		/* Parse cipher suite base on WPA1 & WPA2, they should be parsed differently*/
		// pTmp = ((unsigned char *) pBss->VarIEs) + pBss->VarIELen - ((unsigned short)Length);
		pTmp -= 2;
		// pEid = (PEID_STRUCT) pTmp;
		switch (pEid->Eid) {
		case WLAN_EID_VENDOR_SPECIFIC:
			if (os_memcmp(pEid->Octet, SES_OUI, 3) && (pEid->Len == 7)) {
				// pBss->bSES = TRUE;
				break;
			} else if (os_memcmp(pEid->Octet, WPA_OUI, 4) != 1) {
				/* if unsupported vendor specific IE*/
				break;
			}

			/* pTmp = (unsigned char *) pEid->Octet;*/
			pTmp   += 11;

			/* Parse group cipher*/
			switch (*pTmp) {
			case 1:
				SET_CIPHER_WEP40(pBss->GroupCipher);
				break;

			case 5:
				SET_CIPHER_WEP104(pBss->GroupCipher);
				break;

			case 2:
				SET_CIPHER_TKIP(pBss->GroupCipher);
				break;

			case 4:
				SET_CIPHER_CCMP128(pBss->GroupCipher);
				break;

			default:
				break;
			}

			/* number of unicast suite*/
			pTmp   += 1;
			/* skip all unicast cipher suites*/
			/*Count = *(unsigned char*) pTmp;				*/
			Count = (pTmp[1] << 8) + pTmp[0];
			pTmp   += sizeof(unsigned short);

			/* Parsing all unicast cipher suite*/
			while (Count > 0) {
				/* Skip OUI*/
				pTmp += 3;

				switch (*pTmp) {
				case 1:
					SET_CIPHER_WEP40(pBss->PairwiseCipher);
					break;

				case 5: /* Although WEP is not allowed in WPA related auth mode, we parse it anyway*/
					SET_CIPHER_WEP104(pBss->PairwiseCipher);
					break;

				case 2:
					SET_CIPHER_TKIP(pBss->PairwiseCipher);
					break;

				case 4:
					SET_CIPHER_CCMP128(pBss->PairwiseCipher);
					break;

				default:
					break;
				}

				pTmp++;
				Count--;
			}

			/* 4. get AKM suite counts*/
			/*Count	= *(unsigned char*) pTmp;*/
			Count = (pTmp[1] << 8) + pTmp[0];
			pTmp   += sizeof(unsigned short);
			pTmp   += 3;

			switch (*pTmp) {
			case 1:
				/* Set AP support WPA-enterprise mode*/
				SET_AKM_WPA1(pBss->AKMMap);
				break;

			case 2:
				/* Set AP support WPA-PSK mode*/
				SET_AKM_WPA1PSK(pBss->AKMMap);
				break;

			default:
				break;
			}

			pTmp   += 1;

			/* Fixed for WPA-None*/
			// if (pBss->BssType == BSS_ADHOC)
			//	SET_AKM_WPANONE(pBss->AKMMap);

			break;

		case WLAN_EID_RSN:
			pRsnHeader = (struct _RSN_IE_HEADER_STRUCT *) pTmp;
			if (pRsnHeader->Length + 2 > Length) {
				err(DEBUG_CAT_NL80211, "IE_RSN length exceed the space!!\n");
				break;
			}
			res = wpa_rsne_sanity(pTmp, pRsnHeader->Length + 2, &end_field);

			if (res == FALSE)
				break;
			if (end_field < RSN_FIELD_GROUP_CIPHER)
				SET_CIPHER_CCMP128(pBss->GroupCipher);
			if (end_field < RSN_FIELD_PAIRWISE_CIPHER)
				SET_CIPHER_CCMP128(pBss->PairwiseCipher);
			if (end_field < RSN_FIELD_AKM)
				SET_AKM_WPA2(pBss->AKMMap);

			/* 0. Version must be 1*/
			if (le2cpu16(pRsnHeader->Version) != 1)
				break;

			/* 1. Check group cipher*/
			if (end_field < RSN_FIELD_GROUP_CIPHER)
				break;

			pTmp   += sizeof(struct _RSN_IE_HEADER_STRUCT);
			/* 1. Check group cipher*/
			pCipher = (struct akm_capabe *) pTmp;
			if (os_memcmp(&pCipher->oui, RSN_OUI, 3))
				break;
			/* Parse group cipher*/
			switch (pCipher->suite_type) {
			case 1:
				SET_CIPHER_WEP40(pBss->GroupCipher);
				break;

			case 2:
				SET_CIPHER_TKIP(pBss->GroupCipher);
				break;

			case 4:
				SET_CIPHER_CCMP128(pBss->GroupCipher);
				break;

			case 5:
				SET_CIPHER_WEP104(pBss->GroupCipher);
				break;

			case 8:
				SET_CIPHER_GCMP128(pBss->GroupCipher);
				break;

			case 9:
				SET_CIPHER_GCMP256(pBss->GroupCipher);
				break;

			case 10:
				SET_CIPHER_CCMP256(pBss->GroupCipher);
				break;

			default:
				break;
			}

			/* set to correct offset for next parsing*/
			pTmp   += sizeof(struct akm_capabe);
			/* 2. Get pairwise cipher counts*/
			if (end_field < RSN_FIELD_PAIRWISE_CIPHER)
				break;
			/*Count = *(unsigned char*) pTmp;*/
			Count = (pTmp[1] << 8) + pTmp[0];
			pTmp   += sizeof(unsigned short);

			/* 3. Get pairwise cipher*/
			/* Parsing all unicast cipher suite*/
			while (Count > 0) {
				/* Skip OUI*/
				pCipher = (struct akm_capabe *) pTmp;

				switch (pCipher->suite_type) {
				case 1:
					SET_CIPHER_WEP40(pBss->PairwiseCipher);
					break;

				case 2:
					SET_CIPHER_TKIP(pBss->PairwiseCipher);
					break;

				case 4:
					SET_CIPHER_CCMP128(pBss->PairwiseCipher);
					break;

				case 5:
					SET_CIPHER_WEP104(pBss->PairwiseCipher);
					break;

				case 8:
					SET_CIPHER_GCMP128(pBss->PairwiseCipher);
					break;

				case 9:
					SET_CIPHER_GCMP256(pBss->PairwiseCipher);
					break;

				case 10:
					SET_CIPHER_CCMP256(pBss->PairwiseCipher);
					break;

				default:
					break;
				}

				pTmp += sizeof(struct akm_capabe);
				Count--;
			}

			/* 4. get AKM suite counts*/
			if (end_field < RSN_FIELD_AKM)
				break;
			/*Count	= *(unsigned char*) pTmp;*/
			Count = (pTmp[1] << 8) + pTmp[0];
			pTmp   += sizeof(unsigned short);

			/* 5. Get AKM ciphers*/
			/* Parsing all AKM ciphers*/
			while (Count > 0) {
				pAKM = (struct akm_capabe *) pTmp;

				if (!os_memcmp(pTmp, RSN_OUI, 3)
					|| !os_memcmp(pTmp, DPP_OUI, 3)
					) {
				/* Yes continue */
				} else {
					pTmp   += sizeof(struct akm_capabe);
					Count--;
					continue;
				}
				switch (pAKM->suite_type) {
				case 0:
					SET_AKM_WPANONE(pBss->AKMMap);
					break;

				case 1:
					SET_AKM_WPA2(pBss->AKMMap);
					break;

				case 2:
					if (!os_memcmp(pTmp, RSN_OUI, 3))
						SET_AKM_WPA2PSK(pBss->AKMMap);
					if (!os_memcmp(pTmp, DPP_OUI, 3)) {
						SET_AKM_DPP(pBss->AKMMap);
						pBss->IsSupportSHA256KeyDerivation = TRUE;
					}
					break;

				case 3:
					SET_AKM_FT_WPA2(pBss->AKMMap);
					break;

				case 4:
					SET_AKM_FT_WPA2PSK(pBss->AKMMap);
					break;

				case 5:
					/* SET_AKM_WPA2_SHA256(pBss->AKMMap); */
					SET_AKM_WPA2(pBss->AKMMap);
					SET_AKM_WPA3(pBss->AKMMap);
					pBss->IsSupportSHA256KeyDerivation = TRUE;
					break;

				case 6:
					/* SET_AKM_WPA2PSK_SHA256(pBss->AKMMap); */
					SET_AKM_WPA2PSK(pBss->AKMMap);
					pBss->IsSupportSHA256KeyDerivation = TRUE;
					break;

				case 7:
					SET_AKM_TDLS(pBss->AKMMap);
					break;

				case 8:
					SET_AKM_SAE_SHA256(pBss->AKMMap);
					break;

				case 9:
					SET_AKM_FT_SAE_SHA256(pBss->AKMMap);
					break;

				case 11:
					SET_AKM_SUITEB_SHA256(pBss->AKMMap);
					break;

				case 12:
					SET_AKM_SUITEB_SHA384(pBss->AKMMap);
					break;

				case 13:
					SET_AKM_FT_WPA2_SHA384(pBss->AKMMap);
					break;

				case 18:
					SET_AKM_OWE(pBss->AKMMap);
					break;

				case 24:
					SET_AKM_SAE_EXT(pBss->AKMMap);
					break;

				case 25:
					SET_AKM_FT_SAE_EXT(pBss->AKMMap);
					break;

				default:
					break;
				}
				pTmp   += sizeof(struct akm_capabe);
				Count--;
			}

			/* Fixed for WPA-None*/
			// if (pBss->BssType == BSS_ADHOC)
			//	SET_AKM_WPANONE(pBss->AKMMap);

			/* 6. Get RSN capability*/
			if (end_field < RSN_FIELD_RSN_CAP)
				break;
			/*pBss->WPA2.RsnCapability = *(unsigned char*) pTmp;*/
			pBss->RsnCapability = (pTmp[1] << 8) + pTmp[0];
			pTmp += sizeof(unsigned short);
			break;
		case WLAN_EID_RSNX:
			if (pEid->Octet[0] & (1 << WLAN_RSNX_CAPAB_SAE_H2E)) {
				// if (pEid->Octet[0] & (1 << WLAN_RSNX_CAPAB_SAE_PK))
				//	pBss->sae_conn_type = SAE_CONNECTION_TYPE_SAEPK;
				// else
				//	pBss->sae_conn_type = SAE_CONNECTION_TYPE_H2E;
			}
			pBss->rsnxe_len = pEid->Len + 2;

			if (pBss->rsnxe_len > ARRAY_SIZE(pBss->rsnxe_content))
				pBss->rsnxe_len = ARRAY_SIZE(pBss->rsnxe_content);

			NdisMoveMemory(pBss->rsnxe_content, (UCHAR *)pEid, pBss->rsnxe_len);
			break;

		case WLAN_EID_BSS_AC_ACCESS_DELAY:
			pRsnHeader = (struct _RSN_IE_HEADER_STRUCT *) pTmp;

			/* 0. The version number must be 1*/
			if (le2cpu16(pRsnHeader->Version) != 1)
				break;

			pTmp += sizeof(struct _RSN_IE_HEADER_STRUCT);
			/* 1. Get AKM suite counts*/
			NdisMoveMemory(&Count, pTmp, sizeof(unsigned short));
			Count = cpu2le16(Count);
			pTmp += sizeof(unsigned short);
			/* 2. Get AKM ciphers*/
			pAKM = (struct akm_capabe *) pTmp;

			if (os_memcmp(pTmp, WAPI_OUI, 3))
				break;

			switch (pAKM->suite_type) {
			case 1:
				SET_AKM_WAICERT(pBss->AKMMap);
				break;

			case 2:
				SET_AKM_WPIPSK(pBss->AKMMap);
				break;

			default:
				break;
			}

			pTmp += (Count * sizeof(struct akm_capabe));
			/* 3. Get pairwise cipher counts*/
			NdisMoveMemory(&Count, pTmp, sizeof(unsigned short));
			Count = cpu2le16(Count);
			pTmp += sizeof(unsigned short);

			/* 4. Get pairwise cipher*/
			/* Parsing all unicast cipher suite*/
			while (Count > 0) {
				if (os_memcmp(pTmp, WAPI_OUI, 3))
					break;

				/* Skip OUI*/
				pCipher = (struct akm_capabe *) pTmp;

				switch (pCipher->suite_type) {
				case 1:
					SET_CIPHER_WPI_SMS4(pBss->PairwiseCipher);
					break;

				default:
					break;
				}

				pTmp += sizeof(struct akm_capabe);
				Count--;
			}

			/* 5. Check group cipher*/
			if (os_memcmp(pTmp, WAPI_OUI, 3))
				break;

			pCipher = (struct akm_capabe *) pTmp;

			/* Parse group cipher*/
			switch (pCipher->suite_type) {
			case 1:
				SET_CIPHER_WPI_SMS4(pBss->GroupCipher);
				break;

			default:
				break;
			}

			/* set to correct offset for next parsing*/
			pTmp += sizeof(struct akm_capabe);
			/* update the WAPI capability*/
			pBss->RsnCapability = (pTmp[1] << 8) + pTmp[0];
			pTmp += sizeof(unsigned short);
			break;

		default:
			break;
		}

		Length -= (pEid->Len + 2);
	}
}

static size_t ieee802_11_fragments_length(struct wapp_scan_info *elems,
					  const u8 *start, size_t len)
{
	const struct element *elem;
	size_t frags_len = 0;

	for_each_element(elem, start, len) {
		if (elem->id != WLAN_EID_FRAGMENT)
			break;
		frags_len += elem->datalen + 2;
	}

	return frags_len;
}

static size_t ieee802_11_calculate_len(const u8 *ptr, int  len, int frag, int *full_len, int ml_ie_len)
{
	int local;
	int total = 0;

	while ((len + total) < ml_ie_len &&
		ptr[len + total] == frag) {
		local = ptr[len + total + 1];
		len += local;
		total += 2;
	}
	if (full_len != NULL)
		*full_len = len + total;
	return len;
}

static int finaldata(uint8_t *ptr, uint8_t *new_ptr, int copy_len, int find_f2, int frag_ie)
{
	int start_len = 0, skip_frag_ie = 0;

	memcpy(new_ptr + start_len, ptr + start_len + skip_frag_ie, copy_len);
	while (copy_len == 255 && ptr[find_f2] == frag_ie) {

		start_len += copy_len;
		copy_len = ptr[find_f2 + 1];
		find_f2 += copy_len + 2;
		skip_frag_ie += 2;
		memcpy(new_ptr + start_len, ptr + start_len + skip_frag_ie, copy_len);
	}
	if (start_len == 0)
		start_len = copy_len;
	else
		start_len += copy_len;
	return start_len;
}

static int sta_extended_ie_parse(struct wapp_scan_info *elems, u8 *per_sta, int per_sta_curr, int elen, int sta_profile_count)
{

	struct he_op_ie he_ops;
	struct he_op_ie *ptr_he_ops = &he_ops;
	struct he_6g_op_info he_6g_ops;
	struct he_6g_op_info *ptr_he_6g_ops = &he_6g_ops;
	struct eht_op_ie eht_op;
	struct Scan_data scan_info = { 0 };
	u8 txrx_stream = 0;
	uint8_t he_ch_width = HE_BW_80;
	int he_op_bw = 0;

	if (elems == NULL) {
		debug(DEBUG_CAT_NL80211, "No data of extended ie's available to parse\n");
		return -1;
	}

	switch (per_sta[per_sta_curr]) {
	case WLAN_EID_EXT_HE_CAPABILITIES:
		he_ch_width = ((((uint32_t)per_sta[per_sta_curr + 7])
			& (0x7F << 1)) >> 1);
		if (sta_profile_count >= STA_MLD_LINK_MIN && sta_profile_count < STA_MLD_LINK_MAX) {
			NdisCopyMemory(elems->bss.ml_info.sta_profiles[sta_profile_count].he_cap.he_mcs, per_sta + 18,
				sizeof(elems->bss.ml_info.sta_profiles[sta_profile_count].he_cap.he_mcs));
			if (he_ch_width == HE_BW_160)
				elems->bss.ml_info.sta_profiles[sta_profile_count].he_cap.he_160 = 1;
			else
				elems->bss.ml_info.sta_profiles[sta_profile_count].he_cap.he_160 = 0;
		} else {
			debug(DEBUG_CAT_NL80211, "Error due to invalid sta profile count\n");
		}
		break;
	case WLAN_EID_EXT_HE_OPERATION:
		os_memcpy(ptr_he_ops, per_sta, sizeof(struct he_op_ie));
		if (he_ops.he_op_param.param2 & (1<<1)) {
			os_memcpy(ptr_he_6g_ops, per_sta + per_sta_curr + sizeof(struct he_op_ie),
				sizeof(struct he_6g_op_info));
			he_op_bw = he_6g_ops.ctrl & 0x03;
			if (sta_profile_count >= STA_MLD_LINK_MIN && sta_profile_count < STA_MLD_LINK_MAX) {
				if (he_op_bw == 1)
					elems->bss.ml_info.sta_profiles[sta_profile_count]
						.ht_cap.ht_40 = 1;
				else if (he_op_bw == 2)
					elems->bss.ml_info.sta_profiles[sta_profile_count]
						.vht_cap.vht_160 = 1;
				else if (he_op_bw == 3)
					elems->bss.ml_info.sta_profiles[sta_profile_count]
						.vht_cap.vht_160 = 2;
			} else {
				debug(DEBUG_CAT_NL80211, "Error due to invalid sta profile count\n");
			}
		}
		break;
	case WLAN_EID_EXT_HE_6GHZ_BAND_CAP:
		break;
	case WLAN_EID_EXT_EHT_CAPABILITIES:
		txrx_stream = per_sta[per_sta_curr + 12];
		if (sta_profile_count >= STA_MLD_LINK_MIN && sta_profile_count < STA_MLD_LINK_MAX) {
			elems->bss.ml_info.sta_profiles[sta_profile_count].eht_cap.rx_stream = txrx_stream & 0x0f;
			elems->bss.ml_info.sta_profiles[sta_profile_count].eht_cap.tx_stream = (txrx_stream & 0xf0) >> 4;
		}
		break;
	case WLAN_EID_EXT_EHT_OPERATION:
		eht_get_op_ie(per_sta + per_sta_curr, elen, &scan_info);
		if (scan_info.EHT_OP_INFO_EXISTS)
			os_memcpy(&eht_op, &scan_info.eht_op, sizeof(struct eht_op_ie));
		else
			os_memcpy(&eht_op, &scan_info.eht_op, EHT_OP_IE_BASIC_LEN);

		if (sta_profile_count >= STA_MLD_LINK_MIN && sta_profile_count < STA_MLD_LINK_MAX) {
			elems->bss.ml_info.sta_profiles[sta_profile_count].eht_cap.eht_ch_width = eht_op.op_info.control;
			elems->bss.ml_info.sta_profiles[sta_profile_count].eht_cap.ccfs0 = eht_op.op_info.ccfs0;
			elems->bss.ml_info.sta_profiles[sta_profile_count].eht_cap.ccfs1 = eht_op.op_info.ccfs1;
		} else {
			debug(DEBUG_CAT_NL80211, "Error due to invalid sta profile count\n");
		}
		break;
	default:
		debug(DEBUG_CAT_NL80211, "No need to process not our data\n");
	}
	return 0;
}

static int ieee802_11_parse_mle(u8 *pos, size_t elen, size_t total_len,
				struct wapp_scan_info *elems, struct wapp_dev *wdev)
{
	unsigned int sta_profile_count = 0;
	int ml_ie_len = total_len, sta_sub_ie_len = 0;
	int current_pos = -2;
	uint16_t ml_control, sta_control = 0;
	u8 *per_sta = NULL;


	current_pos++;
	/* current_pos at LENGTH of IE */
	current_pos++;
	/* current_pos at MULTI_LINK_TAG_NUM*/
	current_pos++;
	/* current_pos at MULTI_LINK_CONTROL*/
	os_memcpy(&ml_control, pos + current_pos, sizeof(uint16_t));

	current_pos += 2;
	/* MULTI_LINK COMMON INFO*/
	if (ml_ie_len <= current_pos)
		return 0;
	current_pos++;

#ifdef DEBUG123
	// For dumping stainfo data
	for (int i = 0; i < ml_ie_len; i++)
		printf("%02x ", pos[i]);
	printf("\n");
#endif
	os_memcpy(elems->bss.ml_info.mld_addr, pos + current_pos, MAC_ADDR_LEN);

	current_pos += MAC_ADDR_LEN;
	if (ml_control & 0x0010) {
		/* current_pos at Link ID info*/
		current_pos++;
	}

	if (ml_control & 0x0020) {
		/* current_pos at BSS Parameters Change Count*/
		current_pos++;
	}

	if (ml_control & 0x0040) {
		/* current_pos at Medium Synchronization Delay information*/
		current_pos += 2;
	}

	if (ml_control & 0x0080) {
		/* current_pos at EML Capabilities */
		current_pos += 2;
	}

	if (ml_control & 0x0100) {
		/* current_pos at MLD Capabilities */
		current_pos += 2;
	}

	if (ml_control & 0x0200) {
		/* current_pos at MLD ID*/
		current_pos++;
	}

	if (ml_control & 0x0400) {
		/* current_pos at EXTENDED MLD Capabilities and Operations*/
		current_pos += 2;
	}

	if (ml_ie_len <= current_pos) {
		debug(DEBUG_CAT_NL80211, "current_pos=%d\n", current_pos);
		debug(DEBUG_CAT_NL80211, "ml_ie_len=%d\n", ml_ie_len);
		return 0;
	}

	current_pos += pos[current_pos];

	if (ml_ie_len <= current_pos) {
		debug(DEBUG_CAT_NL80211, "current_pos=%d\n", current_pos);
		debug(DEBUG_CAT_NL80211, "ml_ie_len=%d\n", ml_ie_len);
		return 0;
	}
	/* current_pos at Link Info*/
	elems->bss.ml_info.link_num = 0;
	while (current_pos < ml_ie_len) {
		int full_len = 0;
		int subIELen = pos[current_pos + 1];
		int per_sta_curr = 0;

		if (subIELen == 255) {
			subIELen = ieee802_11_calculate_len(pos + current_pos + 2, 255, 254, &full_len, ml_ie_len - current_pos - 2);
			per_sta = os_zalloc(subIELen);
			if (!per_sta) {
				debug(DEBUG_CAT_NL80211, "per_sta allocation fail subIELen  = %d\n", subIELen);
				return 0;
			}
			subIELen = finaldata(pos + current_pos + 2, per_sta, 255, 255, 254);
		} else {
			per_sta = os_zalloc(subIELen);
			if (!per_sta) {
				debug(DEBUG_CAT_NL80211, "per_sta allocation fail subIELen  = %d\n", subIELen);
				return 0;
			}
			os_memcpy(per_sta, pos + current_pos + 2, subIELen);
			full_len = subIELen;
		}

		current_pos += 2; /* subIE_ID and length*/
		os_memcpy(&sta_control, per_sta + per_sta_curr, 2);

		elems->bss.ml_info.link_num += 1;
		elems->bss.ml_info.sta_profiles[sta_profile_count].link_id = sta_control&0x0f;
		if (sta_control & 0x0020) {
			os_memcpy(&elems->bss.ml_info.sta_profiles[sta_profile_count]
				.link_addr, per_sta + per_sta_curr + 3, MAC_ADDR_LEN);
		}

		per_sta_curr += 2;

		if (wdev) {
			if (WMODE_CAP_6G(wdev->wireless_mode)) {
				elems->bss.ml_info.sta_profiles[0].rfband = 0;
				elems->bss.ml_info.sta_profiles[1].rfband = 1;
				elems->bss.ml_info.sta_profiles[2].rfband = 255;
			} else if (WMODE_CAP_5G(wdev->wireless_mode)) {
				elems->bss.ml_info.sta_profiles[0].rfband = 0;
				elems->bss.ml_info.sta_profiles[1].rfband = 255;
				elems->bss.ml_info.sta_profiles[2].rfband = 2;
			} else if (WMODE_CAP_2G(wdev->wireless_mode)) {
				elems->bss.ml_info.sta_profiles[0].rfband = 255;
				elems->bss.ml_info.sta_profiles[1].rfband = 1;
				elems->bss.ml_info.sta_profiles[2].rfband = 2;
			}
		}
		per_sta_curr += per_sta[per_sta_curr];
		per_sta_curr += 2;
		while (per_sta_curr < subIELen) {
			sta_sub_ie_len = per_sta[per_sta_curr + 1];

			per_sta_curr += 2;
			/* Tagged Parameters*/
			switch (per_sta[per_sta_curr - 2]) {

			case WLAN_EID_DS_PARAMS:
				elems->bss.ml_info.sta_profiles[sta_profile_count]
					.channel = per_sta[per_sta_curr];
				break;
			case WLAN_EID_HT_CAP:
				elems->bss.ml_info.sta_profiles[sta_profile_count]
					.ht_cap.tx_stream = 0;/* TODO */
				elems->bss.ml_info.sta_profiles[sta_profile_count]
					.ht_cap.rx_stream = 0;/* TODO */

				elems->bss.ml_info.sta_profiles[sta_profile_count]
					.ht_cap.sgi_20 = per_sta[per_sta_curr] & BIT(5) ? 1 : 0;
				elems->bss.ml_info.sta_profiles[sta_profile_count]
					.ht_cap.sgi_40 = per_sta[per_sta_curr] & BIT(6) ? 1 : 0;
				elems->bss.ml_info.sta_profiles[sta_profile_count]
					.ht_cap.ht_40 = per_sta[per_sta_curr] & BIT(1) ? 1 : 0;
				break;
			case WLAN_EID_HT_OPERATION:
				elems->bss.ml_info.sta_profiles[sta_profile_count].ht_cap.ht_40 =
					per_sta[per_sta_curr + 1] & BIT(2) ? 1 : 0;/*current operating bw*/
				break;
			case WLAN_EID_VHT_CAP:

				NdisCopyMemory(elems->bss.ml_info.sta_profiles[sta_profile_count]
					.vht_cap.sup_tx_mcs, pos + current_pos + 8,
						sizeof(elems->bss.ml_info.sta_profiles[sta_profile_count].vht_cap.sup_tx_mcs));
				NdisCopyMemory(elems->bss.ml_info.sta_profiles[sta_profile_count]
					.vht_cap.sup_rx_mcs, pos + current_pos + 4,
						sizeof(elems->bss.ml_info.sta_profiles[sta_profile_count].vht_cap.sup_rx_mcs));
				if (((per_sta[per_sta_curr + 6] & 0xc0) >> 6) != VHT_MCS_CAP_NA)
					elems->bss.ml_info.sta_profiles[sta_profile_count].vht_cap.rx_stream = 4;
				else if (((per_sta[per_sta_curr + 6] & 0x30) >> 4) != VHT_MCS_CAP_NA)
					elems->bss.ml_info.sta_profiles[sta_profile_count].vht_cap.rx_stream = 3;
				else if (((per_sta[per_sta_curr + 6] & 0x0c) >> 2) != VHT_MCS_CAP_NA)
					elems->bss.ml_info.sta_profiles[sta_profile_count].vht_cap.rx_stream = 2;
				else
					elems->bss.ml_info.sta_profiles[sta_profile_count].vht_cap.rx_stream = 1;

				if (((per_sta[per_sta_curr + 8] & 0xc0) >> 6) != VHT_MCS_CAP_NA)
					elems->bss.ml_info.sta_profiles[sta_profile_count].vht_cap.tx_stream = 4;
				else if (((per_sta[per_sta_curr + 8] & 0x30) >> 4) != VHT_MCS_CAP_NA)
					elems->bss.ml_info.sta_profiles[sta_profile_count].vht_cap.tx_stream = 3;
				else if (((per_sta[per_sta_curr + 8] & 0x0c) >> 2) != VHT_MCS_CAP_NA)
					elems->bss.ml_info.sta_profiles[sta_profile_count].vht_cap.tx_stream = 2;
				else
					elems->bss.ml_info.sta_profiles[sta_profile_count].vht_cap.tx_stream = 1;

				elems->bss.ml_info.sta_profiles[sta_profile_count]
					.vht_cap.sgi_80 = per_sta[per_sta_curr] & 0x20 ? 1 : 0;
				elems->bss.ml_info.sta_profiles[sta_profile_count]
					.vht_cap.sgi_160 = per_sta[per_sta_curr] & 0x40 ? 1 : 0;
				elems->bss.ml_info.sta_profiles[sta_profile_count]
					.vht_cap.vht_8080 = 0; /* TODO */
				elems->bss.ml_info.sta_profiles[sta_profile_count]
					.vht_cap.su_bf = per_sta[per_sta_curr + 1] & 0x18 ? 1 : 0;
				elems->bss.ml_info.sta_profiles[sta_profile_count]
					.vht_cap.mu_bf = per_sta[per_sta_curr + 2] & 0x18 ? 1 : 0;
				break;
			case WLAN_EID_VHT_OPERATION:
				elems->bss.ml_info.sta_profiles[sta_profile_count]
					.vht_cap.vht_160 = per_sta[per_sta_curr + 0];
				break;
			case WLAN_EID_EXTENSION:
				err(DEBUG_CAT_NL80211, "sta_sub_ie_len = %d\n", sta_sub_ie_len);
				sta_extended_ie_parse(elems, per_sta, per_sta_curr, sta_sub_ie_len, sta_profile_count);
				break;
			default:
				break;
			}
			per_sta_curr += sta_sub_ie_len;
		}
		sta_profile_count++;
		current_pos += full_len;
		os_free(per_sta);
	}
	return 0;
}

u8 peer_max_bw_cap(signed char ch_width_set)
{
	u8 ch_width = HE_BW_20;

	if (ch_width_set & SUPP_40M_CW_IN_24G_BAND)
		ch_width = HE_BW_2040;
	if (ch_width_set & SUPP_40M_80M_CW_IN_5G_6G_BAND) {
		ch_width = HE_BW_80;
		if (ch_width_set & SUPP_160M_8080M_CW_IN_5G_6G_BAND)
			ch_width = HE_BW_8080;
		if (ch_width_set & SUPP_160M_CW_IN_5G_6G_BAND)
			ch_width = HE_BW_160;
	}
	return ch_width;
}

static int ieee802_11_parse_extension(const u8 *pos, size_t elen,
	struct wapp_scan_info *elems, const u8 *start, size_t len, struct wapp_dev *wdev, struct Scan_data *scan_info)
{
	u8 ext_id;
	int ful_len = 0;
	size_t total_len2 = 0;
	u8 *ptr = NULL;
	int partial_ie_len, ch_width;
	u8 *new_ptr = NULL;

	if (elen < 1)
		return -1;

	ext_id = *pos++;
	elen--;

	switch (ext_id) {
	case WLAN_EID_EXT_HE_CAPABILITIES:
		scan_info->HE_CAP_IE_EXISTS = 1;
		scan_info->he_ch_width = (pos[6] & 0xF7) >> 1;
		os_memcpy(elems->bss.he_cap.he_mcs, pos + 17, sizeof(elems->bss.he_cap.he_mcs));

		os_memcpy(&(scan_info->he_caps), pos, sizeof(scan_info->he_caps));
		scan_info->he_ch_width = peer_max_bw_cap(
			GET_DOT11AX_CH_WIDTH(scan_info->he_caps.phy_cap.phy_capinfo_1));
		if (scan_info->he_ch_width == HE_BW_160)
			elems->bss.he_cap.he_160 = 1;
		else
			elems->bss.he_cap.he_160 = 0;
		break;
	case WLAN_EID_EXT_HE_OPERATION:
		scan_info->HE_OP_IE_EXISTS = 1;
		os_memcpy(&(scan_info->he_ops), pos, sizeof(struct he_op_ie));

		if (scan_info->he_ops.he_op_param.param2 & (1<<1)) {
			os_memcpy(&(scan_info->he_6g_ops), pos + sizeof(struct he_op_ie), sizeof(struct he_6g_op_info));

			scan_info->he_op_bw = scan_info->he_6g_ops.ctrl & 0x03;
			if (scan_info->he_op_bw == 1)
				elems->bss.ht_cap.ht_40 = 1;
			else if (scan_info->he_op_bw == 2)
				elems->bss.vht_cap.vht_160 = 1;
			else if (scan_info->he_op_bw == 3)
				elems->bss.vht_cap.vht_160 = 2;
		}

		if (scan_info->he_ops.he_op_param.param2 & (1<<1)) {
			if (scan_info->he_6g_ops.ccfs_1 != 0)
				elems->bss.CentralChannel = scan_info->he_6g_ops.ccfs_1;
			else if (scan_info->he_6g_ops.ccfs_0 != 0)
				elems->bss.CentralChannel = scan_info->he_6g_ops.ccfs_0;
		}

		break;
	case WLAN_EID_EXT_HE_6GHZ_BAND_CAP:
		break;
	case WLAN_EID_EXT_EHT_CAPABILITIES:
		if (elen == 254)
			break;

		os_memcpy(&(scan_info->eht_cap_ie), pos, sizeof(scan_info->eht_cap_ie));
		scan_info->EHT_CAP_IE_EXISTS = 1;
		partial_ie_len = sizeof(scan_info->eht_cap_ie);
		pos = pos + partial_ie_len;
		partial_ie_len = elen - partial_ie_len;

		if (partial_ie_len == 0)
			break;
		ch_width = peer_max_bw_cap(GET_DOT11AX_CH_WIDTH(scan_info->he_caps.phy_cap.phy_capinfo_1));
		if (ch_width == HE_BW_20) {
			if (partial_ie_len >= sizeof(struct eht_txrx_mcs_nss_20))
				os_memcpy(&scan_info->eht_support_mcs_nss.eht_txrx_mcs_nss_20_only, pos,
					sizeof(struct eht_txrx_mcs_nss_20));
			if (partial_ie_len != EHT_NSS_MCS_20M_ONLY && partial_ie_len >= sizeof(struct eht_txrx_mcs_nss)) {
				os_memcpy(&scan_info->eht_support_mcs_nss.eht_txrx_mcs_nss[0], pos, sizeof(struct eht_txrx_mcs_nss));
				scan_info->eht_support_mcs_nss.eht_txrx_mcs_nss_20_only.max_tx_rx_mcs0_7_nss = 0;
				scan_info->eht_support_mcs_nss.eht_txrx_mcs_nss_20_only.max_tx_rx_mcs0_7_nss
				|= (scan_info->eht_support_mcs_nss.eht_txrx_mcs_nss[0].max_tx_rx_mcs0_9_nss & DOT11BE_MCS_NSS_MASK);
				scan_info->eht_support_mcs_nss.eht_txrx_mcs_nss_20_only.max_tx_rx_mcs0_7_nss
				|= (scan_info->eht_support_mcs_nss.eht_txrx_mcs_nss[0].max_tx_rx_mcs0_9_nss
				& (DOT11BE_MCS_NSS_MASK << DOT11BE_MCS_NSS_SHIFT));
				scan_info->eht_support_mcs_nss.eht_txrx_mcs_nss_20_only.max_tx_rx_mcs8_9_nss = 0;
				scan_info->eht_support_mcs_nss.eht_txrx_mcs_nss_20_only.max_tx_rx_mcs8_9_nss
				|= (scan_info->eht_support_mcs_nss.eht_txrx_mcs_nss[0].max_tx_rx_mcs0_9_nss & DOT11BE_MCS_NSS_MASK);
				scan_info->eht_support_mcs_nss.eht_txrx_mcs_nss_20_only.max_tx_rx_mcs8_9_nss
				|= (scan_info->eht_support_mcs_nss.eht_txrx_mcs_nss[0].max_tx_rx_mcs0_9_nss
				& (DOT11BE_MCS_NSS_MASK << DOT11BE_MCS_NSS_SHIFT));
				scan_info->eht_support_mcs_nss.eht_txrx_mcs_nss_20_only.max_tx_rx_mcs10_11_nss = 0;
				scan_info->eht_support_mcs_nss.eht_txrx_mcs_nss_20_only.max_tx_rx_mcs10_11_nss
				|= (scan_info->eht_support_mcs_nss.eht_txrx_mcs_nss[0].max_tx_rx_mcs10_11_nss & DOT11BE_MCS_NSS_MASK);
				scan_info->eht_support_mcs_nss.eht_txrx_mcs_nss_20_only.max_tx_rx_mcs10_11_nss
				|= (scan_info->eht_support_mcs_nss.eht_txrx_mcs_nss[0].max_tx_rx_mcs10_11_nss
				& (DOT11BE_MCS_NSS_MASK << DOT11BE_MCS_NSS_SHIFT));
				scan_info->eht_support_mcs_nss.eht_txrx_mcs_nss_20_only.max_tx_rx_mcs12_13_nss = 0;
				scan_info->eht_support_mcs_nss.eht_txrx_mcs_nss_20_only.max_tx_rx_mcs12_13_nss
				|= (scan_info->eht_support_mcs_nss.eht_txrx_mcs_nss[0].max_tx_rx_mcs12_13_nss & DOT11BE_MCS_NSS_MASK);
				scan_info->eht_support_mcs_nss.eht_txrx_mcs_nss_20_only.max_tx_rx_mcs12_13_nss
				|= (scan_info->eht_support_mcs_nss.eht_txrx_mcs_nss[0].max_tx_rx_mcs12_13_nss
				& (DOT11BE_MCS_NSS_MASK << DOT11BE_MCS_NSS_SHIFT));
			}
		} else {
			if (partial_ie_len >= sizeof(struct eht_txrx_mcs_nss))
				os_memcpy(&scan_info->eht_support_mcs_nss.eht_txrx_mcs_nss[0],
				pos, sizeof(struct eht_txrx_mcs_nss));
			if (partial_ie_len == EHT_NSS_MCS_20M_ONLY)
				os_memcpy(&scan_info->eht_support_mcs_nss.eht_txrx_mcs_nss_20_only,
				pos, sizeof(struct eht_txrx_mcs_nss_20));
			pos += sizeof(struct eht_txrx_mcs_nss);
			partial_ie_len -= sizeof(struct eht_txrx_mcs_nss);

			if (ch_width >= HE_BW_160 && partial_ie_len >= sizeof(struct eht_txrx_mcs_nss)) {
				os_memcpy(&scan_info->eht_support_mcs_nss.eht_txrx_mcs_nss[1], pos, sizeof(struct eht_txrx_mcs_nss));
				pos += sizeof(struct eht_txrx_mcs_nss);
				partial_ie_len -= sizeof(struct eht_txrx_mcs_nss);

				if (scan_info->eht_cap_ie.phy_cap.phy_capinfo_1 & DOT11BE_PHY_CAP_320M_6G &&
					partial_ie_len >= sizeof(struct eht_txrx_mcs_nss))
					os_memcpy(&scan_info->eht_support_mcs_nss.eht_txrx_mcs_nss[2],
					pos, sizeof(struct eht_txrx_mcs_nss));
			}
		}

		break;
	case WLAN_EID_EXT_EHT_OPERATION:
		//os_memcpy(&(scan_info->eht_op), pos, sizeof(struct eht_op_ie));
		eht_get_op_ie(pos, elen, scan_info);
		break;
	case WLAN_EID_EXT_MULTI_LINK:
		scan_info->MULTI_LINK_PRESENT = 1;
		if (elen == 254) {
			total_len2 += 255 + ieee802_11_fragments_length(
					elems, pos + elen, (start + len) - (pos + elen));
			pos--;

			ptr = os_zalloc(total_len2);
			if (!ptr) {
				debug(DEBUG_CAT_NL80211, "ptr allocation fail total_len2 = %zu\n", total_len2);
				return 0;
			}
			os_memcpy(ptr, pos, total_len2);
			ful_len = ieee802_11_calculate_len(pos, 255, 242, NULL, total_len2);
			new_ptr = os_zalloc(ful_len);
			if (!new_ptr) {
				debug(DEBUG_CAT_NL80211, "new_ptr allocation fail ful_len = %d\n", ful_len);
				os_free(ptr);
				return 0;
			}
			ful_len = finaldata(ptr, new_ptr, 255, 255, 242);
			ieee802_11_parse_mle(new_ptr, elen, ful_len, elems, wdev);
			os_free(new_ptr);
			os_free(ptr);

		} else {
			pos--;
			ptr = os_zalloc(elen + 1);
			if (!ptr) {
				debug(DEBUG_CAT_NL80211, "ptr allocation fail elen  = %zu\n", (elen + 1));
				return 0;
			}
			os_memcpy(ptr, pos, elen + 1);
			ieee802_11_parse_mle(ptr, elen, elen + 1, elems, wdev);
			os_free(ptr);
		}

		break;
	default:
		debug(DEBUG_CAT_NL80211, "No need to process not our data\n");
	}

	return 0;
}

void map_parse_vendor_ie(struct scan_bss_info *vendor_ie, struct element *info_elem)
{
#ifdef MAP_R6
	unsigned int *rate;
#else
	short *rate;
#endif
	u8 *end = &(info_elem->data[info_elem->datalen]);
	u8 *ptr = &(info_elem->data[7]);

	vendor_ie->map_info.type = *ptr;
	ptr++;
	vendor_ie->map_info.subtype = *ptr;
	ptr++;
	vendor_ie->map_info.root_distance = *ptr;
	ptr++;
	vendor_ie->map_info.connectivity_to_controller = *ptr;
	ptr++;
#ifdef MAP_R6
	rate = (unsigned int *)ptr;
#else
	rate = (short *)ptr;
#endif
	vendor_ie->map_info.uplink_rate = *rate;
#ifdef MAP_R6
	ptr += 4;
#else
	ptr += 2;
#endif
	if ((ptr+MAC_ADDR_LEN) <= end) {
		NdisCopyMemory(vendor_ie->map_info.uplink_bssid, ptr, MAC_ADDR_LEN);
		ptr += MAC_ADDR_LEN;
	}

	if ((ptr+MAC_ADDR_LEN) <= end) {
		NdisCopyMemory(vendor_ie->map_info.bssid_5g, ptr, MAC_ADDR_LEN);
		ptr += MAC_ADDR_LEN;
	}

	if ((ptr+MAC_ADDR_LEN) <= end)
		NdisCopyMemory(vendor_ie->map_info.bssid_2g, ptr, MAC_ADDR_LEN);
}

void dump_eht_cap(struct wdev_eht_cap eht_cap)
{
	err(DEBUG_CAT_NL80211, "=========scan result EHT cap===\n");
	err(DEBUG_CAT_NL80211, "\n\t rx_stream = %d\n"
						"\t tx_stream = %d\n"
						"\t eht_ch_width = %d\n"
						"\t ccfs0 = %d\n"
						"\t ccfs1 = %d\n",
						eht_cap.rx_stream,
						eht_cap.tx_stream,
						eht_cap.eht_ch_width,
						eht_cap.ccfs0,
						eht_cap.ccfs1);
}
void dump_he_cap(struct _wdev_he_cap he_cap)
{
	err(DEBUG_CAT_NL80211, "=========scan result HE cap===\n");
	err(DEBUG_CAT_NL80211, "\n\t rx_stream = %d\n"
						"\t tx_stream = %d\n",
						he_cap.rx_stream,
						he_cap.tx_stream);
}
void dump_vht_cap(struct _wdev_vht_cap vht_cap)
{
	err(DEBUG_CAT_NL80211, "=========scan result VHT cap===\n");
	err(DEBUG_CAT_NL80211, "\n\t rx_stream = %d\n"
						"\t tx_stream = %d\n",
						vht_cap.rx_stream,
						vht_cap.tx_stream);
}
void dump_ht_cap(struct _wdev_ht_cap ht_cap)
{
	err(DEBUG_CAT_NL80211, "=========scan result HT cap===\n");
	err(DEBUG_CAT_NL80211, "\n\t rx_stream = %d\n"
						"\t tx_stream = %d\n"
						"\t ht_40 = %d\n",
						ht_cap.rx_stream,
						ht_cap.tx_stream,
						ht_cap.ht_40);
}

void dump_mlinfo_sta_profile(struct sta_profile_info sta[])
{

	int i;

	for (i = 0; i < STA_MLD_LINK_MAX; i++) {
		err(DEBUG_CAT_NL80211, "====staprofile[%d]=====\n", i);
		err(DEBUG_CAT_NL80211, "\n\tsta rfband = %d\n"
		"\t sta  channel = %d\n"
		"\t sta  bw = %d\n"
		"\t tx_stream = %d\n"
		"\t sta  rx_stream = %d\n"
		"\t sta  eht_ch_width = %d\n"
		"\t sta eht ccfs0 = %d\n"
		"\t sta eht ccfs1 = %d\n"
		"\t sta eht link_id = %d\n"
		"\t sta  link_addr = " MACSTR "\n",
		sta[i].rfband,
		sta[i].channel,
		sta[i].bw,
		sta[i].eht_cap.tx_stream,
		sta[i].eht_cap.rx_stream,
		sta[i].eht_cap.eht_ch_width,
		sta[i].eht_cap.ccfs0,
		sta[i].eht_cap.ccfs1,
		sta[i].link_id,
		MAC2STR(sta[i].link_addr));
	}
}

static struct wapp_scan_info *wapp_parse_scan_info(struct driver_nl80211_data *drv,
		       struct nl_msg *msg, struct wifi_app *wapp, unsigned int ifindex)
{

	struct nlattr *tb[NL80211_ATTR_MAX + 1];
	struct wapp_scan_info *r;
	struct genlmsghdr *gnlh = nlmsg_data(nlmsg_hdr(msg));
	struct nlattr *bss[NL80211_BSS_MAX + 1];
	static struct nla_policy bss_policy[NL80211_BSS_MAX + 1] = {
		[NL80211_BSS_FREQUENCY] = { .type = NLA_U32 },
		[NL80211_BSS_FREQUENCY_OFFSET] = { .type = NLA_U32 },
		[NL80211_BSS_BSSID] = { .type = NLA_UNSPEC },
		[NL80211_BSS_INFORMATION_ELEMENTS] = { .type = NLA_UNSPEC },
		[NL80211_BSS_BEACON_IES] = { .type = NLA_UNSPEC },
	};
	struct wapp_dev *wdev = NULL;
	struct Scan_data scan_info = {0};
	struct neighbor_ap_info *nbr_ap_info = NULL;
#ifdef DPP_SUPPORT
	UCHAR dpp_oui[] = {0x50, 0x6f, 0x9a, 0x1e};
#endif
	UCHAR mediatek_oui[] = {0x00, 0x0C, 0xE7};
	UCHAR wpa_oui[] = {0x00, 0x50, 0xf2, 0x01};
	const u8 *ie = NULL, *beacon_ie = NULL, *bss_cap = NULL;
	size_t ie_len = 0, beacon_ie_len = 0, bss_cap_len = 0;
	const struct element *elem;
	struct element *map_ie_ptr = NULL;
	struct off_ch_scan_state_ctrl *scan_state = NULL;
	OFFCHANNEL_SCAN_MSG *scan_msg = NULL;
	int ch_width;

	scan_state = &wapp->map->off_ch_scan_state;
	scan_msg = &scan_state->scan_msg;
	CLEAR_SEC_AKM(scan_info.AKMMap);
	CLEAR_CIPHER(scan_info.PairwiseCipher);
	CLEAR_CIPHER(scan_info.GroupCipher);

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	nla_parse(tb, NL80211_ATTR_MAX, genlmsg_attrdata(gnlh, 0),
			genlmsg_attrlen(gnlh, 0), NULL);
	if (!tb[NL80211_ATTR_BSS]) {
		err(DEBUG_CAT_NL80211, "NL80211_ATTR_MAX fail\n");
		return NULL;
	}
	if (nla_parse_nested(bss, NL80211_BSS_MAX, tb[NL80211_ATTR_BSS],
				bss_policy)) {
		err(DEBUG_CAT_NL80211, "NL80211_BSS_MAX fail\n");
		return NULL;
	}

	if (bss[NL80211_BSS_CAPABILITY]) {
		bss_cap = nla_data(bss[NL80211_BSS_CAPABILITY]);
		bss_cap_len = nla_len(bss[NL80211_BSS_CAPABILITY]);
	} else {
		bss_cap = NULL;
		bss_cap_len = 0;
	}

	if (bss[NL80211_BSS_INFORMATION_ELEMENTS]) {
		ie = nla_data(bss[NL80211_BSS_INFORMATION_ELEMENTS]);
		ie_len = nla_len(bss[NL80211_BSS_INFORMATION_ELEMENTS]);
	} else {
		err(DEBUG_CAT_NL80211, "No Probe IE\n");
		return NULL;
	}
	if (bss[NL80211_BSS_BEACON_IES]) {
		beacon_ie = nla_data(bss[NL80211_BSS_BEACON_IES]);
		beacon_ie_len = nla_len(bss[NL80211_BSS_BEACON_IES]);
	} else {
		err(DEBUG_CAT_NL80211, "No beacon IE\n");
		return NULL;
	}

	r = os_zalloc(sizeof(struct wapp_scan_info));
	if (r == NULL) {
		err(DEBUG_CAT_NL80211, "r alloc fail\n");
		return NULL;
	}

	if (bss[NL80211_BSS_FREQUENCY])
		ieee80211_freq_to_chan(nla_get_u32(bss[NL80211_BSS_FREQUENCY]), (u8 *)&r->bss.Channel);
	if (tb[NL80211_ATTR_IFINDEX])
		r->interface_index = nla_get_u32(tb[NL80211_ATTR_IFINDEX]);

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		int ch = 0;

		for (ch = 0; ch < scan_msg->data.offchannel_param.Num_of_Away_Channel; ch++) {
			if (scan_msg->data.offchannel_param.channel[ch] == r->bss.Channel)
				goto Continue_scan;
		}
		os_free(r);
		return NULL;
	}
Continue_scan:
	if (bss_cap != NULL && bss_cap_len != 0) {
		r->bss.Privacy = bss_cap[0] & BIT(4) ? 1 : 0;
		scan_info.Privacy = bss_cap[0] & BIT(4) ? 1 : 0;
	}

	if (r->bss.Privacy == 1)
		r->bss.AuthMode |= WSC_AUTHTYPE_SHARED;

	if (bss[NL80211_BSS_SIGNAL_MBM]) {
		r->bss.Rssi = (int)nla_get_u32(bss[NL80211_BSS_SIGNAL_MBM])/100;
		r->bss.MinSNR = -5; /* r->bss.Rssi % 10; */
		debug(DEBUG_CAT_NL80211, "r->bss.Rssi %d\n", r->bss.Rssi);
	}
	if (bss[NL80211_BSS_BSSID]) {
		os_memcpy(r->bss.Bssid, nla_data(bss[NL80211_BSS_BSSID]),
			ETH_ALEN);
		debug(DEBUG_CAT_NL80211, "r->bss.Bssid "MACSTR"\n", MAC2STR(r->bss.Bssid));
	}

	for_each_element(elem, beacon_ie, beacon_ie_len) {
		u8 id = elem->id, elen = elem->datalen;
		const u8 *pos = elem->data;
		const u8 *tempP = elem->data;

		switch (id) {
		case WLAN_EID_SSID:
			r->bss.SsidLen = elen;
			os_memcpy(r->bss.Ssid, pos, elen);

			break;
		case WLAN_EID_DS_PARAMS:
			r->bss.Channel = pos[0];
			r->bss.CentralChannel = pos[0];

			break;
		case WLAN_EID_RSN:
			BssCipherParse(&scan_info, (const struct COSR_EID_STRUCT *)elem, tempP);
			break;
		case WLAN_EID_RSNX:
			BssCipherParse(&scan_info, (const struct COSR_EID_STRUCT *)elem, tempP);
			break;
		case WLAN_EID_BSS_LOAD:
			r->bss.QbssLoad.bValid = 1;
			r->bss.QbssLoad.StaNum = (int)pos[0] + (int)pos[1] * 256;
			r->bss.QbssLoad.ChannelUtilization = (int)pos[2];
			r->bss.QbssLoad.RemainingAdmissionControl = (int)pos[3] + (int)pos[4] * 256;
			debug(DEBUG_CAT_NL80211, "QbssLoad.ChannelUtilization %d\n", r->bss.QbssLoad.ChannelUtilization);
			break;
		case WLAN_EID_HT_CAP:
			os_memcpy(&scan_info.ht_cap_ie, pos, sizeof(scan_info.ht_cap_ie));
			r->bss.ht_cap.tx_stream = 0;/* TODO */
			r->bss.ht_cap.rx_stream = 0;/* TODO */

			r->bss.ht_cap.sgi_20 = pos[0] & BIT(5) ? 1 : 0;
			r->bss.ht_cap.sgi_40 = pos[0] & BIT(6) ? 1 : 0;
			r->bss.ht_cap.ht_40 = pos[0] & BIT(1) ? 1 : 0;
			break;
		case WLAN_EID_HT_OPERATION:
			os_memcpy(&scan_info.ht_op_ie, pos, sizeof(scan_info.ht_op_ie));
			r->bss.ht_cap.ht_40 = pos[1] & BIT(2) ? 1 : 0;/*current operating bw*/
			if ((r->bss.Channel > 2) &&
				((pos[1] & 0x3) == EXTCHA_BELOW) &&
					(r->bss.ht_cap.ht_40 == BW_40))
				r->bss.CentralChannel = r->bss.Channel - 2;
			else if (((pos[1] & 0x1) == EXTCHA_ABOVE) &&
					(r->bss.ht_cap.ht_40 == BW_40))
				r->bss.CentralChannel = r->bss.Channel + 2;
			else
				r->bss.CentralChannel = r->bss.Channel;

			break;
		case WLAN_EID_VHT_CAP:

			os_memcpy(&(scan_info.vht_cap_ie), pos, sizeof(scan_info.vht_cap_ie));

			NdisCopyMemory(r->bss.vht_cap.sup_tx_mcs,
							pos + 8,
							sizeof(r->bss.vht_cap.sup_tx_mcs));
			NdisCopyMemory(r->bss.vht_cap.sup_rx_mcs,
							pos + 4,
							sizeof(r->bss.vht_cap.sup_rx_mcs));
			if (((pos[4] & 0xc0) >> 6) != VHT_MCS_CAP_NA)
				r->bss.vht_cap.rx_stream = 4;
			else if (((pos[4] & 0x30) >> 4) != VHT_MCS_CAP_NA)
				r->bss.vht_cap.rx_stream = 3;
			else if (((pos[4] & 0x0c) >> 2) != VHT_MCS_CAP_NA)
				r->bss.vht_cap.rx_stream = 2;
			else
				r->bss.vht_cap.rx_stream = 1;

			if (((pos[8] & 0xc0) >> 6) != VHT_MCS_CAP_NA)
				r->bss.vht_cap.tx_stream = 4;
			else if (((pos[8] & 0x30) >> 4) != VHT_MCS_CAP_NA)
				r->bss.vht_cap.tx_stream = 3;
			else if (((pos[8] & 0x0c) >> 2) != VHT_MCS_CAP_NA)
				r->bss.vht_cap.tx_stream = 2;
			else
				r->bss.vht_cap.tx_stream = 1;

			r->bss.vht_cap.sgi_80 = pos[0] & 0x20 ? 1 : 0;
			r->bss.vht_cap.sgi_160 = pos[0] & 0x40 ? 1 : 0;
			r->bss.vht_cap.vht_8080 = 0; /* TODO */
			r->bss.vht_cap.su_bf = pos[1] & 0x18 ? 1 : 0;
			r->bss.vht_cap.mu_bf = pos[2] & 0x18 ? 1 : 0;
			break;
		case WLAN_EID_VHT_OPERATION:
			os_memcpy(&(scan_info.vht_op_ie), pos, sizeof(scan_info.vht_op_ie));
			r->bss.vht_cap.vht_160 = pos[0];

			BOOLEAN hasTwoNonContiguousChannels = (pos[0] == VHT_BW_8080);
			BOOLEAN hasSingleWideChannel = (pos[0] == VHT_BW_160);
			BOOLEAN IsBW160 = (((pos[2]) - (pos[1])) == 8 ||
				((pos[2]) - (pos[1])) == -8);

			/* VHT operation definition 1 */
			if (hasTwoNonContiguousChannels || hasSingleWideChannel) {
				r->bss.CentralChannel = pos[1];
			/* VHT operation definition 2 */
			} else {
				r->bss.CentralChannel = pos[1];
				if (IsBW160 && pos[2])
					r->bss.CentralChannel = pos[2];
			}
			break;

		case WLAN_EID_REDUCED_NEIGHBOR_REPORT:
		scan_info.RNR_PRESENT = 1;
#ifdef MAP_6E_SUPPORT

			int rnr_len = 0;
			do {
				nbr_ap_info = (struct neighbor_ap_info *) (pos + rnr_len);

				if (IS_OP_CLASS_6G(nbr_ap_info->op_class)) {
					r->bss.rnr_6e.op = nbr_ap_info->op_class;
					r->bss.rnr_6e.channel = nbr_ap_info->ch_num;
				}
				uint8_t count = ((nbr_ap_info->tbtt_info_hdr & DOT11_RNR_TBTT_INFO_HDR_TBTTINFO_CNT_MASK)
				>> DOT11_RNR_TBTT_INFO_HDR_TBTTINFO_CNT_SHIFT) + 1;
				uint8_t tbtt_len = (nbr_ap_info->tbtt_info_hdr & DOT11_RNR_TBTT_INFO_HDR_TBTTINFO_LEN_MASK)
				>> DOT11_RNR_TBTT_INFO_HDR_TBTTINFO_LEN_SHIFT;
				rnr_len += tbtt_len * count + sizeof(struct neighbor_ap_info);
			} while (rnr_len < elen);
#endif
			break;
		case WLAN_EID_VENDOR_SPECIFIC:
#ifdef DPP_SUPPORT
			if (!memcmp(pos, dpp_oui, 4))
				r->bss.rnr_6e.cce_ind = 1;
#endif
			if (!memcmp(pos, mediatek_oui, 3)) {
#define MAP_TURNKEY_IE(B1) ((B1)&0x01)

				if (MAP_TURNKEY_IE(pos[4])) {

					r->bss.map_vendor_ie_found = 1;
					map_ie_ptr = (struct element *)os_zalloc(elem->datalen + 2);
					if (map_ie_ptr) {
						os_memcpy(map_ie_ptr, elem, elem->datalen + 2);
						map_parse_vendor_ie(&(r->bss), map_ie_ptr);
						os_free(map_ie_ptr);
					} else
						err(DEBUG_CAT_NL80211, "map_ie_ptr alloc fail !!\n");
				}
			}

			if (!memcmp(pos, wpa_oui, 4)) {
				BssCipherParse(&scan_info, (const struct COSR_EID_STRUCT *)elem, tempP);
			}
			break;
		default:
			break;
		}
	}

	for_each_element(elem, ie, ie_len) {
		u8 id = elem->id, elen = elem->datalen;
		const u8 *pos = elem->data;

		switch (id) {
		case WLAN_EID_EXTENSION:
			ieee802_11_parse_extension(pos, elen, r, ie, ie_len, wdev, &scan_info);
			break;
		case WLAN_EID_SSID:
			/*hidden ssid need parse probe rsp ie*/
			if (r->bss.SsidLen == 0) {
				r->bss.SsidLen = elen;
				os_memcpy(r->bss.Ssid, pos, elen);
			}
			break;
		default:
			break;
		}
	}
	if (scan_info.AKMMap == 0x0) {
		SET_AKM_OPEN(scan_info.AKMMap);

		if (scan_info.Privacy) {
			SET_AKM_SHARED(scan_info.AKMMap);
			SET_CIPHER_WEP(scan_info.PairwiseCipher);
			SET_CIPHER_WEP(scan_info.GroupCipher);
		} else {
			SET_CIPHER_NONE(scan_info.PairwiseCipher);
			SET_CIPHER_NONE(scan_info.GroupCipher);
		}
	}
	r->bss.AuthMode = WscGetAuthTypeAtWapp(scan_info.AKMMap);
	r->bss.EncrypType = WscGetEncryTypeAtWapp(scan_info.PairwiseCipher);

	if (scan_info.MULTI_LINK_PRESENT)
		r->bss.ml_capable = 1;

	if (scan_info.EHT_OP_INFO_EXISTS) {
		scan_info.w_eht_cap.eht_ch_width = scan_info.eht_op.op_info.control;
		scan_info.w_eht_cap.ccfs0 = scan_info.eht_op.op_info.ccfs0;
		scan_info.w_eht_cap.ccfs1 = scan_info.eht_op.op_info.ccfs1;
	} else if (scan_info.EHT_CAP_IE_EXISTS) {
		//Need to add data from HE
		ch_width = peer_max_bw_cap(GET_DOT11AX_CH_WIDTH(scan_info.he_caps.phy_cap.phy_capinfo_1));
		scan_info.w_eht_cap.eht_ch_width = ch_width;
		scan_info.w_eht_cap.ccfs0 = 0;
		scan_info.w_eht_cap.ccfs1 = 0;
	}
	scan_info.w_eht_cap.tx_stream = scan_info.eht_support_mcs_nss.eht_txrx_mcs_nss[0].max_tx_rx_mcs0_9_nss;
	scan_info.w_eht_cap.rx_stream = scan_info.eht_support_mcs_nss.eht_txrx_mcs_nss[0].max_tx_rx_mcs0_9_nss;

	r->bss.eht_cap.eht_ch_width = scan_info.w_eht_cap.eht_ch_width;
	r->bss.eht_cap.ccfs0 = scan_info.w_eht_cap.ccfs0;
	r->bss.eht_cap.ccfs1 = scan_info.w_eht_cap.ccfs1;

	ch_width = peer_max_bw_cap(GET_DOT11AX_CH_WIDTH(scan_info.he_caps.phy_cap.phy_capinfo_1));
	//in some case EHT op IE have control 20BW. in that case txrx stream data may be zero.
	// so consideing HE cap to get txrx stream data. refer this function of driver eht_get_caps_ie().
	if (ch_width == HE_BW_20)
		scan_info.txrx_stream = scan_info.eht_support_mcs_nss.eht_txrx_mcs_nss_20_only.max_tx_rx_mcs0_7_nss;
	else
		scan_info.txrx_stream = scan_info.eht_support_mcs_nss.eht_txrx_mcs_nss[0].max_tx_rx_mcs0_9_nss;
	/*rx bit 0-3,tx bit 4-7*/
	r->bss.eht_cap.rx_stream = scan_info.txrx_stream & 0x0f;
	r->bss.eht_cap.tx_stream = (scan_info.txrx_stream & 0xf0) >> 4;
#ifdef DEBUG_dummy
	err(DEBUG_CAT_NL80211, "r->bss.Bssid Bssid = "MACSTR "\n", MAC2STR(r->bss.Bssid));
	if (r->bss.ml_info.link_num)
		dump_mlinfo_sta_profile(r->bss.ml_info.sta_profiles);
	dump_eht_cap(r->bss.eht_cap);
	//HE txrx stream calculation done by MAPD.
	dump_he_cap(r->bss.he_cap);
	dump_vht_cap(r->bss.vht_cap);
	// for ht txrx stream no applicable.
	dump_ht_cap(r->bss.ht_cap);
#endif
	return r;
}

static int wapp_scan_info_handler(struct nl_msg *msg, void *arg)
{
	struct nl80211_bss_info_arg *_arg = arg;
	struct wapp_scan_info **res = _arg->res;
	struct wapp_scan_info **tmp;
	struct wapp_scan_info *r;

	r = wapp_parse_scan_info(_arg->drv, msg, _arg->wapp, _arg->ifindex);
	if (!r) {
		err(DEBUG_CAT_NL80211, "SKIP\n");
		return NL_SKIP;
	}
	if (!res) {
		os_free(r);
		return NL_SKIP;
	}

	tmp = os_realloc_array(res, _arg->num + 1,
			       sizeof(struct wapp_scan_info *));
	if (tmp == NULL) {
		os_free(r);
		return NL_SKIP;
	}

	tmp[_arg->num++] = r;
	r->bss_count = 1;
	res = tmp;
	_arg->res = tmp;
	_arg->idx++;

	return NL_SKIP;
}

static int add_ch_active_time_in_util_list(struct wapp_dev *wdev, u8 channel, u64 active_time)
{
	int ret = 0;

	if (wdev->active_time.ch_count >= (MAX_NUM_OF_CHANNELS)) {
		err(DEBUG_CAT_NL80211, "nl80211: num of_channel greater than max channel");
		return -1;
	}

	wdev->active_time.ch_num[wdev->active_time.ch_count] = channel;
	wdev->active_time.ch_active_time[wdev->active_time.ch_count] = active_time;
	wdev->active_time.ch_count += 1;

	return ret;
}

static int get_util_list_index_if_ch_present_in_list(struct wapp_dev *wdev, u8 channel, u8 num_of_ch)
{
	int i = 0;
	int ret = -1;

	if (wdev->active_time.ch_count == 0) {
		err(DEBUG_CAT_NL80211, "nl80211: channel count is zero");
		return ret;
	}

	if (num_of_ch > (MAX_NUM_OF_CHANNELS)) {
		num_of_ch = MAX_NUM_OF_CHANNELS;
		err(DEBUG_CAT_NL80211, "nl80211: num of_channel greater than max channel");
	}

	if (wdev->active_time.ch_count > (MAX_NUM_OF_CHANNELS)) {
		wdev->active_time.ch_count = MAX_NUM_OF_CHANNELS;
		err(DEBUG_CAT_NL80211, "nl80211: wdev num of_channel greater than max channel");
	}

	for (i = 0; i < wdev->active_time.ch_count; i++) {
		if (wdev->active_time.ch_num[i] == channel) {
			ret = i;
			break;
		}
	}

	return ret;
}

static int wapp_survey_info_handler(struct nl_msg *msg, void *arg)
{
	struct nl80211_bss_info_arg *_arg = arg;
	struct nlattr *tb[NL80211_ATTR_MAX + 1];
	struct genlmsghdr *gnlh = nlmsg_data(nlmsg_hdr(msg));
	struct nlattr *sinfo[NL80211_SURVEY_INFO_MAX + 1];
	struct off_ch_scan_req_s *scan_req = NULL;
	struct wapp_dev *wdev = NULL;
	static struct nla_policy survey_policy[NL80211_SURVEY_INFO_MAX + 1] = {
		[NL80211_SURVEY_INFO_FREQUENCY] = { .type = NLA_U32 },
		[NL80211_SURVEY_INFO_NOISE] = { .type = NLA_U8 },
	};
	struct off_ch_scan_state_ctrl *scan_state = NULL;
	u8 op_class;
	OFFCHANNEL_SCAN_MSG ch_scan_result;
	OFFCHANNEL_SCAN_MSG *scan_msg = NULL;
	int freq, ret = 0;
	u64 active_time_sd_nl = 0, active_time_diff = 0;

	if (!_arg)
		return NL_SKIP;

	scan_state = &_arg->wapp->map->off_ch_scan_state;
	scan_msg = &scan_state->scan_msg;
	scan_req = _arg->wapp->map->off_ch_scan_req;

	nla_parse(tb, NL80211_ATTR_MAX, genlmsg_attrdata(gnlh, 0),
		  genlmsg_attrlen(gnlh, 0), NULL);

	if (!tb[NL80211_ATTR_SURVEY_INFO]) {
		err(DEBUG_CAT_NL80211, "nl80211: Survey data missing");
		return NL_SKIP;
	}

	if (nla_parse_nested(sinfo, NL80211_SURVEY_INFO_MAX,
			     tb[NL80211_ATTR_SURVEY_INFO], survey_policy)) {
		err(DEBUG_CAT_NL80211, "nl80211: Failed to parse nested");
		return NL_SKIP;
	}

	if (!sinfo[NL80211_SURVEY_INFO_NOISE])
		return NL_SKIP;

	if (!sinfo[NL80211_SURVEY_INFO_FREQUENCY])
		return NL_SKIP;

	freq = nla_get_u32(sinfo[NL80211_SURVEY_INFO_FREQUENCY]);
	wdev = wapp_dev_list_lookup_by_ifindex(_arg->wapp, _arg->ifindex);
	if (!wdev) {
		err(DEBUG_CAT_NL80211, "wdev not found\n");
		return NL_SKIP;
	}


	ieee80211_freq_to_chan(freq, &ch_scan_result.data.channel_data.channel);
	ch_scan_result.data.channel_data.NF = (s8) nla_get_u8(sinfo[NL80211_SURVEY_INFO_NOISE]);
	ch_scan_result.data.channel_data.tx_time = nla_get_u32(sinfo[NL80211_SURVEY_INFO_TIME_TX]);
	ch_scan_result.data.channel_data.rx_time = nla_get_u32(sinfo[NL80211_SURVEY_INFO_TIME_RX]);
	if_indextoname(_arg->ifindex, (char *)ch_scan_result.ifrn_name);
	ch_scan_result.ifIndex = _arg->ifindex;
	/*NL80211_SURVEY_INFO_TIME_BUSY and NL80211_SURVEY_INFO_TIME unit: millisecond*/
	/*spec defines channel_busy_time unit: microsecond*/
	ch_scan_result.data.channel_data.channel_busy_time = nla_get_u64(sinfo[NL80211_SURVEY_INFO_TIME_BUSY]) * 1000;
	ch_scan_result.Action = OFFCHANNEL_INFO_RSP;
	ch_scan_result.data.channel_data.edcca = 0;
	ch_scan_result.data.channel_data.obss_time = 0;
	active_time_sd_nl = nla_get_u64(sinfo[NL80211_SURVEY_INFO_TIME]);
	if (active_time_sd_nl == 0  || (active_time_sd_nl > ch_scan_result.data.channel_data.channel_busy_time)) {
		ch_scan_result.data.channel_data.actual_measured_time = 0;
		goto ch_util;
	}

	ret = get_util_list_index_if_ch_present_in_list(wdev, ch_scan_result.data.channel_data.channel,
						scan_msg->data.offchannel_param.Num_of_Away_Channel);
	if (ret > 0) {
		active_time_diff = active_time_sd_nl - wdev->active_time.ch_active_time[ret];
		if (active_time_diff == 0 || (active_time_sd_nl < wdev->active_time.ch_active_time[ret]))
			ch_scan_result.data.channel_data.actual_measured_time = active_time_sd_nl;
		else
			ch_scan_result.data.channel_data.actual_measured_time = active_time_diff;

		wdev->active_time.ch_active_time[ret] = ch_scan_result.data.channel_data.actual_measured_time;
	} else if (active_time_sd_nl != 0) {
		add_ch_active_time_in_util_list(wdev, ch_scan_result.data.channel_data.channel,
				active_time_sd_nl);
		ch_scan_result.data.channel_data.actual_measured_time = active_time_sd_nl;
	}

ch_util:
	debug(DEBUG_CAT_SCAN, "get scan ifIndex %d ch %d actual_measured_time %lu, channel_busy_time %lu\n", ch_scan_result.ifIndex,
		ch_scan_result.data.channel_data.channel, ch_scan_result.data.channel_data.actual_measured_time,
		ch_scan_result.data.channel_data.channel_busy_time);
	while (_arg->count < scan_msg->data.offchannel_param.Num_of_Away_Channel) {

		op_class = scan_req->body[scan_state->curr_scan_radio_idx].ch_body[scan_state->curr_oper_class_idx].oper_class;

		if (_arg->count >= 0 && _arg->count < MAX_AWAY_CHANNEL
			&& map_get_freq_from_channel_op_class(op_class, scan_msg->data.offchannel_param.channel[_arg->count]) == freq) {
			_arg->wapp->event_ops->event_offch_info(_arg->wapp, (UCHAR *)&ch_scan_result);
			_arg->count++;
		} else
			return NL_SKIP;
	}
	_arg->count++;
	return NL_SKIP;
}

static int wapp_process_scan_result(struct driver_nl80211_data *drv_data, struct nl_msg *nlmsg)
{

	struct genlmsghdr *gnlh = nlmsg_data(nlmsg_hdr(nlmsg));
	struct nlattr *tb[NL80211_ATTR_MAX + 1];
	struct wifi_app *wapp;

	u64 wdev_id;
	struct wapp_dev *wdev = NULL;
	struct nl_msg *msg = NULL;
	int ret = 0;
	struct wapp_scan_info **res;
	struct driver_nl80211_data *drv = NULL;
	struct nl80211_bss_info_arg arg;

	if (!drv_data) {
		err(DEBUG_CAT_NL80211, "invalid input params\n");
		return -1;
	}

	wapp = (struct wifi_app *)drv_data->priv;

	if (!wapp) {
		err(DEBUG_CAT_NL80211, "invalid input params\n");
		return -1;
	}

	ret = nla_parse(tb, NL80211_ATTR_MAX, genlmsg_attrdata(gnlh, 0), genlmsg_attrlen(gnlh, 0), NULL);
	if (ret) {
		err(DEBUG_CAT_NL80211, "nla_parse fail!\n");
		return -1;
	}

	arg.ifindex = nla_get_u32(tb[NL80211_ATTR_IFINDEX]);
	wdev_id = nla_get_u64(tb[NL80211_ATTR_WDEV]);
	wdev = wapp_dev_list_lookup_by_ifindex(wapp, arg.ifindex);
	if (!wdev) {
		err(DEBUG_CAT_NL80211, "wdev not found\n");
		return -1;
	}

	res = os_zalloc(sizeof(*res));
	if (res == NULL) {
		if (wdev->dev_type == WAPP_DEV_TYPE_AP)
			wapp->nl_rest_ap = 0;
		else
			wapp->nl_rest_apcli = 0;
		return -1;
	}

	arg.drv = drv;
	arg.res = res;
	arg.idx = 0;
	arg.num = 0;
	arg.count = 0;
	arg.wapp = wapp;

	drv = (struct driver_nl80211_data *)drv_data;

	if ((wapp->nl_rest_ap == 1 && wdev->dev_type == WAPP_DEV_TYPE_AP) ||
		(wapp->nl_rest_apcli == 1 && (wdev->dev_type == WAPP_DEV_TYPE_APCLI || wdev->dev_type == WAPP_DEV_TYPE_STA))) {
		if (wapp->nl_rest_ap == 1)
			notice(DEBUG_CAT_NL80211, "For Ap Scan\n");
		else
			notice(DEBUG_CAT_NL80211, "For Apcli Scan\n");
	} else {
		notice(DEBUG_CAT_NL80211, "Not our scan\n");
		if (wdev->dev_type == WAPP_DEV_TYPE_AP)
			wapp->nl_rest_ap = 0;
		else
			wapp->nl_rest_apcli = 0;
		os_free(res);
		return -1;
	}
	// For handling partial scan count, skip get scan if its partial scan and complete channel scan list no scanned
	if ((wapp->nl_rest_apcli == 1 && wapp->partial_scan_count > 0)
	 && (wapp->temp_scan_count < wapp->scan_count)) {
		err(DEBUG_CAT_NL80211, "Scanning ongoing, not completed on all channels!!!\n");
		goto out;
	}
	msg = unl_genl_msg(&drv->nl_handle, NL80211_CMD_GET_SCAN, TRUE);
	if (!msg) {
		err(DEBUG_CAT_NL80211, "unl_genl_msg fail!!!\n");
		if (wdev->dev_type == WAPP_DEV_TYPE_AP)
			wapp->nl_rest_ap = 0;
		else
			wapp->nl_rest_apcli = 0;
		os_free(res);
		return -1;
	}

	nla_put_u64(msg, NL80211_ATTR_WDEV, wdev_id);
	if (nla_put_u32(msg, NL80211_ATTR_IFINDEX, arg.ifindex)) {
		err(RT_DEBUG_TRACE, "nla_put_u32 ifindex fail !!\n");
		if (wdev->dev_type == WAPP_DEV_TYPE_AP)
			wapp->nl_rest_ap = 0;
		else
			wapp->nl_rest_apcli = 0;
		os_free(res);
		nlmsg_free(msg);
		return -1;
	}

	ret = unl_genl_request(&drv->nl_handle, msg, wapp_scan_info_handler, &arg);
	if (ret) {
		err(DEBUG_CAT_NL80211, "wapp_scan_info_handler fail!!! %d\n", ret);
		if (wdev->dev_type == WAPP_DEV_TYPE_AP)
			wapp->nl_rest_ap = 0;
		else
			wapp->nl_rest_apcli = 0;
		os_free(res);
		nlmsg_free(msg);
		return -1;
	}
	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		msg = unl_genl_msg(&drv->nl_handle, NL80211_CMD_GET_SURVEY, TRUE);
		if (!msg) {
			err(DEBUG_CAT_NL80211, "unl_genl_msg fail!!!\n");
			if (wdev->dev_type == WAPP_DEV_TYPE_AP)
				wapp->nl_rest_ap = 0;
			else
				wapp->nl_rest_apcli = 0;
			os_free(res);
			return -1;
		}
		if (nla_put_u32(msg, NL80211_ATTR_IFINDEX, arg.ifindex)) {
			err(DEBUG_CAT_NL80211, "nla_put_u32 ifindex fail !!\n");
			if (wdev->dev_type == WAPP_DEV_TYPE_AP)
				wapp->nl_rest_ap = 0;
			else
				wapp->nl_rest_apcli = 0;
			os_free(res);
			nlmsg_free(msg);
			return -1;
		}
		nla_put_u64(msg, NL80211_ATTR_WDEV, wdev_id);
		ret = unl_genl_request(&drv->nl_handle, msg, wapp_survey_info_handler, &arg);
	}

	if (wdev->dev_type == WAPP_DEV_TYPE_AP)
		wapp->nl_rest_ap = 0;
	else
		wapp->nl_rest_apcli = 0;
out:
	wapp->nl_event_ops->nl_event_handle(wapp, arg, arg.ifindex);

	return 0;
}
#endif

#ifdef MAP_R6
static void process_vendor_attr_event_mlo_reconf_status(struct wifi_app *wapp, struct nlattr *attr_vendor_data_tb)
{
	struct nlattr *tb_vendor[MTK_NL80211_VENDOR_ATTR_EVENT_MLO_RECONF_MAX + 1];
	char *data = NULL;
	int ret;

	ret = nla_parse_nested(tb_vendor, MTK_NL80211_VENDOR_ATTR_EVENT_MLO_RECONF_MAX, attr_vendor_data_tb, NULL);
	if (ret) {
		err(DEBUG_CAT_NL80211, "nla_parse_nested fail\n");
		return;
	}

	if (tb_vendor[MTK_NL80211_VENDOR_ATTR_EVENT_MLO_RECONF_SM]) {
		data = nla_data(tb_vendor[MTK_NL80211_VENDOR_ATTR_EVENT_MLO_RECONF_SM]);
		wapp->event_ops->event_mlo_reconfig_status(wapp, data);
	}
}
#endif /* MAP_R6 */

static int process_cmd_frame(struct wifi_app *wapp, struct nl_msg *msg)
{
	struct genlmsghdr *gnlh = nlmsg_data(nlmsg_hdr(msg));
	struct nlattr *tb[NL80211_ATTR_MAX + 1];
	unsigned char *data = NULL;
	unsigned int len = 0;
	unsigned int phy_id = 0, ifindex = 0;
	int ret = 0;

	ret = nla_parse(tb, NL80211_ATTR_MAX, genlmsg_attrdata(gnlh, 0), genlmsg_attrlen(gnlh, 0), NULL);
	if (ret) {
		err(DEBUG_CAT_NL80211, "nla_parse fail!\n");
		return -1;
	}

	if (!tb[NL80211_ATTR_FRAME] ||
		!tb[NL80211_ATTR_IFINDEX] ||
		!tb[NL80211_ATTR_WIPHY]) {
		err(DEBUG_CAT_NL80211, "no valid attribute for cmd frame\n");
		return -1;
	}

	data = nla_data(tb[NL80211_ATTR_FRAME]);
	len = nla_len(tb[NL80211_ATTR_FRAME]);
	phy_id = nla_get_u32(tb[NL80211_ATTR_WIPHY]);
	ifindex = nla_get_u32(tb[NL80211_ATTR_IFINDEX]);

	debug_hexdump(DEBUG_CAT_NL80211, "cmd_frame", data, len);

	return 0;
}


static int process_vendor_cmd(struct wifi_app *wapp, struct nl_msg *msg)
{
	struct genlmsghdr *gnlh = nlmsg_data(nlmsg_hdr(msg));
	struct nlattr *tb[NL80211_ATTR_MAX + 1];
	unsigned int vendor_id, vendor_event;
	int ret = 0;

	ret = nla_parse(tb, NL80211_ATTR_MAX, genlmsg_attrdata(gnlh, 0), genlmsg_attrlen(gnlh, 0), NULL);
	if (ret) {
		err(DEBUG_CAT_NL80211, "nla_parse fail\n");
		return NL_SKIP;
	}

	vendor_id = nla_get_u32(tb[NL80211_ATTR_VENDOR_ID]);
	if (vendor_id != MTK_OUI) {
		notice(DEBUG_CAT_NL80211, "not mtk vendor id; id = 0x%06x; ignore\n", vendor_id);
		return NL_SKIP;
	}

	/* handle mediatek vendor event */
	vendor_event = nla_get_u32(tb[NL80211_ATTR_VENDOR_SUBCMD]);

	switch (vendor_event) {
	case MTK_NL80211_VENDOR_EVENT_TEST:
		process_vendor_attr_event_test(wapp, tb[NL80211_ATTR_VENDOR_DATA]);
		break;
	case MTK_NL80211_VENDOR_EVENT_RSP_WAPP_EVENT:
		process_vendor_attr_event_rsp(wapp, tb[NL80211_ATTR_VENDOR_DATA]);
		break;
	case MTK_NL80211_VENDOR_EVENT_OFFCHANNEL_INFO:
		process_vendor_attr_event_offchannel_info(wapp, tb[NL80211_ATTR_VENDOR_DATA]);
		break;
	case MTK_NL80211_VENDOR_EVENT_MLO_EVENT:
		process_vendor_attr_event_cosr(wapp, tb[NL80211_ATTR_VENDOR_DATA]);
		break;
#ifdef DFS_SLAVE_SUPPORT
	case MTK_NL80211_VENDOR_EVENT_BH_STATUS:
		process_vendor_attr_event_bhstatus(wapp, tb[NL80211_ATTR_VENDOR_DATA]);
		break;
#endif /* DFS_SLAVE_SUPPORT */
#ifdef MAP_R6
	case MTK_NL80211_VENDOR_EVENT_MLO_RECONF:
		process_vendor_attr_event_mlo_reconf_status(wapp, tb[NL80211_ATTR_VENDOR_DATA]);
#endif /* MAP_R6 */
	default:
		break;
	}

	return 0;
}

/**
 * cfg80211_connect_result - process notify cfg80211 of connection result
 *
 * @wapp: wifi app struct.
 * @msg: cfg80211 cfg80211_connect_result send the msg from the wifi driver.
 *
 *
 * It will process the netlink msg by one of the cfg80211_connect_bss(),
 * cfg80211_connect_result(), cfg80211_connect_timeout(), and
 * cfg80211_connect_done() netlink msg. the msg contain the connection success
 * or failure status code.
 */
#ifdef STANDARD_NL_CMD
static int process_apcli_connect_result(struct wifi_app *wapp, struct nl_msg *msg)
{
	u16 status_code = 0, peer_map_en = wapp->cli_assoc_info.peer_map_enable;
	const u8 *req_ies = NULL, *resp_ies = NULL, *rsp_map_ies = NULL, *map_subelem = NULL;
	size_t req_ies_len = 0, resp_ies_len = 0;
	int ret = 0;
	struct ieee802_11_elems elems = {0}, elems_rsp = {0};
	struct genlmsghdr *gnlh = nlmsg_data(nlmsg_hdr(msg));
	struct nlattr *tb[NL80211_ATTR_MAX + 1];
	struct nl_apcli_assoc_info event = {0};

	if (!gnlh) {
		err(DEBUG_CAT_NL80211, "gnlh msg header is null.\n");
		return NL_SKIP;
	}

	ret = nla_parse(tb, NL80211_ATTR_MAX, genlmsg_attrdata(gnlh, 0), genlmsg_attrlen(gnlh, 0), NULL);
	if (ret) {
		err(DEBUG_CAT_NL80211, "nla_parse fail!\n");
		return -1;
	}

	if (!tb[NL80211_ATTR_IFINDEX]) {
		err(DEBUG_CAT_NL80211, "gnlh NL80211_ATTR_IFINDEX is not exist.\n");
		return NL_SKIP;
	}

	status_code =  nla_get_u16(tb[NL80211_ATTR_STATUS_CODE]);
	if (status_code != WLAN_STATUS_SUCCESS) {
		/*covert netlink msg to the event structure*/
		err(DEBUG_CAT_NL80211, "connect failure.\n");
		event.apcli_assoc_state = NL_WAPP_APCLI_DISASSOCIATED;
	} else {
		/*parse assoc rsp, get the peer map enable*/
		req_ies = nla_data(tb[NL80211_ATTR_REQ_IE]);
		if (req_ies) {
			req_ies_len = nla_len(tb[NL80211_ATTR_REQ_IE]);
			wpa_hexdump(MSG_ERROR, "own req_ies:", req_ies, req_ies_len);
		}
		resp_ies = nla_data(tb[NL80211_ATTR_RESP_IE]);
		if (resp_ies) {
			resp_ies_len = nla_len(tb[NL80211_ATTR_RESP_IE]);
			wpa_hexdump(MSG_ERROR, "peer resp_ies ies:", resp_ies, resp_ies_len);
		}
		if (req_ies && resp_ies && req_ies_len > 0 && resp_ies_len > 0) {
			/*parse own map ies in assoc req*/
			if (ieee802_11_parse_elems(req_ies, req_ies_len, &elems, 1) == ParseFailed) {
				err(DEBUG_CAT_NL80211, "parse elems fails.\n");
				return WLAN_STATUS_UNSPECIFIED_FAILURE;
			}

			if (elems.multi_ap && elems.multi_ap_len > 0) {
				wpa_hexdump(MSG_DEBUG, "own multiap ies:", elems.multi_ap, elems.multi_ap_len);
				/*parse peer map ies in assoc rsp*/
				if (ieee802_11_parse_elems(resp_ies, resp_ies_len, &elems_rsp, 1) == ParseFailed) {
					err(DEBUG_CAT_NL80211, "parse elems fails.\n");
					return WLAN_STATUS_UNSPECIFIED_FAILURE;
				}
				peer_map_en = 0;/*own/peer have ies default set as 0*/
				if (elems_rsp.multi_ap && elems_rsp.multi_ap_len > 4) {
					err(DEBUG_CAT_NL80211, "find the elems ies.\n");
					rsp_map_ies = elems_rsp.multi_ap;
					wpa_hexdump(MSG_ERROR, "peer multiap ies:", elems_rsp.multi_ap, elems_rsp.multi_ap_len);
					/*parse peer assoc ies*/
					map_subelem = get_ie(rsp_map_ies + 4, elems_rsp.multi_ap_len - 4, MULTI_AP_SUB_ELEM_TYPE);
					if (map_subelem && map_subelem[1] == 1 &&
						/*peer map value supported FH or BH*/
						(map_subelem[2] & ((MULTI_AP_FRONTHAUL_BSS | MULTI_AP_BACKHAUL_BSS)))) {
						peer_map_en = 1;
						debug(DEBUG_CAT_NL80211, "peer_map_en is %d. multi_ap_value(0x%x)\n",
							peer_map_en, map_subelem[2]);
					}
				}
			} else
				peer_map_en = 0;
		}

		/*covert netlink msg to the event structure*/
		event.apcli_assoc_state = NL_WAPP_APCLI_ASSOCIATED;
		debug(DEBUG_CAT_NL80211, "connect success.\n");
	}
	/*covert netlink msg to the event structure*/
	event.interface_index =  nla_get_u32(tb[NL80211_ATTR_IFINDEX]);
	event.PeerMAPEnable = peer_map_en;
	debug(DEBUG_CAT_NL80211,
		"assoc info :if_idx(%d), peer_map_en(%d), apcli_assoc_state(%d).\n",
		event.interface_index, event.PeerMAPEnable, event.apcli_assoc_state);
	/*call handler*/
	wdev_apcli_assoc_stat_change_nl_handle(wapp, &event);
	return 0;
}

/**
 * process_apcli_connect_result - process notify cfg80211 that connection was dropped
 *
 * @wapp: wifi app struct.
 * @msg: cfg80211 cfg80211_disconnected send the msg from the wifi driver.
 *
 * After it calls this function, the apcli is disconnect the app should update the
 * state by call the event hanlder to update apcli state.
 */

static int process_apcli_disconnect(struct wifi_app *wapp, struct nl_msg *msg)
{
	struct genlmsghdr *gnlh = nlmsg_data(nlmsg_hdr(msg));
	struct nlattr *tb[NL80211_ATTR_MAX + 1];
	struct nl_apcli_assoc_info event = {0};

	if (!gnlh) {
		err(DEBUG_CAT_NL80211, "gnlh msg header is null.\n");
		return NL_SKIP;
	}

	nla_parse(tb, NL80211_ATTR_MAX, genlmsg_attrdata(gnlh, 0),
		  genlmsg_attrlen(gnlh, 0), NULL);

	if (!tb[NL80211_ATTR_IFINDEX]) {
		err(DEBUG_CAT_NL80211, "gnlh NL80211_ATTR_IFINDEX is not exist.\n");
		return NL_SKIP;
	}
	/*covert netlink msg to the event structure*/
	event.interface_index =  nla_get_u32(tb[NL80211_ATTR_IFINDEX]);
	/*use the last apcli conn state to update*/
	event.PeerMAPEnable = wapp->cli_assoc_info.peer_map_enable;
	event.apcli_assoc_state = NL_WAPP_APCLI_DISASSOCIATED;

	debug(DEBUG_CAT_NL80211, "assoc info :if_idx(%d), peer_map_en(%d), apcli_assoc_state(%d).\n",
		event.interface_index, event.PeerMAPEnable, event.apcli_assoc_state);
	/*call handler*/
	wdev_apcli_assoc_stat_change_nl_handle(wapp, &event);
	return NL_SKIP;
}

void wapp_get_new_dev_info(void *eloop_ctx, void *user_ctx)
{
	struct wifi_app *wapp = (struct wifi_app *)eloop_ctx;
	struct dev_info *dev = (struct dev_info *)user_ctx;
	int ret = 0;
	struct dev_info *tmp_dev = NULL, *tmp_t = NULL;
	int dev_found = 0;

	ret = wapp_get_dev(wapp, dev);
	if (ret < 0) {
		err(DEBUG_CAT_EVENT, DYN_INTF_PREX"can't get dev info by ifindex-%d for %s\n", dev->ifindex, dev->ifname);
		os_free(dev);
		return;
	}

	if (dev->freq == 0 && dev->get_phy_retry <= 5) {
		err(DEBUG_CAT_EVENT, DYN_INTF_PREX"freq is stil 0, try to get again, retry: %d\n", dev->get_phy_retry);
		dev->get_phy_retry++;
		eloop_cancel_timeout(wapp_get_new_dev_info, (void *)wapp, (void *)dev);
		eloop_register_timeout(1, 0, wapp_get_new_dev_info, (void *)wapp, (void *)dev);
		return;
	}

	dev->get_phy_retry = 0;
	dl_list_for_each_safe(tmp_dev, tmp_t, &wapp->hdev_head, struct dev_info, list) {
		if (!os_memcmp(dev->ifname, tmp_dev->ifname, os_strlen(dev->ifname))
			&& os_strlen(dev->ifname) == os_strlen(tmp_dev->ifname)) {
			notice(DEBUG_CAT_EVENT, DYN_INTF_PREX"interface %s already in list\n", tmp_dev->ifname);
			dev_found = 1;
			tmp_dev->valid = 1;
			break;
		}
	}

	if (!dev_found) {
		dev->valid = 1;
		dl_list_add_tail(&wapp->hdev_head, &dev->list);
	}

	if (wapp->event_ops && wapp->event_ops->event_new_intf_notify && dev->freq != 0)
		wapp->event_ops->event_new_intf_notify(wapp, dev);
}

void wapp_delete_dev(void *eloop_ctx, void *user_ctx)
{
	struct wifi_app *wapp = (struct wifi_app *)eloop_ctx;
	struct dev_info *dev = (struct dev_info *)user_ctx;

	if (!wapp || !dev) {
		err(DEBUG_CAT_EVENT, DYN_INTF_PREX"invalid input params\n");
		return;
	}

	if (wapp->event_ops && wapp->event_ops->event_delete_intf_notify)
		wapp->event_ops->event_delete_intf_notify(wapp, dev);
}

static void process_intf_event(struct wifi_app *wapp,
	struct nl_msg *msg, char action)
{
#if defined(EM_PLUS_SUPPORT) || defined(EM_PLUS_EXT_SUPPORT)
	struct dev_info *dev = NULL, *tmp_dev = NULL;
#endif /*EM_PLUS_SUPPORT*/
	struct genlmsghdr *gnlh = NULL;
	struct nlattr *tb[NL80211_ATTR_MAX + 1];
	int ret = 0;
	char if_name[IFNAMSIZ] = {0};
	u32 ifindex = 0;

	if (!wapp || !msg) {
		err(DEBUG_CAT_EVENT, DYN_INTF_PREX"invalid input params\n");
		return;
	}
	if (!wapp->event_ops || !wapp->event_ops->event_delete_intf_notify
		|| !wapp->event_ops->event_new_intf_notify || !wapp->event_ops->event_intf) {
		err(DEBUG_CAT_EVENT, DYN_INTF_PREX"no event_intf handler\n");
		return;
	}

	gnlh = nlmsg_data(nlmsg_hdr(msg));
	ret = nla_parse(tb, NL80211_ATTR_MAX, genlmsg_attrdata(gnlh, 0), genlmsg_attrlen(gnlh, 0), NULL);
	if (ret) {
		err(DEBUG_CAT_EVENT, DYN_INTF_PREX"nla_parse fail!\n");
		return;
	}

	if (tb[NL80211_ATTR_IFNAME])
		os_memcpy(if_name, nla_data(tb[NL80211_ATTR_IFNAME]), nla_len(tb[NL80211_ATTR_IFNAME]));
	if (tb[NL80211_ATTR_IFINDEX])
		ifindex = nla_get_u32(tb[NL80211_ATTR_IFINDEX]);

	notice(DEBUG_CAT_EVENT, DYN_INTF_PREX"event %s intf %s\n", action ? "NEW" : "DEL", if_name);

#if defined(EM_PLUS_SUPPORT) || defined(EM_PLUS_EXT_SUPPORT)
	dl_list_for_each(tmp_dev, &wapp->hdev_head, struct dev_info, list) {
		if (!os_strncmp(tmp_dev->ifname, if_name, os_strlen(if_name))) {
			dev = tmp_dev;
			break;
		}
	}

	if (action) {
		if (dev) {
			/* dev exist in hdev_head, means cur dev info has updated, only change the bss state as WAPP_BSS_START*/
			dev->ifindex = ifindex;
			dev->valid = 1;
			eloop_cancel_timeout(wapp_delete_dev, (void *)wapp, (void *)dev);
		} else {
			/* not exist in hdev_head, means new dev, should update dev info*/
			dev = os_zalloc(sizeof(struct dev_info));
			if (dev == NULL) {
				err(DEBUG_CAT_EVENT, DYN_INTF_PREX"fail to alloc dev\n");
				return;
			}
			dev->ifindex = ifindex;
			os_memcpy(dev->ifname, if_name, os_strlen(if_name));
			/*get new dev info, set 1s to wait kernel update dev info ready*/
			eloop_cancel_timeout(wapp_get_new_dev_info, (void *)wapp, (void *)dev);
			eloop_register_timeout(1, 0, wapp_get_new_dev_info, (void *)wapp, (void *)dev);
		}
	} else {
		if (!dev) {
			err(DEBUG_CAT_EVENT, DYN_INTF_PREX"can't find %s in wapp dev list, no need to delete\n", if_name);
			return;
		} else if (dev) {
			if (eloop_is_timeout_registered(wapp_get_new_dev_info, wapp, (void *)dev))
				eloop_cancel_timeout(wapp_get_new_dev_info, (void *)wapp, (void *)dev);

			notice(DEBUG_CAT_EVENT, DYN_INTF_PREX"%s is disable by mesh setting:%d\n", dev->ifname, dev->mesh_disable);

			if (!dev->mesh_disable) {
				if (!eloop_is_timeout_registered(wapp_delete_dev, wapp, (void *)dev))
					eloop_register_timeout(1, 0, wapp_delete_dev, (void *)wapp, (void *)dev);
			} else {
				dev->valid = 0;
				/* dev is still in driver info, only change the bss state as WAPP_BSS_STOP*/
				wapp->event_ops->event_intf(wapp, dev, action);
			}
		}
	}
#endif /*EM_PLUS_SUPPORT*/
}
#endif/*STANDARD_NL_CMD*/

static int genl_event_handler(struct nl_msg *msg, void *arg)
{
	struct genlmsghdr *gnlh = nlmsg_data(nlmsg_hdr(msg));
	struct driver_nl80211_data *drv_data = (struct driver_nl80211_data *)arg;
	struct wifi_app *wapp = (struct wifi_app *)drv_data->priv;
	int ret = NL_OK;

	if (gnlh->cmd != NL80211_CMD_VENDOR &&
		gnlh->cmd != NL80211_CMD_FRAME &&
		gnlh->cmd != NL80211_CMD_CONNECT &&
#ifdef STANDARD_NL_CMD
		gnlh->cmd != NL80211_CMD_NEW_INTERFACE &&
		gnlh->cmd != NL80211_CMD_DEL_INTERFACE &&
		gnlh->cmd != NL80211_CMD_NEW_SCAN_RESULTS &&
		gnlh->cmd != NL80211_CMD_TRIGGER_SCAN &&
		gnlh->cmd != NL80211_CMD_SCAN_ABORTED &&
#endif
		gnlh->cmd != NL80211_CMD_DISCONNECT)
		ret = NL_SKIP;

	switch (gnlh->cmd) {
	case NL80211_CMD_FRAME:
		ret = process_cmd_frame(wapp, msg);
		if (ret < 0)
			ret = NL_SKIP;
		break;
	case NL80211_CMD_VENDOR:
		ret = process_vendor_cmd(wapp, msg);
		if (ret < 0)
			ret = NL_SKIP;
		break;
#ifdef STANDARD_NL_CMD
	case NL80211_CMD_NEW_INTERFACE:
	case NL80211_CMD_DEL_INTERFACE:
		if (gnlh->cmd == NL80211_CMD_NEW_INTERFACE)
			process_intf_event(wapp, msg, 1);
		else
			process_intf_event(wapp, msg, 0);
		break;
	case NL80211_CMD_CONNECT:
		ret = process_apcli_connect_result(wapp, msg);
		if (ret < 0)
			ret = NL_SKIP;
		break;
	case NL80211_CMD_DISCONNECT:
		ret = process_apcli_disconnect(wapp, msg);
		if (ret < 0)
			ret = NL_SKIP;
		break;
	case NL80211_CMD_SCAN_ABORTED:
	case NL80211_CMD_NEW_SCAN_RESULTS:
		ret = wapp_process_scan_result(drv_data, msg);
		if (ret < 0)
			ret = NL_SKIP;
		break;
	case NL80211_CMD_TRIGGER_SCAN:
		ret = NL_SKIP;
		break;
#endif/*STANDARD_NL_CMD*/
	default:
		debug(DEBUG_CAT_NL80211, "Ignored not intrested event(0x%02x)\n", gnlh->cmd);
		break;
	}

	unl_loop_done(&drv_data->nl_event);
	return ret;
}

static void nl80211_event_receive(int sock, void *eloop_ctx, void *handle)
{
	struct driver_nl80211_data *drv_data = (struct driver_nl80211_data *)eloop_ctx;

	unl_loop(&drv_data->nl_event, genl_event_handler, drv_data);
}

static void *driver_nl80211_init(struct wifi_app *wapp, const int opmode, const int drv_mode)
{
	struct driver_nl80211_data *drv_nl80211_data;
	int ret;

	drv_nl80211_data = calloc(1, sizeof(*drv_nl80211_data));
	if (!drv_nl80211_data) {
		err(DEBUG_CAT_NL80211, "alloc drv_nl80211_data fail\n");
		goto err1;
	}

	if (unl_genl_init(&drv_nl80211_data->nl_handle, "nl80211") < 0) {
		err(DEBUG_CAT_NL80211, "failed to connect to nl80211 handle\n");
		goto err2;
	}

	if (unl_genl_init(&drv_nl80211_data->nl_event, "nl80211") < 0) {
		err(DEBUG_CAT_NL80211, "failed to connect to nl80211 event\n");
		goto err2;
	}

	/* TODO: subscribe config/scan/regulatory/mlme event */

	ret = unl_genl_subscribe(&drv_nl80211_data->nl_event, "vendor");
	if (ret)
		err(DEBUG_CAT_NL80211, "ret = %d, unl_genl_subscribe vendor fail\n", ret);
#ifdef STANDARD_NL_CMD
	ret = unl_genl_subscribe(&drv_nl80211_data->nl_event, "config");
	if (ret)
		err(DEBUG_CAT_NL80211, "ret = %d, unl_genl_subscribe configs fail\n", ret);

	ret = unl_genl_subscribe(&drv_nl80211_data->nl_event, "scan");
	if (ret)
		err(DEBUG_CAT_NL80211, "ret = %d, unl_genl_subscribe scan fail\n", ret);

	ret = unl_genl_subscribe(&drv_nl80211_data->nl_event, "mlme");
	if (ret)
		err(DEBUG_CAT_NL80211, "ret = %d, unl_genl_subscribe mlme fail\n", ret);
#endif
	eloop_register_read_sock(nl_socket_get_fd(drv_nl80211_data->nl_event.sock), nl80211_event_receive, drv_nl80211_data, NULL);

	drv_nl80211_data->opmode = opmode;
	drv_nl80211_data->drv_mode = drv_mode;
	drv_nl80211_data->priv = (void *)wapp;

#ifdef WPACTRL_SUPPORT
	switch (RTDebugLevel) {
	case RT_DEBUG_ERROR:
		wpactrl_debug_level_set(WPACTRL_DBGLVL_ERROR);
		break;
	case RT_DEBUG_WARN:
		wpactrl_debug_level_set(WPACTRL_DBGLVL_WARN);
		break;
	case RT_DEBUG_TRACE:
		wpactrl_debug_level_set(WPACTRL_DBGLVL_DEBUG);
		break;
	case RT_DEBUG_INFO:
		wpactrl_debug_level_set(WPACTRL_DBGLVL_INFO);
		break;
	default:
		break;
	}
	wpactrl_debug_prefix_set("[wappd][libwpactrl]");
#endif /* WPACTRL_SUPPORT */

	return (void *)drv_nl80211_data;
err2:
	os_free(drv_nl80211_data);
err1:
	return NULL;
}

static int driver_nl80211_exit(struct wifi_app *wapp)
{
	struct driver_nl80211_data *drv_nl80211_data = wapp->drv_data;

	unl_genl_unsubscribe(&drv_nl80211_data->nl_event, "vendor");
	eloop_unregister_read_sock(nl_socket_get_fd(drv_nl80211_data->nl_event.sock));
	unl_free(&drv_nl80211_data->nl_event);
	unl_free(&drv_nl80211_data->nl_handle);
	os_free(drv_nl80211_data);

	return 0;
}

#ifdef STANDARD_NL_CMD
struct phy_info_arg {
	unsigned char *num_phys;
	struct phy_info *phy;
	int last_phy, last_chan_idx;
	int failed;
	unsigned char dfs_domain;
};

static void phy_info_iftype_copy(struct phy_info *phy,
				 struct nlattr **tb, struct nlattr **tb_flags)
{
	struct he_capabilities *he_capab = &phy->he_capab;
	struct eht_capabilities *eht_capab = &phy->eht_capab;
	size_t len = 0;

	he_capab->he_supported = 1;

	if (tb[NL80211_BAND_IFTYPE_ATTR_HE_CAP_PHY]) {
		len = nla_len(tb[NL80211_BAND_IFTYPE_ATTR_HE_CAP_PHY]);

		if (len > sizeof(he_capab->phy_cap))
			len = sizeof(he_capab->phy_cap);
		os_memcpy(he_capab->phy_cap,
			  nla_data(tb[NL80211_BAND_IFTYPE_ATTR_HE_CAP_PHY]),
			  len);
	}

	if (tb[NL80211_BAND_IFTYPE_ATTR_HE_CAP_MAC]) {
		len = nla_len(tb[NL80211_BAND_IFTYPE_ATTR_HE_CAP_MAC]);

		if (len > sizeof(he_capab->mac_cap))
			len = sizeof(he_capab->mac_cap);
		os_memcpy(he_capab->mac_cap,
			  nla_data(tb[NL80211_BAND_IFTYPE_ATTR_HE_CAP_MAC]),
			  len);
	}

	if (tb[NL80211_BAND_IFTYPE_ATTR_HE_CAP_MCS_SET]) {
		len = nla_len(tb[NL80211_BAND_IFTYPE_ATTR_HE_CAP_MCS_SET]);

		if (len > sizeof(he_capab->mcs))
			len = sizeof(he_capab->mcs);
		os_memcpy(he_capab->mcs,
			  nla_data(tb[NL80211_BAND_IFTYPE_ATTR_HE_CAP_MCS_SET]),
			  len);
	}

	if (tb[NL80211_BAND_IFTYPE_ATTR_HE_CAP_PPE]) {
		len = nla_len(tb[NL80211_BAND_IFTYPE_ATTR_HE_CAP_PPE]);

		if (len > sizeof(he_capab->ppet))
			len = sizeof(he_capab->ppet);
		os_memcpy(&he_capab->ppet,
			  nla_data(tb[NL80211_BAND_IFTYPE_ATTR_HE_CAP_PPE]),
			  len);
	}

	if (tb[NL80211_BAND_IFTYPE_ATTR_HE_6GHZ_CAPA]) {
		u16 capa;

		capa = nla_get_u16(tb[NL80211_BAND_IFTYPE_ATTR_HE_6GHZ_CAPA]);
		he_capab->he_6ghz_capa = capa;
	}

	if (!tb[NL80211_BAND_IFTYPE_ATTR_EHT_CAP_MAC] ||
	    !tb[NL80211_BAND_IFTYPE_ATTR_EHT_CAP_PHY])
		return;

	eht_capab->eht_supported = true;

	if (tb[NL80211_BAND_IFTYPE_ATTR_EHT_CAP_MAC] &&
	    nla_len(tb[NL80211_BAND_IFTYPE_ATTR_EHT_CAP_MAC]) >= 2) {
		const u8 *pos;

		pos = nla_data(tb[NL80211_BAND_IFTYPE_ATTR_EHT_CAP_MAC]);
		eht_capab->mac_cap = WPA_GET_LE16(pos);
	}

	if (tb[NL80211_BAND_IFTYPE_ATTR_EHT_CAP_PHY]) {
		len = nla_len(tb[NL80211_BAND_IFTYPE_ATTR_EHT_CAP_PHY]);
		if (len > sizeof(eht_capab->phy_cap))
			len = sizeof(eht_capab->phy_cap);
		os_memcpy(eht_capab->phy_cap,
			nla_data(tb[NL80211_BAND_IFTYPE_ATTR_EHT_CAP_PHY]),
			len);
	}

	if (tb[NL80211_BAND_IFTYPE_ATTR_EHT_CAP_MCS_SET]) {
		len = nla_len(tb[NL80211_BAND_IFTYPE_ATTR_EHT_CAP_MCS_SET]);
		if (len > sizeof(eht_capab->mcs))
			len = sizeof(eht_capab->mcs);
		os_memcpy(eht_capab->mcs,
			  nla_data(tb[NL80211_BAND_IFTYPE_ATTR_EHT_CAP_MCS_SET]),
			  len);
	}

	if (tb[NL80211_BAND_IFTYPE_ATTR_EHT_CAP_PPE]) {
		len = nla_len(tb[NL80211_BAND_IFTYPE_ATTR_EHT_CAP_PPE]);
		if (len > sizeof(eht_capab->ppet))
			len = sizeof(eht_capab->ppet);
		os_memcpy(&eht_capab->ppet,
			  nla_data(tb[NL80211_BAND_IFTYPE_ATTR_EHT_CAP_PPE]),
			  len);
	}
}

static int cw2ecw(unsigned int cw)
{
	int bit;

	if (cw == 0)
		return 0;

	for (bit = 1; cw != 1; bit++)
		cw >>= 1;

	return bit;
}

static void phy_info_freq(struct phy_info *phy,
			  struct channel_data *chan,
			  struct nlattr *tb_freq[])
{
	enum nl80211_dfs_state state = 0;
	static struct nla_policy wmm_policy[NL80211_WMMR_MAX + 1] = {
		[NL80211_WMMR_CW_MIN] = { .type = NLA_U16 },
		[NL80211_WMMR_CW_MAX] = { .type = NLA_U16 },
		[NL80211_WMMR_AIFSN] = { .type = NLA_U8 },
		[NL80211_WMMR_TXOP] = { .type = NLA_U16 },
	};
	static const u8 wmm_map[4] = {
		[NL80211_AC_BE] = WMM_AC_BE,
		[NL80211_AC_BK] = WMM_AC_BK,
		[NL80211_AC_VI] = WMM_AC_VI,
		[NL80211_AC_VO] = WMM_AC_VO,
	};
	struct nlattr *nl_wmm = NULL;
	struct nlattr *tb_wmm[NL80211_WMMR_MAX + 1];
	int rem_wmm = 0, count = 0;
	unsigned int ac = 0;

	os_memset(chan, 0, sizeof(*chan));
	chan->freq = nla_get_u32(tb_freq[NL80211_FREQUENCY_ATTR_FREQ]);
	chan->flag = 0;
	chan->allowed_bw = ~0;
	chan->dfs_cac_ms = 0;

	if (tb_freq[NL80211_FREQUENCY_ATTR_DISABLED])
		chan->flag |= CHAN_DISABLED;
	if (tb_freq[NL80211_FREQUENCY_ATTR_NO_IR])
		chan->flag |= CHAN_NO_IR;
	if (tb_freq[NL80211_FREQUENCY_ATTR_RADAR])
		chan->flag |= CHAN_RADAR;
	if (tb_freq[NL80211_FREQUENCY_ATTR_INDOOR_ONLY])
		chan->flag |= CHAN_INDOOR_ONLY;
	if (tb_freq[NL80211_FREQUENCY_ATTR_GO_CONCURRENT])
		chan->flag |= CHAN_GO_CONCURRENT;

	if (tb_freq[NL80211_FREQUENCY_ATTR_NO_20MHZ])
		chan->allowed_bw &= ~CHAN_WIDTH_20;
	if (tb_freq[NL80211_FREQUENCY_ATTR_NO_HT40_PLUS])
		chan->allowed_bw &= ~CHAN_WIDTH_40P;
	if (tb_freq[NL80211_FREQUENCY_ATTR_NO_HT40_MINUS])
		chan->allowed_bw &= ~CHAN_WIDTH_40M;
	if (tb_freq[NL80211_FREQUENCY_ATTR_NO_80MHZ])
		chan->allowed_bw &= ~CHAN_WIDTH_80;
	if (tb_freq[NL80211_FREQUENCY_ATTR_NO_160MHZ])
		chan->allowed_bw &= ~CHAN_WIDTH_160;
	if (tb_freq[NL80211_FREQUENCY_ATTR_NO_320MHZ])
		chan->allowed_bw &= ~CHAN_WIDTH_320;

	if (tb_freq[NL80211_FREQUENCY_ATTR_DFS_STATE]) {
		state = nla_get_u32(tb_freq[NL80211_FREQUENCY_ATTR_DFS_STATE]);
		switch (state) {
		case NL80211_DFS_USABLE:
			chan->flag |= CHAN_DFS_USABLE;
			break;
		case NL80211_DFS_AVAILABLE:
			chan->flag |= CHAN_DFS_AVAILABLE;
			break;
		case NL80211_DFS_UNAVAILABLE:
			chan->flag |= CHAN_DFS_UNAVAILABLE;
			break;
		}
	}

	if (tb_freq[NL80211_FREQUENCY_ATTR_DFS_CAC_TIME])
		chan->dfs_cac_ms = nla_get_u32(
			tb_freq[NL80211_FREQUENCY_ATTR_DFS_CAC_TIME]);

	chan->wmm_rules_valid = 0;
	if (tb_freq[NL80211_FREQUENCY_ATTR_WMM]) {
		nla_for_each_nested(nl_wmm, tb_freq[NL80211_FREQUENCY_ATTR_WMM],
				    rem_wmm) {
			if (nla_parse_nested(tb_wmm, NL80211_WMMR_MAX, nl_wmm,
					     wmm_policy)) {
				err(DEBUG_CAT_NL80211,
					"Failed to parse WMM rules attribute\n");
				return;
			}
			if (!tb_wmm[NL80211_WMMR_CW_MIN] ||
			    !tb_wmm[NL80211_WMMR_CW_MAX] ||
			    !tb_wmm[NL80211_WMMR_AIFSN] ||
			    !tb_wmm[NL80211_WMMR_TXOP]) {
				err(DEBUG_CAT_NL80211,
					"Channel is missing WMM rule attribute\n");
				return;
			}
			ac = nl_wmm->nla_type;
			if ((unsigned int) ac >= ARRAY_SIZE(wmm_map)) {
				err(DEBUG_CAT_NL80211,
					"Invalid AC value %d\n", ac);
				return;
			}

			ac = wmm_map[ac];
			chan->wmm_rules[ac].min_cwmin =
				cw2ecw(nla_get_u16(
					       tb_wmm[NL80211_WMMR_CW_MIN]));
			chan->wmm_rules[ac].min_cwmax =
				cw2ecw(nla_get_u16(
					       tb_wmm[NL80211_WMMR_CW_MAX]));
			chan->wmm_rules[ac].min_aifs =
				nla_get_u8(tb_wmm[NL80211_WMMR_AIFSN]);
			chan->wmm_rules[ac].max_txop =
				nla_get_u16(tb_wmm[NL80211_WMMR_TXOP]) / 32;
			count++;
		}

		/* Set valid flag if all the AC rules are present */
		if (count == WMM_AC_NUM)
			chan->wmm_rules_valid = 1;
	}
}

static int phy_info_rates(struct phy_info *phy, struct nlattr *tb)
{
	static struct nla_policy rate_policy[NL80211_BITRATE_ATTR_MAX + 1] = {
		[NL80211_BITRATE_ATTR_RATE] = { .type = NLA_U32 },
		[NL80211_BITRATE_ATTR_2GHZ_SHORTPREAMBLE] = { .type = NLA_FLAG },
	};
	struct nlattr *tb_rate[NL80211_BITRATE_ATTR_MAX + 1];
	struct nlattr *nl_rate = NULL;
	int rem_rate = 0, idx = 0;
	int *rates = NULL;

	if (tb == NULL)
		return NL_OK;

	nla_for_each_nested(nl_rate, tb, rem_rate) {
		nla_parse(tb_rate, NL80211_BITRATE_ATTR_MAX,
			  nla_data(nl_rate), nla_len(nl_rate),
			  rate_policy);
		if (!tb_rate[NL80211_BITRATE_ATTR_RATE])
			continue;
		phy->num_rates++;
	}

	rates = os_realloc_array(phy->rates,
				   phy->num_rates, sizeof(int));
	if (!rates)
		return NL_STOP;
	phy->rates = rates;
	idx = 0;

	nla_for_each_nested(nl_rate, tb, rem_rate) {
		nla_parse(tb_rate, NL80211_BITRATE_ATTR_MAX,
			  nla_data(nl_rate), nla_len(nl_rate),
			  rate_policy);
		if (!tb_rate[NL80211_BITRATE_ATTR_RATE])
			continue;
		phy->rates[idx] = nla_get_u32(
			tb_rate[NL80211_BITRATE_ATTR_RATE]);
		idx++;
	}

	return NL_OK;
}

static int phy_info_iftype(struct phy_info *phy,
			   struct nlattr *nl_iftype)
{
	struct nlattr *tb[NL80211_BAND_IFTYPE_ATTR_MAX + 1];
	struct nlattr *tb_flags[NL80211_IFTYPE_MAX + 1];

	nla_parse(tb, NL80211_BAND_IFTYPE_ATTR_MAX,
		  nla_data(nl_iftype), nla_len(nl_iftype), NULL);

	if (!tb[NL80211_BAND_IFTYPE_ATTR_IFTYPES])
		return NL_STOP;

	if (nla_parse_nested(tb_flags, NL80211_IFTYPE_MAX,
			     tb[NL80211_BAND_IFTYPE_ATTR_IFTYPES], NULL))
		return NL_STOP;

	if (nla_get_flag(tb_flags[NL80211_IFTYPE_STATION]) ||
		nla_get_flag(tb_flags[NL80211_IFTYPE_AP]))
		phy_info_iftype_copy(phy, tb, tb_flags);

	return NL_OK;
}

static void phy_info_ht_capa(struct phy_info *phy, struct nlattr *capa,
			     struct nlattr *ampdu_factor,
			     struct nlattr *ampdu_density,
			     struct nlattr *mcs_set)
{
	u8 *mcs = NULL;

	if (capa)
		phy->ht_capab = nla_get_u16(capa);

	if (ampdu_factor)
		phy->a_mpdu_params |= nla_get_u8(ampdu_factor) & 0x03;

	if (ampdu_density)
		phy->a_mpdu_params |= nla_get_u8(ampdu_density) << 2;

	if (mcs_set && nla_len(mcs_set) >= 16) {
		mcs = nla_data(mcs_set);
		os_memcpy(phy->mcs_set, mcs, 16);
	}
}

static void phy_info_vht_capa(struct phy_info *phy,
			      struct nlattr *capa,
			      struct nlattr *mcs_set)
{
	u8 *mcs = NULL;

	if (capa)
		phy->vht_capab = nla_get_u32(capa);

	if (mcs_set && nla_len(mcs_set) >= 8) {
		mcs = nla_data(mcs_set);
		os_memcpy(phy->vht_mcs_set, mcs, 8);
	}
}

static int phy_info_freqs(struct phy_info_arg *phy_arg,
			  struct phy_info *phy, struct nlattr *tb)
{
	static struct nla_policy freq_policy[NL80211_FREQUENCY_ATTR_MAX + 1] = {
		[NL80211_FREQUENCY_ATTR_FREQ] = { .type = NLA_U32 },
		[NL80211_FREQUENCY_ATTR_DISABLED] = { .type = NLA_FLAG },
		[NL80211_FREQUENCY_ATTR_NO_IR] = { .type = NLA_FLAG },
		[NL80211_FREQUENCY_ATTR_RADAR] = { .type = NLA_FLAG },
		[NL80211_FREQUENCY_ATTR_MAX_TX_POWER] = { .type = NLA_U32 },
		[NL80211_FREQUENCY_ATTR_DFS_STATE] = { .type = NLA_U32 },
		[NL80211_FREQUENCY_ATTR_NO_10MHZ] = { .type = NLA_FLAG },
		[NL80211_FREQUENCY_ATTR_NO_20MHZ] = { .type = NLA_FLAG },
		[NL80211_FREQUENCY_ATTR_NO_HT40_PLUS] = { .type = NLA_FLAG },
		[NL80211_FREQUENCY_ATTR_NO_HT40_MINUS] = { .type = NLA_FLAG },
		[NL80211_FREQUENCY_ATTR_NO_80MHZ] = { .type = NLA_FLAG },
		[NL80211_FREQUENCY_ATTR_NO_160MHZ] = { .type = NLA_FLAG },
	};
	int new_channels = 0;
	struct channel_data *channel = NULL;
	struct nlattr *tb_freq[NL80211_FREQUENCY_ATTR_MAX + 1];
	struct nlattr *nl_freq = NULL;
	int rem_freq = 0, idx = 0;

	if (tb == NULL)
		return NL_OK;

	nla_for_each_nested(nl_freq, tb, rem_freq) {
		nla_parse(tb_freq, NL80211_FREQUENCY_ATTR_MAX,
			  nla_data(nl_freq), nla_len(nl_freq), freq_policy);
		if (!tb_freq[NL80211_FREQUENCY_ATTR_FREQ])
			continue;
		new_channels++;
	}

	channel = os_realloc_array(phy->channels,
				   phy->num_channels + new_channels,
				   sizeof(struct channel_data));
	if (!channel)
		return NL_STOP;

	phy->channels = channel;
	phy->num_channels += new_channels;

	idx = phy_arg->last_chan_idx;

	nla_for_each_nested(nl_freq, tb, rem_freq) {
		nla_parse(tb_freq, NL80211_FREQUENCY_ATTR_MAX,
			  nla_data(nl_freq), nla_len(nl_freq), freq_policy);
		if (!tb_freq[NL80211_FREQUENCY_ATTR_FREQ])
			continue;
		phy_info_freq(phy, &phy->channels[idx], tb_freq);
		idx++;
	}
	phy_arg->last_chan_idx = idx;

	return NL_OK;
}


static int phy_info_band(struct phy_info_arg *phy_arg, struct nlattr *nl_band,
	unsigned char phy_id)
{
	struct nlattr *tb_band[NL80211_BAND_ATTR_MAX + 1];
	struct phy_info *phy = NULL;
	int ret = 0;
	struct nlattr *nl_iftype;
	int rem_band;

	if (phy_arg->last_phy != nl_band->nla_type) {
		phy = os_realloc_array(phy_arg->phy,
				*phy_arg->num_phys + 1, sizeof(*phy));
		if (!phy) {
			phy_arg->failed = 1;
			return NL_STOP;
		}
		phy_arg->phy = phy;
		phy = &phy_arg->phy[*(phy_arg->num_phys)];
		os_memset(phy, 0, sizeof(*phy));
		phy->mode = WMODE_INVALID;
		phy->flags = MODE_FLAG_HT_INFO_KNOWN |
			MODE_FLAG_VHT_INFO_KNOWN;

		/*
		 * Unsupported VHT MCS stream is defined as value 3, so the VHT
		 * MCS RX/TX map must be initialized with 0xffff to mark all 8
		 * possible streams as unsupported. This will be overridden if
		 * driver advertises VHT support.
		 */
		phy->vht_mcs_set[0] = 0xff;
		phy->vht_mcs_set[1] = 0xff;
		phy->vht_mcs_set[4] = 0xff;
		phy->vht_mcs_set[5] = 0xff;

		phy_arg->last_phy = nl_band->nla_type;
		phy->phy_id = phy_id;
		phy_arg->last_chan_idx = 0;
		*(phy_arg->num_phys) += 1;
	} else
		phy = &phy_arg->phy[*(phy_arg->num_phys) - 1];

	nla_parse(tb_band, NL80211_BAND_ATTR_MAX, nla_data(nl_band),
		  nla_len(nl_band), NULL);
	if (tb_band[NL80211_BAND_ATTR_HT_CAPA]) {
		phy_info_ht_capa(phy, tb_band[NL80211_BAND_ATTR_HT_CAPA],
			 tb_band[NL80211_BAND_ATTR_HT_AMPDU_FACTOR],
			 tb_band[NL80211_BAND_ATTR_HT_AMPDU_DENSITY],
			 tb_band[NL80211_BAND_ATTR_HT_MCS_SET]);
		phy->ht_set = 1;
	}
	if (tb_band[NL80211_BAND_ATTR_VHT_CAPA]) {
		phy_info_vht_capa(phy, tb_band[NL80211_BAND_ATTR_VHT_CAPA],
			  tb_band[NL80211_BAND_ATTR_VHT_MCS_SET]);
		phy->vht_set = 1;
	}
	ret = phy_info_freqs(phy_arg, phy, tb_band[NL80211_BAND_ATTR_FREQS]);
	if (ret != NL_OK) {
		phy_arg->failed = 1;
		return ret;
	}
	ret = phy_info_rates(phy, tb_band[NL80211_BAND_ATTR_RATES]);
	if (ret != NL_OK) {
		phy_arg->failed = 1;
		return ret;
	}

	if (tb_band[NL80211_BAND_ATTR_IFTYPE_DATA]) {
		nla_for_each_nested(nl_iftype,
				    tb_band[NL80211_BAND_ATTR_IFTYPE_DATA],
				    rem_band) {
			ret = phy_info_iftype(phy, nl_iftype);
			if (ret != NL_OK) {
				phy_arg->failed = 1;
				return ret;
			}
		}
	}

	return NL_OK;
}


static int get_phy_handler(struct nl_msg *msg, void *arg)
{
	struct nlattr *tb_msg[NL80211_ATTR_MAX + 1];
	struct genlmsghdr *gnlh = nlmsg_data(nlmsg_hdr(msg));
	struct phy_info_arg *phy_arg = (struct phy_info_arg *)arg;
	struct nlattr *nl_band = NULL;
	int rem_band = 0, res = 0;
	unsigned char phy_id = 0;

	nla_parse(tb_msg, NL80211_ATTR_MAX, genlmsg_attrdata(gnlh, 0),
		  genlmsg_attrlen(gnlh, 0), NULL);

	if (!tb_msg[NL80211_ATTR_WIPHY_BANDS] || !tb_msg[NL80211_ATTR_WIPHY])
		return NL_SKIP;

	phy_id = nla_get_u32(tb_msg[NL80211_ATTR_WIPHY]);

	nla_for_each_nested(nl_band, tb_msg[NL80211_ATTR_WIPHY_BANDS], rem_band) {
		res = phy_info_band(phy_arg, nl_band, phy_id);
		if (res != NL_OK)
			return res;
	}

	return NL_SKIP;
}

static struct phy_info *driver_nl80211_postprocess_modes(struct phy_info *phy, unsigned char num_phys)
{
	unsigned short m = 0;
	unsigned char i = 0;

	/* heuristic to set up modes */
	for (m = 0; m < num_phys; m++) {
		if (!phy[m].num_channels)
			continue;
		if (phy[m].channels[0].freq < 2000) {
			phy[m].num_channels = 0;
			continue;
		} else if (phy[m].channels[0].freq < 4000) {
			phy[m].mode |= WMODE_B;
			for (i = 0; i < phy[m].num_rates; i++) {
				if (phy[m].rates[i] > 200) {
					phy[m].mode |= WMODE_G;
					break;
				}
			}
			if (phy[m].ht_capab)
				phy[m].mode |= WMODE_GN;
			if (phy[m].he_capab.he_supported)
				phy[m].mode |= WMODE_AX_24G;
			if (phy[m].eht_capab.eht_supported)
				phy[m].mode |= WMODE_BE_24G;
		} else if (phy[m].channels[0].freq > 5000 && phy[m].channels[0].freq < 5900) {
			phy[m].mode |= WMODE_A;
			if (phy[m].ht_capab)
				phy[m].mode |= WMODE_AN;
			if (phy[m].vht_capab)
				phy[m].mode |= WMODE_AC;
			if (phy[m].he_capab.he_supported)
				phy[m].mode |= WMODE_AX_5G;
			if (phy[m].eht_capab.eht_supported)
				phy[m].mode |= WMODE_BE_5G;
		} else if ((phy[m].channels[0].freq > 5950 && phy[m].channels[0].freq < 7120)) {
			phy[m].mode |= WMODE_AX_6G;
			if (phy[m].ht_capab)
				phy[m].mode |= WMODE_AN;
			if (phy[m].vht_capab)
				phy[m].mode |= WMODE_AC;
			if (phy[m].eht_capab.eht_supported)
				phy[m].mode |= WMODE_BE_6G;
		}
	}

	/* Remove unsupported bands */
	m = 0;
	while (m < num_phys) {
		if (phy[m].mode == WMODE_INVALID) {
			warn(DEBUG_CAT_NL80211, "Remove unsupported mode; phy_id=%d\n", phy[m].phy_id);
			os_free(phy[m].channels);
			os_free(phy[m].rates);
			if (m + 1 < num_phys)
				os_memmove(&phy[m], &phy[m + 1],
					   sizeof(struct phy_info) *
					   (num_phys - (m + 1)));
			num_phys--;
			continue;
		}
		m++;
	}

	return phy;
}


struct phy_info *driver_nl80211_get_hw_info(void *drv_data, u8 *num_phys)
{
	struct nl_msg *msg = NULL;
	struct phy_info *phy = NULL;
	struct driver_nl80211_data *drv = NULL;
	struct phy_info_arg result = {
		.num_phys = num_phys,
		.phy = NULL,
		.last_phy = -1,
		.failed = 0,
	};
	int ret = 0;

	if (!drv_data || !num_phys) {
		err(DEBUG_CAT_NL80211, "invalid input params; drv_data=%p; num_phys=%p\n",
			drv_data, num_phys);
		return NULL;
	}

	drv = (struct driver_nl80211_data *)drv_data;
	*num_phys = 0;
	msg = unl_genl_msg(&drv->nl_handle, NL80211_CMD_GET_WIPHY, TRUE);
	if (!msg) {
		err(DEBUG_CAT_NL80211, "unl_genl_msg fail!!!\n");
		return NULL;
	}
	ret = nla_put_flag(msg, NL80211_ATTR_SPLIT_WIPHY_DUMP);
	if (ret < 0) {
		err(DEBUG_CAT_NL80211, "nla_put_flag fail!!!\n");
		nlmsg_free(msg);
		return NULL;
	}
	unl_genl_request(&drv->nl_handle, msg, get_phy_handler, &result);
	if (result.failed == 1) {
		err(DEBUG_CAT_NL80211, "get_phy_handler fail\n");
		if (phy->rates)
			free(phy->rates);
		if (phy->channels)
			free(phy->channels);
		free(phy);
		*num_phys = 0;

		return NULL;
	}

	phy = driver_nl80211_postprocess_modes(result.phy, *num_phys);

	return phy;
}

struct dev_info_arg {
	unsigned char *num_devs;
	struct dev_info *dev;
	int last_phy;
	int failed;
};

char *channel_width_name(enum nl80211_chan_width width)
{
	switch (width) {
	case NL80211_CHAN_WIDTH_20_NOHT:
		return "20 MHz (no HT)";
	case NL80211_CHAN_WIDTH_20:
		return "20 MHz";
	case NL80211_CHAN_WIDTH_40:
		return "40 MHz";
	case NL80211_CHAN_WIDTH_80:
		return "80 MHz";
	case NL80211_CHAN_WIDTH_80P80:
		return "80+80 MHz";
	case NL80211_CHAN_WIDTH_160:
		return "160 MHz";
	case NL80211_CHAN_WIDTH_5:
		return "5 MHz";
	case NL80211_CHAN_WIDTH_10:
		return "10 MHz";
	default:
		return "unknown";
	}
}

static const char *ifmodes[NL80211_IFTYPE_MAX + 1] = {
	"unspecified",
	"IBSS",
	"managed",
	"AP",
	"AP/VLAN",
	"WDS",
	"monitor",
	"mesh point",
	"P2P-client",
	"P2P-GO",
	"P2P-device",
	"outside context of a BSS",
	"NAN",
};

static char modebuf[100];

const char *iftype_name(enum nl80211_iftype iftype)
{
	int ret = 0;

	if (iftype <= NL80211_IFTYPE_MAX && ifmodes[iftype])
		return ifmodes[iftype];
	ret = os_snprintf(modebuf, sizeof(modebuf), "Unknown mode (%d)", iftype);
	if (os_snprintf_error(sizeof(modebuf), ret)) {
		err(DEBUG_CAT_NL80211, "os_snprintf fail\n");
		return "Unknown mode";
	}
	return modebuf;
}

static int get_devs_handler(struct nl_msg *msg, void *arg)
{
	struct genlmsghdr *gnlh = nlmsg_data(nlmsg_hdr(msg));
	struct nlattr *tb_msg[NL80211_ATTR_MAX + 1];
	struct dev_info_arg *dev_arg = (struct dev_info_arg *)arg;
	struct dev_info *dev = NULL;
	u32 freq = 0;

	nla_parse(tb_msg, NL80211_ATTR_MAX, genlmsg_attrdata(gnlh, 0),
		  genlmsg_attrlen(gnlh, 0), NULL);

	if (!tb_msg[NL80211_ATTR_WIPHY])
		return NL_SKIP;

	/* skip device which ApEnable=0 */
	if (!tb_msg[NL80211_ATTR_SSID] &&
		(nla_get_u32(tb_msg[NL80211_ATTR_IFTYPE]) == NL80211_IFTYPE_AP))
		return NL_SKIP;

	dev = os_realloc_array(dev_arg->dev,
				*dev_arg->num_devs + 1,
				sizeof(*dev));
	if (!dev) {
		dev_arg->failed = 1;
		return NL_STOP;
	}
	dev_arg->dev = dev;
	dev = &dev_arg->dev[*(dev_arg->num_devs)];
	os_memset(dev, 0, sizeof(*dev));
	dev->phy_id = nla_get_u32(tb_msg[NL80211_ATTR_WIPHY]);
	*(dev_arg->num_devs) += 1;

	dev->valid = 1;
	if (tb_msg[NL80211_ATTR_IFNAME])
		os_memcpy(dev->ifname, nla_data(tb_msg[NL80211_ATTR_IFNAME]),
			nla_len(tb_msg[NL80211_ATTR_IFNAME]));
	else
		os_memcpy(dev->ifname, "unnamed intf", os_strlen("unnamed intf"));
	if (tb_msg[NL80211_ATTR_IFINDEX])
		dev->ifindex = nla_get_u32(tb_msg[NL80211_ATTR_IFINDEX]);
	if (tb_msg[NL80211_ATTR_MAC])
		memcpy(dev->mac, nla_data(tb_msg[NL80211_ATTR_MAC]), MAC_ADDR_LEN);
	if (tb_msg[NL80211_ATTR_IFTYPE])
		dev->iftype = nla_get_u32(tb_msg[NL80211_ATTR_IFTYPE]);
	if (tb_msg[NL80211_ATTR_WIPHY_FREQ]) {
		freq = nla_get_u32(tb_msg[NL80211_ATTR_WIPHY_FREQ]);
		dev->freq = freq;
		if (tb_msg[NL80211_ATTR_CHANNEL_WIDTH]) {
			dev->bw = nla_get_u32(tb_msg[NL80211_ATTR_CHANNEL_WIDTH]);
			if (tb_msg[NL80211_ATTR_CENTER_FREQ1])
				dev->center1 = nla_get_u32(tb_msg[NL80211_ATTR_CENTER_FREQ1]);
			if (tb_msg[NL80211_ATTR_CENTER_FREQ2])
				dev->center2 = nla_get_u32(tb_msg[NL80211_ATTR_CENTER_FREQ2]);
		}
	} else {
		warn(DEBUG_CAT_NL80211, "dev %s has no freq info\n", dev->ifname);
	}
	if (tb_msg[NL80211_ATTR_WIPHY_TX_POWER_LEVEL]) {
		/*correct unit*/
		dev->txpower = nla_get_u32(tb_msg[NL80211_ATTR_WIPHY_TX_POWER_LEVEL]);
		/*convert from mbm to dbm*/
		dev->txpower /= 100;
	}
	if (tb_msg[NL80211_ATTR_4ADDR])
		dev->use_4addr = nla_get_u8(tb_msg[NL80211_ATTR_4ADDR]);
	if (tb_msg[NL80211_ATTR_SSID]) {
		os_memcpy(dev->ssid, nla_data(tb_msg[NL80211_ATTR_SSID]),
			nla_len(tb_msg[NL80211_ATTR_SSID]));
		dev->ssid_len = nla_len(tb_msg[NL80211_ATTR_SSID]);
	} else {
		warn(DEBUG_CAT_NL80211, "dev %s has no ssid\n", dev->ifname);
	}

	return NL_SKIP;
}

static int get_dev_handler(struct nl_msg *msg, void *arg)
{
	struct genlmsghdr *gnlh = nlmsg_data(nlmsg_hdr(msg));
	struct nlattr *tb_msg[NL80211_ATTR_MAX + 1];
	struct dev_info *dev = (struct dev_info *)arg;
	u32 freq = 0;

	nla_parse(tb_msg, NL80211_ATTR_MAX, genlmsg_attrdata(gnlh, 0),
		  genlmsg_attrlen(gnlh, 0), NULL);

	if (tb_msg[NL80211_ATTR_WIPHY]) {
		dev->phy_id = nla_get_u32(tb_msg[NL80211_ATTR_WIPHY]);
		info(DEBUG_CAT_NL80211, "\tphy_id %d\n", dev->phy_id);
	}
	if (tb_msg[NL80211_ATTR_IFNAME]) {
		os_memcpy(dev->ifname, nla_data(tb_msg[NL80211_ATTR_IFNAME]),
			nla_len(tb_msg[NL80211_ATTR_IFNAME]));
		info(DEBUG_CAT_NL80211, "\tInterface %s\n", dev->ifname);
	}
	if (tb_msg[NL80211_ATTR_IFINDEX]) {
		dev->ifindex = nla_get_u32(tb_msg[NL80211_ATTR_IFINDEX]);
		info(DEBUG_CAT_NL80211, "\tifindex %u\n", dev->ifindex);
	}
	if (tb_msg[NL80211_ATTR_MAC]) {
		COPY_MAC_ADDR(dev->mac, nla_data(tb_msg[NL80211_ATTR_MAC]));
		info(DEBUG_CAT_NL80211, "\taddr "MACSTR"\n", MAC2STR(dev->mac));
	}
	if (tb_msg[NL80211_ATTR_IFTYPE]) {
		dev->iftype = nla_get_u32(tb_msg[NL80211_ATTR_IFTYPE]);
		info(DEBUG_CAT_NL80211, "\tdev_type = %s\n", iftype_name(dev->iftype));
	}
	if (tb_msg[NL80211_ATTR_WIPHY_FREQ]) {
		freq = nla_get_u32(tb_msg[NL80211_ATTR_WIPHY_FREQ]);
		dev->freq = freq;
		info(DEBUG_CAT_NL80211, "\tfreq (%d MHz)", freq);
		if (tb_msg[NL80211_ATTR_CHANNEL_WIDTH]) {
			dev->bw = nla_get_u32(tb_msg[NL80211_ATTR_CHANNEL_WIDTH]);
			info(DEBUG_CAT_NL80211, "\tbw %s", channel_width_name(dev->bw));

			if (tb_msg[NL80211_ATTR_CENTER_FREQ1]) {
				dev->center1 = nla_get_u32(tb_msg[NL80211_ATTR_CENTER_FREQ1]);
				info(DEBUG_CAT_NL80211, "\t center1: %d MHz", dev->center1);
			}
			if (tb_msg[NL80211_ATTR_CENTER_FREQ2]) {
				dev->center2 = nla_get_u32(tb_msg[NL80211_ATTR_CENTER_FREQ2]);
				info(DEBUG_CAT_NL80211, "\t center21: %d MHz", dev->center2);
			}
		}
	}
	if (tb_msg[NL80211_ATTR_WIPHY_TX_POWER_LEVEL]) {
		/*correct unit*/
		dev->txpower = nla_get_u32(tb_msg[NL80211_ATTR_WIPHY_TX_POWER_LEVEL]);
		info(DEBUG_CAT_NL80211, "\ttxpower %d.%.2d dBm\n",
			dev->txpower / 100, dev->txpower % 100);
		/*convert from mbm to dbm*/
		dev->txpower /= 100;
	}
	if (tb_msg[NL80211_ATTR_4ADDR]) {
		dev->use_4addr = nla_get_u8(tb_msg[NL80211_ATTR_4ADDR]);
		info(DEBUG_CAT_NL80211, "\t4addr: %d\n", dev->use_4addr);
	}
	if (tb_msg[NL80211_ATTR_SSID]) {
		os_memcpy(dev->ssid, nla_data(tb_msg[NL80211_ATTR_SSID]),
			nla_len(tb_msg[NL80211_ATTR_SSID]));
		dev->ssid_len = nla_len(tb_msg[NL80211_ATTR_SSID]);
		info(DEBUG_CAT_NL80211, "\tssid %s len=%d\n",
			dev->ssid, dev->ssid_len);
	}

	return NL_SKIP;
}

struct dev_info *driver_nl80211_get_devs(void *drv_data, u8 *num_devs)
{
	struct nl_msg *msg = NULL;
	struct driver_nl80211_data *drv = NULL;
	struct dev_info_arg result = {
			.num_devs = num_devs,
			.dev = NULL,
			.last_phy = -1,
			.failed = 0,
		};

	if (!drv_data || !num_devs) {
		err(DEBUG_CAT_NL80211, "invalid input params; drv_data=%p; num_devs=%p\n",
			drv_data, num_devs);
		return NULL;
	}

	drv = (struct driver_nl80211_data *)drv_data;
	msg = unl_genl_msg(&drv->nl_handle, NL80211_CMD_GET_INTERFACE, TRUE);
	if (!msg) {
		err(DEBUG_CAT_NL80211, "unl_genl_msg fail!!!\n");
		return NULL;
	}
	unl_genl_request(&drv->nl_handle, msg, get_devs_handler, &result);

	return result.dev;
}

int driver_nl80211_get_dev(void *drv_data, struct dev_info *dev)
{
	struct nl_msg *msg = NULL;
	struct driver_nl80211_data *drv = NULL;
	int ret = 0;
	if (!drv_data || !dev) {
		err(DEBUG_CAT_NL80211, "invalid input params\n");
		return -1;
	}

	drv = (struct driver_nl80211_data *)drv_data;
	msg = unl_genl_msg(&drv->nl_handle, NL80211_CMD_GET_INTERFACE, FALSE);
	if (!msg) {
		err(DEBUG_CAT_NL80211, "unl_genl_msg fail!!!\n");
		return -1;
	}
	ret = nla_put_u32(msg, NL80211_ATTR_IFINDEX, dev->ifindex);
	if (ret < 0) {
		err(DEBUG_CAT_NL80211, "nla_put_u32 failed\n");
		nlmsg_free(msg);
		return -1;
	}
	info(DEBUG_CAT_NL80211, "query dev %s by ifindex %d\n", dev->ifname, dev->ifindex);
	unl_genl_request(&drv->nl_handle, msg, get_dev_handler, dev);

	return 0;
}

static int country_handler(struct nl_msg *msg, void *arg)
{
	char *alpha2 = NULL;
	struct nlattr *tb_msg[NL80211_ATTR_MAX + 1];
	struct genlmsghdr *gnlh = NULL;

	if (!msg || !arg) {
		err(DEBUG_CAT_NL80211, "invalid input params\n");
		return NL_SKIP;
	}

	alpha2 = arg;
	gnlh = nlmsg_data(nlmsg_hdr(msg));
	nla_parse(tb_msg, NL80211_ATTR_MAX, genlmsg_attrdata(gnlh, 0),
		  genlmsg_attrlen(gnlh, 0), NULL);
	if (!tb_msg[NL80211_ATTR_REG_ALPHA2]) {
		err(DEBUG_CAT_NL80211, "No country information available");
		return NL_SKIP;
	}
	os_strlcpy(alpha2, nla_data(tb_msg[NL80211_ATTR_REG_ALPHA2]), 3);

	return NL_SKIP;
}

int driver_nl80211_get_country(void *drv_data, char *country_code)
{
	struct nl_msg *msg = NULL;
	struct driver_nl80211_data *drv = NULL;
	int ret = 0;

	if (!drv_data || !country_code) {
		err(DEBUG_CAT_MISC, "invalid input params\n");
		return -1;
	}

	drv = (struct driver_nl80211_data *)drv_data;
	msg = unl_genl_msg(&drv->nl_handle, NL80211_CMD_GET_REG, FALSE);
	if (!msg) {
		err(DEBUG_CAT_NL80211, "unl_genl_msg fail\n");
		return -1;
	}
	country_code[0] = '\0';
	unl_genl_request(&drv->nl_handle, msg, country_handler, (void *)country_code);
	if (!country_code[0])
		ret = -1;

	return ret;
}

static int ext_feature_isset(const unsigned char *ext_features, int ext_features_len,
			     enum nl80211_ext_feature_index ftidx)
{
	unsigned char ft_byte;

	if ((int) ftidx / 8 >= ext_features_len)
		return 0;

	ft_byte = ext_features[ftidx / 8];
	return (ft_byte & BIT(ftidx % 8)) != 0;
}

static int phy_feature_handler(struct nl_msg *msg, void *arg)
{
	struct nlattr *tb_msg[NL80211_ATTR_MAX + 1];
	struct genlmsghdr *gnlh = NULL;
	struct phy_info *phy = NULL;

	if (!msg || !arg) {
		err(DEBUG_CAT_NL80211, "invalid input params\n");
		return NL_SKIP;
	}

	gnlh = nlmsg_data(nlmsg_hdr(msg));
	phy = (struct phy_info *)arg;
	nla_parse(tb_msg, NL80211_ATTR_MAX, genlmsg_attrdata(gnlh, 0),
		  genlmsg_attrlen(gnlh, 0), NULL);

	if (tb_msg[NL80211_ATTR_EXT_FEATURES]) {
		if (ext_feature_isset(nla_data(tb_msg[NL80211_ATTR_EXT_FEATURES]),
			nla_len(tb_msg[NL80211_ATTR_EXT_FEATURES]), NL80211_EXT_FEATURE_RADAR_BACKGROUND)) {
			phy->zero_wait_dfs = 1;
		}
	}

	return NL_SKIP;
}


int driver_nl80211_get_feature(void *drv_data,
	struct phy_info *phy)
{
	struct nl_msg *msg = NULL;
	struct driver_nl80211_data *drv = NULL;
	int ret = 0;

	if (!drv_data || !phy) {
		err(DEBUG_CAT_MISC, "invalid input params\n");
		return -1;
	}

	drv = (struct driver_nl80211_data *)drv_data;
	msg = unl_genl_msg(&drv->nl_handle, NL80211_CMD_GET_WIPHY, TRUE);
	if (!msg) {
		err(DEBUG_CAT_NL80211, "unl_genl_msg failed\n");
		return -1;
	}
	ret = nla_put_u32(msg, NL80211_ATTR_WIPHY, phy->phy_id);
	if (ret < 0) {
		err(DEBUG_CAT_NL80211, "nla_put_u32 failed\n");
		nlmsg_free(msg);
		return -1;
	}
	ret = nla_put_flag(msg, NL80211_ATTR_SPLIT_WIPHY_DUMP);
	if (ret < 0) {
		err(DEBUG_CAT_NL80211, "nla_put_flag failed\n");
		nlmsg_free(msg);
		return -1;
	}
	unl_genl_request(&drv->nl_handle, msg, phy_feature_handler, phy);

	return 0;
}
#endif

static void nl80211_handle_wapp_support_ver(struct nlattr *attr)
{
	char *version;
	char wapp_support_ver[16] = {0};
	int ret;

	version = nla_data(attr);
	ret = os_snprintf(&wapp_support_ver[0], sizeof(wapp_support_ver), "%s", version);
	if (os_snprintf_error(sizeof(wapp_support_ver), ret)) {
		err(DEBUG_CAT_NL80211, "os_snprintf fail\n");
		return;
	}

	if (os_memcmp(WAPP_VERSION, wapp_support_ver, os_strlen(WAPP_VERSION)) != 0)
		err(DEBUG_CAT_MISC, "driver support ver (%s) != cur WAPP ver (%s)\n",
			wapp_support_ver, WAPP_VERSION);
}

static void nl80211_handle_wifi_ver(struct nlattr *attr)
{
	char *version;
	char wifi_ver[16];
	int ret;

	version = nla_data(attr);
	ret = os_snprintf(&wifi_ver[0], sizeof(wifi_ver), "%s", version);
	if (os_snprintf_error(sizeof(wifi_ver), ret)) {
		err(DEBUG_CAT_MISC, "os_snprintf fail\n");
		return;
	}

	notice(DEBUG_CAT_MISC, "wifi_ver=%s\n", wifi_ver);
}

static void nl80211_handle_wapp_chip_id(struct wifi_app *wapp, u32 ifindex, u32 *chip_id)
{
	struct wapp_dev *wdev = NULL;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (!wdev) {
		err(DEBUG_CAT_NL80211, "can't find wdev by ifindex(%d)\n", ifindex);
		return;
	}

	wdev->radio->chip_id = *chip_id;
}

static void nl80211_handle_wapp_max_sta_num(struct wifi_app *wapp, u32 ifindex, u16 *max_sta_num)
{
	u16 MaxStaAllowed = 0;

	MaxStaAllowed = wapp->map->max_client_cnt;
	if (*max_sta_num <= 0 || *max_sta_num > wapp->map->max_client_cnt)
		wapp->map->max_client_cnt = MaxStaAllowed;
	else
		wapp->map->max_client_cnt = *max_sta_num;
}

static int nl80211_get_msg_copy2caller(struct driver_nl80211_data *drv_data, char *data, u32 data_len)
{
	if (!drv_data->get_data) {
		err(DEBUG_CAT_MISC, "get_data is NULL\n");
		return -1;
	}

	if (*drv_data->get_data_len > 4096) {
		err(DEBUG_CAT_MISC, "get_data_len(%d) is too long > 4096\n", *drv_data->get_data_len);
		return -1;
	}

	if (data_len < *drv_data->get_data_len) {
		os_memcpy(drv_data->get_data, data, data_len);
		*drv_data->get_data_len = data_len;
	} else {
		os_memcpy(drv_data->get_data, data, *drv_data->get_data_len);
	}

	return 0;
}

static int nl80211_static_info_get_msg_cb(struct nl_msg *msg, void *arg)
{
	struct nlattr *tb[NL80211_ATTR_MAX + 1];
	struct nlattr *sub_tb[MTK_NL80211_VENDOR_ATTR_GET_STATIC_INFO_MAX + 1];
	struct genlmsghdr *gnlh = nlmsg_data(nlmsg_hdr(msg));
	struct driver_nl80211_data *drv_data = (struct driver_nl80211_data *)arg;
	struct wifi_app *wapp = (struct wifi_app *)drv_data->priv;
	char *data;
	u32 data_len;
	int ret;

	if (gnlh->cmd != NL80211_CMD_VENDOR) {
		err(DEBUG_CAT_NL80211, "not mtk vendor cmd\n");
		return NL_SKIP;
	}

	ret = nla_parse(tb, NL80211_ATTR_MAX, genlmsg_attrdata(gnlh, 0), genlmsg_attrlen(gnlh, 0), NULL);
	if (ret) {
		err(DEBUG_CAT_NL80211, "nla_parse fail!\n");
		return NL_SKIP;
	}

	if (!tb[NL80211_ATTR_VENDOR_DATA]) {
		err(DEBUG_CAT_NL80211, "NL80211_ATTR_VENDOR_DATA missing\n");
		return NL_SKIP;
	}

	ret = nla_parse_nested(sub_tb, MTK_NL80211_VENDOR_ATTR_GET_STATIC_INFO_MAX, tb[NL80211_ATTR_VENDOR_DATA], NULL);
	if (ret) {
		err(DEBUG_CAT_NL80211, "nla_parse_nested fail!\n");
		return NL_SKIP;
	}

	if (sub_tb[MTK_NL80211_VENDOR_ATTR_GET_STATIC_INFO_CHIP_ID]) {
		data = nla_data(sub_tb[MTK_NL80211_VENDOR_ATTR_GET_STATIC_INFO_CHIP_ID]);
		nl80211_handle_wapp_chip_id(wapp, drv_data->ifindex, (u32 *)data);
	}

	if (sub_tb[MTK_NL80211_VENDOR_ATTR_GET_STATIC_INFO_COEXISTENCE]) {
		data = nla_data(sub_tb[MTK_NL80211_VENDOR_ATTR_GET_STATIC_INFO_COEXISTENCE]);
		data_len = nla_len(sub_tb[MTK_NL80211_VENDOR_ATTR_GET_STATIC_INFO_COEXISTENCE]);
		nl80211_get_msg_copy2caller(drv_data, data, data_len);
	}

	if (sub_tb[MTK_NL80211_VENDOR_ATTR_GET_STATIC_INFO_WIFI_VER])
		nl80211_handle_wifi_ver(sub_tb[MTK_NL80211_VENDOR_ATTR_GET_STATIC_INFO_WIFI_VER]);

	if (sub_tb[MTK_NL80211_VENDOR_ATTR_GET_STATIC_INFO_WAPP_SUPPORT_VER])
		nl80211_handle_wapp_support_ver(sub_tb[MTK_NL80211_VENDOR_ATTR_GET_STATIC_INFO_WAPP_SUPPORT_VER]);

	return NL_SKIP;
}

static int nl80211_runtime_info_get_msg_cb(struct nl_msg *msg, void *arg)
{
	struct nlattr *tb[NL80211_ATTR_MAX + 1];
	struct nlattr *sub_tb[MTK_NL80211_VENDOR_ATTR_GET_RUNTIME_INFO_MAX + 1];
	struct genlmsghdr *gnlh = nlmsg_data(nlmsg_hdr(msg));
	struct driver_nl80211_data *drv_data = (struct driver_nl80211_data *)arg;
	struct wifi_app *wapp = (struct wifi_app *)drv_data->priv;
	char *data;
	u32 data_len;
	int ret;

	if (gnlh->cmd != NL80211_CMD_VENDOR) {
		err(DEBUG_CAT_NL80211, "not mtk vendor msg\n");
		return NL_SKIP;
	}

	nla_parse(tb, NL80211_ATTR_MAX, genlmsg_attrdata(gnlh, 0), genlmsg_attrlen(gnlh, 0), NULL);

	if (!tb[NL80211_ATTR_VENDOR_DATA]) {
		err(DEBUG_CAT_NL80211, "NL80211_ATTR_VENDOR_DATA missing\n");
		return NL_SKIP;
	}

	ret = nla_parse_nested(sub_tb, MTK_NL80211_VENDOR_ATTR_GET_RUNTIME_INFO_MAX, tb[NL80211_ATTR_VENDOR_DATA], NULL);
	if (ret) {
		err(DEBUG_CAT_NL80211, "nla_parse_nested fail!\n");
		return NL_SKIP;
	}

	if (sub_tb[MTK_NL80211_VENDOR_ATTR_GET_RUNTIME_INFO_GET_MAX_NUM_OF_STA]) {
		data = nla_data(sub_tb[MTK_NL80211_VENDOR_ATTR_GET_RUNTIME_INFO_GET_MAX_NUM_OF_STA]);
		nl80211_handle_wapp_max_sta_num(wapp, drv_data->ifindex, (u16 *)data);
	}

	if (sub_tb[MTK_NL80211_VENDOR_ATTR_GET_RUNTIME_INFO_GET_CHAN_LIST]) {
		data = nla_data(sub_tb[MTK_NL80211_VENDOR_ATTR_GET_RUNTIME_INFO_GET_CHAN_LIST]);
		wdev_chn_list_query_rsp_handle(wapp, drv_data->ifindex, (wdev_chn_info *)data);
	}

	if (sub_tb[MTK_NL80211_VENDOR_ATTR_GET_RUNTIME_INFO_GET_NOP_CHANNEL_LIST]) {
		data = nla_data(sub_tb[MTK_NL80211_VENDOR_ATTR_GET_RUNTIME_INFO_GET_NOP_CHANNEL_LIST]);
		wdev_handle_nop_channels((struct nop_channel_list_s *)data);
	}

	if (sub_tb[MTK_NL80211_VENDOR_ATTR_GET_RUNTIME_INFO_GET_OP_CLASS]) {
		data = nla_data(sub_tb[MTK_NL80211_VENDOR_ATTR_GET_RUNTIME_INFO_GET_OP_CLASS]);
#ifndef MAP_6E_SUPPORT
		wdev_op_class_query_rsp_handle(wapp, drv_data->ifindex, (wdev_op_class_info *)data);
#else
		wdev_op_class_query_rsp_handle(wapp, drv_data->ifindex, (struct _wdev_op_class_info_ext *)data);
#endif
	}

	if (sub_tb[MTK_NL80211_VENDOR_ATTR_GET_RUNTIME_INFO_GET_BSS_INFO]) {
		data = nla_data(sub_tb[MTK_NL80211_VENDOR_ATTR_GET_RUNTIME_INFO_GET_BSS_INFO]);
		wdev_bss_info_query_rsp_handle(wapp, drv_data->ifindex, (wdev_bss_info *)data);
	}

	if (sub_tb[MTK_NL80211_VENDOR_ATTR_GET_RUNTIME_INFO_GET_WAPP_WSC_PROFILES]) {
		data = nla_data(sub_tb[MTK_NL80211_VENDOR_ATTR_GET_RUNTIME_INFO_GET_WAPP_WSC_PROFILES]);
		data_len = nla_len(sub_tb[MTK_NL80211_VENDOR_ATTR_GET_RUNTIME_INFO_GET_WAPP_WSC_PROFILES]);
		nl80211_get_msg_copy2caller(drv_data, data, data_len);
	}

	if (sub_tb[MTK_NL80211_VENDOR_ATTR_GET_RUNTIME_INFO_GET_MLO_MLD_INFO]) {
		data = nla_data(sub_tb[MTK_NL80211_VENDOR_ATTR_GET_RUNTIME_INFO_GET_MLO_MLD_INFO]);
#ifdef MTK_MLO_MAP_SUPPORT
		wdev_mlo_mld_quey_rsp_handle(wapp, drv_data->ifindex, (struct _wdev_mlo_info *)data);
#endif
	}

	return NL_SKIP;
}

static int nl80211_cap_get_msg_cb(struct nl_msg *msg, void *arg)
{
	struct nlattr *tb[NL80211_ATTR_MAX + 1];
	struct nlattr *sub_tb[MTK_NL80211_VENDOR_ATTR_GET_CAP_INFO_MAX + 1];
	struct genlmsghdr *gnlh = nlmsg_data(nlmsg_hdr(msg));
	struct driver_nl80211_data *drv_data = (struct driver_nl80211_data *)arg;
	struct wifi_app *wapp = (struct wifi_app *)drv_data->priv;
	char *data;
	u32 data_len;
	int ret;

	if (gnlh->cmd != NL80211_CMD_VENDOR) {
		err(DEBUG_CAT_NL80211, "not mtk vendor cmd\n");
		return NL_SKIP;
	}

	nla_parse(tb, NL80211_ATTR_MAX, genlmsg_attrdata(gnlh, 0), genlmsg_attrlen(gnlh, 0), NULL);

	if (!tb[NL80211_ATTR_VENDOR_DATA]) {
		err(DEBUG_CAT_NL80211, "NL80211_ATTR_VENDOR_DATA missing\n");
		return NL_SKIP;
	}

	ret = nla_parse_nested(sub_tb, MTK_NL80211_VENDOR_ATTR_GET_CAP_INFO_MAX, tb[NL80211_ATTR_VENDOR_DATA], NULL);
	if (ret) {
		err(DEBUG_CAT_NL80211, "nla_parse_nested fail!\n");
		return NL_SKIP;
	}

	if (sub_tb[MTK_NL80211_VENDOR_ATTR_GET_CAP_INFO_CAC_CAP]) {
		data = nla_data(sub_tb[MTK_NL80211_VENDOR_ATTR_GET_CAP_INFO_CAC_CAP]);
		data_len = nla_len(sub_tb[MTK_NL80211_VENDOR_ATTR_GET_CAP_INFO_CAC_CAP]);

		nl80211_get_msg_copy2caller(drv_data, data, data_len);
	}

	if (sub_tb[MTK_NL80211_VENDOR_ATTR_GET_CAP_INFO_MISC_CAP]) {
		data = nla_data(sub_tb[MTK_NL80211_VENDOR_ATTR_GET_CAP_INFO_MISC_CAP]);
		wdev_misc_cap_query_rsp_handle(wapp, drv_data->ifindex, (wdev_misc_cap *)data);
	}

	if (sub_tb[MTK_NL80211_VENDOR_ATTR_GET_CAP_INFO_HT_CAP]) {
		data = nla_data(sub_tb[MTK_NL80211_VENDOR_ATTR_GET_CAP_INFO_HT_CAP]);
		wdev_ht_cap_query_rsp_handle(wapp, drv_data->ifindex, (wdev_ht_cap *)data);
	}

	if (sub_tb[MTK_NL80211_VENDOR_ATTR_GET_CAP_INFO_VHT_CAP]) {
		data = nla_data(sub_tb[MTK_NL80211_VENDOR_ATTR_GET_CAP_INFO_VHT_CAP]);
		wdev_vht_cap_query_rsp_handle(wapp, drv_data->ifindex, (wdev_vht_cap *)data);
	}

	if (sub_tb[MTK_NL80211_VENDOR_ATTR_GET_CAP_INFO_HE_CAP]) {
		data = nla_data(sub_tb[MTK_NL80211_VENDOR_ATTR_GET_CAP_INFO_HE_CAP]);
		wdev_he_cap_query_rsp_handle(wapp, drv_data->ifindex, (wdev_he_cap *)data);
	}
#ifdef MAP_EHT_SUPPORT
	if (sub_tb[MTK_NL80211_VENDOR_ATTR_GET_CAP_INFO_EHT_CAP]) {
		data = nla_data(sub_tb[MTK_NL80211_VENDOR_ATTR_GET_CAP_INFO_EHT_CAP]);
		wdev_eht_cap_query_rsp_handle(wapp, drv_data->ifindex, (struct wdev_eht_cap *)data);
	}
#endif
#ifdef MTK_MLO_MAP_SUPPORT
		if (sub_tb[MTK_NL80211_VENDOR_ATTR_GET_CAP_INFO_MLO_CAP]) {
			data = nla_data(sub_tb[MTK_NL80211_VENDOR_ATTR_GET_CAP_INFO_MLO_CAP]);
			wdev_mlo_cap_query_rsp_handle(wapp, drv_data->ifindex, (struct wdev_mlo_caps *)data);
		}
#endif
#ifdef MAP_R3_WF6
	if (sub_tb[MTK_NL80211_VENDOR_ATTR_GET_CAP_INFO_WF6_CAPABILITY]) {
		data = nla_data(sub_tb[MTK_NL80211_VENDOR_ATTR_GET_CAP_INFO_WF6_CAPABILITY]);
		/*data_len = nla_len(sub_tb[MTK_NL80211_VENDOR_ATTR_GET_CAP_INFO_WF6_CAPABILITY]);*/
		wdev_wf6_cap_query_rsp_handle(wapp, drv_data->ifindex, (wdev_wf6_cap_roles *)data);
	}
#endif
	if (sub_tb[MTK_NL80211_VENDOR_ATTR_GET_CAP_INFO_WDEV]) {
		data = nla_data(sub_tb[MTK_NL80211_VENDOR_ATTR_GET_CAP_INFO_WDEV]);
		data_len = nla_len(sub_tb[MTK_NL80211_VENDOR_ATTR_GET_CAP_INFO_WDEV]);

		nl80211_get_msg_copy2caller(drv_data, data, data_len);
	}

	return NL_SKIP;
}

static int nl80211_statistic_get_msg_cb(struct nl_msg *msg, void *arg)
{
	struct nlattr *tb[NL80211_ATTR_MAX + 1];
	struct nlattr *sub_tb[MTK_NL80211_VENDOR_ATTR_GET_STATISTIC_MAX + 1];
	struct genlmsghdr *gnlh = nlmsg_data(nlmsg_hdr(msg));
	struct driver_nl80211_data *drv_data = (struct driver_nl80211_data *)arg;
	struct wifi_app *wapp = (struct wifi_app *)drv_data->priv;
	char *data;
	int ret;

	if (gnlh->cmd != NL80211_CMD_VENDOR) {
		err(DEBUG_CAT_NL80211, "not mtk vendor msg\n");
		return NL_SKIP;
	}

	nla_parse(tb, NL80211_ATTR_MAX, genlmsg_attrdata(gnlh, 0), genlmsg_attrlen(gnlh, 0), NULL);

	if (!tb[NL80211_ATTR_VENDOR_DATA]) {
		err(DEBUG_CAT_NL80211, "NL80211_ATTR_VENDOR_DATA missing\n");
		return NL_SKIP;
	}

	ret = nla_parse_nested(sub_tb, MTK_NL80211_VENDOR_ATTR_GET_STATISTIC_MAX, tb[NL80211_ATTR_VENDOR_DATA], NULL);
	if (ret) {
		err(DEBUG_CAT_NL80211, "nla_parse_nested fail!\n");
		return NL_SKIP;
	}

	if (sub_tb[MTK_NL80211_VENDOR_ATTR_GET_TX_PWR]) {
		data = nla_data(sub_tb[MTK_NL80211_VENDOR_ATTR_GET_TX_PWR]);
		wdev_tx_pwr_query_rsp_handle_ext(wapp, drv_data->ifindex, (struct _wdev_tx_power_ext *)data);
	}

	if (sub_tb[MTK_NL80211_VENDOR_ATTR_GET_AP_METRICS]) {
		data = nla_data(sub_tb[MTK_NL80211_VENDOR_ATTR_GET_AP_METRICS]);
		wdev_ap_metric_query_rsp_handle(wapp, drv_data->ifindex, (wdev_ap_metric *)data);
	}

	return NL_SKIP;
}

static int nl80211_qos_get_msg_cb(struct nl_msg *msg, void *arg)
{
#ifdef QOS_R1
	struct nlattr *tb[NL80211_ATTR_MAX + 1];
	struct nlattr *sub_tb[MTK_NL80211_VENDOR_ATTR_QOS_MAX + 1];
	struct genlmsghdr *gnlh = nlmsg_data(nlmsg_hdr(msg));
	char *data;
	unsigned int data_len;
	int ret;

	if (gnlh->cmd != NL80211_CMD_VENDOR) {
		err(DEBUG_CAT_NL80211, "not mtk vendor msg\n");
		return NL_SKIP;
	}

	nla_parse(tb, NL80211_ATTR_MAX, genlmsg_attrdata(gnlh, 0), genlmsg_attrlen(gnlh, 0), NULL);

	if (!tb[NL80211_ATTR_VENDOR_DATA]) {
		err(DEBUG_CAT_NL80211, "NL80211_ATTR_VENDOR_DATA missing\n");
		return NL_SKIP;
	}

	ret = nla_parse_nested(sub_tb, MTK_NL80211_VENDOR_ATTR_QOS_MAX, tb[NL80211_ATTR_VENDOR_DATA], NULL);
	if (ret) {
		err(DEBUG_CAT_NL80211, "nla_parse_nested fail\n");
		return NL_SKIP;
	}

	if (sub_tb[MTK_NL80211_VENDOR_ATTR_GET_PMK_BY_PEER_MAC]) {
		data = nla_data(sub_tb[MTK_NL80211_VENDOR_ATTR_GET_PMK_BY_PEER_MAC]);
		data_len = nla_len(sub_tb[MTK_NL80211_VENDOR_ATTR_GET_PMK_BY_PEER_MAC]);
		if (data_len > LEN_PMK) {
			err(DEBUG_CAT_NL80211, "data_len check fail!\n");
			return NL_SKIP;
		}
		wapp_write_pmk("/tmp/pmk.txt", data, data_len);
	}

	return NL_SKIP;
#else
	return NL_SKIP;
#endif
}

static int nl80211_dfs_get_msg_cb(struct nl_msg *msg, void *arg)
{
	struct nlattr *tb[NL80211_ATTR_MAX + 1];
	struct nlattr *sub_tb[MTK_NL80211_VENDOR_ATTR_DFS_MAX + 1];
	struct genlmsghdr *gnlh = nlmsg_data(nlmsg_hdr(msg));
	struct driver_nl80211_data *drv_data = (struct driver_nl80211_data *)arg;
	char *data;
	unsigned int data_len;
	int ret;

	if (gnlh->cmd != NL80211_CMD_VENDOR) {
		err(DEBUG_CAT_NL80211, "not mtk vendor msg\n");
		return NL_SKIP;
	}

	nla_parse(tb, NL80211_ATTR_MAX, genlmsg_attrdata(gnlh, 0), genlmsg_attrlen(gnlh, 0), NULL);

	if (!tb[NL80211_ATTR_VENDOR_DATA]) {
		err(DEBUG_CAT_NL80211, "NL80211_ATTR_VENDOR_DATA missing\n");
		return NL_SKIP;
	}

	ret = nla_parse_nested(sub_tb, MTK_NL80211_VENDOR_ATTR_DFS_MAX, tb[NL80211_ATTR_VENDOR_DATA], NULL);
	if (ret) {
		err(DEBUG_CAT_NL80211, "nla_parse_nested fail\n");
		return NL_SKIP;
	}

	if (sub_tb[MTK_NL80211_VENDOR_ATTR_DFS_GET_ZERO_WAIT]) {
		data = nla_data(sub_tb[MTK_NL80211_VENDOR_ATTR_DFS_GET_ZERO_WAIT]);
		data_len = nla_len(sub_tb[MTK_NL80211_VENDOR_ATTR_DFS_GET_ZERO_WAIT]);

		nl80211_get_msg_copy2caller(drv_data, data, data_len);
	}

	return NL_SKIP;
}

static int nl80211_easymesh_get_msg_cb(struct nl_msg *msg, void *arg)
{
	struct nlattr *tb[NL80211_ATTR_MAX + 1];
	struct nlattr *sub_tb[MTK_NL80211_VENDOR_ATTR_EASYMESH_MAX + 1];
	struct genlmsghdr *gnlh = nlmsg_data(nlmsg_hdr(msg));
	struct driver_nl80211_data *drv_data = (struct driver_nl80211_data *)arg;
	struct wifi_app *wapp = (struct wifi_app *)drv_data->priv;
	char *data;
	unsigned int data_len;
	int ret;

	if (wapp == NULL) {
		err(DEBUG_CAT_NL80211, "wapp is NULL\n");
		return NL_SKIP;
	}

	if (gnlh->cmd != NL80211_CMD_VENDOR) {
		err(DEBUG_CAT_NL80211, "not mtk vendor msg\n");
		return NL_SKIP;
	}

	nla_parse(tb, NL80211_ATTR_MAX, genlmsg_attrdata(gnlh, 0), genlmsg_attrlen(gnlh, 0), NULL);

	if (!tb[NL80211_ATTR_VENDOR_DATA]) {
		err(DEBUG_CAT_NL80211, "NL80211_ATTR_VENDOR_DATA missing\n");
		return NL_SKIP;
	}

	ret = nla_parse_nested(sub_tb, MTK_NL80211_VENDOR_ATTR_EASYMESH_MAX, tb[NL80211_ATTR_VENDOR_DATA], NULL);
	if (ret) {
		err(DEBUG_CAT_NL80211, "nla_parse_nested fail\n");
		return NL_SKIP;
	}

	if (sub_tb[MTK_NL80211_VENDOR_ATTR_EASYMESH_GET_ASSOC_REQ_FRAME]) {
		data = nla_data(sub_tb[MTK_NL80211_VENDOR_ATTR_EASYMESH_GET_ASSOC_REQ_FRAME]);
		data_len = nla_len(sub_tb[MTK_NL80211_VENDOR_ATTR_EASYMESH_GET_ASSOC_REQ_FRAME]);

		nl80211_get_msg_copy2caller(drv_data, data, data_len);
	}

	if (sub_tb[MTK_NL80211_VENDOR_ATTR_EASYMESH_GET_DPP_FRAME]) {
		data = nla_data(sub_tb[MTK_NL80211_VENDOR_ATTR_EASYMESH_GET_DPP_FRAME]);
		data_len = nla_len(sub_tb[MTK_NL80211_VENDOR_ATTR_EASYMESH_GET_DPP_FRAME]);

		nl80211_get_msg_copy2caller(drv_data, data, data_len);
	}
#ifdef MAP_R4_SPT
	if (sub_tb[MTK_NL80211_VENDOR_ATTR_GET_SPT_REUSE_REQ]) {
		data = nla_data(sub_tb[MTK_NL80211_VENDOR_ATTR_GET_SPT_REUSE_REQ]);
		data_len = nla_len(sub_tb[MTK_NL80211_VENDOR_ATTR_GET_SPT_REUSE_REQ]);
		wdev_spt_reuse_query_rsp_handle(wapp, drv_data->ifindex, (struct wapp_mesh_sr_info *)data);
	}
#endif
	return NL_SKIP;
}

static int nl80211_ap_monitor_get_msg_cb(struct nl_msg *msg, void *arg)
{
	struct nlattr *tb[NL80211_ATTR_MAX + 1];
	struct nlattr *sub_tb[MTK_NL80211_VENDOR_AP_MONITOR_ATTR_MAX + 1];
	struct genlmsghdr *gnlh = nlmsg_data(nlmsg_hdr(msg));
	struct driver_nl80211_data *drv_data = (struct driver_nl80211_data *)arg;
	char *data;
	unsigned int data_len;
	int ret;

	if (gnlh->cmd != NL80211_CMD_VENDOR) {
		err(DEBUG_CAT_NL80211, "not mtk vendor msg\n");
		return NL_SKIP;
	}

	nla_parse(tb, NL80211_ATTR_MAX, genlmsg_attrdata(gnlh, 0), genlmsg_attrlen(gnlh, 0), NULL);

	if (!tb[NL80211_ATTR_VENDOR_DATA]) {
		err(DEBUG_CAT_NL80211, "NL80211_ATTR_VENDOR_DATA missing\n");
		return NL_SKIP;
	}

	ret = nla_parse_nested(sub_tb, MTK_NL80211_VENDOR_AP_MONITOR_ATTR_MAX, tb[NL80211_ATTR_VENDOR_DATA], NULL);
	if (ret) {
		err(DEBUG_CAT_NL80211, "nla_parse_nested fail\n");
		return NL_SKIP;
	}

	if (sub_tb[MTK_NL80211_VENDOR_ATTR_AP_MONITOR_GET_RESULT]) {
		data = nla_data(sub_tb[MTK_NL80211_VENDOR_ATTR_AP_MONITOR_GET_RESULT]);
		data_len = nla_len(sub_tb[MTK_NL80211_VENDOR_ATTR_AP_MONITOR_GET_RESULT]);

		nl80211_get_msg_copy2caller(drv_data, data, data_len);
	}

	return NL_SKIP;
}

static int nl80211_radio_stats_get_msg_cb(struct nl_msg *msg, void *arg)
{
	struct nlattr *tb[NL80211_ATTR_MAX + 1];
	struct nlattr *sub_tb[MTK_NL80211_VENDOR_ATTR_RADIO_STATS_ATTR_MAX + 1];
	struct genlmsghdr *gnlh = nlmsg_data(nlmsg_hdr(msg));
	struct driver_nl80211_data *drv_data = (struct driver_nl80211_data *)arg;
	char *data;
	unsigned int data_len;
	int ret;

	if (gnlh->cmd != NL80211_CMD_VENDOR) {
		err(DEBUG_CAT_NL80211, "not mtk vendor msg\n");
		return NL_SKIP;
	}

	nla_parse(tb, NL80211_ATTR_MAX, genlmsg_attrdata(gnlh, 0), genlmsg_attrlen(gnlh, 0), NULL);

	if (!tb[NL80211_ATTR_VENDOR_DATA]) {
		err(DEBUG_CAT_NL80211, "NL80211_ATTR_VENDOR_DATA missing\n");
		return NL_SKIP;
	}

	ret = nla_parse_nested(sub_tb, MTK_NL80211_VENDOR_ATTR_RADIO_STATS_ATTR_MAX, tb[NL80211_ATTR_VENDOR_DATA], NULL);
	if (ret) {
		err(DEBUG_CAT_NL80211, "nla_parse_nested fail\n");
		return NL_SKIP;
	}

	if (sub_tb[MTK_NL80211_VENDOR_ATTR_GET_RADIO_CPU_TEMPRETURE]) {
		data = nla_data(sub_tb[MTK_NL80211_VENDOR_ATTR_GET_RADIO_CPU_TEMPRETURE]);
		data_len = nla_len(sub_tb[MTK_NL80211_VENDOR_ATTR_GET_RADIO_CPU_TEMPRETURE]);
		nl80211_get_msg_copy2caller(drv_data, data, data_len);
	}

	return NL_SKIP;
}

char *get_nl80211_set_msg_cmd_str(unsigned short cmd)
{
	switch (cmd) {
	case MTK_NL80211_VENDOR_SUBCMD_WAPP_REQ:
		return "MTK_NL80211_VENDOR_SUBCMD_WAPP_REQ";
	case MTK_NL80211_VENDOR_SUBCMD_EASYMESH:
		return "MTK_NL80211_VENDOR_SUBCMD_EASYMESH";
	case MTK_NL80211_VENDOR_SUBCMD_SET_CHANNEL:
		return "MTK_NL80211_VENDOR_SUBCMD_SET_CHANNEL";
	case MTK_NL80211_VENDOR_SUBCMD_SET_AUTO_CH_SEL:
		return "MTK_NL80211_VENDOR_SUBCMD_SET_AUTO_CH_SEL";
	case MTK_NL80211_VENDOR_SUBCMD_SET_SCAN:
		return "MTK_NL80211_VENDOR_SUBCMD_SET_SCAN";
	case MTK_NL80211_VENDOR_SUBCMD_DFS:
		return "MTK_NL80211_VENDOR_SUBCMD_DFS";
	case MTK_NL80211_VENDOR_SUBCMD_OFFCHANNEL_INFO:
		return "MTK_NL80211_VENDOR_SUBCMD_OFFCHANNEL_INFO";
	case MTK_NL80211_VENDOR_SUBCMD_SET_ACTION:
		return "MTK_NL80211_VENDOR_SUBCMD_SET_ACTION";
	case MTK_NL80211_VENDOR_SUBCMD_QOS:
		return "MTK_NL80211_VENDOR_SUBCMD_QOS";
	case MTK_NL80211_VENDOR_SUBCMD_SET_AP_BSS:
		return "MTK_NL80211_VENDOR_SUBCMD_SET_AP_BSS";
	case MTK_NL80211_VENDOR_SUBCMD_SET_AP_MONITOR:
		return "MTK_NL80211_VENDOR_SUBCMD_SET_AP_MONITOR";
	case MTK_NL80211_VENDOR_SUBCMD_SET_V10CONVERTER:
		return "MTK_NL80211_VENDOR_SUBCMD_SET_V10CONVERTER";
	case MTK_NL80211_VENDOR_SUBCMD_SET_APPROXYREFRESH:
		return "MTK_NL80211_VENDOR_SUBCMD_SET_APPROXYREFRESH";
	case MTK_NL80211_VENDOR_SUBCMD_SET_MLO_SWITCH:
		return "MTK_NL80211_VENDOR_SUBCMD_SET_MLO_SWITCH";
	case MTK_NL80211_VENDOR_SUBCMD_SET_ACL:
		return "MTK_NL80211_VENDOR_SUBCMD_SET_ACL";
	case MTK_NL80211_VENDOR_SUBCMD_BH_STATUS:
		return "MTK_NL80211_VENDOR_SUBCMD_BH_STATUS";
	case MTK_NL80211_VENDOR_SUBCMD_SET_COSR_IE:
		return "MTK_NL80211_VENDOR_SUBCMD_SET_COSR_IE";
	case MTK_NL80211_VENDOR_SUBCMD_SET_COSR_INFO:
		return "MTK_NL80211_VENDOR_SUBCMD_SET_COSR_INFO";
	case MTK_NL80211_VENDOR_SUBCMD_SET_AP_RADIO:
		return "MTK_NL80211_VENDOR_SUBCMD_SET_AP_RADIO";
	default:
		return "UNKNOWN_CMD";
	}


}

static int driver_nl80211_set_msg(struct driver_nl80211_data *drv_data, const char *ifname, unsigned short cmd_id,
				  unsigned short sub_cmd_id, void *data, size_t len)
{
	struct nl_msg *msg;
	void *nl_data;
	int ret = -1;

	debug(DEBUG_CAT_NL80211, "ifname=%s; cmd_id=0x%04x(%s); sub_cmd_id=0x%04x\n",
		(ifname == NULL ? "" : ifname),
		cmd_id, get_nl80211_set_msg_cmd_str(cmd_id),
		sub_cmd_id);
	if (data)
		info_hexdump(DEBUG_CAT_NL80211, "cmd dump", data, len);

	if (!ifname) {
		err(DEBUG_CAT_NL80211, "ifname is NULL\n");
		return ret;
	}

	msg = unl_genl_msg(&drv_data->nl_handle, NL80211_CMD_VENDOR, FALSE);
	if (!msg) {
		err(DEBUG_CAT_NL80211, "unl_genl_msg fail\n");
		return ret;
	}

	if (nla_put_u32(msg, NL80211_ATTR_IFINDEX, if_nametoindex(ifname)) ||
	    nla_put_u32(msg, NL80211_ATTR_VENDOR_ID, MTK_NL80211_VENDOR_ID) ||
	    nla_put_u32(msg, NL80211_ATTR_VENDOR_SUBCMD, cmd_id)) {
		err(DEBUG_CAT_NL80211, "nla_put_u32 fail\n");
		goto out;
	}

	nl_data = nla_nest_start(msg, NL80211_ATTR_VENDOR_DATA);
	if (!nl_data)
		goto out;

	ret = nla_put(msg, sub_cmd_id, len, data);
	if (ret) {
		err(DEBUG_CAT_NL80211, "nla_put fail\n");
		goto out;
	}

	nla_nest_end(msg, nl_data);

	ret = unl_genl_request(&drv_data->nl_handle, msg, NULL, NULL);
	if (ret)
		err(DEBUG_CAT_NL80211, "unl_genl_request fail; errno=%s\n",
			strerror(-ret));

	return ret;
out:
	nlmsg_free(msg);
	return ret;
}

#ifdef EM_PLUS_SUPPORT
static int driver_nl80211_set_2_msg(struct driver_nl80211_data *drv_data,
		const char *ifname, unsigned short cmd_id,
		unsigned short sub_cmd_id, void *data, size_t len,
		unsigned short sub_cmd_id2, void *data2, size_t len2)
{
	struct nl_msg *msg;
	void *nl_data;
	int ret = -1;

	msg = unl_genl_msg(&drv_data->nl_handle, NL80211_CMD_VENDOR, FALSE);
	if (!msg) {
		err(DEBUG_CAT_NL80211, "unl_genl_msg fail\n");
		return ret;
	}

	if (nla_put_u32(msg, NL80211_ATTR_IFINDEX, if_nametoindex(ifname)) ||
		nla_put_u32(msg, NL80211_ATTR_VENDOR_ID, MTK_NL80211_VENDOR_ID) ||
		nla_put_u32(msg, NL80211_ATTR_VENDOR_SUBCMD, cmd_id)) {
		err(DEBUG_CAT_NL80211, "nla_put_u32 fail\n");
		goto out;
	}

	nl_data = nla_nest_start(msg, NL80211_ATTR_VENDOR_DATA);
	if (!nl_data)
		goto out;

	ret = nla_put(msg, sub_cmd_id, len, data);
	if (ret) {
		err(DEBUG_CAT_NL80211, "nla_put fail; errno=%s\n", strerror(-ret));
		goto out;
	}

	ret = nla_put(msg, sub_cmd_id2, len2, data2);
	if (ret) {
		err(DEBUG_CAT_NL80211, "nla_put fail; errno=%s\n", strerror(-ret));
		goto out;
	}

	nla_nest_end(msg, nl_data);

	ret = unl_genl_request(&drv_data->nl_handle, msg, NULL, NULL);
	if (ret)
		err(DEBUG_CAT_NL80211, "unl_genl_request fail; errno=%s\n", strerror(-ret));

	return ret;
out:
	nlmsg_free(msg);
	return ret;
}
#endif /* EM_PLUS_SUPPORT */

static int driver_nl80211_set_4_msg(struct driver_nl80211_data *drv_data,
		const char *ifname, unsigned short cmd_id,
		unsigned short sub_cmd_id, void *data, size_t len,
		unsigned short sub_cmd_id2, void *data2, size_t len2,
		unsigned short sub_cmd_id3, void *data3, size_t len3,
		unsigned short sub_cmd_id4, void *data4, size_t len4)
{
	struct nl_msg *msg;
	void *nl_data;
	int ret = -1;

	msg = unl_genl_msg(&drv_data->nl_handle, NL80211_CMD_VENDOR, FALSE);
	if (!msg) {
		err(DEBUG_CAT_NL80211, "unl_genl_msg fail!!!\n");
		return ret;
	}

	if (nla_put_u32(msg, NL80211_ATTR_IFINDEX, if_nametoindex(ifname)) ||
		nla_put_u32(msg, NL80211_ATTR_VENDOR_ID, MTK_NL80211_VENDOR_ID) ||
		nla_put_u32(msg, NL80211_ATTR_VENDOR_SUBCMD, cmd_id)) {
		err(DEBUG_CAT_NL80211, "nla_put_u32 fail!!!\n");
		goto out;
	}

	nl_data = nla_nest_start(msg, NL80211_ATTR_VENDOR_DATA);
	if (!nl_data)
		goto out;

	ret = nla_put(msg, sub_cmd_id, len, data);
	if (ret) {
		err(DEBUG_CAT_NL80211, "nla_put fail: %s\n", strerror(-ret));
		goto out;
	}

	ret = nla_put(msg, sub_cmd_id2, len2, data2);
	if (ret) {
		err(DEBUG_CAT_NL80211, "nla_put fail: %s\n", strerror(-ret));
		goto out;
	}

	ret = nla_put(msg, sub_cmd_id3, len3, data3);
	if (ret) {
		err(DEBUG_CAT_NL80211, "nla_put fail: %s\n", strerror(-ret));
		goto out;
	}

	ret = nla_put(msg, sub_cmd_id4, len4, data4);
	if (ret) {
		err(DEBUG_CAT_NL80211, "nla_put fail: %s\n", strerror(-ret));
		goto out;
	}

	nla_nest_end(msg, nl_data);

	ret = unl_genl_request(&drv_data->nl_handle, msg, NULL, NULL);
	if (ret)
		err(DEBUG_CAT_NL80211, "nl80211 call fail: %s\n", strerror(-ret));

	return ret;
out:
	nlmsg_free(msg);
	return ret;
}

static int driver_nl80211_get_msg(struct driver_nl80211_data *drv_data, const char *ifname, unsigned short cmd_id,
				  unsigned short sub_cmd_id, char *data, size_t *len)
{
	struct nl_msg *msg;
	void *attr;
	int ret = -1;

	drv_data->ifindex = if_nametoindex(ifname);
	if (data && len) {
		drv_data->get_data = data;
		drv_data->get_data_len = (u32 *)len;
	} else {
		err(DEBUG_CAT_NL80211, "invalid input params; data=%p; len=%p\n", data, len);
		return ret;
	}

	msg = unl_genl_msg(&drv_data->nl_handle, NL80211_CMD_VENDOR, FALSE);
	if (!msg) {
		err(DEBUG_CAT_NL80211, "unl_genl_msg fail!!!\n");
		return ret;
	}

	if (nla_put_u32(msg, NL80211_ATTR_IFINDEX, if_nametoindex(ifname)) ||
	    nla_put_u32(msg, NL80211_ATTR_VENDOR_ID, MTK_NL80211_VENDOR_ID) ||
	    nla_put_u32(msg, NL80211_ATTR_VENDOR_SUBCMD, cmd_id)) {
		err(DEBUG_CAT_NL80211, "nla_put_u32 fail!!!\n");
		goto out;
	}

	attr = nla_nest_start(msg, NL80211_ATTR_VENDOR_DATA);
	if (!attr) {
		err(DEBUG_CAT_NL80211, "nla_nest_start fail\n");
		goto out;
	}

	if (nla_put(msg, sub_cmd_id, *len, data)) {
		err(DEBUG_CAT_NL80211, "nla_put fail\n");
		goto out;
	}

	nla_nest_end(msg, attr);

	switch (cmd_id) {
	case MTK_NL80211_VENDOR_SUBCMD_GET_STATIC_INFO:
		ret = unl_genl_request(&drv_data->nl_handle, msg, nl80211_static_info_get_msg_cb, drv_data);
		break;
	case MTK_NL80211_VENDOR_SUBCMD_GET_RUNTIME_INFO:
		ret = unl_genl_request(&drv_data->nl_handle, msg, nl80211_runtime_info_get_msg_cb, drv_data);
		break;
	case MTK_NL80211_VENDOR_SUBCMD_GET_CAP:
		ret = unl_genl_request(&drv_data->nl_handle, msg, nl80211_cap_get_msg_cb, drv_data);
		break;
	case MTK_NL80211_VENDOR_SUBCMD_GET_STATISTIC:
		ret = unl_genl_request(&drv_data->nl_handle, msg, nl80211_statistic_get_msg_cb, drv_data);
		break;
	case MTK_NL80211_VENDOR_SUBCMD_QOS:
		ret = unl_genl_request(&drv_data->nl_handle, msg, nl80211_qos_get_msg_cb, drv_data);
		break;
	case MTK_NL80211_VENDOR_SUBCMD_DFS:
		ret = unl_genl_request(&drv_data->nl_handle, msg, nl80211_dfs_get_msg_cb, drv_data);
		break;
	case MTK_NL80211_VENDOR_SUBCMD_EASYMESH:
		ret = unl_genl_request(&drv_data->nl_handle, msg, nl80211_easymesh_get_msg_cb, drv_data);
		break;
	case MTK_NL80211_VENDOR_SUBCMD_SET_AP_MONITOR:
		ret = unl_genl_request(&drv_data->nl_handle, msg, nl80211_ap_monitor_get_msg_cb, drv_data);
		break;
	case MTK_NL80211_VENDOR_SUBCMD_GET_RADIO_STATS:
		ret = unl_genl_request(&drv_data->nl_handle, msg, nl80211_radio_stats_get_msg_cb, drv_data);
		break;
	default:
		err(DEBUG_CAT_NL80211, "invalid cmd; cmd_id=%d\n", cmd_id);
		goto out;
	}

	if (ret)
		err(DEBUG_CAT_NL80211, "cmd handle fail; cmd_id=%d(%s)\n", cmd_id,
			get_vendor_nl80211_cmd_str(cmd_id));

	return ret;
out:
	nlmsg_free(msg);
	return ret;
}

/*
 * WiFi driver verion
 */
static int driver_nl80211_wifi_version(void *drv_data, const char *ifname, char *ver, size_t *len)
{
	int ret;

	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_get_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_GET_STATIC_INFO,
				     MTK_NL80211_VENDOR_ATTR_GET_STATIC_INFO_WIFI_VER, ver, len);
	if (ret != 0)
		err(DEBUG_CAT_NL80211, "send wifi_version failed\n");

	return ret;
}

static int driver_nl80211_wapp_support_version(void *drv_data, const char *ifname)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	char ver[16] = {0};
	size_t len = sizeof(ver);

	ret = driver_nl80211_get_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_GET_STATIC_INFO,
				     MTK_NL80211_VENDOR_ATTR_GET_STATIC_INFO_WAPP_SUPPORT_VER, ver, &len);
	if (ret != 0)
		err(DEBUG_CAT_NL80211, "send support_version failed\n");

	return ret;
}

static int driver_nl80211_send_wapp_req(void *drv_data, const char *ifname, struct wapp_req *req)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_WAPP_REQ, MTK_NL80211_VENDOR_ATTR_WAPP_REQ,
				     (char *)req, (sizeof(struct wapp_req)));
	if (ret != 0)
		err(DEBUG_CAT_NL80211, "send wapp_req failed\n");

	return ret;
}


static int driver_nl80211_get_bss_coex(void *drv_data, const char *ifname, char *buf, size_t *buf_len)
{
	int ret;
	size_t len = 4;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_get_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_GET_STATIC_INFO,
				     MTK_NL80211_VENDOR_ATTR_GET_STATIC_INFO_COEXISTENCE, buf, &len);
	if (ret != 0)
		err(DEBUG_CAT_NL80211, "send wapp req failed\n");

	return ret;
}

#if defined(MTK_HOSTAPD_SUPPORT) && defined(WPACTRL_SUPPORT)
int driver_nl80211_set_ssid(void *drv_data, const char *ifname, char *ssid, int network_id)
{
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	struct wifi_app *wapp;
	struct wapp_dev *wdev = NULL;
	int ret = -1;

	if (!drv_nl80211_data) {
		err(DEBUG_CAT_NL80211, "invalid drv_data\n");
		return -1;
	}

	wapp = drv_nl80211_data->priv;
	if (!wapp) {
		err(DEBUG_CAT_NL80211, "invalid wapp\n");
		return -1;
	}

	wdev = wapp_dev_list_lookup_by_ifname(wapp, ifname);
	if (!wdev) {
		err(DEBUG_CAT_NL80211, "wdev for ifname:%s not found\n", ifname);
		return -1;
	}

	debug(DEBUG_CAT_NL80211, "wdev:%s type:%d ifname:%s network:%d ssid:%s\n",
		wdev->ifname, wdev->dev_type, ifname, network_id, ssid);

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		ret = wpactrl_cmd_set_ssid(wapp->wpactrl_hostapd_ctx, ifname, ssid, network_id,  WPACTRL_TYPE_AP_LIB);
	} else if (wdev->dev_type == WAPP_DEV_TYPE_STA) {
		ret = wpactrl_cmd_set_ssid(wapp->wpactrl_supplicant_ctx, ifname, ssid, network_id,  WPACTRL_TYPE_STA_LIB);
	}

	if (ret != 0) {
		err(DEBUG_CAT_NL80211, "wpactrl_cmd_set_ssid failed\n");
		return ret;
	}
	return 0;
}
#else
int driver_nl80211_set_ssid(void *drv_data, const char *ifname, char *ssid, int network_id)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	if (strlen(ssid) > SSID_MAX_LEN) {
		err(DEBUG_CAT_NL80211, "invalid ssid length %u\n", (unsigned int)strlen(ssid));
		return -1;
	}

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
				     MTK_NL80211_VENDOR_ATTR_EASYMESH_SET_SSID, ssid, strlen(ssid));
	if (ret != 0) {
		err(DEBUG_CAT_NL80211, "driver_nl80211_set_ssid fail\n");
		return ret;
	}
	ret = os_execute("/usr/bin/wifi_config_save", 3, ifname, "SSID", ssid);

	return ret;
}
#endif /* MTK_HOSTAPD_SUPPORT */
int driver_nl80211_set_ssid_2(void *drv_data, const char *ifname, char *ssid)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
				     MTK_NL80211_VENDOR_ATTR_EASYMESH_SET_SSID, ssid, strlen(ssid));

	return ret;
}

int driver_nl80211_set_psk(void *drv_data, const char *ifname, char *psk)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	if (strlen(psk) > 65) {
		err(DEBUG_CAT_NL80211, "invalid psk length %u\n", (unsigned int)strlen(psk));
		return -1;
	}

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH, MTK_NL80211_VENDOR_ATTR_EASYMESH_SET_PSK,
				     psk, strlen(psk));

	if (ret != 0) {
		err(DEBUG_CAT_NL80211, "driver_nl80211_set_psk fail\n");
		return ret;
	}
#ifndef MTK_HOSTAPD_SUPPORT
	ret = os_execute("/usr/bin/wifi_config_save", 3, ifname, "WPAPSK", psk);
#endif

	return ret;
}

/*
 * Set information element to driver
 */
static int driver_nl80211_set_ie(void *drv_data, const char *ifname, char *ie, size_t ie_len)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH, MTK_NL80211_VENDOR_ATTR_EASYMESH_WAPP_IE,
				     ie, ie_len);

	return ret;
}

#ifdef COSR_SUPPORT
/*
 * Set CoSr information element to driver
 */
static int driver_nl80211_set_cosr_ie(void *drv_data, const char *ifname, char *ie, size_t ie_len)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname,
			MTK_NL80211_VENDOR_SUBCMD_SET_COSR_IE,
			MTK_NL80211_VENDOR_ATTR_SET_AP_COSR_IE,
			ie, ie_len);

	return ret;
}

static int driver_nl80211_set_cosr_stainfo(void *drv_data, const char *ifname, struct cosr_info_set *req)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname,
			MTK_NL80211_VENDOR_SUBCMD_SET_COSR_INFO,
			MTK_NL80211_VENDOR_ATTR_SET_COSR_STAINFO,
			(char *)req, (sizeof(struct cosr_info_set)));
	if (ret != 0)
		err(DEBUG_CAT_NL80211, "send cosr sta info failed\n");

	return ret;
}

static int driver_nl80211_set_cosr_apinfo(void *drv_data, const char *ifname, struct cosr_info_set *req)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname,
			MTK_NL80211_VENDOR_SUBCMD_SET_COSR_INFO,
			MTK_NL80211_VENDOR_ATTR_SET_COSR_APINFO,
			(char *)req, (sizeof(struct cosr_info_set)));
	if (ret != 0)
		err(DEBUG_CAT_NL80211, "send set_cosr_apinfo failed\n");

	return ret;
}

#endif /* COSR_SUPPORT */

int driver_nl80211_set_wireless_mode(void *drv_data, const char *ifname, u8 mode)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
					MTK_NL80211_VENDOR_ATTR_EASYMESH_SET_WIRELESS_MODE, (char *)&mode, sizeof(mode));

	return ret;
}

int driver_nl80211_set_channel(void *drv_data, const char *ifname, u8 channel)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_SET_CHANNEL,
					MTK_NL80211_VENDOR_ATTR_CHAN_SET_NUM, (char *)&channel, sizeof(channel));

	return ret;
}

int driver_nl80211_set_bw(void *drv_data, const char *ifname, u32 bw)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_SET_CHANNEL,
					MTK_NL80211_VENDOR_ATTR_CHAN_SET_BW, (u32 *)&bw, sizeof(bw));

	return ret;
}

int driver_nl80211_set_bw_and_channel(void *drv_data, const char *ifname, u32 bw, u8 channel, u8 cac_req, u8 eht_extcha)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_4_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_SET_CHANNEL,
				MTK_NL80211_VENDOR_ATTR_CHAN_SET_BW, (u32 *)&bw, sizeof(bw),
				MTK_NL80211_VENDOR_ATTR_CHAN_SET_NUM, (u8 *)&channel, sizeof(channel),
				MTK_NL80211_VENDOR_ATTR_CHAN_SET_BYPASS_CAC, (u8 *)&cac_req, sizeof(cac_req),
				MTK_NL80211_VENDOR_ATTR_CHAN_SET_HT_EXTCHAN, (u8 *)&eht_extcha, sizeof(eht_extcha));

	return ret;
}

#ifdef MAP_EHT_SUPPORT
int driver_nl80211_set_ehtbw(void *drv_data, const char *ifname, u8 bw)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
					MTK_NL80211_VENDOR_ATTR_EASYMESH_SET_EHTBW, (char *)&bw, sizeof(bw));
	return ret;
}
#endif

#ifdef EM_PLUS_SUPPORT
int driver_nl80211_set_cfg_bw(void *drv_data, const char *ifname, u32 bw)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_SET_CHANNEL,
					MTK_NL80211_VENDOR_ATTR_CHAN_SET_BW, (u32 *)&bw, sizeof(bw));
	return ret;
}


int driver_nl80211_set_acs_ch_list(void *drv_data, const char *ifname,
					struct acs_ch_config_info *ch_info)
{
	int ret = 0;
	char *buf = NULL;
	size_t len = 0;
	struct ch_list_info *map_pref_list;

	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	len = sizeof(*map_pref_list);
	buf = os_zalloc(len);

	if (!buf) {
		err(DEBUG_CAT_NL80211, "Not available memory\n");
		return -1;
	}

	map_pref_list = (struct ch_list_info *)buf;

	map_pref_list->num_of_ch = ch_info->channel_list_acs;
	os_memcpy(map_pref_list->ch_list, ch_info->channel_acs, ch_info->channel_list_acs);

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_SET_AUTO_CH_SEL,
					MTK_NL80211_VENDOR_ATTR_AUTO_CH_PREFER_LIST, buf, len);
	os_free(buf);
	return ret;
}

int driver_nl80211_set_acs_partial_scan(void *drv_data, const char *ifname, u8 partial_scan_flag)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_SET_AUTO_CH_SEL,
					MTK_NL80211_VENDOR_ATTR_AUTO_CH_PARTIAL, (u8 *)&partial_scan_flag,
					sizeof(partial_scan_flag));
	return ret;
}

int driver_nl80211_set_acs_scan_ch_num(void *drv_data, const char *ifname, u8 ch_scan_num)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_SET_AUTO_CH_SEL,
					MTK_NL80211_VENDOR_ATTR_AUTO_CH_NUM, (u8 *)&ch_scan_num, sizeof(ch_scan_num));
	return ret;
}

int driver_nl80211_set_acs_sta_thresold(void *drv_data, const char *ifname, u16 sta_num_thr)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_SET_AUTO_CH_SEL,
			MTK_NL80211_VENDOR_ATTR_AUTO_CH_STA_NUM_THR, (u16 *)&sta_num_thr,
			sizeof(sta_num_thr));
	return ret;
}

int driver_nl80211_set_acs_ch_util_thresold(void *drv_data, const char *ifname, u8 ch_util)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_SET_AUTO_CH_SEL,
					MTK_NL80211_VENDOR_ATTR_AUTO_CH_CH_UTIL_THR, (u8 *)&ch_util, sizeof(ch_util));
	return ret;
}

int driver_nl80211_set_acs_scan_dwell(void *drv_data, const char *ifname, u16 ch_scan_dwell)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_SET_AUTO_CH_SEL,
					MTK_NL80211_VENDOR_ATTR_AUTO_CH_SCANNING_DWELL, (u16 *)&ch_scan_dwell,
					sizeof(ch_scan_dwell));
	return ret;
}

int driver_nl80211_set_acs_ch_6g_psc(void *drv_data, const char *ifname, u8 ch_6g_psc)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_SET_AUTO_CH_SEL,
					MTK_NL80211_VENDOR_ATTR_AUTO_CH_6G_PSC, (u8 *)&ch_6g_psc, sizeof(ch_6g_psc));
	return ret;
}

int driver_nl80211_set_acs_restore_dwell(void *drv_data, const char *ifname, u16 ch_restore_dwell)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_SET_AUTO_CH_SEL,
					MTK_NL80211_VENDOR_ATTR_AUTO_CH_RESTORE_DWELL, (u16 *)&ch_restore_dwell,
					sizeof(ch_restore_dwell));
	return ret;
}

int driver_nl80211_set_acs_ch_check_time(void *drv_data, const char *ifname, u32 ch_check_time)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_SET_AUTO_CH_SEL,
					MTK_NL80211_VENDOR_ATTR_AUTO_CH_CHECK_TIME, (u16 *)&ch_check_time,
					sizeof(ch_check_time));
	return ret;
}

int driver_nl80211_set_acs_ch_checktime_trigger(void *drv_data, const char *ifname, u8 trigger_flag,
		u32 ch_check_time)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_2_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_SET_AUTO_CH_SEL,
				MTK_NL80211_VENDOR_ATTR_AUTO_CH_SEL, (u8 *)&trigger_flag, sizeof(trigger_flag),
				MTK_NL80211_VENDOR_ATTR_AUTO_CH_CHECK_TIME, (u32 *)&ch_check_time,
					sizeof(ch_check_time));
	return ret;
}
#endif

int driver_nl80211_set_htbw(void *drv_data, const char *ifname, u8 htbw)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
					MTK_NL80211_VENDOR_ATTR_EASYMESH_SET_HTBW, (char *)&htbw, sizeof(htbw));

	return ret;
}

int driver_nl80211_set_vhtbw(void *drv_data, const char *ifname, u8 htbw)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
					MTK_NL80211_VENDOR_ATTR_EASYMESH_SET_VHTBW, (char *)&htbw, sizeof(htbw));

	return ret;
}

int driver_nl80211_set_hidden_ssid(void *drv_data, const char *ifname, u8 hidden_ssid)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
					 MTK_NL80211_VENDOR_ATTR_EASYMESH_SET_HIDDEN_SSID, (char *)&hidden_ssid, sizeof(hidden_ssid));

	return ret;
}

int driver_nl802111_set_auth_mode(void *drv_data, const char *ifname, char *auth_mode)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
					 MTK_NL80211_VENDOR_ATTR_EASYMESH_SET_AUTH_MODE, auth_mode, strlen(auth_mode) + 1);

	return ret;
}

int driver_nl80211_set_encrypt_type(void *drv_data, const char *ifname, char *encrypt_type)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
					 MTK_NL80211_VENDOR_ATTR_EASYMESH_SET_ENCRYP_TYPE, encrypt_type, strlen(encrypt_type));

	return ret;
}

int driver_nl80211_set_default_key_id(void *drv_data, const char *ifname, u8 id)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
					MTK_NL80211_VENDOR_ATTR_EASYMESH_SET_DEFAULT_KEY_ID, (char *)&id, sizeof(id));

	return ret;
}

int driver_nl80211_set_key1(void *drv_data, const char *ifname, char *key)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
					 MTK_NL80211_VENDOR_ATTR_EASYMESH_SET_KEY1, key, strlen(key));

	return ret;
}

int driver_nl80211_set_wpapsk(void *drv_data, const char *ifname, char *wpapsk)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
					 MTK_NL80211_VENDOR_ATTR_EASYMESH_SET_WPA_PSK, wpapsk, strlen(wpapsk));

	return ret;
}

int driver_nl80211_set_radio_on(void *drv_data, const char *ifname, int onoff)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
					 MTK_NL80211_VENDOR_ATTR_EASYMESH_SET_RADIO_ON, (char *)&onoff, sizeof(onoff));

	return ret;
}

int driver_nl80211_set_DisConnectSta(void *drv_data, const char *ifname, unsigned char *sta_addr)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
					 MTK_NL80211_VENDOR_ATTR_EASYMESH_SET_DISCONNECT_STA, (char *)sta_addr, MAC_ADDR_LEN);

	return ret;
}

int driver_nl80211_set_ts_bh_primary_vid(void *drv_data, const char *ifname, unsigned short vid)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
					 MTK_NL80211_VENDOR_ATTR_EASYMESH_SET_TS_BH_PRIMARY_VID, (char *)&vid, sizeof(vid));

	return ret;
}

int driver_nl80211_set_ts_bh_primary_pcp(void *drv_data, const char *ifname, unsigned char pcp)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
					 MTK_NL80211_VENDOR_ATTR_EASYMESH_SET_TS_BH_PRIMARY_PCP, (char *)&pcp, sizeof(pcp));

	return ret;
}

int driver_nl80211_set_bh_vid(void *drv_data, const char *ifname, char *buf, size_t buf_len)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
					 MTK_NL80211_VENDOR_ATTR_EASYMESH_SET_TS_BH_VID, buf, buf_len);

	return ret;
}

int driver_nl80211_set_fh_vid(void *drv_data, const char *ifname, unsigned short vid)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
					 MTK_NL80211_VENDOR_ATTR_EASYMESH_SET_TS_FH_VID, (char *)&vid, sizeof(vid));

	return ret;
}

int driver_nl80211_set_transparent_vid(void *drv_data, const char *ifname, char *buf, size_t buf_len)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
					 MTK_NL80211_VENDOR_ATTR_EASYMESH_SET_TRANSPARENT_VID, buf, buf_len);

	return ret;
}

int driver_nl80211_set_BcnReq(void *drv_data, const char *ifname, char *buf)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
					 MTK_NL80211_VENDOR_ATTR_EASYMESH_SET_BCN_REQ, buf, strlen(buf));

	return ret;
}

int driver_nl80211_HtBssCoex(void *drv_data, const char *ifname, char enable)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
					 MTK_NL80211_VENDOR_ATTR_EASYMESH_SET_HTBSSCOEX, &enable, sizeof(enable));

	return ret;
}

int driver_nl80211_PMFMFPC(void *drv_data, const char *ifname, char enable)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
					 MTK_NL80211_VENDOR_ATTR_EASYMESH_SET_PMFMFPC, &enable, sizeof(enable));

	return ret;
}

int driver_nl80211_AutoRoaming(void *drv_data, const char *ifname, char enable)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
					 MTK_NL80211_VENDOR_ATTR_EASYMESH_SET_AUTO_ROAMING, &enable, sizeof(enable));

	return ret;
}

int driver_nl80211_DSCPPolicyEnable(void *drv_data, const char *ifname, char enable)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
					 MTK_NL80211_VENDOR_ATTR_EASYMESH_SET_DSCP_POLICY_ENABLE, &enable, sizeof(enable));

	return ret;
}

int driver_nl80211_QosMapCapa(void *drv_data, const char *ifname, char enable)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
					 MTK_NL80211_VENDOR_ATTR_EASYMESH_SET_QOS_MAP_CAPA, &enable, sizeof(enable));

	return ret;
}

int driver_nl80211_ScanType(void *drv_data, const char *ifname, char *type)
{
	int ret;
	u8 i, scan_type;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	if (!type) {
		err(DEBUG_CAT_NL80211, "type is NULL\n");
		return -EINVAL;
	}

	for (i = 0; i < ARRAY_SIZE(type_opt); i++) {
		if (strlen(type_opt[i].type_name) == strlen(type) &&
			!strncmp(type_opt[i].type_name, type, strlen(type))) {
			scan_type = type_opt[i].type;
			break;
		}
	}

	if (i == ARRAY_SIZE(type_opt)) {
		err(DEBUG_CAT_NL80211, "can't find scan type\n");
		return -EINVAL;
	}

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_SET_SCAN,
					 MTK_NL80211_VENDOR_ATTR_SCAN_TYPE, &scan_type, sizeof(scan_type));

	return ret;
}

int driver_nl80211_ScanClear(void *drv_data, const char *ifname)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_SET_SCAN,
					 MTK_NL80211_VENDOR_ATTR_SCAN_CLEAR, NULL, 0);

	return ret;
}

int driver_nl80211_get_wsc_profiles(void *drv_data, const char *ifname, char *wsc_profile_data, int *length)
{
	int ret;
	size_t len = 512;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_get_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_GET_RUNTIME_INFO,
				     MTK_NL80211_VENDOR_ATTR_GET_RUNTIME_INFO_GET_WAPP_WSC_PROFILES, wsc_profile_data, &len);

	*length = (int)len;
	return ret;
}
#ifdef MTK_MLO_MAP_SUPPORT
int driver_nl80211_get_mlo_info(void *drv_data, const char *ifname, char *buf, size_t *buf_len)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_get_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_GET_RUNTIME_INFO,
			MTK_NL80211_VENDOR_ATTR_GET_RUNTIME_INFO_GET_MLO_MLD_INFO,
			buf, buf_len);

	return ret;
}
#endif


/* for mbo_ie parsing*/
void parse_mbo_ie_for_btm(struct wifi_app *wapp,
			const char *pos, const char *btm_req, size_t btm_req_len, int *mbo_values) {
	P_MBO_ATTR_STRUCT mbo_attr = NULL;
	MBO_ATTR_STRUCT mbo_attr_nl;

	os_memset(&mbo_attr_nl, 0, sizeof(mbo_attr_nl));
	int cdcp_present = 0;
	int tran_reason_present = 0;
	int tran_reason = 255;
	int relay_delay = 0;

	if (*pos == IE_MBO_ELEMENT_ID) {
		pos = pos + 1;
		pos = pos + 1;
		for (int i = 0; i < 4 ; i++) {
			pos = pos + 1;
		}
		mbo_attr = (P_MBO_ATTR_STRUCT)pos;
		if (mbo_attr->AttrID == MBO_ATTR_AP_CDCP) {
			mbo_attr_nl.AttrID = MBO_ATTR_AP_CDCP;
			mbo_attr_nl.AttrLen = mbo_attr->AttrLen;
			mbo_attr_nl.AttrBody[0] = mbo_attr->AttrBody[0];
			cdcp_present = 1;
			pos += 3;
		}
		if (mbo_attr->AttrID == MBO_ATTR_AP_TRANS_REASON) {
			mbo_attr_nl.AttrID = MBO_ATTR_AP_TRANS_REASON;
			mbo_attr_nl.AttrLen = mbo_attr->AttrLen;
			mbo_attr_nl.AttrBody[0] = mbo_attr->AttrBody[0];
			tran_reason_present = 1;
			tran_reason =   mbo_attr->AttrBody[0];
			pos += 3;
		}
		if (mbo_attr->AttrID == MBO_ATTR_AP_ASSOC_RETRY_DELAY) {
			mbo_attr_nl.AttrID = MBO_ATTR_AP_ASSOC_RETRY_DELAY;
			mbo_attr_nl.AttrLen = mbo_attr->AttrLen;
			os_memcpy(&mbo_attr_nl.AttrBody[0], &mbo_attr->AttrBody[0], 2);
			relay_delay = 1;
			pos += 4;
		}
	}

	mbo_values[0] = cdcp_present;
	mbo_values[1] = tran_reason_present;
	mbo_values[2] = tran_reason;
	mbo_values[3] = relay_delay;
}

#ifdef WPACTRL_SUPPORT
static int driver_nl80211_send_btm_req(void *drv_data, const char *ifname,
					const u8 *peer_sta_addr, const char *btm_req,
					size_t btm_req_len)
{
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	struct wifi_app *wapp;
	struct btm_payload *frame = (struct btm_payload *)btm_req;
	const char *pos;
	int i;
	int ret;
	int disassoc_timer = 0;
	int valid_int = 0;
	int dialog_token = 0;
	int bss_term = 0;
	bss_tm_req_candidate_t *cand_list = NULL;
	int cand_list_len = 0;
	char *url = NULL;
	int url_len = 0;
	int pref = 0;
	int abridged = 0;
	int disassoc_imminent = 0;
	int cdcp_present = 0;
	int tran_reason_present = 0;
	int tran_reason = 255;
	int relay_delay = 0;
	int mbo_values[4] = { cdcp_present, tran_reason_present, tran_reason, relay_delay };
/*	int ess_disassociation_imminent = 0; */

	if (!drv_nl80211_data) {
		err(DEBUG_CAT_NL80211, "invalid drv_data\n");
		return -1;
	}

	wapp = drv_nl80211_data->priv;
	if (!wapp) {
		err(DEBUG_CAT_NL80211, "invalid wapp\n");
		return -1;
	}

	if (frame->u.btm_req.request_mode & 0x02)
		abridged = 1;

	if (frame->u.btm_req.request_mode & 0x04)
		disassoc_imminent = 1;

/*
 *	if (frame->u.btm_req.request_mode & 0x10) {
 *		ess_disassociation_imminent = 1;
 *	}
*/

	disassoc_timer = (int)le2cpu16(frame->u.btm_req.disassociation_timer);
	valid_int = (int)frame->u.btm_req.validity_interval;

	pos = btm_req + 4;

	if (frame->u.btm_req.request_mode & 0x08) { /* termination include */
		struct neighbor_report_subelement *report_subelement;

		report_subelement = (struct neighbor_report_subelement *)pos;
		bss_term = (int)le2cpu16(report_subelement->u.bss_termination_duration.duration);
		pos += 12;
	}

	if ((frame->u.btm_req.request_mode  & (1 << ESS_DISASSOC_IMNT_BIT_MAP))) {
		url_len = (int)*pos;
		pos += 1;
		if (url_len > 0) {
			url = os_malloc(url_len + 1);
			if (url == NULL)
				return -1;

			os_strncpy(url, pos, url_len);
			url[url_len] = '\0';
			pos += url_len;
		}
	}

	if (frame->u.btm_req.request_mode & 0x01) { /* candidate include */
		pref = 1;
		while (pos < (btm_req + btm_req_len)) {
			if (*pos != IE_RRM_NEIGHBOR_REP)
				break;

			int elem_len;
			struct neighbor_report_element *report_element;

			report_element = (struct neighbor_report_element *)pos;
			elem_len = report_element->length;

			cand_list = os_realloc(cand_list, (cand_list_len + 1)*sizeof(bss_tm_req_candidate_t));
			if (cand_list == NULL) {
				if (url)
					os_free(url);

				return -1;
			}
			os_memcpy(cand_list[cand_list_len].bssid, report_element->bssid, 6);
			cand_list[cand_list_len].bssid_info = report_element->bss_info;
			cand_list[cand_list_len].operating_class = report_element->regulatory_class;
			cand_list[cand_list_len].channel = report_element->channel_number;
			cand_list[cand_list_len].phy_type = report_element->phy_type;
			if (elem_len > sizeof(struct neighbor_report_element)) {
				cand_list[cand_list_len].subelement_len = 3;
				os_memcpy(cand_list[cand_list_len].subelement,
					report_element->variable,
					cand_list[cand_list_len].subelement_len);
			}

			pos += elem_len;
			pos = pos + 2;
			cand_list_len++;
#ifdef MAP_R2
			/* For MAP cert mode limiting the neighbor number to 10 */
			if (wapp->map && (wapp->map->TurnKeyEnable == 0)) {
				if (cand_list_len >= (OCE_MAX_RNR_NUM_TO_BCN + 1))
					break;
			}
#endif /* MAP_R2 */
		}
	}

	if (*pos == IE_MBO_ELEMENT_ID) {
		parse_mbo_ie_for_btm(wapp, pos, btm_req, btm_req_len, mbo_values);
		for (int i = 0; i < 4 ; i++) {
			cdcp_present = mbo_values[0];
			tran_reason_present = mbo_values[1];
			tran_reason =   mbo_values[2];
			relay_delay = mbo_values[3];
		}
	}

	debug(DEBUG_CAT_NL80211, "sta mac:" MACSTR " disassoc_timer:%d\n"
			" valid_int:%d dialog_token:%d bss_term:%d\n"
			" url:%s(%d) pref:%d bridged:%d disassoc_imminent:%d\n"
			, MAC2STR(peer_sta_addr),
			disassoc_timer, valid_int, dialog_token, bss_term,
			url, url_len, pref, abridged, disassoc_imminent);

	for (i = 0; i < cand_list_len; i++) {
		debug(DEBUG_CAT_NL80211, " candidate: bssid:" MACSTR " info:0x%x operating_class:%d channel:%d phy_type:%d\n",
				MAC2STR(cand_list[i].bssid),
				cand_list[i].bssid_info,
				cand_list[i].operating_class,
				cand_list[i].channel,
				cand_list[i].phy_type);
	}

	ret = wpactrl_cmd_bss_tm_req(wapp->wpactrl_hostapd_ctx, ifname, peer_sta_addr,
			disassoc_timer, valid_int, dialog_token, bss_term,
			cand_list, cand_list_len, url, url_len, pref,
			abridged, disassoc_imminent, tran_reason, relay_delay, cdcp_present);

	if (ret != 0)
		err(DEBUG_CAT_NL80211, "wpactrl_cmd_bss_tm_req failed\n");

	if (url)
		os_free(url);

	if (cand_list)
		os_free(cand_list);

	return 0;
}

static int driver_nl80211_send_btm_query(void *drv_data, const char *ifname,
					  const char *peer_sta_addr, const char *btm_query,
					  size_t btm_query_len)
{
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	struct wifi_app *wapp;
	int ret = -1;

	if (!drv_nl80211_data) {
		err(DEBUG_CAT_NL80211, RED("invalid drv_data\n"));
		return -1;
	}

	wapp = drv_nl80211_data->priv;
	if (!wapp) {
		err(DEBUG_CAT_NL80211, RED("invalid wapp\n"));
		return -1;
	}

/*	ret = wpactrl_cmd_bss_tm_query(wapp->wpactrl_hostapd_ctx, ifname, peer_sta_addr); */
	if (ret != 0)
		err(DEBUG_CAT_NL80211, "wpactrl_cmd_bss_tm_query failed\n");

	return ret;
}

static int driver_nl80211_send_btm_rsp(void *drv_data, const char *ifname,
					const u8 *peer_sta_addr, const char *btm_rsp,
					size_t btm_rsp_len)
{
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	struct wifi_app *wapp;
	int ret = -1;

	if (!drv_nl80211_data) {
		err(DEBUG_CAT_NL80211, "invalid drv_data\n");
		return -1;
	}

	wapp = drv_nl80211_data->priv;
	if (!wapp) {
		err(DEBUG_CAT_NL80211, "invalid wapp\n");
		return -1;
	}

/*	ret = wpactrl_cmd_bss_tm_resp(wapp->wpactrl_hostapd_ctx, ifname, peer_sta_addr); */
	if (ret != 0)
		err(DEBUG_CAT_NL80211, "wpactrl_cmd_bss_tm_req failed\n");

	return ret;
}

static int driver_nl80211_send_bcn_req(void *drv_data, const char *ifname,
					const u8 *peer_sta_addr, const u8 req_mode,
					const char *bcn_req, size_t bcn_req_len)
{
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	struct wifi_app *wapp;
	int ret;

	if (!drv_nl80211_data) {
		err(DEBUG_CAT_NL80211, "invalid drv_data\n");
		return -1;
	}

	wapp = drv_nl80211_data->priv;
	if (!wapp) {
		err(DEBUG_CAT_NL80211, "invalid wapp\n");
		return -1;
	}

	ret = wpactrl_cmd_req_beacon(wapp->wpactrl_hostapd_ctx, ifname, (uint8_t *)peer_sta_addr,
			req_mode, (uint8_t *)bcn_req, (int)bcn_req_len);
	if (ret != 0)
		err(DEBUG_CAT_NL80211, "wpactrl_cmd_req_beacon failed\n");

	return ret;
}
#endif /* WPACTRL_SUPPORT */

#ifdef MAP_R2
#ifdef DFS_CAC_R2
int driver_nl80211_cac_req(void *drv_data, const char *ifname, u32 param, u32 value)
{
	int ret = -1;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	char *buf;
	size_t len = 0;

	if (param != WAPP_SET_CAC_STOP) {
		err(DEBUG_CAT_NL80211, "param not equal CAC_STOP send msg failed!!!\n");
		return ret;
	}

	buf = os_zalloc(len);

	if (!buf) {
		err(DEBUG_CAT_NL80211, "Not available memory\n");
		return -1;
	}

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_DFS, MTK_NL80211_VENDOR_ATTR_DFS_CAC_STOP,
				     buf, len);
	if (ret != 0)
		err(DEBUG_CAT_NL80211, "send driver_nl80211_cac_req failed\n");

	if (buf != NULL)
		free(buf);

	return ret;
}

int driver_nl80211_mon_ch_assign(void *drv_data, const char *ifname, char *buf, size_t buf_len)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_DFS, MTK_NL80211_VENDOR_ATTR_DFS_SET_ZERO_WAIT,
				     buf, buf_len);
	if (ret != 0)
		err(DEBUG_CAT_NL80211, "send driver_nl80211_mon_ch_assign failed\n");

	return ret;
}

#endif
#endif

int driver_nl80211_get_wdev(void *drv_data, const char *ifname, char *buf, size_t buf_len)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_get_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_GET_CAP,
				     MTK_NL80211_VENDOR_ATTR_GET_CAP_INFO_WDEV, buf, (size_t *)&buf_len);
	if (ret != 0)
		err(DEBUG_CAT_NL80211, "get wdev failed\n");

	return ret;
}

#ifdef DFS_CAC_R2
int driver_nl80211_get_cac_capability(void *drv_data, const char *ifname, char *buf, size_t buf_len)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_get_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_GET_CAP,
				     MTK_NL80211_VENDOR_ATTR_GET_CAP_INFO_CAC_CAP, buf, (size_t *)&buf_len);
	if (ret != 0)
		err(DEBUG_CAT_NL80211, "send misc_cap failed\n");

	return ret;
}

int driver_nl80211_get_avail_channel(void *drv_data, const char *ifname, char *buf, size_t buf_len)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_get_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_DFS, MTK_NL80211_VENDOR_ATTR_DFS_GET_ZERO_WAIT,
				     buf, (size_t *)&buf_len);
	if (ret != 0)
		err(DEBUG_CAT_NL80211, "send misc_cap failed\n");

	return ret;
}
#endif /* DFS_CAC_R2 */

static int driver_nl80211_get_misc_cap(void *drv_data, const char *ifname, char *buf, size_t *buf_len)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_get_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_GET_CAP,
				     MTK_NL80211_VENDOR_ATTR_GET_CAP_INFO_MISC_CAP, buf, buf_len);
	if (ret != 0)
		err(DEBUG_CAT_NL80211, "send misc_cap failed\n");

	return ret;
}

static int driver_nl80211_get_ht_cap(void *drv_data, const char *ifname, char *buf, size_t *buf_len)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_get_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_GET_CAP,
				     MTK_NL80211_VENDOR_ATTR_GET_CAP_INFO_HT_CAP, buf, buf_len);
	if (ret != 0)
		err(DEBUG_CAT_NL80211, "send ht_cap failed\n");

	return ret;
}

static int driver_nl80211_get_vht_cap(void *drv_data, const char *ifname, char *buf, size_t *buf_len)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_get_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_GET_CAP,
				     MTK_NL80211_VENDOR_ATTR_GET_CAP_INFO_VHT_CAP, buf, buf_len);
	if (ret != 0)
		err(DEBUG_CAT_NL80211, "send vht_cap failed\n");

	return ret;
}

static int driver_nl80211_get_he_cap(void *drv_data, const char *ifname, char *buf, size_t *buf_len)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_get_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_GET_CAP,
				     MTK_NL80211_VENDOR_ATTR_GET_CAP_INFO_HE_CAP, buf, buf_len);
	if (ret != 0)
		err(DEBUG_CAT_NL80211, "send he_cap failed\n");

	return ret;
}
#ifdef MAP_EHT_SUPPORT
static int driver_nl80211_get_eht_cap(void *drv_data, const char *ifname, char *buf, size_t *buf_len)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_get_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_GET_CAP,
				     MTK_NL80211_VENDOR_ATTR_GET_CAP_INFO_EHT_CAP, buf, buf_len);
	if (ret != 0)
		err(DEBUG_CAT_NL80211, "send eht_cap failed\n");

	return ret;
}
#endif
#ifdef MTK_MLO_MAP_SUPPORT
static int driver_nl80211_get_mlo_cap(void *drv_data, const char *ifname, char *buf, size_t *buf_len)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_get_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_GET_CAP,
				     MTK_NL80211_VENDOR_ATTR_GET_CAP_INFO_MLO_CAP, buf, buf_len);
	if (ret != 0)
		err(DEBUG_CAT_NL80211, "send mlo_cap failed\n");

	return ret;
}
#endif

static int driver_nl80211_get_chan_list(void *drv_data, const char *ifname, char *buf, size_t *buf_len)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_get_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_GET_RUNTIME_INFO,
				     MTK_NL80211_VENDOR_ATTR_GET_RUNTIME_INFO_GET_CHAN_LIST, buf, buf_len);
	if (ret != 0)
		err(DEBUG_CAT_NL80211, "send chan_list failed\n");

	return ret;
}

static int driver_nl80211_get_op_class(void *drv_data, const char *ifname, char *buf, size_t *buf_len)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_get_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_GET_RUNTIME_INFO,
				     MTK_NL80211_VENDOR_ATTR_GET_RUNTIME_INFO_GET_OP_CLASS, buf, buf_len);
	if (ret != 0)
		err(DEBUG_CAT_NL80211, "send op_class failed\n");

	return ret;
}

static int driver_nl80211_get_bss_info(void *drv_data, const char *ifname, char *buf, size_t *buf_len)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_get_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_GET_RUNTIME_INFO,
				     MTK_NL80211_VENDOR_ATTR_GET_RUNTIME_INFO_GET_BSS_INFO, buf, buf_len);
	if (ret != 0)
		err(DEBUG_CAT_NL80211, "send get_bss_info failed\n");

	return ret;
}

static int driver_nl80211_get_ap_metrics(void *drv_data, const char *ifname, char *buf, size_t *buf_len)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_get_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_GET_STATISTIC,
				     MTK_NL80211_VENDOR_ATTR_GET_AP_METRICS, buf, buf_len);
	if (ret != 0)
		err(DEBUG_CAT_NL80211, "send ap_metrics failed\n");

	return ret;
}

static int driver_nl80211_off_ch_scan_req(void *drv_data, const char *ifname, const char *scan_msg, size_t msg_len)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_OFFCHANNEL_INFO,
				     MTK_NL80211_VENDOR_ATTR_SUBCMD_OFF_CHANNEL_INFO, (char *)scan_msg, msg_len);
	if (ret != 0)
		err(DEBUG_CAT_NL80211, "send driver_nl80211_off_ch_scan_req failed\n");

	return ret;
}

static int driver_nl80211_get_nop_list(void *drv_data, const char *ifname, char *buf, size_t *buf_len)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_get_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_GET_RUNTIME_INFO,
				     MTK_NL80211_VENDOR_ATTR_GET_RUNTIME_INFO_GET_NOP_CHANNEL_LIST, buf, buf_len);
	if (ret != 0)
		err(DEBUG_CAT_NL80211, "send get_nop_list failed\n");

	return ret;
}

int driver_nl80211_get_chip_id(void *drv_data, const char *ifname, char *buf, size_t *buf_len)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_get_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_GET_STATIC_INFO,
				     MTK_NL80211_VENDOR_ATTR_GET_STATIC_INFO_CHIP_ID, buf, buf_len);
	if (ret != 0)
		err(DEBUG_CAT_NL80211, "send get_chip_id failed\n");

	return ret;
}

int driver_nl80211_get_max_sta_num(void *drv_data, const char *ifname, char *buf, size_t *buf_len)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_get_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_GET_RUNTIME_INFO,
				     MTK_NL80211_VENDOR_ATTR_GET_RUNTIME_INFO_GET_MAX_NUM_OF_STA, buf, buf_len);
	if (ret != 0)
		err(DEBUG_CAT_NL80211, "send max_sta_num failed\n");

	return ret;
}

static int driver_nl80211_send_action_frm(unsigned short sub_cmd_id, void *drv_data, const char *ifname, unsigned int chan,
					  unsigned int wait_time, const u8 *dst, const u8 *src, const u8 *bssid, const u8 *data,
					  size_t data_len, u16 seq_no, int no_cck)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	char *buf;
	size_t len = 0;
	struct action_frm_data *req_data;

	len = sizeof(*req_data) + data_len;
	buf = os_zalloc(len);

	if (!buf) {
		err(DEBUG_CAT_NL80211, "Not available memory\n");
		return -1;
	}

	req_data = (struct action_frm_data *)buf;

	os_memcpy(req_data->destination_addr, dst, MAC_ADDR_LEN);
	os_memcpy(req_data->transmitter_addr, src, MAC_ADDR_LEN);
	os_memcpy(req_data->bssid, bssid, MAC_ADDR_LEN);
	debug(DEBUG_CAT_NL80211, "da = " MACSTR "\033[0m\n", MAC2STR(req_data->destination_addr));
	debug(DEBUG_CAT_NL80211, "ta = " MACSTR "\033[0m\n", MAC2STR(req_data->transmitter_addr));
	debug(DEBUG_CAT_NL80211, "bssid = " MACSTR "\033[0m\n", MAC2STR(req_data->bssid));

	req_data->frm_len = data_len;
	req_data->no_cck = no_cck;
	req_data->wait_time = wait_time;

	req_data->chan = chan;
	req_data->seq_no = seq_no;
	os_memcpy(req_data->frm, data, data_len);

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_SET_ACTION, sub_cmd_id, buf, len);

	os_free(buf);

	return ret;
}

static int driver_nl80211_cancel_roc(void *drv_data, const char *ifname)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	char *buf;
	size_t len = 0;

	buf = os_zalloc(len);

	if (!buf) {
		err(DEBUG_CAT_NL80211, "Not available memory\n");
		return -1;
	}
	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
				     MTK_NL80211_VENDOR_ATTR_EASYMESH_CANCEL_ROC, buf, len);

	os_free(buf);

	return ret;
}

static int driver_nl80211_start_roc(void *drv_data, const char *ifname, unsigned int chan,
			unsigned int wait_time)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	char *buf;
	size_t len = 0;
	struct roc_req *req_data;

	len = sizeof(*req_data);
	buf = os_zalloc(len);

	if (!buf) {
		err(DEBUG_CAT_NL80211, "Not available memory\n");
		return -1;
	}

	req_data = (struct roc_req *)buf;

	req_data->chan = chan;
	req_data->wait_time = wait_time;
	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
				MTK_NL80211_VENDOR_ATTR_EASYMESH_START_ROC, buf, len);

	os_free(buf);

	return ret;
}

static int driver_nl80211_get_tx_pwr(void *drv_data, const char *ifname, char *buf, size_t *buf_len)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_get_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_GET_STATISTIC, MTK_NL80211_VENDOR_ATTR_GET_TX_PWR,
				     buf, buf_len);
	if (ret != 0)
		err(DEBUG_CAT_NL80211, "send get_tx_pwr failed\n");

	return ret;
}

#ifdef DPP_SUPPORT
int driver_nl80211_get_dpp_frame(void *drv_data, const char *ifname, char *frame, size_t length)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_get_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
				     MTK_NL80211_VENDOR_ATTR_EASYMESH_GET_DPP_FRAME, frame, (size_t *)&length);

	return ret;
}
#endif /* DPP_SUPPORT */

int driver_nl80211_get_assoc_req_frame(void *drv_data, const char *ifname, char *assoc_data, size_t length)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_get_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
				     MTK_NL80211_VENDOR_ATTR_EASYMESH_GET_ASSOC_REQ_FRAME, assoc_data, (size_t *)&length);

	return ret;
}

#ifdef QOS_R1
int driver_nl80211_qos_send_up_tuple_expired(void *drv_data, const char *ifname, char *buf, u32 buflen)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_QOS,
				     MTK_NL80211_VENDOR_ATTR_QOS_UP_TUPLE_EXPIRED_NOTIFY, buf, buflen);

	return ret;
}

#ifdef QOS_R2
static int driver_nl80211_get_pmk_by_peermac(void *drv_data, const char *ifname, char *buf, int *length)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_get_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_QOS, MTK_NL80211_VENDOR_ATTR_GET_PMK_BY_PEER_MAC,
				     buf, (size_t *)length);

	return ret;
}
#endif
#ifdef QOS_R3
int driver_nl80211_set_qos_characteristics_ie(void *drv_data, const char *ifname, char *buf, u32 buflen)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_QOS,
				     MTK_NL80211_VENDOR_ATTR_QOS_CHARATERISTICS_IE, buf, buflen);

	return ret;
}
#endif
#endif

#ifdef EPCS_SUPPORT
int driver_nl80211_sync_epcs_state(void *drv_data, const char *ifname, char *buf, u32 buflen)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_QOS,
				     MTK_NL80211_VENDOR_ATTR_EPCS_STATE_SYNC, buf, buflen);

	return ret;
}
#endif

#ifdef MAP_R5
int driver_nl80211_reset_dscp2up_table(void *drv_data, const char *ifname, char reset)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
					MTK_NL80211_VENDOR_ATTR_EASYMESH_RESET_DSCP2UP_TABLE, &reset, sizeof(reset));

	return ret;
}
#endif

#ifdef MAP_R3_WF6
static int driver_nl80211_get_wf6_cap(void *drv_data, const char *ifname, char *buf, size_t *buf_len)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_get_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_GET_CAP,
				     MTK_NL80211_VENDOR_ATTR_GET_CAP_INFO_WF6_CAPABILITY, buf, buf_len);

	return ret;
}
#endif /*MAP_R3_WF6*/

#ifdef MAP_R4_SPT
static int driver_nl80211_get_spt_reuse_req(void *drv_data, const char *ifname, char *buf,
							size_t *buf_len)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_get_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
				     MTK_NL80211_VENDOR_ATTR_GET_SPT_REUSE_REQ, buf, buf_len);

	return ret;
}

#ifdef MAP_R6
static int driver_nl80211_set_no_bcn(void *drv_data, const char *ifname, char enable)
{
	int ret;
	char *buf = &enable;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_SET_AP_BSS,
			MTK_NL80211_VENDOR_ATTR_AP_NO_BCN, buf, sizeof(enable));
	return ret;
}
#endif /* MAP_R6 */

static int driver_nl80211_set_bss_color(void *drv_data, const char *ifname, char *buf,
		size_t buf_len)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_SET_AP_BSS,
			MTK_NL80211_VENDOR_ATTR_SET_AP_BSS_COLOR, buf, buf_len);
	return ret;
}

static int driver_nl80211_set_sr_enable(void *drv_data, const char *ifname, char enable)
{
	int ret;
	char *buf = &enable;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
			MTK_NL80211_VENDOR_ATTR_EASYMESH_SR_ENABLE, buf, sizeof(enable));
	return ret;
}

static int driver_nl80211_set_bh_bitmap(void *drv_data, const char *ifname, char *buf,
		size_t buf_len)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
			MTK_NL80211_VENDOR_ATTR_EASYMESH_SET_BH_SR_BITMAP, buf, buf_len);
	return ret;
}
#endif

#ifdef MAP_R3
static int driver_nl80211_reset_cce_ie(void *drv_data, const char *ifname)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	char *buf;
	size_t len = 0;

	buf = os_zalloc(len);

	if (!buf) {
		err(DEBUG_CAT_NL80211, "Not available memory\n");
		return -1;
	}
	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
				     MTK_NL80211_VENDOR_ATTR_EASYMESH_DEL_CCE_IE, buf, len);

	os_free(buf);

	return ret;
}

static int driver_nl80211_agnt_dpp_uri(void *drv_data, const char *ifname, char *uri)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	char *buf = NULL;
	size_t len = 0;
#ifdef MTK_HOSTAPD_SUPPORT
	struct wifi_app *wapp;
#endif /* MTK_HOSTAPD_SUPPORT */

	if (uri) {
		len = os_strlen(uri);
		buf = os_zalloc(len + 1);

		if (!buf) {
			err(DEBUG_CAT_NL80211, "Not available memory\n");
			return -1;
		}

		os_memcpy(buf, uri, len);
		buf[len] = '\0';
	} else
		len = 0;

#ifdef MTK_HOSTAPD_SUPPORT
	if (!drv_nl80211_data) {
		err(DEBUG_CAT_NL80211, "invalid drv_data\n");
		if (buf) {
			os_free(buf);
			buf = NULL;
		}
		return -1;
	}

	wapp = drv_nl80211_data->priv;
	if (!wapp) {
		err(DEBUG_CAT_NL80211, "invalid wapp\n");
		if (buf) {
			os_free(buf);
			buf = NULL;
		}
		return -1;
	}

#ifdef WPACTRL_SUPPORT
	ret = wpactrl_cmd_set_dpp_uri(wapp->wpactrl_supplicant_ctx, ifname, (const uint8_t *)buf, len);
	if (ret != 0) {
		err(DEBUG_CAT_NL80211, "wpactrl_cmd_set_dpp_uri failed\n");
		if (buf) {
			os_free(buf);
			buf = NULL;
		}
		return ret;
	}
#endif /* WPACTRL_SUPPORT */
#else
	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
				     MTK_NL80211_VENDOR_ATTR_EASYMESH_R3_DPP_URI, buf, len);
#endif /* MTK_HOSTAPD_SUPPORT */

	os_free(buf);

	return ret;
}

static int driver_nl80211_set_1905_sec(void *drv_data, const char *ifname, const u8 flag)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
#ifdef MTK_HOSTAPD_SUPPORT
	struct wifi_app *wapp;
#else
	char *buf;
	size_t len = 1;
#endif /* MTK_HOSTAPD_SUPPORT */

#ifdef MTK_HOSTAPD_SUPPORT
	if (!drv_nl80211_data) {
		err(DEBUG_CAT_NL80211, "invalid drv_data\n");
		return -1;
	}

	wapp = drv_nl80211_data->priv;
	if (!wapp) {
		err(DEBUG_CAT_NL80211, "invalid wapp\n");
		return -1;
	}

#ifdef WPACTRL_SUPPORT
	ret = wpactrl_cmd_set_map_sec(wapp->wpactrl_hostapd_ctx, ifname, flag);
	if (ret != 0) {
		err(DEBUG_CAT_NL80211, "wpactrl_cmd_set_map_sec failed\n");
		return ret;
	}
#endif /* WPACTRL_SUPPORT */
#else
	buf = os_zalloc(len);

	if (!buf) {
		err(DEBUG_CAT_NL80211, "Not available memory\n");
		return -1;
	}

	*buf = flag;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
				     MTK_NL80211_VENDOR_ATTR_EASYMESH_R3_1905_SEC_ENABLED, buf, len);

	os_free(buf);
#endif /* MTK_HOSTAPD_SUPPORT */

	return ret;
}

static int driver_nl80211_set_onboarding_type(void *drv_data, const char *ifname, const u8 flag)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	char *buf;
	size_t len = 1;

	buf = os_zalloc(len);

	if (!buf) {
		err(DEBUG_CAT_NL80211, "Not available memory\n");
		return -1;
	}

	*buf = flag;
	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
				     MTK_NL80211_VENDOR_ATTR_EASYMESH_R3_ONBOARDING_TYPE, buf, len);

	os_free(buf);

	return ret;
}
#endif /* MAP_R3 */

#ifdef DPP_SUPPORT
static int driver_nl80211_set_pmk(void *drv_data, const char *ifname, const u8 *pmk, size_t pmk_len, const u8 *pmkid,
				  const u8 *authenticator_addr, const u8 *supplicant_addr, int session_timeout, int akmp, u8 *ssid,
				  size_t ssid_len)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	char *buf;
	size_t len = 0;
	struct pmk_req *req_data;

	len = sizeof(*req_data);
	buf = os_zalloc(len);

	if (!buf) {
		err(DEBUG_CAT_NL80211, "Not available memory\n");
		return -1;
	}

	req_data = (struct pmk_req *)buf;

	req_data->pmk_len = pmk_len;
	os_memcpy(req_data->pmk, pmk, LEN_PMK);
	os_memcpy(req_data->pmkid, pmkid, LEN_PMKID);
	os_memcpy(req_data->authenticator_addr, authenticator_addr, 6);
	os_memcpy(req_data->supplicant_addr, supplicant_addr, 6);
	req_data->timeout = session_timeout;
	req_data->akmp = akmp;
	os_memcpy(req_data->ssid, ssid, ssid_len);
	req_data->ssidlen = ssid_len;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH, MTK_NL80211_VENDOR_ATTR_EASYMESH_SET_PMK,
				     buf, len);

	os_free(buf);

	return ret;
}
#endif /*DPP_SUPPORT*/

static int driver_nl80211_set_air_mnt_en(void *drv_data, const char *ifname, unsigned char flag)
{
	int ret;
	char *buf;
	size_t len = 1;

	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	buf = os_zalloc(len);

	if (!buf) {
		err(DEBUG_CAT_NL80211, "Not available memory\n");
		return -1;
	}

	*buf = flag;
	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_SET_AP_MONITOR,
			MTK_NL80211_VENDOR_ATTR_AP_MONITOR_ENABLE, buf, len);

	os_free(buf);

	return ret;
}

static int driver_nl80211_set_air_mnt_rule(void *drv_data, const char *ifname, const char *buf,
		size_t buf_len)
{
	int ret;
	unsigned int val_tmp[AIR_MONITOR_RULE_SIZE] = {0};
	char monitor_rule[AIR_MONITOR_RULE_SIZE] = {0};
	unsigned char i;

	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;


	//ret = sscanf(buf, "%d:%d:%d", &val_tmp[0], &val_tmp[1], &val_tmp[2]);
	//if ((ret != AIR_MONITOR_RULE_SIZE) || (ret == EOF)) {
	//	err(DEBUG_CAT_NL80211, "sscanf failed with ret %d\n", ret);
	//	return -1;
       //}

	val_tmp[0] = (int)buf[0] - '0';
	val_tmp[1] = (int)buf[2] - '0';
	val_tmp[2] = (int)buf[4] - '0';

	for (i = 0; i < AIR_MONITOR_RULE_SIZE; i++) {
		if (val_tmp[i] > 1)
			return -1;
		monitor_rule[i] = (char)val_tmp[i];
	}

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_SET_AP_MONITOR,
			MTK_NL80211_VENDOR_ATTR_AP_MONITOR_RULE, monitor_rule, sizeof(monitor_rule));
	return ret;
}

static int driver_nl80211_set_air_mnt_sta_id(void *drv_data, const char *ifname, const u8 id,
		const char *sta_mac)
{
	int ret;
	char *buf;
	size_t len = 0;
	struct mnt_sta *req_sta;

	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	len = sizeof(*req_sta);
	buf = os_zalloc(len);

	if (!buf) {
		err(DEBUG_CAT_NL80211, "Not available memory\n");
		return -1;
	}

	req_sta = (struct mnt_sta *)buf;

	os_memcpy(req_sta->sta_mac, sta_mac, MAC_ADDR_LEN);
	req_sta->sta_id = id;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_SET_AP_MONITOR,
			MTK_NL80211_VENDOR_ATTR_AP_MONITOR_STA_ID, buf, len);
	os_free(buf);
	return ret;
}

static int driver_nl80211_set_air_mnt_max_pkt(void *drv_data, const char *ifname, unsigned int pkt_num)
{
	int ret;
	char *buf;
	size_t len = 0;
	struct mnt_max_pkt *max_pkt;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	len = sizeof(*max_pkt);
	buf = os_zalloc(len);

	if (!buf) {
		err(DEBUG_CAT_NL80211, "Not available memory\n");
		return -1;
	}

	max_pkt = (struct mnt_max_pkt *)buf;

	max_pkt->pkt_number = pkt_num;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_SET_AP_MONITOR,
			MTK_NL80211_VENDOR_ATTR_AP_MONITOR_MAX_PKT, buf, len);

	os_free(buf);

	return ret;
}

static int driver_nl80211_get_air_mnt_result(void *drv_data, const char *ifname, char *buf,
							size_t *buf_len)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_get_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_SET_AP_MONITOR,
			MTK_NL80211_VENDOR_ATTR_AP_MONITOR_GET_RESULT, buf, buf_len);
	return ret;
}

static int driver_nl80211_set_map_ch(void *drv_data, const char *ifname, const u8 ch
#ifdef MAP_R2
		, const u8 cac_req, const u8 dev_role
#endif /* MAP_R2 */
)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	char *buf;
	size_t len = 0;
	struct map_ch *req_ch;

	len = sizeof(*req_ch);
	buf = os_zalloc(len);
	if (!buf) {
		err(DEBUG_CAT_NL80211, "Not available memory\n");
		return -1;
	}

	req_ch = (struct map_ch *)buf;

	req_ch->ch_num = ch;
#ifdef MAP_R2
	req_ch->cac_req = cac_req;
	req_ch->map_dev_role = dev_role;
#endif /* MAP_R2 */

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
		MTK_NL80211_VENDOR_ATTR_EASYMESH_SET_MAP_CH, buf, len);

	os_free(buf);
	return ret;
}
int driver_nl80211_create_mld_group(void *drv_data, const char *ifname, u8 mld_group_idx, const u8 *mld_addr, u8 mld_type)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	char *buf;
	size_t len = 0;
	struct mld_group *req_mld;

	len = sizeof(*req_mld);
	buf = os_zalloc(len);
	if (!buf) {
		err(DEBUG_CAT_NL80211, "Not available memory\n");
		return -1;
	}

	req_mld = (struct mld_group *)buf;

	req_mld->mld_group_idx = mld_group_idx;
	os_memcpy(req_mld->mld_addr, mld_addr, MAC_ADDR_LEN);
	req_mld->mld_type = mld_type;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
		MTK_NL80211_VENDOR_ATTR_EASYMESH_SET_MLD_CREATE, buf, len);

	os_free(buf);
	return ret;
}

int driver_nl80211_delete_mld_group(void *drv_data, const char *ifname, u8 mld_id)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
			MTK_NL80211_VENDOR_ATTR_EASYMESH_SET_MLD_DESTROY, (char *)&mld_id, sizeof(mld_id));
	return ret;
}

int driver_nl80211_mld_link_add(void *drv_data, const char *ifname, u8 mld_id, u16 is_reconfig)
{
	int ret;
	char *buf = NULL;
	size_t len = 0;
	struct mld_add_link *req_mld;

	len = sizeof(*req_mld);
	buf = os_zalloc(len);

	if (!buf) {
		err(DEBUG_CAT_NL80211, "zalloc fail\n");
		return -1;
	}
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	req_mld = (struct mld_add_link *)buf;
	req_mld->mld_id = mld_id;
#ifdef MAP_R6
	req_mld->is_reconfig = is_reconfig;
#endif /* MAP_R6 */

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
			MTK_NL80211_VENDOR_ATTR_EASYMESH_SET_MLD_LINK_ADD, buf, len);

	os_free(buf);
	return ret;
}

int driver_nl80211_mld_link_transfer(void *drv_data, const char *ifname, u8 mld_id)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
			MTK_NL80211_VENDOR_ATTR_EASYMESH_SET_MLD_LINK_TRANSFER, (char *)&mld_id, sizeof(mld_id));
	return ret;
}

int driver_nl80211_mld_link_del(void *drv_data, const char *ifname, u8 mld_id)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
			MTK_NL80211_VENDOR_ATTR_EASYMESH_SET_MLD_LINK_DEL, (char *)&mld_id, sizeof(mld_id));
	return ret;
}

#ifdef MAP_R6
int driver_nl80211_mld_link_reconfig(void *drv_data, const char *ifname, u8 mld_id, u16 reconfig_to)
{
	int ret;
	char *buf;
	size_t len = 0;
	struct mld_reconf *req_mld;

	len = sizeof(*req_mld);
	buf = os_zalloc(len);
	if (!buf) {
		err(DEBUG_CAT_NL80211, "Not available memory\n");
		return -1;
	}

	req_mld = (struct mld_reconf *)buf;
	req_mld->mld_id = mld_id;
	req_mld->reconfig_to = reconfig_to;

	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
			MTK_NL80211_VENDOR_ATTR_EASYMESH_SET_MLD_LINK_RECONF, buf, len);
	os_free(buf);
	return ret;
}
#endif /* MAP_R6 */

int driver_nl80211_set_static_punc_dscb(void *drv_data, const char *ifname, u16 punc_bitmap)
{
	int ret;

	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_SET_ACTION,
		MTK_NL80211_VENDOR_ATTR_SET_ACTION_STATIC_PUNCTURE_BITMAP, (char *)&punc_bitmap, sizeof(punc_bitmap));
	return ret;
}

#ifdef CSA_BAND_SUPPORT
int driver_nl80211_set_2g_csa_support(void *drv_data, const char *ifname, u8 csa_2g_support)
{
	int ret;
	u8 csa_2g = csa_2g_support;

	err(DEBUG_CAT_NL80211, "Value of CSA = %d", csa_2g);
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_SET_AP_RADIO,
		MTK_NL80211_VENDOR_ATTR_AP_2G_CSA_SUPPORT, (char *)&csa_2g, sizeof(csa_2g));
	return ret;
}

int driver_nl80211_set_csa_support(void *drv_data, const char *ifname, u8 csa_support)
{
	int ret;
	u8 csa = csa_support;

	err(DEBUG_CAT_NL80211, "Value of CSA = %d", csa);
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_SET_AP_RADIO,
		MTK_NL80211_VENDOR_ATTR_AP_CSA_SUPPORT, (char *)&csa, sizeof(csa));
	return ret;
}
#endif

int driver_nl80211_send_t2lm_request(void *drv_data, const char *ifname, char *buf, u32 buflen)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_SET_ACTION,
		MTK_NL80211_VENDOR_ATTR_SET_ACTION_SEND_T2LM_REQUEST, buf, buflen);

	return ret;
}

static int driver_nl80211_set_map_en(void *drv_data, const char *ifname, const u8 map_en)
{
	int ret;
	char *buf;
	size_t len = 1;

	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	buf = os_zalloc(len);
	if (!buf) {
		err(DEBUG_CAT_NL80211, "Not available memory\n");
		return -1;
	}

	*buf = map_en;
	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
		MTK_NL80211_VENDOR_ATTR_EASYMESH_SET_MAP_ENABLE, buf, len);

	os_free(buf);

	return ret;
}

static int driver_nl80211_set_ap_fhbss(void *drv_data, const char *ifname, const u8 fh_en)
{
	int ret;
	char *buf;
	size_t len = 1;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	buf = os_zalloc(len);
	if (!buf) {
		err(DEBUG_CAT_MISC, "alloc buf fail; size=%zu\n", len);
		return -1;
	}

	*buf = fh_en;
	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
		MTK_NL80211_VENDOR_ATTR_EASYMESH_SET_FHBSS, buf, len);

	os_free(buf);

	return ret;
}

static int driver_nl80211_set_ap_bhbss(void *drv_data, const char *ifname, const u8 bh_en)
{
	int ret;
	char *buf;
	size_t len = 1;

	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	buf = os_zalloc(len);
	if (!buf) {
		err(DEBUG_CAT_NL80211, "Not available memory\n");
		return -1;
	}

	*buf = bh_en;
	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
		MTK_NL80211_VENDOR_ATTR_EASYMESH_SET_BHBSS, buf, len);

	os_free(buf);

	return ret;
}

#ifdef WPACTRL_SUPPORT
#ifdef MTK_HOSTAPD_SUPPORT
static int driver_nl80211_set_dpp_peermac(void *drv_data, const char *ifname, struct dpp_authentication *auth)
{
	int ret;
	char sta_mac[MAC_ADDR_LEN] = {0};

	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	os_memcpy(sta_mac, auth->peer_mac_addr, MAC_ADDR_LEN);

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
		MTK_NL80211_VENDOR_ATTR_EASYMESH_SET_DPP_STAMAC, sta_mac, MAC_ADDR_LEN);

	return ret;
}


static int driver_nl80211_set_ap_pmk_hapd(void *drv_data, const char *ifname,
			const u8 *sta_mac, const u8 *pmkid, const u8 *pmk,
			size_t pmk_len, int expiry, int akmp)
{
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	struct wifi_app *wapp;
	int ret = -1;

	if (!drv_nl80211_data) {
		err(DEBUG_CAT_NL80211, "invalid drv_data\n");
		return ret;
	}

	wapp = drv_nl80211_data->priv;
	if (!wapp) {
		err(DEBUG_CAT_NL80211, "invalid wapp\n");
		return ret;
	}

	ret = wpactrl_cmd_set_ap_pmk(wapp->wpactrl_hostapd_ctx, ifname, sta_mac, pmkid,
			pmk, pmk_len, expiry, akmp);

	if (ret != 0) {
		err(DEBUG_CAT_NL80211, "wpactrl_cmd_set_ap_pmk failed\n");
		return ret;
	}

	return 0;
}

static int driver_nl80211_set_sta_pmk_supp(void *drv_data, const char *ifname,
			const u8 nw_id, const u8 *bssid, const u8 *pmkid,
			const u8 *pmk, size_t pmk_len, int reauth,
			int expiry, int akmp, int opportunistic)
{
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	struct wifi_app *wapp;
	int ret = -1;

	if (!drv_nl80211_data) {
		err(DEBUG_CAT_NL80211, "invalid drv_data\n");
		return ret;
	}

	wapp = drv_nl80211_data->priv;
	if (!wapp) {
		err(DEBUG_CAT_NL80211, "invalid wapp\n");
		return ret;
	}

	ret = wpactrl_cmd_set_sta_pmk(wapp->wpactrl_supplicant_ctx, ifname, nw_id, bssid,
		pmkid, pmk, pmk_len, reauth,
		expiry, akmp, opportunistic);

	if (ret != 0)
		err(DEBUG_CAT_NL80211, "wpactrl_cmd_set_sta_pmk failed\n");

	return 0;

}

static int driver_nl80211_send_get_pmk(void *drv_data, const char *ifname, char *sta_mac, char *buf)
{
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	struct wifi_app *wapp;
	int ret;

	if (!drv_nl80211_data) {
		err(DEBUG_CAT_NL80211, "invalid drv_data\n");
		return -1;
	}

	wapp = drv_nl80211_data->priv;
	if (!wapp) {
		err(DEBUG_CAT_NL80211, "invalid wapp\n");
		return -1;
	}

	ret = wpactrl_cmd_get_pmk(wapp->wpactrl_hostapd_ctx, ifname, (uint8_t *)sta_mac, (uint8_t *)buf);
	if (ret != 0) {
		err(DEBUG_CAT_NL80211, "wpactrl_cmd_get_pmk failed\n");
		return ret;
	}

	return 0;
}

#ifdef MAP_R6 /* GERNERIC_R6 */
static int driver_nl80211_set_network_pairwise(void *drv_data, const char *ifname, int network_id, const char *pairwise)
{
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	struct wifi_app *wapp;
	int ret;


	if (!drv_nl80211_data) {
		err(DEBUG_CAT_NL80211, "invalid drv_data\n");
		return -1;
	}

	wapp = drv_nl80211_data->priv;
	if (!wapp) {
		err(DEBUG_CAT_NL80211, "invalid wapp\n");
		return -1;
	}

	ret = wpactrl_cmd_set_network_pairwise(wapp->wpactrl_supplicant_ctx, ifname, network_id, pairwise);
	if (ret != 0) {
		err(DEBUG_CAT_NL80211, "wpactrl_cmd_set_network_pairwise failed\n");
		return ret;
	}

	return 0;
}

static int driver_nl80211_set_network_group(void *drv_data, const char *ifname, int network_id, const char *grp)
{
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	struct wifi_app *wapp;
	int ret;


	if (!drv_nl80211_data) {
		err(DEBUG_CAT_NL80211, "invalid drv_data\n");
		return -1;
	}

	wapp = drv_nl80211_data->priv;
	if (!wapp) {
		err(DEBUG_CAT_NL80211, "invalid wapp\n");
		return -1;
	}

	ret = wpactrl_cmd_set_network_group(wapp->wpactrl_supplicant_ctx, ifname, network_id, grp);
	if (ret != 0) {
		err(DEBUG_CAT_NL80211, "wpactrl_cmd_set_network_group failed\n");
		return ret;
	}

	return 0;
}

static int driver_nl80211_set_network_grpmgmt(void *drv_data, const char *ifname, int network_id, const char *grpmgmt)
{
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	struct wifi_app *wapp;
	int ret;


	if (!drv_nl80211_data) {
		err(DEBUG_CAT_NL80211, "invalid drv_data\n");
		return -1;
	}

	wapp = drv_nl80211_data->priv;
	if (!wapp) {
		err(DEBUG_CAT_NL80211, "invalid wapp\n");
		return -1;
	}

	ret = wpactrl_cmd_set_network_grpmgmt(wapp->wpactrl_supplicant_ctx, ifname, network_id, grpmgmt);
	if (ret != 0) {
		err(DEBUG_CAT_NL80211, "wpactrl_cmd_set_network_grpmgmt failed\n");
		return ret;
	}

	return 0;
}

static int driver_nl80211_set_beacon_prot(void *drv_data, const char *ifname, int network_id, u8 bcn_prot)
{
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	struct wifi_app *wapp;
	int ret;


	if (!drv_nl80211_data) {
		err(DEBUG_CAT_NL80211, "invalid drv_data\n");
		return -1;
	}

	wapp = drv_nl80211_data->priv;
	if (!wapp) {
		err(DEBUG_CAT_NL80211, "invalid wapp\n");
		return -1;
	}

	ret = wpactrl_cmd_set_bcn_prot(wapp->wpactrl_supplicant_ctx, ifname, network_id, bcn_prot);
	if (ret != 0) {
		err(DEBUG_CAT_NL80211, "wpactrl_cmd_set_bcn_prot failed\n");
		return ret;
	}

	return 0;
}
#endif /* MAP_R6 */
#endif /* MTK_HOSTAPD_SUPPORT */
#endif /* WPACTRL_SUPPORT */

static int driver_nl80211_set_ap_v10converter(void *drv_data, const char *ifname, const u8 v_en)
{
	int ret;
	char *buf;
	size_t len = 1;

	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	buf = os_zalloc(len);
	if (!buf) {
		err(DEBUG_CAT_NL80211, "Not available memory\n");
		return -1;
	}

	*buf = v_en;
	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_SET_V10CONVERTER,
		MTK_NL80211_VENDOR_ATTR_SET_V10CONVERTER, buf, len);

	os_free(buf);

	return ret;
}

static int driver_nl80211_set_approxyrefresh(void *drv_data, const char *ifname, const u8 proxy_en)
{
	int ret;
	char *buf;
	size_t len = 1;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	buf = os_zalloc(len);
	if (!buf) {
		err(DEBUG_CAT_NL80211, "Not available memory\n");
		return -1;
	}

	*buf = proxy_en;
	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_SET_APPROXYREFRESH,
		MTK_NL80211_VENDOR_ATTR_SET_APPROXYREFRESH, buf, len);

	os_free(buf);

	return ret;
}

#ifdef WPACTRL_SUPPORT
static int driver_nl80211_set_enable(void *drv_data, const char *ifname)
{
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	struct wifi_app *wapp;
	int ret;

	if (!drv_nl80211_data) {
		err(DEBUG_CAT_NL80211, "invalid drv_data\n");
		return -1;
	}

	wapp = drv_nl80211_data->priv;
	if (!wapp) {
		err(DEBUG_CAT_NL80211, "invalid wapp\n");
		return -1;
	}

	ret = wpactrl_cmd_enable(wapp->wpactrl_hostapd_ctx, ifname);
	if (ret != 0) {
		err(DEBUG_CAT_NL80211, "wpactrl_cmd_enable failed\n");
		return ret;
	}

	return 0;
}

static int driver_nl80211_set_disable(void *drv_data, const char *ifname)
{
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	struct wifi_app *wapp;
	int ret;

	if (!drv_nl80211_data) {
		err(DEBUG_CAT_NL80211, "invalid drv_data\n");
		return -1;
	}

	wapp = drv_nl80211_data->priv;
	if (!wapp) {
		err(DEBUG_CAT_NL80211, "invalid wapp\n");
		return -1;
	}

	ret = wpactrl_cmd_disable(wapp->wpactrl_hostapd_ctx, ifname);
	if (ret != 0) {
		err(DEBUG_CAT_NL80211, "wpactrl_cmd_disable failed\n");
		return ret;
	}

	return 0;
}
static int driver_nl80211_set_intf_add(void *drv_data, const char *ifname, const char *ifname_prim)
{
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	struct wifi_app *wapp;
#ifdef EM_PLUS_SUPPORT
	struct wapp_dev *wdev;
	char value[128] = {0};
	char param[32] = {0};
	char def_ssid[64] = "default_ssid";
#endif /* EM_PLUS_SUPPORT */
	int ret;
	char bss_config_path[256] = {0};

	if (!drv_nl80211_data) {
		err(DEBUG_CAT_NL80211, "invalid drv_data\n");
		return -1;
	}

	wapp = drv_nl80211_data->priv;
	if (!wapp) {
		err(DEBUG_CAT_NL80211, "invalid wapp\n");
		return -1;
	}
	notice(DEBUG_CAT_NL80211, "ifname %s, prim %s", ifname, ifname_prim);

#ifdef EM_PLUS_SUPPORT
	char ifname_pri[32]  = {0};
	int res = 0;

	wdev = wapp_dev_list_lookup_by_ifname(wapp, ifname);
	if (!wdev) {
		err(DEBUG_CAT_NL80211, "wdev for ifname:%s not found\n", ifname);
		return -1;
	}

	hapd_extract_conf_file(wapp, wdev, bss_config_path);
	if (is_str_null(bss_config_path)) {
		err(DEBUG_CAT_NL80211, "invalid config file");
		return -1;
	}

	if (IS_OP_CLASS_24G(wdev->radio->opclass)) {
		res = os_snprintf(ifname_pri, sizeof(ifname_pri), "%s", "phy0");
		if (res < 0)
			err(DEBUG_CAT_NL80211, "os_printf error in macaddr\n");
		os_memcpy(ifname_pri, "phy0", sizeof("phy0"));
	} else if (IS_OP_CLASS_5G(wdev->radio->opclass)) {
		res = os_snprintf(ifname_pri, sizeof(ifname_pri), "%s", "phy1");
		if (res < 0)
			err(DEBUG_CAT_NL80211, "os_printf error in macaddr\n");
	} else if (IS_OP_CLASS_6G(wdev->radio->opclass)) {
		res = os_snprintf(ifname_pri, sizeof(ifname_pri), "%s", "phy2");
		if (res < 0)
			err(DEBUG_CAT_NL80211, "os_printf error in macaddr\n");
	} else {
		err(DEBUG_CAT_NL80211, DPP_MAP_PREX"Invalid band fail\n");
		return -1;
	}
	ifname_prim = ifname_pri;
	debug(DEBUG_CAT_NL80211, "hapd conf file: %s\n", bss_config_path);

	/*read ssid */
	ret = os_snprintf(param, sizeof(param), "ssid");
	if (os_snprintf_error(sizeof(param), ret)) {
		err(DEBUG_CAT_NL80211, "[%s] os_snprintf fail\n", __func__);
		return -1;
	}
	get_parameters(bss_config_path, param, value, NON_DRIVER_PARAM, sizeof(value));
	err(DEBUG_CAT_NL80211, "current SSID value:%s\n", value);
	if (value[0] == '\0') {
		set_parameters(bss_config_path, param, def_ssid, NON_DRIVER_PARAM);
		err(DEBUG_CAT_NL80211, "Modified SSID value:%s\n", def_ssid);
	}
#else
	ret = snprintf(bss_config_path, sizeof(bss_config_path), "/var/run/hostapd/hostapd-%s.conf", ifname);
	if (ret < 0) {
		err(DEBUG_CAT_NL80211, "snprintf failed");
		return -1;
	}
#endif /* EM_PLUS_SUPPORT */

	ret = wpactrl_cmd_intf_add(wapp->wpactrl_hostapd_ctx, ifname_prim, bss_config_path, NULL);
	if (ret != 0) {
		err(DEBUG_CAT_NL80211, "wpactrl_cmd_intf_add failed\n");
		return ret;
	}
	return 0;
}

static int driver_nl80211_set_intf_disable(void *drv_data, const char *ifname)
{
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	struct wifi_app *wapp;
	int ret;

	if (!drv_nl80211_data) {
		err(DEBUG_CAT_NL80211, "invalid drv_data\n");
		return -1;
	}

	wapp = drv_nl80211_data->priv;
	if (!wapp) {
		err(DEBUG_CAT_NL80211, "invalid wapp\n");
		return -1;
	}

	ret = wpactrl_cmd_intf_disable(wapp->wpactrl_hostapd_ctx, ifname);
	if (ret != 0) {
		err(DEBUG_CAT_NL80211, "wpactrl_cmd_intf_disable failed\n");
		return ret;
	}

	return 0;
}
static int driver_nl80211_set_BhAssocCtrl(void *drv_data, const char *ifname, char *buf, size_t *len)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	if (!buf) {
		err(DEBUG_CAT_NL80211, "Not available memory\n");
		return -1;
	}
	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
		MTK_NL80211_VENDOR_ATTR_EASYMESH_SET_BH_ASSOC_CTRL, buf, *len);

	os_free(buf);

	return ret;
}

static int driver_nl80211_send_sta_deauth(void *drv_data, const char *ifname, char *sta_mac)
{
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	struct wifi_app *wapp;
	int ret;

	if (!drv_nl80211_data) {
		err(DEBUG_CAT_NL80211, "invalid drv_data\n");
		return -1;
	}

	wapp = drv_nl80211_data->priv;
	if (!wapp) {
		err(DEBUG_CAT_NL80211, "invalid wapp\n");
		return -1;
	}

	ret = wpactrl_cmd_sta_deauth(wapp->wpactrl_hostapd_ctx, ifname, (uint8_t *)sta_mac);
	if (ret != 0) {
		err(DEBUG_CAT_NL80211, "wpactrl_cmd_sta_deauth failed\n");
		return ret;
	}

	return 0;
}

static int driver_nl80211_send_remove_network(void *drv_data, const char *ifname)
{
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	struct wifi_app *wapp;
	int ret;

	if (!drv_nl80211_data) {
		err(DEBUG_CAT_NL80211, "invalid drv_data\n");
		return -1;
	}

	wapp = drv_nl80211_data->priv;
	if (!wapp) {
		err(DEBUG_CAT_NL80211, "invalid wapp\n");
		return -1;
	}

	ret = wpactrl_cmd_remove_network(wapp->wpactrl_supplicant_ctx, ifname);
	if (ret != 0) {
		err(DEBUG_CAT_NL80211, "wpactrl_cmd_remove_network failed\n");
		return ret;
	}

	ret = wpactrl_cmd_set_autoscan_module(wapp->wpactrl_supplicant_ctx, ifname, WPACTRL_AUTOSCAN_NULL, 0, 0);
	if (ret != 0) {
		err(DEBUG_CAT_NL80211, "wpactrl_cmd_set_autoscan_module failed\n");
		return ret;
	}

	return 0;
}

static int driver_nl80211_set_hide_ssid(void *drv_data, const char *ifname, int enable)
{
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	struct wifi_app *wapp;
	int ret = 0;

	if (!drv_nl80211_data) {
		err(DEBUG_CAT_NL80211, "invalid drv_data\n");
		return -1;
	}

	wapp = drv_nl80211_data->priv;
	if (!wapp) {
		err(DEBUG_CAT_NL80211, "invalid wapp\n");
		return -1;
	}

/*	ret = wpactrl_cmd_hide_ssid(wdev->wpactrl_ctx, ifname, enable); */
	if (ret != 0) {
		err(DEBUG_CAT_NL80211, "wpactrl_cmd_hide_ssid failed\n");
		return ret;
	}
	return 0;
}

static int driver_nl80211_send_disable_network(void *drv_data, const char *ifname, int network_id)
{
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	struct wifi_app *wapp;
	int ret;

	if (!drv_nl80211_data) {
		err(DEBUG_CAT_NL80211, "invalid drv_data\n");
		return -1;
	}

	wapp = drv_nl80211_data->priv;
	if (!wapp) {
		err(DEBUG_CAT_NL80211, "invalid wapp\n");
		return -1;
	}

	ret = wpactrl_cmd_disable_network(wapp->wpactrl_supplicant_ctx, ifname, network_id);
	if (ret != 0) {
		err(DEBUG_CAT_NL80211, "wpactrl_cmd_disable_network failed\n");
		return ret;
	}

	return 0;
}

#ifdef MTK_HOSTAPD_SUPPORT
static int driver_nl80211_send_select_network(void *drv_data, const char *ifname, int network_id, int frequency)
{
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	struct wifi_app *wapp;
	int ret;

	if (!drv_nl80211_data) {
		err(DEBUG_CAT_NL80211, "invalid drv_data\n");
		return -1;
	}

	wapp = drv_nl80211_data->priv;
	if (!wapp) {
		err(DEBUG_CAT_NL80211, "invalid wapp\n");
		return -1;
	}

	ret = wpactrl_cmd_select_network(wapp->wpactrl_supplicant_ctx, ifname, network_id, frequency);
	if (ret != 0) {
		err(DEBUG_CAT_NL80211, "wpactrl_cmd_select_network failed\n");
		return ret;
	}

	return 0;
}

static int driver_nl80211_send_update_bridge(void *drv_data, const char *ifname,
			u8 update_flag, const char *br_name)
{
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	struct wifi_app *wapp;
	int ret = -1;

	if (!drv_nl80211_data) {
		err(DEBUG_CAT_NL80211, "invalid drv_data\n");
		return ret;
	}

	wapp = drv_nl80211_data->priv;
	if (!wapp) {
		err(DEBUG_CAT_NL80211, "invalid wapp\n");
		return ret;
	}

	ret = wpactrl_cmd_update_bridge_supplicant(wapp->wpactrl_supplicant_ctx, ifname,
			(uint8_t)update_flag, br_name);
	if (ret != 0) {
		err(DEBUG_CAT_NL80211, "wpactrl_cmd_update_bridge_supplicant failed\n");
		return ret;
	}

	return 0;
}

/* function to call wpactrl_cmd_bss_flush */
static int driver_nl80211_send_bss_flush(void *drv_data, const char *ifname)
{
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	struct wifi_app *wapp;
	int ret;

	if (!drv_nl80211_data) {
		err(DEBUG_CAT_NL80211, "invalid drv_data\n");
		return -1;
	}

	wapp = drv_nl80211_data->priv;
	if (!wapp) {
		err(DEBUG_CAT_NL80211, "invalid wapp\n");
		return -1;
	}

	/* Call wpactrl_cmd_bss_flush using wpa_supplicant context */
	ret = wpactrl_cmd_bss_flush(wapp->wpactrl_supplicant_ctx, ifname);
	if (ret != 0) {
		err(DEBUG_CAT_NL80211, "wpactrl_cmd_bss_flush failed\n");
		return ret;
	}

	return 0;
}
#endif /* MTK_HOSTAPD_SUPPORT */

static int driver_nl80211_send_enable_network(void *drv_data, const char *ifname, int network_id)
{
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	struct wifi_app *wapp;
	int ret;

	if (!drv_nl80211_data) {
		err(DEBUG_CAT_NL80211, "invalid drv_data\n");
		return -1;
	}

	wapp = drv_nl80211_data->priv;
	if (!wapp) {
		err(DEBUG_CAT_NL80211, "invalid wapp\n");
		return -1;
	}

	ret = wpactrl_cmd_enable_network(wapp->wpactrl_supplicant_ctx, ifname, network_id);
	if (ret != 0) {
		err(DEBUG_CAT_NL80211, "wpactrl_cmd_enable_network failed\n");
		return ret;
	}

	return 0;
}

static int driver_nl80211_set_network_bssid(void *drv_data, const char *ifname, int network_id, const char *bssid)
{
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	struct wifi_app *wapp;
	int ret;

	if (!drv_nl80211_data) {
		err(DEBUG_CAT_NL80211, "invalid drv_data\n");
		return -1;
	}

	wapp = drv_nl80211_data->priv;
	if (!wapp) {
		err(DEBUG_CAT_NL80211, "invalid wapp\n");
		return -1;
	}

	ret = wpactrl_cmd_set_network_bssid(wapp->wpactrl_supplicant_ctx, ifname, network_id, bssid);
	if (ret != 0) {
		err(DEBUG_CAT_NL80211, "wpactrl_cmd_set_network_bssid failed\n");
		return ret;
	}

	return 0;
}

static int driver_nl80211_send_add_network(void *drv_data, const char *ifname)
{
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	struct wifi_app *wapp;
	int ret;

	if (!drv_nl80211_data) {
		err(DEBUG_CAT_NL80211, "invalid drv_data\n");
		return -1;
	}

	wapp = drv_nl80211_data->priv;
	if (!wapp) {
		err(DEBUG_CAT_NL80211, "invalid wapp\n");
		return -1;
	}

	ret = wpactrl_cmd_add_network(wapp->wpactrl_supplicant_ctx, ifname);
	if (ret != 0) {
		err(DEBUG_CAT_NL80211, "wpactrl_cmd_add_network failed\n");
		return ret;
	}

	return ret;
}

static int driver_nl80211_set_network_key(void *drv_data, const char *ifname, int network_id, const char *key)
{
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	struct wifi_app *wapp;
	int ret;

	if (!drv_nl80211_data) {
		err(DEBUG_CAT_NL80211, "invalid drv_data\n");
		return -1;
	}

	wapp = drv_nl80211_data->priv;
	if (!wapp) {
		err(DEBUG_CAT_NL80211, "invalid wapp\n");
		return -1;
	}

	ret = wpactrl_cmd_add_network_key(wapp->wpactrl_supplicant_ctx, ifname, network_id, key);
	if (ret != 0) {
		err(DEBUG_CAT_NL80211, "wpactrl_cmd_add_network_key failed\n");
		return ret;
	}

	return 0;
}

static int driver_nl80211_set_network_keymgmt(void *drv_data, const char *ifname, int network_id, const char *keymgmt)
{
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	struct wifi_app *wapp;
	int ret;

	if (!drv_nl80211_data) {
		err(DEBUG_CAT_NL80211, "invalid drv_data\n");
		return -1;
	}

	wapp = drv_nl80211_data->priv;
	if (!wapp) {
		err(DEBUG_CAT_NL80211, "invalid wapp\n");
		return -1;
	}

	ret = wpactrl_cmd_set_keymgmt(wapp->wpactrl_supplicant_ctx, ifname, network_id, keymgmt);
	if (ret != 0) {
		err(DEBUG_CAT_NL80211, "wpactrl_cmd_set_keymgmt failed\n");
		return ret;
	}

	return 0;
}

static int driver_nl80211_set_sae_pwd(void *drv_data, const char *ifname, int network_id, const char *pwd)
{
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	struct wifi_app *wapp;
	int ret;

	if (!drv_nl80211_data) {
		err(DEBUG_CAT_NL80211, "invalid drv_data\n");
		return -1;
	}

	wapp = drv_nl80211_data->priv;
	if (!wapp) {
		err(DEBUG_CAT_NL80211, "invalid wapp\n");
		return -1;
	}

	ret = wpactrl_cmd_set_sae_pwd(wapp->wpactrl_supplicant_ctx, ifname, network_id, pwd);
	if (ret != 0) {
		err(DEBUG_CAT_NL80211, "wpactrl_cmd_set_sae_pwd failed\n");
		return ret;
	}

	return 0;
}

static int driver_nl80211_set_wep_key(void *drv_data, const char *ifname, int network_id, int key_idx, const char *key)
{
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	struct wifi_app *wapp;
	int ret;

	if (!drv_nl80211_data) {
		err(DEBUG_CAT_NL80211, "invalid drv_data\n");
		return -1;
	}

	wapp = drv_nl80211_data->priv;
	if (!wapp) {
		err(DEBUG_CAT_NL80211, "invalid wapp\n");
		return -1;
	}

	ret = wpactrl_cmd_set_wep_key(wapp->wpactrl_supplicant_ctx, ifname, network_id, key_idx, key);
	if (ret != 0) {
		err(DEBUG_CAT_NL80211, "wpactrl_cmd_set_wep_key failed\n");
		return ret;
	}
	return 0;
}

static int driver_nl80211_send_save_config(void *drv_data, const char *ifname)
{
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	struct wifi_app *wapp;
	int ret;

	if (!drv_nl80211_data) {
		err(DEBUG_CAT_NL80211, "invalid drv_data\n");
		return -1;
	}

	wapp = drv_nl80211_data->priv;
	if (!wapp) {
		err(DEBUG_CAT_NL80211, "invalid wapp\n");
		return -1;
	}

	ret = wpactrl_cmd_save_config(wapp->wpactrl_supplicant_ctx, ifname);
	if (ret != 0) {
		err(DEBUG_CAT_NL80211, "wpactrl_cmd_save_config failed\n");
		return ret;
	}

	return 0;
}

static int driver_nl80211_set_scan_ssid(void *drv_data, const char *ifname, int network_id, int enable)
{
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	struct wifi_app *wapp;
	int ret;

	if (!drv_nl80211_data) {
		err(DEBUG_CAT_NL80211, "invalid drv_data\n");
		return -1;
	}

	wapp = drv_nl80211_data->priv;
	if (!wapp) {
		err(DEBUG_CAT_NL80211, "invalid wapp\n");
		return -1;
	}

	ret = wpactrl_cmd_scan_ssid(wapp->wpactrl_supplicant_ctx, ifname, network_id, enable);
	if (ret != 0) {
		err(DEBUG_CAT_NL80211, "wpactrl_cmd_scan_ssid failed\n");
		return ret;
	}

	return 0;
}

static int driver_nl80211_send_wps_pbc(void *drv_data, const char *ifname, int map_enable)
{
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	struct wifi_app *wapp;
	int ret;
	struct wapp_dev *wdev = NULL;

	if (!drv_nl80211_data) {
		err(DEBUG_CAT_NL80211, "invalid drv_data\n");
		return -1;
	}

	wapp = drv_nl80211_data->priv;
	if (!wapp) {
		err(DEBUG_CAT_NL80211, "invalid wapp\n");
		return -1;
	}

	wdev = wapp_dev_list_lookup_by_ifname(wapp, ifname);
	if (!wdev) {
		err(DEBUG_CAT_NL80211, "wdev for ifname:%s not found\n", ifname);
		return -1;
	}

	if (wdev->dev_type == WAPP_DEV_TYPE_AP)
		ret = wpactrl_cmd_set_wps_pbc(wapp->wpactrl_hostapd_ctx, ifname, WPACTRL_TYPE_AP_LIB, map_enable);
	else
		ret = wpactrl_cmd_set_wps_pbc(wapp->wpactrl_supplicant_ctx, ifname, WPACTRL_TYPE_STA_LIB, map_enable);

	if (ret != 0) {
		err(DEBUG_CAT_NL80211, "wpactrl_cmd_set_wps_pbc failed\n");
		return ret;
	}

	return 0;
}

static int driver_nl80211_send_config_update(void *drv_data, const char *ifname)
{
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	struct wifi_app *wapp;
	int ret;

	if (!drv_nl80211_data) {
		err(DEBUG_CAT_NL80211, "invalid drv_data\n");
		return -1;
	}

	wapp = drv_nl80211_data->priv;
	if (!wapp) {
		err(DEBUG_CAT_NL80211, "invalid wapp\n");
		return -1;
	}

	ret = wpactrl_cmd_config_update(wapp->wpactrl_hostapd_ctx, ifname);
	if (ret != 0) {
		err(DEBUG_CAT_NL80211, "wpactrl_cmd_config_update failed\n");
		return ret;
	}

	return 0;
}

static int driver_nl80211_send_reload(void *drv_data, const char *ifname)
{
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	struct wifi_app *wapp;
	int ret;

	if (!drv_nl80211_data) {
		err(DEBUG_CAT_NL80211, "invalid drv_data\n");
		return -1;
	}

	wapp = drv_nl80211_data->priv;
	if (!wapp) {
		err(DEBUG_CAT_NL80211, "invalid wapp\n");
		return -1;
	}

	ret = wpactrl_cmd_reload(wapp->wpactrl_hostapd_ctx, ifname);
	if (ret != 0) {
		err(DEBUG_CAT_NL80211, "wpactrl_cmd_reload failed\n");
		return ret;
	}

	return 0;
}

static int driver_nl80211_set_anqp_elem(void *drv_data, const char *ifname, int id, u8 *buf, size_t buf_len)
{
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	struct wifi_app *wapp;
	int i, ret, res;
	size_t buf_str_size = (buf_len * 2) + 1;
	char *buf_str = (char *)malloc(buf_str_size);
	char *value = NULL;

	if (!buf_str) {
		err(DEBUG_CAT_NL80211, "Memory Allocation for buf_str failed\n");
		return -1;
	}
	if (!drv_nl80211_data) {
		err(DEBUG_CAT_NL80211, "invalid drv_data\n");
		free(buf_str);
		return -1;
	}

	wapp = drv_nl80211_data->priv;
	if (!wapp) {
		err(DEBUG_CAT_NL80211, "invalid wapp\n");
		free(buf_str);
		return -1;
	}

	os_memset(buf_str, 0, buf_str_size);
	for (i = 0; i < buf_len; i++) {
		ret = os_snprintf(buf_str + (i * 2), buf_str_size, "%02x", buf[i]);
		if (ret < 0 || ((i * 2 + ret) >= buf_str_size)) {
			err(DEBUG_CAT_NL80211, "os_snprintf fail!\n");
			free(buf_str);
			return -1;
		}
	}
	value = (char *)malloc(buf_str_size + 10);

	if (!value) {
		err(DEBUG_CAT_NL80211, "Memory Allocation for value failed\n");
		free(buf_str);
		return -1;
	}

	os_memset(value, 0, buf_str_size + 10);
	ret = os_snprintf(value, buf_str_size + 10, "%d:%s", id, buf_str);
	if (ret < 0 || ret >= buf_str_size + 10) {
		err(DEBUG_CAT_NL80211, "os_snprintf fail!\n");
		free(buf_str);
		free(value);
		return -1;
	}

	res = wpactrl_cmd_set(wapp->wpactrl_hostapd_ctx, ifname, "anqp_elem", value);

	free(buf_str);
	free(value);

	return res;
}

static int driver_nl80211_set_map_param(void *drv_data, const char *ifname,
					u8 map_param, char *buf, size_t buf_len)
{
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	struct wifi_app *wapp;
	int ret = -1;

	debug(DEBUG_CAT_NL80211, "buf: %s, map_param:%d\n", buf, map_param);

	if (!drv_nl80211_data) {
		err(DEBUG_CAT_NL80211, "invalid drv_data\n");
		return -1;
	}

	wapp = drv_nl80211_data->priv;
	if (!wapp) {
		err(DEBUG_CAT_NL80211, "invalid wapp\n");
		return -1;
	}

	switch (map_param) {
	case HAPD_AUTH_ALGS:
		ret = wpactrl_cmd_set(wapp->wpactrl_hostapd_ctx, ifname, "auth_algs", buf);
		break;
	case HAPD_WPA:
		ret = wpactrl_cmd_set(wapp->wpactrl_hostapd_ctx, ifname, "wpa", buf);
		break;
	case HAPD_MAP_BACKHAUL_WPA_PASSPHRASE:
		ret = wpactrl_cmd_set(wapp->wpactrl_hostapd_ctx, ifname, "multi_ap_backhaul_wpa_passphrase", buf);
		break;
	case HAPD_MAP:
		ret = wpactrl_cmd_set(wapp->wpactrl_hostapd_ctx, ifname, "multi_ap", buf);
		break;
	case HAPD_IGNORE_BROADCAST_SSID:
		ret = wpactrl_cmd_set(wapp->wpactrl_hostapd_ctx, ifname, "ignore_broadcast_ssid", buf);
		break;
	case HAPD_MAP_BH_SSID:
	{
		char hex_value[2048];

		os_memset(hex_value, 0, 2048);
		os_snprintf_hex(hex_value, sizeof(hex_value), (const u8 *)buf, buf_len);
		ret = wpactrl_cmd_set(wapp->wpactrl_hostapd_ctx, ifname, "multi_ap_backhaul_ssid", hex_value);
		break;
	}
	case HAPD_PMF_6G:
		ret = wpactrl_cmd_set(wapp->wpactrl_hostapd_ctx, ifname, "ieee80211w", "2");
		break;
	case HAPD_AUTHMODE:
		ret = wpactrl_cmd_set(wapp->wpactrl_hostapd_ctx, ifname, "wpa_key_mgmt", buf);
		break;
	case HAPD_WPA_PAIRWISE:
		ret = wpactrl_cmd_set(wapp->wpactrl_hostapd_ctx, ifname, "wpa_pairwise", buf);
		break;
	case HAPD_RSN_PAIRWISE:
		ret = wpactrl_cmd_set(wapp->wpactrl_hostapd_ctx, ifname, "rsn_pairwise", buf);
		break;
	case HAPD_WPA_PASSPHRASE:
		if (strlen(buf) == PSK_CONF)
			ret = wpactrl_cmd_set(wapp->wpactrl_hostapd_ctx, ifname, "wpa_psk", buf);
		else
			ret = wpactrl_cmd_set(wapp->wpactrl_hostapd_ctx, ifname, "wpa_passphrase", buf);
		break;
	case HAPD_SAE_PASSPHRASE:
		ret = wpactrl_cmd_set(wapp->wpactrl_hostapd_ctx, ifname, "sae_password", buf);
		break;
	case HAPD_SAE_PWE:
		ret = wpactrl_cmd_set(wapp->wpactrl_hostapd_ctx, ifname, "sae_pwe", buf);
		break;
#ifdef MAP_R6
	case HAPD_MAP_BH_KEY_MGMT:
		ret = wpactrl_cmd_set(wapp->wpactrl_hostapd_ctx, ifname, "multi_ap_backhaul_key_mgmt", buf);
		break;
	case HAPD_MAP_SAE_GROUPS:
		ret = wpactrl_cmd_set(wapp->wpactrl_hostapd_ctx, ifname, "sae_groups", buf);
		break;
	case HAPD_MAP_GROUP_CIPHER:
		ret = wpactrl_cmd_set(wapp->wpactrl_hostapd_ctx, ifname, "group_cipher", buf);
		break;
	case HAPD_MAP_GROUP_MGMT_CIPHER:
		ret = wpactrl_cmd_set(wapp->wpactrl_hostapd_ctx, ifname, "group_mgmt_cipher", buf);
		break;
	case HAPD_MAP_BEACON_PROT:
		ret = wpactrl_cmd_set(wapp->wpactrl_hostapd_ctx, ifname, "beacon_prot", buf);
		break;
#endif
	case HAPD_MAP_OWE_GROUPS:
			ret = wpactrl_cmd_set(wapp->wpactrl_hostapd_ctx, ifname, "owe_groups", buf);
			break;
	case HAPD_MAP_OWE_TRANSITION_IFNAME:
			ret = wpactrl_cmd_set(wapp->wpactrl_hostapd_ctx, ifname, "owe_transition_ifname", buf);
			break;
	case HAPD_MAP_WPS_STATE:
		ret = wpactrl_cmd_set(wapp->wpactrl_hostapd_ctx, ifname, "wps_state", buf);
		break;
	default:
		err(DEBUG_CAT_NL80211, "unmatched; ifname:%s , param:%d NA\n", ifname, map_param);
		break;
	}

	return ret;
}

static int driver_nl80211_set_pmfmfpc(void *drv_data, const char *ifname, char *buf, size_t buf_len)
{
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	struct wifi_app *wapp;

	if (!drv_nl80211_data) {
		err(DEBUG_CAT_NL80211, "invalid drv_data\n");
		return -1;
	}

	wapp = drv_nl80211_data->priv;
	if (!wapp) {
		err(DEBUG_CAT_NL80211, "invalid wapp\n");
		return -1;
	}

	return wpactrl_cmd_set(wapp->wpactrl_hostapd_ctx, ifname, "ieee80211w", buf);
}

static int driver_nl80211_set_apcli_PMFMFPC(void *drv_data, const char *ifname, int network_id, char *buf, size_t buf_len)
{
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	struct wifi_app *wapp;

	if (!drv_nl80211_data) {
		err(DEBUG_CAT_NL80211, "invalid drv_data\n");
		return -1;
	}

	wapp = drv_nl80211_data->priv;
	if (!wapp) {
		err(DEBUG_CAT_NL80211, "invalid wapp\n");
		return -1;
	}

	return wpactrl_cmd_set_network(wapp->wpactrl_supplicant_ctx, ifname, network_id, "ieee80211w", buf);
}

static int driver_nl80211_set_apcli_dpp_pfs(void *drv_data, const char *ifname, int network_id, int value)
{
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	struct wifi_app *wapp;

	if (!drv_nl80211_data || !ifname) {
		err(DEBUG_CAT_NL80211, "invalid drv_data\n");
		return -1;
	}

	wapp = drv_nl80211_data->priv;
	if (!wapp) {
		err(DEBUG_CAT_NL80211, "invalid wapp\n");
		return -1;
	}

	return wpactrl_cmd_set_network_dpp_pfs(wapp->wpactrl_supplicant_ctx, ifname, network_id, "dpp_pfs", value);
}

static int driver_nl80211_mbo_param_setting(void *drv_data, const char *ifname, u32 param, u32 value)
{
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	struct wifi_app *wapp;
	char buf[1] = {0};

	if (param != PARAM_MBO_AP_ASSOC_DISALLOW && value > MBO_TRANSITION_TO_A_PREMIUM_AP)
		return 0;

	if (!drv_nl80211_data) {
		err(DEBUG_CAT_NL80211, "invalid drv_data\n");
		return -1;
	}

	buf[0] = '0' + (char)value;
	wapp = drv_nl80211_data->priv;
	if (!wapp) {
		err(DEBUG_CAT_NL80211, "invalid wapp\n");
		return -1;
	}

	return wpactrl_cmd_set(wapp->wpactrl_hostapd_ctx, ifname, "mbo_assoc_disallow", buf);
}
#endif /* WPACTRL_SUPPORT */

#ifdef DFS_SLAVE_SUPPORT
static int driver_nl80211_update_BhStatus(void *drv_data, const char *ifname, char *buf, size_t len)
{
	return driver_nl80211_set_msg((struct driver_nl80211_data *)drv_data, ifname,
					MTK_NL80211_VENDOR_SUBCMD_BH_STATUS,
					MTK_NL80211_VENDOR_ATTR_DFS_SLAVE_BH_STATUS,
					buf, len);
}
#endif /* WPACTRL_SUPPORT */

static int driver_nl80211_set_ACLAddEntry(void *drv_data, const char *ifname, u8 *buf, size_t buf_len)
{
	return driver_nl80211_set_msg((struct driver_nl80211_data *) drv_data, ifname,
					MTK_NL80211_VENDOR_SUBCMD_SET_ACL,
					MTK_NL80211_VENDOR_ATTR_ACL_ADD_MAC,
					buf, buf_len);
}

static int driver_nl80211_set_BLAdd(void *drv_data, const char *ifname, u8 *buf, size_t buf_len)
{
	return driver_nl80211_set_msg((struct driver_nl80211_data *) drv_data, ifname,
					MTK_NL80211_VENDOR_SUBCMD_SET_ACL,
					MTK_NL80211_VENDOR_ATTR_ACL_BL_ADD_MAC,
					buf, buf_len);
}

static int driver_nl80211_set_ACLDelEntry(void *drv_data, const char *ifname, u8 *buf, size_t buf_len)
{
	return driver_nl80211_set_msg((struct driver_nl80211_data *) drv_data, ifname,
					MTK_NL80211_VENDOR_SUBCMD_SET_ACL,
					MTK_NL80211_VENDOR_ATTR_ACL_DEL_MAC,
					buf, buf_len);
}

static int driver_nl80211_set_BLDel(void *drv_data, const char *ifname, u8 *buf, size_t buf_len)
{
	return driver_nl80211_set_msg((struct driver_nl80211_data *) drv_data, ifname,
					MTK_NL80211_VENDOR_SUBCMD_SET_ACL,
					MTK_NL80211_VENDOR_ATTR_ACL_BL_DEL_MAC,
					buf, buf_len);
}

static int driver_nl80211_set_ACLClearAll(void *drv_data, const char *ifname, u8 *buf, size_t buf_len)
{
	return driver_nl80211_set_msg((struct driver_nl80211_data *) drv_data, ifname,
					MTK_NL80211_VENDOR_SUBCMD_SET_ACL,
					MTK_NL80211_VENDOR_ATTR_ACL_CLEAR_ALL,
					buf, buf_len);
}

static int driver_nl80211_set_AccessPolicy(void *drv_data, const char *ifname, u8 *buf, size_t buf_len)
{
	return driver_nl80211_set_msg((struct driver_nl80211_data *) drv_data, ifname,
					MTK_NL80211_VENDOR_SUBCMD_SET_ACL,
					MTK_NL80211_VENDOR_ATTR_ACL_POLICY,
					buf, buf_len);
}

static int driver_nl80211_test_cb(struct nl_msg *msg, void *arg)
{
	struct nlattr *tb[NL80211_ATTR_MAX + 1];
	struct nlattr *sub_tb[MTK_NL80211_VENDOR_ATTR_TEST_MAX + 1];
	struct genlmsghdr *gnlh = nlmsg_data(nlmsg_hdr(msg));
	u32 val;
	int ret;

	if (gnlh->cmd != NL80211_CMD_VENDOR) {
		err(DEBUG_CAT_NL80211, "not mtk vendor msg\n");
		return NL_SKIP;
	}

	nla_parse(tb, NL80211_ATTR_MAX, genlmsg_attrdata(gnlh, 0), genlmsg_attrlen(gnlh, 0), NULL);

	if (!tb[NL80211_ATTR_VENDOR_DATA]) {
		err(DEBUG_CAT_NL80211, "NL80211_ATTR_VENDOR_DATA missing\n");
		return NL_SKIP;
	}

	ret = nla_parse_nested(sub_tb, MTK_NL80211_VENDOR_ATTR_TEST_MAX, tb[NL80211_ATTR_VENDOR_DATA], NULL);
	if (ret) {
		err(DEBUG_CAT_NL80211, "nla_parse_nested fail!\n");
		return NL_SKIP;
	}

	if (!sub_tb[MTK_NL80211_VENDOR_ATTR_TEST]) {
		err(DEBUG_CAT_NL80211, "no MTK_NL80211_VENDOR_ATTR_TEST\n");
		return NL_SKIP;
	}

	val = nla_get_u32(sub_tb[MTK_NL80211_VENDOR_ATTR_TEST]);
	notice(DEBUG_CAT_NL80211, "val = %d\n", val);

	return NL_SKIP;
}

#ifdef MAP_R6
static int driver_nl80211_set_mlo_switch(void *drv_data, const char *ifname, unsigned char flag)
{
	int ret;
	char *buf;
	size_t len = 1;

	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	buf = os_zalloc(len);

	if (!buf) {
		err(DEBUG_CAT_NL80211, "Not available memory\n");
		return -1;
	}

	*buf = flag;
	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_SET_MLO_SWITCH,
			MTK_NL80211_VENDOR_ATTR_MLO_SWITCH_SET, buf, len);

	os_free(buf);

	return ret;
}

int driver_nl80211_set_t2lm_mapping(void *drv_data, const char *ifname, char *buf, u32 buflen)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_SET_ACTION,
		MTK_NL80211_VENDOR_ATTR_SET_ACTION_SET_T2LM_MAPPING, buf, buflen);

	return ret;
}

#endif

#ifdef MAP_VENDOR_SUPPORT
static int driver_nl80211_set_vendor_nop_state(void *drv_data, const char *ifname, char *buf, size_t *len)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	if (!buf) {
		err(DEBUG_CAT_NL80211, "Not available memory\n");
		return -1;
	}
	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
		MTK_NL80211_VENDOR_ATTR_EASYMESH_SET_VENDOR_NOP_STATE, buf, *len);


	return ret;
}

static int driver_nl80211_set_vendor_ch_pref_state(void *drv_data, const char *ifname, char *buf, size_t *len)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	if (!buf) {
		err(DEBUG_CAT_NL80211, "Not available memory\n");
		return -1;
	}
	ret = driver_nl80211_set_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_EASYMESH,
		MTK_NL80211_VENDOR_ATTR_EASYMESH_SET_VENDOR_CH_PREF_STATE, buf, *len);


	return ret;
}
#endif /* MAP_VENDOR_SUPPORT */

static int driver_nl80211_get_radio_cpu_tempreture(void *drv_data, const char *ifname, char *buf,
							size_t *buf_len)
{
	int ret;
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;

	ret = driver_nl80211_get_msg(drv_nl80211_data, ifname, MTK_NL80211_VENDOR_SUBCMD_GET_RADIO_STATS,
					MTK_NL80211_VENDOR_ATTR_GET_RADIO_CPU_TEMPRETURE, buf, buf_len);
	return ret;
}

int driver_nl80211_test(void *drv_data, u32 test_data)
{
	struct driver_nl80211_data *drv_nl80211_data = (struct driver_nl80211_data *)drv_data;
	struct nl_msg *msg;
	void *attr;
	int ret = -1;

	msg = unl_genl_msg(&drv_nl80211_data->nl_handle, NL80211_CMD_VENDOR, FALSE);
	if (!msg) {
		err(DEBUG_CAT_NL80211, "unl_genl_msg fail!!!\n");
		return ret;
	}

	if (nla_put_u32(msg, NL80211_ATTR_IFINDEX, if_nametoindex("ra0")) ||
	    nla_put_u32(msg, NL80211_ATTR_VENDOR_ID, MTK_NL80211_VENDOR_ID) ||
	    nla_put_u32(msg, NL80211_ATTR_VENDOR_SUBCMD, MTK_NL80211_VENDOR_SUBCMD_TEST)) {
		err(DEBUG_CAT_NL80211, "nla_put_u32 fail!!!\n");
		goto out;
	}

	attr = nla_nest_start(msg, NL80211_ATTR_VENDOR_DATA);

	if (!attr)
		goto out;

	if (nla_put_u32(msg, MTK_NL80211_VENDOR_ATTR_TEST, test_data))
		goto out;

	nla_nest_end(msg, attr);

	ret = unl_genl_request(&drv_nl80211_data->nl_handle, msg, driver_nl80211_test_cb, NULL);
	if (ret)
		err(DEBUG_CAT_NL80211, "nl80211 call fail!!!\n");

	return ret;
out:
	nlmsg_free(msg);
	return ret;
}

#ifdef STANDARD_NL_CMD
int driver_nl80211_get_scan_result(struct wifi_app *wapp, struct wapp_dev *wdev, struct wapp_req *req, u8 op_class)
{
	int ret = 0, i;
	struct nl_msg *msg = NULL;
	struct nlattr *ssids;
	struct nlattr *freqs;
	struct driver_nl80211_data *drv = NULL;
	OFFCHANNEL_SCAN_MSG *scan_msg = NULL;
	struct off_ch_scan_state_ctrl *scan_state;


	if (!wapp || !wapp->drv_data) {
		err(DEBUG_CAT_NL80211, "invalid input params\n");
		return -1;
	}
	scan_state = &wapp->map->off_ch_scan_state;
	scan_msg = &scan_state->scan_msg;

	drv = (struct driver_nl80211_data *)wapp->drv_data;

	msg = unl_genl_msg(&drv->nl_handle, req->req_id, FALSE);
	if (!msg) {
		err(DEBUG_CAT_NL80211, "unl_genl_msg fail!!!\n");
		return -1;
	}

	if (nla_put_u32(msg, NL80211_ATTR_IFINDEX, req->data.ifindex)) {
		err(DEBUG_CAT_NL80211, "nla_put_u32 ifindex fail!!!\n");
		nlmsg_free(msg);
		return -1;
	}

	switch (wdev->dev_type) {
	case WAPP_DEV_TYPE_AP:
		freqs = nla_nest_start(msg, NL80211_ATTR_SCAN_FREQUENCIES);
		if (!freqs) {
			err(DEBUG_CAT_NL80211, "nla_nest_start freq fail!!!\n");
			nlmsg_free(msg);
			return -1;
		}


		for (i = 0; i < scan_msg->data.offchannel_param.Num_of_Away_Channel; i++) {
			notice(DEBUG_CAT_NL80211, "channel time %d ", scan_msg->data.offchannel_param.scan_time[i]);
			notice(DEBUG_CAT_NL80211, "channel %d %d\n", scan_msg->data.offchannel_param.channel[i],
				map_get_freq_from_channel_op_class(op_class, scan_msg->data.offchannel_param.channel[i]));
			if (nla_put_u32(msg, i + 1, map_get_freq_from_channel_op_class(op_class,
				scan_msg->data.offchannel_param.channel[i]))) {
				err(DEBUG_CAT_NL80211, "nla_put_u32 channel fail!!!\n");
				nlmsg_free(msg);
				return -1;
			}

		}
		nla_nest_end(msg, freqs);
		wapp->nl_rest_ap = 1;
		break;
	case WAPP_DEV_TYPE_STA:
	case WAPP_DEV_TYPE_APCLI:
		if (wdev && WMODE_CAP_6G(wdev->wireless_mode) && req->data.scan_bh_ssids.scan_channel_count > 0) {
			freqs = nla_nest_start(msg, NL80211_ATTR_SCAN_FREQUENCIES);
			if (!freqs) {
				err(DEBUG_CAT_NL80211, "nla_nest_start freq fail!!!\n");
				nlmsg_free(msg);
				return -1;
			}
			for (i = 0; i < req->data.scan_bh_ssids.scan_channel_count; i++) {
				if (nla_put_u32(msg, i + 1, map_get_freq_from_channel_op_class(134,
					req->data.scan_bh_ssids.scan_channel_list[i]))) {
					err(DEBUG_CAT_NL80211, "nla_put_u32 channel fail!!!\n");
					nlmsg_free(msg);
					return -1;
				}
			}
			nla_nest_end(msg, freqs);
			debug(DEBUG_CAT_NL80211, "6G scan!!!\n");
		}
		if (wapp->partial_scan_count > 0 && (WMODE_CAP_5G(wdev->wireless_mode) || WMODE_CAP_2G(wdev->wireless_mode)) &&
		 req->data.scan_bh_ssids.scan_channel_count > 0) {
			info(DEBUG_CAT_NL80211, "Partial scan!!!\n");
			freqs = nla_nest_start(msg, NL80211_ATTR_SCAN_FREQUENCIES);
			if (!freqs) {
				err(DEBUG_CAT_NL80211, "nla_nest_start freq fail!!!\n");
				nlmsg_free(msg);
				return -1;
			}
			int k = 0;

			for (i = wapp->temp_scan_count; i < req->data.scan_bh_ssids.scan_channel_count; i++) {
				if (nla_put_u32(msg, i + 1, wapp->freq_par[i])) {
					err(DEBUG_CAT_NL80211, "nla_put_u32 channel fail!!!\n");
					nlmsg_free(msg);
					return -1;
				}
				wapp->temp_scan_count++;
				k++;
				if (k == wapp->partial_scan_count)
					break;
			}
			nla_nest_end(msg, freqs);
		}
		ssids = nla_nest_start(msg, NL80211_ATTR_SCAN_SSIDS);
		if (ssids == NULL) {
			err(DEBUG_CAT_NL80211, "nla_nest_start ssid fail!!!\n");
			nlmsg_free(msg);
			return -1;
		}
		notice(DEBUG_CAT_NL80211, " Total ssids %d\n", req->data.scan_bh_ssids.profile_cnt);
		for (i = 0; i < 1 ; i++) {
			ret = nla_put(msg, i + 1, req->data.scan_bh_ssids.scan_SSID_val[i].SsidLen,
				req->data.scan_bh_ssids.scan_SSID_val[i].ssid);
			if (ret)
				err(DEBUG_CAT_NL80211, "nla_put fail!!!\n");
			notice(DEBUG_CAT_NL80211, "%d %s\n", (int)req->data.scan_bh_ssids.scan_SSID_val[i].SsidLen,
				(char *)req->data.scan_bh_ssids.scan_SSID_val[i].ssid);
		}
		nla_nest_end(msg, ssids);
		wapp->nl_rest_apcli = 1;
		break;
	default:
		err(DEBUG_CAT_NL80211, "Invalid case received!!!\n");
	break;
	}
	ret = unl_genl_request(&drv->nl_handle, msg, NULL, NULL);
	if (ret) {
		if (wdev->dev_type == WAPP_DEV_TYPE_AP)
			wapp->nl_rest_ap = 0;
		else
			wapp->nl_rest_apcli = 0;
	}
	return ret;
}
#endif

const struct wapp_drv_ops wapp_drv_nl80211_ops = {
	.drv_inf_init = driver_nl80211_init,
	.drv_inf_exit = driver_nl80211_exit,
	.drv_test = driver_nl80211_test,
#ifdef STANDARD_NL_CMD
	.drv_get_hw_info = driver_nl80211_get_hw_info,
	.drv_get_devs = driver_nl80211_get_devs,
	.drv_get_dev = driver_nl80211_get_dev,
	.drv_get_country = driver_nl80211_get_country,
	.drv_get_feature = driver_nl80211_get_feature,
	.drv_get_scan_result = driver_nl80211_get_scan_result,
#endif
	.drv_wifi_version = driver_nl80211_wifi_version,
	.drv_wapp_version_check = driver_nl80211_wapp_support_version,
	.drv_wapp_req = driver_nl80211_send_wapp_req,
	.drv_set_ie = driver_nl80211_set_ie,
#ifdef COSR_SUPPORT
	.drv_set_cosr_ie = driver_nl80211_set_cosr_ie,
	.drv_wapp_set_cosr_stainfo = driver_nl80211_set_cosr_stainfo,
	.drv_wapp_set_cosr_apinfo = driver_nl80211_set_cosr_apinfo,
#endif /* COSR_SUPPORT */
	.drv_get_wsc_profiles = driver_nl80211_get_wsc_profiles,
#ifdef MTK_MLO_MAP_SUPPORT
	.drv_get_mlo_info = driver_nl80211_get_mlo_info,
#endif
#ifdef WPACTRL_SUPPORT
	.drv_send_btm_req = driver_nl80211_send_btm_req,
	.drv_send_btm_query = driver_nl80211_send_btm_query,
	.drv_send_btm_rsp = driver_nl80211_send_btm_rsp,
	.drv_send_bcn_req = driver_nl80211_send_bcn_req,
#endif /* WPACTRL_SUPPORT */
	.drv_get_wdev = driver_nl80211_get_wdev,
#ifdef MAP_R2
#ifdef DFS_CAC_R2
	.drv_get_cac_cap = driver_nl80211_get_cac_capability,
	.drv_cac_req = driver_nl80211_cac_req,
	.drv_set_monitor_ch_assign = driver_nl80211_mon_ch_assign,
	.drv_get_ch_avail_list = driver_nl80211_get_avail_channel,
#endif
#endif
	.drv_get_misc_cap = driver_nl80211_get_misc_cap,
	.drv_get_ht_cap = driver_nl80211_get_ht_cap,
	.drv_get_vht_cap = driver_nl80211_get_vht_cap,
	.drv_get_he_cap = driver_nl80211_get_he_cap,
#ifdef MAP_EHT_SUPPORT
	.drv_get_eht_cap = driver_nl80211_get_eht_cap,
#endif
#ifdef MTK_MLO_MAP_SUPPORT
	.drv_get_mlo_cap = driver_nl80211_get_mlo_cap,
#endif
	.drv_get_chan_list = driver_nl80211_get_chan_list,
	.drv_get_op_class = driver_nl80211_get_op_class,
	.drv_get_bss_info = driver_nl80211_get_bss_info,
	.drv_get_ap_metrics = driver_nl80211_get_ap_metrics,
	.drv_off_ch_scan_req = driver_nl80211_off_ch_scan_req,
	.drv_get_nop_channels = driver_nl80211_get_nop_list,
	.drv_get_chip_id = driver_nl80211_get_chip_id,
	.drv_set_ssid = driver_nl80211_set_ssid,
	.drv_set_psk = driver_nl80211_set_psk,
	.send_action = driver_nl80211_send_action_frm,
	.drv_cancel_roc = driver_nl80211_cancel_roc,
	.drv_start_roc = driver_nl80211_start_roc,
	.drv_get_tx_pwr = driver_nl80211_get_tx_pwr,
	.drv_get_max_sta_num = driver_nl80211_get_max_sta_num,
	.drv_get_assoc_req_frame = driver_nl80211_get_assoc_req_frame,
	.drv_get_bss_coex = driver_nl80211_get_bss_coex,
	.drv_set_wireless_mode = driver_nl80211_set_wireless_mode,
	.drv_set_channel_proc = driver_nl80211_set_channel,
	.drv_set_htbw_proc = driver_nl80211_set_htbw,
	.drv_set_vhtbw_proc = driver_nl80211_set_vhtbw,
	.drv_set_bw_proc = driver_nl80211_set_bw,
	.drv_set_bw_channel_proc = driver_nl80211_set_bw_and_channel,
#ifdef MAP_EHT_SUPPORT
	.drv_set_ehtbw_proc = driver_nl80211_set_ehtbw,
#endif
#ifdef EM_PLUS_SUPPORT
	.drv_set_cfg_bw_proc = driver_nl80211_set_cfg_bw,
	.drv_set_acs_ch_list = driver_nl80211_set_acs_ch_list,
	.drv_set_acs_partial_scan = driver_nl80211_set_acs_partial_scan,
	.drv_set_acs_scan_ch_num = driver_nl80211_set_acs_scan_ch_num,
	.drv_set_acs_sta_thresold = driver_nl80211_set_acs_sta_thresold,
	.drv_set_acs_ch_util_thresold = driver_nl80211_set_acs_ch_util_thresold,
	.drv_set_acs_scan_dwell = driver_nl80211_set_acs_scan_dwell,
	.drv_set_acs_restore_dwell = driver_nl80211_set_acs_restore_dwell,
	.drv_set_acs_ch_check_time = driver_nl80211_set_acs_ch_check_time,
	.drv_set_acs_ch_checktime_trigger = driver_nl80211_set_acs_ch_checktime_trigger,
	.drv_set_acs_ch_6g_psc = driver_nl80211_set_acs_ch_6g_psc,
#endif
	.drv_set_hidden_ssid = driver_nl80211_set_hidden_ssid,
	.drv_set_auth_mode = driver_nl802111_set_auth_mode,
	.drv_set_encrypt_type = driver_nl80211_set_encrypt_type,
	.drv_set_default_key_id = driver_nl80211_set_default_key_id,
	.drv_set_key1 = driver_nl80211_set_key1,
	.drv_set_wpapsk = driver_nl80211_set_wpapsk,
	.drv_set_raido_on = driver_nl80211_set_radio_on,
	.drv_set_DisConnectSta = driver_nl80211_set_DisConnectSta,
	.drv_set_ts_bh_primary_vid = driver_nl80211_set_ts_bh_primary_vid,
	.drv_set_ts_bh_primary_pcp = driver_nl80211_set_ts_bh_primary_pcp,
	.drv_set_ts_bh_vid = driver_nl80211_set_bh_vid,
	.drv_set_ts_fh_vid = driver_nl80211_set_fh_vid,
	.drv_set_transparent_vid = driver_nl80211_set_transparent_vid,
	.drv_set_BcnReq = driver_nl80211_set_BcnReq,
	.drv_set_HtBssCoex = driver_nl80211_HtBssCoex,
	.drv_set_PMFMFPC = driver_nl80211_PMFMFPC,
	.drv_set_AutoRoaming = driver_nl80211_AutoRoaming,
	.drv_set_DSCPPolicyEnable = driver_nl80211_DSCPPolicyEnable,
	.drv_set_QosMapCapa = driver_nl80211_QosMapCapa,
	.drv_set_ScanType = driver_nl80211_ScanType,
	.drv_set_ScanClear = driver_nl80211_ScanClear,
#ifdef DPP_SUPPORT
	.drv_set_pmk = driver_nl80211_set_pmk,
	.drv_get_dpp_frame = driver_nl80211_get_dpp_frame,
#endif /*DPP_SUPPORT */
#ifdef MAP_R3
	.drv_reset_cce_ie = driver_nl80211_reset_cce_ie,
	.drv_agnt_dpp_uri = driver_nl80211_agnt_dpp_uri,
	.drv_set_1905_sec = driver_nl80211_set_1905_sec,
	.drv_set_onboarding_type = driver_nl80211_set_onboarding_type,
#endif /* MAP_R3 */
#ifdef MAP_R3_WF6
	.drv_get_wf6_cap = driver_nl80211_get_wf6_cap,
#endif /*MAP_R3_WF6 */
#ifdef MAP_R6
	.drv_set_no_bcn = driver_nl80211_set_no_bcn,
#endif /* MAP_R6 */
#ifdef MAP_R4_SPT
	.drv_get_spt_reuse_req = driver_nl80211_get_spt_reuse_req,
	.drv_set_bss_color = driver_nl80211_set_bss_color,
	.drv_set_sr_enable = driver_nl80211_set_sr_enable,
	.drv_set_bh_bitmap = driver_nl80211_set_bh_bitmap,
#endif
#ifdef QOS_R1
	.drv_send_up_tuple_expired = driver_nl80211_qos_send_up_tuple_expired,
#ifdef QOS_R2
	.drv_get_pmk_by_peermac = driver_nl80211_get_pmk_by_peermac,
#endif
#ifdef QOS_R3
	.drv_set_qos_characteristics_ie = driver_nl80211_set_qos_characteristics_ie,
#endif
#ifdef EPCS_SUPPORT
	.drv_sync_epcs_state = driver_nl80211_sync_epcs_state,
#endif
#ifdef MAP_R5
	.drv_reset_dscp2up_table = driver_nl80211_reset_dscp2up_table,
#endif
#endif
	.drv_set_air_mnt_en = driver_nl80211_set_air_mnt_en,
	.drv_set_air_mnt_rule = driver_nl80211_set_air_mnt_rule,
	.drv_set_air_mnt_sta_id = driver_nl80211_set_air_mnt_sta_id,
	.drv_set_air_mnt_max_pkt = driver_nl80211_set_air_mnt_max_pkt,
	.drv_get_air_mnt_result = driver_nl80211_get_air_mnt_result,
	.drv_set_map_ch = driver_nl80211_set_map_ch,
	.drv_set_map_enable = driver_nl80211_set_map_en,
	.drv_set_ap_fhbss = driver_nl80211_set_ap_fhbss,
	.drv_set_ap_bhbss = driver_nl80211_set_ap_bhbss,
	.drv_set_ap_v10converter = driver_nl80211_set_ap_v10converter,
	.drv_set_approxyrefresh = driver_nl80211_set_approxyrefresh,
#ifdef MAP_R6
	.drv_set_mlo_switch = driver_nl80211_set_mlo_switch,
	.drv_set_t2lm_mapping = driver_nl80211_set_t2lm_mapping,
#endif
#ifdef WPACTRL_SUPPORT
	.drv_send_ap_intf_enable = driver_nl80211_set_enable,
	.drv_send_ap_intf_disable = driver_nl80211_set_disable,
	.drv_send_sta_deauth = driver_nl80211_send_sta_deauth,
	.drv_send_remove_network = driver_nl80211_send_remove_network,
	.drv_send_hide_ssid = driver_nl80211_set_hide_ssid,
	.drv_send_disable_network = driver_nl80211_send_disable_network,
	.drv_send_enable_network = driver_nl80211_send_enable_network,
	.drv_send_network_bssid = driver_nl80211_set_network_bssid,
	.drv_send_add_network = driver_nl80211_send_add_network,
	.drv_send_network_key = driver_nl80211_set_network_key,
	.drv_send_network_keymgmt = driver_nl80211_set_network_keymgmt,
	.drv_send_sae_pwd = driver_nl80211_set_sae_pwd,
	.drv_send_wep_key = driver_nl80211_set_wep_key,
	.drv_send_save_config = driver_nl80211_send_save_config,
	.drv_set_scan_ssid = driver_nl80211_set_scan_ssid,
	.drv_send_wps_pbc = driver_nl80211_send_wps_pbc,
	.drv_send_config_update = driver_nl80211_send_config_update,
	.drv_send_reload = driver_nl80211_send_reload,
#ifdef MTK_HOSTAPD_SUPPORT
	.drv_set_dpp_peermac = driver_nl80211_set_dpp_peermac,
	.drv_set_ap_pmk_hapd = driver_nl80211_set_ap_pmk_hapd,
	.drv_set_sta_pmk_supp = driver_nl80211_set_sta_pmk_supp,
	.drv_send_select_network = driver_nl80211_send_select_network,
	.drv_send_bss_flush = driver_nl80211_send_bss_flush,
	.drv_send_update_bridge = driver_nl80211_send_update_bridge,
	.drv_send_get_pmk = driver_nl80211_send_get_pmk,
#ifdef MAP_R6 /* GERNERIC_R6 */
	.drv_send_network_pairwise = driver_nl80211_set_network_pairwise,
	.drv_send_network_group = driver_nl80211_set_network_group,
	.drv_send_network_grpmgmt = driver_nl80211_set_network_grpmgmt,
	.drv_send_beacon_prot = driver_nl80211_set_beacon_prot,
#endif /* MAP_R6 */
#endif
	.drv_set_anqp_elem = driver_nl80211_set_anqp_elem,
	.drv_set_pmfmfpc = driver_nl80211_set_pmfmfpc,
	.drv_set_map_param = driver_nl80211_set_map_param,
	.drv_set_apcli_PMFMFPC = driver_nl80211_set_apcli_PMFMFPC,
	.drv_mbo_param_setting = driver_nl80211_mbo_param_setting,
	.drv_send_ap_intf_stop = driver_nl80211_set_intf_disable,
	.drv_set_apcli_dpp_pfs = driver_nl80211_set_apcli_dpp_pfs,
#endif /* WPACTRL_SUPPORT */
	.drv_set_ACLAddEntry = driver_nl80211_set_ACLAddEntry,
	.drv_set_ACLDelEntry = driver_nl80211_set_ACLDelEntry,
	.drv_set_ACLClearAll = driver_nl80211_set_ACLClearAll,
	.drv_set_AccessPolicy = driver_nl80211_set_AccessPolicy,
	.drv_set_BLAdd = driver_nl80211_set_BLAdd,
	.drv_set_BLDel = driver_nl80211_set_BLDel,
#ifdef WPACTRL_SUPPORT
	.drv_set_BhAssocCtrl = driver_nl80211_set_BhAssocCtrl,
#endif
	.drv_set_mld_group_create = driver_nl80211_create_mld_group,
	.drv_set_mld_group_delete = driver_nl80211_delete_mld_group,
	.drv_set_mld_link_add = driver_nl80211_mld_link_add,
	.drv_set_mld_link_del = driver_nl80211_mld_link_del,
#ifdef MAP_R6
	.drv_set_mld_link_reconfig = driver_nl80211_mld_link_reconfig,
#endif /* MAP_R6 */
	.drv_set_mld_link_transfer = driver_nl80211_mld_link_transfer,
	.drv_set_static_punc_dscb = driver_nl80211_set_static_punc_dscb,
#ifdef CSA_BAND_SUPPORT
	.drv_set_2g_csa_support = driver_nl80211_set_2g_csa_support,
	.drv_set_csa_support = driver_nl80211_set_csa_support,
#endif
#ifdef WPACTRL_SUPPORT
	.drv_send_ap_intf_add = driver_nl80211_set_intf_add,
#endif
#ifdef DFS_SLAVE_SUPPORT
	.drv_update_BhStatus = driver_nl80211_update_BhStatus,
#endif /* DFS_SLAVE_SUPPORT */
	.drv_get_radio_cpu_temperature = driver_nl80211_get_radio_cpu_tempreture,
	.drv_send_t2lm_request = driver_nl80211_send_t2lm_request,
#ifdef MAP_VENDOR_SUPPORT
	.drv_set_vendor_nop_state = driver_nl80211_set_vendor_nop_state,
	.drv_set_vendor_ch_pref_state = driver_nl80211_set_vendor_ch_pref_state
#endif /* MAP_VENDOR_SUPPORT */
};
