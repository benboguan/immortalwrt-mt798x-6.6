/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#include <stdlib.h>
#include <stdio.h>
#include "wdev.h"
#include "driver_wext.h"
#ifdef WPACTRL_SUPPORT
#include <libwpactrl.h>
#endif

static int wdev_ap_del(struct wifi_app *wapp, struct wapp_dev *wdev);

static struct wdev_ops wdev_ap_ops = {
	.wdev_del = wdev_ap_del,
};

void wdev_handle_nop_channels(struct nop_channel_list_s *nop_channels)
{
	int i = 0;
	for (i = 0; i < nop_channels->channel_count; i++)
		update_primary_ch_status(nop_channels->channel_list[i], FALSE);
}

#ifdef WPACTRL_SUPPORT
static int wdev_ap_event_sta_connected(void *ctx, const char *iface,
					const uint8_t *addr)
{
	DBGPRINT(RT_DEBUG_TRACE, "%s: %s " MACSTR "\n", __func__, iface, MAC2STR(addr));

	return 0;
}

static int wdev_ap_event_sta_disconnected(void *ctx, const char *iface,
					const uint8_t *addr)
{
	DBGPRINT(RT_DEBUG_TRACE, "%s: %s " MACSTR "\n", __func__, iface, MAC2STR(addr));

	return 0;
}

static int wdev_ap_event_btm_query(void *ctx, const char *iface,
				uint8_t *mac, uint8_t *payload, size_t payload_len)
{
	int ret;
	struct wifi_app *wapp = (struct wifi_app *)ctx;

	DBGPRINT(RT_DEBUG_TRACE, "%s: %s\n", __func__, iface);

	if (!wapp || !wapp->event_ops || !wapp->event_ops->event_btm_query)
		return 0;

	ret = wapp->event_ops->event_btm_query(wapp,
				iface, mac, (const char *)payload, payload_len);

	if (ret != WAPP_SUCCESS) {
		DBGPRINT(RT_DEBUG_ERROR, RED("%s: event_btm_query failed:%d\n"), __func__, ret);
		return -1;
	}
	return 0;
}

static int wdev_ap_event_btm_resp(void *ctx, const char *iface,
				uint8_t *mac, uint8_t *payload, size_t payload_len)
{
	int ret;
	struct wifi_app *wapp = (struct wifi_app *)ctx;

	DBGPRINT(RT_DEBUG_TRACE, "%s: %s\n", __func__, iface);

	if (!wapp || !wapp->event_ops || !wapp->event_ops->event_btm_rsp)
		return 0;

	ret = wapp->event_ops->event_btm_rsp(wapp,
				iface, mac, (const char *)payload, payload_len);

	if (ret != WAPP_SUCCESS) {
		DBGPRINT(RT_DEBUG_ERROR, RED("%s: event_btm_rsp failed:%d\n"), __func__, ret);
		return -1;
	}
	return 0;
}

static int wdev_ap_event_anqp_init_req(void *ctx, const char *iface,
				uint8_t *mac, uint8_t *payload, size_t payload_len)
{
	int ret;
	struct wifi_app *wapp = (struct wifi_app *)ctx;

	DBGPRINT(RT_DEBUG_TRACE, "%s: %s\n", __func__, iface);

	if (!wapp || !wapp->event_ops || !wapp->event_ops->event_anqp_req)
		return 0;

	ret = wapp->event_ops->event_anqp_req(wapp,
				iface, mac, (char *)payload, payload_len);

	if (ret != WAPP_SUCCESS) {
		DBGPRINT(RT_DEBUG_ERROR, RED("%s: event_anqp_req failed:%d\n"), __func__, ret);
		return -1;
	}
	return 0;
}


static int wdev_ap_event_wps_timeout(void *ctx, const char *iface)
{

#ifdef MTK_HOSTAPD_SUPPORT
	struct wifi_app *wapp = (struct wifi_app *)ctx;
	wapp_device_status *device_status = &wapp->map->device_status;
#endif

	DBGPRINT(RT_DEBUG_TRACE, "%s: %s\n", __func__, iface);

#ifdef MTK_HOSTAPD_SUPPORT
	DBGPRINT(RT_DEBUG_OFF, "wps_per_band (%d)\n", wapp->wps_per_band);
	if (wapp->is_mesh_wps_onboarding == FALSE) {
		DBGPRINT(RT_DEBUG_OFF, "%s: %s, not mesh wps onboarding, do not trigger other band's wps\n",
				__func__, iface);
		return 0;
	}

	if ((wapp->radio_count
#ifdef MAP_6E_SUPPORT
		- wapp->no_wps_on_6G
#endif
		-1) > wapp->wps_per_band)
		wps_ctrl_run_ap_wps(wapp);
	else {
		wapp->is_mesh_wps_onboarding = FALSE;
		device_status->status_fhbss = STATUS_FHBSS_WPS_FAILED;
		wapp_send_1905_msg(wapp, WAPP_DEVICE_STATUS, sizeof(wapp_device_status), (char *)device_status);
	}
#endif

	return 0;
}

static int wdev_ap_event_wps_success(void *ctx, const char *iface)
{
#ifdef MTK_HOSTAPD_SUPPORT
	struct wifi_app *wapp = (struct wifi_app *)ctx;
#endif

	DBGPRINT(RT_DEBUG_TRACE, "%s: %s\n", __func__, iface);
#ifdef MTK_HOSTAPD_SUPPORT
	wapp->is_mesh_wps_onboarding = FALSE;
#endif

	return 0;
}

static int wdev_ap_event_wps_new_ap_setting(void *ctx, const char *iface,
					const uint8_t *cred_attr, size_t cred_attr_len)
{
/*      struct wifi_app *wapp = (struct wifi_app *)ctx; */

	DBGPRINT(RT_DEBUG_TRACE, "%s: %s\n", __func__, iface);

	return 0;
}

static int wdev_ap_event_enrollee_seen(void *ctx, const char *iface,
					const uint8_t *addr, const uint8_t *uuid,
					const uint8_t *dev_type, uint32_t config_methods,
					uint32_t dev_password_id, uint32_t request_type,
					const char *dev_name)
{
/*      struct wifi_app *wapp = (struct wifi_app *)ctx; */

	DBGPRINT(RT_DEBUG_TRACE, "%s: %s\n", __func__, iface);

	return 0;
}

static int wdev_ap_event_wps_overlap(void *ctx, const char *iface)
{
/*      struct wifi_app *wapp = (struct wifi_app *)ctx; */

	DBGPRINT(RT_DEBUG_TRACE, "%s: %s\n", __func__, iface);

	return 0;
}

static int wdev_ap_event_wps_fail(void *ctx, const char *iface,
				int msg, int config_error, int reason)
{
/*      struct wifi_app *wapp = (struct wifi_app *)ctx; */
	int ret;
	struct wifi_app *wapp = (struct wifi_app *)ctx;

	DBGPRINT(RT_DEBUG_TRACE, "%s\n", __func__);

	if (!wapp || !wapp->event_ops || !wapp->event_ops->event_wps_failure)
		return 0;

	ret = wapp->event_ops->event_wps_failure(wapp,
				iface, msg, config_error, reason);

	if (ret != WAPP_SUCCESS) {
		DBGPRINT(RT_DEBUG_ERROR, RED("%s: event_wps_failure failed:%d\n"), __func__, ret);
		return -1;
	}
	return 0;
}

static int wdev_ap_event_eapol_complete(void *ctx, const char *iface, const u8 *addr, u8 multi_ap_ext)
{
#ifdef MTK_TK_HOSTAPD_SUPPORT
	struct wifi_app *wapp = (struct wifi_app *)ctx;

	DBGPRINT(RT_DEBUG_TRACE, "%s: %s\n", __func__, iface);

	if (!wapp || !wapp->event_ops || !wapp->event_ops->event_eapol_complete)
		return 0;

	wapp->event_ops->event_eapol_complete(wapp, iface, addr, multi_ap_ext);

	return 0;
#else
	return 0;
#endif /* MTK_TK_HOSTAPD_SUPPORT */
}

static int wdev_ap_event_wps_active(void *ctx, const char *iface)
{
/*      struct wifi_app *wapp = (struct wifi_app *)ctx; */

	DBGPRINT(RT_DEBUG_TRACE, "%s: %s\n", __func__, iface);

	return 0;
}

static int wdev_ap_event_wps_disable(void *ctx, const char *iface)
{
/*      struct wifi_app *wapp = (struct wifi_app *)ctx; */

	DBGPRINT(RT_DEBUG_TRACE, "%s: %s\n", __func__, iface);

	return 0;
}

static int wdev_ap_event_dfs_radar_detected(void *ctx, const char *iface,
	int freq, int ht_enabled, int chan_offset, int chan_width, int cf1, int cf2)
{
/*      struct wifi_app *wapp = (struct wifi_app *)ctx; */

	DBGPRINT(RT_DEBUG_TRACE, "%s: %s\n", __func__, iface);

	return 0;
}

static int wdev_ap_event_dfs_new_channel(void *ctx, const char *iface,
	int freq, int chan, int sec_chan)
{
/*      struct wifi_app *wapp = (struct wifi_app *)ctx; */

	DBGPRINT(RT_DEBUG_TRACE, "%s: %s\n", __func__, iface);

	return 0;
}

static int wdev_ap_event_dfs_cac_start(void *ctx, const char *iface,
				int freq, int chan, int sec_chan,
				int width, int seq0, int seq1, int cac_time)
{
/*      struct wifi_app *wapp = (struct wifi_app *)ctx; */

	DBGPRINT(RT_DEBUG_TRACE, "%s: %s\n", __func__, iface);

	return 0;
}

static int wdev_ap_event_dfs_cac_complete(void *ctx, const char *iface,
					int success, int freq, int ht_enabled,
					int chan_offset, int chan_width,
					int cf1, int cf2)
{
/*      struct wifi_app *wapp = (struct wifi_app *)ctx; */

	DBGPRINT(RT_DEBUG_TRACE, "%s: %s\n", __func__, iface);

	return 0;
}

static int wdev_ap_event_dfs_nop_finished(void *ctx, const char *iface,
	int freq, int ht_enabled, int chan_offset, int chan_width, int cf1, int cf2)
{
/*      struct wifi_app *wapp = (struct wifi_app *)ctx; */

	DBGPRINT(RT_DEBUG_TRACE, "%s: %s\n", __func__, iface);

	return 0;
}

static int wdev_ap_event_dfs_pre_cac_expired(void *ctx, const char *iface,
					int freq, int ht_enabled,
					int chan_offset, int chan_width,
					int cf1, int cf2)
{
/*      struct wifi_app *wapp = (struct wifi_app *)ctx; */

	DBGPRINT(RT_DEBUG_TRACE, "%s: %s\n", __func__, iface);

	return 0;
}

#ifdef MAP_R2
static int wdev_ap_event_wnm_notify_req(void *ctx, const char *iface,
					uint8_t *mac, uint8_t *payload,
					size_t payload_len)
{
	int ret;
	struct wifi_app *wapp = (struct wifi_app *)ctx;

	DBGPRINT(RT_DEBUG_TRACE, "%s\n", __func__);

	if (!wapp || !wapp->event_ops || !wapp->event_ops->event_wnm_notify)
		return 0;

	ret = wapp->event_ops->event_wnm_notify(wapp,
				iface, mac, (const char *)payload, payload_len);

	if (ret != WAPP_SUCCESS) {
		DBGPRINT(RT_DEBUG_ERROR, RED("%s: event_wnm_notify failed:%d\n"), __func__, ret);
		return -1;
	}
	return 0;
}
#endif /* MAP_R2 */

static int wdev_ap_event_beacon_report_cb(void *ctx, const char *iface,
					uint8_t *mac, uint8_t token,
					uint8_t report_mode, uint8_t *payload,
					size_t payload_len)
{
	struct wifi_app *wapp = (struct wifi_app *)ctx;

	DBGPRINT(RT_DEBUG_TRACE, "%s: %s\n", __func__, iface);

	if (!wapp || !wapp->event_ops || !wapp->event_ops->event_hapd_bcn_report)
		return 0;

	wapp->event_ops->event_hapd_bcn_report(wapp, iface,
				(u8 *)mac, (u8)token, (u8)report_mode,
				(u8 *)payload, payload_len);

	return 0;
}

static int wdev_ap_event_beacon_report_done_cb(void *ctx, const char *iface,
					uint8_t *mac, uint8_t token,
					uint8_t report_mode)
{
	struct wifi_app *wapp = (struct wifi_app *)ctx;

	DBGPRINT(RT_DEBUG_TRACE, "%s: %s\n", __func__, iface);

	if (!wapp || !wapp->event_ops || !wapp->event_ops->event_hapd_bcn_report_complete)
		return 0;

	wapp->event_ops->event_hapd_bcn_report_complete(wapp, iface,
				(u8 *)mac, (u8)token, (u8)report_mode);


	return 0;
}

#ifdef MTK_HOSTAPD_SUPPORT
static int wdev_ap_event_eap_failure(void *ctx, const char *iface, uint8_t *mac)
{
	int ret;
	struct wifi_app *wapp = (struct wifi_app *)ctx;

	DBGPRINT(RT_DEBUG_TRACE, "%s: %s\n", __func__, iface);

	if (!wapp || !wapp->event_ops || !wapp->event_ops->event_eap_failure)
		return 0;

	ret = wapp->event_ops->event_eap_failure(wapp, iface, mac);

	if (ret != WAPP_SUCCESS) {
		DBGPRINT(RT_DEBUG_ERROR, RED("%s: event_btm_rsp failed:%d\n"), __func__, ret);
		return -1;
	}
	return 0;
}
#ifdef WPS_UNCONFIG_FEATURE_SUPPORT
static int wdev_ap_event_wps_cred(void *ctx, const char *iface,
		uint8_t *payload, size_t payload_len)
{
	struct wifi_app *wapp = (struct wifi_app *)ctx;

	DBGPRINT(RT_DEBUG_INFO, "%s WPS creds received\n", __func__);

	if (!wapp || !wapp->event_ops || !wapp->event_ops->event_ap_wps_cred)
		return -1;

	wapp->event_ops->event_ap_wps_cred(wapp, iface,
			(u8 *)payload, payload_len);

	return 0;
}
#endif
#endif /* MTK_HOSTAPD_SUPPORT */

static int wdev_ap_event_dpp_uri_cb(void *ctx, const char *iface,
		uint8_t *sta_mac, uint8_t *payload, size_t payload_len)
{
	struct wifi_app *wapp = (struct wifi_app *)ctx;

	DBGPRINT(RT_DEBUG_TRACE, "%s: %s\n", __func__, iface);

	if (!wapp || !wapp->event_ops || !wapp->event_ops->event_hapd_wps_dpp_uri)
		return -1;

	wapp->event_ops->event_hapd_wps_dpp_uri(wapp, iface,
			sta_mac, (u8 *)payload, payload_len);

	return 0;
}

static wpactrl_cbs_t wdev_ap_wpactrl_cbs = {
	.event_sta_connected_cb		= wdev_ap_event_sta_connected,
	.event_sta_disconnected_cb	= wdev_ap_event_sta_disconnected,
	.event_wps_timeout_cb		= wdev_ap_event_wps_timeout,
	.event_wps_success_cb		= wdev_ap_event_wps_success,
	.event_wps_enrollee_seen_cb	= wdev_ap_event_enrollee_seen,
	.event_wps_new_ap_setting_cb	= wdev_ap_event_wps_new_ap_setting,
	.event_wps_overlap_cb		= wdev_ap_event_wps_overlap,
	.event_wps_fail_cb		= wdev_ap_event_wps_fail,
	.event_wps_active_cb		= wdev_ap_event_wps_active,
	.event_wps_disable_cb		= wdev_ap_event_wps_disable,
	.event_btm_query_cb		= wdev_ap_event_btm_query,
	.event_btm_resp_cb		= wdev_ap_event_btm_resp,
	.event_beacon_report_cb		= wdev_ap_event_beacon_report_cb,
	.event_beacon_report_done_cb	= wdev_ap_event_beacon_report_done_cb,
#ifdef MAP_R2
	.event_wnm_notify_req_cb	= wdev_ap_event_wnm_notify_req,
#endif /* MAP_R2 */
	.event_anqp_init_req_cb		= wdev_ap_event_anqp_init_req,
	.event_dfs_radar_detected_cb	= wdev_ap_event_dfs_radar_detected,
	.event_dfs_new_channel_cb	= wdev_ap_event_dfs_new_channel,
	.event_dfs_cac_start_cb		= wdev_ap_event_dfs_cac_start,
	.event_dfs_cac_complete_cb	= wdev_ap_event_dfs_cac_complete,
	.event_dfs_nop_finished_cb	= wdev_ap_event_dfs_nop_finished,
	.event_dfs_pre_cac_expired_cb	= wdev_ap_event_dfs_pre_cac_expired,
#ifdef MTK_HOSTAPD_SUPPORT
	.event_eap_failure_cb		= wdev_ap_event_eap_failure,
#ifdef WPS_UNCONFIG_FEATURE_SUPPORT
	.event_wps_cred_cb		= wdev_ap_event_wps_cred,
#endif
#endif /* MTK_HOSTAPD_SUPPORT */
	.event_wps_dpp_uri_cb	   = wdev_ap_event_dpp_uri_cb,
	.event_eapol_complete_cb	= wdev_ap_event_eapol_complete,
};

static void wdev_ap_wpactrl_event_receive(int sock, void *eloop_ctx, void *handle)
{
	int ret;
	struct wifi_app *wapp = (struct wifi_app *)eloop_ctx;

	DBGPRINT(RT_DEBUG_TRACE, "%s\n", __func__);

	ret = wpactrl_event_get(wapp->wpactrl_hostapd_ctx);
	if (ret < 0)
		DBGPRINT(RT_DEBUG_ERROR, "%s: wpactrl_event_get:%d\n", __func__, ret);
}


int wdev_ap_wpactrl_init(struct wifi_app *wapp)
{
	int ret;
	int fd;
	void *ctx = NULL;
	const char *wpactrl_path = "/var/run/hostapd/";
	const char *wpactrl_ifname = "global";
	int wpactrl_type = WPACTRL_TYPE_HOSTAPD;

	if (wapp->drv_mode != NL80211)
		return 0;

	ret = wpactrl_iface_open(&ctx,
				wpactrl_type,
				wpactrl_ifname,
				wpactrl_path,
				wapp,
				&wdev_ap_wpactrl_cbs,
				1);

	if (ret != 0) {
		err(DEBUG_CAT_INIT, "wpactrl_iface_open fail; path=%s; "
			"ifname=%s; type=HOSTAPD; ret=%d\n",
			wpactrl_path, wpactrl_ifname, ret);
		goto err;
	}

	fd = wpactrl_iface_fd_get(ctx);
	if (fd < 0) {
		err(DEBUG_CAT_INIT, "wpactrl_iface_fd_get fail; path=%s; "
			"ifname=%s; type=HOSTAPD; ret=%d\n",
			wpactrl_path, wpactrl_ifname, fd);
		goto err2;
	}

	ret = eloop_register_read_sock(fd, wdev_ap_wpactrl_event_receive, wapp, NULL);
	if (ret < 0) {
		err(DEBUG_CAT_INIT, "eloop_register_read_sock fail; ret=%d\n", ret);
		goto err2;
	}

	wapp->wpactrl_hostapd_fd = fd;
	wapp->wpactrl_hostapd_ctx = ctx;

	return 0;
err2:
	wpactrl_iface_close(ctx);
err:
	return -1;
}

void wdev_ap_wpactrl_deinit(struct wifi_app *wapp)
{
	if (wapp->wpactrl_hostapd_ctx)
		wpactrl_iface_close(wapp->wpactrl_hostapd_ctx);

	wapp->wpactrl_hostapd_ctx = NULL;
	wapp->wpactrl_hostapd_fd = -1;
}
#endif /* WPACTRL_SUPPORT */


#ifdef STANDARD_NL_CMD
int wdev_ap_create_sd_nl(struct wifi_app *wapp,
	struct dev_info *dev, struct phy_info *phy)
{
	struct wapp_dev *wdev = NULL;
	struct ap_dev *ap = NULL;

	if (!dev || !phy) {
		err(DEBUG_CAT_MISC, "invalid input params; dev=%p; phy=%p\n",
			dev, phy);
		return WAPP_INVALID_ARG;
	}

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, dev->ifindex);
	if (wdev == NULL)
		goto new_wdev;
	else if (wdev->p_dev == NULL)
		goto new_bss;
	else if (wdev->dev_type != WAPP_DEV_TYPE_AP) {
		err(DEBUG_CAT_MISC, "dev_type(%u) is not ap for %s\n",
			wdev->dev_type, wdev->ifname);
		/* check duplicate mac_address? */
		return WAPP_UNEXP;
	}

	/* already exsist */
	return WAPP_SUCCESS;

new_wdev:
	if (wapp_dev_create(wapp, dev->ifname, dev->ifindex, dev->mac) != WAPP_SUCCESS)
		err(DEBUG_CAT_MISC, "wapp_dev_create fail for %s\n", dev->ifname);
	return WAPP_SUCCESS;

new_bss:
	wdev->p_dev = os_zalloc(sizeof(struct ap_dev));
	if (!wdev->p_dev)
		return WAPP_RESOURCE_ALLOC_FAIL;

	ap = wdev->p_dev;
	wdev->dev_type = WAPP_DEV_TYPE_AP;
	os_memset(ap, 0, sizeof(struct ap_dev));
	if (dev->valid)
		ap->isActive = WAPP_BSS_START;
	wdev->ops = &wdev_ap_ops;
	wdev->radio = wapp_radio_update_or_create(wapp, phy->phy_id + 1, phy->phy_id);
	if (!wdev->radio)
		err(DEBUG_CAT_MISC, "radio not found for %s for phy_id(%d)\n", wdev->ifname, phy->phy_id);
	wdev->wireless_mode = phy->mode;
	wapp_reset_backhaul_config(wapp, wdev);

#ifdef MAP_EHT_SUPPORT
	struct wdev_eht_cap eht_cap;
#endif
#ifdef MTK_MLO_MAP_SUPPORT
	struct wdev_mlo_caps mlo_cap;
#endif
	wdev_misc_cap misc_cap;
	wdev_chn_info chn_list;
#ifndef MAP_6E_SUPPORT
	wdev_op_class_info op_class;
#else
	struct _wdev_op_class_info_ext op_class;
#endif
	wdev_bss_info bss_info;
#ifdef MTK_MLO_MAP_SUPPORT
	struct _wdev_mlo_info mlo_info;
#endif
	wdev_ap_metric ap_metrics;
	struct nop_channel_list_s nop_channels;
	unsigned short max_sta_num = 0;
	wdev_tx_power tx_pwr;
#ifdef MAP_R4_SPT
	struct wapp_mesh_sr_info spt_reuse;
#endif
#ifdef MAP_R4_SPT
	os_memset(&spt_reuse, 0, sizeof(struct wapp_mesh_sr_info));
#endif /*MAP_R4_SPT*/
	os_memset(&misc_cap, 0, sizeof(wdev_misc_cap));
	os_memset(&chn_list, 0, sizeof(wdev_chn_info));
#ifndef MAP_6E_SUPPORT
	os_memset(&op_class, 0, sizeof(wdev_op_class_info));
#else
	os_memset(&op_class, 0, sizeof(struct _wdev_op_class_info_ext));
#endif
	os_memset(&bss_info, 0, sizeof(wdev_bss_info));
#ifdef MTK_MLO_MAP_SUPPORT
	os_memset(&mlo_info, 0, sizeof(struct _wdev_mlo_info));
#endif
	os_memset(&ap_metrics, 0, sizeof(wdev_ap_metric));
	os_memset(&nop_channels, 0, sizeof(struct nop_channel_list_s));
	os_memset(&tx_pwr, 0, sizeof(wdev_tx_power));

	wapp_get_misc_cap(wapp, (char *)dev->ifname, (char *)&misc_cap, sizeof(wdev_misc_cap));
	if (phy->ht_set) {
		assign_wdev_ht_cap(wapp, dev, phy);
	} else {
		wdev_ht_cap ht_cap;

		os_memset(&ht_cap, 0, sizeof(wdev_ht_cap));
		notice(DEBUG_CAT_MISC, "no ht cap; assign vendor ht for phy-%d\n", phy->phy_id);
		wapp_get_ht_cap(wapp, (char *)dev->ifname, (char *)&ht_cap, sizeof(wdev_ht_cap));
	}
	if (phy->vht_set) {
		assign_wdev_vht_cap(wapp, dev, phy);
	} else {
		wdev_vht_cap vht_cap;

		os_memset(&vht_cap, 0, sizeof(wdev_vht_cap));
		notice(DEBUG_CAT_MISC, "no vht cap; assign vendor vht for phy-%d\n", phy->phy_id);
		wapp_get_vht_cap(wapp, (char *)dev->ifname, (char *)&vht_cap, sizeof(wdev_vht_cap));
	}

	if (phy->he_capab.he_supported)
		assign_wdev_he_cap(wapp, dev, phy);
#ifdef MAP_R3_WF6
	if (phy->he_capab.he_supported)
		assign_wdev_wf6_cap(wapp, dev, phy);
#endif
#ifdef MAP_EHT_SUPPORT
	wapp_get_eht_cap(wapp, (char *)dev->ifname, (char *)&eht_cap, sizeof(struct wdev_eht_cap));
#endif
#ifdef MTK_MLO_MAP_SUPPORT
	wapp_get_mlo_cap(wapp, (char *)dev->ifname, (char *)&mlo_cap, sizeof(struct wdev_mlo_caps));
#endif
#ifdef MAP_R4_SPT
	wapp_get_spt_reuse_req(wapp, (char *)dev->ifname, (char *)&spt_reuse, sizeof(struct wapp_mesh_sr_info)); /* Todo */
#endif /*MAP_R4_SPT*/
	// assign_wdev_chan_list(wapp, dev, phy);
	wapp_get_chan_list(wapp, (char *)dev->ifname, (char *)&chn_list, sizeof(wdev_chn_info));
	wapp_get_nop_channels(wapp, (char *)dev->ifname, (char *)&nop_channels, sizeof(nop_channels));

#ifndef MAP_6E_SUPPORT
	wapp_get_op_class(wapp, (char *)dev->ifname, (char *)&op_class, sizeof(wdev_op_class_info));
#else
	wapp_get_op_class(wapp, (char *)dev->ifname, (char *)&op_class, sizeof(struct _wdev_op_class_info_ext));
#endif
	assign_wdev_chan_list(wapp, dev, phy);
	if (dev->valid)
		assign_wdev_bss_info(wapp, dev, phy);
	wapp_get_ap_metrics(wapp, (char *)dev->ifname, (char *)&ap_metrics, sizeof(wdev_ap_metric));
	wapp_get_max_sta_num(wapp, (char *)dev->ifname, (char *)&max_sta_num, sizeof(max_sta_num));
	wapp_get_tx_pwr(wapp, (char *)dev->ifname, (char *)&tx_pwr, sizeof(wdev_tx_power));
	wapp_set_ap_config(wapp, wdev);

	wdev->wapp = wapp;
	wdev->valid = 1;

	return WAPP_SUCCESS;
}
#endif

int wdev_ap_create(struct wifi_app *wapp, wapp_dev_info *dev_info)
{
	struct wapp_dev *wdev = NULL;
	struct ap_dev *ap = NULL;

	DBGPRINT(RT_DEBUG_TRACE, "%s\n", __func__);
	if (!wapp || !dev_info) {
		return WAPP_INVALID_ARG;
	}

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, dev_info->ifindex);

	if (wdev == NULL) {
		wdev = wapp_dev_list_lookup_by_mac_and_type(wapp, dev_info->mac_addr, WAPP_DEV_TYPE_AP);
		if (wdev) {
			DBGPRINT(RT_DEBUG_OFF, "Found wdev %s with diff ifindex %d, update to new %d\n",
				wdev->ifname, wdev->ifindex, dev_info->ifindex);
			wdev->ifindex = dev_info->ifindex;
			goto new_setting;
		} else
			goto new_wdev;
	} else if (wdev->p_dev == NULL)
		goto new_bss;
	else if (wdev->dev_type != WAPP_DEV_TYPE_AP) {
		DBGPRINT_RAW(RT_DEBUG_OFF, "Error! dev_type = %u\n", wdev->dev_type);
		/* check duplicate mac_address? */
		return WAPP_UNEXP;
#ifdef EM_PLUS_SUPPORT
	} else if (((struct ap_dev *)wdev->p_dev)->isActive == WAPP_BSS_STOP) {
		DBGPRINT_RAW(RT_DEBUG_OFF, "Just start BSS= %s\n", wdev->ifname);
		goto new_setting;
#endif
	} else {
		/* already exsist */
		return WAPP_SUCCESS;
	}

new_wdev:
	if (wapp_dev_create(wapp, (char *)dev_info->ifname, dev_info->ifindex, dev_info->mac_addr) != WAPP_SUCCESS)
		DBGPRINT_RAW(RT_DEBUG_OFF, "Warning! wdev create failed.\n");
	return WAPP_SUCCESS;

new_bss:
	wdev->p_dev = os_zalloc(sizeof(struct ap_dev));

	if (!wdev->p_dev)
		return WAPP_RESOURCE_ALLOC_FAIL;

new_setting:
	ap = wdev->p_dev;
	wdev->dev_type = WAPP_DEV_TYPE_AP;
	/* free client list */
	wdev_ap_client_table_release(wapp, ap);
	os_memset(ap, 0, sizeof(struct ap_dev));
	/*set the default value*/
	ap->isActive = dev_info->dev_active;
	wdev->ops = &wdev_ap_ops;

	if (!wdev->radio)
		wdev->radio = wapp_radio_update_or_create(wapp, dev_info->adpt_id, dev_info->radio_id);

	if (!wdev->radio) {
		DBGPRINT_RAW(RT_DEBUG_OFF, "Warning! radio not found.\n");
	}
	wdev->wireless_mode = dev_info->wireless_mode;
	wapp_reset_backhaul_config(wapp, wdev);

	/* get max table size to build client table */
#if 0
	wapp_query_wdev_by_req_id(wapp, (char *)dev_info->ifname, WAPP_MISC_CAP_QUERY_REQ);
	wapp_query_wdev_by_req_id(wapp, (char *)dev_info->ifname, WAPP_HT_CAP_QUERY_REQ);
	wapp_query_wdev_by_req_id(wapp, (char *)dev_info->ifname, WAPP_VHT_CAP_QUERY_REQ);
	wapp_query_wdev_by_req_id(wapp, (char *)dev_info->ifname, WAPP_CHN_LIST_QUERY_REQ);
	wapp_query_wdev_by_req_id(wapp, (char *)dev_info->ifname, WAPP_OP_CLASS_QUERY_REQ);
	wapp_query_wdev_by_req_id(wapp, (char *)dev_info->ifname, WAPP_BSS_INFO_QUERY_REQ);
	wapp_query_wdev_by_req_id(wapp, (char *)dev_info->ifname, WAPP_AP_METRIC_QUERY_REQ);
#else
	wdev_ht_cap ht_cap;
	wdev_vht_cap vht_cap;
#ifdef MAP_EHT_SUPPORT
	struct wdev_eht_cap eht_cap;
#endif
#ifdef MTK_MLO_MAP_SUPPORT
	struct wdev_mlo_caps mlo_cap;
#endif
	wdev_misc_cap misc_cap;
	wdev_chn_info chn_list;
#ifndef MAP_6E_SUPPORT
	wdev_op_class_info op_class;
#else
	struct _wdev_op_class_info_ext op_class;
#endif
	wdev_bss_info bss_info;
#ifdef MTK_MLO_MAP_SUPPORT
	 struct _wdev_mlo_info mlo_info;
#endif
	wdev_ap_metric ap_metrics;
	struct nop_channel_list_s nop_channels;
	u32 chip_id = 0;
	u16 max_sta_num = 0, MaxStaAllowed = 0;
	wdev_he_cap he_cap;
	wdev_tx_power tx_pwr;
#ifdef MAP_R4_SPT
	struct wapp_mesh_sr_info spt_reuse;
#endif
#ifdef MAP_R3_WF6
	wdev_wf6_cap_roles wf6_cap;
	os_memset(&wf6_cap, 0, sizeof(wdev_wf6_cap_roles));
#endif /*MAP_R3_WF6*/

#ifdef MAP_R4_SPT
	os_memset(&spt_reuse, 0, sizeof(struct wapp_mesh_sr_info));
#endif /*MAP_R4_SPT*/

	os_memset(&he_cap, 0, sizeof(wdev_he_cap));
	os_memset(&ht_cap, 0, sizeof(wdev_ht_cap));
	os_memset(&vht_cap, 0, sizeof(wdev_vht_cap));
	os_memset(&misc_cap, 0, sizeof(wdev_misc_cap));
	os_memset(&chn_list, 0, sizeof(wdev_chn_info));
#ifndef MAP_6E_SUPPORT
	os_memset(&op_class, 0, sizeof(wdev_op_class_info));
#else
	os_memset(&op_class, 0, sizeof(struct _wdev_op_class_info_ext));
#endif
	os_memset(&bss_info, 0, sizeof(wdev_bss_info));
#ifdef MTK_MLO_MAP_SUPPORT
	os_memset(&mlo_info, 0, sizeof(struct _wdev_mlo_info));
#endif
	os_memset(&ap_metrics, 0, sizeof(wdev_ap_metric));
	os_memset(&nop_channels, 0, sizeof(struct nop_channel_list_s));
	os_memset(&tx_pwr, 0, sizeof(wdev_tx_power));

	wapp_get_misc_cap(wapp, (char *)dev_info->ifname, (char *)&misc_cap, sizeof(wdev_misc_cap));
	if (wapp->drv_mode == WEXT)
		wdev_misc_cap_query_rsp_handle(wapp, dev_info->ifindex, &misc_cap);

	wapp_get_ht_cap(wapp, (char *)dev_info->ifname, (char *)&ht_cap, sizeof(wdev_ht_cap));
	if (wapp->drv_mode == WEXT)
		wdev_ht_cap_query_rsp_handle(wapp, dev_info->ifindex, &ht_cap);

	wapp_get_vht_cap(wapp, (char *)dev_info->ifname, (char *)&vht_cap, sizeof(wdev_vht_cap));
	if (wapp->drv_mode == WEXT)
		wdev_vht_cap_query_rsp_handle(wapp, dev_info->ifindex, &vht_cap);

	wapp_get_he_cap(wapp, (char *)dev_info->ifname, (char *)&he_cap, sizeof(wdev_he_cap));
	if (wapp->drv_mode == WEXT)
		wdev_he_cap_query_rsp_handle(wapp, dev_info->ifindex, &he_cap);
#ifdef MAP_EHT_SUPPORT
	wapp_get_eht_cap(wapp, (char *)dev_info->ifname, (char *)&eht_cap, sizeof(struct wdev_eht_cap));
	if (wapp->drv_mode == WEXT)
		wdev_eht_cap_query_rsp_handle(wapp, dev_info->ifindex, &eht_cap);
#endif
#ifdef MTK_MLO_MAP_SUPPORT
	wapp_get_mlo_cap(wapp, (char *)dev_info->ifname, (char *)&mlo_cap, sizeof(struct wdev_mlo_caps));
#endif
#ifdef MAP_R3_WF6
	wapp_get_wf6_cap(wapp, (char *)dev_info->ifname, (char *)&wf6_cap, sizeof(wdev_wf6_cap_roles));
	if (wapp->drv_mode == WEXT)
		wdev_wf6_cap_query_rsp_handle(wapp, dev_info->ifindex, &wf6_cap);
#endif /*MAP_R3_WF6*/

#ifdef MAP_R4_SPT
	wapp_get_spt_reuse_req(wapp, (char *)dev_info->ifname, (char *)&spt_reuse, sizeof(struct wapp_mesh_sr_info)); /* Todo */
	if (wapp->drv_mode == WEXT)
		wdev_spt_reuse_query_rsp_handle(wapp, dev_info->ifindex, &spt_reuse);
#endif /*MAP_R4_SPT*/

	wapp_get_chan_list(wapp, (char *)dev_info->ifname, (char *)&chn_list, sizeof(wdev_chn_info));
	if (wapp->drv_mode == WEXT)
		wdev_chn_list_query_rsp_handle(wapp, dev_info->ifindex, &chn_list);

	wapp_get_nop_channels(wapp, (char *)dev_info->ifname, (char *)&nop_channels, sizeof(nop_channels));
	if (wapp->drv_mode == WEXT)
		wdev_handle_nop_channels(&nop_channels);
#ifndef MAP_6E_SUPPORT
	wapp_get_op_class(wapp, (char *)dev_info->ifname, (char *)&op_class, sizeof(wdev_op_class_info));
#else
	wapp_get_op_class(wapp, (char *)dev_info->ifname, (char *)&op_class, sizeof(struct _wdev_op_class_info_ext));
#endif
	if (wapp->drv_mode == WEXT)
		wdev_op_class_query_rsp_handle(wapp, dev_info->ifindex, &op_class);

	wapp_get_bss_info(wapp, (char *)dev_info->ifname, (char *)&bss_info, sizeof(wdev_bss_info));
	if (wapp->drv_mode == WEXT)
		wdev_bss_info_query_rsp_handle(wapp, dev_info->ifindex, &bss_info);

	wapp_get_ap_metrics(wapp, (char *)dev_info->ifname, (char *)&ap_metrics, sizeof(wdev_ap_metric));
	if (wapp->drv_mode == WEXT)
		wdev_ap_metric_query_rsp_handle(wapp, dev_info->ifindex, &ap_metrics);
	wapp_get_chip_id(wapp, (char *)dev_info->ifname, (char *)&chip_id, sizeof(chip_id));
	if (wapp->drv_mode == WEXT)
		wdev->radio->chip_id = chip_id;
	wapp_get_max_sta_num(wapp, (char *)dev_info->ifname, (char *)&max_sta_num, sizeof(max_sta_num));
	if (wapp->drv_mode == WEXT) {
		MaxStaAllowed = wapp->map->max_client_cnt;
		if (max_sta_num <= 0 || max_sta_num > wapp->map->max_client_cnt)
			wapp->map->max_client_cnt = MaxStaAllowed;
		else
			wapp->map->max_client_cnt = max_sta_num;
	}

	wapp_get_tx_pwr(wapp, (char *)dev_info->ifname, (char *)&tx_pwr, sizeof(wdev_tx_power));
	if (wapp->drv_mode == WEXT)
		wdev_tx_pwr_query_rsp_handle(wapp, dev_info->ifindex, &tx_pwr);

#endif
	wapp_set_ap_config(wapp, wdev);

	wdev->wapp = wapp;

	wdev->valid = 1;

	return WAPP_SUCCESS;
}

static int wdev_ap_del(struct wifi_app *wapp, struct wapp_dev *wdev)
{
	struct ap_dev *ap = NULL;

	DBGPRINT(RT_DEBUG_TRACE, "%s\n", __func__);
	if (!wapp || !wdev) {
		return WAPP_INVALID_ARG;
	}

	ap = (struct ap_dev *)wdev->p_dev;
	if (ap) {
		/* free client list */
		wdev_ap_client_table_release(wapp, ap);
		/* free ap */
		os_free(ap);
	}

	wdev->p_dev = NULL;

	return WAPP_SUCCESS;
}

int wdev_ap_update(struct wifi_app *wapp, struct ap_dev *ap, u8 action, u32 len, void *data)
{
	DBGPRINT(RT_DEBUG_TRACE, "%s\n", __func__);
	if (!wapp || !ap) {
		return WAPP_INVALID_ARG;
	}

	switch (action) {
#if 0
		case MBO_CDC_UPDATE:
		{
			if (len == sizeof(u8))
				sta->cell_data_cap = *((u8 *) data);
			break;
		}

		case MBO_NPC_APPEND:
		{
			if (len == sizeof( struct non_pref_ch)){
				struct non_pref_ch_entry *npc_entry;

				npc_entry = os_zalloc(sizeof(struct non_pref_ch_entry));
				os_memcpy(&npc_entry->npc, data, len);
				dl_list_add_tail(&sta->non_pref_ch_list, &npc_entry->list);
			}

			break;
		}

		case MBO_BSSID_UPDATE:
		{
			if (len == MAC_ADDR_LEN){
				os_memcpy(&sta->bssid, data, len);
			}

			break;
		}

		case MBO_AKM_UPDATE:
		{
			if (len == sizeof(u32))
				sta->akm = *((u32 *) data);
			break;
		}

		case MBO_CIPHER_UPDATE:
		{
			if (len == sizeof(u32))
				sta->cipher = *((u32 *) data);
			break;
		}
#endif
	default:
		break;
	}

	return WAPP_SUCCESS;
}

int wdev_ap_block_list_init(struct wifi_app *wapp, struct ap_dev *ap)
{
	int i = 0;

	if (ap->max_num_of_block_cli) {
		for (i = 0; i < ap->max_num_of_block_cli; i++)
			os_memset(ap->block_table[i].mac_addr, 0, MAC_ADDR_LEN);
	} else {
		err(DEBUG_CAT_MISC, "max_num_of_block_cli is zero\n");
		return WAPP_INVALID_ARG;
	}

	return WAPP_SUCCESS;
}

int wapp_del_block_sta(struct ap_dev *ap, unsigned char *sta_addr)
{
	int i = 0;
	int num = ap->max_num_of_block_cli;

	DBGPRINT(RT_DEBUG_TRACE, "%s\n", __func__);
	for (i = 0; i < num; i++) {
		if (!os_memcmp(ap->block_table[i].mac_addr, sta_addr, MAC_ADDR_LEN)) {
			os_memset(ap->block_table[i].mac_addr, 0, MAC_ADDR_LEN);
			ap->block_table[i].valid_period = 0;
			ap->num_of_block_cli--;
			break;
		}
	}

	return WAPP_SUCCESS;
}

int wapp_add_block_sta(struct wifi_app *wapp, struct ap_dev *ap, u8 *sta_addr, u16 valid_period)
{
	struct wapp_block_sta *block_sta = NULL;
	int i = 0;

	DBGPRINT(RT_DEBUG_TRACE, "%s\n", __func__);
	if (!wapp || !ap) {
		return WAPP_INVALID_ARG;
	}

	if (ap->num_of_block_cli >= ap->max_num_of_block_cli) {
		DBGPRINT(RT_DEBUG_ERROR, "Cli number  is more than table size\n");
		return WAPP_RESOURCE_ALLOC_FAIL;
	}

	/* Find out the First Avail Entry */
	for (i = 0; i < ap->max_num_of_block_cli; i++) {
		if (is_all_zero_mac(ap->block_table[i].mac_addr)) {
			block_sta = &ap->block_table[i];
			break;
		}
	}
	if (!block_sta) {
		DBGPRINT(RT_DEBUG_ERROR, "Cli number  is more than table size\n");
		return WAPP_RESOURCE_ALLOC_FAIL;
	}

	os_memcpy(block_sta->mac_addr, sta_addr, MAC_ADDR_LEN);
	block_sta->valid_period = valid_period;

	ap->num_of_block_cli++;
	return WAPP_SUCCESS;
}

struct wapp_block_sta *wdev_ap_block_list_lookup(struct wifi_app *wapp, struct ap_dev *ap, u8 *mac_addr)
{
	int i;
	struct wapp_block_sta *block_sta = NULL;

	DBGPRINT(RT_DEBUG_TRACE, "%s\n", __func__);
	if (!wapp || !ap || !mac_addr)
		return block_sta;

	for (i = 0; i < ap->max_num_of_block_cli; i++) {
		if (os_memcmp(ap->block_table[i].mac_addr, mac_addr, MAC_ADDR_LEN) == 0) {
			block_sta = &ap->block_table[i];
			break;
		}
	}

	return block_sta;
}

int wdev_ap_client_table_create(struct wifi_app *wapp, struct ap_dev *ap)
{
	u32 mem_size;

	mem_size = (sizeof(struct wapp_sta *) * CLIENT_TABLE_SIZE);
	ap->client_table = os_zalloc(mem_size);
	if (!ap->client_table) {
		err(DEBUG_CAT_MISC, "alloc client_table fail; size=%u\n", mem_size);
		return WAPP_RESOURCE_ALLOC_FAIL;
	}
	os_memset(ap->client_table, 0, mem_size);

	return WAPP_SUCCESS;
}

int wdev_ap_client_table_release(struct wifi_app *wapp, struct ap_dev *ap)
{
	int i;

	DBGPRINT(RT_DEBUG_TRACE, "%s\n", __func__);
	if (!wapp || !ap) {
		return WAPP_INVALID_ARG;
	}

	if (!ap->client_table) {
		return WAPP_SUCCESS;
	}

	/* free sta entries */
	for (i = 0; i < CLIENT_TABLE_SIZE; i++) {
		if (ap->client_table[i] != NULL) {
			os_free(ap->client_table[i]);
			ap->client_table[i] = NULL;
		}
	}

	/* free table itself */
	os_free(ap->client_table);
	ap->client_table = NULL;

	return WAPP_SUCCESS;
}

int wapp_client_create(struct wifi_app *wapp, struct ap_dev *ap, struct wapp_sta **new_sta)
{
	int i;
	struct wapp_sta *sta_temp = NULL;
	*new_sta = NULL;

	DBGPRINT(RT_DEBUG_TRACE, "%s\n", __func__);
	if (!wapp || !ap) {
		return WAPP_INVALID_ARG;
	}

	if (!ap->client_table) {
		return WAPP_NOT_INITIALIZED;
	}

	for (i = 0; i < CLIENT_TABLE_SIZE; i++) {
		/* if there is an old entry, use it */
		sta_temp = ap->client_table[i];
		if (sta_temp && (sta_temp->sta_status == WAPP_STA_INVALID)) {
			*new_sta = sta_temp;
			break;
		} else if (!sta_temp) {
			/* alloc a new entry */
			ap->client_table[i] = os_zalloc(sizeof(struct wapp_sta));
			*new_sta = ap->client_table[i];
			break;
		}
	}

	if ((*new_sta) == NULL) {
		/* find the oldest one*/
		*new_sta = ap->client_table[0];
		for (i = 1; i < CLIENT_TABLE_SIZE; i++) {
			sta_temp = ap->client_table[i];
			if (os_time_before(&sta_temp->last_update_time, &(*new_sta)->last_update_time))
				*new_sta = sta_temp;
		}
		os_memset(*new_sta, 0, sizeof(struct wapp_sta));

	} else {
		ap->num_of_clients++;
	}

	return WAPP_SUCCESS;
}

int wapp_client_clear(struct wifi_app *wapp, struct ap_dev *ap, u8 *mac_addr)
{
	struct wapp_sta *sta = NULL;

	DBGPRINT(RT_DEBUG_TRACE, "%s\n", __func__);
	sta = wdev_ap_client_list_lookup(wapp, ap, mac_addr);

	if (sta) {
		os_memset(sta->mac_addr, 0, MAC_ADDR_LEN);
		sta->sta_status = WAPP_STA_INVALID;
		sta->assoc_time = 0;
		if (sta->beacon_report) {
			free(sta->beacon_report);
			sta->beacon_report = NULL;
		}
		/* reuse the memory, don't free. */
	}

	ap->num_of_clients--;

	return WAPP_SUCCESS;
}

void wapp_fill_client_info(struct wifi_app *wapp, wapp_client_info *cli_info, struct wapp_sta *sta)
{
	DBGPRINT(RT_DEBUG_TRACE, "%s\n", __func__);
	COPY_MAC_ADDR(sta->mac_addr, cli_info->mac_addr);
	COPY_MAC_ADDR(sta->bssid, cli_info->bssid);
	sta->sta_status = cli_info->sta_status;
	sta->assoc_time = cli_info->assoc_time;
	sta->assoc_req_len = cli_info->assoc_req_len;
	if (sta->assoc_req_len > ASSOC_REQ_LEN_MAX)
		sta->assoc_req_len = ASSOC_REQ_LEN_MAX;
	os_memcpy(&sta->cli_caps, &cli_info->cli_caps, sizeof(struct map_cli_cap));
	sta->downlink = cli_info->downlink;
	sta->uplink = cli_info->uplink;
	sta->uplink_rssi = cli_info->uplink_rssi;
	sta->bBSSMantSupport = (cli_info->cli_caps.btm_capable == 1 ? TRUE : FALSE);
#ifdef COSR_SUPPORT
	sta->is_11k = (cli_info->cli_caps.rrm_capable == 1 ? TRUE : FALSE);
#endif /* COSR_SUPPORT */
	sta->bLocalSteerDisallow = cli_info->bLocalSteerDisallow;
	sta->bBTMSteerDisallow = cli_info->bBTMSteerDisallow;
	os_get_time(&sta->last_update_time);

	/*traffic stats*/
	sta->bytes_sent = cli_info->bytes_sent;
	sta->bytes_received = cli_info->bytes_received;
	sta->packets_sent = cli_info->packets_sent;
	sta->packets_received = cli_info->packets_received;
	sta->tx_packets_errors = cli_info->tx_packets_errors;
	sta->rx_packets_errors = cli_info->rx_packets_errors;
	sta->retransmission_count = cli_info->retransmission_count;
	sta->link_availability = cli_info->link_availability;
	sta->tx_tp = cli_info->tx_tp;
	sta->rx_tp = cli_info->rx_tp;
	sta->is_APCLI = cli_info->is_APCLI;

	debug(DEBUG_CAT_EVENT, "wapp-sta(apcli:%d): "MACSTR", rssi=%d, tx-rate=%u,"
		"rx-rate=%u, tx-bytes=%u, rx-bytes=%u, tx-pkt=%u, rx-pkt=%u, tx-err=%u, rx-err=%u,"
		"retrans=%u, link_a=%u, tx_tp=%u, rx_tp=%u\n", sta->is_APCLI, MAC2STR(sta->mac_addr),
		sta->uplink_rssi, sta->downlink, sta->uplink, sta->bytes_sent, sta->bytes_received,
		sta->packets_sent, sta->packets_received, sta->tx_packets_errors, sta->rx_packets_errors,
		sta->retransmission_count, sta->link_availability, sta->tx_tp, sta->rx_tp);

	/* MLD Specific data */
#ifdef MTK_MLO_MAP_SUPPORT
	sta->mlo_join = cli_info->mlo_join;
	sta->EmlsrBitmap = cli_info->EmlsrBitmap;
	sta->mlo.mlo_en = cli_info->mlo.mlo_en;
	sta->mlo.is_setup_link_entry = cli_info->mlo.is_setup_link_entry;
	os_memcpy(sta->mlo.mld_info.addr, cli_info->mlo.mld_info.addr, MAC_ADDR_LEN);
	sta->mlo.mld_info.mld_sta_idx = cli_info->mlo.mld_info.mld_sta_idx;
	sta->mlo.mld_info.nsep = cli_info->mlo.mld_info.nsep;
	sta->mlo.mld_info.emlmr = cli_info->mlo.mld_info.emlmr;
	sta->mlo.mld_info.emlsr = cli_info->mlo.mld_info.emlsr;
	sta->mlo.mld_info.eml_cap = cli_info->mlo.mld_info.eml_cap;
	sta->mlo.mld_info.setup_link_wcid = cli_info->mlo.mld_info.setup_link_wcid;
	sta->mlo.mld_info.setup_link_id = cli_info->mlo.mld_info.setup_link_id;
	sta->mlo.mld_info.link_num = cli_info->mlo.mld_info.link_num;
	sta->mlo.mld_info.valid = cli_info->mlo.mld_info.valid;
	sta->mlo.link_info.link_id = cli_info->mlo.link_info.link_id;
	sta->mlo.link_info.tid_bitmap_dl = cli_info->mlo.link_info.tid_bitmap_dl;
	sta->mlo.link_info.tid_bitmap_ul = cli_info->mlo.link_info.tid_bitmap_ul;
#endif
}

struct wapp_sta *wdev_ap_client_list_lookup_for_all_bss(struct wifi_app *wapp, const u8 *mac_addr)
{
	struct wapp_sta *cli = NULL;
	struct wapp_dev *wdev = NULL, *wdev_temp = NULL;
	struct dl_list *dev_list;
	struct ap_dev *ap = NULL;

	DBGPRINT(RT_DEBUG_TRACE, "func is %s\n", __func__);
	if (!wapp || !mac_addr)
		return cli;

	dev_list = &wapp->dev_list;

	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list)
	{
		if (wdev->dev_type == WAPP_DEV_TYPE_AP)
			ap = (struct ap_dev *)wdev->p_dev;
		else
			continue;

		cli = wdev_ap_client_list_lookup(wapp, ap, mac_addr);
		if (cli) {
			return cli;
		}
	}

	return cli;
}

#ifdef MAP_R3
struct wapp_dev *wdev_sta_lookup_for_all_bss(struct wifi_app *wapp, const u8 *mac_addr)
{
	struct wapp_sta *cli = NULL;
	struct wapp_dev *wdev = NULL, *wdev_temp = NULL;
	struct dl_list *dev_list;
	struct ap_dev *ap = NULL;

	DBGPRINT(RT_DEBUG_TRACE, "func is %s\n", __func__);
	if (!wapp || !mac_addr)
		return NULL;

	dev_list = &wapp->dev_list;

	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list)
	{
		if (wdev->dev_type == WAPP_DEV_TYPE_AP)
			ap = (struct ap_dev *)wdev->p_dev;
		else
			continue;

		cli = wdev_ap_client_list_lookup(wapp, ap, mac_addr);
		if (cli) {
			DBGPRINT(RT_DEBUG_OFF, "STA is connected to wdev:%s so disconnecting..\n", wdev->ifname);
			map_trigger_deauth(wapp, wdev->ifname, (unsigned char *)mac_addr);
			return wdev;
		}
	}
	DBGPRINT(RT_DEBUG_TRACE, "STA is not connected to any wdev\n");
	return NULL;
}
#endif /* MAP_R3 */

struct wapp_dev *wdev_sta_lookup_for_all_bss_cosr(struct wifi_app *wapp, const u8 *mac_addr)
{
	struct wapp_sta *cli = NULL;
	struct wapp_dev *wdev = NULL, *wdev_temp = NULL;
	struct dl_list *dev_list;
	struct ap_dev *ap = NULL;

	DBGPRINT(RT_DEBUG_TRACE, "func is %s\n", __func__);
	if (!wapp || !mac_addr)
		return NULL;

	dev_list = &wapp->dev_list;

	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
		if (wdev->dev_type == WAPP_DEV_TYPE_AP)
			ap = (struct ap_dev *)wdev->p_dev;
		else
			continue;

		cli = wdev_ap_client_list_lookup(wapp, ap, mac_addr);
		if (cli) {
			DBGPRINT(RT_DEBUG_INFO, "found wdev: %s\n", wdev->ifname);
			return wdev;
		}
	}
	DBGPRINT(RT_DEBUG_ERROR, "STA is not connected to any wdev\n");
	return NULL;
}

struct wapp_sta *wdev_ap_client_list_lookup(struct wifi_app *wapp, struct ap_dev *ap, const u8 *mac_addr)
{
	int i;
	struct wapp_sta *cli = NULL;

	DBGPRINT(RT_DEBUG_TRACE, "%s\n", __func__);
	if (!wapp || !ap || !mac_addr)
		return cli;

	if (!ap->client_table)
		return cli;

	for (i = 0; i < CLIENT_TABLE_SIZE; i++) {
		cli = ap->client_table[i];
		if (cli && (os_memcmp(cli->mac_addr, mac_addr, MAC_ADDR_LEN) == 0))
			return cli;
	}

	return NULL;
}

int wdev_show_wapp_sta_info(struct wapp_sta *cli)
{
	struct non_pref_ch_entry *npc_entry;

	DBGPRINT(RT_DEBUG_TRACE, "%s\n", __func__);
	if (!cli)
		return WAPP_INVALID_ARG;

#ifdef MTK_MLO_MAP_SUPPORT
	DBGPRINT_RAW(RT_DEBUG_OFF, "is_MLO:(%u) MLO_en(%u) setup_link(%u)\n"
		"MLD_MAC:" MACSTR"\n"
		"MLD_sta_idx(%u) nsep(%u) emlmr(%u) emlsr(%u)\n"
		"eml_cap(%u) setup_link_wcid(%u) setup_link_id(%u)\n"
		"link_num(%u) valid(%u) link_id(%u), tid_bitmap_dl(%u), tid_bitmap_ul(%u)\n"
		"emlsrbitmap(%u)\n", cli->mlo_join, cli->mlo.mlo_en, cli->mlo.is_setup_link_entry,
		PRINT_MAC(cli->mlo.mld_info.addr), cli->mlo.mld_info.mld_sta_idx,
			cli->mlo.mld_info.nsep, cli->mlo.mld_info.emlmr, cli->mlo.mld_info.emlsr,
			cli->mlo.mld_info.eml_cap, cli->mlo.mld_info.setup_link_wcid, cli->mlo.mld_info.setup_link_id,
			cli->mlo.mld_info.link_num, cli->mlo.mld_info.valid, cli->mlo.link_info.link_id,
			cli->mlo.link_info.tid_bitmap_dl, cli->mlo.link_info.tid_bitmap_ul, cli->EmlsrBitmap);
#endif

	DBGPRINT_RAW(RT_DEBUG_OFF,
		     "\t mac_addr = " MACSTR "\n"
		     "\t bssid = " MACSTR "\n"
		     "\t status = %u\n"
		     "\t assoc_time = %u\n"
		     "\t downlink = %u\n"
		     "\t uplink = %u\n"
		     "\t rssi = %d\n"
		     "\t bytes_sent = %u\n"
		     "\t bytes_received = %u\n"
		     "\t packets_sent = %u\n"
		     "\t packets_received = %u\n"
		     "\t tx_packets_errors = %u\n"
		     "\t rx_packets_errors = %u\n"
		     "\t retransmission_count = %u\n"
		     "\t link_availability = %u\n"
		     "\t last_update_time = %lu Sec\n"
		     "\t bBSSMantSupport = %u\n"
		     "\t bLocalSteerDisallow = %u\n"
		     "\t bBTMSteerDisallow = %u\n",
		     MAC2STR(cli->mac_addr), MAC2STR(cli->bssid), cli->sta_status, cli->assoc_time, cli->downlink, cli->uplink,
		     cli->uplink_rssi, cli->bytes_sent, cli->bytes_received, cli->packets_sent, cli->packets_received,
		     cli->tx_packets_errors, cli->rx_packets_errors, cli->retransmission_count, cli->link_availability,
		     cli->last_update_time.sec, cli->bBSSMantSupport, cli->bLocalSteerDisallow, cli->bBTMSteerDisallow);
	DBGPRINT_RAW(RT_DEBUG_OFF, "non_pref_ch_list: (ch/pref/reason)\n");
	if (!dl_list_empty(&cli->non_pref_ch_list))
		dl_list_for_each(npc_entry, &cli->non_pref_ch_list, struct non_pref_ch_entry, list)
		{
			DBGPRINT_RAW(RT_DEBUG_OFF, "%u/%u/%u ", npc_entry->npc.ch, npc_entry->npc.pref, npc_entry->npc.reason_code);
		}
	else
		DBGPRINT_RAW(RT_DEBUG_OFF, "ch list is empty:");
	DBGPRINT_RAW(RT_DEBUG_OFF, "\n");

	return WAPP_SUCCESS;
}

int wdev_ap_show_block_list(struct wifi_app *wapp, struct ap_dev *ap)
{
	int i = 0;

	DBGPRINT(RT_DEBUG_TRACE, "%s\n", __func__);
	if (!wapp || !ap) {
		return WAPP_INVALID_ARG;
	}

	DBGPRINT_RAW(RT_DEBUG_OFF, "Block List:\n");
	for (i = 0; i < ap->max_num_of_block_cli; i++) {
		if (is_all_zero_mac(ap->block_table[i].mac_addr)) {
			continue;
		}
		DBGPRINT_RAW(RT_DEBUG_OFF, "(%d) sta: " MACSTR "\n", i, MAC2STR(ap->block_table[i].mac_addr));
	}

	return WAPP_SUCCESS;
}

void wdev_apcli_show_info(struct wifi_app *wapp, struct wapp_sta *sta)
{
	if (sta == NULL)
		return;

	DBGPRINT_RAW(RT_DEBUG_OFF,
		"\t mac_addr = " MACSTR "\n"
		"\t bssid = " MACSTR "\n"
		"\t status = %u\n",
		MAC2STR(sta->mac_addr), MAC2STR(sta->bssid), sta->sta_status);

#ifdef MTK_MLO_MAP_SUPPORT
	DBGPRINT_RAW(RT_DEBUG_OFF, "is_MLO:(%u) MLO_en(%u) setup_link(%u)\n"
		"MLD_MAC:" MACSTR"\n"
		"MLD_sta_idx(%u) nsep(%u) emlmr(%u) emlsr(%u)\n"
		"eml_cap(%u) setup_link_wcid(%u) setup_link_id(%u)\n"
		"link_num(%u) valid(%u) link_id(%u), tid_bitmap_dl(%u), tid_bitmap_ul(%u)\n"
		"emlsrbitmap(%u)\n", sta->mlo_join, sta->mlo.mlo_en, sta->mlo.is_setup_link_entry,
		PRINT_MAC(sta->mlo.mld_info.addr), sta->mlo.mld_info.mld_sta_idx,
			sta->mlo.mld_info.nsep, sta->mlo.mld_info.emlmr, sta->mlo.mld_info.emlsr,
			sta->mlo.mld_info.eml_cap, sta->mlo.mld_info.setup_link_wcid, sta->mlo.mld_info.setup_link_id,
			sta->mlo.mld_info.link_num, sta->mlo.mld_info.valid, sta->mlo.link_info.link_id,
			sta->mlo.link_info.tid_bitmap_dl, sta->mlo.link_info.tid_bitmap_ul, sta->EmlsrBitmap);
#endif
}

int wdev_ap_show_cli_list(struct wifi_app *wapp, struct ap_dev *ap)
{
	int i;
	struct wapp_sta *cli;

	DBGPRINT(RT_DEBUG_TRACE, "%s\n", __func__);
	if (!wapp || !ap) {
		return WAPP_INVALID_ARG;
	}

	if (!ap->client_table) {
		return WAPP_NOT_INITIALIZED;
	}

	for (i = 0; i < CLIENT_TABLE_SIZE; i++) {
		cli = ap->client_table[i];
		if (cli) {
			DBGPRINT_RAW(RT_DEBUG_OFF, "cli_info:\n");
			wdev_show_wapp_sta_info(cli);
		}
	}

	return WAPP_SUCCESS;
}

int wdev_ap_show_chn_list(struct wifi_app *wapp, struct ap_dev *ap)
{
	int j = 0;

	DBGPRINT(RT_DEBUG_TRACE, "%s\n", __func__);
	if (!wapp || !ap) {
		return WAPP_INVALID_ARG;
	}

	DBGPRINT_RAW(RT_DEBUG_OFF,
		     "chn_list_info:\n"
		     "\t op_ch =    %u\n"
		     "\t op_class = %u\n"
		     "\t band =   %u\n"
		     "\t ch_list_num =   %u\n"
		     "\t non_op_chn_num =   %d\n",
		     ap->ch_info.op_ch, ap->ch_info.op_class, ap->ch_info.band, ap->ch_info.ch_list_num, ap->ch_info.non_op_chn_num);

	for (j = 0; j < ap->ch_info.ch_list_num; j++) {
		DBGPRINT_RAW(RT_DEBUG_OFF, "channel = %d\n", ap->ch_info.ch_list[j].channel);
	}
	return WAPP_SUCCESS;
}

int wdev_ap_show_bss_info(struct wifi_app *wapp, struct ap_dev *ap)
{
	int i = 0;

	DBGPRINT(RT_DEBUG_TRACE, "%s\n", __func__);
	if (!wapp || !ap) {
		return WAPP_INVALID_ARG;
	}

	DBGPRINT_RAW(RT_DEBUG_OFF, "ap->num_of_bss = %d, total bss:%d\n", ap->num_of_bss, wapp->map->bss_tbl_idx);
	for (i = 0; i < wapp->map->bss_tbl_idx; i++) {
		DBGPRINT_RAW(RT_DEBUG_OFF,
			     "op_bss_info[%d]: \n"
			     "\t Bssid = " MACSTR "\n"
			     "\t ssid = %s\n"
			     "\t SsidLen = %u\n",
			     i, MAC2STR(wapp->map->op_bss_table[i].bssid), wapp->map->op_bss_table[i].ssid,
			     wapp->map->op_bss_table[i].SsidLen);
	}
	return WAPP_SUCCESS;
}

int wdev_ap_show_ap_metric(struct wifi_app *wapp, char *buf, size_t max_len)
{
	int ret = 0, len = 0;
	struct wapp_dev *wdev = NULL;
	struct ap_dev *ap = NULL;
	struct wapp_radio *ra = NULL;
	unsigned char id[MAC_ADDR_LEN] = {0};
	unsigned char i = 0;

	ret = snprintf(buf + len, max_len - len, "\nap_metric info:");
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	for (i = 0; i < MAX_NUM_OF_RADIO; i++) {
		ra = &wapp->radio[i];
		if (!ra->adpt_id)
			continue;
		MAP_GET_RADIO_IDNFER(ra, id);
		dl_list_for_each(wdev, &wapp->dev_list, struct wapp_dev, list) {
			if (ra == wdev->radio && wdev->valid == 1 &&
				wdev->dev_type == WAPP_DEV_TYPE_AP)
				break;
		}
		if (!wdev) {
			err(DEBUG_CAT_MISC, "no valid ap wdev for raid "MACSTR"\n",
				MAC2STR(id));
			return -1;
		}
		ap = (struct ap_dev *)wdev->p_dev;
		if (!ap) {
			err(DEBUG_CAT_MISC, "ap is NULL for raid "MACSTR"\n", MAC2STR(id));
			return -1;
		}

		ret = snprintf(buf + len, max_len - len,
			"\n\traid="MACSTR"; cu = %u; ESPI_BE=[%02x][%02x][%02x]; "
			"ESPI_BK=[%02x][%02x][%02x]; ESPI_VI=[%02x][%02x][%02x]; "
			"ESPI_VO=[%02x][%02x][%02x]\n",
			MAC2STR(id), ap->ap_metrics.cu,
			ap->ap_metrics.ESPI_AC[0][0], ap->ap_metrics.ESPI_AC[0][1], ap->ap_metrics.ESPI_AC[0][2],
			ap->ap_metrics.ESPI_AC[1][0], ap->ap_metrics.ESPI_AC[1][1], ap->ap_metrics.ESPI_AC[1][2],
			ap->ap_metrics.ESPI_AC[2][0], ap->ap_metrics.ESPI_AC[2][1], ap->ap_metrics.ESPI_AC[2][2],
			ap->ap_metrics.ESPI_AC[3][0], ap->ap_metrics.ESPI_AC[3][1], ap->ap_metrics.ESPI_AC[3][2]);
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;
	}

	return len;
}

int wdev_ap_show_ap_info(struct wifi_app *wapp, struct wapp_dev *wdev, struct ap_dev *ap)
{
	DBGPRINT(RT_DEBUG_TRACE, "%s\n", __func__);
	if (!wapp || !ap) {
		return WAPP_INVALID_ARG;
	}

	DBGPRINT_RAW(RT_DEBUG_OFF,
		     "ap_info:\n"
		     "\t wireless_mode =		%u\n"
		     "\t num_of_cli =		%u\n"
		     "\t num_of_assoc_cli =	%u\n"
		     "\t max_num_of_cli =        %u\n"
		     "\t max_num_of_bss =        %u\n"
		     "\t num_of_bss =            %u\n"
		     "\t max_num_of_block_cli =  %u\n"
		     "\t num_of_block_cli =      %u\n"
		     "\t pwr =                   %d\n",
		     wdev->wireless_mode, ap->num_of_clients, ap->num_of_assoc_cli, ap->max_num_of_cli, ap->max_num_of_bss, ap->num_of_bss,
		     ap->max_num_of_block_cli, ap->num_of_block_cli, ap->pwr.tx_pwr);

	return WAPP_SUCCESS;
}

int wdev_ap_set_txpwr_limit(struct wifi_app *wapp, struct wapp_dev *wdev, char pwr_limit, unsigned char op_class)
{
	struct ap_dev *ap = NULL;
	unsigned char power_limit = 0;

	DBGPRINT(RT_DEBUG_TRACE, "%s\n", __func__);
	if (!wapp || !wdev) {
		return WAPP_INVALID_ARG;
	}

	if (wdev->dev_type != WAPP_DEV_TYPE_AP)
		return WAPP_INVALID_ARG;

	ap = (struct ap_dev *)wdev->p_dev;
	power_limit = get_max_power_for_op_class(ap, op_class);
	if (power_limit == pwr_limit || pwr_limit == 0) {
		printf("%s: same pwr limit %d dB, do nothing\n", __func__, pwr_limit);
	} else {
		set_max_power_for_op_class(ap, op_class, pwr_limit);
#if 1 // use pwr percentage as emp sol. nned to find another way to control per-bss / per-channel pwr
		if (pwr_limit < 6) { /*Used Lowest Power Percentage.*/
			wapp_set_tx_power_percentage(wapp, wdev, 6);
		} else if (pwr_limit < 9) {
			wapp_set_tx_power_percentage(wapp, wdev, 10);
		} else if (pwr_limit < 12) {
			wapp_set_tx_power_percentage(wapp, wdev, 25);
		} else if (pwr_limit < 14) {
			wapp_set_tx_power_percentage(wapp, wdev, 50);
		} else if (pwr_limit < 15) {
			wapp_set_tx_power_percentage(wapp, wdev, 75);
		} else {
			wapp_set_tx_power_percentage(wapp, wdev, 100);
		}
#endif
		printf(BLUE("%s: change pwr limit to %d dB\n"), __func__, pwr_limit);
	}

	return WAPP_SUCCESS;
}

#ifdef STANDARD_NL_CMD
int wdev_ap_create_new_intf(struct wifi_app *wapp, struct dev_info *dev)
{
	struct phy_info *phy = NULL;
	unsigned char found = 0;
	int ret = 0;

	if (!wapp || !dev) {
		err(DEBUG_CAT_INIT, DYN_INTF_PREX"invalid input params\n");
		return WAPP_INVALID_ARG;
	}

	dl_list_for_each(phy, &wapp->phy_head, struct phy_info, list) {
		if (dev->phy_id == phy->phy_id) {
			found = 1;
			break;
		}
	}

	if (!found) {
		err(DEBUG_CAT_INIT, DYN_INTF_PREX"%s get phy info fail\n", dev->ifname);
		return WAPP_LOOKUP_ENTRY_NOT_FOUND;
	}

	wapp_dev_create(wapp, dev->ifname, dev->ifindex, dev->mac);
#ifdef MAP_R5
	map_update_device_info_sd_nl(wapp, dev);
#endif
	switch (dev->iftype) {
	case NL80211_IFTYPE_AP:
		ret = wdev_ap_create_sd_nl(wapp, dev, phy);
		if (ret < 0)
			return WAPP_UNEXP;
		break;
	case NL80211_IFTYPE_STATION:
		ret = wdev_sta_create_sd_nl(wapp, dev, phy);
		if (ret < 0)
			return WAPP_UNEXP;
		break;
	default:
		err(DEBUG_CAT_INIT, DYN_INTF_PREX"dev_type(%u) incorrect for %s\n", dev->iftype,
			dev->ifname);
		return WAPP_UNEXP;
	}
#if defined(DPP_SUPPORT) && !defined(MAP_R3)
	dpp_conf_init(wapp, dev->ifindex);
#endif /* DPP_SUPPORT && !MAP_R3*/

	return WAPP_SUCCESS;
}

u8 get_dev_num_per_band(struct wifi_app *wapp, struct dev_info *dev)
{
	struct dev_info *pdev = NULL;
	int cnt = 0;

	if (!wapp || !dev) {
		DBGPRINT(RT_DEBUG_ERROR, DYN_INTF_PREX"invalid input params\n");
		return 0;
	}

	dl_list_for_each(pdev, &wapp->hdev_head, struct dev_info, list) {
		DBGPRINT(RT_DEBUG_TRACE, "pre_ifname:%s(%d),dev->ifname:%s(%d)\n",
			pdev->ifname, pdev->ch, dev->ifname, dev->ch);
		if (pdev->ch == dev->ch)
			cnt++;
	}

	return cnt;
}

void wapp_event_intf_notify(struct wifi_app *wapp, struct dev_info *dev, char action)
{
	struct wapp_dev *wdev = NULL;
	struct ap_dev *ap = NULL;

	if (!wapp || !dev) {
		err(DEBUG_CAT_INIT, DYN_INTF_PREX"invalid input params\n");
		return;
	}
	notice(DEBUG_CAT_INIT, DYN_INTF_PREX"%s action %d\n", dev->ifname, action);

	wdev = wapp_dev_list_lookup_by_ifname(wapp, dev->ifname);
	if (wdev == NULL) {
		err(DEBUG_CAT_INIT, DYN_INTF_PREX"can't find %s in wdev list\n", dev->ifname);
		return;
	}
	if ((wdev->radio == NULL) || (wdev->p_dev == NULL)) {
		notice(DEBUG_CAT_INIT, DYN_INTF_PREX"radio or ap null for %s\n", dev->ifname);
		return;
	}
	ap = (struct ap_dev *)wdev->p_dev;

	if (action) {
		wdev->ifindex = dev->ifindex;
		notice(DEBUG_CAT_INIT, DYN_INTF_PREX"update %s as WAPP_BSS_START\n", dev->ifname);
		ap->isActive = WAPP_BSS_START;
	} else {
		notice(DEBUG_CAT_INIT, DYN_INTF_PREX"pdate %s as WAPP_BSS_STOP\n", dev->ifname);
		ap->isActive = WAPP_BSS_STOP;
	}
}

void wapp_event_new_intf_notify(struct wifi_app *wapp, struct dev_info *dev)
{
	struct wapp_dev *wdev = NULL, *tmp_wdev = NULL;
	struct dev_info *tmp_dev = NULL;
	struct ap_dev *ap = NULL;
	struct phy_info *phy = NULL;
	unsigned char found = 0;

	if (!wapp || !dev) {
		err(DEBUG_CAT_INIT, DYN_INTF_PREX"invalid input params\n");
		return;
	}

	dl_list_for_each(phy, &wapp->phy_head, struct phy_info, list) {
		if (dev->phy_id == phy->phy_id) {
			found = 1;
			break;
		}
	}
	if (!found) {
		err(DEBUG_CAT_INIT, DYN_INTF_PREX"%s get phy info fail\n", dev->ifname);
		return;
	}

	dev->ch = ieee80211_frequency_to_channel(dev->freq);
	info(DEBUG_CAT_INIT, DYN_INTF_PREX"freq: %d, ch: %d\n", dev->freq, dev->ch);
	dev->bw = nl80211_bw_to_wifi_bw(dev->bw, dev->ch, dev->center1);
	if (dev->ch == 0 || dev->bw == CHAN_WIDTH_INVALID) {
		err(DEBUG_CAT_INIT, DYN_INTF_PREX"can't find correct ch-%d and bw-%d for freq-%d for dev-%s\n",
			dev->ch, dev->bw, dev->freq, dev->ifname);
		return;
	}

	if (wdev_ap_create_new_intf(wapp, dev) != WAPP_SUCCESS) {
		err(DEBUG_CAT_INIT, DYN_INTF_PREX"wdev_ap_create_new_intf %s fail\n", dev->ifname);
		return;
	}

	/*set map profile*/
	wdev = wapp_dev_list_lookup_by_ifindex(wapp, dev->ifindex);
	if (!wdev) {
		err(DEBUG_CAT_INIT, DYN_INTF_PREX"%s find wdev fail\n", dev->ifname);
		return;
	}
	wdev->dev = dev;

	/*update the max bss number per band*/
	dl_list_for_each(tmp_dev, &wapp->hdev_head, struct dev_info, list) {
		if (tmp_dev->phy_id != dev->phy_id)
			continue;
		tmp_wdev = wapp_dev_list_lookup_by_ifname(wapp, tmp_dev->ifname);
		if (!tmp_wdev || tmp_wdev->dev_type != WAPP_DEV_TYPE_AP)
			continue;
		ap = (struct ap_dev *)tmp_wdev->p_dev;
		if (!ap)
			continue;
		ap->num_of_bss = get_dev_num_per_band(wapp, tmp_dev);
		info(DEBUG_CAT_INIT, DYN_INTF_PREX"update dev %s(ch %d) num_of_bss %d\n", tmp_dev->ifname, tmp_dev->ch, ap->num_of_bss);
	}

	map_send_new_intf_info(wapp, wdev);
}

void wapp_event_delete_intf_notify(struct wifi_app *wapp, struct dev_info *dev)
{
	struct wapp_dev *wdev = NULL;
	struct dev_info *tmp_dev = NULL;
	struct ap_dev *ap = NULL;
	int ret = 0, i = 0;
	u8 phy_id = 0;
	char ifname[IFNAMSIZ] = {0};
	unsigned char ra_id[ETH_ALEN] = {0};
	struct wapp_radio *ra = NULL;

	if (!wapp || !dev) {
		err(DEBUG_CAT_INIT, DYN_INTF_PREX"invalid input params\n");
		return;
	}

	notice(DEBUG_CAT_INIT, DYN_INTF_PREX" delete %s\n", dev->ifname);

	os_memcpy(ifname, dev->ifname, IFNAMSIZ);
	ifname[IFNAMSIZ - 1] = '\0';
	phy_id = dev->phy_id;

	wdev = wapp_dev_list_lookup_by_ifname(wapp, ifname);
	if (!wdev) {
		err(DEBUG_CAT_INIT, DYN_INTF_PREX"%s find wdev fail\n", dev->ifname);
		return;
	}
	ret = wapp_dev_del(wapp, wdev, dev->mac, wdev->dev_type);
	if (ret) {
		err(DEBUG_CAT_INIT, DYN_INTF_PREX"del %s from wdev list fail\n", dev->ifname);
		return;
	}

	dl_list_del(&dev->list);
	os_free(dev);

	/*update the max bss number per band*/
	dl_list_for_each(tmp_dev, &wapp->hdev_head, struct dev_info, list) {
		if (tmp_dev->phy_id != phy_id)
			continue;
		wdev = wapp_dev_list_lookup_by_ifname(wapp, tmp_dev->ifname);
		if (!wdev || wdev->dev_type != WAPP_DEV_TYPE_AP)
			continue;
		ap = (struct ap_dev *)wdev->p_dev;
		if (!ap)
			continue;
		ap->num_of_bss = get_dev_num_per_band(wapp, tmp_dev);
		info(DEBUG_CAT_INIT, DYN_INTF_PREX"update dev %s num_of_bss:%d\n", tmp_dev->ifname, ap->num_of_bss);
	}

	/*if radio interface all down, update radio->op_ch as 0*/
	for (i = 0; i < MAX_NUM_OF_RADIO; i++) {
		ra = &wapp->radio[i];
		if (ra->op_ch != 0) {
			wdev = NULL;
			MAP_GET_RADIO_IDNFER(ra, ra_id);
			wdev = wapp_dev_list_lookup_by_radio(wapp, (char *)ra_id);
			if (!wdev) {
				ra->op_ch = 0;
				notice(DEBUG_CAT_INIT, DYN_INTF_PREX"update ch as 0 for radio "MACSTR"\n", MAC2STR(ra_id));
				break;
			}
		}
	}
	map_send_del_intf_info(wapp, ifname);
}
#endif /*STANDARD_NL_CMD*/

