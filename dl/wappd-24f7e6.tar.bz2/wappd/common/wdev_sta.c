/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#include <stdlib.h>
#include <stdio.h>
#include "wdev.h"
#include "driver_wext.h"
#ifdef WPACTRL_SUPPORT
#include <libwpactrl.h>

static int wdev_sta_event_wps_timeout(void *ctx, const char *iface)
{
	int ret;
	struct wifi_app *wapp = (struct wifi_app *)ctx;

	if (!wapp || !wapp->event_ops || !wapp->event_ops->event_wps_timeout)
		return 0;

	ret = wapp->event_ops->event_wps_timeout(wapp, iface);
	if (ret != WAPP_SUCCESS) {
		err(DEBUG_CAT_MISC, "event_wps_timeout failed:%d\n", ret);
		return -1;
	}

	return 0;
}

static int wdev_sta_event_wps_success(void *ctx, const char *iface)
{
	int ret;
	struct wifi_app *wapp = (struct wifi_app *)ctx;

	if (!wapp || !wapp->event_ops || !wapp->event_ops->event_wps_success)
		return 0;

	ret = wapp->event_ops->event_wps_success(wapp, iface);
	if (ret != WAPP_SUCCESS) {
		err(DEBUG_CAT_MISC, "event_wps_success failed:%d\n", ret);
		return -1;
	}

	return 0;
}

static int wdev_sta_event_connected(void *ctx, const char *iface)
{
	return 0;
}

static int wdev_sta_event_disconnected(void *ctx, const char *iface)
{
	return 0;
}

static int wdev_sta_event_wps_overlap(void *ctx, const char *iface)
{
	int ret;
	struct wifi_app *wapp = (struct wifi_app *)ctx;

	if (!wapp || !wapp->event_ops || !wapp->event_ops->event_wps_overlap)
		return 0;

	ret = wapp->event_ops->event_wps_overlap(wapp, iface);
	if (ret != WAPP_SUCCESS) {
		err(DEBUG_CAT_MISC, "event_wps_overlap failed:%d\n", ret);
		return -1;
	}

	return 0;
}

static int wdev_sta_event_wps_scan_fail(void *ctx, const char *iface)
{
	int ret;
	struct wifi_app *wapp = (struct wifi_app *)ctx;

	if (!wapp || !wapp->event_ops || !wapp->event_ops->event_wps_scan_fail)
		return 0;

	ret = wapp->event_ops->event_wps_scan_fail(wapp, iface);
	if (ret != WAPP_SUCCESS) {
		err(DEBUG_CAT_MISC, "event_wps_scan_fail failed:%d\n", ret);
		return -1;
	}

	return 0;
}

static int wdev_sta_event_wps_fail(void *ctx, const char *iface,
					int msg, int config_error, int reason)
{
	int ret;
	struct wifi_app *wapp = (struct wifi_app *)ctx;

	if (!wapp || !wapp->event_ops || !wapp->event_ops->event_wps_failure)
		return 0;
	ret = wapp->event_ops->event_wps_failure(wapp,
				iface, msg, config_error, reason);
	if (ret != WAPP_SUCCESS) {
		err(DEBUG_CAT_MISC, "event_wps_failure failed:%d\n", ret);
		return -1;
	}
	return 0;
}

static int wdev_sta_event_wps_active(void *ctx, const char *iface)
{
	return 0;
}

static int wdev_sta_event_wps_disable(void *ctx, const char *iface)
{
	return 0;
}

#ifdef MAP_R2
static int wdev_sta_event_wnm_notify_req(void *ctx, const char *iface,
				uint8_t *mac, uint8_t *payload, size_t payload_len)
{
	int ret;
	struct wifi_app *wapp = (struct wifi_app *)ctx;

	if (!wapp || !wapp->event_ops || !wapp->event_ops->event_wnm_notify)
		return 0;

	ret = wapp->event_ops->event_wnm_notify(wapp,
				iface, mac, (const char *)payload, payload_len);

	if (ret != WAPP_SUCCESS) {
		DBGPRINT(RT_DEBUG_ERROR, "event_wnm_notify failed:%d\n", ret);
		return -1;
	}
	return 0;
}
#endif

#ifdef MTK_HOSTAPD_SUPPORT
static int wdev_sta_event_eap_failure(void *ctx, const char *iface,  uint8_t *mac)
{
	int ret;
	struct wifi_app *wapp = (struct wifi_app *)ctx;

	if (!wapp || !wapp->event_ops || !wapp->event_ops->event_eap_failure)
		return 0;

	ret = wapp->event_ops->event_eap_failure(wapp, iface, mac);
	if (ret != WAPP_SUCCESS) {
		err(DEBUG_CAT_MISC, "event_eap_failure failed:%d\n", ret);
		return -1;
	}

	return 0;
}

static int wdev_sta_event_eap_timeout(void *ctx, const char *iface)
{
	int ret;
	struct wifi_app *wapp = (struct wifi_app *)ctx;

	if (!wapp || !wapp->event_ops || !wapp->event_ops->event_eap_timeout)
		return 0;

	ret = wapp->event_ops->event_eap_timeout(wapp, iface);
	if (ret != WAPP_SUCCESS) {
		err(DEBUG_CAT_MISC, "event_eap_timeout failed:%d\n", ret);
		return -1;
	}

	return 0;
}
#endif

static int wdev_sta_event_network_add(void *ctx, const char *iface, int wdev_network_id)
{
	int ret;
	struct wifi_app *wapp = (struct wifi_app *)ctx;

	if (!wapp || !wapp->event_ops || !wapp->event_ops->event_network_add)
		return 0;

	ret = wapp->event_ops->event_network_add(wapp, iface, wdev_network_id);
	if (ret != WAPP_SUCCESS) {
		err(DEBUG_CAT_MISC, "event_network_added failed:%d\n", ret);
		return -1;
	}

	return 0;
}

static int wdev_sta_event_wps_cred(void *ctx, const char *iface,
		uint8_t *payload, size_t payload_len)
{
	struct wifi_app *wapp = (struct wifi_app *)ctx;

	if (!wapp || !wapp->event_ops || !wapp->event_ops->event_supp_wps_cred)
		return -1;

	wapp->event_ops->event_supp_wps_cred(wapp, iface,
			(u8 *)payload, payload_len);

	return 0;
}

static int wdev_sta_event_reconfig_fail(void *ctx, const char *iface)
{
	struct wifi_app *wapp = (struct wifi_app *)ctx;

	if (!wapp || !wapp->event_ops || !wapp->event_ops->event_supp_reconfig_fail)
		return -1;

	wapp->event_ops->event_supp_reconfig_fail(wapp, iface);

	return 0;
}

static wpactrl_cbs_t wdev_sta_wpactrl_cbs = {
	.event_connected_cb		= wdev_sta_event_connected,
	.event_disconnected_cb		= wdev_sta_event_disconnected,
	.event_wps_timeout_cb		= wdev_sta_event_wps_timeout,
	.event_wps_success_cb		= wdev_sta_event_wps_success,
	.event_wps_overlap_cb		= wdev_sta_event_wps_overlap,
	.event_wps_fail_cb		= wdev_sta_event_wps_fail,
	.event_wps_active_cb		= wdev_sta_event_wps_active,
	.event_wps_disable_cb		= wdev_sta_event_wps_disable,
#ifdef MAP_R2
	.event_wnm_notify_req_cb	= wdev_sta_event_wnm_notify_req,
#endif
#ifdef MTK_HOSTAPD_SUPPORT
	.event_eap_failure_cb		= wdev_sta_event_eap_failure,
	.event_eap_timeout_cb		= wdev_sta_event_eap_timeout,
#endif
	.event_wnm_notify_network_added_cb = wdev_sta_event_network_add,
	.event_wps_scan_fail_cb		= wdev_sta_event_wps_scan_fail,
	.event_wps_cred_cb              = wdev_sta_event_wps_cred,
	.event_reconfig_fail_cb         = wdev_sta_event_reconfig_fail,
};

static void wdev_sta_wpactrl_event_receive(int sock, void *eloop_ctx, void *handle)
{
	int ret;
	struct wifi_app *wapp = (struct wifi_app *)eloop_ctx;

	ret = wpactrl_event_get(wapp->wpactrl_supplicant_ctx);
	if (ret < 0)
		DBGPRINT(RT_DEBUG_ERROR, "%s: wpactrl_event_get:%d\n", __func__, ret);
}

int wdev_sta_wpactrl_init(struct wifi_app *wapp)
{

	int ret;
	int fd;
	void *ctx = NULL;
	const char *wpactrl_path = "/var/run/wpa_supplicant/";
	const char *wpactrl_ifname = "global";
	int wpactrl_type = WPACTRL_TYPE_SUPPLICANT;

	if (wapp->drv_mode != NL80211)
		return 0;

	ret = wpactrl_iface_open(&ctx,
				wpactrl_type,
				wpactrl_ifname,
				wpactrl_path,
				wapp,
				&wdev_sta_wpactrl_cbs,
				1);

	if (ret != 0) {
		err(DEBUG_CAT_INIT, "wpactrl_iface_open fail; path=%s; "
			"ifname=%s; type=SUPPLICANT; ret=%d\n",
			wpactrl_path, wpactrl_ifname, ret);
		goto err;
	}

	fd = wpactrl_iface_fd_get(ctx);
	if (fd < 0) {
		err(DEBUG_CAT_INIT, "wpactrl_iface_fd_get fail; path=%s; "
			"ifname=%s; type=SUPPLICANT; ret=%d\n",
			wpactrl_path, wpactrl_ifname, fd);
		goto err2;
	}

	ret = eloop_register_read_sock(fd, wdev_sta_wpactrl_event_receive, wapp, NULL);
	if (ret < 0) {
		err(DEBUG_CAT_INIT, "eloop_register_read_sock fail; ret=%d\n", ret);
		goto err2;
	}

	wapp->wpactrl_supplicant_fd = fd;
	wapp->wpactrl_supplicant_ctx = ctx;

	return 0;
err2:
	wpactrl_iface_close(ctx);
err:
	return -1;
}


void wdev_sta_wpactrl_deinit(struct wifi_app *wapp)
{
	if (wapp->wpactrl_supplicant_ctx)
		wpactrl_iface_close(wapp->wpactrl_supplicant_ctx);

	wapp->wpactrl_supplicant_ctx = NULL;
	wapp->wpactrl_supplicant_fd = -1;
}
#endif /* WPACTRL_SUPPORT */


static int wdev_sta_del(struct wifi_app *wapp, struct wapp_dev *wdev)
{
	struct wapp_sta *sta = NULL;

	if (!wapp || !wdev)
		return WAPP_INVALID_ARG;

	sta = (struct wapp_sta *)wdev->p_dev;

	/* free sta */
	if (sta)
		os_free(sta);
	wdev->p_dev = NULL;

	return WAPP_SUCCESS;
}

static struct wdev_ops wdev_sta_ops = {
	.wdev_del = wdev_sta_del,
};

#ifdef STANDARD_NL_CMD
int wdev_sta_create_sd_nl(struct wifi_app *wapp, struct dev_info *dev, struct phy_info *phy)
{
	struct wapp_dev *wdev = NULL;
	struct wapp_sta *sta = NULL;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, dev->ifindex);
	if (wdev == NULL)
		goto new_wdev;
	else if (wdev->p_dev == NULL)
		goto new_sta;
	else if (wdev->dev_type != WAPP_DEV_TYPE_STA /* remove APCLI*/) {
		err(DEBUG_CAT_MISC, "dev_type(%u) is not sta for %s\n", wdev->dev_type, wdev->ifname);
		/* check duplicate mac_address? */
		return WAPP_UNEXP;
	}

	/* already exsist */
	return WAPP_SUCCESS;

new_wdev:
	if (wapp_dev_create(wapp, (char *)dev->ifname, dev->ifindex, dev->mac) != WAPP_SUCCESS)
		err(DEBUG_CAT_MISC, "wdev create failed for %s\n", dev->ifname);

	return WAPP_SUCCESS;

new_sta:
	wdev->p_dev = os_zalloc(sizeof(struct wapp_sta));

	if (!wdev->p_dev)
		return WAPP_RESOURCE_ALLOC_FAIL;

	sta = wdev->p_dev;
	os_memset(sta, 0, sizeof(struct wapp_sta));
	dl_list_init(&sta->non_pref_ch_list);
	wdev->ops = &wdev_sta_ops;

	wdev->dev_type = WAPP_DEV_TYPE_STA;
	wdev->radio = wapp_radio_update_or_create(wapp, phy->phy_id + 1, phy->phy_id);
	if (!wdev->radio)
		err(DEBUG_CAT_MISC, "radio not found for %s\n", wdev->ifname);

	wdev->wireless_mode = phy->mode;
	wdev->wapp = wapp;
	wdev->valid = 1;

	return WAPP_SUCCESS;
}
#endif

int wdev_sta_create(struct wifi_app *wapp, wapp_dev_info *dev_info)
{
	struct wapp_dev *wdev = NULL;
	struct wapp_sta *sta = NULL;

	if (!wapp || !dev_info)
		return WAPP_INVALID_ARG;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, dev_info->ifindex);

	if (wdev == NULL)
		goto new_wdev;
	else if (wdev->p_dev == NULL)
		goto new_sta;
	else if (wdev->dev_type != WAPP_DEV_TYPE_STA /* remove APCLI*/) {
		DBGPRINT_RAW(RT_DEBUG_OFF, "Error! dev_type = %u\n", wdev->dev_type);
		/* check duplicate mac_address? */
		return WAPP_UNEXP;
	}

	/* already exsist */
	return WAPP_SUCCESS;

new_wdev:
	if (wapp_dev_create(wapp, (char *)dev_info->ifname, dev_info->ifindex, dev_info->mac_addr) != WAPP_SUCCESS)
		DBGPRINT_RAW(RT_DEBUG_OFF, "Warning! wdev create failed.\n");
	return WAPP_SUCCESS;

new_sta:
	wdev->p_dev = os_zalloc(sizeof(struct wapp_sta));

	if (!wdev->p_dev)
		return WAPP_RESOURCE_ALLOC_FAIL;

	sta = wdev->p_dev;
	os_memset(sta, 0, sizeof(struct wapp_sta));
	dl_list_init(&sta->non_pref_ch_list);
	wdev->ops = &wdev_sta_ops;

	wdev->dev_type = WAPP_DEV_TYPE_STA;
	wdev->radio = wapp_radio_update_or_create(wapp, dev_info->adpt_id, dev_info->radio_id);

	if (!wdev->radio)
		DBGPRINT_RAW(RT_DEBUG_OFF, "Warning! radio not found.\n");

	wdev->wireless_mode = dev_info->wireless_mode;

	wdev->wapp = wapp;

	wdev->valid = 1;
	return WAPP_SUCCESS;
}
