﻿/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#include "wapp_cmm.h"
#include "hotspot.h"
#include <sys/socket.h>
#include <unistd.h>
#include "ctrl_iface_unix.h"
#ifdef EPCS_SUPPORT
#include "epcs.h"
#endif
#ifdef COSR_SUPPORT
#include "cosr.h"
#endif
static void wapp_ctrl_set_brace_multiple_param(struct wapp_conf *conf, const char *confname, const char *param, const char *value);

#ifdef DPP_SUPPORT
int wapp_ctrl_iface_cmd_dpp(struct wifi_app *wapp, char *iface, char *buf, char *reply, int reply_size);
#endif /*DPP_SUPPORT*/

static int wapp_ctrl_iface_event_register(struct wapp_ctrl_iface *ctrl_iface, struct sockaddr_un *from, socklen_t fromlen)
{
	struct wapp_ctrl_dst *ctrl_dst;

	ctrl_dst = os_zalloc(sizeof(*ctrl_dst));
	if (!ctrl_dst) {
		err(DEBUG_CAT_MISC, "alloc ctrl_dst fail\n");
		return -1;
	}

	os_memcpy(&ctrl_dst->addr, from, sizeof(struct sockaddr_un));
	ctrl_dst->addrlen = fromlen;
	dl_list_add(&ctrl_iface->w_ctrl_dst_list, &ctrl_dst->list);

	return 0;
}

static int wapp_ctrl_iface_event_unregister(struct wapp_ctrl_iface *ctrl_iface, struct sockaddr_un *from, socklen_t fromlen)
{
	struct wapp_ctrl_dst *ctrl_dst, *ctrl_dst_tmp;

	dl_list_for_each_safe(ctrl_dst, ctrl_dst_tmp, &ctrl_iface->w_ctrl_dst_list, struct wapp_ctrl_dst, list)
	{
		if (fromlen == ctrl_dst->addrlen &&
		    os_memcpy(from->sun_path, ctrl_dst->addr.sun_path, fromlen - offsetof(struct sockaddr_un, sun_path)) == 0) {
			dl_list_del(&ctrl_dst->list);
			os_free(ctrl_dst);
			return 0;
		}
	}

	return -1;
}

static int wapp_ctrl_iface_cmd_version(struct wifi_app *wapp, char *reply, size_t *reply_len)
{
	int ret = 0;

	ret = os_snprintf(reply, strlen(HOTSPOT_VERSION) + 1, "%s", HOTSPOT_VERSION);
	if (os_snprintf_error(sizeof(reply), ret)) {
		err(DEBUG_CAT_EVENT, "os_snprintf fail\n");
		return -1;
	}
	*reply_len = strlen(HOTSPOT_VERSION);
	return 0;
}

static int wapp_ctrl_iface_cmd_on(struct wifi_app *wapp, const char *iface, char *reply, size_t *reply_len)
{
	int ret = 0;

	ret = hotspot_onoff(wapp, iface, 1, EVENT_TRIGGER_ON, HS_ON_OFF_BASE);
	*reply_len = 0;

	return ret;
}

static int wapp_ctrl_iface_cmd_off(struct wifi_app *wapp, const char *iface, char *reply, size_t *reply_len)
{
	int ret = 0;

	ret = hotspot_onoff(wapp, iface, 0, EVENT_TRIGGER_ON, HS_ON_OFF_BASE);
	*reply_len = 0;

	return ret;
}

static int wapp_ctrl_iface_cmd_get(struct wifi_app *wapp, const char *iface, char *param, char *reply, size_t *reply_len)
{
	int ret = 0;
	struct wapp_conf *conf = NULL;
	int is_found = 0;

	dl_list_for_each(conf, &wapp->conf_list, struct wapp_conf, list)
	{
		if (os_strcmp(conf->iface, iface) == 0) {
			is_found = 1;
			break;
		}
	}

	if (is_found) {
		if (os_strcmp(param, "access_network_type") == 0) {
			ret = os_snprintf(reply, *reply_len, "access_network_type=%d", conf->access_network_type);
			if (os_snprintf_error(sizeof(reply), ret)) {
				err(DEBUG_CAT_EVENT, "os_snprintf fail\n");
				ret = -1;
			}
			*reply_len = os_strlen(reply);
		} else if (os_strcmp(param, "internet") == 0) {
			ret = os_snprintf(reply, *reply_len, "internet=%d", conf->internet);
			if (os_snprintf_error(sizeof(reply), ret)) {
				err(DEBUG_CAT_EVENT, "os_snprintf fail\n");
				ret = -1;
			}
			*reply_len = os_strlen(reply);
		} else if (os_strcmp(param, "timezone") == 0) {
			ret = os_snprintf(reply, *reply_len, "timezone=%s", conf->time_zone);
			if (os_snprintf_error(sizeof(reply), ret)) {
				err(DEBUG_CAT_EVENT, "os_snprintf fail\n");
				ret = -1;
			}
			*reply_len = os_strlen(reply);
		} else if (os_strcmp(param, "all") == 0) {
			ret = os_snprintf(reply, *reply_len,
					  "access_network_type=%d\n"
					  "internet=%d\n",
					  conf->access_network_type, conf->internet);
			if (os_snprintf_error(sizeof(reply), ret)) {
				err(DEBUG_CAT_EVENT, "os_snprintf fail\n");
				ret = -1;
			}
			*reply_len = os_strlen(reply);
		} else
			ret = -1;
	} else
		ret = -1;

	return ret;
}

static void wapp_ctrl_clear_general_multiple_param(const char *confname, const char *param)
{
	FILE *file, *tmpfile;
	char buf[256];
	char tmp_confname[256];
	char *tmp_ptr;
	int ret = 0;

	u8 is_clear = 0;

	os_memset(buf, 0, 256);

	tmp_ptr = strrchr(confname, '/');
	if (!tmp_ptr) {
		err(DEBUG_CAT_EVENT, "tmp_ptr is null\n");
		return;
	}
	os_strncpy(tmp_confname, confname, strlen(confname) - strlen(tmp_ptr));
	tmp_confname[strlen(confname) - strlen(tmp_ptr)] = '\0';

	ret = os_snprintf(tmp_confname + strlen(tmp_confname), sizeof(tmp_confname) - strlen(tmp_confname), "%s",
			  "/wapp_ap_interface.conf");
	if (os_snprintf_error(sizeof(tmp_confname) - strlen(tmp_confname), ret)) {
		err(DEBUG_CAT_EVENT, "os_snprintf fail\n");
		return;
	}

	file = fopen(confname, "r");

	if (!file) {
		err(DEBUG_CAT_EVENT, "open configuration(%s) fail\n", confname);
		return;
	}

	tmpfile = fopen(tmp_confname, "w");

	if (!tmpfile) {
		err(DEBUG_CAT_EVENT, "open configuration(%s) fail\n", tmp_confname);
		ret = fclose(file);
		if (ret == EOF)
			err(DEBUG_CAT_EVENT, "close configuration(%s) fail\n", confname);
		return;
	}

	while (fgets(buf, sizeof(buf), file) != NULL) {
		if (strstr(buf, param) != NULL) {
			if (!is_clear) {
				ret = fprintf(tmpfile, "%s=n/a\n", param);
				if (ret < 0) {
					err(DEBUG_CAT_EVENT, "fprintf fail\n");
					break;
				}
				is_clear = 1;
			}

			if (strcmp(param, "venue_name") == 0) {
				int tmplen, is_end = 0;
				do {
					for (tmplen = 0; tmplen < strlen(buf); tmplen++) {
						if (buf[tmplen] == '}') {
							is_end = 1;
							break;
						}
					}
					if (is_end == 0) {
						os_memset(buf, 0, 256);
						if (fgets(buf, sizeof(buf), file) == NULL)
							break;
					}
				} while (is_end == 0);
			}
		} else {
			ret = fputs(buf, tmpfile);
			if (ret == EOF) {
				err(DEBUG_CAT_EVENT, "fprintf fail\n");
				break;
			}
		}
	}

	ret = fclose(tmpfile);
	if (ret == EOF)
		err(DEBUG_CAT_EVENT, "close configuration(%s) fail\n", tmp_confname);
	ret = fclose(file);
	if (ret == EOF)
		err(DEBUG_CAT_EVENT, "close configuration(%s) fail\n", confname);

	if (unlink(confname) < 0)
		err(DEBUG_CAT_EVENT, "unlink(%s) fail\n", confname);

	if (rename(tmp_confname, confname) < 0)
		err(DEBUG_CAT_EVENT, "rename(%s, %s) fail\n", tmp_confname, confname);
}

static void wapp_ctrl_set_general_param(const char *confname, const char *param, char *value)
{
	FILE *file, *tmpfile;
	char buf[256];
	char tmp_confname[256];
	char *tmp_ptr;
	int ret = 0;

	os_memset(buf, 0, 256);

	tmp_ptr = strrchr(confname, '/');
	if (!tmp_ptr) {
		err(DEBUG_CAT_EVENT, "strrchr fail\n");
		return;
	}
	os_strncpy(tmp_confname, confname, strlen(confname) - strlen(tmp_ptr));
	tmp_confname[strlen(confname) - strlen(tmp_ptr)] = '\0';
	ret = os_snprintf(tmp_confname + strlen(tmp_confname), sizeof(tmp_confname) - strlen(tmp_confname), "%s",
			  "/wapp_ap_interface.conf");

	if (os_snprintf_error(sizeof(tmp_confname) - strlen(tmp_confname), ret)) {
		err(DEBUG_CAT_EVENT, "os_snprintf fail\n");
		return;
	}

	file = fopen(confname, "r");

	if (!file) {
		err(DEBUG_CAT_EVENT, "open configuration(%s) fail\n", confname);
		return;
	}

	tmpfile = fopen(tmp_confname, "w");

	if (!tmpfile) {
		err(DEBUG_CAT_EVENT, "open configuration(%s) fail\n", tmp_confname);
		ret = fclose(file);
		if (ret == EOF)
			err(DEBUG_CAT_EVENT, "close configuration(%s) fail\n", confname);
		return;
	}

	while (fgets(buf, sizeof(buf), file) != NULL) {
		if (strstr(buf, param) != NULL) {
			ret = fprintf(tmpfile, "%s=%s\n", param, value);
			if (ret < 0) {
				err(DEBUG_CAT_EVENT, "fprintf fail\n");
				break;
			}
		} else {
			ret = fputs(buf, tmpfile);
			if (ret == EOF) {
				err(DEBUG_CAT_EVENT, "fputs fail\n");
				break;
			}
		}
	}

	ret = fclose(tmpfile);
	if (ret == EOF)
		err(DEBUG_CAT_EVENT, "close configuration(%s) fail\n", tmp_confname);

	ret = fclose(file);
	if (ret == EOF)
		err(DEBUG_CAT_EVENT, "close configuration(%s) fail\n", confname);

	if (unlink(confname) < 0)
		err(DEBUG_CAT_EVENT, "unlink(%s) fail\n", confname);

	if (rename(tmp_confname, confname) < 0)
		err(DEBUG_CAT_EVENT, "rename(%s, %s) fail\n", tmp_confname, confname);
}

/* ====== MBO ============== */
static void wapp_ctrl_set_ap_cdcp(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "mbo_cdcp", value);
}

static void wapp_ctrl_set_disallow_assoc_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "mbo_ap_assoc_disallow_reason", value);
}

static void wapp_ctrl_set_assoc_retry_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "mbo_default_assoc_retry_delay", value);
}

static void wapp_ctrl_set_trans_reason_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "mbo_default_trans_reason", value);
}

static void wapp_ctrl_set_ap_capability_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "mbo_ap_capability", value);
}

/* ===== MBO END =========== */
static void wapp_ctrl_set_interface_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "interface", value);
}

static void wapp_ctrl_set_osu_interface_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "osu_interface", value);
}

static void wapp_ctrl_set_interworking_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "interworking", value);
}

static void wapp_ctrl_set_access_net_type_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "access_network_type", value);
}

static void wapp_ctrl_set_internet_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "internet", value);
}

static void wapp_ctrl_set_venue_group_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "venue_group", value);
}

static void wapp_ctrl_set_venue_type_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "venue_type", value);
}

void wapp_ctrl_set_hessid_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "hessid", value);
}

static void wapp_ctrl_set_roaming_consortium_oi_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "roaming_consortium_oi", value);
}

static void wapp_ctrl_set_advertisement_proto_id_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "advertisement_proto_id", value);
}

static void wapp_ctrl_set_anqp_query_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "anqp_query", value);
}

static void wapp_ctrl_set_cosr_support_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "cosr_support", value);
}

static void wapp_ctrl_set_mih_support_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "mih_support", value);
}

static void wapp_ctrl_set_dgaf_disabled_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "dgaf_disabled", value);
}

static void wapp_ctrl_set_timezone_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "timezone", value);
}

static void wapp_ctrl_set_gas_cb_delay_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "gas_cb_delay", value);
}

static void wapp_ctrl_set_hs2_openmode_test_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "hs2_openmode_test", value);
}

static void wapp_ctrl_set_hs2_legacy_osu_enable(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "legacy_osu", value);
}

static void wapp_ctrl_set_qosmap_enable(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "qosmap", value);
}

static void wapp_ctrl_set_qosmap_dscp_range(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "dscp_range", value);
}

static void wapp_ctrl_set_qosmap_dscp_exception(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "dscp_exception", value);
}

static void wapp_ctrl_set_qload_mode(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "qload_test", value);
}

static void wapp_ctrl_set_qload_cu(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "qload_cu", value);
}

static void wapp_ctrl_set_qload_sta_cnt(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "qload_sta_cnt", value);
}

void wapp_ctrl_set_proxy_arp_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "proxy_arp", value);
}

static void wapp_ctrl_set_l2_filter_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "l2_filter", value);
}

static void wapp_ctrl_set_p2p_cross_connect_permitted_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "p2p_cross_connect_permitted", value);
}

static void wapp_ctrl_set_mmpdu_size_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "mmpdu_size", value);
}

static void wapp_ctrl_set_external_anqp_server_test_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "external_anqp_server_test", value);
}

static void wapp_ctrl_set_icmpv4_deny_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "icmpv4_deny", value);
}

static void wapp_ctrl_set_ipv4_type_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "ipv4_type", value);
}

static void wapp_ctrl_set_ipv6_type_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "ipv6_type", value);
}

static void wapp_ctrl_set_ip_type_id_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_ipv4_type_param(conf, confname, "n/a");
	wapp_ctrl_set_ipv6_type_param(conf, confname, "n/a");

	if (os_strcmp(value, "1") == 0) {
		wapp_ctrl_set_ipv4_type_param(conf, confname, "3");
		wapp_ctrl_set_ipv6_type_param(conf, confname, "0");
	} else {
		err(DEBUG_CAT_EVENT, "Unknown IP Type ID\n");
	}
}

static void wapp_ctrl_set_domain_name_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "domain_name", value);
}

static void wapp_ctrl_set_anonymous_nai_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "anonymous_nai", value);
}

static void wapp_ctrl_set_iconfile_path_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "icon_path", value);
}

static void wapp_ctrl_set_icon_tag_param(struct wapp_conf *conf, const char *conf_name, char *val)
{
	long value = 0;

	debug(DEBUG_CAT_EVENT, "(%s)\n", conf_name);

	value = strtol(val, NULL, 10);
	if (value == LONG_MAX || value == LONG_MIN)
		err(DEBUG_CAT_INIT, "strtol fail\n");
	else
		conf->icon_tag = (u8)value;
	wapp_ctrl_set_general_param(conf_name, "icon_tag", val);
}

static void hotspot_set_multiple_param_nums(struct wapp_conf *conf, const char *param, u8 param_nums)
{
	if (os_strcmp(param, "venue_name") == 0)
		conf->venue_name_nums = param_nums;
	else if (os_strcmp(param, "network_auth_type") == 0)
		conf->network_auth_type_nums = param_nums;
	else if (os_strcmp(param, "op_friendly_name") == 0)
		conf->op_friendly_name_nums = param_nums;
	else if (os_strcmp(param, "plmn") == 0)
		conf->plmn_nums = param_nums;
	else if (os_strcmp(param, "proto_port") == 0)
		conf->proto_port_nums = param_nums;
	else if (os_strcmp(param, "wan_metrics") == 0)
		conf->wan_metrics_nums = param_nums;
	else if (os_strcmp(param, "nai_realm_data") == 0)
		conf->nai_realm_data_nums = param_nums;
	else if (os_strcmp(param, "osu_providers_list") == 0)
		conf->osu_providers_list_nums = param_nums;
	else if (os_strcmp(param, "venue_url") == 0)
		conf->venue_url_nums = param_nums;
	else if (os_strcmp(param, "osu_providers_nai_list") == 0)
		conf->osu_providers_nai_nums = param_nums;
	else
		err(DEBUG_CAT_EVENT, "Unknown parameters(%s)\n", param);
}

static u8 hotspot_get_multiple_param_nums(struct wapp_conf *conf, const char *param)
{
	u8 param_nums = 0;

	if (os_strcmp(param, "venue_name") == 0)
		param_nums = conf->venue_name_nums;
	else if (os_strcmp(param, "network_auth_type") == 0)
		param_nums = conf->network_auth_type_nums;
	else if (os_strcmp(param, "op_friendly_name") == 0)
		param_nums = conf->op_friendly_name_nums;
	else if (os_strcmp(param, "plmn") == 0)
		param_nums = conf->plmn_nums;
	else if (os_strcmp(param, "proto_port") == 0)
		param_nums = conf->proto_port_nums;
	else if (os_strcmp(param, "wan_metrics") == 0)
		param_nums = conf->wan_metrics_nums;
	else if (os_strcmp(param, "nai_realm_data") == 0)
		param_nums = conf->nai_realm_data_nums;
	else if (os_strcmp(param, "osu_providers_list") == 0)
		param_nums = conf->osu_providers_list_nums;
	else if (os_strcmp(param, "venue_url") == 0)
		param_nums = conf->venue_url_nums;
	else if (os_strcmp(param, "osu_providers_nai_list") == 0)
		param_nums = conf->osu_providers_nai_nums;
	else
		err(DEBUG_CAT_EVENT, "Unknown parameters(%s)\n", param);

	return param_nums;
}
static void wapp_ctrl_set_general_multiple_param(struct wapp_conf *conf, const char *confname, const char *param, const char *value)
{
	FILE *file, *tmpfile;
	char buf[256];
	char tmp_confname[256];
	char *tmp_ptr;
	u8 cur_param_nums = 0;
	u8 total_param_nums = 0;
	int ret = 0;

	os_memset(buf, 0, 256);

	tmp_ptr = strrchr(confname, '/');
	if (!tmp_ptr) {
		err(DEBUG_CAT_EVENT, "strrchr fail\n");
		return;
	}
	os_strncpy(tmp_confname, confname, strlen(confname) - strlen(tmp_ptr));
	tmp_confname[strlen(confname) - strlen(tmp_ptr)] = '\0';

	ret = os_snprintf(tmp_confname + strlen(tmp_confname), sizeof(tmp_confname) - strlen(tmp_confname), "%s",
			  "/wapp_ap_interface.conf");
	if (os_snprintf_error(sizeof(tmp_confname) - strlen(tmp_confname), ret)) {
		err(DEBUG_CAT_EVENT, "os_snprintf fail\n");
		return;
	}

	if (os_strcmp(value, "n/a") == 0) {
		wapp_ctrl_clear_general_multiple_param(confname, param);
		hotspot_set_multiple_param_nums(conf, param, 0);
	} else {
		file = fopen(confname, "r");

		if (!file) {
			err(DEBUG_CAT_EVENT, "open configuration(%s) fail\n", confname);
			return;
		}

		tmpfile = fopen(tmp_confname, "w");

		if (!tmpfile) {
			err(DEBUG_CAT_EVENT, "open configuration(%s) fail\n", tmp_confname);
			ret = fclose(file);
			if (ret != 0)
				err(DEBUG_CAT_EVENT, "fclose fail\n");
			return;
		}

		total_param_nums = hotspot_get_multiple_param_nums(conf, param);
		while (fgets(buf, sizeof(buf), file) != NULL) {
			if ((strstr(buf, param) != NULL)) {
				cur_param_nums++;
				if (total_param_nums == cur_param_nums) {
					ret = fputs(buf, tmpfile);
					if (ret == EOF) {
						err(DEBUG_CAT_EVENT, "fputs fail\n");
						break;
					}

					if (strcmp(param, "venue_name") == 0) {
						int tmplen, is_end = 0;
						do {
							for (tmplen = 0; tmplen < strlen(buf); tmplen++) {
								if (buf[tmplen] == '}') {
									is_end = 1;
									break;
								}
							}

							if (is_end == 0) {
								os_memset(buf, 0, 256);
								if (fgets(buf, sizeof(buf), file) == NULL)
									break;
								ret = fputs(buf, tmpfile);
								if (ret == EOF) {
									err(DEBUG_CAT_EVENT, "fputs fail\n");
									break;
								}
							}
						} while (is_end == 0);
					}

					ret = fprintf(tmpfile, "%s=%s\n", param, value);
					if (ret < 0) {
						err(DEBUG_CAT_EVENT, "fprintf fail\n");
						break;
					}
					total_param_nums++;
					hotspot_set_multiple_param_nums(conf, param, total_param_nums);
				} else if (total_param_nums < cur_param_nums) {
					ret = fprintf(tmpfile, "%s=%s\n", param, value);
					if (ret < 0) {
						err(DEBUG_CAT_EVENT, "fprintf fail\n");
						break;
					}
					hotspot_set_multiple_param_nums(conf, param, 1);
				} else {
					ret = fputs(buf, tmpfile);
					if (ret == EOF) {
						err(DEBUG_CAT_EVENT, "fputs fail\n");
						break;
					}
				}
			} else {
				ret = fputs(buf, tmpfile);
				if (ret == EOF) {
					err(DEBUG_CAT_EVENT, "fputs fail\n");
					break;
				}
			}
		}

		ret = fclose(tmpfile);
		if (ret != 0)
			err(DEBUG_CAT_EVENT, "fclose %s fail\n", tmp_confname);
		ret = fclose(file);
		if (ret != 0)
			err(DEBUG_CAT_EVENT, "fclose %s fail\n", confname);

		if (unlink(confname) < 0)
			err(DEBUG_CAT_EVENT, "unlink(%s) fail\n", confname);

		if (rename(tmp_confname, confname) < 0)
			err(DEBUG_CAT_EVENT, "rename(%s, %s) fail\n", tmp_confname, confname);
	}
}

static void wapp_ctrl_set_venue_name_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_multiple_param(conf, confname, "venue_name", value);
}

static void wapp_ctrl_set_venue_name_id_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_venue_name_param(conf, confname, "n/a");

	if (os_strcmp(value, "1") == 0) {
		wapp_ctrl_set_venue_name_param(conf, confname, "eng%{Wi-Fi Alliance\n\
								2989 Copper Road\n\
								Santa Clara, CA 95051, USA}");
		wapp_ctrl_set_venue_name_param(conf, confname, "chi%{Wi-Fi联盟实验室\n\
								二九八九年库柏路\n\
								圣克拉拉, 加利福尼亚95051, 美国}");
	} else {
		err(DEBUG_CAT_EVENT, "Unknown Venue Name ID\n");
	}
}

static void wapp_ctrl_set_network_auth_type_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_multiple_param(conf, confname, "network_auth_type", "n/a");
	wapp_ctrl_set_general_multiple_param(conf, confname, "network_auth_type", value);
}

static void wapp_ctrl_set_net_auth_type_id_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_multiple_param(conf, confname, "network_auth_type", "n/a");

	if (os_strcmp(value, "1") == 0) {
		wapp_ctrl_set_general_multiple_param(conf, confname, "network_auth_type", "0,https://tandc-server.wi-fi.org");
	} else if (os_strcmp(value, "2") == 0) {
		wapp_ctrl_set_general_multiple_param(conf, confname, "network_auth_type", "1");
	} else {
		err(DEBUG_CAT_EVENT, "Unknown Auth Type ID\n");
	}
}

static void wapp_ctrl_set_op_friendly_name_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_multiple_param(conf, confname, "op_friendly_name", value);
}

static void wapp_ctrl_set_op_friendly_name_id_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_op_friendly_name_param(conf, confname, "n/a");

	if (os_strcmp(value, "1") == 0) {
		wapp_ctrl_set_op_friendly_name_param(conf, confname, "eng,Wi-Fi Alliance");
		wapp_ctrl_set_op_friendly_name_param(conf, confname, "chi,Wi-Fi联盟");
	} else {
		err(DEBUG_CAT_EVENT, "Unknown Operator Friendly Name ID\n");
	}
}

static void wapp_ctrl_clear_brace_multiple_param(struct wapp_conf *conf, const char *confname, const char *param)
{
	FILE *file, *tmpfile;
	char tmpbuf[256];
	char buf[256];
	char tmp_confname[256];
	char *tmp_ptr;
	u8 is_brace_open = 0;
	u8 cur_param_nums = 0;
	u8 total_param_nums = 0;
	int ret = 0;

	os_memset(tmpbuf, 0, 256);
	os_memset(buf, 0, 256);

	tmp_ptr = strrchr(confname, '/');
	if (!tmp_ptr) {
		err(DEBUG_CAT_EVENT, "strrchr fail\n");
		return;
	}
	os_strncpy(tmp_confname, confname, strlen(confname) - strlen(tmp_ptr));
	tmp_confname[strlen(confname) - strlen(tmp_ptr)] = '\0';

	ret = os_snprintf(tmp_confname + strlen(tmp_confname), sizeof(tmp_confname) - strlen(tmp_confname), "%s",
			  "/wapp_ap_interface.conf");
	if (os_snprintf_error(sizeof(tmp_confname) - strlen(tmp_confname), ret)) {
		err(DEBUG_CAT_EVENT, "os_snprintf fail\n");
		return;
	}

	file = fopen(confname, "r");

	if (!file) {
		err(DEBUG_CAT_EVENT, "open configuration(%s) fail\n", confname);
		return;
	}

	tmpfile = fopen(tmp_confname, "w");

	if (!tmpfile) {
		err(DEBUG_CAT_EVENT, "open configuration(%s) fail\n", tmp_confname);
		ret = fclose(file);
		if (ret < 0)
			err(DEBUG_CAT_EVENT, "fclose %s fail\n", confname);
		return;
	}

	total_param_nums = hotspot_get_multiple_param_nums(conf, param);

	if (total_param_nums == 0) {
		ret = os_snprintf(tmpbuf, sizeof(tmpbuf), "%s=n/a\n", param);
		if (os_snprintf_error(sizeof(tmpbuf), ret)) {
			err(DEBUG_CAT_EVENT, "os_snprintf fail\n");
			goto out;
		}
	} else {
		ret = os_snprintf(tmpbuf, sizeof(tmpbuf), "%s={\n", param);
		if (os_snprintf_error(sizeof(tmpbuf), ret)) {
			err(DEBUG_CAT_EVENT, "os_snprintf fail\n");
			goto out;
		}
	}

	while (fgets(buf, sizeof(buf), file) != NULL) {
		if (strstr(buf, tmpbuf) != NULL) {
			if ((total_param_nums == 0) || (cur_param_nums == (total_param_nums - 1))) {
				ret = fprintf(tmpfile, "%s=n/a\n", param);
				if (ret < 0) {
					err(DEBUG_CAT_EVENT, "fprintf fail\n");
					break;
				}
			}
			if (total_param_nums != 0)
				is_brace_open = 1;
		} else if (strstr(buf, "}") != NULL && is_brace_open) {
			cur_param_nums++;
			is_brace_open = 0;
		} else {
			if (!is_brace_open) {
				ret = fputs(buf, tmpfile);
				if (ret == EOF) {
					err(DEBUG_CAT_EVENT, "fputs fail\n");
					break;
				}
			}
		}
	}
out:
	ret = fclose(tmpfile);
	if (ret != 0)
		err(DEBUG_CAT_EVENT, "fclose %s fail\n", tmp_confname);
	ret = fclose(file);
	if (ret != 0)
		err(DEBUG_CAT_EVENT, "fclose %s fail\n", confname);

	if (unlink(confname) < 0)
		err(DEBUG_CAT_EVENT, "unlink(%s) fail\n", confname);

	if (rename(tmp_confname, confname) < 0)
		err(DEBUG_CAT_EVENT, "rename(%s, %s) fail\n", tmp_confname, confname);
}

static void wapp_ctrl_set_brace_multiple_param(struct wapp_conf *conf, const char *confname, const char *param, const char *value)
{
	FILE *file, *tmpfile;
	char *token;
	char buf[512], tmp_value[512];
	char tmp_confname[512];
	char *tmp_ptr;
	u8 cur_param_nums = 0;
	u8 total_param_nums = 0;
	u8 is_param = 0;
	int ret = 0;

	os_memset(buf, 0, 512);
	os_memset(tmp_value, 0, 512);

	tmp_ptr = strrchr(confname, '/');
	if (!tmp_ptr) {
		err(DEBUG_CAT_EVENT, "strrchr fail\n");
		return;
	}
	os_strncpy(tmp_confname, confname, strlen(confname) - strlen(tmp_ptr));
	tmp_confname[strlen(confname) - strlen(tmp_ptr)] = '\0';

	ret = os_snprintf(tmp_confname + strlen(tmp_confname), sizeof(tmp_confname) - strlen(tmp_confname), "%s",
			  "/wapp_ap_interface.conf");
	if (os_snprintf_error(sizeof(tmp_confname) - strlen(tmp_confname), ret)) {
		err(DEBUG_CAT_EVENT, "os_snprintf fail\n");
		return;
	}

	if (os_strcmp(value, "n/a") == 0) {
		wapp_ctrl_clear_brace_multiple_param(conf, confname, param);
		hotspot_set_multiple_param_nums(conf, param, 0);
	} else {
		file = fopen(confname, "r");

		if (!file) {
			err(DEBUG_CAT_EVENT, "open configuration(%s) fail\n", confname);
			return;
		}

		tmpfile = fopen(tmp_confname, "w");

		if (!tmpfile) {
			err(DEBUG_CAT_EVENT, "open configuration(%s) fail\n", tmp_confname);
			ret = fclose(file);
			if (ret != 0)
				err(DEBUG_CAT_EVENT, "fclose %s fail\n", confname);
			return;
		}

		total_param_nums = hotspot_get_multiple_param_nums(conf, param);
		os_memset(tmp_value, 0, 512);
		if (os_strlen(value) < sizeof(tmp_value))
			os_memcpy(tmp_value, value, os_strlen(value));
		else
			err(DEBUG_CAT_EVENT, "value length exceed tmp_value size.\n");

		while (fgets(buf, sizeof(buf), file) != NULL) {
			if ((strstr(buf, param) != NULL)) {
				is_param = 1;
				if (total_param_nums == 0) {
					ret = fprintf(tmpfile, "%s={\n", param);
					if (ret < 0) {
						err(DEBUG_CAT_EVENT, "fprintf fail\n");
						break;
					}
					token = strtok(tmp_value, ",");
					if (token == NULL) {
						err(DEBUG_CAT_EVENT, "strtok fail\n");
						break;
					}
					do {
						ret = fprintf(tmpfile, "	%s=", token);
						if (ret < 0) {
							err(DEBUG_CAT_EVENT, "fprintf fail\n");
							break;
						}
						token = strtok(NULL, ",");
						if (token == NULL) {
							err(DEBUG_CAT_EVENT, "strtok fail\n");
							break;
						}
						ret = fprintf(tmpfile, "%s\n", token);
						if (ret < 0) {
							err(DEBUG_CAT_EVENT, "fprintf fail\n");
							break;
						}
						token = strtok(NULL, ",");
					} while (token != NULL);
					ret = fprintf(tmpfile, "}\n");
					if (ret < 0) {
						err(DEBUG_CAT_EVENT, "fprintf fail\n");
						break;
					}
					hotspot_set_multiple_param_nums(conf, param, 1);
				} else {
					ret = fputs(buf, tmpfile);
					if (ret == EOF) {
						err(DEBUG_CAT_EVENT, "fputs fail\n");
						break;
					}
				}
			} else {
				if ((strstr(buf, "}") != NULL) && (is_param)) {
					cur_param_nums++;
					if (cur_param_nums == total_param_nums) {
						fputs(buf, tmpfile);
						fprintf(tmpfile, "%s={\n", param);
						token = strtok(tmp_value, ",");
						do {
							ret = fprintf(tmpfile, "	%s=", token);
							if (ret < 0) {
								err(DEBUG_CAT_EVENT, "fprintf fail\n");
								break;
							}
							token = strtok(NULL, ",");
							if (token == NULL) {
								err(DEBUG_CAT_EVENT, "strtok fail\n");
								break;
							}
							ret = fprintf(tmpfile, "%s\n", token);
							if (ret < 0) {
								err(DEBUG_CAT_EVENT, "fprintf fail\n");
								break;
							}
							token = strtok(NULL, ",");
						} while (token != NULL);
						ret = fprintf(tmpfile, "}\n");
						if (ret < 0) {
							err(DEBUG_CAT_EVENT, "fprintf fail\n");
							break;
						}
						total_param_nums++;
						hotspot_set_multiple_param_nums(conf, param, total_param_nums);
					} else {
						ret = fputs(buf, tmpfile);
						if (ret == EOF) {
							err(DEBUG_CAT_EVENT, "fputs fail\n");
							break;
						}
					}

					is_param = 0;
				} else {
					ret = fputs(buf, tmpfile);
					if (ret == EOF) {
						err(DEBUG_CAT_EVENT, "fputs fail\n");
						break;
					}
				}
			}
		}

		ret = fclose(tmpfile);
		if (ret != 0)
			err(DEBUG_CAT_EVENT, "fclose %s fail\n", tmp_confname);
		ret = fclose(file);
		if (ret != 0)
			err(DEBUG_CAT_EVENT, "fclose %s fail\n", confname);

		if (unlink(confname) < 0)
			err(DEBUG_CAT_EVENT, "unlink(%s) fail\n", confname);

		if (rename(tmp_confname, confname) < 0)
			err(DEBUG_CAT_EVENT, "rename(%s, %s) fail\n", tmp_confname, confname);
	}
}

static void wapp_ctrl_set_brace_multiple_param_special_delimiter(struct wapp_conf *conf, const char *confname, const char *param,
								 const char *value, const char *delimiter)
{
	FILE *file, *tmpfile;
	char *token;
	char buf[512], tmp_value[2048];
	char tmp_confname[512];
	char *tmp_ptr;
	u8 cur_param_nums = 0;
	u8 total_param_nums = 0;
	u8 is_param = 0;
	int ret = 0;

	os_memset(buf, 0, sizeof(buf));
	os_memset(tmp_value, 0, sizeof(tmp_value));

	tmp_ptr = strrchr(confname, '/');
	if (!tmp_ptr) {
		err(DEBUG_CAT_EVENT, "strrchr fail\n");
		return;
	}
	os_strncpy(tmp_confname, confname, strlen(confname) - strlen(tmp_ptr));
	tmp_confname[strlen(confname) - strlen(tmp_ptr)] = '\0';

	ret = os_snprintf(tmp_confname + strlen(tmp_confname), 512 - strlen(tmp_confname), "/wapp_ap_interface.conf");
	if (os_snprintf_error(sizeof(tmp_confname) - strlen(tmp_confname), ret)) {
		err(DEBUG_CAT_EVENT, "os_strncpy fail\n");
		return;
	}
	if (os_strcmp(value, "n/a") == 0) {
		wapp_ctrl_clear_brace_multiple_param(conf, confname, param);
		hotspot_set_multiple_param_nums(conf, param, 0);
	} else {
		if (os_strlen(value) > sizeof(tmp_value)) {
			err(DEBUG_CAT_EVENT, "the length of value exceed tmp_value size\n");
			return;
		}

		file = fopen(confname, "r");

		if (!file) {
			err(DEBUG_CAT_EVENT, "open configuration(%s) fail\n", confname);
			return;
		}

		tmpfile = fopen(tmp_confname, "w");

		if (!tmpfile) {
			err(DEBUG_CAT_EVENT, "open configuration(%s) fail\n", tmp_confname);
			ret = fclose(file);
			if (ret != 0)
				err(DEBUG_CAT_EVENT, "fclose fail\n");
			return;
		}

		total_param_nums = hotspot_get_multiple_param_nums(conf, param);
		os_memcpy(tmp_value, value, os_strlen(value));
		while (fgets(buf, sizeof(buf), file) != NULL) {
			if ((strstr(buf, param) != NULL)) {
				is_param = 1;
				if (total_param_nums == 0) {
					ret = fprintf(tmpfile, "%s={\n", param);
					if (ret < 0) {
						err(DEBUG_CAT_EVENT, "fprintf fail\n");
						break;
					}

					token = strtok(tmp_value, delimiter);
					if (!token) {
						err(DEBUG_CAT_EVENT, "strtok fail\n");
						break;
					}
					do {
						ret = fprintf(tmpfile, "%s=", token);
						if (ret < 0) {
							err(DEBUG_CAT_EVENT, "fprintf fail\n");
							break;
						}
						token = strtok(NULL, delimiter);
						if (!token) {
							err(DEBUG_CAT_EVENT, "strtok fail\n");
							break;
						}
						ret = fprintf(tmpfile, "%s\n", token);
						if (ret < 0) {
							err(DEBUG_CAT_EVENT, "fprintf fail\n");
							break;
						}
						token = strtok(NULL, delimiter);
					} while (token != NULL);
					ret = fprintf(tmpfile, "}\n");
					if (ret < 0) {
						err(DEBUG_CAT_EVENT, "fprintf fail\n");
						break;
					}
					hotspot_set_multiple_param_nums(conf, param, 1);
				} else {
					ret = fputs(buf, tmpfile);
					if (ret == EOF) {
						err(DEBUG_CAT_EVENT, "fputs fail\n");
						break;
					}
				}

			} else {
				if ((strstr(buf, "}") != NULL) && (is_param)) {
					cur_param_nums++;
					if (cur_param_nums == total_param_nums) {
						ret = fputs(buf, tmpfile);
						if (ret == EOF) {
							err(DEBUG_CAT_EVENT, "fputs fail\n");
							break;
						}
						ret = fprintf(tmpfile, "%s={\n", param);
						if (ret < 0) {
							err(DEBUG_CAT_EVENT, "fprintf fail\n");
							break;
						}
						token = strtok(tmp_value, delimiter);
						if (!token) {
							err(DEBUG_CAT_EVENT, "strtok fail\n");
							break;
						}
						do {
							ret = fprintf(tmpfile, "              %s=", token);
							if (ret < 0) {
								err(DEBUG_CAT_EVENT, "fprintf fail\n");
								break;
							}

							token = strtok(NULL, delimiter);
							if (!token) {
								err(DEBUG_CAT_EVENT, "strtok fail\n");
								break;
							}
							ret = fprintf(tmpfile, "%s\n", token);
							if (ret < 0) {
								err(DEBUG_CAT_EVENT, "fprintf fail\n");
								break;
							}
							token = strtok(NULL, delimiter);
						} while (token != NULL);
						ret = fprintf(tmpfile, "}\n");
						if (ret < 0) {
							err(DEBUG_CAT_EVENT, "fprintf fail\n");
							break;
						}

						total_param_nums++;
						hotspot_set_multiple_param_nums(conf, param, total_param_nums);
					} else {
						ret = fputs(buf, tmpfile);
						if (ret == EOF) {
							err(DEBUG_CAT_EVENT, "fputs fail\n");
							break;
						}
					}
					is_param = 0;
				} else {
					ret = fputs(buf, tmpfile);
					if (ret == EOF) {
						err(DEBUG_CAT_EVENT, "fputs fail\n");
						break;
					}
				}
			}
		}
		ret = fputs(buf, tmpfile);
		if (ret == EOF) {
			err(DEBUG_CAT_EVENT, "fputs fail\n");
			goto out;
		}
		ret = fputs(buf, file);
		if (ret == EOF) {
			err(DEBUG_CAT_EVENT, "fputs fail\n");
			goto out;
		}

		if (unlink(confname) < 0)
			err(DEBUG_CAT_EVENT, "unlink(%s) fail\n", confname);
		if (rename(tmp_confname, confname) < 0)
			err(DEBUG_CAT_EVENT, "rename(%s, %s) fail\n", tmp_confname, confname);
	out:
		ret = fclose(file);
		if (ret != 0)
			err(DEBUG_CAT_EVENT, "fclose %s fail\n", confname);
		ret = fclose(tmpfile);
		if (ret != 0)
			err(DEBUG_CAT_EVENT, "fclose %s fail\n", tmp_confname);
	}
}

static void wapp_ctrl_set_plmn_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_brace_multiple_param(conf, confname, "plmn", value);
}

static void wapp_ctrl_set_operating_class_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "operating_class", value);
}

static void wapp_ctrl_set_operating_class_id_param(struct wapp_conf *conf, const char *confname, char *value)
{
	if (os_strcmp(value, "1") == 0) {
		wapp_ctrl_set_operating_class_param(conf, confname, "81");
	} else if (os_strcmp(value, "2") == 0) {
		wapp_ctrl_set_operating_class_param(conf, confname, "115");
	} else if (os_strcmp(value, "3") == 0) {
		wapp_ctrl_set_operating_class_param(conf, confname, "81,115");
	} else {
		err(DEBUG_CAT_EVENT, "Unknown Operating Class ID\n");
	}
}

static void wapp_ctrl_set_preferred_candi_list_included_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "preferred_candi_list_included", value);
}

static void wapp_ctrl_set_abridged_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "abridged", value);
}

static void wapp_ctrl_set_disassociation_imminent_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "disassociation_imminent", value);
}

static void wapp_ctrl_set_bss_termination_included_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "bss_termination_included", value);
}

static void wapp_ctrl_set_ess_disassociation_imminent_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "ess_disassociation_imminent", value);
}

static void wapp_ctrl_set_disassociation_timer_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "disassociation_timer", value);
}

static void wapp_ctrl_set_validity_interval_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "validity_interval", value);
}

static void wapp_ctrl_set_bss_termination_duration_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "bss_termination_duration", value);
}

static void wapp_ctrl_set_session_information_url_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "session_information_url", value);
}

static void wapp_ctrl_set_t_c_filename_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "t_c_filename", value);
}

static void wapp_ctrl_set_t_c_filename_id_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_t_c_filename_param(conf, confname, "n/a");

	if (os_strcmp(value, "1") == 0) {
		wapp_ctrl_set_t_c_filename_param(conf, confname, "tandc-id1-content.txt");
	} else
		err(DEBUG_CAT_EVENT, "Unknown TnC filename id ID\n");
}

static void wapp_ctrl_set_t_c_timestamp_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "t_c_timestamp", value);
}

static void wapp_ctrl_set_osu_providers_nai_list_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_multiple_param(conf, confname, "osu_providers_nai_list", value);
}

static void wapp_ctrl_set_osu_providers_nai_id_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_osu_providers_nai_list_param(conf, confname, "n/a");

	if (os_strcmp(value, "1") == 0) {
		wapp_ctrl_set_osu_providers_nai_list_param(conf, confname, "21,anonymous@hotspot.net");
	} else if (os_strcmp(value, "2") == 0) {
		wapp_ctrl_set_osu_providers_nai_list_param(conf, confname, "24,test-anonymous@wi-fi.org");
	} else if (os_strcmp(value, "3") == 0) {
		wapp_ctrl_set_osu_providers_nai_list_param(conf, confname, "24,test-anonymous@wi-fi.org");
		wapp_ctrl_set_osu_providers_nai_list_param(conf, confname, "21,anonymous@hotspot.net");
	} else if (os_strcmp(value, "4") == 0) {
		wapp_ctrl_set_osu_providers_nai_list_param(conf, confname, "18,random@hotspot.net");
		wapp_ctrl_set_osu_providers_nai_list_param(conf, confname, "21,anonymous@hotspot.net");
	} else
		err(DEBUG_CAT_EVENT, "Unknown Osu providers nai lits ID\n");
}

static void wapp_ctrl_set_oim_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "icon_metadata", value);
}

static void wapp_ctrl_set_oim_id_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_oim_param(conf, confname, "n/a");

	if (os_strcmp(value, "1") == 0) {
		wapp_ctrl_set_oim_param(conf, confname, "160:76:eng:image/png:icon_red_eng.png");
	} else
		err(DEBUG_CAT_EVENT, "Unkwnown OIM ID");
}

static void wapp_ctrl_set_bss_transisition_candi_list_preferences_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_param(confname, "bss_transisition_candi_list_preferences", value);
}

static void wapp_ctrl_set_proto_port_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_brace_multiple_param(conf, confname, "proto_port", value);
}

static void wapp_ctrl_set_con_cap_id_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_proto_port_param(conf, confname, "n/a");

	if (os_strcmp(value, "1") == 0) {
		wapp_ctrl_set_proto_port_param(conf, confname, "ip_protocol,1,port,0,status,0");
		wapp_ctrl_set_proto_port_param(conf, confname, "ip_protocol,6,port,20,status,1");
		wapp_ctrl_set_proto_port_param(conf, confname, "ip_protocol,6,port,22,status,0");
		wapp_ctrl_set_proto_port_param(conf, confname, "ip_protocol,6,port,80,status,1");
		wapp_ctrl_set_proto_port_param(conf, confname, "ip_protocol,6,port,443,status,1");
		wapp_ctrl_set_proto_port_param(conf, confname, "ip_protocol,6,port,1723,status,0");
		wapp_ctrl_set_proto_port_param(conf, confname, "ip_protocol,6,port,5060,status,0");
		wapp_ctrl_set_proto_port_param(conf, confname, "ip_protocol,17,port,500,status,1");
		wapp_ctrl_set_proto_port_param(conf, confname, "ip_protocol,17,port,5060,status,0");
		wapp_ctrl_set_proto_port_param(conf, confname, "ip_protocol,17,port,4500,status,1");
		wapp_ctrl_set_proto_port_param(conf, confname, "ip_protocol,50,port,0,status,1");
	} else if (os_strcmp(value, "3") == 0) {
		wapp_ctrl_set_proto_port_param(conf, confname, "ip_protocol,6,port,80,status,1");
		wapp_ctrl_set_proto_port_param(conf, confname, "ip_protocol,6,port,443,status,1");
	} else if (os_strcmp(value, "4") == 0) {
		wapp_ctrl_set_proto_port_param(conf, confname, "ip_protocol,6,port,80,status,1");
		wapp_ctrl_set_proto_port_param(conf, confname, "ip_protocol,6,port,443,status,1");
		wapp_ctrl_set_proto_port_param(conf, confname, "ip_protocol,6,port,5060,status,1");
		wapp_ctrl_set_proto_port_param(conf, confname, "ip_protocol,17,port,5060,status,1");
	} else if (os_strcmp(value, "5") == 0) {
	} else {
		err(DEBUG_CAT_EVENT, "Unknown Connection Capability ID\n");
	}
}

static void wapp_ctrl_set_wan_metrics_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_brace_multiple_param(conf, confname, "wan_metrics", value);
}

static void wapp_ctrl_set_wan_metrics_id_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_wan_metrics_param(conf, confname, "n/a");

	if (os_strcmp(value, "1") == 0) {
		wapp_ctrl_set_wan_metrics_param(conf, confname,
						"link_status,1,at_capacity,0,dl_speed,2500,ul_speed,384,dl_load,0,up_load,0,lmd,10");
	} else if (os_strcmp(value, "2") == 0) {
		wapp_ctrl_set_wan_metrics_param(conf, confname,
						"link_status,1,at_capacity,0,dl_speed,1500,ul_speed,384,dl_load,20,up_load,20,lmd,10");
	} else if (os_strcmp(value, "3") == 0) {
		wapp_ctrl_set_wan_metrics_param(conf, confname,
						"link_status,1,at_capacity,0,dl_speed,2000,ul_speed,1000,dl_load,20,up_load,20,lmd,10");
	} else if (os_strcmp(value, "4") == 0) {
		wapp_ctrl_set_wan_metrics_param(conf, confname,
						"link_status,1,at_capacity,0,dl_speed,8000,ul_speed,1000,dl_load,20,up_load,20,lmd,10");
	} else if (os_strcmp(value, "5") == 0) {
		wapp_ctrl_set_wan_metrics_param(conf, confname,
						"link_status,1,at_capacity,0,dl_speed,9000,ul_speed,5000,dl_load,20,up_load,20,lmd,10");
	} else {
		err(DEBUG_CAT_EVENT, "Unknown WAN Metrics ID\n");
	}
}

static void wapp_ctrl_set_nai_realm_data_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_brace_multiple_param(conf, confname, "nai_realm_data", value);
}

static void wapp_ctrl_set_nai_realm_id_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_nai_realm_data_param(conf, confname, "n/a");

	if (os_strcmp(value, "1") == 0) {
		wapp_ctrl_set_nai_realm_data_param(conf, confname,
						   "nai_realm,mail.example.com,eap_method,eap-ttls,auth_param,2:4,auth_param,5:7");
		wapp_ctrl_set_nai_realm_data_param(conf, confname, "nai_realm,cisco.com,eap_method,eap-ttls,auth_param,2:4,auth_param,5:7");
		wapp_ctrl_set_nai_realm_data_param(
			conf, confname,
			"nai_realm,wi-fi.org,eap_method,eap-ttls,auth_param,2:4,auth_param,5:7,eap_method,eap-tls,auth_param,5:6");
		wapp_ctrl_set_nai_realm_data_param(conf, confname, "nai_realm,example.com,eap_method,eap-tls,auth_param,5:6");
	} else if (os_strcmp(value, "2") == 0) {
		wapp_ctrl_set_nai_realm_data_param(conf, confname, "nai_realm,wi-fi.org,eap_method,eap-ttls,auth_param,2:4,auth_param,5:7");
	} else if (os_strcmp(value, "3") == 0) {
		wapp_ctrl_set_nai_realm_data_param(conf, confname, "nai_realm,cisco.com,eap_method,eap-ttls,auth_param,2:4,auth_param,5:7");
		wapp_ctrl_set_nai_realm_data_param(
			conf, confname,
			"nai_realm,wi-fi.org,eap_method,eap-ttls,auth_param,2:4,auth_param,5:7,eap_method,eap-tls,auth_param,5:6");
		wapp_ctrl_set_nai_realm_data_param(conf, confname, "nai_realm,example.com,eap_method,eap-tls,auth_param,5:6");
	} else if (os_strcmp(value, "4") == 0) {
		wapp_ctrl_set_nai_realm_data_param(
			conf, confname,
			"nai_realm,mail.example.com,eap_method,eap-ttls,auth_param,2:4,auth_param,5:7,eap_method,eap-tls,auth_param,5:6");
	} else if (os_strcmp(value, "5") == 0) {
		wapp_ctrl_set_nai_realm_data_param(conf, confname, "nai_realm,wi-fi.org,eap_method,eap-ttls,auth_param,2:4,auth_param,5:7");
		wapp_ctrl_set_nai_realm_data_param(conf, confname,
						   "nai_realm,ruckuswireless.com,eap_method,eap-ttls,auth_param,2:4,auth_param,5:7");
	} else if (os_strcmp(value, "6") == 0) {
		wapp_ctrl_set_nai_realm_data_param(conf, confname, "nai_realm,wi-fi.org,eap_method,eap-ttls,auth_param,2:4,auth_param,5:7");
		wapp_ctrl_set_nai_realm_data_param(conf, confname,
						   "nai_realm,mail.example.com,eap_method,eap-ttls,auth_param,2:4,auth_param,5:7");
	} else if (os_strcmp(value, "7") == 0) {
		wapp_ctrl_set_nai_realm_data_param(
			conf, confname,
			"nai_realm,wi-fi.org,eap_method,eap-ttls,auth_param,2:4,auth_param,5:7,eap_method,eap-tls,auth_param,5:6");
	} else {
		err(DEBUG_CAT_EVENT, "Unknown NAI Realm List ID\n");
	}
}

static void wapp_ctrl_set_venue_url_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_general_multiple_param(conf, confname, "venue_url_data", value);
}

static void wapp_ctrl_set_venue_url_id_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_venue_url_param(conf, confname, "n/a");

	if (os_strcmp(value, "1") == 0) {
		wapp_ctrl_set_venue_url_param(conf, confname, "1,https://venue-server.r2m-test bed.wi-fi.org/floorplans/index.html");
		wapp_ctrl_set_venue_url_param(conf, confname, "1,https://venue-server.r2m-test bed.wi-fi.org/directory/index.html");
	} else if (os_strcmp(value, "2") == 0) {
		wapp_ctrl_set_venue_url_param(conf, confname, "1,https://the-great-mall.r2m-test bed.wi-fi.org/floorplans/index.html");
		wapp_ctrl_set_venue_url_param(conf, confname, "2,https://abercrombie.r2m-test bed.wi-fi.org/floorplans/index.html");
		wapp_ctrl_set_venue_url_param(conf, confname, "3,https://adidas.r2m-test bed.wi-fi.org/floorplans/index.html");
		wapp_ctrl_set_venue_url_param(conf, confname, "4,https://aeropostale.r2m-test bed.wi-fi.org/floorplans/index.html");
		wapp_ctrl_set_venue_url_param(conf, confname, "5,https://agaci.r2m-test bed.wi-fi.org/floorplans/index.html");
		wapp_ctrl_set_venue_url_param(conf, confname, "6,https://aldo-shoes.r2m-test bed.wi-fi.org/floorplans/index.html");
		wapp_ctrl_set_venue_url_param(conf, confname,
					      "7,https://american-eagle-outfitters.r2m-test bed.wi-fi.org/floorplans/index.html");
		wapp_ctrl_set_venue_url_param(conf, confname, "8,https://anderson-bakery.r2m-test bed.wi-fi.org/floorplans/index.html");
		wapp_ctrl_set_venue_url_param(conf, confname,
					      "9,https://banana-republic-factory-store.r2m-test bed.wi-fi.org/floorplans/index.html");
		wapp_ctrl_set_venue_url_param(conf, confname,
					      "10,https://bed-bath-and-beyond.r2m-test bed.wi-fi.org/floorplans/index.html");
	} else {
		err(DEBUG_CAT_EVENT, "Unknown Venue URL ID\n");
	}
}

static void wapp_ctrl_set_advice_of_charge_data_param(struct wapp_conf *conf, const char *confname, char *value, const char *delimiter)
{
	wapp_ctrl_set_brace_multiple_param_special_delimiter(conf, confname, "advice_of_charge_data", value, delimiter);
}

static void wapp_ctrl_set_advice_of_charge_id_param(struct wapp_conf *conf, const char *confname, char *value)
{
	char conf_content[2048] = {0};
	wapp_ctrl_set_advice_of_charge_data_param(conf, confname, "n/a", "*");

	if (os_strcmp(value, "1") == 0) {
		os_strncpy(
			conf_content,
			"advice_of_charge_type*0*aoc_realm_encoding*0*aoc_realm*N/"
			"A*aoc_language*ENG*aoc_currency_code*USD*aoc_plan_info*<\?xml version=\"1.0\" encoding=\"UTF-8\"\?><Plan "
			"xmlns=\"http://www.wi-fi.org/specifications/hotspot2dot0/v1.0/aocpi\"><Description>Wi-Fi access for 1 hour, while "
			"you wait at the gate, $0.99</Description></Plan>*aoc_language*FRA*aoc_currency_code*CAD*aoc_plan_info*<\?xml "
			"version=\"1.0\" encoding=\"UTF-8\"\?><Plan "
			"xmlns=\"http://www.wi-fi.org/specifications/hotspot2dot0/v1.0/aocpi\"><Description>Accès Wi-Fi pendant 1 heure, "
			"pendant que vous attendez Ãla porte, 0,99 $</Description></Plan>",
			sizeof(conf_content));

		wapp_ctrl_set_advice_of_charge_data_param(conf, confname, conf_content, "*");

		os_memset(conf_content, 0, sizeof(conf_content));
		os_strncpy(conf_content,
			   "advice_of_charge_type*1*aoc_realm_encoding*0*aoc_realm*N/"
			   "A*aoc_language*ENG*aoc_currency_code*USD*aoc_plan_info*<?xml version=\"1.0\" encoding=\"UTF-8\"?><Plan "
			   "xmlns=\"http://www.wi-fi.org/specifications/hotspot2dot0/v1.0/aocpi\"><Description>Download videos for your "
			   "flight, $2.99 for 10GB</Description></Plan>*aoc_language*FRA*aoc_currency_code*CAD*aoc_plan_info*<?xml "
			   "version=\"1.0\" encoding=\"UTF-8\"?><Plan "
			   "xmlns=\"http://www.wi-fi.org/specifications/hotspot2dot0/v1.0/aocpi\"><Description>Téléchargez des vidéos pour "
			   "votre vol, 2,99 $ pour 10 Go</Description></Plan>",
			   sizeof(conf_content));

		wapp_ctrl_set_advice_of_charge_data_param(conf, confname, conf_content, "*");

		os_memset(conf_content, 0, sizeof(conf_content));
		os_strncpy(conf_content,
			   "advice_of_charge_type*3*aoc_realm_encoding*0*aoc_realm*service-provider.com*aoc_language*ENG*aoc_currency_code*"
			   "USD*aoc_plan_info*<?xml version=\"1.0\" encoding=\"UTF-8\"?><Plan "
			   "xmlns=\"http://www.wi-fi.org/specifications/hotspot2dot0/v1.0/aocpi\"><Description>Free with your "
			   "subscription!</Description></Plan>",
			   sizeof(conf_content));

		wapp_ctrl_set_advice_of_charge_data_param(conf, confname, conf_content, "*");
	} else
		err(DEBUG_CAT_EVENT, "Unknown Advice Of Charge ID\n");
}

static void wapp_ctrl_set_osu_providers_list_param(struct wapp_conf *conf, const char *confname, char *value)
{
	wapp_ctrl_set_brace_multiple_param(conf, confname, "osu_providers_list", value);
}

static void wapp_ctrl_set_osu_providers_list_id_param(struct wapp_conf *conf, const char *confname, char *value)
{
	char *token, *url = NULL, tmpbuf[2048];
	char *url2 = NULL;
	int ret = 0;
	int osu_method = 0, osu_method2 = 0; //, osu_method3, osu_method4;
	long val = 0;

	os_memset(tmpbuf, 0, 2048);

	wapp_ctrl_set_brace_multiple_param(conf, confname, "osu_providers_list", "n/a");

	token = strtok(value, ",");
	if (token != NULL) {
		int provider_id = strtol(value, NULL, 10);

		printf("Provider ID = %d\n", provider_id);
		if (provider_id != 6) {
			url = strtok(NULL, ",");
			printf("Provider URL = %s\n", url);
			if (url != NULL) {
				char *method = NULL;
				method = strtok(NULL, ",");
				if (method != NULL) {
					val = strtol(method, NULL, 10);
					if (val == LONG_MAX || val == LONG_MIN)
						err(DEBUG_CAT_INIT, "strtol fail\n");
					else
						osu_method = (int)val;
					printf("Provider METHOD = %d\n", osu_method);
				}
			}

		} else {
			url = strtok(NULL, ",");
			printf("URL = %s\n", url);
			if (url != NULL) {
				url2 = strtok(NULL, ",");
				printf("URL2 = %s\n", url2);
				if (url2 != NULL) {
					char *method = NULL;
					char *method2 = NULL;
					method = strtok(NULL, ",");
					if (method != NULL) {
						val = strtol(method, NULL, 10);
						if (val == LONG_MAX || val == LONG_MIN)
							err(DEBUG_CAT_INIT, "strtol fail\n");
						else
							osu_method = (int)val;

						printf("method = %d\n", osu_method);

						method2 = strtok(NULL, ",");
						if (method2 != NULL) {
							val = strtol(method2, NULL, 10);
							if (val == LONG_MAX || val == LONG_MIN)
								err(DEBUG_CAT_INIT, "strtol fail\n");
							else
								osu_method2 = (int)val;

							printf("method2 = %d\n", osu_method2);
						}
					}
				}
			}
		}
	}

	if (os_strcmp(value, "1") == 0) {
		if (conf->icon_tag == 2) {
			printf("id=1,fake icon tag 2\n");
			mtk_copy_file(WAPP_CONF_PATH "/wifi-abgn-logo_270x73.png", WAPP_CONF_PATH "/icon_red_zxx.png");
			mtk_copy_file(WAPP_CONF_PATH "/wifi-abgn-logo_270x73.png", WAPP_CONF_PATH "/icon_red_eng.png");
		} else {
			printf("id=1,normal icon tag 1\n");
			mtk_copy_file(WAPP_CONF_PATH "/icon_red_zxx_default.png", WAPP_CONF_PATH "/icon_red_zxx.png");
			mtk_copy_file(WAPP_CONF_PATH "/icon_red_eng_default.png", WAPP_CONF_PATH "/icon_red_eng.png");
		}

		if (url != NULL) {
			ret = snprintf(tmpbuf, sizeof(tmpbuf),
				 "osu_friendly_name,eng:SP Red Test Only,osu_friendly_name,kor:SP 빨강 테스트 전용,"
				 "osu_server_uri,%s,osu_method,%d,icon,128:61:zxx:image/png:icon_red_zxx.png,icon,160:76:eng:image/"
				 "png:icon_red_eng.png,osu_nai,n/a,"
				 "osu_service_desc,eng:Free service for test purpose,osu_service_desc,kor:테스트 목적으로 무료 서비스",
				 url, osu_method);
			if (os_snprintf_error(sizeof(tmpbuf), ret))
				err(DEBUG_CAT_EVENT, "snprintf error\n");
			wapp_ctrl_set_brace_multiple_param(conf, confname, "osu_providers_list", tmpbuf);
		} else {
			wapp_ctrl_set_brace_multiple_param(
				conf, confname, "osu_providers_list",
				"osu_friendly_name,eng:SP Red Test Only,osu_friendly_name,kor:SP 빨강 테스트 전용,osu_server_uri,"
				"https://osu-server.r2-testbed.wi-fi.org,osu_method,1,icon,128:61:zxx:image/"
				"png:icon_red_zxx.png,icon,160:76:eng"
				":image/png:icon_red_eng.png,osu_nai,n/a,osu_service_desc,eng:Free service for test purpose,"
				"osu_service_desc,kor:테스트 목적으로 무료 서비스");
		}
	} else if (os_strcmp(value, "2") == 0) {
		if (conf->icon_tag == 2) {
			printf("id=2,fake icon tag 2\n");
			mtk_copy_file(WAPP_CONF_PATH "/wifi-abgn-logo_270x73.png", WAPP_CONF_PATH "/icon_orange_zxx.png");
		} else {
			printf("id=2,normal icon tag 1\n");
			mtk_copy_file(WAPP_CONF_PATH "/icon_orange_zxx_default.png", WAPP_CONF_PATH "/icon_orange_zxx.png");
		}

		if (url != NULL) {
			ret = snprintf(tmpbuf, sizeof(tmpbuf),
				 "osu_friendly_name,eng:Wireless Broadband Alliance,osu_friendly_name,"
				 "kor:와이어리스 브로드밴드 "
				 "얼라이언스,osu_server_uri,%s,osu_method,%d,icon,128:61:zxx:image/png:icon_orange_zxx.png,"
				 "osu_nai,n/a,osu_service_desc,eng:Free service for test purpose,osu_service_desc,kor:테스트 목적으로 무료 "
				 "서비스",
				 url, osu_method);
			if (os_snprintf_error(sizeof(tmpbuf), ret))
				err(DEBUG_CAT_EVENT, "snprintf error\n");
			wapp_ctrl_set_brace_multiple_param(conf, confname, "osu_providers_list", tmpbuf);
		} else {
			wapp_ctrl_set_brace_multiple_param(
				conf, confname, "osu_providers_list",
				"osu_friendly_name,eng:Wireless Broadband Alliance,osu_friendly_name,"
				"kor:와이어리스 브로드밴드 얼라이언스,osu_server_uri,"
				"https://osu-server.r2-testbed.wi-fi.org,osu_method,1,icon,128:61:zxx:image/png:icon_orange_zxx.png,"
				"osu_nai,n/a,osu_service_desc,eng:Free service for test purpose,osu_service_desc,kor:테스트 목적으로 무료 "
				"서비스");
		}
	} else if (os_strcmp(value, "8") == 0) {
		if (conf->icon_tag == 2) {
			printf("id=8,fake icon tag 2\n");
			mtk_copy_file(WAPP_CONF_PATH "/wifi-abgn-logo_270x73.png", WAPP_CONF_PATH "/icon_red_zxx.png");
		} else {
			printf("id=8,normal icon tag 1\n");
			mtk_copy_file(WAPP_CONF_PATH "/icon_red_zxx_default.png", WAPP_CONF_PATH "/icon_red_zxx.png");
		}

		if (url != NULL) {
			ret = snprintf(tmpbuf, sizeof(tmpbuf),
				 "osu_friendly_name,eng:SP Red Test Only,osu_friendly_name,kor:SP 빨강 테스트 "
				 "전용,osu_server_uri,%s,osu_method,%d,icon,128:61:zxx:image/"
				 "png:icon_red_zxx.png,osu_nai,anonymous@hotspot.net,osu_service_desc,eng:Free service for test "
				 "purpose,osu_service_desc,kor:테스트 목적으로 무료 서비스",
				 url, osu_method);
			if (os_snprintf_error(sizeof(tmpbuf), ret)) {
				err(DEBUG_CAT_EVENT, "os_snprintf fail\n");
				return;
			}
			wapp_ctrl_set_brace_multiple_param(conf, confname, "osu_providers_list", tmpbuf);
		} else {
			wapp_ctrl_set_brace_multiple_param(
				conf, confname, "osu_providers_list",
				"osu_friendly_name,eng:SP Red Test Only,osu_friendly_name,kor:SP 빨강 테스트 "
				"전용,osu_server_uri,https://osu-server.r2-testbed.wi-fi.org,osu_method,1,icon,128:61:zxx:image/"
				"png:icon_red_zxx.png,osu_nai,anonymous@hotspot.net,osu_service_desc,eng:Free service for test "
				"purpose,osu_service_desc,kor:테스트 목적으로 무료 서비스");
		}
	} else if (os_strcmp(value, "9") == 0) {
		if (conf->icon_tag == 2) {
			printf("id=9,fake icon tag 2\n");
			mtk_copy_file(WAPP_CONF_PATH "/wifi-abgn-logo_270x73.png", WAPP_CONF_PATH "/icon_orange_zxx.png");
		} else {
			printf("id=9,normal icon tag 1\n");
			mtk_copy_file(WAPP_CONF_PATH "/icon_orange_zxx_default.png", WAPP_CONF_PATH "/icon_orange_zxx.png");
		}

		if (url != NULL) {
			ret = os_snprintf(tmpbuf, sizeof(tmpbuf),
					  "osu_friendly_name,eng:SP Orange Test "
					  "Only,osu_server_uri,%s,osu_method,%d,icon,128:61:zxx:image/"
					  "png:icon_orange_zxx.png,osu_nai,test-anonymous@wi-fi.org,osu_service_desc,n/a",
					  url, osu_method);
			if (os_snprintf_error(sizeof(tmpbuf), ret)) {
				err(DEBUG_CAT_EVENT, "os_snprintf fail\n");
				return;
			}
			wapp_ctrl_set_brace_multiple_param(conf, confname, "osu_providers_list", tmpbuf);
		} else {
			wapp_ctrl_set_brace_multiple_param(
				conf, confname, "osu_providers_list",
				"osu_friendly_name,eng:SP Orange Test "
				"Only,osu_server_uri,https://osu-server.r2-testbed.wi-fi.org,osu_method,1,icon,128:61:zxx:image/"
				"png:icon_orange_zxx.png,osu_nai,test-anonymous@wi-fi.org,osu_service_desc,n/a");
		}
	}
	/*
	 else if (os_strcmp(value, "11") == 0) {
		if (url != NULL) {
				sprintf(tmpbuf, "osu_friendly_name,eng:SP Red Test Only,osu_friendly_name,kor:SP 레드 시험
	 만,osu_server_uri,%s,osu_method,1,icon,160:76:eng:image/png:icon_red.png,osu_nai,n/a,osu_service_desc,eng:Free service for test
	 purpose,osu_service_desc,kor:테스트 목적으로 무료 서비스", url); wapp_ctrl_set_brace_multiple_param(conf, confname,
	 "osu_providers_list", tmpbuf);
			}
			else {
				wapp_ctrl_set_brace_multiple_param(conf, confname, "osu_providers_list", "osu_friendly_name,eng:SP Red Test
	 Only,osu_friendly_name,kor:SP 레드 시험
	 만,osu_server_uri,https://osu-server.r2-testbed.wi-fi.org,osu_method,1,icon,160:76:eng:image/png:icon_red.png,osu_nai,n/a,osu_service_desc,eng:Free
	 service for test purpose,osu_service_desc,kor:테스트 목적으로 무료 서비스");
			}
		}
	*/
	else if (os_strcmp(value, "3") == 0) {
		if (conf->icon_tag == 2) {
			printf("id=3,fake icon tag 2\n");
			mtk_copy_file(WAPP_CONF_PATH "/wifi-abgn-logo_270x73.png", WAPP_CONF_PATH "/icon_red_zxx.png");
		} else {
			printf("id=3,normal icon tag 1\n");
			mtk_copy_file(WAPP_CONF_PATH "/icon_red_zxx_default.png", WAPP_CONF_PATH "/icon_red_zxx.png");
		}

		if (url != NULL) {
			ret = os_snprintf(tmpbuf, sizeof(tmpbuf),
					  "osu_friendly_name,spa:SP Red Test "
					  "Only,osu_server_uri,%s,osu_method,%d,icon,128:61:zxx:image/png:icon_red_zxx.png,osu_nai,n/"
					  "a,osu_service_desc,spa:Free service for test purpose",
					  url, osu_method);
			if (os_snprintf_error(sizeof(tmpbuf), ret)) {
				err(DEBUG_CAT_EVENT, "os_snprintf fail\n");
				return;
			}
			wapp_ctrl_set_brace_multiple_param(conf, confname, "osu_providers_list", tmpbuf);
		} else {
			wapp_ctrl_set_brace_multiple_param(
				conf, confname, "osu_providers_list",
				"osu_friendly_name,spa:SP Red Test "
				"Only,osu_server_uri,https://osu-server.r2-testbed.wi-fi.org,osu_method,1,icon,128:61:zxx:image/"
				"png:icon_red_zxx.png,osu_nai,n/a,osu_service_desc,spa:Free service for test purpose");
		}
	} else if (os_strcmp(value, "4") == 0) {
		if (conf->icon_tag == 2) {
			printf("id=4,fake icon tag 2\n");
			mtk_copy_file(WAPP_CONF_PATH "/wifi-abgn-logo_270x73.png", WAPP_CONF_PATH "/icon_orange_zxx.png");
			mtk_copy_file(WAPP_CONF_PATH "/wifi-abgn-logo_270x73.png", WAPP_CONF_PATH "/icon_orange_eng.png");
		} else {
			printf("id=4,normal icon tag 1\n");
			mtk_copy_file(WAPP_CONF_PATH "/icon_orange_zxx_default.png", WAPP_CONF_PATH "/icon_orange_zxx.png");
			mtk_copy_file(WAPP_CONF_PATH "/icon_orange_eng_default.png", WAPP_CONF_PATH "/icon_orange_eng.png");
		}

		if (url != NULL) {
			ret = os_snprintf(
				tmpbuf, sizeof(tmpbuf),
				"osu_friendly_name,eng:SP Orange Test Only,kor,SP 오렌지 테스트 "
				"전용,osu_server_uri,%s,osu_method,%d,icon,128:61:zxx:image/png:icon_orange_zxx.png,icon,160:76:eng:image/"
				"png:icon_orange_eng.png,osu_nai,n/a,osu_service_desc,eng:Free service for test "
				"purpose,osu_service_desc,kor:테스트 목적으로 무료 서비스",
				url, osu_method);
			if (os_snprintf_error(sizeof(tmpbuf), ret)) {
				err(DEBUG_CAT_EVENT, "os_snprintf fail\n");
				return;
			}
			wapp_ctrl_set_brace_multiple_param(conf, confname, "osu_providers_list", tmpbuf);
		} else {
			wapp_ctrl_set_brace_multiple_param(
				conf, confname, "osu_providers_list",
				"osu_friendly_name,eng:SP Orange Test Only,kor,SP 오렌지 테스트 "
				"전용,osu_server_uri,https://osu-server.r2-testbed.wi-fi.org,osu_method,1,icon,128:61:zxx:image/"
				"png:icon_orange_zxx.png,icon,160:76:eng:image/png:icon_orange_eng.png,osu_nai,n/"
				"a,osu_service_desc,eng:Free service for test purpose,osu_service_desc,kor:테스트 목적으로 무료 서비스");
		}
	} else if (os_strcmp(value, "5") == 0) {
		if (conf->icon_tag == 2) {
			printf("id=5,fake icon tag 2\n");
			mtk_copy_file(WAPP_CONF_PATH "/wifi-abgn-logo_270x73.png", WAPP_CONF_PATH "/icon_orange_zxx.png");
		} else {
			printf("id=5,normal icon tag 1\n");
			mtk_copy_file(WAPP_CONF_PATH "/icon_orange_zxx_default.png", WAPP_CONF_PATH "/icon_orange_zxx.png");
		}
		if (url != NULL) {
			ret = os_snprintf(
				tmpbuf, sizeof(tmpbuf),
				"osu_friendly_name,eng:SP Orange Test Only,kor,SP 오렌지 테스트 "
				"전용,osu_server_uri,%s,osu_method,%d,icon,128:61:zxx:image/png:icon_orange_zxx.png,osu_nai,n/"
				"a,osu_service_desc,eng:Free service for test purpose,osu_service_desc,kor:테스트 목적으로 무료 서비스",
				url, osu_method);
			if (os_snprintf_error(sizeof(tmpbuf), ret)) {
				err(DEBUG_CAT_EVENT, "os_snprintf fail\n");
				return;
			}
			wapp_ctrl_set_brace_multiple_param(conf, confname, "osu_providers_list", tmpbuf);
		} else {
			wapp_ctrl_set_brace_multiple_param(
				conf, confname, "osu_providers_list",
				"osu_friendly_name,eng:SP Orange Test Only,kor,SP 오렌지 테스트 "
				"전용,osu_server_uri,https://osu-server.r2-testbed.wi-fi.org,osu_method,1,icon,128:61:zxx:image/"
				"png:icon_orange_zxx.png,osu_nai,n/a,osu_service_desc,eng:Free service for test "
				"purpose,osu_service_desc,kor:테스트 목적으로 무료 서비스");
		}
	} else if (os_strcmp(value, "6") == 0) {
		if (conf->icon_tag == 2) {
			printf("id=6,fake icon tag 2\n");
			mtk_copy_file(WAPP_CONF_PATH "/wifi-abgn-logo_270x73.png", WAPP_CONF_PATH "/icon_green_zxx.png");
			mtk_copy_file(WAPP_CONF_PATH "/wifi-abgn-logo_270x73.png", WAPP_CONF_PATH "/icon_orange_zxx.png");
		} else {
			printf("id=6,normal icon tag 1\n");
			mtk_copy_file(WAPP_CONF_PATH "/icon_green_zxx_default.png", WAPP_CONF_PATH "/icon_green_zxx.png");
			mtk_copy_file(WAPP_CONF_PATH "/icon_orange_zxx_default.png", WAPP_CONF_PATH "/icon_orange_zxx.png");
		}

		ret = os_snprintf(tmpbuf, sizeof(tmpbuf),
				  "osu_friendly_name,eng:SP Green Test Only,kor,SP 초록 테스트 "
				  "전용,osu_server_uri,%s,osu_method,%d,icon,128:61:zxx:image/png:icon_green_zxx.png,osu_nai,n/"
				  "a,osu_service_desc,n/a",
				  url, osu_method);
		if (os_snprintf_error(sizeof(tmpbuf), ret)) {
			err(DEBUG_CAT_EVENT, "os_snprintf fail\n");
			return;
		}
		wapp_ctrl_set_brace_multiple_param(conf, confname, "osu_providers_list", tmpbuf);

		os_memset(tmpbuf, 0, 2048);
		ret = os_snprintf(tmpbuf, sizeof(tmpbuf),
				  "osu_friendly_name,eng:SP Orange Test Only,kor,SP 오렌지 테스트 "
				  "전용,osu_server_uri,%s,osu_method,%d,icon,128:61:zxx:image/png:icon_orange_zxx.png,osu_nai,n/"
				  "a,osu_service_desc,n/a",
				  url2, osu_method2);
		if (os_snprintf_error(sizeof(tmpbuf), ret)) {
			err(DEBUG_CAT_EVENT, "os_snprintf fail\n");
			return;
		}
		wapp_ctrl_set_brace_multiple_param(conf, confname, "osu_providers_list", tmpbuf);
	} else if (os_strcmp(value, "7") == 0) {
		if (conf->icon_tag == 2) {
			printf("id=7,fake icon tag 2\n");
			mtk_copy_file(WAPP_CONF_PATH "/wifi-abgn-logo_270x73.png", WAPP_CONF_PATH "/icon_green_zxx.png");
			mtk_copy_file(WAPP_CONF_PATH "/wifi-abgn-logo_270x73.png", WAPP_CONF_PATH "/icon_green_eng.png");
		} else {
			printf("id=7,normal icon tag 1\n");
			mtk_copy_file(WAPP_CONF_PATH "/icon_green_zxx_default.png", WAPP_CONF_PATH "/icon_green_zxx.png");
			mtk_copy_file(WAPP_CONF_PATH "/icon_green_eng_default.png", WAPP_CONF_PATH "/icon_green_eng.png");
		}

		if (url != NULL) {
			ret = os_snprintf(
				tmpbuf, sizeof(tmpbuf),
				"osu_friendly_name,eng:SP Green Test Only,kor,SP 초록 테스트 전용,osu_server_uri,%s,"
				"osu_method,%d,icon,128:61:zxx:image/png:icon_green_zxx.png,icon,160:76:eng:image/"
				"png:icon_green_eng.png,osu_nai,"
				"n/a,osu_service_desc,eng:Free service for test purpose,osu_service_desc,kor:테스트 목적으로 무료 서비스",
				url, osu_method);
			if (os_snprintf_error(sizeof(tmpbuf), ret)) {
				err(DEBUG_CAT_EVENT, "os_snprintf fail\n");
				return;
			}
			wapp_ctrl_set_brace_multiple_param(conf, confname, "osu_providers_list", tmpbuf);
		} else {
			wapp_ctrl_set_brace_multiple_param(
				conf, confname, "osu_providers_list",
				"osu_friendly_name,eng:SP Green Test Only,kor,SP 녹색 테스트 "
				"만,osu_server_uri,https://osu-server.r2-testbed.wi-fi.org,osu_method,0,icon,128:61:zxx:image/"
				"png:icon_green_zxx.png,icon,160:76:eng:image/png:icon_green_eng.png,osu_nai,n/a,osu_service_desc,eng:Free "
				"service for test purpose,osu_service_desc,kor:테스트 목적으로 무료 서>비스");
		}
	}
	/*
		else if (os_strcmp(value, "10") == 0) {
		sprintf(tmpbuf, "osu_friendly_name,eng:SP Red Test Only,kor,SP 레드 시험
	   만,osu_server_uri,%s,osu_method,%d,icon,160:76:eng:image/png:icon_red.png,osu_nai,n/a,osu_service_desc,n/a", url,
	   atoi(osu_method)); wapp_ctrl_set_brace_multiple_param(conf, confname, "osu_providers_list", tmpbuf);

			os_memset(tmpbuf, 0, 2048);
			sprintf(tmpbuf, "osu_friendly_name,eng:SP Blue Test Only,kor,SP 블루 만
	   테스트,osu_server_uri,%s,osu_method,%d,icon,160:76:eng:image/png:icon_blue.png,osu_nai,n/a,osu_service_desc,n/a", url2,
	   atoi(osu_method2)); wapp_ctrl_set_brace_multiple_param(conf, confname, "osu_providers_list", tmpbuf);

			os_memset(tmpbuf, 0, 2048);
			sprintf(tmpbuf, "osu_friendly_name,eng:SP Green Test Only,kor,SP 녹색 테스트
	   만,osu_server_uri,%s,osu_method,%d,icon,160:76:eng:image/png:icon_green.png,osu_nai,n/a,osu_service_desc,n/a", url3,
	   atoi(osu_method3)); wapp_ctrl_set_brace_multiple_param(conf, confname, "osu_providers_list", tmpbuf);

			os_memset(tmpbuf, 0, 2048);
			sprintf(tmpbuf, "osu_friendly_name,eng:SP Orange Test Only,kor,SP 오렌지 시험
	   만,osu_server_uri,%s,osu_method,%d,icon,160:76:eng:image/png:icon_orange.png,osu_nai,n/a,osu_service_desc,n/a", url4,
	   atoi(osu_method4)); wapp_ctrl_set_brace_multiple_param(conf, confname, "osu_providers_list", tmpbuf);
		}
	*/

	else if (os_strcmp(value, "10") == 0) {
		if (conf->icon_tag == 2) {
			printf("id=10,fake icon tag 2\n");
			mtk_copy_file(WAPP_CONF_PATH "/wifi-abgn-logo_270x73.png", WAPP_CONF_PATH "/icon_orange_zxx.png");
		} else {
			printf("id=10, normal icon tag 1\n");
			mtk_copy_file(WAPP_CONF_PATH "/icon_orange_zxx_default.png", WAPP_CONF_PATH "/icon_orange_zxx.png");
		}

		ret = os_snprintf(tmpbuf, sizeof(tmpbuf),
				  "osu_friendly_name,eng:SP Orange Test Only,osu_friendly_name,kor:SP .. ... "
				  "..,osu_server_uri,https://osu-server.r2-testbed.wi-fi.org/,osu_method,1,icon,128:61:zxx:image/"
				  "png:icon_orange_zxx.png,osu_nai,test-anonymous@wi-fi.org,osuservice_desc,n/a");
		if (os_snprintf_error(sizeof(tmpbuf), ret)) {
			err(DEBUG_CAT_EVENT, "os_snprintf fail\n");
			return;
		}

		wapp_ctrl_set_brace_multiple_param(conf, confname, "osu_providers_list", tmpbuf);
		os_memset(tmpbuf, 0, 2048);
		ret = os_snprintf(tmpbuf, sizeof(tmpbuf),
				  "osu_friendly_name,eng:SP Red Test Only,osu_friendly_name,kor:SP .. ... "
				  "..,osu_server_uri,https://osu-server.r2-testbed.wi-fi.org/,osu_method,1,icon,128:61:zxx:image/"
				  "png:icon_red_zxx.png,osu_nai,anonymous@hotspot.net,osu_service_desc,n/a");
		if (os_snprintf_error(sizeof(tmpbuf), ret)) {
			err(DEBUG_CAT_EVENT, "os_snprintf fail\n");
			return;
		}
		wapp_ctrl_set_brace_multiple_param(conf, confname, "osu_providers_list", tmpbuf);
	} else {
		err(DEBUG_CAT_EVENT, "Unknown OSU Provider List ID\n");
	}
}

/*
 * hotspot related parameters setting
 */
static struct wapp_ctrl_set_param w_ctrl_set_params[] = {
	{"interface", wapp_ctrl_set_interface_param},
	{"interworking", wapp_ctrl_set_interworking_param},
	{"access_network_type", wapp_ctrl_set_access_net_type_param},
	{"internet", wapp_ctrl_set_internet_param},
	{"venue_group", wapp_ctrl_set_venue_group_param},
	{"venue_type", wapp_ctrl_set_venue_type_param},
	{"anqp_query", wapp_ctrl_set_anqp_query_param},
	{"cosr_support", wapp_ctrl_set_cosr_support_param},
	{"mih_support", wapp_ctrl_set_mih_support_param},
	{"venue_name", wapp_ctrl_set_venue_name_param},
	{"venue_name_id", wapp_ctrl_set_venue_name_id_param},
	{"hessid", wapp_ctrl_set_hessid_param},
	{"roaming_consortium_oi", wapp_ctrl_set_roaming_consortium_oi_param},
	{"advertisement_proto_id", wapp_ctrl_set_advertisement_proto_id_param},
	{"domain_name", wapp_ctrl_set_domain_name_param},
	{"network_auth_type", wapp_ctrl_set_network_auth_type_param},
	{"net_auth_type_id", wapp_ctrl_set_net_auth_type_id_param},
	{"ipv4_type", wapp_ctrl_set_ipv4_type_param},
	{"ipv6_type", wapp_ctrl_set_ipv6_type_param},
	{"ip_type_id", wapp_ctrl_set_ip_type_id_param},
	{"nai_realm_data", wapp_ctrl_set_nai_realm_data_param},
	{"nai_realm_id", wapp_ctrl_set_nai_realm_id_param},
	{"op_friendly_name", wapp_ctrl_set_op_friendly_name_param},
	{"op_friendly_name_id", wapp_ctrl_set_op_friendly_name_id_param},
	{"proto_port", wapp_ctrl_set_proto_port_param},
	{"con_cap_id", wapp_ctrl_set_con_cap_id_param},
	{"wan_metrics", wapp_ctrl_set_wan_metrics_param},
	{"wan_metrics_id", wapp_ctrl_set_wan_metrics_id_param},
	{"plmn", wapp_ctrl_set_plmn_param},
	{"operating_class", wapp_ctrl_set_operating_class_param},
	{"operating_class_id", wapp_ctrl_set_operating_class_id_param},
	{"preferred_candi_list_included", wapp_ctrl_set_preferred_candi_list_included_param},
	{"abridged", wapp_ctrl_set_abridged_param},
	{"disassociation_imminent", wapp_ctrl_set_disassociation_imminent_param},
	{"bss_termination_included", wapp_ctrl_set_bss_termination_included_param},
	{"ess_disassociation_imminent", wapp_ctrl_set_ess_disassociation_imminent_param},
	{"disassociation_timer", wapp_ctrl_set_disassociation_timer_param},
	{"validity_interval", wapp_ctrl_set_validity_interval_param},
	{"bss_termination_duration", wapp_ctrl_set_bss_termination_duration_param},
	{"session_information_url", wapp_ctrl_set_session_information_url_param},
	{"bss_transisition_candi_list_preferences", wapp_ctrl_set_bss_transisition_candi_list_preferences_param},
	{"timezone", wapp_ctrl_set_timezone_param},
	{"dgaf_disabled", wapp_ctrl_set_dgaf_disabled_param},
	{"proxy_arp", wapp_ctrl_set_proxy_arp_param},
	{"l2_filter", wapp_ctrl_set_l2_filter_param},
	{"icmpv4_deny", wapp_ctrl_set_icmpv4_deny_param},
	{"p2p_cross_connect_permitted", wapp_ctrl_set_p2p_cross_connect_permitted_param},
	{"mmpdu_size", wapp_ctrl_set_mmpdu_size_param},
	{"external_anqp_server_test", wapp_ctrl_set_external_anqp_server_test_param},
	{"gas_cb_delay", wapp_ctrl_set_gas_cb_delay_param},
	{"hs2_openmode_test", wapp_ctrl_set_hs2_openmode_test_param},
	{"anonymous_nai", wapp_ctrl_set_anonymous_nai_param},
	{"osu_interface", wapp_ctrl_set_osu_interface_param},
	{"osu_providers_list", wapp_ctrl_set_osu_providers_list_param},
	{"osu_providers_id", wapp_ctrl_set_osu_providers_list_id_param},
	{"legacy_osu", wapp_ctrl_set_hs2_legacy_osu_enable},
	{"icon_path", wapp_ctrl_set_iconfile_path_param},
	{"icon_tag", wapp_ctrl_set_icon_tag_param},
	{"qosmap", wapp_ctrl_set_qosmap_enable},
	{"dscp_range", wapp_ctrl_set_qosmap_dscp_range},
	{"dscp_exception", wapp_ctrl_set_qosmap_dscp_exception},
	{"qload_test", wapp_ctrl_set_qload_mode},
	{"qload_cu", wapp_ctrl_set_qload_cu},
	{"qload_sta_cnt", wapp_ctrl_set_qload_sta_cnt},
	{"mbo_cdcp", wapp_ctrl_set_ap_cdcp},
	{"mbo_ap_assoc_disallow_reason", wapp_ctrl_set_disallow_assoc_param},
	{"mbo_default_assoc_retry_delay", wapp_ctrl_set_assoc_retry_param},
	{"mbo_default_trans_reason", wapp_ctrl_set_trans_reason_param},
	{"mbo_ap_capability", wapp_ctrl_set_ap_capability_param},
	{"venue_url_id", wapp_ctrl_set_venue_url_id_param},
	{"advice_of_charge_id", wapp_ctrl_set_advice_of_charge_id_param},
	{"t_c_filename", wapp_ctrl_set_t_c_filename_param},
	{"t_c_filename_id", wapp_ctrl_set_t_c_filename_id_param},
	{"t_c_timestamp", wapp_ctrl_set_t_c_timestamp_param},
	{"osu_providers_nai_list", wapp_ctrl_set_osu_providers_nai_list_param},
	{"osu_providers_nai_id", wapp_ctrl_set_osu_providers_nai_id_param},
	{"oim_id", wapp_ctrl_set_oim_id_param},
};

static int wapp_ctrl_iface_cmd_set(struct wifi_app *wapp, const char *iface, char *param_value_pair, char *reply, size_t *reply_len)
{
	int ret = 0;
	struct wapp_conf *conf = NULL;
	int is_found = 0;
	char *token;
	char confname[256];
	struct wapp_ctrl_set_param *match = NULL;
	struct wapp_ctrl_set_param *param = w_ctrl_set_params;

	os_memset(confname, 0, 256);

	dl_list_for_each(conf, &wapp->conf_list, struct wapp_conf, list)
	{
		if (os_strcmp(conf->iface, iface) == 0) {
			is_found = 1;
			break;
		}
	}

	if (is_found) {
		token = strtok(param_value_pair, " ");
		if (!token) {
			err(DEBUG_CAT_EVENT, "strtok fail\n");
			return -1;
		}
		while (param->param) {
			if (os_strcmp(param->param, token) == 0) {
				match = param;
				break;
			}
			param++;
		}
	} else {
		err(DEBUG_CAT_EVENT, "Do not find corresponding hotspot configuration for this interface %s\n", iface);
		return -1;
	}

	if (match) {
		ret = os_snprintf(confname, sizeof(confname), "%s", conf->confname);
		if (os_snprintf_error(sizeof(confname), ret)) {
			err(DEBUG_CAT_EVENT, "os_snprintf fail\n");
			return -1;
		}
		token = strtok(NULL, "");
		if (!token) {
			err(DEBUG_CAT_EVENT, "strtok fail\n");
			return -1;
		}
		match->set_param(conf, confname, token);
	} else {
		err(DEBUG_CAT_EVENT, "Unknown parameters\n");
		return -1;
	}

	return ret;
}

static int wapp_ctrl_iface_cmd_dump(struct wifi_app *wapp, const char *iface, char *param,
	char **reply, size_t *reply_len)
{
	int len = 0;
	char *buf = NULL;

	if (os_strncmp(param, "globe_info", os_strlen("globe_info")) == 0) {
		buf = (char *)os_zalloc(102400);
		if (buf) {
			len = dump_globe_info(wapp, buf, 102400);
			if (len > 0) {
				os_free(*reply);
				*reply = buf;
				*reply_len = len;
				notice(DEBUG_CAT_MISC, "len=%d\n", len);
				return len;
			}
			os_free(buf);
			err(DEBUG_CAT_MISC, "dump_globe_info fail\n");
		} else {
			warn(DEBUG_CAT_MISC, "alloc 102400 buffer fail; can't dump_globe_info\n");
		}
	}

	return -1;
}


static int wapp_ctrl_iface_cmd_btmreq(struct wifi_app *wapp, const char *iface, char *param_value_pair, char *reply, size_t *reply_len)
{
	int ret = 0, i = 0;
	char *buf;
	size_t btm_req_len = 0;
	struct wapp_conf *conf;
	int is_found = 0;
	u8 peer_addr[6];
	char *token;
	u8 *peer_sta_addr = NULL;
	char *ess_disassoc_imm = NULL, *disassoc_timer = NULL, *sess_url = NULL;
	long value = 0;

	dl_list_for_each(conf, &wapp->conf_list, struct wapp_conf, list)
	{
		if (os_strcmp(conf->iface, iface) == 0) {
			is_found = 1;
			break;
		}
	}

	if (!is_found) {
		if (wapp_dev_list_lookup_by_ifname(wapp, iface) == NULL) {
			err(DEBUG_CAT_EVENT, "can not find configuration for interface(%s)\n", iface);
			return -1;
		} else {
			conf = wapp->wapp_default_config;
			/* use default config for common ioctls */
		}
	}

	if (!conf) {
		err(DEBUG_CAT_EVENT, "conf is null\n");
		return -1;
	}

	token = strtok(param_value_pair, " ");
	while (token != NULL) {
		switch (i) {
		case 0:
			peer_sta_addr = (u8 *)token;
			break;
		case 1:
			ess_disassoc_imm = token;
			break;
		case 2:
			disassoc_timer = token;
			break;
		case 3:
			sess_url = token;
			break;
		default:
			err(DEBUG_CAT_EVENT, "unknown parameter:%s\n", token);
			break;
		}
		i++;

		token = strtok(NULL, " ");
	}

	if (!ess_disassoc_imm && !disassoc_timer && !sess_url) {
		err(DEBUG_CAT_EVENT, "Wrong token!!!\n");
		return -1;
	}
	// update btm paramters
	if (ess_disassoc_imm && strcmp(ess_disassoc_imm, "n/a")) {
		value = strtol(ess_disassoc_imm, NULL, 10);
		if (value == LONG_MAX || value == LONG_MIN)
			err(DEBUG_CAT_INIT, "strtol fail\n");
		else
			conf->ess_disassociation_imminent = (u8)value;
	}
	if (disassoc_timer && strcmp(disassoc_timer, "n/a")) {
		value = strtol(disassoc_timer, NULL, 10);
		if (value == LONG_MAX || value == LONG_MIN)
			err(DEBUG_CAT_INIT, "strtol fail\n");
		else
			conf->disassociation_timer = (u16)value;
	}
	if (conf->have_session_info_url)
		os_free(conf->session_info_url);
	conf->have_session_info_url = 1;
	conf->disassociation_imminent = 1;
	if (sess_url && os_strlen(sess_url) > 0) {
		conf->session_info_url_len = os_strlen(sess_url) + 1;
		conf->session_info_url = os_zalloc(conf->session_info_url_len);
		os_memcpy(conf->session_info_url, sess_url, conf->session_info_url_len);

		notice(DEBUG_CAT_EVENT, "ESS_IMM[%d] Disassoc_Timer[%d] Session_URL : ", conf->ess_disassociation_imminent,
			 conf->disassociation_timer);
		for (i = 0; i < conf->session_info_url_len; i++)
			printf("%c", conf->session_info_url[i]);

		printf("\n");
	} else {
		err(DEBUG_CAT_EVENT, "the length of sess_url is 0");
	}

	i = 0;
	token = strtok((char *)peer_sta_addr, ":");
	while (token != NULL) {
		AtoH(token, (char *)&peer_addr[i], 1);
		debug(DEBUG_CAT_EVENT, "peer_mac[%d] = 0x%02x\n", i, peer_addr[i]);
		i++;
		if (i >= 6)
			break;
		token = strtok(NULL, ":");
	}

	if (i != 6) {
		err(DEBUG_CAT_EVENT, "Wrong mac addr\n");
		return -1;
	}

	btm_req_len = hotspot_calc_btm_req_len(wapp, conf);

	buf = os_zalloc(btm_req_len);

	if (!buf) {
		err(DEBUG_CAT_EVENT, "Not available memory\n");
		return -1;
	}

	hotspot_collect_btm_req(wapp, conf, peer_addr, buf);

	wapp_send_btm_req(wapp, iface, peer_addr, buf, btm_req_len);

	os_free(buf);

	return ret;
}

static int wapp_ctrl_iface_cmd_mbo(struct wifi_app *wapp, const char *iface, char *param_value_pair, char *reply, size_t *reply_len)
{
	int ret = 0; //, i = 0;
	struct wapp_conf *conf;
	int is_found = 0;
	char *token;
	u8 argc = 0;
	char *argv[5];

	dl_list_for_each(conf, &wapp->conf_list, struct wapp_conf, list)
	{
		if (os_strcmp(conf->iface, iface) == 0) {
			is_found = 1;
			break;
		}
	}

	if (!is_found) {
		if (wapp_dev_list_lookup_by_ifname(wapp, iface) == NULL) {
			err(DEBUG_CAT_EVENT, "can not find configuration for interface(%s)\n", iface);
			return -1;
		}
	}

	/* for now, it always has 4 argc, due to the format of the source msg */
	token = strtok(param_value_pair, " ");
	while (token != NULL) {
		argv[argc] = token;
		argc++;
		token = strtok(NULL, " ");
	}

	mbo_ctrl_interface_cmd_handle(wapp, iface, argc, argv);

	return ret;
}

#ifdef MAP_SUPPORT
static int wapp_ctrl_iface_cmd_map(struct wifi_app *wapp, const char *iface, char *param_value_pair, char *reply, size_t *reply_len)
{
	int ret = 0; //, i = 0;
	struct wapp_conf *conf;
	int is_found = 0;
	char *token;
	u8 argc = 0;
	char *argv[9];

	dl_list_for_each(conf, &wapp->conf_list, struct wapp_conf, list)
	{
		if (os_strcmp(conf->iface, iface) == 0) {
			is_found = 1;
			break;
		}
	}

	if (!is_found) {
		if (wapp_dev_list_lookup_by_ifname(wapp, iface) == NULL) {
			err(DEBUG_CAT_EVENT, "can not find configuration for interface(%s)\n", iface);
			return -1;
		}
	}

	/* for now, it always has 4 argc, due to the format of the source msg */
	token = strtok(param_value_pair, " ");
	while (token != NULL) {
		argv[argc] = token;
		argc++;
		token = strtok(NULL, " ");
	}

	map_ctrl_interface_cmd_handle(wapp, iface, argc, argv);

	return ret;
}
#endif /* MAP_SUPPORT */

static int wapp_ctrl_iface_cmd_wapp_cmm(struct wifi_app *wapp, const char *iface, char *param_value_pair, char *reply, size_t *reply_len)
{
	int ret = 0; //, i = 0;
	struct wapp_conf *conf;
	int is_found = 0;
	char *token;
	u8 argc = 0;
	char *argv[5];

	dl_list_for_each(conf, &wapp->conf_list, struct wapp_conf, list)
	{
		if (os_strcmp(conf->iface, iface) == 0) {
			is_found = 1;
			break;
		}
	}

	if (!is_found) {
		if (wapp_dev_list_lookup_by_ifname(wapp, iface) == NULL) {
			err(DEBUG_CAT_EVENT, "can not find configuration for interface(%s)\n", iface);
			return -1;
		}
	}

	/* for now, it always has 4 argc, due to the format of the source msg */
	token = strtok(param_value_pair, " ");
	while (token != NULL) {
		argv[argc] = token;
		argc++;
		token = strtok(NULL, " ");
	}

	wapp_ctrl_interface_cmd_handle(wapp, iface, argc, argv);

	return ret;
}

static int wapp_ctrl_iface_cmd_drv_version(struct wifi_app *wapp, const char *iface, char *reply, size_t *reply_len)
{
	int ret = 0;

	ret = wapp_driver_version(wapp, iface, reply, reply_len);

	return ret;
}
static int wapp_ctrl_iface_cmd_wps_pbc_trigger(struct wifi_app *wapp, const char *iface, char *reply, size_t *reply_len)
{
	int ret = 0;

	ret = wapp_wps_pbc_trigger(wapp, iface, reply, reply_len);

	return ret;
}
static int wapp_ctrl_iface_cmd_wps_pbc_trigger_cli(struct wifi_app *wapp, const char *iface, char *reply, size_t *reply_len)
{
	int ret = 0;

	wapp->wps_on_controller_cli = 1;
	ret = wapp_wps_pbc_trigger(wapp, iface, reply, reply_len);
	return ret;
}

static int wapp_ctrl_iface_cmd_ipv4_proxy_arp_list(struct wifi_app *wapp, const char *iface, char *reply, size_t *reply_len)
{
	int ret = 0;

	ret = hotspot_ipv4_proxy_arp_list(wapp, iface, reply, reply_len);

	return ret;
}

static int wapp_ctrl_iface_cmd_ipv6_proxy_arp_list(struct wifi_app *wapp, const char *iface, char *reply, size_t *reply_len)
{
	int ret = 0;

	ret = hotspot_ipv6_proxy_arp_list(wapp, iface, reply, reply_len);

	return ret;
}

static int wapp_ctrl_iface_cmd_reload(struct wifi_app *wapp, const char *iface, char *reply, size_t *reply_len)
{
	int ret = 0;

	if (wapp->opmode == OPMODE_AP)
		ret = hotspot_ap_reload(wapp, iface);

	return ret;
}

static int wapp_ctrl_iface_cmd_qosmap(struct wifi_app *wapp, const char *iface, char *param_value_pair, char *reply, size_t *reply_len)
{
	int ret = 0, i = 0;
	// char *url = NULL;
	u8 cnt = 0;
	// size_t btm_req_len = 0;
	struct wapp_conf *conf;
	int is_found = 0, type = 0;							//, delay = 0
	char peer_addr[6], *token, tmpbuf[256], tmpbuf2[256], exception[64], range[64]; // code
	long value = 0;

	dl_list_for_each(conf, &wapp->conf_list, struct wapp_conf, list)
	{
		if (os_strcmp(conf->iface, iface) == 0) {
			is_found = 1;
			break;
		}
	}

	if (!is_found) {
		if (wapp_dev_list_lookup_by_ifname(wapp, iface) == NULL) {
			err(DEBUG_CAT_EVENT, "can not find configuration for interface(%s)\n", iface);
			return -1;
		}
	}

	ret = os_snprintf(tmpbuf, sizeof(tmpbuf), "%s", param_value_pair);
	if (os_snprintf_error(sizeof(tmpbuf), ret)) {
		err(DEBUG_CAT_EVENT, "os_snprintf fail\n");
		return -1;
	}

	token = strtok(tmpbuf, ":");
	while (token != NULL) {
		AtoH(token, &peer_addr[i], 1);
		debug(DEBUG_CAT_EVENT, "peer_mac[%d] = 0x%02x\n", i, peer_addr[i]);
		i++;
		if (i >= 6)
			break;
		token = strtok(NULL, ":");
	}

	if (i != 6) {
		err(DEBUG_CAT_EVENT, "Wrong mac addr\n");
		return -1;
	}

	// type
	notice(DEBUG_CAT_EVENT, "param_value_pair1=%s\n", param_value_pair);
	token = strtok(param_value_pair, " ");
	if (token != NULL) {
		printf("token=%s\n", token);
		token = strtok(NULL, " ");
		if (!token) {
			err(DEBUG_CAT_EVENT, "strtok fail\n");
			return -1;
		}
		value = strtol(token, NULL, 10);
		if (value == LONG_MAX || value == LONG_MIN)
			err(DEBUG_CAT_INIT, "strtol fail\n");
		else
			type = (int)value;
		printf("type=%d\n", type);
	}

	os_memset(tmpbuf2, 0, 256);
	if (type == 0) {
		token = strtok(NULL, " ");
		if (os_strlen(token) < sizeof(exception)) {
			os_memcpy(exception, token, os_strlen(token));
			exception[os_strlen(token)] = '\0';
		} else {
			err(DEBUG_CAT_EVENT, "token length exceed exception size.\n");
			return -1;
		}

		token = strtok(NULL, " ");

		if (os_strlen(token) < sizeof(range)) {
			os_memcpy(range, token, os_strlen(token));
			range[os_strlen(token)] = '\0';
		} else {
			err(DEBUG_CAT_EVENT, "token length exceed range size.\n");
			return -1;
		}

		token = strtok(exception, ":");
		while (token != NULL) {
			value = strtol(token, NULL, 10);
			if (value == LONG_MAX || value == LONG_MIN)
				err(DEBUG_CAT_INIT, "strtol fail\n");
			else
				tmpbuf2[cnt++] = (char)value;
			token = strtok(NULL, ":");
		}

		token = strtok(range, ":");
		while (token != NULL) {
			value = strtol(token, NULL, 10);
			if (value == LONG_MAX || value == LONG_MIN)
				err(DEBUG_CAT_INIT, "strtol fail\n");
			else
				tmpbuf2[cnt++] = (char)value;
			token = strtok(NULL, ":");
		}

		printf("iface=%s\n", iface);
		hotspot_send_qosmap_configure(wapp, iface, peer_addr, tmpbuf2, cnt);
	} else {
		token = strtok(NULL, " ");
		if (os_strlen(token) < sizeof(range)) {
			os_memcpy(range, token, os_strlen(token));
			range[os_strlen(token)] = '\0';
		} else {
			err(DEBUG_CAT_EVENT, "token length exceed range size.\n");
			return -1;
		}

		token = strtok(range, ":");
		while (token != NULL) {
			value = strtol(token, NULL, 10);
			if (value == LONG_MAX || value == LONG_MIN)
				err(DEBUG_CAT_INIT, "strtol fail\n");
			else
				tmpbuf2[cnt++] = (char)value;
			token = strtok(NULL, ":");
		}

		printf("iface=%s\n", iface);
		hotspot_send_qosmap_configure(wapp, iface, peer_addr, tmpbuf2, cnt);
	}

	return ret;
}

static int wapp_ctrl_iface_cmd_wnmreq(struct wifi_app *wapp, const char *iface, char *param_value_pair, char *reply, size_t *reply_len)
{
	int ret = 0, i = 0;
	char *url = NULL;
	// size_t btm_req_len = 0;
	struct wapp_conf *conf;
	int is_found = 0, delay = 0, type = 0;
	char code = 0, peer_addr[6], *token, tmpbuf[256], tmpbuf2[256];
	long value = 0;

	dl_list_for_each(conf, &wapp->conf_list, struct wapp_conf, list)
	{
		if (os_strcmp(conf->iface, iface) == 0) {
			is_found = 1;
			break;
		}
	}

	if (!is_found) {
		err(DEBUG_CAT_EVENT, "can not find configuration for interface(%s)\n", iface);
		return -1;
	}

	ret = os_snprintf(tmpbuf, sizeof(tmpbuf), "%s", param_value_pair);
	if (os_snprintf_error(sizeof(tmpbuf), ret)) {
		err(DEBUG_CAT_EVENT, "os_snprintf fail\n");
		return -1;
	}
	token = strtok(tmpbuf, ":");
	while (token != NULL) {
		AtoH(token, &peer_addr[i], 1);
		debug(DEBUG_CAT_EVENT, "peer_mac[%d] = 0x%02x\n", i, peer_addr[i]);
		i++;
		if (i >= 6)
			break;
		token = strtok(NULL, ":");
	}

	if (i != 6) {
		err(DEBUG_CAT_EVENT, "Wrong mac addr\n");
		return -1;
	}

	// type
	notice(DEBUG_CAT_EVENT, "param_value_pair1=%s\n", param_value_pair);
	token = strtok(param_value_pair, " ");
	if (token != NULL) {
		printf("token=%s\n", token);
		token = strtok(NULL, " ");
		if (!token) {
			err(DEBUG_CAT_EVENT, "strtok fail\n");
			return -1;
		}
		value = strtol(token, NULL, 10);
		if (value == LONG_MAX || value == LONG_MIN)
			err(DEBUG_CAT_INIT, "strtol fail\n");
		else
			type = (int)value;
		notice(DEBUG_CAT_EVENT, "type=%d\n", type);
	}

	os_memset(tmpbuf2, 0, 256);
	if (type == 0) {
		token = strtok(NULL, " ");
		while (token != NULL) {
			if (os_strlen(token) < sizeof(tmpbuf2)) {
				os_memcpy(tmpbuf2, token, os_strlen(token));
				tmpbuf2[os_strlen(token)] = '\0';
			}
			else
				err(DEBUG_CAT_EVENT, "token length exceed tmpbuf2 size.\n");
			token = strtok(NULL, " ");
		}

		notice(DEBUG_CAT_EVENT, "iface=%s,%s\n", iface, tmpbuf2);
		wapp_send_wnm_notify_req(wapp, iface, peer_addr, tmpbuf2, os_strlen(tmpbuf2), type);
	} else {
		token = strtok(NULL, " ");
		if (!token) {
			err(DEBUG_CAT_EVENT, "strtok fail\n");
			return -1;
		}
		value = strtol(token, NULL, 10);
		if (value == LONG_MAX || value == LONG_MIN)
			err(DEBUG_CAT_INIT, "strtol fail\n");
		else
			code = (char)value;
		token = strtok(NULL, " ");
		if (!token) {
			err(DEBUG_CAT_EVENT, "strtok fail\n");
			return -1;
		}
		value = strtol(token, NULL, 10);
		if (value == LONG_MAX || value == LONG_MIN)
			err(DEBUG_CAT_INIT, "strtol fail\n");
		else
			delay = (int)value;
		token = strtok(NULL, " ");
		if (!token) {
			tmpbuf2[0] = code;
			os_memcpy(&tmpbuf2[1], &delay, 2);

			printf("iface=%s\n", iface);
			wapp_send_wnm_notify_req(wapp, iface, peer_addr, tmpbuf2, 3, type);
		} else {
			url = token;
			tmpbuf2[0] = code;
			os_memcpy(&tmpbuf2[1], &delay, 2);
			if (os_strlen(url) < (sizeof(tmpbuf2) - 3))
				os_memcpy(&tmpbuf2[3], url, os_strlen(url));
			else
				err(DEBUG_CAT_EVENT, "url length exceed tmpbuf2 size.\n");

			printf("iface=%s\n", iface);
			wapp_send_wnm_notify_req(wapp, iface, peer_addr, tmpbuf2, 3 + os_strlen(url), type);
		}
	}

	return ret;
}
#ifdef COSR_SUPPORT
static int wapp_ctrl_iface_cmd_cosr(struct wifi_app *wapp, char *iface,
								char *buf, char *reply, int reply_size)
{
	struct wapp_dev *wdev = NULL;
	int reply_len = 0, res = 0;
	char *pos = buf;
	uint8_t mac[ETH_ALEN] = {0};
	BOOLEAN cosr_enable = 0;

	os_memcpy(reply, "OK\n", 3);
	reply_len = 3;
	if (!wapp) {
		err(DEBUG_CAT_EVENT, "Failed to get wapp");
		return -1;
	}

	wdev = wapp_dev_list_lookup_by_ifname(wapp, iface);
	if (!wdev) {
		err(DEBUG_CAT_EVENT, "failed to get wdev");
		return -1;
	}

	if (os_strncmp(pos, "COSR_ENABLE ", 12) == 0) {
		char *endptr;

		pos += 12;

		errno = 0;
		long val = strtol(pos, &endptr, 10);

		if ((errno == ERANGE && (val == LONG_MAX || val == LONG_MIN))
			|| (errno != 0 && val == 0) || (endptr == pos)) {
			err(DEBUG_CAT_EVENT, "Error: Invalid number format or out of range\n");
			return -1;
		}

		cosr_enable = (int)val;

		if (cosr_enable == TRUE) {
			res = wapp_cosr_enable(wapp);
			if (res != WAPP_SUCCESS) {
				reply_len = -1;
			} else {
				reply_len = os_snprintf(reply, reply_size, "%d", res);
				if (os_snprintf_error(reply_size, reply_len))
					reply_len = -1;
			}
		} else if (cosr_enable == FALSE) {
			res = wapp_cosr_disable(wapp);
			if (res != WAPP_SUCCESS) {
				reply_len = -1;
			} else {
				reply_len = os_snprintf(reply, reply_size, "%d", res);
				if (os_snprintf_error(reply_size, reply_len))
					reply_len = -1;
			}
		} else {
			err(DEBUG_CAT_EVENT, "Unknown value %d\n", cosr_enable);
			reply_len = -1;
		}
	} else if (os_strncmp(pos, "COSR_START ", 11) == 0) {
		res = wapp_cosr_ap_mode_set_per_band(wapp, iface, TRUE);
		if (res < 0) {
			reply_len = -1;
		} else {
			reply_len = os_snprintf(reply, reply_size, "%d", res);
			if (os_snprintf_error(reply_size, reply_len))
				reply_len = -1;
		}
	} else if (os_strncmp(pos, "COSR_STOP ", 10) == 0) {
		res = wapp_cosr_ap_mode_set_per_band(wapp, iface, FALSE);
		if (res < 0) {
			reply_len = -1;
		} else {
			reply_len = os_snprintf(reply, reply_size, "%d", res);
		if (os_snprintf_error(reply_size, reply_len))
			reply_len = -1;
		}
	} else if (os_strncmp(pos, "COSR_ADD_CANDLIST ", 18) == 0) {
		int ret;

		pos += 18;
		ret = hwaddr_aton(pos, mac);
		if (ret != 0) {
			err(DEBUG_CAT_EVENT, "Failed to convert ASCII to MAC address\n");
			reply_len = -1;
		}
		notice(DEBUG_CAT_EVENT, "ADD MAC" MACSTR "\n", MAC2STR(mac));
		if (wapp_cosr_add_whitelist_ap(wapp, iface, mac) != 0)
			reply_len = -1;
	} else if (os_strncmp(pos, "COSR_DEL_CANDLIST ", 18) == 0) {
		int ret;

		pos += 18;
		ret = hwaddr_aton(pos, mac);
		if (ret != 0) {
			err(DEBUG_CAT_EVENT, "Failed to convert ASCII to MAC address\n");
			reply_len = -1;
		}

		notice(DEBUG_CAT_EVENT, "Del MAC" MACSTR "\n", MAC2STR(mac));
		ret = wapp_cosr_del_whitelist_ap(wapp, iface, mac);
		if (ret != 0) {
			reply_len = -1;
		} else {
			reply_len = os_snprintf(reply, reply_size, "%d", ret);
			if (os_snprintf_error(reply_size, reply_len))
				reply_len = -1;
		}
	} else if (os_strncmp(pos, "COSR_CLEAR_CANDLIST ", 20) == 0) {
		notice(DEBUG_CAT_EVENT, "ClEAR_CANDLIST\n");
		if (wapp_cosr_clear_whitelist_ap(wapp, iface) != 0)
			reply_len = -1;
	} else if (os_strncmp(pos, "COSR_SHOW ", 10) == 0) {
		err(DEBUG_CAT_EVENT, "SHOW COSR\n");
		if (wapp_cosr_show_whitelist_ap(wapp, iface) != 0)
			reply_len = -1;
	} else {
		os_memcpy(reply, "UNKNOWN COMMAND\n", 16);
		reply_len = 16;
	}

	if (reply_len < 0) {
		os_memcpy(reply, "FAIL\n", 5);
		reply_len = 5;
	}
	return reply_len;
}
#endif

static int wapp_ctrl_iface_cmd_process(struct wifi_app *wapp, char *buf, char **reply, size_t *reply_len)
{
#define REPLY_LEN 5120
	int ret = 0;
	char *token = NULL, *token1 = NULL;
	char tmp[2048] = {0};
	char iface[256] = {0}, cmd[2048] = {0};
	int linelen = 0;

	*reply = os_zalloc(REPLY_LEN);
	if (!(*reply)) {
		err(DEBUG_CAT_EVENT, "fail to alloc reply buffer; size=5120\n");
		return -1;
	}
	*reply_len = REPLY_LEN;

	token = strtok(buf, "\n");
	os_memset(tmp, 0, 2048);
	os_memset(iface, 0, 256);
	os_memset(cmd, 0, 2048);

	while (token != NULL) {
		linelen = os_strlen(token);
		os_strncpy(tmp, token, 2048);
		tmp[2047] = '\0';

		token1 = strtok(tmp, "=");
		if (!token1) {
			err(DEBUG_CAT_EVENT, "strtok fail\n");
			return -1;
		}

		if (os_strcmp(token1, "interface") == 0) {
			token1 = strtok(NULL, "");
			if (!token1) {
				err(DEBUG_CAT_EVENT, "strtok fail\n");
				return -1;
			}
			os_strncpy(iface, token1, 256);
			iface[255] = '\0';
		} else if (os_strcmp(token1, "cmd") == 0) {
			token1 = strtok(NULL, "");
			if (!token1) {
				err(DEBUG_CAT_EVENT, "strtok fail\n");
				return -1;
			}
			os_strncpy(cmd, token1, 2048);
			cmd[2047] = '\0';
		}
		token = strtok(token + linelen + 1, "\n");
	}

	os_sleep(0, 5000);

	debug(DEBUG_CAT_EVENT, "interface = %s, cmd = %s\n", iface, cmd);

	if (os_strcmp(cmd, "hs_version") == 0)
		ret = wapp_ctrl_iface_cmd_version(wapp, *reply, reply_len);
	else if (os_strcmp(cmd, "on") == 0)
		ret = wapp_ctrl_iface_cmd_on(wapp, iface, *reply, reply_len);
	else if (os_strcmp(cmd, "off") == 0)
		ret = wapp_ctrl_iface_cmd_off(wapp, iface, *reply, reply_len);
#ifdef QOS_R1
	else if (os_strncmp(cmd, "set_qos_config", 14) == 0)
		ret = wapp_ctrl_iface_cmd_set_qos_config(wapp, iface, cmd + 15, *reply, reply_len);
	else if (os_strncmp(cmd, "get_qos_config", 14) == 0)
		ret = wapp_ctrl_iface_cmd_get_qos_config(wapp, iface, cmd + 15, *reply, reply_len);
	else if (os_strncmp(cmd, "save_qos_config", 15) == 0)
		ret = wapp_ctrl_iface_cmd_save_qos_config(wapp, iface, cmd + 16, *reply, reply_len);
	else if (os_strncmp(cmd, "get_qos_errorcode", 17) == 0)
		ret = wapp_ctrl_iface_cmd_get_qos_errorcode(wapp, iface, cmd + 18, *reply, reply_len);
	else if (os_strncmp(cmd, "show_qos_config", 15) == 0)
		ret = wapp_ctrl_iface_cmd_show_qos_config(wapp, iface, cmd + 16, *reply, reply_len);
#endif
	else if (os_strncmp(cmd, "get", 3) == 0)
		ret = wapp_ctrl_iface_cmd_get(wapp, iface, cmd + 4, *reply, reply_len);
	else if (os_strncmp(cmd, "set", 3) == 0)
		ret = wapp_ctrl_iface_cmd_set(wapp, iface, cmd + 4, *reply, reply_len);
	else if (os_strncmp(cmd, "dump", 4) == 0)
		ret = wapp_ctrl_iface_cmd_dump(wapp, iface, cmd + 5, reply, reply_len);
	else if (os_strncmp(cmd, "btmreq", 6) == 0)
		ret = wapp_ctrl_iface_cmd_btmreq(wapp, iface, cmd + 7, *reply, reply_len);
	else if (os_strncmp(cmd, "drv_version", 11) == 0)
		ret = wapp_ctrl_iface_cmd_drv_version(wapp, iface, *reply, reply_len);
	else if (os_strncmp(cmd, "wps_pbc_trigger_cli", 19) == 0)
		ret = wapp_ctrl_iface_cmd_wps_pbc_trigger_cli(wapp, iface, *reply, reply_len);
	else if (os_strncmp(cmd, "wps_pbc_trigger", 15) == 0)
		ret = wapp_ctrl_iface_cmd_wps_pbc_trigger(wapp, iface, *reply, reply_len);
	else if (os_strcmp(cmd, "ipv4_proxy_arp_list") == 0)
		ret = wapp_ctrl_iface_cmd_ipv4_proxy_arp_list(wapp, iface, *reply, reply_len);
	else if (os_strcmp(cmd, "ipv6_proxy_arp_list") == 0)
		ret = wapp_ctrl_iface_cmd_ipv6_proxy_arp_list(wapp, iface, *reply, reply_len);
	else if (os_strcmp(cmd, "reload") == 0)
		ret = wapp_ctrl_iface_cmd_reload(wapp, iface, *reply, reply_len);
	else if (os_strncmp(cmd, "wnmreq", 6) == 0)
		ret = wapp_ctrl_iface_cmd_wnmreq(wapp, iface, cmd + 7, *reply, reply_len);
	else if (os_strncmp(cmd, "qosmap", 6) == 0)
		ret = wapp_ctrl_iface_cmd_qosmap(wapp, iface, cmd + 7, *reply, reply_len);
	else if (os_strncmp(cmd, "mbo", 3) == 0)
		ret = wapp_ctrl_iface_cmd_mbo(wapp, iface, cmd + 4, *reply, reply_len);
	else if (os_strncmp(cmd, "map", 3) == 0)
		ret = wapp_ctrl_iface_cmd_map(wapp, iface, cmd + 4, *reply, reply_len);
	else if (os_strncmp(cmd, "wapp", 4) == 0)
		ret = wapp_ctrl_iface_cmd_wapp_cmm(wapp, iface, cmd + 5, *reply, reply_len);
#ifdef DPP_SUPPORT
	else if (os_strncmp(cmd, "dpp", 3) == 0)
		ret = wapp_ctrl_iface_cmd_dpp(wapp, iface, cmd + 4, *reply, *reply_len);
#endif /*DPP_SUPPORT*/
	else if (os_strncmp(cmd, "version_info", 12) == 0) {
		notice(DEBUG_CAT_EVENT, "WAPP version: %s\n", WAPP_VERSION);
		notice(DEBUG_CAT_EVENT, "wapp cmm type version: %s\n", VERSION_WAPP_CMM);
		os_memcpy(*reply, WAPP_VERSION, os_strlen(WAPP_VERSION));
		*reply_len = os_strlen(WAPP_VERSION);
		ret = 1;
	}
#ifdef QOS_R1
	else if (os_strncmp(cmd, "qm", 2) == 0)
		ret = wapp_ctrl_iface_cmd_qos(wapp, iface, cmd + 3, *reply, reply_len);
#endif /*QOS_R1*/
#ifdef EPCS_SUPPORT
	else if (os_strncmp(cmd, "send_act_frame", 14) == 0)
		ret = wapp_ctrl_send_act_frame(wapp, iface, cmd + 15, *reply, reply_len);
	else if (os_strncmp(cmd, "epcs_setup", 10) == 0)
		ret = wapp_ctrl_epcs_setup(wapp, iface, cmd + 11, *reply, reply_len);
	else if (os_strncmp(cmd, "wmmpe", 5) == 0)
		ret = wapp_ctrl_epcs_wmmpe(wapp, iface, cmd + 6, *reply, reply_len);
	else if (os_strncmp(cmd, "show_epcs_list", 14) == 0)
		wapp_ctrl_show_epcs_list();
#endif /*EPCS_SUPPORT*/
#ifdef COSR_SUPPORT
	else if (os_strncmp(cmd, "cosr", 4) == 0)
		ret = wapp_ctrl_iface_cmd_cosr(wapp, iface, cmd + 5, *reply, *reply_len);
#endif /* COSR_SUPPORT */
	else {
		err(DEBUG_CAT_EVENT, "no such command: %s\n", cmd);
		ret = -1;
	}

	if (ret == 0 && *reply_len > 0)
		ret = 1;

	return ret;
}

static void wapp_ctrl_iface_receive(int sock, void *eloop_ctx, void *sock_ctx)
{
	struct wifi_app *wapp = eloop_ctx;
	struct wapp_ctrl_iface *ctrl_iface = sock_ctx;
	struct sockaddr_un from;
	socklen_t fromlen = sizeof(from);
	int recv_fd = 0;
	int receive_len;
	char buf[4096] = {0};
	size_t reply_len = 0;
	char *reply = NULL;
	int ret;
	int ret_send = -1;

	recv_fd = accept(sock, (struct sockaddr *)&from, (socklen_t *)&fromlen);
	if (recv_fd < 0) {
		err(DEBUG_CAT_EVENT, "accept ctrl_sock fail; errno=%d(%s)\n", errno, strerror(errno));
		return;
	}

	receive_len = recv(recv_fd, buf, sizeof(buf) - 1, 0);
	if (receive_len < 0) {
		err(DEBUG_CAT_EVENT, "recvfrom fail\n");
		close(recv_fd);
		return;
	}
	buf[receive_len] = '\0';

	if (os_strcmp(buf, "EVENT_REGISTER") == 0) {
		if (wapp_ctrl_iface_event_register(ctrl_iface, &from, fromlen))
			ret_send = send(recv_fd, "FAIL\n", 5, 0);
		else
			ret_send = send(recv_fd, "OK\n", 3, 0);

	} else if (os_strcmp(buf, "EVENT_UNREGISTER") == 0) {
		if (wapp_ctrl_iface_event_unregister(ctrl_iface, &from, fromlen))
			ret_send = send(recv_fd, "FAIL\n", 5, 0);
		else
			ret_send = send(recv_fd, "OK\n", 3, 0);
	} else {
		ret = wapp_ctrl_iface_cmd_process(wapp, buf, &reply, &reply_len);
		errno = 0;
		if (ret == -1)
			ret_send = send(recv_fd, "FAIL\n", 5, 0);
		else if (ret == 0)
			ret_send = send(recv_fd, "OK\n", 3, 0);
		else
			ret_send = send(recv_fd, reply, reply_len, 0);
	}

	if (ret_send < 0)
		err(DEBUG_CAT_EVENT, "sendto failed; errno=%s\n", strerror(errno));

	os_free(reply);

	close(recv_fd);

	return;
}

struct wapp_ctrl_iface *wapp_ctrl_iface_init(struct wifi_app *wapp)
{
	struct wapp_ctrl_iface *ctrl_iface;
	struct sockaddr_un addr;

	ctrl_iface = os_zalloc(sizeof(*ctrl_iface));
	if (!ctrl_iface) {
		err(DEBUG_CAT_MISC, "alloc ctrl_iface fail\n");
		goto error0;
	}

	dl_list_init(&ctrl_iface->w_ctrl_dst_list);
	ctrl_iface->sock = -1;
	ctrl_iface->sock = socket(AF_UNIX, SOCK_STREAM, 0);
	if (ctrl_iface->sock < 0) {
		err(DEBUG_CAT_INIT, "create socket for ctrl interface fail\n");
		goto error1;
	}

	os_memset(&addr, 0, sizeof(addr));
	addr.sun_family = AF_UNIX;
	os_strncpy(addr.sun_path, "/tmp/wapp_ctrl", sizeof(addr.sun_path));
	if (bind(ctrl_iface->sock, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
		err(DEBUG_CAT_INIT, "bind fail; sun_path=%s; errno=%s\n",
			addr.sun_path, strerror(errno));
		goto error2;
	}

	if (listen(ctrl_iface->sock, 1) < 0) {
		err(DEBUG_CAT_INIT, "fail to listen ctrl_sock; errno=%d(%s)\n",
			errno, strerror(errno));
		goto error2;
	}

	eloop_register_read_sock(ctrl_iface->sock, wapp_ctrl_iface_receive, wapp, ctrl_iface);

	return ctrl_iface;

error2:
	unlink(addr.sun_path);
error1:
	if (ctrl_iface->sock >= 0)
		close(ctrl_iface->sock);
	os_free(ctrl_iface);
error0:
	return NULL;
}

void wapp_ctrl_iface_deinit(struct wifi_app *wapp)
{
	struct wapp_ctrl_iface *ctrl_iface = wapp->w_ctrl_iface;
	struct wapp_ctrl_dst *ctrl_dst, *ctrl_dst_tmp;
	char socket_path[64] = {0};

	if (!ctrl_iface)
		return;

	eloop_unregister_read_sock(ctrl_iface->sock);

	if (close(ctrl_iface->sock) < 0)
		err(DEBUG_CAT_EVENT, "error in close\n");
	ctrl_iface->sock = -1;

	if (os_snprintf(socket_path, sizeof(socket_path), "/tmp/wapp_ctrl") < 0)
		err(DEBUG_CAT_EVENT, "error in close\n");
	unlink(socket_path);

	dl_list_for_each_safe(ctrl_dst, ctrl_dst_tmp, &ctrl_iface->w_ctrl_dst_list, struct wapp_ctrl_dst, list) { os_free(ctrl_dst); }

	os_free(ctrl_iface);
}
