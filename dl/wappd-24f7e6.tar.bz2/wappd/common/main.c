/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>
#include "wapp_cmm.h"
#ifdef DPP_SUPPORT
#include "dpp_wdev.h"
#endif /*DPP_SUPPORT */
#ifdef OPENWRT_SUPPORT
#include <libdatconf.h>
#endif

#ifdef EPCS_SUPPORT
#include "epcs.h"
#endif /*EPCS_SUPPORT */

#include "rt_config.h"

extern int wapp_iface_init(struct wifi_app *wapp);

#include "hotspot.h"
extern struct hotspot_event_ops hs_event_ops;
extern void wapp_iface_deinit(struct wifi_app *wapp);

int eloop_sigterm;

#define LOCK_FILE "/tmp/wapp_program.lock"

int hs_usage()
{
	notice_np(DEBUG_CAT_MISC, "hotspot [-f <hotspot configuration file>] [-m <hotspot mode>] [-i <hotspot ipc type>] [-d <debug level>] "
			       "[-I <ineterface name>]\n");
	notice_np(DEBUG_CAT_MISC, "-f <hotspot configuration file>\n");
	notice_np(DEBUG_CAT_MISC, "-m <hotspot mode> (OPMODE_STA, OPMODE_AP)\n");
	notice_np(DEBUG_CAT_MISC, "-i <hotspot ipc type> (RA_WEXT, RA_NETLINK)\n");
	notice_np(DEBUG_CAT_MISC, "-d <hotspot debug level>\n");
	notice_np(DEBUG_CAT_MISC, "-h help\n");

	return 0;
}

#ifdef MAP_SUPPORT
int process_options(int argc, char *argv[], char *filename, int *opmode, int *drv_mode, int *debug_level, int *version, char *iface,
		    char *map_cfg, char *map_user_cfg)
#else
int process_options(int argc, char *argv[], char *filename, int *opmode, int *drv_mode, int *debug_level, int *version, char *iface)
#endif
{
	int c;
	char *cvalue = NULL;
	int ret = 0;

	opterr = 0;

	while ((c = getopt(argc, argv, "m:f:i:d:v:e:w:k:c:F:u:")) != -1) {
		switch (c) {
		case 'd':
			cvalue = optarg;
			if (os_strcmp(cvalue, "0") == 0)
				*debug_level = RT_DEBUG_OFF;
			else if (os_strcmp(cvalue, "1") == 0)
				*debug_level = RT_DEBUG_ERROR;
			else if (os_strcmp(cvalue, "2") == 0)
				*debug_level = RT_DEBUG_WARN;
			else if (os_strcmp(cvalue, "3") == 0)
				*debug_level = RT_DEBUG_TRACE;
			else if (os_strcmp(cvalue, "4") == 0)
				*debug_level = RT_DEBUG_INFO;
			else {
				err(DEBUG_CAT_INIT, "-d option does not have this debug_level %s\n", cvalue);
				return -1;
			}
			break;
		case 'f':
			cvalue = optarg;
			ret = os_snprintf(filename, 256, "%s", cvalue);
			if (os_snprintf_error(sizeof(filename), ret)) {
				err(DEBUG_CAT_INIT, "os_snprintf fail\n");
				return -1;
			}
			break;
		case 'm':
			cvalue = optarg;
			if (os_strcmp(cvalue, "OPMODE_STA") == 0)
				*opmode = OPMODE_STA;
			else if (os_strcmp(cvalue, "OPMODE_AP") == 0)
				*opmode = OPMODE_AP;
			else {
				err(DEBUG_CAT_INIT, "-m option does not have this mode %s\n", cvalue);
				return -1;
			}
			break;
		case 'i':
			cvalue = optarg;
			if (os_strcmp(cvalue, "WEXT") == 0)
				*drv_mode = WEXT;
			else if (os_strcmp(cvalue, "NL80211") == 0)
				*drv_mode = NL80211;
			else {
				err(DEBUG_CAT_INIT, "-i option does not have this type %s\n", cvalue);
				return -1;
			}
			break;
		case 'v':
			cvalue = optarg;
			errno = 0;
			*version = strtol(cvalue, NULL, 10);
			if ((errno == ERANGE && (*version == INT_MAX || *version == INT_MIN))
				|| (errno != 0 && *version == 0)) {
				err(DEBUG_CAT_INIT, "-v version=%d is error\n", *version);
				return -1;
			}
			break;
		case 'h':
			cvalue = optarg;
			hs_usage();
			break;
		case '?':
			if (optopt == 'f')
				notice_np(DEBUG_CAT_INIT, "Option -%c requires an argument\n", optopt);
			else if (optopt == 'm')
				notice_np(DEBUG_CAT_INIT, "Option -%c requires an argument\n", optopt);
			else if (optopt == 'd')
				notice_np(DEBUG_CAT_INIT, "Option -%c requires an argument\n", optopt);
			else if (optopt == 'i')
				notice_np(DEBUG_CAT_INIT, "Option -%c requires an argument\n", optopt);
			else if (isprint(optopt))
				notice_np(DEBUG_CAT_INIT, "Unknown options -%c\n", optopt);
			return -1;
#ifdef MAP_SUPPORT
		case 'F':
			cvalue = optarg;
			if (strlen(cvalue) != 0)
				strncpy(map_cfg, cvalue, sizeof(map_cfg) - 1);
			break;
		case 'u':
			cvalue = optarg;
			if (strlen(cvalue) != 0)
				strncpy(map_user_cfg, cvalue, sizeof(map_user_cfg) - 1);
			break;
#endif
		}
	}

	if (strlen(iface) == 0) {
		os_strncpy(iface, DEFAULT_IFNAME, sizeof(DEFAULT_IFNAME)-1);
		iface[sizeof(DEFAULT_IFNAME)-1] = '\0';
		notice(DEBUG_CAT_INIT, "Default interface=%s\n", iface);
	} else {
		notice(DEBUG_CAT_INIT, "Interface=%s\n", iface);
	}

	return 0;
}

#ifdef MAP_R6
void delete_agent_bsta_cfg(struct dl_list *bsta_list)
{
	struct dpp_config_agent_mld_bsta *sta_db = NULL, *sta_db_tmp = NULL;
	struct dpp_config_affiliated_sta *aff_sta = NULL, *aff_sta_tmp = NULL;

	dl_list_for_each_safe(sta_db, sta_db_tmp, bsta_list, struct  dpp_config_agent_mld_bsta, list) {
		dl_list_for_each_safe(aff_sta, aff_sta_tmp, &sta_db->affiliated_sta_list,
			struct dpp_config_affiliated_sta, list) {
			dl_list_del(&aff_sta->list);
			os_free(aff_sta);
		}

		dl_list_del(&sta_db->list);
		os_free(sta_db);
	}
}

void wapp_read_mlo_bsta_config(struct wifi_app *wapp)
{
	char *pos = NULL, *pos1 = NULL, *pos2 = NULL;
	unsigned int mac_int[6] = {0};
	int line = 0;
	char buf[512] = {0}, config_str[512] = {0};
	unsigned char max_bsta_num = 9, num = 0;
	unsigned int index = 0, i = 0, j = 0;
	char backslash = 0x5C, space = 0x20, SUB = 0x1A;
	struct  dpp_config_agent_mld_bsta *sta_db = NULL;
	struct dpp_config_affiliated_sta *aff_sta = NULL;
	unsigned char aff_ap_idx = 0;
	unsigned int num_ruid = 0;
	char op_class[OP_CLASS_SIZE] = {0};
	u8 is_opclass_pres = -1, is_ruid_pres = -1;
	FILE *f = NULL;
	long value = 0;

	f = fopen(MAPD_WTS_BSTA_CFG_FILE, "r");
	if (f == NULL) {
		err(DEBUG_CAT_MLO, "no (%s), ignore\n", MAPD_WTS_BSTA_CFG_FILE);
		return;
	}

	delete_agent_bsta_cfg(&wapp->agent_bsta_list);
	dl_list_init(&wapp->agent_bsta_list);
	while (wapp_config_get_line(buf, sizeof(buf) - 1, f, &line, &pos)) {
		num++;
		if (num > max_bsta_num) {
			err(DEBUG_CAT_MLO, "too much bsta mlo setting\n");
			break;
		}

		memset(config_str, 0, sizeof(config_str));
		j = 0;
		for (i = 0; i < strlen(pos); i++) {
			if (pos[i] == backslash) {
				if (pos[i + 1] == space) {
					config_str[j] = SUB;
					i++;
					j++;
					continue;
				} else if (pos[i + 1] == backslash) {
					config_str[j] = backslash;
					i++;
					j++;
					continue;
				}
			}

			config_str[j] = pos[i];
			j++;
		}

		sta_db = os_zalloc(sizeof(struct dpp_config_agent_mld_bsta));
		if (!sta_db) {
			err(DEBUG_CAT_MLO, "fail to malloc dpp_config_agent_mld_bsta\n");
			break;
		}

		dl_list_init(&sta_db->affiliated_sta_list);
		dl_list_add_tail(&wapp->agent_bsta_list, &sta_db->list);
		/* insert ' ' before '\0' */
		config_str[j++] = ' ';
		config_str[j++] = '\0';
		pos1 = config_str;
		/*index*/
		pos2 = strchr(pos1, ',');
		if (pos2 == NULL) {
			err(DEBUG_CAT_MLO, "index not found\n");
			goto err;
		}

		*pos2 = '\0';
		value = strtol(pos1, NULL, 10);
		if (value == LONG_MAX || value == LONG_MIN)
			err(DEBUG_CAT_INIT, "strtol fail\n");
		else
			index = (unsigned int)value;

		pos2++;
		pos1 = pos2;
		debug(DEBUG_CAT_MLO, "index :%d\n", index);
		/*al mac*/
		pos2 = strchr(pos1, ' ');
		if (pos2 == NULL) {
			debug(DEBUG_CAT_MLO, "mac not found\n");
			goto err;
		}

		*pos2 = '\0';
		if (sscanf(pos1, "%02x:%02x:%02x:%02x:%02x:%02x", mac_int,
			(mac_int + 1), (mac_int + 2), (mac_int + 3),
			(mac_int + 4), (mac_int + 5)) != ETH_ALEN) {
			err(DEBUG_CAT_MLO, "[%d]sscanf fail!\n", __LINE__);
			goto err;
		}

		for (i = 0; i < ETH_ALEN; i++)
			sta_db->al_mac[i] = (unsigned char)mac_int[i];
		pos2++;
		pos1 = pos2;
		debug(DEBUG_CAT_MLO, "almac "MACSTR"!\n", MAC2STR(sta_db->al_mac));
		/* num of affiliated ap */
		pos2 = strchr(pos1, ' ');
		if (pos2 == NULL) {
			err(DEBUG_CAT_MLO, "num of affiliated ap not found\n");
			goto err;
		}

		*pos2 = '\0';
		value = strtol(pos1, NULL, 10);
		if (value == LONG_MAX || value == LONG_MIN)
			err(DEBUG_CAT_INIT, "strtol fail\n");
		else
			num_ruid = (unsigned int)value;
		pos2++;
		pos1 = pos2;
		sta_db->num_affiliated_sta = (unsigned char)num_ruid;
		err(DEBUG_CAT_MLO, "num of affiliated sta %d\n", sta_db->num_affiliated_sta);
		/*ruid*/

		if (sta_db->num_affiliated_sta > MAX_MLO_NON_SETUP_LINK) {
			err(DEBUG_CAT_MLO, "num of affiliated sta greater than 3\n");
			goto err;
		}

		for (aff_ap_idx = 0; aff_ap_idx < sta_db->num_affiliated_sta; aff_ap_idx++) {
			pos2 = strchr(pos1, ' ');
			if (pos2 == NULL) {
				err(DEBUG_CAT_MLO, "ruid not found\n");
				goto err;
			}

			*pos2 = '\0';
			if (sscanf(pos1, "0x%02x%02x%02x%02x%02x%02x", mac_int,
				(mac_int + 1), (mac_int + 2), (mac_int + 3),
				(mac_int + 4), (mac_int + 5)) == ETH_ALEN) {
				is_ruid_pres = 1;
				err(DEBUG_CAT_MLO, "affiliated ruid "MACSTR"\n", MAC2STR(mac_int));
			} else if (sscanf(pos1, "%03s", op_class) != EOF) {
				is_opclass_pres = 1;
				err(DEBUG_CAT_MLO, "opclass %s\n", op_class);
			} else {
				err(DEBUG_CAT_MLO, "[%s] sscanf fail\n", __func__);
				goto err;
			}

			aff_sta = os_zalloc(sizeof(struct dpp_config_affiliated_sta));
			if (!aff_sta) {
				err(DEBUG_CAT_MLO, "fail to malloc affiliated sta\n");
				goto err;
			}

			dl_list_add_tail(&sta_db->affiliated_sta_list, &aff_sta->list);
			if (is_ruid_pres == 1) {
				for (i = 0; i < ETH_ALEN; i++)
					aff_sta->ruid[i] = (unsigned char)mac_int[i];
			} else if (is_opclass_pres == 1) {
				if (memcmp(op_class, "8", 1) == 0)
					memcpy(aff_sta->op_class, op_class, sizeof(op_class));
				else if (memcmp(op_class, "11", 2) == 0)
					memcpy(aff_sta->op_class, op_class, sizeof(op_class));
				else if (memcmp(op_class, "12", 2) == 0)
					memcpy(aff_sta->op_class, op_class, sizeof(op_class));
#ifdef MAP_6E_SUPPORT
				else if (memcmp(op_class, "13", 2) == 0)
					memcpy(aff_sta->op_class, op_class, sizeof(op_class));
#endif
			}
			pos2++;
			pos1 = pos2;
		}
	}
	if (fclose(f) < 0)
		err(DEBUG_CAT_MLO, "File close error\n");
	return;
err:
	if (fclose(f) < 0)
		err(DEBUG_CAT_MLO, "File close error\n");
	delete_agent_bsta_cfg(&wapp->agent_bsta_list);
}
#endif /* MAP_R6 */

int wapp_read_wts_map_config(struct wifi_app *wapp, char *name, struct set_config_bss_info bss_info[], unsigned char max_bss_num,
			     unsigned char *config_bss_num)
{
	FILE *f;
	int index = 1, resv1, resv2, i, j, k = 0, len = 0;
	unsigned int mac_int[6] = {0};
	unsigned char mac[6] = {0};
	char op_class[4] = {0};
	unsigned char ssid[33] = {0};
	int authmode = 0, encrytype = 0;
	unsigned char key[65] = {0};
	unsigned int content_len = 0;
	char *content = NULL;
	char *pos1 = NULL, *pos2 = NULL;
	int ch = 0, sch = 0;
	unsigned char hidden_ssid = 0;
	unsigned char hidden_ssid_exist = 0;
	unsigned char fh_bss_unhidden = 0;
	unsigned char op_8x = 0, op_11x = 0, op_12x = 0;
#ifdef MAP_6E_SUPPORT
	unsigned char op_13x = 0;
#endif
#ifdef MAP_R6
	wapp_read_mlo_bsta_config(wapp);
#endif /* MAP_R6 */
	char backslash = 0x5C;
	char space = 0x20;
	char SUB = 0x1A;
	int ret = 0;
	int tmp = 0;

	if (!max_bss_num || max_bss_num > MAX_SET_BSS_INFO_NUM) {
		err(DEBUG_CAT_INIT, "[%s]input max_bss_num is invalid", __func__);
		return -1;
	}

	content_len = WTS_FILE_READ_LINE * max_bss_num;
	content = (char *)os_zalloc(content_len);
	if (!content) {
		err(DEBUG_CAT_INIT, "[%s]all buf fail", __func__);
		return -1;
	}

	f = fopen(name, "r");
	if (f == NULL) {
		debug(DEBUG_CAT_INIT, "open file %s fail\n", name);
		os_free(content);
		return -1;
	}

	for (i = 0; i < max_bss_num; i++) {
		memset(&bss_info[i], 0, sizeof(struct set_config_bss_info));
	}

	i = 0;
	do {
		ch = fgetc(f);
		if (ferror(f)) {
			debug(DEBUG_CAT_INIT, "fgetc error");
			break;
		}
		/* If ssid is a space, need add \ as ESC infront of it in wts file. As space is regard as
		 * a separator. If ssid is a \, need add \ as ESC in front of it. when parsing wts file,
		 * "\space"need remove \ and replace space to SUB. "\\"need remove
		 */
		if (ch == backslash) {
			sch = fgetc(f);
			if (ferror(f)) {
				debug(DEBUG_CAT_INIT, "[%s] fgetc fail\n", __func__);
				break;
			}
			if (sch == space) {
				ch = SUB;
			} else if (sch == backslash) {
				ch = sch;
			} else {
				content[i++] = ch;
				ch = sch;
				if (i >= content_len) {
					debug(DEBUG_CAT_INIT, "[%d]wts file is bigger than input buffer fail!\n", __LINE__);
					goto err;
				}
			}
		}
		content[i++] = ch;
		if (i >= content_len) {
			err(DEBUG_CAT_INIT, "[%s] [%d]wts file is bigger than input buffer fail!\n", __func__, __LINE__);
			goto err;
		}
	} while (ch != EOF);

	i = 0;
	pos1 = content;
	while (1) {
		/*index */
		pos2 = strchr(pos1, ',');
		if (pos2 == NULL) {
			debug(DEBUG_CAT_INIT, "index not found\n");
			break;
		}
		*pos2 = '\0';
		ret = sscanf(pos1, "%d", &index);
		if (ret == EOF) {
			err(DEBUG_CAT_INIT, "[%s] sscanf fail\n", __func__);
			continue;
		}
		pos2++;
		pos1 = pos2;

		/*mac */
		pos2 = strchr(pos1, ' ');
		if (pos2 == NULL) {
			debug(DEBUG_CAT_INIT, "mac not found\n");
			break;
		}
		*pos2 = '\0';
		ret = sscanf(pos1, "%02x:%02x:%02x:%02x:%02x:%02x", mac_int, (mac_int + 1), (mac_int + 2), (mac_int + 3), (mac_int + 4),
			     (mac_int + 5));
		if (ret == EOF) {
			err(DEBUG_CAT_INIT, "[%s] sscanf fail\n", __func__);
			continue;
		}
		for (j = 0; j < 6; j++)
			mac[j] = (unsigned char)mac_int[j];

		pos2++;
		pos1 = pos2;

		/*opclass */
		pos2 = strchr(pos1, ' ');
		if (pos2 == NULL) {
			debug(DEBUG_CAT_INIT, "opclass not found\n");
			break;
		}
		*pos2 = '\0';
		/*extract the len of opclass*/
		while (pos1[len] != '\0')
			len++;
		if (len > 3) {
			err(DEBUG_CAT_INIT, "[%s] opclass is greater than 3 characters.\n", __func__);
			len = 0;
			continue;
		}
		len = 0;
		while (pos1[k] != '\0') {
			op_class[k] = pos1[k];
			k++;
		}
		op_class[k] = '\0';
		k = 0;
		notice(DEBUG_CAT_INIT, "opclass %s\n", op_class);

		if (memcmp(op_class, "8", 1) == 0) {
			op_8x++;
			bss_info[i].operating_chan = RADIO_24G;
		} else if (memcmp(op_class, "11", 2) == 0) {
			op_11x++;
			bss_info[i].operating_chan = RADIO_5GL;
		} else if (memcmp(op_class, "12", 2) == 0) {
			op_12x++;
			bss_info[i].operating_chan = RADIO_5GH;
		}
#ifdef MAP_6E_SUPPORT
		else if (memcmp(op_class, "13", 2) == 0) {
			op_13x++;
			bss_info[i].operating_chan = RADIO_6G;
		}
#endif

		pos2++;
		pos1 = pos2;

		/*ssid */
		pos2 = strchr(pos1, ' ');
		if (pos2 == NULL) {
			debug(DEBUG_CAT_INIT, "ssid not found\n");
			break;
		}
		*pos2 = '\0';
		/*extract the len of ssid*/
		while (pos1[len] != '\0')
			len++;
		if (len > 32) {
			err(DEBUG_CAT_INIT, "[%s] ssid is greater than 32 characters.\n", __func__);
			len = 0;
			continue;
		}
		len = 0;
		while (pos1[k] != '\0') {
			ssid[k] = pos1[k];
			k++;
		}
		ssid[k] = '\0';
		k = 0;
		for (j = 0; j < 32; j++) {
			if (ssid[j] == SUB)
				ssid[j] = space;
		}
		pos2++;
		pos1 = pos2;

		/*authmode */
		pos2 = strchr(pos1, ' ');
		if (pos2 == NULL) {
			debug(DEBUG_CAT_INIT, "authmode not found\n");
			break;
		}
		*pos2 = '\0';
		ret = sscanf(pos1, "0x%04x", &authmode);
		if (ret == EOF) {
			err(DEBUG_CAT_INIT, "[%s] sscanf fail\n", __func__);
			continue;
		}
		pos2++;
		pos1 = pos2;

		/*encrytype */
		pos2 = strchr(pos1, ' ');
		if (pos2 == NULL) {
			debug(DEBUG_CAT_INIT, "encrytype not found\n");
			break;
		}
		*pos2 = '\0';
		ret = sscanf(pos1, "0x%04x", &encrytype);
		if (ret == EOF) {
			err(DEBUG_CAT_INIT, "[%s] sscanf fail\n", __func__);
			continue;
		}
		pos2++;
		pos1 = pos2;

		/*key */
		pos2 = strchr(pos1, ' ');
		if (pos2 == NULL) {
			debug(DEBUG_CAT_INIT, "key not found\n");
			break;
		}
		*pos2 = '\0';
		/*extract the length of key*/
		while (pos1[len] != '\0')
			len++;
		if (len > 64) {
			err(DEBUG_CAT_INIT, "[%s] key is greater than 64 characters.\n", __func__);
			len = 0;
			continue;
		}
		len = 0;
		while (pos1[k] != '\0') {
			key[k] = pos1[k];
			k++;
		}
		key[k] = '\0';
		k = 0;
		pos2++;
		pos1 = pos2;

		/*resv1 */
		pos2 = strchr(pos1, ' ');
		if (pos2 == NULL) {
			debug(DEBUG_CAT_INIT, "resv1 not found\n");
			break;
		}
		*pos2 = '\0';
		ret = sscanf(pos1, "%d", &resv1);
		if (ret == EOF) {
			err(DEBUG_CAT_INIT, "[%s] sscanf fail\n", __func__);
			continue;
		}
		pos2++;
		pos1 = pos2;
		/*resv2 */
		pos2 = strstr(pos1, "hidden-");
		if (pos2 != NULL) {
			debug(DEBUG_CAT_INIT, "hidden SSID exist\n");
			hidden_ssid_exist = 1;
		} else {
			debug(DEBUG_CAT_INIT, "no hidden SSID\n");
			hidden_ssid_exist = 0;
			hidden_ssid = 'N';
		}

		if (!hidden_ssid_exist) {
			/*resv2 */
			pos2 = strchr(pos1, '\n');
			if (pos2 == NULL) {
				debug(DEBUG_CAT_INIT, "resv2 not found\n");
				break;
			}
			*pos2 = '\0';
			ret = sscanf(pos1, "%d", &resv2);
			if (ret == EOF) {
				err(DEBUG_CAT_INIT, "[%s] sscanf fail\n", __func__);
				continue;
			}
			pos2++;
			pos1 = pos2;
		} else {
			/*resv2 */
			pos2 = strchr(pos1, ' ');
			if (pos2 == NULL) {
				debug(DEBUG_CAT_INIT, "resv2 not found\n");
				break;
			}
			*pos2 = '\0';
			ret = sscanf(pos1, "%d", &resv2);
			if (ret == EOF) {
				err(DEBUG_CAT_INIT, "[%s] sscanf fail\n", __func__);
				continue;
			}
			pos2++;
			pos1 = pos2;

			/*hidden ssid */
			pos2 = strchr(pos1, '\n');
			if (pos2 == NULL) {
				debug(DEBUG_CAT_INIT, "hidden ssid not found\n");
				break;
			}
			*pos2 = '\0';
			if (sscanf(pos1, "hidden-%c", &hidden_ssid) == 1) {
				pos2++;
				pos1 = pos2;
			} else {
				debug(DEBUG_CAT_INIT, "wrong format hidden ssid\n");
				break;
			}
		}
		bss_info[i].authmode = authmode;
		bss_info[i].encryptype = encrytype;
		memcpy(bss_info[i].mac, mac, 6);
		memcpy(bss_info[i].key, key, sizeof(key));
		memcpy(bss_info[i].oper_class, op_class, sizeof(op_class));
		memcpy(bss_info[i].ssid, ssid, sizeof(ssid));

		bss_info[i].wfa_vendor_extension |= (resv1 & 0x01) << 6;
		bss_info[i].wfa_vendor_extension |= (resv2 & 0x01) << 5;
		if (hidden_ssid == 'Y')
			bss_info[i].hidden_ssid = 1;
		else if (hidden_ssid == 'N')
			bss_info[i].hidden_ssid = 0;
		else
			bss_info[i].hidden_ssid = 0;
		notice(DEBUG_CAT_INIT,
			 "set bss index=%d, mac=" MACSTR ", opclass=%s, ssid=%s, authmode=%04x, encrytype=%04x, key=%s, "
			 "bh_bss=%s, fh_bss=%s hidden_ssid=%d\n",
			 index, MAC2STR(mac), op_class, ssid, authmode, encrytype, key,
			 bss_info[i].wfa_vendor_extension & BIT_BH_BSS ? "1" : "0",
			 bss_info[i].wfa_vendor_extension & BIT_FH_BSS ? "1" : "0", bss_info[i].hidden_ssid);
		i++;
		if (i >= max_bss_num) {
			debug(DEBUG_CAT_INIT, "too much bss wireless setting info\n");
			i--;
			break;
		}
	}

	*config_bss_num = i;
	notice(DEBUG_CAT_INIT, "config_bss_num=%d\n", *config_bss_num);
	os_free(content);
	tmp = fclose(f);
	if (tmp != 0) {
		err(DEBUG_CAT_INIT, "[%s] fclose fail\n", __func__);
		return -1;
	}

	if (0 == op_8x) {
		debug(DEBUG_CAT_INIT, RED("!!!2G Band BSS Configuration is missing!!!\n"));
	}
	if (0 == op_11x) {
		debug(DEBUG_CAT_INIT, RED("!!!5G Low Band BSS Configuration is missing!!!\n"));
	}
	if (0 == op_12x) {
		debug(DEBUG_CAT_INIT, RED("!!!5G High Band BSS Configuration is missing!!!\n"));
	}
#ifdef MAP_6E_SUPPORT
	if (op_13x == 0)
		debug(DEBUG_CAT_INIT, RED("!!!6G High Band BSS Configuration is missing!!!\n"));
#endif

	fh_bss_unhidden = 0;
	for (i = 0; i < *config_bss_num; i++) {
		if ((bss_info[i].oper_class[0] == '8') && (bss_info[i].wfa_vendor_extension & BIT_FH_BSS) &&
		    (bss_info[i].hidden_ssid == 0)) {
			fh_bss_unhidden = 1;
			break;
		}
	}
	if (fh_bss_unhidden == 0) {
		debug(DEBUG_CAT_INIT, "all fronthaul bss of radio 24G is hidden! wps may fail!\n");
	}

	fh_bss_unhidden = 0;
	for (i = 0; i < *config_bss_num; i++) {
		if ((bss_info[i].oper_class[1] == '1') && (bss_info[i].wfa_vendor_extension & BIT_FH_BSS) &&
		    (bss_info[i].hidden_ssid == 0)) {
			fh_bss_unhidden = 1;
			break;
		}
	}
	if (fh_bss_unhidden == 0) {
		debug(DEBUG_CAT_INIT, "all fronthaul bss of radio 5GL is hidden! wps may fail!\n");
	}

	fh_bss_unhidden = 0;
	for (i = 0; i < *config_bss_num; i++) {
		if ((bss_info[i].oper_class[1] == '2') && (bss_info[i].wfa_vendor_extension & BIT_FH_BSS) &&
		    (bss_info[i].hidden_ssid == 0)) {
			fh_bss_unhidden = 1;
			break;
		}
	}
	if (fh_bss_unhidden == 0) {
		debug(DEBUG_CAT_INIT, "all fronthaul bss of radio 5GH is hidden! wps may fail!\n");
	}
	return 0;
err:
	os_free(content);
	tmp = fclose(f);
	if (tmp != 0)
		err(DEBUG_CAT_INIT, "[%s] fclose fail\n", __func__);
	return -1;
}

#ifdef DPP_SUPPORT
void wapp_dpp_config_init(struct wifi_app *wapp)
{
#ifdef DPP_R2_SUPPORT
	int dpp_ret = 0;
#endif /* DPP_R2_SUPPORT */

#ifndef MAP_R3
	if (wapp_dpp_init(wapp) < 0) {
		err(DEBUG_CAT_DPP, "failed to init dpp\n");
	}
#endif /* MAP_R3 */
	if (wapp_dpp_gas_server_init(wapp) < 0) {
		err(DEBUG_CAT_DPP, "failed to init hostapd dpp\n");
	}
	notice(DEBUG_CAT_DPP, "initialized dpp\n");
	dpp_read_config_file(wapp->dpp);
	if (wapp->dpp->dpp_configurator_supported
#ifdef MAP_R3
	    && !is_str_null(wapp->dpp->dpp_private_key)
#endif /* MAP_R3 */
	)
		wapp_dpp_configurator_add(wapp->dpp);
#if !(defined(MAP_R3) || defined(EM_PLUS_SUPPORT))
	else
		wapp->dpp->dpp_allowed_roles = DPP_CAPAB_ENROLLEE;
#endif /* MAP_R3 */

	debug(DEBUG_CAT_DPP, "key %s\n", wapp->dpp->dpp_private_key);
#ifdef MAP_R3
	debug(DEBUG_CAT_DPP, "mac_addr %s\n", wapp->dpp->dpp_macaddr_key);
#ifdef EM_PLUS_EXT_SUPPORT
	debug(DEBUG_CAT_DPP, "info_sn %s\n", wapp->dpp->dpp_info_SN);
#endif
#endif /* MAP_R3 */

#ifdef DPP_R2_SUPPORT

#ifdef MAP_R3
#ifdef EM_PLUS_EXT_SUPPORT
	dpp_ret = dpp_bootstrap_gen_at_bootup(wapp->dpp, (char *)wapp->dpp->dpp_private_key,
			(char *)wapp->dpp->dpp_macaddr_key, (char *)wapp->dpp->dpp_chan_list, (char *)wapp->dpp->dpp_info_SN);
#else
	dpp_ret = dpp_bootstrap_gen_at_bootup(wapp->dpp, (char *)wapp->dpp->dpp_private_key, (char *)wapp->dpp->dpp_macaddr_key,
					      (char *)wapp->dpp->dpp_chan_list);
#endif
#else
#ifdef EM_PLUS_EXT_SUPPORT
	dpp_ret = dpp_bootstrap_gen_at_bootup(wapp->dpp, (char *)wapp->dpp->dpp_private_key, NULL, NULL, NULL);
#else
	dpp_ret = dpp_bootstrap_gen_at_bootup(wapp->dpp, (char *)wapp->dpp->dpp_private_key, NULL, NULL);
#endif
#endif /* MAP_R3 */
	notice(DEBUG_CAT_DPP, "dpp: dpp_configurator_supported :%d, gen_ret:%d\n", wapp->dpp->dpp_configurator_supported,
		 dpp_ret);
#if !(defined(MAP_R3) || defined(EM_PLUS_SUPPORT))
	if (dpp_ret != -1)
		wapp_dpp_presence_annouce(wapp, NULL);
#endif /* MAP_R3 */
#else
#ifdef EM_PLUS_EXT_SUPPORT
	dpp_bootstrap_gen_at_bootup(wapp->dpp, (char *)wapp->dpp->dpp_private_key, NULL, NULL, NULL);
#else
	dpp_bootstrap_gen_at_bootup(wapp->dpp, (char *)wapp->dpp->dpp_private_key, NULL, NULL);
#endif
#endif /* DPP_R2_SUPPORT */

	dl_list_init(&wapp->scan_results_list);
#ifdef MAP_R3
	if (wapp->dpp->is_map) {
		if (wapp->dpp->dpp_configurator_supported) {
			wapp_read_wts_map_config(wapp, MAPD_WTS_FILE, wapp->dpp->bss_config, MAX_SET_BSS_INFO_NUM,
						 &wapp->dpp->bss_config_num);

			debug(RT_DEBUG_TRACE, "Setting configurator\n");
			dpp_controller_start(wapp->dpp);
		}
	}
	dl_list_init(&wapp->map_devices);
#endif /* MAP_R3 */
#if !(defined(MAP_R3) || defined(EM_PLUS_SUPPORT))
#ifdef DPP_R2_SUPPORT
	/*set vendor beacon ie for DPP CCE */
	if (wapp->dpp->dpp_configurator_supported)
		wapp_dpp_set_ie(wapp);
#endif /* DPP_R2_SUPPORT */
#endif /* MAP_R3 */
}

int get_dpp_parameters(struct map_info *map, char *param, char *value, size_t val_len)
{
#ifdef OPENWRT_SUPPORT
	const char *tmp_value = NULL;
	unsigned int len = 0;
	struct kvc_context *dat_ctx = NULL;
	const char *file = NULL;
	int ret = 0;

	notice(DEBUG_CAT_DPP, "%s param(%s)\n", __func__, param);

	os_memset(value, 0, val_len);
	file = DPP_CFG_FILE;

	if (!file) {
		err(DEBUG_CAT_DPP,  "invalid file!!!\n");
		return -1;
	}

	dat_ctx = dat_load(file);
	if (!dat_ctx) {
		err(DEBUG_CAT_DPP, "load file(%s) fail\n", file);
		ret = -1;
		goto out;
	}

	tmp_value = kvc_get(dat_ctx, (const char *)param);
	if (!tmp_value) {
		err(DEBUG_CAT_DPP, "get param(%s) fail\n", param);
		ret = -1;
		goto out;
	}
	len = os_min(os_strlen(tmp_value), val_len - 1);
	os_memcpy(value, tmp_value, len);

	notice(DEBUG_CAT_DPP, "%s value(%s)\n", __func__, value);
out:
	if (dat_ctx)
		kvc_unload(dat_ctx);

	return ret;
#else
	char cmd_buffer[256] = {0};
	char tmp_buffer[350] = {0};
	char temp_file[] = "/tmp/system_command_output";
	FILE *fp;

	os_memset(value, 0, val_len);
	os_snprintf(cmd_buffer, sizeof(cmd_buffer), "nvram_get 2860 %s > %s &", param, temp_file);
	if ((fp = popen(temp_file, "r")) == NULL) {
		err(DEBUG_CAT_DPP, "Error opening pipe!\n");
		return -1;
	}
	fscanf(fp, "%349s", tmp_buffer);

	os_memcpy(value, tmp_buffer, val_len);
	notice(DEBUG_CAT_DPP, "get_dpp_parameter %s = %s\n", param, value);

	if (pclose(fp)) {
		err(DEBUG_CAT_DPP, "Command not found or exited with error status\n");
		return -1;
	}

	return 0;
#endif
}

int dpp_read_config_file_for_connection(struct wifi_app *wapp)
{
	char param[64], value[1024] = {0};
	unsigned char buf_temp[1024] = {0};
	int k = 0;
	struct wapp_dev *wdev = NULL, *wdev_temp = NULL;
	struct dpp_config config[3];
	int ret = 0;
#ifdef MAP_R3
	struct dpp_sec_cred *cred = NULL;
	struct dpp_authentication auth;
	// struct dpp_bss_cred *bss_cred = NULL;
	u16 is_1905_conn = 0, is_normal = 0;
	struct dl_list *dev_list;
	dev_list = &wapp->dev_list;
	// char all_zero_mac[MAC_ADDR_LEN]={0};
#endif
	long val = 0;

	if (!wapp) {
		err(DEBUG_CAT_DPP, "\033[1;31m %s, %u \033[0m\n", __func__, __LINE__);
		return WAPP_INVALID_ARG;
	}

	os_memset(config, 0, 3 * sizeof(struct dpp_config));
	ret = os_snprintf(param, sizeof(param), "_valid");
	if (os_snprintf_error(sizeof(param), ret)) {
		err(DEBUG_CAT_DPP, "[%s] os_snprintf fail\n", __func__);
		return -1;
	}
	get_dpp_parameters(wapp->map, param, value, sizeof(value));
	if (os_strcmp(value, "1"))
		is_normal = 0;
	else
		is_normal = 1;
	NdisZeroMemory(value, 1024);
	NdisZeroMemory(param, 64);
	ret = os_snprintf(param, sizeof(param), "_1905valid");
	if (os_snprintf_error(sizeof(param), ret)) {
		err(DEBUG_CAT_DPP, "[%s] os_snprintf fail\n", __func__);
		return -1;
	}
	get_dpp_parameters(wapp->map, param, value, sizeof(value));
	notice(DEBUG_CAT_DPP,  "%s _1905valid%s\n", __func__, value);
	if (os_strcmp(value, "1"))
		return -1;
	is_1905_conn = 1;
	if (is_normal) {
		NdisZeroMemory(value, 1024);
		NdisZeroMemory(param, 64);
		ret = os_snprintf(param, sizeof(param), "_ssid");
		if (os_snprintf_error(sizeof(param), ret)) {
			err(DEBUG_CAT_DPP, "[%s] os_snprintf fail\n", __func__);
			return -1;
		}
		get_dpp_parameters(wapp->map, param, value, sizeof(value));
		config[k].ssid_len = os_strlen(value);
		config[k].ssid = os_zalloc(config[k].ssid_len + 1);
		if (!config[k].ssid)
			return -1;
		os_memcpy(config[k].ssid, value, os_strlen(value));
		config[k].ssid[os_strlen(value)] = '\0';
		NdisZeroMemory(value, 1024);
		NdisZeroMemory(param, 64);
		ret = os_snprintf(param, sizeof(param), "_akm");
		if (os_snprintf_error(sizeof(param), ret)) {
			err(DEBUG_CAT_DPP, "[%s] os_snprintf fail\n", __func__);
			goto error;
		}
		get_dpp_parameters(wapp->map, param, value, sizeof(value));
		val = strtol(value, NULL, 10);
		if (val == LONG_MAX || val == LONG_MIN)
			err(DEBUG_CAT_INIT, "strtol fail\n");
		else
			config[k].akm = (u8)val;
		NdisZeroMemory(value, 1024);
		NdisZeroMemory(param, 64);
		ret = os_snprintf(param, sizeof(param), "_passPhrase");
		if (os_snprintf_error(sizeof(param), ret)) {
			err(DEBUG_CAT_DPP, "[%s] os_snprintf fail\n", __func__);
			goto error;
		}
		get_dpp_parameters(wapp->map, param, value, sizeof(value));
		os_memcpy(config[k].psk, value, 32);
		NdisZeroMemory(value, 1024);
		NdisZeroMemory(param, 64);
		ret = os_snprintf(param, sizeof(param), "_cSignKey");
		if (os_snprintf_error(sizeof(param), ret)) {
			err(DEBUG_CAT_DPP, "[%s] os_snprintf fail\n", __func__);
			goto error;
		}
		get_dpp_parameters(wapp->map, param, value, sizeof(value));
		config[k].dpp_csign_len = os_strlen(value) / 2;
		config[k].dpp_csign = os_zalloc(config[k].dpp_csign_len + 1);
		if (!config[k].dpp_csign) {
			err(DEBUG_CAT_DPP, "[%s] os_snprintf fail\n", __func__);
			goto error;
		}
		hexstr2bin(value, config[k].dpp_csign, config[k].dpp_csign_len);
		NdisZeroMemory(value, 1024);
		NdisZeroMemory(param, 64);
		ret = os_snprintf(param, sizeof(param), "_netAccessKey");
		if (os_snprintf_error(sizeof(param), ret)) {
			err(DEBUG_CAT_DPP, "[%s] os_snprintf fail\n", __func__);
			goto error;
		}
		get_dpp_parameters(wapp->map, param, value, sizeof(value));
		config[k].dpp_netaccesskey_len = os_strlen(value) / 2;
		config[k].dpp_netaccesskey = os_zalloc(config[k].dpp_netaccesskey_len + 1);
		if (!config[k].dpp_netaccesskey) {
			err(DEBUG_CAT_DPP, "[%s] os_zalloc fail\n", __func__);
			goto error;
		}
		hexstr2bin(value, config[k].dpp_netaccesskey, config[k].dpp_netaccesskey_len);
		NdisZeroMemory(value, 1024);
		NdisZeroMemory(param, 64);
		ret = os_snprintf(param, sizeof(param), "_connector");
		if (os_snprintf_error(sizeof(param), ret)) {
			err(DEBUG_CAT_DPP, "[%s] os_snprintf fail\n", __func__);
			goto error;
		}
		get_dpp_parameters(wapp->map, param, value, sizeof(value));
		config[k].dpp_connector = os_zalloc(os_strlen(value) + 1);
		if (!config[k].dpp_connector) {
			err(DEBUG_CAT_DPP, "[%s] os_zalloc fail\n", __func__);
			goto error;
		}
		os_memcpy(config[k].dpp_connector, value, os_strlen(value));
		config[k].dpp_connector[os_strlen(value)] = '\0';
	}
	if (is_1905_conn) {
		NdisZeroMemory(value, 1024);
		NdisZeroMemory(param, 64);
		os_memset(&auth, '\0', sizeof(struct dpp_authentication));
		ret = os_snprintf(param, sizeof(param), "_netKeyExpiry");
		if (os_snprintf_error(sizeof(param), ret)) {
			err(DEBUG_CAT_DPP, "[%s] os_snprintf fail\n", __func__);
			goto error;
		}
		get_dpp_parameters(wapp->map, param, value, sizeof(value));
		auth.net_access_key_expiry = strtol(value, NULL, 10);
		if (errno == ERANGE ||  auth.net_access_key_expiry > INT_MAX || auth.net_access_key_expiry < INT_MIN)
			err(DEBUG_CAT_DPP, "[%s] strtol value1 fail\n", __func__);

		NdisZeroMemory(value, 1024);
		NdisZeroMemory(param, 64);
		ret = os_snprintf(param, sizeof(param), "_decryptThreshold");
		if (os_snprintf_error(sizeof(param), ret)) {
			err(DEBUG_CAT_DPP, "[%s] os_snprintf fail\n", __func__);
			goto error;
		}
		get_dpp_parameters(wapp->map, param, value, sizeof(value));
		val = strtol(value, NULL, 10);
		if (val == LONG_MAX || val == LONG_MIN)
			err(DEBUG_CAT_INIT, "strtol fail\n");
		else
			auth.decrypt_thresold = (unsigned short)val;
		NdisZeroMemory(value, 1024);
		NdisZeroMemory(param, 64);
		ret = os_snprintf(param, sizeof(param), "_1905connector");
		if (os_snprintf_error(sizeof(param), ret)) {
			err(DEBUG_CAT_DPP, "[%s] os_snprintf fail\n", __func__);
			goto error;
		}
		get_dpp_parameters(wapp->map, param, value, sizeof(value));
		auth.connector = os_zalloc(os_strlen(value) + 1);
		if (!auth.connector) {
			err(DEBUG_CAT_DPP, "[%s] os_zalloc fail\n", __func__);
			goto error;
		}
		os_memcpy(auth.connector, value, os_strlen(value));
		NdisZeroMemory(buf_temp, 1024);
		NdisZeroMemory(value, 1024);
		NdisZeroMemory(param, 64);
		ret = os_snprintf(param, sizeof(param), "_1905netAccessKey");
		if (os_snprintf_error(sizeof(param), ret)) {
			err(DEBUG_CAT_DPP, "[%s] os_snprintf fail\n", __func__);
			goto error;
		}
		get_dpp_parameters(wapp->map, param, value, sizeof(value));
		hexstr2bin(value, buf_temp, os_strlen(value));
		auth.net_access_key = wpabuf_alloc(os_strlen(value));
		if (!auth.net_access_key) {
			err(DEBUG_CAT_DPP, "[%s] os_alloc fail\n", __func__);
			goto error;
		}
		NdisCopyMemory(auth.net_access_key->buf, buf_temp, os_strlen(value));
		auth.net_access_key->used = os_strlen(value);
		NdisZeroMemory(buf_temp, 1024);
		NdisZeroMemory(value, 1024);
		NdisZeroMemory(param, 64);
		ret = os_snprintf(param, sizeof(param), "_1905cSignKey");
		if (os_snprintf_error(sizeof(param), ret)) {
			err(DEBUG_CAT_DPP, "[%s] os_snprintf fail\n", __func__);
			goto error;
		}
		get_dpp_parameters(wapp->map, param, value, sizeof(value));
		NdisZeroMemory(buf_temp, 1024);
		NdisZeroMemory(value, 1024);
		NdisZeroMemory(param, 64);
		hexstr2bin(value, buf_temp, os_strlen(value));
		auth.c_sign_key = wpabuf_alloc(os_strlen(value));
		if (!auth.c_sign_key) {
			err(DEBUG_CAT_DPP, "[%s] os_strlen fail\n", __func__);
			goto error;
		}
		NdisCopyMemory(auth.c_sign_key->buf, buf_temp, os_strlen(value));
		auth.c_sign_key->used = os_strlen(value);
		cred = wapp_dpp_save_dpp_cred(&auth);
		if (!cred) {
			err(DEBUG_CAT_DPP, "[%s] wapp_dpp_save_dpp_cred fail\n", __func__);
			goto error;
		}

		wpabuf_clear_free(auth.net_access_key);
		wpabuf_clear_free(auth.c_sign_key);
		os_free(auth.connector);
	}
#ifdef MAP_R3_RECONFIG

	NdisZeroMemory(value, 1024);
	NdisZeroMemory(param, 64);
	ret = os_snprintf(param, sizeof(param), "_ppkey");
	if (os_snprintf_error(sizeof(param), ret)) {
		err(DEBUG_CAT_DPP, "[%s] os_snprintf fail\n", __func__);
		goto error;
	}
	get_dpp_parameters(wapp->map, param, value, sizeof(value));
	config[k].dpp_ppkey_len = os_strlen(value) / 2;
	config[k].dpp_ppkey = os_zalloc(config[k].dpp_ppkey_len + 1);
	if (!config[k].dpp_ppkey)
		err(DEBUG_CAT_DPP, "ppKey not found in dpp_cfg.txt\n");
	hexstr2bin(value, config[k].dpp_ppkey, config[k].dpp_ppkey_len);

	notice(DEBUG_CAT_DPP, "\n ppKey on rread frol dpp_cfg.txt - %s", config[k].dpp_ppkey);
#endif
	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list)
	{
		if (wdev->dev_type == WAPP_DEV_TYPE_STA) {
			if (is_normal == 0 || is_1905_conn == 0)
				continue;
			if (wdev->config) {
				if (wdev->config->ssid) {
					os_free(wdev->config->ssid);
					wdev->config->ssid = NULL;
				}
				if (wdev->config->dpp_connector) {
					os_free(wdev->config->dpp_connector);
					wdev->config->dpp_connector = NULL;
				}
				if (wdev->config->dpp_csign) {
					os_free(wdev->config->dpp_csign);
					wdev->config->dpp_csign = NULL;
				}
				if (wdev->config->dpp_netaccesskey) {
					os_free(wdev->config->dpp_netaccesskey);
					wdev->config->dpp_netaccesskey = NULL;
				}
#ifdef MAP_R3_RECONFIG
				if (wdev->config->dpp_ppkey) {
					os_free(wdev->config->dpp_ppkey);
					wdev->config->dpp_ppkey = NULL;
				}
#endif
			}
			if (!wdev->config)
				wdev->config = os_zalloc(sizeof(struct dpp_config));
			if (wdev->config) {
				os_memcpy(wdev->config, (char *)(&config[k]), sizeof(struct dpp_config));
				if (config[k].dpp_csign_len > 0) {
					wdev->config->dpp_csign = os_zalloc(config[k].dpp_csign_len);
					os_memcpy(wdev->config->dpp_csign, config[k].dpp_csign, config[k].dpp_csign_len);
#ifdef MAP_R3_RECONFIG
					if (wapp->dpp_csign) {
						os_free(wapp->dpp_csign);
						wapp->dpp_csign = NULL;
					}
					wapp->dpp_csign = os_zalloc(config[k].dpp_csign_len);
					if (!wapp->dpp_csign) {
						wpa_printf(MSG_ERROR, DPP_MAP_PREX
						"wapp->dpp_csign allocation failed");
						goto error;
					}
					os_memcpy(wapp->dpp_csign, config[k].dpp_csign,
					config[k].dpp_csign_len);
					wapp->dpp_csign_len = config[k].dpp_csign_len;

					wpa_hexdump(MSG_DEBUG, DPP_MAP_PREX "in process config cign key",
					wapp->dpp_csign, wapp->dpp_csign_len);
#endif /* MAP_R3_RECONFIG */

				}
				if (config[k].dpp_netaccesskey_len > 0) {
					wdev->config->dpp_netaccesskey = os_zalloc(config[k].dpp_netaccesskey_len);
					os_memcpy(wdev->config->dpp_netaccesskey, config[k].dpp_netaccesskey,
						  config[k].dpp_netaccesskey_len);
				}
				if (config[k].ssid_len > 0) {
					wdev->config->ssid = os_zalloc(config[k].ssid_len + 1);
					os_memcpy(wdev->config->ssid, config[k].ssid, config[k].ssid_len);
					wdev->config->ssid[config[k].ssid_len] = '\0';
				}
				if (os_strlen(config[k].dpp_connector) > 0) {
					wdev->config->dpp_connector = os_zalloc(os_strlen(config[k].dpp_connector) + 1);
					os_memcpy(wdev->config->dpp_connector, config[k].dpp_connector, os_strlen(config[k].dpp_connector));
					wdev->config->dpp_connector[os_strlen(config[k].dpp_connector)] = '\0';
				}
#ifdef MAP_R3_RECONFIG
				if (config[k].dpp_ppkey_len > 0) {
					wdev->config->dpp_ppkey = os_zalloc(config[k].dpp_ppkey_len);
					os_memcpy(wdev->config->dpp_ppkey, config[k].dpp_ppkey, config[k].dpp_ppkey_len);
				}
#endif
				wdev->config->key_mgmt = WPA_KEY_MGMT_DPP;
			}
		}
	}
	if (config[k].dpp_csign)
		os_free(config[k].dpp_csign);
	if (config[k].dpp_netaccesskey)
		os_free(config[k].dpp_netaccesskey);
	if (config[k].ssid)
		os_free(config[k].ssid);
	if (config[k].dpp_connector)
		os_free(config[k].dpp_connector);
#ifdef MAP_R3_RECONFIG
	if (config[k].dpp_ppkey)
		os_free(config[k].dpp_ppkey);
#endif

	/* Get QR code save conunt for */
	get_dpp_parameters(wapp->map, "qr_count", value, sizeof(value));
	if (wapp->dpp) {
		wapp->dpp->qr_code_num = strtol(value, NULL, 10);
		if (errno == ERANGE)
			err(DEBUG_CAT_DPP, "%s strtol fail for qr_code_num\n", __func__);
	}

	if (cred)
		os_free(cred);

	return WAPP_SUCCESS;

error:
	if (auth.c_sign_key)
		wpabuf_clear_free(auth.c_sign_key);
	if (auth.net_access_key)
		wpabuf_clear_free(auth.net_access_key);
	if (auth.connector)
		os_free(auth.connector);
	if (config[k].dpp_connector)
		os_free(config[k].dpp_connector);
	if (config[k].dpp_netaccesskey)
		os_free(config[k].dpp_netaccesskey);
	if (config[k].dpp_csign)
		os_free(config[k].dpp_csign);
	if (config[k].ssid)
		os_free(config[k].ssid);
	if (cred)
		os_free(cred);
	return -1;
}

#endif /*DPP_SUPPORT */
static void wapp_terminate(int sig, void *signal_ctx)
{
	if (sig != SIGTERM)
		eloop_terminate();
	else
		eloop_terminate2();
}

#ifdef MTK_MLO_MAP_SUPPORT
void wapp_get_mlo_mld_info(struct wifi_app *wapp)
{
	struct wapp_dev *wdev = NULL, *wdev_temp = NULL;
	struct dl_list *dev_list = NULL;
	struct _wdev_mlo_info mlo_info;

	dev_list = &wapp->dev_list;

	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
		os_memset(&mlo_info, 0, sizeof(struct _wdev_mlo_info));
		wapp_get_mlo_info(wapp, (char *)wdev->ifname, (char *)&mlo_info, sizeof(struct  _wdev_mlo_info));
	}
}
#endif

#ifdef STANDARD_NL_CMD
void wapp_hdev_head_release(struct wifi_app *wapp)
{
	struct dev_info *dev = NULL, *dev_tmp = NULL;

	dl_list_for_each_safe(dev, dev_tmp, &wapp->hdev_head, struct dev_info, list) {
		dl_list_del(&dev->list);
		os_free(dev);
	}
	dl_list_init(&wapp->hdev_head);
}



int wapp_alloc_hdev_list(struct wifi_app *wapp, struct dev_info *dev_array,
		unsigned char num_devs)
{
	struct dev_info *dev = NULL;
	struct wapp_dev *wdev = NULL;
	unsigned char i = 0;

	dl_list_init(&wapp->hdev_head);

	for (i = 0; i < num_devs; i++) {
		dev = os_zalloc(sizeof(*dev));
		if (dev == NULL) {
			err(DEBUG_CAT_INIT, "fail to alloc dev\n");
			goto fail;
		}
		memcpy(dev, &dev_array[i], sizeof(*dev));
		dl_list_add_tail(&wapp->hdev_head, &dev->list);
	}

	dl_list_for_each(wdev, &wapp->dev_list, struct wapp_dev, list) {
		dl_list_for_each(dev, &wapp->hdev_head, struct dev_info, list) {
			if (wdev->ifindex == dev->ifindex) {
				wdev->dev = dev;
				break;
			}
		}
	}

	return 0;
fail:
	wapp_hdev_head_release(wapp);

	return -1;

}

void wapp_phy_head_release(struct wifi_app *wapp)
{
	struct phy_info *phy = NULL, *phy_tmp = NULL;

	dl_list_for_each_safe(phy, phy_tmp, &wapp->phy_head, struct phy_info, list) {
		dl_list_del(&phy->list);
		os_free(phy);
	}
	dl_list_init(&wapp->phy_head);
}


int wapp_alloc_phy_list(struct wifi_app *wapp, struct phy_info *phy_array,
		unsigned char num_phys)
{
	struct phy_info *phy = NULL;
	struct wapp_dev *wdev = NULL;
	unsigned char i = 0;

	dl_list_init(&wapp->phy_head);

	for (i = 0; i < num_phys; i++) {
		phy = os_zalloc(sizeof(*phy));
		if (phy == NULL) {
			err(DEBUG_CAT_INIT, "fail to alloc phy\n");
			goto fail;
		}
		memcpy(phy, &phy_array[i], sizeof(*phy));
		dl_list_add_tail(&wapp->phy_head, &phy->list);
	}

	dl_list_for_each(wdev, &wapp->dev_list, struct wapp_dev, list) {
		dl_list_for_each(phy, &wapp->phy_head, struct phy_info, list) {
			if (wdev->dev && (wdev->dev->phy_id == phy->phy_id)) {
				wdev->phy = phy;
				break;
			}
		}
	}

	return 0;
fail:
	wapp_phy_head_release(wapp);

	return -1;

}
#endif

char log_cat_str[][32] = {
	{"MISC"},
	{"INIT"},
	{"QOS"},
	{"EPCS"},
	{"T2LM"},
	{"NL80211"},
	{"CHANNEL"},
	{"EVENT"},
	{"ACL"},
};

int dump_globe_info(struct wifi_app *wapp, char *buf, int max_len)
{
	int ret = 0, len = 0;

	ret = get_log_info(buf + len, max_len - len);
	if (ret < 0) {
		err(DEBUG_CAT_MISC, "get_log_info fail\n");
		return -1;
	}
	len += ret;
#ifdef STANDARD_NL_CMD
	ret = dump_phy_info(wapp, buf + len, max_len - len);
	if (ret < 0) {
		err(DEBUG_CAT_MISC, "dump_phy_info fail\n");
		return -1;
	}
	len += ret;

	ret = dump_dev_info(wapp, buf + len, max_len - len);
	if (ret < 0) {
		err(DEBUG_CAT_MISC, "dump_dev_info fail\n");
		return -1;
	}
	len += ret;
#endif
	ret = dump_wapp_info(wapp, buf + len, max_len - len);
	if (ret < 0) {
		err(DEBUG_CAT_MISC, "dump_wapp_info fail\n");
		return -1;
	}
	len += ret;

	ret = dump_map_info(wapp, buf + len, max_len - len);
	if (ret < 0) {
		err(DEBUG_CAT_MISC, "dump_map_info fail\n");
		return -1;
	}
	len += ret;
#ifdef STANDARD_NL_CMD
	ret = dump_scan_cap(wapp->map->off_ch_scan_capab, buf + len, max_len - len);
	if (ret < 0) {
		err(DEBUG_CAT_MISC, "dump_scan_cap fail\n");
		return -1;
	}
	len += ret;
#endif
	ret = dump_wdev_info(wapp, buf + len, max_len - len);
	if (ret < 0) {
		err(DEBUG_CAT_MISC, "dump_dev_info fail\n");
		return -1;
	}
	len += ret;

	ret = dump_txpower_info(wapp, buf + len, max_len - len);
	if (ret < 0) {
		err(DEBUG_CAT_MISC, "dump_txpower_info fail\n");
		return -1;
	}
	len += ret;
#ifdef STANDARD_NL_CMD
	ret = dump_chan_list(wapp, buf + len, max_len - len);
	if (ret < 0) {
		err(DEBUG_CAT_MISC, "dump_chan_list fail\n");
		return -1;
	}
	len += ret;

	ret = dump_opclass(wapp, buf + len, max_len - len);
	if (ret < 0) {
		err(DEBUG_CAT_MISC, "dump_opclass fail\n");
		return -1;
	}
	len += ret;
#endif
	ret = wdev_ap_show_ap_metric(wapp, buf + len, max_len - len);
	if (ret < 0) {
		err(DEBUG_CAT_MISC, "wdev_ap_show_ap_metric fail\n");
		return -1;
	}
	len += ret;

	return len;

}

int main(int argc, char *argv[])
{
	int ret = 0;
	int opmode;
	int drv_mode;
	int debug_level = 0;
	int version = 2;
	char filename[256] = {0};
	struct wifi_app wapp_cfg;
	struct hotspot hs;
	struct mbo_cfg mbo;
	struct oce_cfg oce;
#ifdef MAP_SUPPORT
	struct map_info map;
	char value[10] = {0};
	char map_cfg[128] = {0};
	char map_user_cfg[128] = {0};
#endif
	struct wifi_app *wapp = &wapp_cfg;
#ifdef STANDARD_NL_CMD
	unsigned char num_phys = 0, num_devs = 0;
	struct phy_info *phy = NULL;
	struct dev_info *dev = NULL;
#endif
	long val = 0;
#ifdef DFS_SLAVE_SUPPORT
	int DfsSlaveEn = 0;
#endif
#ifdef EM_PLUS_SUPPORT
	u8 MapAcsDatParam = 0;
	int result = 0;
#endif

	ret = log_init("wappd", log_cat_str, ARRAY_SIZE(log_cat_str));
	if (ret) {
		err(DEBUG_CAT_INIT, "log_init fail\n");
		goto error;
	}

	/* default setting */
	opmode = OPMODE_AP;
	drv_mode = WEXT;

	memset(wapp, 0, sizeof(struct wifi_app));
	memset(&hs, 0, sizeof(struct hotspot));
	memset(&mbo, 0, sizeof(struct mbo_cfg));
	memset(&oce, 0, sizeof(struct oce_cfg));
#ifdef MAP_SUPPORT
	memset(&map, 0, sizeof(struct map_info));
#endif

#ifdef MAP_SUPPORT
	ret = process_options(argc, argv, filename, &opmode, &drv_mode, &debug_level, &version, &wapp_cfg.iface[0], map_cfg, map_user_cfg);
#else
	ret = process_options(argc, argv, filename, &opmode, &drv_mode, &debug_level, &version, &wapp_cfg.iface[0]);

#endif

	if (ret) {
		hs_usage();
		err(DEBUG_CAT_INIT, "process_options fail\n");
		goto error;
	}

	RTDebugLevel = debug_level;

#ifdef EM_PLUS_SUPPORT
	result = wapp_process_running(wapp, LOCK_FILE);
	if (result != 0) {
		// Another instance is running
		err(DEBUG_CAT_INIT, "another wapp instance running\n");
		goto error;
	}
#endif /* EM_PLUS_SUPPORT */

	ret = wapp_cmm_init(wapp, drv_mode, opmode, version, &hs, &mbo, &oce, &map);
	if (ret) {
		err(DEBUG_CAT_INIT, "wapp_cmm_init fail\n");
		goto error;
	}

#ifdef MAP_SUPPORT
	if (strlen(map_cfg) == 0) {
		ret = os_snprintf(wapp->map->map_cfg, 128, "/etc/map/mapd_cfg");
		if (os_snprintf_error(128, ret)) {
			err(DEBUG_CAT_INIT, "os_snprintf fail\n");
			goto error;
		}
	} else {
		ret = os_snprintf(wapp->map->map_cfg, 128, "%s", map_cfg);
		if (os_snprintf_error(128, ret)) {
			err(DEBUG_CAT_INIT, "os_snprintf fail\n");
			goto error;
		}
	}

	if (strlen(map_user_cfg) == 0) {
		ret = os_snprintf(wapp->map->map_user_cfg, 128, "/etc/map/mapd_user.cfg");
		if (os_snprintf_error(128, ret)) {
			err(DEBUG_CAT_INIT, "os_snprintf fail\n");
			goto error;
		}
	} else {
		ret = os_snprintf(wapp->map->map_user_cfg, 128, "%s", map_user_cfg);
		if (os_snprintf_error(128, ret)) {
			err(DEBUG_CAT_INIT, "os_snprintf fail\n");
			goto error;
		}
	}
#endif

#ifdef MAP_SUPPORT
	dl_list_init(&wapp->air_monitor_query_list);
	dl_list_init(&wapp->sta_mntr_list);
	dl_list_init(&wapp->bh_assoc_ctrl_list);
#endif
#ifdef MAP_R6
	dl_list_init(&wapp->agent_bsta_list);
#endif /* MAP_R6 */

	setsid();

	ret = wapp_socket_and_ctrl_inf_init(wapp, drv_mode, opmode);
	if (ret) {
		err(DEBUG_CAT_INIT, "wapp_socket_and_ctrl_inf_init fail\n");
		goto error1;
	}

#ifdef QOS_R1
	wapp_drv_qos_init(wapp);
#endif

#ifdef STANDARD_NL_CMD
	phy = wapp_get_hw_info(wapp, &num_phys);
	if (!phy) {
		err(DEBUG_CAT_INIT, "wapp_get_hw_info fail\n");
		goto error1;
	}
	dev = wapp_get_devs(wapp, &num_devs);
	if (!dev) {
		err(DEBUG_CAT_INIT, "wapp_get_devs fail\n");
		goto error1;
	}
	ret = wapp_init_phy_devs(wapp, phy, num_phys, dev, num_devs);
	if (ret) {
		err(DEBUG_CAT_INIT, "wapp_init_phy_devs fail\n");
		goto error1;
	}
	/*here turn dev array to dev list to wapp*/
	ret = wapp_alloc_hdev_list(wapp, dev, num_devs);
	if (ret) {
		err(DEBUG_CAT_INIT, "wapp_alloc_hdev_list fail\n");
		goto error1;
	}
	ret = wapp_alloc_phy_list(wapp, phy, num_phys);
	if (ret) {
		err(DEBUG_CAT_INIT, "wapp_alloc_phy_list fail\n");
		goto error1;
	}
#ifdef MAP_SUPPORT
	ret = wapp_get_country(wapp, wapp->country_code);
	if (ret) {
		err(DEBUG_CAT_INIT, "get country code fail\n");
		goto error1;
	}
	ret = wapp_init_scan_cap(wapp);
	if (ret) {
		err(DEBUG_CAT_INIT, "init scan caps fail\n");
		goto error1;
	}
#endif
#else
	ret += wapp_get_wireless_interfaces(wapp);
#endif

#ifdef MTK_MLO_MAP_SUPPORT
	wapp_get_mlo_mld_info(wapp);
#endif

	/* Initialize control interface */
	wapp->w_ctrl_iface = wapp_ctrl_iface_init(wapp);
#ifdef MAP_SUPPORT
	wapp_iface_init(wapp);
#ifdef AUTOROLE_NEGO
	wapp_MapDevRoleNegotiation_init(wapp);
#endif

	get_map_parameters(wapp->map, "Enable_WPS_toggle_5GL_5GH", value, NON_DRIVER_PARAM, sizeof(value));
	if (!strcmp(value, "1"))
		wapp->map->enable_wps_toggle_5GL_5GH = 1;
	else
		wapp->map->enable_wps_toggle_5GL_5GH = 0;
	get_map_parameters(wapp->map, "MAP_QuickChChange", value, NON_DRIVER_PARAM, sizeof(value));
	if (!strcmp(value, "1"))
		wapp->map->quick_ch_change = 1;
	else
		wapp->map->quick_ch_change = 0;
#ifdef MAP_R2
	get_map_parameters(wapp->map, "MetricRepIntv", value, NON_DRIVER_PARAM, sizeof(value));
	val = strtol(value, NULL, 10);
	if (val == LONG_MAX || val == LONG_MIN)
		err(DEBUG_CAT_INIT, "strtol fail\n");
	else
		wapp->map->metric_rep_intv = (u32)val;
#endif
#ifdef MAP_R6
	get_map_parameters(wapp->map, "AfcDeviceType", value, DRIVER_6G_PARAM, sizeof(value));
	val = strtol(value, NULL, 10);
	if (val == LONG_MAX || val == LONG_MIN)
		err(DEBUG_CAT_INIT, "strtol fail\n");
	else
		wapp->afc_mode = (u8)val;
#endif
	get_map_parameters(wapp->map, "MaxStaAllowed", value, NON_DRIVER_PARAM, sizeof(value));
	val = strtol(value, NULL, 10);
	if (val == LONG_MAX || val == LONG_MIN)
		err(DEBUG_CAT_INIT, "strtol fail\n");
	else
		wapp->map->max_client_cnt = (u16)val;

	if (wapp->map->max_client_cnt <= 0)
		wapp->map->max_client_cnt = MAX_NUM_OF_CLIENT;
	wapp->map->send_buffer = WAPP_EVT_SIZE;
	wapp->map_wapp_buffer_size = WAPP_EVT_SIZE;
	wapp->map_wapp_buffer = os_malloc(wapp->map_wapp_buffer_size);
	if (!wapp->map_wapp_buffer) {
		err(DEBUG_CAT_MISC, "alloc map_wapp_buffer fail; size=%d\n",
			wapp->map_wapp_buffer_size);
#ifdef QOS_R1
		wapp_drv_qos_deinit(wapp);
#endif
		goto error;
	}

	/*if MAP enable, create ARP socket for br & wireless interface */
	get_map_parameters(wapp->map, "MapMode", value, DRIVER_PARAM, sizeof(value));
	if (!strcmp(value, "1"))
		ret += wapp_create_arp_socket(wapp);
#endif
	if (ret) {
#ifdef QOS_R1
		wapp_drv_qos_deinit(wapp);
#endif
		goto error;
	}
	if (os_strlen(filename) == 0) {
		ret = snprintf(filename, 256, WAPP_CONF_PATH "/wapp_ap.conf");
		if (os_snprintf_error(sizeof(filename), ret)) {
			err(DEBUG_CAT_INIT, "%s %d snprintf error\n", __func__, __LINE__);
			goto error;
		}
	}
	ret = wapp_init_all_config(wapp, filename);
	if (ret) {
		err(DEBUG_CAT_INIT, "wapp_init_all_config fail; file=%s\n", filename);
		goto error0;
	}
#ifdef DPP_SUPPORT
#if defined(MAP_R3) || defined(EM_PLUS_SUPPORT)
		if (wapp_dpp_init(wapp) < 0) {
			/* if dpp_init fails means wapp->dpp is not */
			/* ok so need to exit from this */
			err(DEBUG_CAT_DPP, "failed to init dpp\n");
			goto error1;
		}
		get_map_parameters(wapp->map, "DeviceRole", value, NON_DRIVER_PARAM, sizeof(value));
		if (strcmp(value, "0") == 0 && wapp->map->TurnKeyEnable) {
			notice(DEBUG_CAT_DPP, "DPP init afterwards");
		} else {
#endif /* MAP_R3 || EM_PLUS_SUPPORT */
			wapp_dpp_config_init(wapp);
#ifdef MAP_R3
			get_map_parameters(wapp->map, "DppOnboardType", value, NON_DRIVER_PARAM, sizeof(value));
			if (!strcmp(value, "1")) {
				val = strtol(value, NULL, 10);
				if (val == LONG_MAX || val == LONG_MIN)
					err(DEBUG_CAT_INIT, "strtol fail\n");
				else
					wapp->dpp->onboarding_type = (u8)val;
			} else
				wapp->dpp->onboarding_type = 0;
		}
#endif
#endif /*DPP_SUPPORT */
#ifdef DFS_SLAVE_SUPPORT
	get_map_parameters(wapp->map, "DfsSlaveEn", value, NON_DRIVER_PARAM, sizeof(value));
	val = strtol(value, NULL, 10);
	if (val == LONG_MAX || val == LONG_MIN)
		err(DEBUG_CAT_INIT, "strtol fail\n");
	else
		DfsSlaveEn = (int)val;
	if (DfsSlaveEn > 0)
		wapp->map->DfsSlaveEn = TRUE;
	else
		wapp->map->DfsSlaveEn = FALSE;
	err(DEBUG_CAT_DFS, "[DFS-SLAVE] mapDfsSlaveEn:%d\n", wapp->map->DfsSlaveEn);
#endif /* DFS_SLAVE_SUPPORT */

#ifdef EM_PLUS_SUPPORT
	get_map_parameters(wapp->map, "MapAcsDatParam", value, NON_DRIVER_PARAM, sizeof(value));
	val = strtol(value, NULL, 10);
	if (val == LONG_MAX || val == LONG_MIN)
		err(DEBUG_CAT_INIT, "strtol fail\n");
	else
		MapAcsDatParam = (u8)val;
	if (MapAcsDatParam > 0)
		wapp->map->acs_dat_params = TRUE;
	else
		wapp->map->acs_dat_params = FALSE;
	err(DEBUG_CAT_DFS, "MapAcsDatParam:%d\n", wapp->map->acs_dat_params);
	if (!wapp->map->acs_dat_params) {
		get_map_parameters(wapp->map, "AcsChCheckTime2g", value, NON_DRIVER_PARAM, sizeof(value));
		val = strtol(value, NULL, 10);
		if (val == LONG_MAX || val == LONG_MIN)
			err(DEBUG_CAT_INIT, "strtol fail\n");
		else
			wapp->map->acs_ch_check_time_2g = (u32)val;
		if (wapp->map->acs_ch_check_time_2g == 0)
			wapp->map->acs_ch_check_time_2g = ACS_CH_CHECK_TIME;


		get_map_parameters(wapp->map, "AcsChUtilThresold2g", value, NON_DRIVER_PARAM, sizeof(value));
		val = strtol(value, NULL, 10);
		if (val == LONG_MAX || val == LONG_MIN)
			err(DEBUG_CAT_INIT, "strtol fail\n");
		else
			wapp->map->acs_ch_util_thresold_2g = (u8)val;
		if (wapp->map->acs_ch_util_thresold_2g == 0
				|| wapp->map->acs_ch_util_thresold_2g >= 100)
			wapp->map->acs_ch_util_thresold_2g = ACS_CH_UTIL_THRESOLD;

		get_map_parameters(wapp->map, "AcsScanDwellTime2g", value, NON_DRIVER_PARAM, sizeof(value));
		val = strtol(value, NULL, 10);
		if (val == LONG_MAX || val == LONG_MIN)
			err(DEBUG_CAT_INIT, "strtol fail\n");
		else
			wapp->map->acs_scan_dwell_time_2g = (u16)val;
		if (wapp->map->acs_scan_dwell_time_2g == 0)
			wapp->map->acs_scan_dwell_time_2g = ACS_SCAN_DWELL_TIME;

		get_map_parameters(wapp->map, "AcsChRestoreTime2g", value, NON_DRIVER_PARAM, sizeof(value));
		val = strtol(value, NULL, 10);
		if (val == LONG_MAX || val == LONG_MIN)
			err(DEBUG_CAT_INIT, "strtol fail\n");
		else
			wapp->map->acs_restore_dwell_time_2g = (u16)val;
		if (wapp->map->acs_restore_dwell_time_2g == 0)
			wapp->map->acs_restore_dwell_time_2g = ACS_SCAN_RESTORE_TIME;

		get_map_parameters(wapp->map, "AcsChCheckTime5g", value, NON_DRIVER_PARAM, sizeof(value));
		val = strtol(value, NULL, 10);
		if (val == LONG_MAX || val == LONG_MIN)
			err(DEBUG_CAT_INIT, "strtol fail\n");
		else
			wapp->map->acs_ch_check_time_5g = (u32)val;
		if (wapp->map->acs_ch_check_time_5g == 0)
			wapp->map->acs_ch_check_time_5g = ACS_CH_CHECK_TIME;


		get_map_parameters(wapp->map, "AcsChUtilThresold5g", value, NON_DRIVER_PARAM, sizeof(value));
		val = strtol(value, NULL, 10);
		if (val == LONG_MAX || val == LONG_MIN)
			err(DEBUG_CAT_INIT, "strtol fail\n");
		else
			wapp->map->acs_ch_util_thresold_5g = (u8)val;
		if (wapp->map->acs_ch_util_thresold_5g == 0
				|| wapp->map->acs_ch_util_thresold_5g >= 100)
			wapp->map->acs_ch_util_thresold_5g = ACS_CH_UTIL_THRESOLD;

		get_map_parameters(wapp->map, "AcsScanDwellTime5g", value, NON_DRIVER_PARAM, sizeof(value));
		val = strtol(value, NULL, 10);
		if (val == LONG_MAX || val == LONG_MIN)
			err(DEBUG_CAT_INIT, "strtol fail\n");
		else
			wapp->map->acs_scan_dwell_time_5g = (u16)val;
		if (wapp->map->acs_scan_dwell_time_5g == 0)
			wapp->map->acs_scan_dwell_time_5g = ACS_SCAN_DWELL_TIME;

		get_map_parameters(wapp->map, "AcsChRestoreTime5g", value, NON_DRIVER_PARAM, sizeof(value));
		val = strtol(value, NULL, 10);
		if (val == LONG_MAX || val == LONG_MIN)
			err(DEBUG_CAT_INIT, "strtol fail\n");
		else
			wapp->map->acs_restore_dwell_time_5g = (u16)val;
		if (wapp->map->acs_restore_dwell_time_5g == 0)
			wapp->map->acs_restore_dwell_time_5g = ACS_SCAN_RESTORE_TIME;

#ifdef MAP_6E_SUPPORT
		get_map_parameters(wapp->map, "AcsChCheckTime6g", value, NON_DRIVER_PARAM, sizeof(value));
		val = strtol(value, NULL, 10);
		if (val == LONG_MAX || val == LONG_MIN)
			err(DEBUG_CAT_INIT, "strtol fail\n");
		else
			wapp->map->acs_ch_check_time_6g = (u32)val;
		if (wapp->map->acs_ch_check_time_6g == 0)
			wapp->map->acs_ch_check_time_6g = ACS_CH_CHECK_TIME;

		get_map_parameters(wapp->map, "AcsChUtilThresold6g", value, NON_DRIVER_PARAM, sizeof(value));
		val = strtol(value, NULL, 10);
		if (val == LONG_MAX || val == LONG_MIN)
			err(DEBUG_CAT_INIT, "strtol fail\n");
		else
			wapp->map->acs_ch_util_thresold_6g = (u8)val;
		if (wapp->map->acs_ch_util_thresold_6g == 0
				|| wapp->map->acs_ch_util_thresold_6g >= 100)
			wapp->map->acs_ch_util_thresold_6g = ACS_CH_UTIL_THRESOLD;

		get_map_parameters(wapp->map, "AcsScanDwellTime6g", value, NON_DRIVER_PARAM, sizeof(value));
		val = strtol(value, NULL, 10);
		if (val == LONG_MAX || val == LONG_MIN)
			err(DEBUG_CAT_INIT, "strtol fail\n");
		else
			wapp->map->acs_scan_dwell_time_6g = (u16)val;
		if (wapp->map->acs_scan_dwell_time_6g == 0)
			wapp->map->acs_scan_dwell_time_6g = ACS_SCAN_DWELL_TIME;

		get_map_parameters(wapp->map, "AcsChRestoreTime6g", value, NON_DRIVER_PARAM, sizeof(value));
		val = strtol(value, NULL, 10);
		if (val == LONG_MAX || val == LONG_MIN)
			err(DEBUG_CAT_INIT, "strtol fail\n");
		else
			wapp->map->acs_restore_dwell_time_6g = (u16)val;
		if (wapp->map->acs_restore_dwell_time_6g == 0)
			wapp->map->acs_restore_dwell_time_6g = ACS_SCAN_RESTORE_TIME;
#endif /* MAP_6E_SUPPORT */

		notice(DEBUG_CAT_CHANNEL, "[ACS] AcsChCheckTime2g:%d\n", wapp->map->acs_ch_check_time_2g);
		notice(DEBUG_CAT_CHANNEL, "[ACS] AcsChUtilThresold2g:%d\n", wapp->map->acs_ch_util_thresold_2g);
		notice(DEBUG_CAT_CHANNEL, "[ACS] AcsScanDwellTime2g:%d\n", wapp->map->acs_scan_dwell_time_2g);
		notice(DEBUG_CAT_CHANNEL, "[ACS] AcsChRestoreTime2g:%d\n", wapp->map->acs_restore_dwell_time_2g);
		notice(DEBUG_CAT_CHANNEL, "[ACS] AcsChCheckTime5g:%d\n", wapp->map->acs_ch_check_time_5g);
		notice(DEBUG_CAT_CHANNEL, "[ACS] AcsChUtilThresold5g:%d\n", wapp->map->acs_ch_util_thresold_5g);
		notice(DEBUG_CAT_CHANNEL, "[ACS] AcsScanDwellTime5g:%d\n", wapp->map->acs_scan_dwell_time_5g);
		notice(DEBUG_CAT_CHANNEL, "[ACS] AcsChRestoreTime5g:%d\n", wapp->map->acs_restore_dwell_time_5g);
#ifdef MAP_6E_SUPPORT
		notice(DEBUG_CAT_CHANNEL, "[ACS] AcsChCheckTime6g:%d\n", wapp->map->acs_ch_check_time_6g);
		notice(DEBUG_CAT_CHANNEL, "[ACS] AcsChUtilThresold6g:%d\n", wapp->map->acs_ch_util_thresold_6g);
		notice(DEBUG_CAT_CHANNEL, "[ACS] AcsScanDwellTime6g:%d\n", wapp->map->acs_scan_dwell_time_6g);
		notice(DEBUG_CAT_CHANNEL, "[ACS] AcsChRestoreTime6g:%d\n", wapp->map->acs_restore_dwell_time_6g);
#endif /* MAP_6E_SUPPORT */
	} else {
		notice(DEBUG_CAT_CHANNEL, "[ACS] Update AcsChCheckTime:%d\n", ACS_CH_CHECK_TIME);
		wapp->map->acs_ch_check_time_2g = ACS_CH_CHECK_TIME;
		wapp->map->acs_ch_check_time_5g = ACS_CH_CHECK_TIME;
		wapp->map->acs_ch_check_time_6g = ACS_CH_CHECK_TIME;
	}
#endif /* EM_PLUS_SUPPORT */

#ifdef EPCS_SUPPORT
	wapp_epcs_init(wapp);
#endif
#ifdef CUSTOM_MLD_ADDR
	get_map_parameters(wapp->map, "CustomMLDAddr", value, NON_DRIVER_PARAM, sizeof(value));
	if (atoi(value) > 0)
		wapp->map->mld_mac.CustomMLDAddr = atoi(value);
	else
		wapp->map->mld_mac.CustomMLDAddr = 0;

	if (wapp->map->mld_mac.CustomMLDAddr)
		get_mld_mac_from_file(wapp);
#endif
#ifdef COSR_SUPPORT
	dl_list_init(&wapp->cosr_airmonitor_query_list);
	dl_list_init(&wapp->cosr_sta_mntr_list);
	dl_list_init(&wapp->cosr_airmonitor_result_list);
	wapp_query_sr_support_mode(wapp);
#endif /*COSR_SUPPORT */

#ifdef WPACTRL_SUPPORT
	ret = wdev_ap_wpactrl_init(wapp);
	if (ret != 0)
		goto error3;

	ret = wdev_sta_wpactrl_init(wapp);
#ifndef EM_PLUS_SUPPORT /* 2 */
	if (ret != 0)
		goto error4;
#endif

#endif /* WPACTRL_SUPPORT */
	if (wapp->drv_mode == WEXT) {
		ret = hotspot_set_ap_ifaces_all_ies(wapp);
		if (ret)
			goto error1;

		/* Enable hotspot feature for all interfaces */
		ret = hotspot_onoff_all(wapp, 1);
		if (ret)
			goto error1;
		hotspot_run(wapp);
		/* Disable hotspot feature for all interfaces */
		hotspot_onoff_all(wapp, 0);
	} else {
		eloop_register_signal_terminate(wapp_terminate, NULL);
		{
			char *buf = NULL;
			int len = 0;

			buf = (char *)os_zalloc(102400);
			if (buf) {
				len = dump_globe_info(wapp, buf, 102400);
				if (len > 0)
					notice(DEBUG_CAT_INIT, "dump_globe_info(len=%d)\n%s", len, buf);
				else
					err(DEBUG_CAT_INIT, "dump_globe_info fail\n");
				os_free(buf);
			} else {
				warn(DEBUG_CAT_MISC, "alloc 102400 buffer fail; can't dump_globe_info\n");
			}
		}
		eloop_run();
	}

#ifdef WPACTRL_SUPPORT
	if (eloop_sigterm == 0) {
		err(DEBUG_CAT_INIT, "wpactrl deinit!\n");
		wdev_sta_wpactrl_deinit(wapp);
#ifndef EM_PLUS_SUPPORT
error4:
#endif
		wdev_ap_wpactrl_deinit(wapp);
	} else
		debug(DEBUG_CAT_INIT, "SKIP wpactrl deinit!\n");
error3:
#endif

#ifdef EPCS_SUPPORT
	wapp_epcs_deinit(wapp);
#endif
error1:
	wapp_deinit_all_config(wapp);
error0:
	hotspot_deinit(wapp);
#ifdef MAP_SUPPORT
	map_bss_table_release(wapp->map);
#endif
#ifdef QOS_R1
	wapp_drv_qos_deinit(wapp);
#endif
error:
	log_deinit();
	exit(-1);
}
