/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#ifdef OPENWRT_SUPPORT
#include <libdatconf.h>
#endif
#include "wapp_cmm.h"
#include "driver_wext.h"
#include "interface.h"
#include "map_test.h"
#include "wps.h"
#include "dhcp_ctl.h"
#ifdef MAP_R3
#include "dpp_wdev.h"
#endif
#ifdef MAP_R3_DE
#include <sys/utsname.h>
#endif
//#define MAX_NUM_DEPENDENT_CHANNELS			4
#ifdef MAP_EHT_SUPPORT
#define MAX_NUM_DEPENDENT_CHANNELS			16
#else
#define MAX_NUM_DEPENDENT_CHANNELS			8
#endif

struct channel_operable_status_s {
	unsigned char channel_num;
	unsigned char operable_status;
	unsigned char idc_status;
};
struct channel_dependency_list_s {
	unsigned char channel_num;
	unsigned char opclass;	/* regulatory class */
	unsigned char dependent_channel_set[MAX_NUM_DEPENDENT_CHANNELS];	/* max 13 channels, use 0 as terminator */
};
static int32_t min(int32_t a, int32_t b)
{
	return ((a > b) ? b : a);
}
struct channel_operable_status_s channel_operable_status[] = {
#ifdef WIFI_MD_COEX_SUPPORT
{1, 1, 1},
{2, 1, 1},
{3, 1, 1},
{4, 1, 1},
{5, 1, 1},
{6, 1, 1},
{7, 1, 1},
{8, 1, 1},
{9, 1, 1},
{10, 1, 1},
{11, 1, 1},
{12, 1, 1},
{13, 1, 1},
{14, 1, 1},
#endif
{36, 1, 1},
{40, 1, 1},
{44, 1, 1},
{48, 1, 1},
{52, 1, 1},
{56, 1, 1},
{60, 1, 1},
{64, 1, 1},
{100, 1, 1},
{104, 1, 1},
{108, 1, 1},
{112, 1, 1},
{116, 1, 1},
{120, 1, 1},
{124, 1, 1},
{128, 1, 1},
{132, 1, 1},
{136, 1, 1},
{140, 1, 1},
{144, 1, 1},
{149, 1, 1},
{153, 1, 1},
{157, 1, 1},
{161, 1, 1},
{165, 1, 1},
{169, 1, 1},
{173, 1, 1},
{177, 1, 1},
};

struct channel_dependency_list_s channel_dependency_list[] = {
	{36,	116	,{40}},
	{40,	117	,{36}},
	{44,	116	,{48}},
	{48,	117	,{44}},
	{52,	119	,{56}},
	{56,	120	,{52}},
	{60,	119	,{64}},
	{64,	120	,{60}},
	{100,	122	,{104}},
	{104,	123	,{100}},
	{108,	122	,{112}},
	{112,	123	,{108}},
	{116,	122	,{120}},
	{120,	123	,{116}},
	{124,	122	,{128}},
	{128,	123	,{124}},
	{132,	122	,{136}},
	{136,	123	,{132}},
	{140,	122	,{144}},
	{144,	123	,{140}},
	{149,	126	,{153}},
	{153,	127	,{149}},
	{157,	126	,{161}},
	{161,	127	,{157}},
	{42 ,	128	,{36		,40		,44		,48}},
	{58 ,	128	,{52		,56		,60		,64}},
	{106,	128	,{100	,104	,108	,112}},
	{122,	128	,{116	,120	,124	,128}},
	{138,	128	,{132	,136	,140	,144}},
	{155,	128	,{149	,153	,157	,161}},
	{50,	129	,{36	,40		,44		,48		,52		,56		,60		,64}},
	{114,	129	,{100	,104	,108	,112	,116	,120	,124	,128}},
};
/* MAP Command API */
int map_cmd_show_help( struct wifi_app *wapp, const char *iface, u8 argc, char **argv);
int map_cmd_show_param( struct wifi_app *wapp, const char *iface, u8 argc, char **argv);
int map_cmd_set_bh_type( struct wifi_app *wapp, const char *iface, u8 argc, char **argv);
int map_cmd_set_alid( struct wifi_app *wapp, const char *iface, u8 argc, char **argv);
int map_cmd_send_1905( struct wifi_app *wapp, const char *iface, u8 argc, char **argv);
int map_cmd_reset_default( struct wifi_app *wapp, const char *iface, u8 argc, char **argv);
int map_cmd_set_dev_config( struct wifi_app *wapp, const char *iface, u8 argc, char **argv);
int map_cmd_trigger_wps( struct wifi_app *wapp, const char *iface, u8 argc, char **argv);
int map_cmd_get_macaddr_by_ssid_ruid( struct wifi_app *wapp, const char *iface, u8 argc, char **argv);
int map_cmd_1905_req( struct wifi_app *wapp, const char *iface, u8 argc, char **argv);
#ifdef MAP_R2
int map_cmd_ch_scan_req( struct wifi_app *wapp, const char *iface, u8 argc, char **argv);
#ifdef DFS_CAC_R2
int map_cmd_cac_status( struct wifi_app *wapp, const char *iface, u8 argc, char **argv);
#endif
#endif
int map_cmd_set_beacon_state( struct wifi_app *wapp, const char *iface, u8 argc, char **argv);
#ifdef MAP_R3
int map_cmd_dev_set_trigger( struct wifi_app *wapp, const char *iface, u8 argc, char **argv);
#endif /* MAP_R3 */
#ifdef MAP_R6
int map_cmd_get_mld_addr_by_ssid(struct wifi_app *wapp, const char *iface, u8 argc, char **argv);
#endif

/*************************************************
       map related function
**************************************************/
int hex2num(char c) {
	if (c >= '0' && c <= '9')
		return c - '0';
	if (c >= 'a' && c <= 'f')
		return c - 'a' + 10;
	if (c >= 'A' && c <= 'F')
		return c - 'A' + 10;
	return -1;
}


int hwaddr_aton(const char *txt, u8 *addr)
{
	int i;

	for (i = 0; i < 6; i++) {
		int a, b;

		a = hex2num(*txt++);
		if (a < 0)
			return -1;
		b = hex2num(*txt++);
		if (b < 0)
			return -1;
		*addr++ = (a << 4) | b;
		if (i < 5 && *txt++ != ':')
			return -1;
	}

	return 0;
}

int map_send_reset_msg(struct wifi_app *wapp)
{
	struct evt *wapp_event;
	char buf[50]= {0};
	int send_pkt_len = 0;

	wapp_event = (struct evt *)buf;
	wapp_event->type = WAPP_MAP_RESET;
	wapp_event->length = 0;

	send_pkt_len = sizeof(*wapp_event) + wapp_event->length;

	if(0 > map_1905_send(wapp, buf, send_pkt_len)) {
		notice(DEBUG_CAT_MISC, "send map reset event\n");
		return -1;
	}

	memset(buf, 0, send_pkt_len);
	return 0;
}

void map_bss_table_release(struct map_info *map)
{
	if (map->op_bss_table) {
		os_free(map->op_bss_table);
		map->op_bss_table = NULL;
	}
}

void map_bss_table_init(struct map_info *map)
{
	u32 mem_size;

	mem_size = (sizeof(wdev_bss_info) * MAX_WIFI_COUNT);
	map->op_bss_table = os_zalloc(mem_size);
	if (!map->op_bss_table)
		err(DEBUG_CAT_MISC, "alloc op_bss_table fail; size=%u\n", mem_size);
}

void map_reset_conf_sm(struct map_info *map)
{
	map->conf_ongoing_radio = NULL;
	map->conf_ongoing_radio_idx = 0;
	map->ongoing_conf_retry_times = 0;
	map->conf = MAP_CONN_STATUS_UNCONF;
}

int map_read_config_file(struct map_info *map)
{
	FILE *file;
	char buf[256], *pos, *token, *token1;
	char tmpbuf[256];
	int line = 0, i = 0;
	int ret = 0, value = 0;

	file = fopen(MAP_1905_CFG_FILE, "r");
	if (!file) {
		err(DEBUG_CAT_INIT, "open MAP cfg file (%s) fail; errno=%d(%s)\n",
			MAP_1905_CFG_FILE, errno, strerror(errno));
		return WAPP_NOT_INITIALIZED;
	}

	os_memset(buf, 0, 256);
	os_memset(tmpbuf, 0, 256);

	while (wapp_config_get_line(buf, sizeof(buf), file, &line, &pos)) {
		ret = snprintf(tmpbuf, sizeof(tmpbuf), "%s", pos);
		if (os_snprintf_error(sizeof(tmpbuf), ret))
			err(DEBUG_CAT_INIT, "snprintf error\n");

		token = strtok(pos, "=");
		if (token != NULL) {
			if (os_strcmp(token, "log_option") == 0) {
				token = strtok(NULL, "");
				if (!token) {
					err(DEBUG_CAT_INIT, "lack of log_option content\n");
					continue;
				}
				set_log_option_str(token);
			} else if (os_strcmp(token, "map_controller_alid") == 0) {
				token = strtok(NULL, "");
				if (token != NULL) {
					i = 0;
					token1 = strtok(token, ":");

					while (token1 != NULL) {
						AtoH(token1, (char *) &map->ctrl_alid[i], 1);
						i++;
					if (i >= MAC_ADDR_LEN)
						break;
					token1 = strtok(NULL, ":");
					}
				}
			} else if (os_strcmp(token, "map_agent_alid") == 0) {
				token = strtok(NULL, "");
				if (token != NULL) {
					i = 0;
					token1 = strtok(token, ":");

					while (token1 != NULL) {
						AtoH(token1, (char *) &map->agnt_alid[i], 1);
						i++;
					if (i >= MAC_ADDR_LEN)
						break;
					token1 = strtok(NULL, ":");
					}
				}
			} else if (os_strcmp(token, "bh_type") == 0) {
				token = strtok(NULL, "");
				if (token != NULL) {
					if (os_strcmp(token, "eth") == 0)
						map->bh_type = MAP_BH_ETH;
					else if (os_strcmp(token, "wifi") == 0)
						map->bh_type = MAP_BH_WIFI;
					else
						err(DEBUG_CAT_INIT, "unknown bh_type(%s)", token);
				}
			} else if (os_strcmp(token, "map_controller") == 0) {
				token = strtok(NULL, "");
				if (token != NULL) {
					value = strtol(token, NULL, 10);
					if (value < 0 || value > 255)
						map->is_ctrler = 0;
					else
						map->is_ctrler = value;
				}
			} else if (os_strcmp(token, "map_agent") == 0) {
				token = strtok(NULL, "");
				if (token != NULL) {
					value = strtol(token, NULL, 10);
					if (value < 0 || value > 255)
						map->is_agnt = 0;
					else
						map->is_agnt = value;
				}
			}  else if (os_strcmp(token, "map_root") == 0) {
				token = strtok(NULL, "");
				if (token != NULL) {
					value = strtol(token, NULL, 10);
					if (value < 0 || value > 255)
						map->is_root = 0;
					else
						map->is_root = value;
				}
			}  else if (os_strcmp(token, "br_inf") == 0) {
				token = strtok(NULL, "");
				if (token != NULL) {
					ret = snprintf(map->br_iface, sizeof(map->br_iface), "%s", token);
					if (os_snprintf_error(sizeof(map->br_iface), ret))
						err(DEBUG_CAT_INIT, "snprintf error\n");
				}
			}  else if (os_strcmp(token, "map_ver") == 0) {
				token = strtok(NULL, "");
				if (token != NULL) {
					map->map_version = DEV_TYPE_R1;
					if (os_strcmp(token, "R1") == 0)
						map->map_version = DEV_TYPE_R1;
					else if (os_strcmp(token, "R2") == 0)
						map->map_version = DEV_TYPE_R2;
#ifdef MAP_R3
					else if (os_strcmp(token, "R3") == 0)
						map->map_version = DEV_TYPE_R3;
#endif
				}
			} else if (os_strcmp(token, "radio_band") == 0) {
				u8 ra_band_idx = 0;
				token = strtok(NULL, ";");
				while (token != NULL && ra_band_idx < MAP_MAX_RADIO) {
					if (os_strcmp(token, "24G") == 0)
						map->radio_band_options[ra_band_idx] = RADIO_24G;
					else if (os_strcmp(token, "5GL") == 0)
						map->radio_band_options[ra_band_idx] = RADIO_5GL;
					else if (os_strcmp(token, "5GH") == 0)
						map->radio_band_options[ra_band_idx] = RADIO_5GH;
					else if (os_strcmp(token, "5G") == 0)
						map->radio_band_options[ra_band_idx] = RADIO_5G;
#ifdef MAP_6E_SUPPORT
					else if (os_strcmp(token, "6G") == 0)
						map->radio_band_options[ra_band_idx] = RADIO_6G;
#endif
					ra_band_idx++;
					token = strtok(NULL, ";");
				}
			}
		}
	}

	if (fclose(file) < 0)
		err(DEBUG_CAT_INIT, "fclose fail\n");

	return WAPP_SUCCESS;
}

#ifdef MAP_R2
void map_r2_cap_init(struct map_info *map)
{
	memset(&map->r2_ap_capab, 0, sizeof(struct r2_ap_cap));
	if (map->map_version > 1)
		map->r2_ap_capab.byte_counter_units = 0x01;/*Kib/Mib support*/
	else
		map->r2_ap_capab.byte_counter_units = 0x00;/*only bytes support */
	map->r2_ap_capab.max_total_num_sp_rules = 6;
	map->r2_ap_capab.max_total_num_vid = 2;
	if (map->map_version >= 2) {
		map->r2_ap_capab.sp_flag = 1;
		map->r2_ap_capab.ts_flag = 1;
	} else {
		map->r2_ap_capab.sp_flag = 0;
		map->r2_ap_capab.ts_flag = 0;
	}
	if (map->map_version >= 3)
		map->r2_ap_capab.dpp_flag = 1; /*DPP enable*/
	else
		map->r2_ap_capab.dpp_flag = 0; /*DPP disable*/
}
#endif

int map_init(struct map_info *map)
{
	u8 fk_mac[] = {0x00,0x0c,0x43,0x11,0x22,0x33};
	char value[10] = {0};
	u8 ret;
#ifdef DFS_CAC_R2
	int i = 0;
#endif

#ifndef MAP_6E_SUPPORT
	map->radio_band_options[0] = RADIO_24G;
	map->radio_band_options[1] = RADIO_5GL;
	map->radio_band_options[2] = RADIO_5GH;
#else
	map->radio_band_options[0] = RADIO_24G;
	map->radio_band_options[1] = RADIO_5G;
	map->radio_band_options[2] = RADIO_6G;
#endif

	if (map_read_config_file(map) != WAPP_SUCCESS)
		err(DEBUG_CAT_INIT, "map_read_config_file fail\n");

	map->fh_radio_supt = RADIO_24G;
	map->bh_sta_radio = RADIO_5GL;
	COPY_MAC_ADDR(map->fh_24g_bssid, fk_mac);
	COPY_MAC_ADDR(map->fh_5g1_bssid, fk_mac);
	COPY_MAC_ADDR(map->fh_5g2_bssid, fk_mac);
	map->ht_24g_supt = 1;
	map->he_24g_supt = 0;
	map->ht_5g1_supt = 1;
	map->vht_5g1_supt = 1;
	map->he_5g1_supt = 0;
	map->ht_5g2_supt = 0;
	map->vht_5g2_supt = 0;
	map->he_5g2_supt = 0;

	/*Read TurnKey Enable From Nvram*/
	get_map_parameters(map, "MapMode", value, DRIVER_PARAM, sizeof(value));
	ret = strtol(value, NULL, 10);
	if (ret)
		map->MapMode = ret;
	if (!ret)
		map->MapMode = 0;
	if(!strcmp(value,"1"))
		map->TurnKeyEnable = 1;
	else
		map->TurnKeyEnable = 0;

	map->sta_report_on_cop = TRUE;
	map->sta_report_not_cop = FALSE;
	map->rssi_steer = FALSE;
	map_bss_table_init(map);
	map_reset_conf_sm(map);
	map->conf = MAP_CONN_STATUS_UNCONF;
#ifdef MAP_R2
	map->scan_policy = 0;
	map_r2_cap_init(map);
#ifdef DFS_CAC_R2
	map->cac_capab = NULL;
	map->cac_tlv = NULL;

	os_memset((void *)&map->cac_state,0, sizeof(struct cac_state_ctrl));
	for (i=0; i < MAP_MAX_RADIO; i++)
		map->cac_state.radio_state[i].state_cac = CAC_DONE;
#endif
#endif
	dl_list_init(&map->bh_link_list);
	map->bh_link_num = 0;

	return 0;
}


int map_build_wifi_tx_link_stats(
	struct wifi_app *wapp, struct wapp_sta *sta, char *evt_buf)
{
	struct evt *map_event = NULL;
	struct tx_link_stat_rsp *tx_link = NULL;
	int send_pkt_len = 0;

	if (sta->sta_status == WAPP_STA_CONNECTED) {
		map_event = (struct evt *)evt_buf;
		map_event->type = WAPP_TX_LINK_STATISTICS;
		tx_link = (struct tx_link_stat_rsp *) map_event->buffer;
#ifdef MTK_MLO_MAP_SUPPORT
		os_memcpy(tx_link->mac_addr, sta->mac_addr, MAC_ADDR_LEN);
		os_memcpy(tx_link->bssid, sta->bssid, MAC_ADDR_LEN);
#endif
		tx_link->pkt_errs = sta->tx_packets_errors;
		tx_link->tx_pkts = sta->packets_sent;
		if (sta->is_APCLI == 1 && sta->is_sta_dev_type == 1)
			tx_link->mac_tp_cap = sta->uplink;
		else
			tx_link->mac_tp_cap = sta->downlink;

		tx_link->link_avail = sta->link_availability;
		tx_link->phyrate = 0xFFFF;
		tx_link->tx_tp = sta->tx_tp;
		map_event->length = sizeof(struct tx_link_stat_rsp);
		send_pkt_len = sizeof(struct evt) + map_event->length;
	}
	return send_pkt_len;
}


int map_build_eth_tx_link_stats(
	struct wifi_app *wapp, char *msg_buf, char *evt_buf)
{
	struct evt *map_event = NULL;
	struct tx_link_stat_rsp *tx_link = NULL;
	struct wapp_conf *conf;
	int send_pkt_len = 0;

	map_event = (struct evt *)evt_buf;
	map_event->type = WAPP_TX_LINK_STATISTICS;
	tx_link = (struct tx_link_stat_rsp *) map_event->buffer;

	dl_list_for_each(conf, &wapp->conf_list, struct wapp_conf, list) {
		debug(DEBUG_CAT_STATS, "####conf->iface(%s) iface(%s)\n", conf->iface, "ra0");
		if (os_strcmp(conf->iface, "ra0") == 0) {
			break;
		}
	}
	tx_link->pkt_errs = 0;
	tx_link->tx_pkts = 1000;
	tx_link->mac_tp_cap = conf->metrics.dl_load;
	tx_link->link_avail = 100;
	tx_link->phyrate = conf->metrics.dl_speed;
	tx_link->tx_tp = 0;
	map_event->length = sizeof(struct tx_link_stat_rsp);
	send_pkt_len = sizeof(struct evt) + map_event->length;
	return send_pkt_len;
}

int map_build_wifi_rx_link_stats(
	struct wifi_app *wapp, struct wapp_sta *sta, char *evt_buf)
{
	struct evt *map_event = NULL;
	struct rx_link_stat_rsp *rx_link = NULL;
	int send_pkt_len = 0;

	if (sta->sta_status == WAPP_STA_CONNECTED) {
		map_event = (struct evt *)evt_buf;
		map_event->type = WAPP_RX_LINK_STATISTICS;
		rx_link = (struct rx_link_stat_rsp *) map_event->buffer;
#ifdef MTK_MLO_MAP_SUPPORT
		os_memcpy(rx_link->mac_addr, sta->mac_addr, MAC_ADDR_LEN);
		os_memcpy(rx_link->bssid, sta->bssid, MAC_ADDR_LEN);
#endif
		rx_link->pkt_errs = sta->rx_packets_errors;
		rx_link->rx_pkts = sta->packets_received;
		rx_link->rssi = sta->uplink_rssi;
		rx_link->rx_tp = sta->rx_tp;
		map_event->length = sizeof(struct rx_link_stat_rsp);
		send_pkt_len = sizeof(struct evt) + map_event->length;
	}
	return send_pkt_len;

}


int map_build_eth_rx_link_stats(
	struct wifi_app *wapp, char *msg_buf, char *evt_buf)
{
	struct evt *map_event = NULL;
	struct rx_link_stat_rsp *rx_link = NULL;
	struct wapp_conf *conf;
	int send_pkt_len = 0;

	map_event = (struct evt *)evt_buf;
	map_event->type = WAPP_RX_LINK_STATISTICS;
	rx_link = (struct rx_link_stat_rsp *) map_event->buffer;

	dl_list_for_each(conf, &wapp->conf_list, struct wapp_conf, list) {
		debug(DEBUG_CAT_STATS, "####conf->iface(%s) iface(%s)\n", conf->iface, "ra0");
		if (os_strcmp(conf->iface, "ra0") == 0) {
			break;
		}
	}
	rx_link->pkt_errs = 0;
	rx_link->rx_pkts = 0;
	rx_link->rssi = 100;
	rx_link->rx_tp = 0;
	map_event->length = sizeof(struct rx_link_stat_rsp);
	send_pkt_len = sizeof(struct evt) + map_event->length;
	return send_pkt_len;
}

#ifdef MAP_R2
long int cal_power(int c)
{
	if (c == 0)
		return 1;
	return 1024 * cal_power(--c);
}
#endif

int map_get_assoc_sta_traffic_stats_len(
	struct wifi_app *wapp, u8 *radio_id)
{
	struct dl_list *dev_list;
	struct wapp_dev *wdev = NULL, *wdev_temp = NULL;
	struct ap_dev *ap = NULL;
	struct wapp_sta *sta = NULL;
	int send_pkt_len = 0;
	unsigned int sta_cnt = 0;
	unsigned char identifier[MAC_ADDR_LEN] = {0};
	int i;
	unsigned short length = 0;

	dev_list = &wapp->dev_list;
	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
		if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
			ap = (struct ap_dev *)wdev->p_dev;
			MAP_GET_RADIO_IDNFER(wdev->radio, identifier);
			/* Report only for the requested radio id */
			if (os_memcmp(identifier, radio_id, ETH_ALEN))
				continue;

			if (ap->num_of_clients == 0)
				continue;

			for (i = 0; i < CLIENT_TABLE_SIZE; i++) {
				sta = ap->client_table[i];
				if (sta && sta->sta_status == WAPP_STA_CONNECTED)
					sta_cnt++;
			}
		}
	}

	length = sizeof(struct sta_traffic_stats) + sta_cnt * sizeof(struct stat_info);
	send_pkt_len = sizeof(struct evt) + length;
	return send_pkt_len;
}
#ifdef MAP_R6
int map_get_assoc_sta_mld_traffic_stats_len(
	struct wifi_app *wapp, u8 *radio_id)
{
	struct dl_list *dev_list;
	struct wapp_dev *wdev = NULL, *wdev_temp = NULL;
	struct ap_dev *ap = NULL;
	struct wapp_sta *sta = NULL;
	int send_pkt_len = 0;
	unsigned int sta_cnt = 0;
	unsigned char identifier[MAC_ADDR_LEN] = {0};
	int i;
	int mlo_enable = 0;
	unsigned short length = 0;
	struct wdev_mlo_caps *mlo_cap;

	debug(DEBUG_CAT_STATS, "func is %s\n", __func__);

	dev_list = &wapp->dev_list;
	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
		if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
			mlo_enable = 0;
			MAP_GET_RADIO_IDNFER(wdev->radio, identifier);
			/* Report only for the requested radio id */
			if (os_memcmp(identifier, radio_id, ETH_ALEN))
				continue;

			ap = (struct ap_dev *)wdev->p_dev;

			if (ap->num_of_clients == 0)
				continue;

			/* Code added to check if MLO enable */
			mlo_cap = &ap->mlo_cap;
			for (i = 0; i < mlo_cap->RoleNum && i < MAX_ROLE_NUM; i++) {
				if (mlo_cap->MloCapPerRole[i].DeviceRole == 0
					&& (mlo_cap->MloCapPerRole[i].MloEnable == 1)) {
					mlo_enable = 1;
					break;
				}
			}

			if (!mlo_enable) {
				err(DEBUG_CAT_STATS, "%s mlo not enable for ap\n", __func__);
				continue;
			}

			for (i = 0; i < CLIENT_TABLE_SIZE; i++) {
				sta = ap->client_table[i];
				if (sta && (sta->sta_status == WAPP_STA_CONNECTED)
					&& (sta->mlo.mlo_en == 1))
					sta_cnt++;
			}
		}
	}

	length = sizeof(struct sta_mld_traffic_stats) + sta_cnt * sizeof(struct stat_mld_info);
	send_pkt_len = sizeof(struct evt) + length;
	return send_pkt_len;
}

void append_mlo_sta_traffic_stats(struct wifi_app *wapp,
				struct stat_info *stats,
				u8 *sta_mld_mac,
				u8 *radio_id)
{
	struct wapp_dev *wdev, *wdev_temp = NULL;
	unsigned char wdev_identifier[ETH_ALEN] = {0};
	struct dl_list *dev_list;
	struct ap_dev *ap = NULL;
	struct wapp_sta *sta = NULL;
	struct wdev_mlo_caps *mlo_cap;
	int mlo_enable = 0;
	int i;

	dev_list = &wapp->dev_list;

dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {

	if (wdev->radio == NULL)
		continue;

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		MAP_GET_RADIO_IDNFER(wdev->radio, wdev_identifier);
		/* Report only for the other radio id */
		if (!os_memcmp(wdev_identifier, radio_id, ETH_ALEN))
			continue;

		ap = (struct ap_dev *)wdev->p_dev;

		if (ap->num_of_clients == 0)
			continue;


		/* Code added to check if MLO enable */
		mlo_cap = &ap->mlo_cap;
		for (i = 0; i < mlo_cap->RoleNum && i < MAX_ROLE_NUM; i++) {
			if (mlo_cap->MloCapPerRole[i].DeviceRole == 0
				&& mlo_cap->MloCapPerRole[i].MloEnable == 1) {
				mlo_enable = 1;
				break;
			}
		}

		if (!mlo_enable) {
			err(DEBUG_CAT_STATS, "%s mlo not enable for ap\n", __func__);
			continue;
		}

		for (i = 0; i < CLIENT_TABLE_SIZE; i++) {
			sta = ap->client_table[i];
			if (sta && (sta->sta_status == WAPP_STA_CONNECTED)
				&& (sta->mlo.mlo_en == 1)
				&& (!os_memcmp(sta->mlo.mld_info.addr, sta_mld_mac, ETH_ALEN))) {
				COPY_MAC_ADDR(stats->mac, sta->mlo.mld_info.addr);
				stats->bytes_sent += sta->bytes_sent;
				stats->bytes_received += sta->bytes_received;
				stats->packets_sent += sta->packets_sent;
				stats->packets_received += sta->packets_received;
				stats->tx_packets_errors += sta->tx_packets_errors;
				stats->rx_packets_errors += sta->rx_packets_errors;
				stats->retransmission_count += sta->retransmission_count;
			}
		}
	}
}

}

#endif /* MAP_R6 */
int map_build_assoc_sta_traffic_stats(
	struct wifi_app *wapp, char *evt_buf, u8 *radio_id)
{
	struct dl_list *dev_list;
	struct wapp_dev *wdev = NULL, *wdev_temp = NULL;
	struct ap_dev *ap = NULL;
	struct wapp_sta *sta = NULL;
	struct evt *map_event = NULL;
	struct sta_traffic_stats *traffic_stats = NULL;
	struct stat_info * stats = NULL;
	int send_pkt_len = 0;
	int i;

	map_event = (struct evt *)evt_buf;
	map_event->type = WAPP_ALL_ASSOC_STA_TRAFFIC_STATS;
	traffic_stats = (struct sta_traffic_stats *) map_event->buffer;

	dev_list = &wapp->dev_list;
	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
		if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
			ap = (struct ap_dev *)wdev->p_dev;
			MAP_GET_RADIO_IDNFER(wdev->radio, traffic_stats->identifier);
			/* Report only for the requested radio id */
			if (os_memcmp(traffic_stats->identifier, radio_id, ETH_ALEN))
				continue;

			if (ap->num_of_clients == 0)
				continue;

			for (i = 0; i < CLIENT_TABLE_SIZE; i++) {
				sta = ap->client_table[i];
				if (sta && sta->sta_status == WAPP_STA_CONNECTED) {
					stats = &traffic_stats->stats[traffic_stats->sta_cnt];
					COPY_MAC_ADDR(stats->mac, sta->mac_addr);
					stats->bytes_sent = sta->bytes_sent;
					stats->bytes_received = sta->bytes_received;
					stats->packets_sent = sta->packets_sent;
					stats->packets_received = sta->packets_received;
					stats->tx_packets_errors = sta->tx_packets_errors;
					stats->rx_packets_errors = sta->rx_packets_errors;
					stats->retransmission_count = sta->retransmission_count;
					stats->is_APCLI = sta->is_APCLI;
#ifdef MAP_R6
					if (sta->mlo.mlo_en)
						COPY_MAC_ADDR(stats->sta_mld_mac, sta->mlo.mld_info.addr);
					else
						os_memset(stats->sta_mld_mac, 0, ETH_ALEN);
#endif
					traffic_stats->sta_cnt++;
				}
			}
		}
	}

	os_memcpy(traffic_stats->identifier, radio_id, ETH_ALEN);
	map_event->length = sizeof(struct sta_traffic_stats) + traffic_stats->sta_cnt * sizeof(struct stat_info);
	send_pkt_len = sizeof(struct evt) + map_event->length;
	return send_pkt_len;
}
#ifdef MAP_R6
int map_build_assoc_sta_mld_traffic_stats(
	struct wifi_app *wapp, char *evt_buf, u8 *radio_id)
{
	struct dl_list *dev_list;
	struct wapp_dev *wdev = NULL, *wdev_temp = NULL;
	struct ap_dev *ap = NULL;
	struct wapp_sta *sta = NULL;
	struct evt *map_event = NULL;
	struct sta_mld_traffic_stats *traffic_stats = NULL;
	struct stat_mld_info *stats = NULL;
	struct wdev_mlo_caps *mlo_cap;
	int send_pkt_len = 0;
	int mlo_enable = 0;
	int i;

	debug(DEBUG_CAT_STATS, "func is %s\n", __func__);

	map_event = (struct evt *)evt_buf;
	map_event->type = WAPP_ALL_ASSOC_STA_MLD_TRAFFIC_STATS;
	traffic_stats = (struct sta_mld_traffic_stats *) map_event->buffer;

	dev_list = &wapp->dev_list;
	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
		if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
			mlo_enable = 0;
			MAP_GET_RADIO_IDNFER(wdev->radio, traffic_stats->identifier);
			/* Report only for the requested radio id */
			if (os_memcmp(traffic_stats->identifier, radio_id, ETH_ALEN))
				continue;

			ap = (struct ap_dev *)wdev->p_dev;

			if (ap->num_of_clients == 0)
				continue;


			/* Code added to check if MLO enable */
			mlo_cap = &ap->mlo_cap;
			for (i = 0; i < mlo_cap->RoleNum && i < MAX_ROLE_NUM; i++) {
				if (mlo_cap->MloCapPerRole[i].DeviceRole == 0
					&& mlo_cap->MloCapPerRole[i].MloEnable == 1) {
					mlo_enable = 1;
					break;
				}
			}

			if (!mlo_enable) {
				err(DEBUG_CAT_STATS, "%s mlo not enable for ap\n", __func__);
				continue;
			}

			for (i = 0; i < CLIENT_TABLE_SIZE; i++) {
				sta = ap->client_table[i];
				if (sta && (sta->sta_status == WAPP_STA_CONNECTED)
					&& (sta->mlo.mlo_en == 1)) {
					stats = &traffic_stats->stats[traffic_stats->sta_cnt];
					COPY_MAC_ADDR(stats->mac, sta->mac_addr);
					stats->bytes_sent = sta->bytes_sent;
					stats->bytes_received = sta->bytes_received;
					stats->packets_sent = sta->packets_sent;
					stats->packets_received = sta->packets_received;
					stats->tx_packets_errors = sta->tx_packets_errors;
					stats->is_APCLI = sta->is_APCLI;
					traffic_stats->sta_cnt++;
				}
			}
		}
	}

	os_memcpy(traffic_stats->identifier, radio_id, ETH_ALEN);
	map_event->length = sizeof(struct sta_mld_traffic_stats) + traffic_stats->sta_cnt * sizeof(struct stat_mld_info);
	send_pkt_len = sizeof(struct evt) + map_event->length;
	return send_pkt_len;
}
#endif
#ifdef MAP_R3_WF6
int map_get_assoc_wifi6_sta_status_len(
	struct wifi_app *wapp, u8 *radio_id)
{
	struct dl_list *dev_list;
	struct wapp_dev *wdev = NULL, *wdev_temp = NULL;
	struct ap_dev *ap = NULL;
	struct wapp_sta *sta = NULL;
	int send_pkt_len = 0;
	int i = 0;
	unsigned int sta_cnt = 0;
	unsigned char identifier[MAC_ADDR_LEN] = {0};
	unsigned short length = 0;

	dev_list = &wapp->dev_list;
	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
		if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
			ap = (struct ap_dev *)wdev->p_dev;
			MAP_GET_RADIO_IDNFER(wdev->radio, identifier);
			/* Report only for the requested radio id */
			if (os_memcmp(identifier, radio_id, ETH_ALEN))
				continue;

			if (ap->num_of_clients == 0)
				continue;

			for (i = 0; i < CLIENT_TABLE_SIZE; i++) {
				sta = ap->client_table[i];
				if (sta && sta->sta_status == WAPP_STA_CONNECTED)
					sta_cnt++;
			}
		}
	}

	length = sizeof(struct assoc_wifi6_sta_status) + sta_cnt * sizeof(struct assoc_wifi6_sta_status_tlv);
	send_pkt_len = sizeof(struct evt) + length;
	return send_pkt_len;
}

int map_build_assoc_wifi6_sta_status(
	struct wifi_app *wapp, char *evt_buf, u8 *radio_id)
{
	struct dl_list *dev_list;
	struct wapp_dev *wdev = NULL, *wdev_temp = NULL;
	struct ap_dev *ap = NULL;
	struct wapp_sta *sta = NULL;
	struct evt *map_event = NULL;
	struct assoc_wifi6_sta_status *wf6_sta = NULL;
	struct assoc_wifi6_sta_status_tlv *wf6_sta_tlv = NULL;
	int send_pkt_len = 0;
	int i, j;

	map_event = (struct evt *)evt_buf;
	map_event->type = WAPP_ASSOC_WIFI6_STA_STATUS;
	wf6_sta = (struct assoc_wifi6_sta_status *) map_event->buffer;

	dev_list = &wapp->dev_list;
	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
		if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
			ap = (struct ap_dev *)wdev->p_dev;
			MAP_GET_RADIO_IDNFER(wdev->radio, wf6_sta->identifier);
			/* Report only for the requested radio id */
			if (os_memcmp(wf6_sta->identifier, radio_id, ETH_ALEN))
				continue;

			if (ap->num_of_clients == 0)
				continue;

			for (i = 0; i < CLIENT_TABLE_SIZE; i++) {
				sta = ap->client_table[i];
#ifndef MAP_R6
				if (sta && sta->sta_status == WAPP_STA_CONNECTED) {
					wf6_sta_tlv = &wf6_sta->status[wf6_sta->sta_cnt];
					COPY_MAC_ADDR(wf6_sta_tlv->mac, sta->mac_addr);
					wf6_sta_tlv->tid_cnt = sta->tid_cnt;
					for (j = 0; j < MAX_TID; j++) {
						wf6_sta_tlv->status_tlv[j].tid = sta->status_tlv[j].tid;
						wf6_sta_tlv->status_tlv[j].tid_q_size = sta->status_tlv[j].tid_q_size;
					}
					wf6_sta->sta_cnt++;
				}
#else
				if ((sta && sta->sta_status == WAPP_STA_CONNECTED) &&
					((sta->mlo.mlo_en == 1 && sta->mlo.is_setup_link_entry == 1) || (sta->mlo.mlo_en != 1))) {
					wf6_sta_tlv = &wf6_sta->status[wf6_sta->sta_cnt];
					if (sta->mlo.mlo_en == 1)
						COPY_MAC_ADDR(wf6_sta_tlv->mac, sta->mlo.mld_info.addr);
					else
						COPY_MAC_ADDR(wf6_sta_tlv->mac, sta->mac_addr);
					wf6_sta_tlv->tid_cnt = sta->tid_cnt;
					for (j = 0; j < MAX_TID; j++) {
						wf6_sta_tlv->status_tlv[j].tid = sta->status_tlv[j].tid;
						wf6_sta_tlv->status_tlv[j].tid_q_size = sta->status_tlv[j].tid_q_size;
					}
					wf6_sta->sta_cnt++;
				}
#endif /* MAP_R6 */
			}
		}
	}

	os_memcpy(wf6_sta->identifier, radio_id, ETH_ALEN);
	map_event->length = sizeof(struct assoc_wifi6_sta_status) + wf6_sta->sta_cnt * sizeof(struct assoc_wifi6_sta_status_tlv);
	send_pkt_len = sizeof(struct evt) + map_event->length;
	return send_pkt_len;
}
#endif

int map_build_one_assoc_sta_traffic_stats(
	struct wifi_app *wapp, struct wapp_sta *sta, char *evt_buf)
{
	struct evt *map_event = NULL;
	struct stat_info *stats = NULL;
#ifdef MAP_R2
	unsigned char byte_cnt = 0;
#endif
	int send_pkt_len = 0;
#ifdef MAP_R2
	if (wapp->map->map_version > DEV_TYPE_R1)
		byte_cnt = wapp->map->r2_ap_capab.byte_counter_units;
#endif
	if (sta->sta_status == WAPP_STA_CONNECTED) {
		map_event = (struct evt *)evt_buf;
		map_event->type = WAPP_ONE_ASSOC_STA_TRAFFIC_STATS;
		stats = (struct stat_info *) map_event->buffer;

		COPY_MAC_ADDR(stats->mac, sta->mac_addr);
#ifdef MAP_R2
		// TODO: should depend on whether the controller is R2 or not.
		stats->bytes_sent = sta->bytes_sent/cal_power(byte_cnt);
		stats->bytes_received = sta->bytes_received/cal_power(byte_cnt);
#else
		stats->bytes_sent = sta->bytes_sent;
		stats->bytes_received = sta->bytes_received;
#endif
		stats->packets_sent = sta->packets_sent;
		stats->packets_received = sta->packets_received;
		stats->tx_packets_errors = sta->tx_packets_errors;
		stats->rx_packets_errors = sta->rx_packets_errors;
		stats->retransmission_count = sta->retransmission_count;

		map_event->length = sizeof(struct stat_info);
		send_pkt_len = sizeof(struct evt) + map_event->length;
	}

	return send_pkt_len;
}

int map_get_assoc_sta_tp_metric_len(
	struct wifi_app *wapp, u8 *radio_id)
{
	struct dl_list *dev_list;
	struct wapp_dev *wdev = NULL, *wdev_temp = NULL;
	struct ap_dev *ap = NULL;
	struct wapp_sta *sta = NULL;
	int send_pkt_len = 0;
	int i;
	unsigned int sta_cnt = 0;
	unsigned char identifier[MAC_ADDR_LEN] = {0};
	unsigned short length = 0;

	dev_list = &wapp->dev_list;
	if (!dl_list_empty(dev_list)) {
		dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
			if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
				ap = (struct ap_dev *)wdev->p_dev;
				MAP_GET_RADIO_IDNFER(wdev->radio, identifier);
				if (os_memcmp(identifier, radio_id, ETH_ALEN))
					continue;

				if (ap->num_of_clients == 0)
					continue;

				for (i = 0; i < CLIENT_TABLE_SIZE; i++) {
					sta = ap->client_table[i];
					if (sta && sta->sta_status == WAPP_STA_CONNECTED)
						sta_cnt++;
				}
			}
		}
	}

	length = sizeof(struct sta_tp_metrics) + sta_cnt * sizeof(struct tp_metrics);
	send_pkt_len = sizeof(struct evt) + length;
	return send_pkt_len;
}

int map_build_assoc_sta_tp_metric(
	struct wifi_app *wapp, char *evt_buf, u8 *radio_id)
{
	struct dl_list *dev_list;
	struct wapp_dev *wdev = NULL, *wdev_temp = NULL;
	struct ap_dev *ap = NULL;
	struct wapp_sta *sta = NULL;
	struct evt *map_event = NULL;
	struct sta_tp_metrics *tp_metrics_info = NULL;
	struct tp_metrics * tp_metric = NULL;
	int send_pkt_len = 0;
	int i;

	map_event = (struct evt *)evt_buf;
	map_event->type = WAPP_ALL_ASSOC_TP_METRICS;
	tp_metrics_info = (struct sta_tp_metrics *) map_event->buffer;

	dev_list = &wapp->dev_list;
	if (!dl_list_empty(dev_list)) {
		dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
			if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
				ap = (struct ap_dev *)wdev->p_dev;
				MAP_GET_RADIO_IDNFER(wdev->radio, tp_metrics_info->identifier);
				if (os_memcmp(tp_metrics_info->identifier, radio_id, ETH_ALEN))
					continue;

				if (ap->num_of_clients == 0)
					continue;

				for (i = 0; i < CLIENT_TABLE_SIZE; i++) {
					sta = ap->client_table[i];
					if (sta && sta->sta_status == WAPP_STA_CONNECTED) {
						tp_metric = &tp_metrics_info->info[tp_metrics_info->sta_cnt];
						COPY_MAC_ADDR(tp_metric->mac, sta->mac_addr);
						COPY_MAC_ADDR(tp_metric->bssid, sta->bssid);
						tp_metric->tx_tp = sta->tx_tp;
						tp_metric->rx_tp = sta->rx_tp;
						tp_metric->is_APCLI = sta->is_APCLI;
						tp_metrics_info->sta_cnt++;
					}
				}
			}
		}
	}

	map_event->length = sizeof(struct sta_tp_metrics) + tp_metrics_info->sta_cnt * sizeof(struct tp_metrics);
	send_pkt_len = sizeof(struct evt) + map_event->length;
	return send_pkt_len;
}

int map_get_assoc_sta_link_metric_len(
	struct wifi_app *wapp, u8 *radio_id)
{
	struct dl_list *dev_list;
	struct wapp_dev *wdev = NULL, *wdev_temp = NULL;
	struct ap_dev *ap = NULL;
	struct wapp_sta *sta = NULL;
	int send_pkt_len = 0;
	int i;
	unsigned int sta_cnt = 0;
	unsigned char identifier[MAC_ADDR_LEN] = {0};
	unsigned short length = 0;

	dev_list = &wapp->dev_list;
	if (!dl_list_empty(dev_list)) {
		dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
			if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
				ap = (struct ap_dev *)wdev->p_dev;
				MAP_GET_RADIO_IDNFER(wdev->radio, identifier);
				if (os_memcmp(identifier, radio_id, ETH_ALEN))
					continue;

				if (ap->num_of_clients == 0)
					continue;

				for (i = 0; i < CLIENT_TABLE_SIZE; i++) {
					sta = ap->client_table[i];
					if (sta && sta->sta_status == WAPP_STA_CONNECTED)
						sta_cnt++;
				}
			}
		}
	}
	length = sizeof(struct sta_link_metrics) + sta_cnt * sizeof(struct link_metrics);
	send_pkt_len = sizeof(struct evt) + length;
	return send_pkt_len;
}

int map_build_assoc_sta_link_metric(
	struct wifi_app *wapp, char *evt_buf, u8 *radio_id)
{
	struct dl_list *dev_list;
	struct wapp_dev *wdev = NULL, *wdev_temp = NULL;
	struct ap_dev *ap = NULL;
	struct wapp_sta *sta = NULL;
	struct evt *map_event = NULL;
	struct sta_link_metrics *sta_metrics = NULL;
	struct link_metrics * metric = NULL;
	struct os_time now, delta;
	int send_pkt_len = 0;
	int i;

	map_event = (struct evt *)evt_buf;
	map_event->type = WAPP_ALL_ASSOC_STA_LINK_METRICS;
	sta_metrics = (struct sta_link_metrics *) map_event->buffer;

	os_get_time(&now);

	dev_list = &wapp->dev_list;
	if (!dl_list_empty(dev_list)){
		dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
			if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
				ap = (struct ap_dev *)wdev->p_dev;
				MAP_GET_RADIO_IDNFER(wdev->radio, sta_metrics->identifier);
				if (os_memcmp(sta_metrics->identifier, radio_id, ETH_ALEN))
					continue;

				if (ap->num_of_clients == 0)
					continue;

				for (i = 0; i < CLIENT_TABLE_SIZE; i++) {
					sta = ap->client_table[i];
					if (sta && sta->sta_status == WAPP_STA_CONNECTED) {
						metric = &sta_metrics->info[sta_metrics->sta_cnt];
						COPY_MAC_ADDR(metric->mac, sta->mac_addr);
						COPY_MAC_ADDR(metric->bssid, sta->bssid);
						metric->erate_downlink = sta->downlink;
						metric->erate_uplink = sta->uplink;
						metric->rssi_uplink = sta->uplink_rssi;
						metric->is_APCLI = sta->is_APCLI;
						os_time_sub(&now, &sta->last_update_time, &delta);
						metric->time_delta = delta.sec * 1000 + delta.usec / 1000;
						sta_metrics->sta_cnt++;
					}
				}
			}
		}
	}
	map_event->length = sizeof(struct sta_link_metrics) + sta_metrics->sta_cnt * sizeof(struct link_metrics);
	send_pkt_len = sizeof(struct evt) + map_event->length;
	return send_pkt_len;
}

#ifdef MAP_R2
int map_get_assoc_sta_ext_metric_len(
	struct wifi_app *wapp, u8 *radio_id)
{
	struct dl_list *dev_list;
	struct wapp_dev *wdev = NULL, *wdev_temp = NULL;
	struct ap_dev *ap = NULL;
	struct wapp_sta *sta = NULL;
	int send_pkt_len = 0;
	int i;
	unsigned int sta_cnt = 0;
	unsigned char identifier[MAC_ADDR_LEN] = {0};
	unsigned short length = 0;

	dev_list = &wapp->dev_list;
	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
		if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
			ap = (struct ap_dev *)wdev->p_dev;
			MAP_GET_RADIO_IDNFER(wdev->radio, identifier);
			if (os_memcmp(identifier, radio_id, ETH_ALEN))
				continue;

			if (ap->num_of_clients == 0)
				continue;

			for (i = 0; i < CLIENT_TABLE_SIZE; i++) {
				sta = ap->client_table[i];
				if (sta && sta->sta_status == WAPP_STA_CONNECTED)
					sta_cnt++;
			}
		}
	}

	length = sizeof(struct ext_sta_link_metrics) + sta_cnt * sizeof(struct ext_link_metrics);
	send_pkt_len = sizeof(struct evt) + length;
	return send_pkt_len;
}

int map_build_assoc_sta_ext_metric(
	struct wifi_app *wapp, char *evt_buf, u8 *radio_id)
{
	struct dl_list *dev_list;
	struct wapp_dev *wdev = NULL, *wdev_temp = NULL;
	struct ap_dev *ap = NULL;
	struct wapp_sta *sta = NULL;
	struct evt *map_event = NULL;
	struct ext_sta_link_metrics *sta_metrics = NULL;
	struct ext_link_metrics * metric = NULL;
	int send_pkt_len = 0;
	int i;

	map_event = (struct evt *)evt_buf;
	map_event->type = WAPP_ALL_ASSOC_STA_EXTENDED_LINK_METRICS;
	sta_metrics = (struct ext_sta_link_metrics *) map_event->buffer;


	dev_list = &wapp->dev_list;
	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
		if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
			ap = (struct ap_dev *)wdev->p_dev;
			MAP_GET_RADIO_IDNFER(wdev->radio, sta_metrics->identifier);
			if (os_memcmp(sta_metrics->identifier, radio_id, ETH_ALEN))
				continue;

			if (ap->num_of_clients == 0)
				continue;

			for (i = 0; i < CLIENT_TABLE_SIZE; i++) {
				sta = ap->client_table[i];
				if (sta && sta->sta_status == WAPP_STA_CONNECTED) {
					debug(DEBUG_CAT_STATS, "WAPP_ALL_ASSOC_STA_EXTENDED_LINK_METRICS to MAPD\n");
					metric = &sta_metrics->info[sta_metrics->sta_cnt];
					COPY_MAC_ADDR(metric->mac, sta->mac_addr);
					COPY_MAC_ADDR(metric->bssid, sta->bssid);
					metric->last_data_dl_rate = sta->ext_sta_metrics.sta_info.last_data_dl_rate;
					metric->last_data_ul_rate = sta->ext_sta_metrics.sta_info.last_data_ul_rate;
					metric->utilization_rx = sta->ext_sta_metrics.sta_info.utilization_rx;
					metric->utilization_tx = sta->ext_sta_metrics.sta_info.utilization_tx;
					sta_metrics->sta_cnt++;
				}
			}
		}
	}

	map_event->length = sizeof(struct ext_sta_link_metrics) + sta_metrics->sta_cnt * sizeof(struct ext_link_metrics);
	send_pkt_len = sizeof(struct evt) + map_event->length;
	//printf("send pkt len: %d\n", send_pkt_len);
	return send_pkt_len;
}
int map_build_one_assoc_sta_ext_link_metric(
	struct wifi_app *wapp, struct wapp_sta *sta, char *evt_buf)
{
	struct evt *map_event = NULL;
	struct ext_link_metrics * metric = NULL;
	int send_pkt_len = 0;

	if (sta->sta_status == WAPP_STA_CONNECTED) {
		map_event = (struct evt *)evt_buf;
		map_event->type = WAPP_ONE_ASSOC_STA_EXTENDED_LINK_METRICS;
		metric = (struct ext_link_metrics *) map_event->buffer;
		//printf("sending one assoc info to mapd\n");
		COPY_MAC_ADDR(metric->mac, sta->mac_addr);
		COPY_MAC_ADDR(metric->bssid, sta->bssid);
		metric->last_data_dl_rate = sta->ext_sta_metrics.sta_info.last_data_dl_rate;
		metric->last_data_ul_rate = sta->ext_sta_metrics.sta_info.last_data_ul_rate;
		metric->utilization_rx = sta->ext_sta_metrics.sta_info.utilization_rx;
		metric->utilization_tx = sta->ext_sta_metrics.sta_info.utilization_tx;
		map_event->length = sizeof(struct ext_link_metrics);
		send_pkt_len = sizeof(struct evt) + map_event->length;
	}
	return send_pkt_len;
}

#endif

int map_build_one_assoc_sta_link_metric(
	struct wifi_app *wapp, struct wapp_sta *sta, char *evt_buf)
{
	struct evt *map_event = NULL;
	struct link_metrics * metric = NULL;
	struct os_time now, delta;
	int send_pkt_len = 0;

	if (sta->sta_status == WAPP_STA_CONNECTED) {
		map_event = (struct evt *)evt_buf;
		map_event->type = WAPP_ONE_ASSOC_STA_LINK_METRICS;
		metric = (struct link_metrics *) map_event->buffer;
		os_get_time(&now);

		COPY_MAC_ADDR(metric->mac, sta->mac_addr);
		COPY_MAC_ADDR(metric->bssid, sta->bssid);
		metric->erate_downlink = sta->downlink;
		metric->erate_uplink = sta->uplink;
		metric->rssi_uplink = sta->uplink_rssi;
		metric->is_APCLI = sta->is_APCLI;
		os_time_sub(&now, &sta->last_update_time, &delta);
		metric->time_delta = delta.sec * 1000 + delta.usec / 1000;
		map_event->length = sizeof(struct link_metrics);
		send_pkt_len = sizeof(struct evt) + map_event->length;
	}
	return send_pkt_len;
}


int map_build_unassoc_sta_link_metrics(
	struct wifi_app *wapp, char *msg_buf, char *evt_buf)
{
	struct unlink_metrics_query *query;
	struct evt *map_event = NULL;
	struct unlink_metrics_rsp * metric = NULL;
	struct unlink_rsp_sta *info;
	struct probe_info * probe;
	struct os_time now, delta;
	int send_pkt_len = 0;
	int i, j;

	query = (struct unlink_metrics_query *)msg_buf;
	map_event = (struct evt *)evt_buf;
	map_event->type = WAPP_UNASSOC_STA_LINK_METRICS;
	metric = (struct unlink_metrics_rsp *) map_event->buffer;
	metric->oper_class = query->oper_class;

	os_get_time(&now);

	for (i = 0; i < query->sta_num; i++) {
		probe = wapp_probe_lookup(wapp, query->sta_list + i*MAC_ADDR_LEN);
		if (probe) {
			//check channel
			for (j = 0; j < query->ch_num; j++) {
				if (probe->channel == query->ch_list[j])
					break;
			}
			if (j < query->ch_num) { //found channel
				info = &metric->info[metric->sta_num];
				COPY_MAC_ADDR(info->mac, probe->mac_addr);
				info->ch = probe->channel;
				os_time_sub(&now, &probe->last_update_time, &delta);
				info->time_delta = delta.sec * 1000 + delta.usec / 1000;
				info->uplink_rssi = probe->rssi;
				metric->sta_num++;
			}
		}
	}

	map_event->length = sizeof(struct unlink_metrics_rsp) + metric->sta_num * sizeof(struct unlink_rsp_sta);
	send_pkt_len = sizeof(struct evt) + map_event->length;
	return send_pkt_len;
}


int map_build_ap_metric(
	struct wifi_app *wapp, struct wapp_dev *wdev, struct ap_dev *ap, char *evt_buf)
{
	wdev_ap_metric *ap_metrics = NULL;
	struct evt *map_event = NULL;
	struct ap_metrics_info *metrics = NULL;
	int send_pkt_len = 0;
	int i;

	if (!wapp || !wdev || !ap)
		return WAPP_UNEXP;

	ap_metrics = &ap->ap_metrics;
	map_event = (struct evt *)evt_buf;
	map_event->type = WAPP_AP_METRICS_INFO;
	metrics = (struct ap_metrics_info *)map_event->buffer;
	COPY_MAC_ADDR(metrics->bssid, ap_metrics->bssid);
#ifndef EM_PLUS_SUPPORT
	metrics->ch_util = ap_metrics->cu;
#else
	metrics->ch_util = wdev->cu;
#endif
	metrics->assoc_sta_cnt = ap->num_of_assoc_cli;
	metrics->valid_esp_count = AC_NUM;
#ifdef MAP_R6
	metrics->mlo_ext_ap_metric.mlo_pkts_tx = ap_metrics->mlo_ext_ap_metric.mlo_pkts_tx;
	metrics->mlo_ext_ap_metric.mlo_pkts_rx = ap_metrics->mlo_ext_ap_metric.mlo_pkts_rx;
	metrics->mlo_ext_ap_metric.mlo_tx_error_count = ap_metrics->mlo_ext_ap_metric.mlo_tx_error_count;
	metrics->mlo_ext_ap_metric.mlo_bc_rx = ap_metrics->mlo_ext_ap_metric.mlo_bc_rx;
	metrics->mlo_ext_ap_metric.mlo_bc_tx = ap_metrics->mlo_ext_ap_metric.mlo_bc_tx;
	metrics->mlo_ext_ap_metric.mlo_mc_rx = ap_metrics->mlo_ext_ap_metric.mlo_mc_rx;
	metrics->mlo_ext_ap_metric.mlo_mc_tx = ap_metrics->mlo_ext_ap_metric.mlo_mc_tx;
	metrics->mlo_ext_ap_metric.mlo_uc_rx = ap_metrics->mlo_ext_ap_metric.mlo_uc_rx;
	metrics->mlo_ext_ap_metric.mlo_uc_tx = ap_metrics->mlo_ext_ap_metric.mlo_uc_tx;
#endif
#ifdef MAP_R2
	metrics->ext_ap_metric.bc_rx = ap_metrics->ext_ap_metric.bc_rx;
	metrics->ext_ap_metric.bc_tx = ap_metrics->ext_ap_metric.bc_tx;
	metrics->ext_ap_metric.mc_rx = ap_metrics->ext_ap_metric.mc_rx;
	metrics->ext_ap_metric.mc_tx = ap_metrics->ext_ap_metric.mc_tx;
	metrics->ext_ap_metric.uc_rx = ap_metrics->ext_ap_metric.uc_rx;
	metrics->ext_ap_metric.uc_tx = ap_metrics->ext_ap_metric.uc_tx;
#endif
	for (i = 0; i < AC_NUM; i++) {
		metrics->esp[i].ac = ap_metrics->ESPI_AC[i][0] & 0x03;
		metrics->esp[i].format = (ap_metrics->ESPI_AC[i][0] & 0x18) >> 3;
		metrics->esp[i].ba_win_size = (ap_metrics->ESPI_AC[i][0] & 0xe0) >> 5;
		metrics->esp[i].e_air_time_fraction = ap_metrics->ESPI_AC[i][1];
		metrics->esp[i].ppdu_dur_target = ap_metrics->ESPI_AC[i][2];
	}

	map_event->length = sizeof(struct ap_metrics_info) + metrics->valid_esp_count*sizeof(struct esp_info);
	send_pkt_len = sizeof(*map_event) + map_event->length;
	return send_pkt_len;
}
#ifdef MAP_R2

#ifdef EM_PLUS_SUPPORT
void update_wdev_cu(struct wifi_app *wapp, struct wapp_dev *wdev, wdev_radio_metric *radio_metrics)
{
	struct wapp_dev *wdev_temp = NULL, *wdev_tmp = NULL;
	struct dl_list *dev_list;
	u32 local_cu = 0;

	if (!wapp || !wdev || !radio_metrics)
		return;

	dev_list = &wapp->dev_list;

	local_cu = radio_metrics->cu_tx + radio_metrics->cu_rx +
				radio_metrics->cu_other + radio_metrics->edcca;

	dl_list_for_each_safe(wdev_temp, wdev_tmp, dev_list, struct wapp_dev, list) {
		if (wdev_temp->p_dev == NULL || !wdev_temp->radio) {
			DBGPRINT(RT_DEBUG_ERROR, "invalid input parameters\n");
			continue;
		}

		if (wdev_temp->radio->op_ch != wdev->radio->op_ch)
			continue;

		wdev_temp->cu = (local_cu > 255) ? 255 : local_cu;
	}

	debug(DEBUG_CAT_STATS, "radio_metrics cu_tx %d cu_rx %d cu_other %d edcca %d cu %d\n",
		radio_metrics->cu_tx, radio_metrics->cu_rx, radio_metrics->cu_other, radio_metrics->edcca,
		wdev->cu);

}
#endif

int map_build_radio_metric(
	struct wifi_app *wapp, wapp_event_data *event_data, char *evt_buf, u32 ifindex)
{
	wdev_radio_metric *radio_metrics = NULL;
	struct evt *map_event = NULL;
	struct radio_metrics_info *metrics = NULL;
	int send_pkt_len = 0;
	struct wapp_dev *wdev = NULL;
	u8 ra_identifier[ETH_ALEN] = {0};
	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
	if (wdev)
		MAP_GET_RADIO_IDNFER(wdev->radio,ra_identifier);

	radio_metrics = &event_data->radio_metrics;

	map_event = (struct evt *)evt_buf;
	map_event->type = WAPP_RADIO_METRICS_INFO;
	metrics = (struct radio_metrics_info *)map_event->buffer;
	metrics->cu_noise = radio_metrics->cu_noise;
	metrics->cu_tx = radio_metrics->cu_tx;
	metrics->cu_rx = radio_metrics->cu_rx;
	metrics->cu_other = radio_metrics->cu_other;
	metrics->edcca = radio_metrics->edcca;

	COPY_MAC_ADDR(metrics->ra_id, ra_identifier);
#ifdef EM_PLUS_SUPPORT
	update_wdev_cu(wapp, wdev, radio_metrics);
#endif
	debug(DEBUG_CAT_STATS,
	"idfer	=	%02x%02x%02x%02x%02x%02x\n",
	PRINT_RA_IDENTIFIER(ra_identifier)
	);


	debug(DEBUG_CAT_STATS,
	"idfer	=	%02x%02x%02x%02x%02x%02x\n",
	PRINT_RA_IDENTIFIER(metrics->ra_id)
	);
	map_event->length = sizeof(struct radio_metrics_info);
	send_pkt_len = sizeof(*map_event) + map_event->length;

	return send_pkt_len;
}
#endif

int set_ch_pref_val(
	struct wifi_app *wapp,
	wdev_chn_info *ch_info)
{
//TBD
	return PREF_SCORE_14;
}

BOOLEAN is_primary_idc_channel_operable(unsigned char channel)
{
	int i = 0;

	for (i = 0; i < ARRAY_SIZE(channel_operable_status); i++) {
		if (channel_operable_status[i].channel_num == channel)
			return channel_operable_status[i].idc_status;
	}
	return TRUE;
}

BOOLEAN is_primary_channel_operable(unsigned char channel)
{
	int i = 0;

	for (i = 0; i < sizeof(channel_operable_status)/sizeof(channel_operable_status[0]); i++) {
		if (channel_operable_status[i].channel_num == channel) {
			return channel_operable_status[i].operable_status;
		}
	}
	return TRUE;
}

void update_primary_ch_status_opclass(struct wifi_app *wapp, struct wapp_dev *wdev, unsigned char channel,
		unsigned char status, unsigned char bw, unsigned char ch)
{
	int i = 0, j = 0, k = 0;
	u8 center_channel = 0;

	for (i = 0; i < sizeof(channel_operable_status)/sizeof(channel_operable_status[0]); i++) {
		if (channel_operable_status[i].channel_num == channel) {
			channel_operable_status[i].operable_status = status;
		}
	}
	if (bw == BW_160) {
#ifdef MAP_EHT_SUPPORT
		center_channel = get_centre_freq_ch(wapp, wdev, channel, 129, wdev->HE_EXTCHA);
#else
		center_channel = get_centre_freq_ch(wapp, wdev, channel, 129, 0);
#endif
		for (i = 0; i < sizeof(channel_dependency_list)/sizeof(channel_dependency_list[0]); i++) {
			if (channel_dependency_list[i].opclass == 129 && channel_dependency_list[i].channel_num == center_channel) {
				for (k = 0; k < MAX_NUM_DEPENDENT_CHANNELS; k++) {
					for (j = 0; j < sizeof(channel_operable_status)/sizeof(channel_operable_status[0]); j++) {
						if (channel_operable_status[j].channel_num == channel_dependency_list[i].dependent_channel_set[k]) {
							channel_operable_status[j].operable_status = 0;
							break;
						}
					}
				}
				break;
			}
		}
	}
#ifdef MAP_EHT_SUPPORT
	if (bw == BW_320) {
		center_channel = get_centre_freq_ch(wapp, wdev, channel, 137, wdev->HE_EXTCHA);
		for (i = 0; i < ARRAY_SIZE(channel_dependency_list); i++) {
			if (channel_dependency_list[i].opclass == 137 && channel_dependency_list[i].channel_num == center_channel) {
				for (k = 0; k < MAX_NUM_DEPENDENT_CHANNELS; k++) {
					for (j = 0; j < ARRAY_SIZE(channel_operable_status); j++) {
					if (channel_operable_status[j].channel_num == channel_dependency_list[i].dependent_channel_set[k]) {
						channel_operable_status[j].operable_status = 0;
						break;
						}
					}
				}
				break;
			}
		}
	}
#endif
}


void update_primary_ch_status(unsigned char channel, unsigned char status)
{
	int i = 0;

	for (i = 0; i < sizeof(channel_operable_status)/sizeof(channel_operable_status[0]); i++) {
		if (channel_operable_status[i].channel_num == channel)
			channel_operable_status[i].operable_status = status;
	}
}

void update_primary_idc_ch_status(unsigned char channel, unsigned char status)
{
	int i = 0;

	for (i = 0; i < ARRAY_SIZE(channel_operable_status); i++) {
		if (channel_operable_status[i].channel_num == channel)
			channel_operable_status[i].idc_status = status;
	}
}


#ifdef STANDARD_NL_CMD
void dump_primary_ch_status(void)
{
	u8 i = 0, cnt = 0;

	cnt = ARRAY_SIZE(channel_operable_status);
	debug(DEBUG_CAT_CHANNEL, "cnt=%d\n", cnt);
	for (i = 0; i < cnt; i++) {
		notice(DEBUG_CAT_CHANNEL, "channel=%d operable=%d\n",
			channel_operable_status[i].channel_num,
			channel_operable_status[i].operable_status);
	}
}
#endif

BOOLEAN is_idc_ch_operable(unsigned char channel, unsigned char opclass)
{
	int i = 0;
	int j = 0;

	if (opclass > 129)
		return TRUE;

	if (is_primary_idc_channel_operable(channel)) {
		for (i = 0; i < ARRAY_SIZE(channel_dependency_list); i++) {
			if (channel_dependency_list[i].channel_num == channel &&
				channel_dependency_list[i].opclass == opclass) {
				for (j = 0; j < MAX_NUM_DEPENDENT_CHANNELS; j++) {
					if (!is_primary_idc_channel_operable(
						channel_dependency_list[i].dependent_channel_set[j])) {
						return FALSE;
					}
				}
				return TRUE;
			}
		}
	} else {
		return FALSE;
	}

	return TRUE;
}

BOOLEAN is_ch_operable(unsigned char channel, unsigned char opclass)
{
	int i = 0;
	int j = 0;

	if (opclass > 129)
		return TRUE;

	if (is_primary_channel_operable(channel)) {
		for (i = 0; i < sizeof(channel_dependency_list)/sizeof(channel_dependency_list[0]);
			i++) {
			if (channel_dependency_list[i].channel_num == channel &&
				channel_dependency_list[i].opclass == opclass)
			{
				for (j = 0; j < MAX_NUM_DEPENDENT_CHANNELS; j++) {
					if (!is_primary_channel_operable(
						channel_dependency_list[i].dependent_channel_set[j])) {
						return FALSE;
					}
				}
				return TRUE;
			}
		}
	} else {
		return FALSE;
	}
	return TRUE;
}

#ifdef WIFI_MD_COEX_SUPPORT
void dump_operable_channel()
{
	int i = 0;

	for (i = 0; i < sizeof(channel_operable_status)/sizeof(channel_operable_status[0]); i++) {
		notice(DEBUG_CAT_CHANNEL, "channel=%d operable=%d\n", channel_operable_status[i].channel_num,
			channel_operable_status[i].operable_status);
	}
}
#endif

unsigned char get_total_opclass_for_pref(struct wapp_dev *wdev)
{
	unsigned char i, j;
	struct ap_dev *ap = NULL;
#ifndef MAP_6E_SUPPORT
	wdev_op_class_info *op_class = NULL;
#else
	struct _wdev_op_class_info_ext *op_class = NULL;
#endif
	unsigned char channel_count = 0;
	unsigned char opclass_count = 0;

	if (!wdev) {
		warn(DEBUG_CAT_CHANNEL, "wdev is NULL.\n");
		return 0;
	}
	if (!wdev->radio) {
		warn(DEBUG_CAT_CHANNEL, "wdev->radio is NULL.\n");
		return 0;
	}

	if (!wdev->radio->radio_band) {
		debug(DEBUG_CAT_CHANNEL, "wdev->radio->radio_band is NULL.\n");
		return 0;
	}

	ap = (struct ap_dev *)wdev->p_dev;
	if (ap)
		op_class = &ap->op_class;

	if (op_class == NULL) {
		notice(DEBUG_CAT_CHANNEL, "Error! Opclass should not be NULL\n");
		return 0;
	}

	for (i = 0; i < op_class->num_of_op_class; i++) {
		channel_count = 0;
#ifdef MAP_6E_SUPPORT
		if (wdev->radio && OP_CLASS_MATCH_RADIO_CONF(*wdev->radio->radio_band, op_class->opClassInfoExt[i].op_class))
#else
		if (wdev->radio && OP_CLASS_MATCH_RADIO_CONF(*wdev->radio->radio_band, op_class->opClassInfo[i].op_class))
#endif
		{
#ifdef MAP_6E_SUPPORT
			for (j = 0; j < op_class->opClassInfoExt[i].num_of_ch; j++) {
				if (is_ch_operable(op_class->opClassInfoExt[i].ch_list[j],
					op_class->opClassInfoExt[i].op_class)) {
					channel_count++;
				}
			}
#else
			for (j = 0; j < op_class->opClassInfo[i].num_of_ch; j++) {
				if (is_ch_operable(op_class->opClassInfo[i].ch_list[j],
					op_class->opClassInfo[i].op_class)) {
					channel_count++;
				}
			}
#endif
			if (channel_count)
				opclass_count++;
		}
	}

	for (i = 0; i < op_class->num_of_op_class; i++) {
		channel_count = 0;
#ifdef MAP_6E_SUPPORT
		if (wdev->radio && OP_CLASS_MATCH_RADIO_CONF(*wdev->radio->radio_band, op_class->opClassInfoExt[i].op_class))
#else
		if (wdev->radio && OP_CLASS_MATCH_RADIO_CONF(*wdev->radio->radio_band, op_class->opClassInfo[i].op_class))
#endif
		{
#ifdef MAP_6E_SUPPORT
			for (j = 0; j < op_class->opClassInfoExt[i].num_of_ch; j++) {
				if (!is_ch_operable(op_class->opClassInfoExt[i].ch_list[j],
					op_class->opClassInfoExt[i].op_class)) {
					channel_count++;
				}
			}
#else
			for (j = 0; j < op_class->opClassInfo[i].num_of_ch; j++) {
				if (!is_ch_operable(op_class->opClassInfo[i].ch_list[j],
					op_class->opClassInfo[i].op_class)) {
					channel_count++;
				}
			}
#endif
			if (channel_count)
				opclass_count++;
		}
	}

	return opclass_count;
}

int map_build_chn_pref(
	struct wifi_app *wapp, unsigned char *addr, char *evt_buf, BOOLEAN idc_event)
{
	u8 i = 0, j = 0;
	struct wapp_dev *wdev = NULL;
	struct ap_dev *ap = NULL;
	struct evt *map_event = NULL;
	int send_pkt_len = 0;
	struct ch_prefer *ch_pref = NULL;
	struct prefer_info *op_info = NULL;
#ifndef MAP_6E_SUPPORT
	wdev_op_class_info *op_class = NULL;
#else
	struct _wdev_op_class_info_ext *op_class = NULL;
#endif
	unsigned char channel_count = 0, idc_count = 0;
	unsigned char opclass_count = 0;
#ifdef MAP_VENDOR_SUPPORT
	u8 pref_count = 0;
#endif /* MAP_VENDOR_SUPPORT */

	wdev = wapp_dev_list_lookup_by_radio(wapp, (char *)addr);
	if (!wdev) {
		err(DEBUG_CAT_CHANNEL, "%s null wdev\n", __func__);
		return 0;
	}

	if (!wdev->radio) {
		debug(DEBUG_CAT_CHANNEL, "wdev->radio is NULL.\n");
		return 0;
	}

	if (!wdev->radio->radio_band) {
		debug(DEBUG_CAT_CHANNEL, "wdev->radio->radio_ban is NULL.\n");
		return 0;
	}

	if(wdev->dev_type == WAPP_DEV_TYPE_AP) {
		ap = (struct ap_dev *)wdev->p_dev;
		op_class = &ap->op_class;

		map_event = (struct evt *)evt_buf;
		if (!map_event) {
			err(DEBUG_CAT_CHANNEL, "%s null map_event\n", __func__);
			return 0;
		}
		map_event->type = WAPP_CHANNEL_PREFERENCE;

		ch_pref = (struct ch_prefer*)  map_event->buffer;
		if (wdev->radio) {
			MAP_GET_RADIO_IDNFER(wdev->radio, ch_pref->identifier);
		}

		op_info = ch_pref->opinfo;
		for (i = 0; i < op_class->num_of_op_class; i++) {
			channel_count = 0;
#ifdef MAP_6E_SUPPORT
			if (wdev->radio && OP_CLASS_MATCH_RADIO_CONF(*wdev->radio->radio_band, op_class->opClassInfoExt[i].op_class)
#ifdef MAP_VENDOR_SUPPORT
			&& (op_class->opClassInfoExt[i].op_class != 0)
#endif /* MAP_VENDOR_SUPPORT */
			)
#else
			if (wdev->radio && OP_CLASS_MATCH_RADIO_CONF(*wdev->radio->radio_band, op_class->opClassInfo[i].op_class))
#endif
			{
#ifdef MAP_6E_SUPPORT
				for (j = 0; j < op_class->opClassInfoExt[i].num_of_ch; j++) {
					if (is_ch_operable(op_class->opClassInfoExt[i].ch_list[j],
						op_class->opClassInfoExt[i].op_class)) {
						op_info->ch_list[channel_count] =
							op_class->opClassInfoExt[i].ch_list[j];
						channel_count++;
					}
				}
#else
				for (j = 0; j < op_class->opClassInfo[i].num_of_ch; j++) {
					if (is_ch_operable(op_class->opClassInfo[i].ch_list[j],
						op_class->opClassInfo[i].op_class)) {
						op_info->ch_list[channel_count] =
							op_class->opClassInfo[i].ch_list[j];
						channel_count++;
					}
				}
#endif
				if (channel_count) {
#ifdef MAP_6E_SUPPORT
					op_info->op_class = op_class->opClassInfoExt[i].op_class;
#else
					op_info->op_class = op_class->opClassInfo[i].op_class;
#endif
					op_info->ch_num = channel_count;
					op_info->perference = PREF_SCORE_14;
					op_info->reason = 0;
					opclass_count++;
					op_info++;

				}
			}
		}

		for (i = 0; i < op_class->num_of_op_class; i++) {
			channel_count = 0;
			idc_count = 0;
#ifdef MAP_6E_SUPPORT
			if (wdev->radio && OP_CLASS_MATCH_RADIO_CONF(*wdev->radio->radio_band, op_class->opClassInfoExt[i].op_class)
#ifdef MAP_VENDOR_SUPPORT
			&& (op_class->opClassInfoExt[i].op_class != 0)
#endif /* MAP_VENDOR_SUPPORT */
			)
#else
			if (wdev->radio && OP_CLASS_MATCH_RADIO_CONF(*wdev->radio->radio_band, op_class->opClassInfo[i].op_class))
#endif
			{
#ifdef MAP_6E_SUPPORT
				for (j = 0; j < op_class->opClassInfoExt[i].num_of_ch; j++) {
					if (idc_event) {
						if (!is_idc_ch_operable(op_class->opClassInfoExt[i].ch_list[j],
							op_class->opClassInfoExt[i].op_class) &&
							!is_ch_operable(op_class->opClassInfoExt[i].ch_list[j],
							op_class->opClassInfoExt[i].op_class)) {
							op_info->ch_list[idc_count] =
								op_class->opClassInfoExt[i].ch_list[j];
							idc_count++;
						}
					} else {
						if (!is_ch_operable(op_class->opClassInfoExt[i].ch_list[j],
							op_class->opClassInfoExt[i].op_class)) {
							op_info->ch_list[channel_count] =
								op_class->opClassInfoExt[i].ch_list[j];
							channel_count++;
						}
					}
				}
#else
				for (j = 0; j < op_class->opClassInfo[i].num_of_ch; j++) {
					if (idc_event) {
						if (!is_idc_ch_operable(op_class->opClassInfo[i].ch_list[j],
							op_class->opClassInfo[i].op_class) &&
							!is_ch_operable(op_class->opClassInfo[i].ch_list[j],
							op_class->opClassInfo[i].op_class)) {
							op_info->ch_list[idc_count] =
								op_class->opClassInfo[i].ch_list[j];
							idc_count++;
						}
					} else {
						if (!is_ch_operable(op_class->opClassInfo[i].ch_list[j],
							op_class->opClassInfo[i].op_class)) {
							op_info->ch_list[channel_count] =
								op_class->opClassInfo[i].ch_list[j];
							channel_count++;
						}
					}
				}
#endif
				if ((idc_event && idc_count) || (!idc_event && channel_count)) {
#ifdef MAP_6E_SUPPORT
					op_info->op_class = op_class->opClassInfoExt[i].op_class;
#else
					op_info->op_class = op_class->opClassInfo[i].op_class;
#endif
					op_info->ch_num = idc_event ? idc_count : channel_count;
					op_info->reason = idc_event ? 0x0 : 0x7;
					op_info->perference = PREF_SCORE_0;
					opclass_count++;
					op_info++;
				}

			}
		}

#ifdef MAP_VENDOR_SUPPORT
		for (i = 0; i < op_class->num_of_op_class; i++) {
			channel_count = 0;
#ifdef MAP_6E_SUPPORT
			if (wdev->radio && OP_CLASS_MATCH_RADIO_CONF(*wdev->radio->radio_band, op_class->opClassInfoExt[i].op_class)
#ifdef MAP_VENDOR_SUPPORT
			&& (op_class->opClassInfoExt[i].op_class != 0)
#endif /* MAP_VENDOR_SUPPORT */
			)
#else
			if (wdev->radio && OP_CLASS_MATCH_RADIO_CONF(*wdev->radio->radio_band, op_class->opClassInfo[i].op_class))
#endif
			{
#ifdef MAP_6E_SUPPORT
				for (j = 0; j < op_class->opClassInfoExt[i].num_of_ch; j++) {
					if (is_ch_operable(op_class->opClassInfoExt[i].ch_list[j],
						op_class->opClassInfoExt[i].op_class)) {

					if (wdev->radio && ((*(wdev->radio->radio_band) == RADIO_24G)
#ifdef MAP_6E_SUPPORT
						|| (*(wdev->radio->radio_band) == RADIO_6G))
#endif /* MAP_6E_SUPPORT */
					) {
						ch_pref->prefer[i].ch_pref[channel_count] = 0x0e;
					} else {
						ch_pref->prefer[pref_count].ch_pref[channel_count] =
						op_class->opClassInfoExt[i].ch_pref[j];
					}
						channel_count++;
					}
				}
#endif
			if (channel_count) {
				 pref_count++;
#ifdef MAP_6E_SUPPORT
				 ch_pref->prefer[i].is_40M_bw_disable = op_class->is_40M_bw_disable;
#endif
			}
			}
		}

		for (i = 0; i < op_class->num_of_op_class; i++) {
			channel_count = 0;
#ifdef MAP_6E_SUPPORT
		if (wdev->radio && OP_CLASS_MATCH_RADIO_CONF(*wdev->radio->radio_band, op_class->opClassInfoExt[i].op_class)
#ifdef MAP_VENDOR_SUPPORT
		&& (op_class->opClassInfoExt[i].op_class != 0)
#endif /* MAP_VENDOR_SUPPORT */
		)
#else
		if (wdev->radio && OP_CLASS_MATCH_RADIO_CONF(*wdev->radio->radio_band, op_class->opClassInfo[i].op_class))
#endif
		{
			for (j = 0; j < op_class->opClassInfoExt[i].num_of_ch; j++) {
				if (!is_ch_operable(op_class->opClassInfoExt[i].ch_list[j],
					op_class->opClassInfoExt[i].op_class)) {
					ch_pref->prefer[pref_count].ch_pref[channel_count] = PREF_SCORE_0;
					channel_count++;
				}
			}

			if (channel_count)
				pref_count++;
		}
		}

#endif /* MAP_VENDOR_SUPPORT */


		ch_pref->op_class_num = opclass_count;
		map_event->length = sizeof(struct ch_prefer)
								+ sizeof(struct prefer_info) * opclass_count;
		send_pkt_len = sizeof(*map_event) + map_event->length;
	}

	return send_pkt_len;
}


int map_build_ra_op_restrict(
	struct wifi_app *wapp, unsigned char *addr, char *evt_buf)
{
	u8 i = 0, j = 0;
	struct wapp_dev *wdev = NULL;
	struct ap_dev *ap = NULL;
	struct evt *map_event = NULL;
	int send_pkt_len = 0;
	struct restriction *rest = NULL;
	struct restrict_info *opinfo = NULL;
#ifdef MAP_6E_SUPPORT
	struct _wdev_op_class_info_ext *op_class = NULL;
#else
	wdev_op_class_info *op_class = NULL;
#endif

	wdev = wapp_dev_list_lookup_by_radio(wapp, (char *)addr);
	if (!wdev) {
		err(DEBUG_CAT_CHANNEL, "%s null wdev\n", __func__);
		return 0;
	}

	if(wdev->dev_type == WAPP_DEV_TYPE_AP) {
		ap = (struct ap_dev *)wdev->p_dev;
		op_class = &ap->op_class;

		map_event = (struct evt *)evt_buf;
		if (!map_event) {
			err(DEBUG_CAT_CAP, "%s null map_event\n", __func__);
			return 0;
		}
		map_event->type = WAPP_RADIO_OPERATION_RESTRICTION;
		map_event->length = sizeof(struct restriction)
							+ (op_class->num_of_op_class * sizeof(struct restrict_info));

		rest = (struct restriction *) map_event->buffer;
		if (wdev->radio) {
			MAP_GET_RADIO_IDNFER(wdev->radio, rest->identifier);
		}
		rest->op_class_num = op_class->num_of_op_class;

		opinfo = rest->opinfo;
#ifdef MAP_6E_SUPPORT
		for (i = 0; i < op_class->num_of_op_class; i++) {
			opinfo->op_class = op_class->opClassInfoExt[i].op_class;
			opinfo->ch_num = op_class->opClassInfoExt[i].num_of_ch;
			for (j = 0; j < opinfo->ch_num; j++) {
				opinfo->ch_list[j] = op_class->opClassInfoExt[i].ch_list[j];
				opinfo->fre_separation[j] = 0;
			}
			opinfo++;
		}
#else
		for(i = 0; i < op_class->num_of_op_class; i++) {
			opinfo->op_class = op_class->opClassInfo[i].op_class;
			opinfo->ch_num = op_class->opClassInfo[i].num_of_ch;
			for(j = 0; j < opinfo->ch_num; j++) {
				opinfo->ch_list[j] = op_class->opClassInfo[i].ch_list[j];
				opinfo->fre_separation[j] = 0;
			}
			opinfo++;
		}
#endif
	send_pkt_len = sizeof(*map_event) + map_event->length;
	}


	return send_pkt_len;
}

int map_build_ap_op_bss(
	struct wifi_app *wapp, unsigned char *addr, char *evt_buf)
{
	int i = 0;
	struct wapp_dev *wdev = NULL, *wdev_temp = NULL;
	struct evt *map_event = NULL;
#ifdef MAP_R6
	struct map_info *map = NULL;
#endif
	int send_pkt_len = 0;

	struct oper_bss_cap *op_bss_cap = NULL;
	struct op_bss_cap *cap = NULL;
	unsigned char wdev_identifier[ETH_ALEN];
	struct dl_list *dev_list;

	dev_list = &wapp->dev_list;

	map_event = (struct evt *)evt_buf;
	map_event->type = WAPP_OPERBSS_REPORT;
	op_bss_cap = (struct oper_bss_cap *) map_event->buffer;

	os_memcpy(op_bss_cap->identifier, addr, ETH_ALEN);
	cap = op_bss_cap->cap;

#ifdef MAP_R6
	map = wapp->map;
#endif

#ifdef MAP_R6
	if (wapp->mlo_bss_present == TRUE) {
		dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
			struct _wdev_mlo_info mlo_info;

			if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
				if (wapp->set_wireless_setting == FALSE) {
					notice(DEBUG_CAT_MLO, "continue\n");
					continue;
				}
				wapp_get_mlo_info(wapp, (char *)wdev->ifname,
							(char *)&mlo_info, sizeof(struct  _wdev_mlo_info));
				struct ap_dev *ap = (struct ap_dev *)wdev->p_dev;

				debug(DEBUG_CAT_MLO, "wdev->ifname = %s mld_idx = %d\n",
						wdev->ifname, ap->mlo_info.mld_idx);
				if (ap->mlo_info.mld_idx)
					continue;

#ifdef MTK_MLO_MAP_SUPPORT
				if (!WMODE_CAP_BE(wdev->wireless_mode)) {
					notice(DEBUG_CAT_MLO, "not BE mode, continue\n");
					continue;
				}
#endif

				/* it indicate wdev not of any group so do bss stop
				 * this case may come after reboot apmld renew and reboot controller
				 */
				if (wapp->map->MapMode != TURNKEY_MODE && ap->ap_mld_ra_id_check == 1) {
					err(DEBUG_CAT_MISC, "FIX for R6 Cert 4.3.5_BHWIFI TC\n");
					continue;
				}

				ap->isActive = WAPP_BSS_STOP;

#ifdef WPACTRL_SUPPORT
				if (wapp->drv_ops->drv_send_ap_intf_stop) {
					err(DEBUG_CAT_MISC, "drv_send_ap_intf_stop for ifname  = %s\n", wdev->ifname);
					wapp->drv_ops->drv_send_ap_intf_stop(wapp->drv_data, wdev->ifname);
				}
#endif /* WPACTRL_SUPPORT */
			}
		}
	}
#endif /* MAP_R6 */
	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
		if (wdev->radio) {
			struct map_conf_state *conf_state = &wdev->radio->conf_state;

			if(IS_CONF_STATE(conf_state, MAP_CONF_STOP))
				continue;
#ifdef WIFI_MD_COEX_SUPPORT
			/*all bss has been stopped if no operatable channel on current radio*/
			if (!wdev->radio->operatable) {
				notice(DEBUG_CAT_MISC, "itf_mac("MACSTR")'s radio is not operatable\n",
							MAC2STR(wdev->mac_addr));
				continue;
			}
#endif
			MAP_GET_RADIO_IDNFER(wdev->radio, wdev_identifier);
			if(!os_memcmp(wdev_identifier, (char *)addr, ETH_ALEN) &&
				(wdev->dev_type == WAPP_DEV_TYPE_AP)) {
				struct ap_dev *ap = (struct ap_dev *)wdev->p_dev;

				if (ap->isActive == WAPP_BSS_START) {
#ifdef MAP_R6
					if (map->MapMode == 4 && wapp->affiliated_ap_del_renew == 1
						&& wdev->mld_affltd_ap_in_renew != 1) {
						ap->isActive = WAPP_BSS_STOP;
						os_memset(cap->oper_bss_mlo_info.mld_addr, 0, MAC_ADDR_LEN);
						notice(DEBUG_CAT_MLO,
							" bss stop marked for deleted link %s\n", wdev->ifname);
						continue;
					}
					if (wdev->mld_del_link_state == DEL_LINK_ONGOING) {
						os_memset(cap->oper_bss_mlo_info.mld_addr, 0, MAC_ADDR_LEN);
						notice(DEBUG_CAT_MLO,
							"marked %s oper bss mld as zero\n", wdev->ifname);
						continue;
					}
#endif
						if (wdev->radio->radio_band)
							op_bss_cap->band = *(wdev->radio->radio_band);
						os_memcpy(cap->bssid, wdev->mac_addr, MAC_ADDR_LEN);
						cap->ssid_len = strlen(ap->bss_info.ssid);
						cap->map_vendor_extension = ap->bss_info.map_role;
						wdev->i_am_fh_bss = (ap->bss_info.map_role & (1<<MAP_ROLE_FRONTHAUL_BSS))?1:0;
						wdev->i_am_bh_bss = (ap->bss_info.map_role & (1<<MAP_ROLE_BACKHAUL_BSS))?1:0;
						os_memcpy(cap->ssid, ap->bss_info.ssid, cap->ssid_len);
						cap->auth_mode = ap->bss_info.auth_mode;
						cap->enc_type = ap->bss_info.enc_type;
						cap->key_len = ap->bss_info.key_len;
#ifdef MTK_MLO_MAP_SUPPORT
						/* get update mlo info from driver */
						struct _wdev_mlo_info mlo_info;

						os_memset(&mlo_info, 0, sizeof(struct  _wdev_mlo_info));
						wapp_get_mlo_info(wapp, (char *)wdev->ifname,
						(char *)&mlo_info, sizeof(struct  _wdev_mlo_info));
						os_memcpy(cap->oper_bss_mlo_info.mld_addr, ap->mlo_info.mld_addr, MAC_ADDR_LEN);
						cap->oper_bss_mlo_info.mld_idx = ap->mlo_info.mld_idx;
						cap->oper_bss_mlo_info.link_id = ap->mlo_info.link_id;
						cap->oper_bss_mlo_info.ap_str_support = ap->mlo_info.ap_str_support;
						cap->oper_bss_mlo_info.ap_nstr_support = ap->mlo_info.ap_nstr_support;
						cap->oper_bss_mlo_info.ap_emlsr_support = ap->mlo_info.ap_emlsr_support;
						cap->oper_bss_mlo_info.ap_emlmr_support = ap->mlo_info.ap_emlmr_support;
#endif
						os_memcpy(cap->key, ap->bss_info.key, ap->bss_info.key_len);
						debug(DEBUG_CAT_MISC, "%s opbss(%s)\n",
							__func__, ap->bss_info.ssid);
						debug(DEBUG_CAT_MISC, "itf_mac("MACSTR")\n",
							MAC2STR(wdev->mac_addr));
						i++;
						cap++;
					}
			}
		}
	}
	op_bss_cap->oper_bss_num = i;
	map_event->length = OPER_BSS_CAP_LEN + (sizeof(struct op_bss_cap) * i);

	notice(DEBUG_CAT_MISC, "%s oper_bss_num=%d, band=%d\n", __func__, op_bss_cap->oper_bss_num, op_bss_cap->band);
	send_pkt_len = sizeof(*map_event) + map_event->length;
	return send_pkt_len;
}

unsigned char get_max_power_for_op_class(struct ap_dev *ap, unsigned char op_class)
{
	int op_num = 0;
	for (op_num = 0; op_num < ap->tx_pwr_ext.num_of_op_class; op_num++) {
		if (ap->tx_pwr_ext.tx_pwr_limit[op_num].op_class == op_class)
			return ap->tx_pwr_ext.tx_pwr_limit[op_num].max_pwr;
	}
#ifdef EM_PLUS_SUPPORT
	if (ap->ch_info.band == BAND_24G)
		return MAX_TX_POWER_2G;
	else if (ap->ch_info.band == BAND_5G)
		return MAX_TX_POWER_5G;
	else if (ap->ch_info.band == BAND_6G)
		return MAX_TX_POWER_6G;
#endif
	return 0;
}

void set_max_power_for_op_class(struct ap_dev *ap, unsigned char op_class, unsigned char power)
{
	int op_num = 0;
	for (op_num = 0; op_num < ap->tx_pwr_ext.num_of_op_class; op_num++) {
		if (ap->tx_pwr_ext.tx_pwr_limit[op_num].op_class == op_class)
			ap->tx_pwr_ext.tx_pwr_limit[op_num].max_pwr = power;
	}
	return;
}

/*
int map_build_ap_ra_basic_cap(
	struct wifi_app *wapp, unsigned char *addr, char *evt_buf)
{
	int i = 0, j = 0, k = 0, m = 0, match = 0;
	int send_pkt_len = 0;
	struct ap_dev *ap = NULL;
	struct wapp_dev *wdev = NULL;
	struct evt *map_event = NULL;
	struct ap_radio_basic_cap *apRaCap = NULL;
	struct radio_basic_cap *opcap = NULL;
#ifdef MAP_6E_SUPPORT
	struct _wdev_op_class_info_ext *op_class = NULL;
	struct opClassInfoExt *op_info = NULL;
#else
	wdev_op_class_info *op_class = NULL;
	struct opClassInfo *op_info = NULL;
#endif
	struct opclass *op = NULL;
	unsigned char num_map_op_class = 0;
	unsigned char radio_band = 0;

	map_event = (struct evt *)evt_buf;
	if (!map_event) {
		err(DEBUG_CAT_CHANNEL "null map_event\n");
		return 0;
	}

	wdev = wapp_dev_list_lookup_by_radio(wapp, (char *)addr);
	if (!wdev) {
		err(DEBUG_CAT_CHANNEL "can't find wdev by "MACSTR"\n", MAC2STR(addr));
		return 0;
	}
	if (wdev->dev_type != WAPP_DEV_TYPE_AP)
		return 0;
	ap = (struct ap_dev *)wdev->p_dev;
	if (!ap) {
		err(DEBUG_CAT_CHANNEL "ap is null for wdev-%s\n", wdev->ifname);
		return 0;
	}
	op_class = &ap->op_class;

	map_event->type = WAPP_RADIO_BASIC_CAP;
	apRaCap = (struct ap_radio_basic_cap *)map_event->buffer;
	if (wdev->radio) {
		MAP_GET_RADIO_IDNFER(wdev->radio, apRaCap->identifier);
		if (wdev->radio->radio_band)
			radio_band = *wdev->radio->radio_band;
	}
	apRaCap->max_bss_num = ap->max_num_of_bss;
	apRaCap->band = radio_band;
	apRaCap->wireless_mode = wdev->wireless_mode;
	opcap = apRaCap->opcap;
	for (i = 0; i < op_class->num_of_op_class; i++) {
#ifdef MAP_6E_SUPPORT
		op_info = &op_class->opClassInfoExt[i];
#else
		op_info = &op_class->opClassInfo[i];
#endif
		m = 0;
		op = get_opclass_item(op_info->op_class);
		if (!op) {
			err(DEBUG_CAT_CHANNEL "can't get valid opclass item by opclass-%d\n",
				op_info->op_class);
			return 0;
		}
		opcap->op_class = op_info->op_class;
		opcap->max_tx_pwr = get_max_power_for_op_class(ap, opcap->op_class);
		opcap->non_operch_num = 0;
		os_memset(opcap->non_operch_list, 0, MAX_CH_NUM);
		if (op->ch_num > op_info->num_of_ch) {
			opcap->non_operch_num = op->ch_num - op_info->num_of_ch;
			for (j = 0; j < op->ch_num; j++) {
				match = 0;
				for (k = 0; k < op_info->num_of_ch; k++) {
					if (op->ch[j] == op_info->ch_list[k]) {
						match = 1;
						break;
					}
				}
				if (!match)
					opcap->non_operch_list[m++] = op->ch[j];
			}
		}
		opcap++;
		num_map_op_class++;
	}
	map_event->length = sizeof(struct ap_radio_basic_cap)
				+ (num_map_op_class * sizeof(struct radio_basic_cap));
	apRaCap->op_class_num = num_map_op_class;
	send_pkt_len = sizeof(*map_event) + map_event->length;

	return send_pkt_len;
}
*/

int map_build_ap_ra_basic_cap(
	struct wifi_app *wapp, unsigned char *addr, char *evt_buf)
{
	int i = 0, j = 0;
	int send_pkt_len = 0;
	struct ap_dev *ap = NULL;
	struct wapp_dev *wdev = NULL;
	struct evt *map_event = NULL;
	struct ap_radio_basic_cap *apRaCap = NULL;
	struct radio_basic_cap *opcap = NULL;
#ifdef MAP_6E_SUPPORT
	struct _wdev_op_class_info_ext *op_class = NULL;
#else
	wdev_op_class_info *op_class = NULL;
#endif
#ifndef EM_PLUS_SUPPORT
	unsigned char non_op_5GL_128[4] = {106, 122, 138, 155};
	unsigned char non_op_5GL_129[1] = {114};
	unsigned char non_op_5GH_128[2] = {42, 58};
	unsigned char non_op_5GH_129[1] = {50};
#endif
#ifdef EM_PLUS_SUPPORT
	int k = 0, m = 0, match = 0;
	struct global_oper_class *op = NULL;
#ifdef MAP_6E_SUPPORT
	struct opClassInfoExt *op_info = NULL;
#else
	struct opClassInfo *op_info = NULL;
#endif
#endif
	wdev = wapp_dev_list_lookup_by_radio(wapp, (char *)addr);
	if (!wdev) {
		err(DEBUG_CAT_CAP, "%s null wdev\n", __func__);
		return 0;
	}
	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		u8 num_map_op_class = 0;
		u8 radio_band = 0;
		ap = (struct ap_dev *)wdev->p_dev;

		op_class = &ap->op_class;
		map_event = (struct evt *)evt_buf;
		if (!map_event) {
			err(DEBUG_CAT_CAP, "%s null map_event\n", __func__);
			return 0;
		}
		map_event->type = WAPP_RADIO_BASIC_CAP;

		apRaCap = (struct ap_radio_basic_cap *)map_event->buffer;
		if (wdev->radio) {
			MAP_GET_RADIO_IDNFER(wdev->radio, apRaCap->identifier);
			if (wdev->radio->radio_band)
				radio_band = *wdev->radio->radio_band;
		}
		apRaCap->max_bss_num = ap->max_num_of_bss;
		apRaCap->band = radio_band;
		apRaCap->wireless_mode = wdev->wireless_mode;

		opcap = apRaCap->opcap;
#ifdef EM_PLUS_SUPPORT
		for (i = 0; i < op_class->num_of_op_class; i++) {
#ifdef MAP_6E_SUPPORT
			op_info = &op_class->opClassInfoExt[i];
#else
			op_info = &op_class->opClassInfo[i];
#endif
			m = 0;
			op = wapp_get_global_op_class(op_info->op_class);
			if (!op) {
				err(DEBUG_CAT_CAP, "can't get valid opclass item by opclass-%d\n",
				op_info->op_class);
				return 0;
			}
			opcap->op_class = op_info->op_class;
			opcap->max_tx_pwr = get_max_power_for_op_class(ap, opcap->op_class);
			opcap->non_operch_num = 0;
			os_memset(opcap->non_operch_list, 0, MAX_CH_NUM);
			if (op->channel_num > op_info->num_of_ch) {
				opcap->non_operch_num = op->channel_num - op_info->num_of_ch;
				for (j = 0; j < op->channel_num; j++) {
					match = 0;
				for (k = 0; k < op_info->num_of_ch; k++) {
					if (op->channel_set[j] == op_info->ch_list[k]) {
						match = 1;
						break;
					}
				}

				if (!match)
					opcap->non_operch_list[m++] = op->channel_set[j];
				}
			}
			opcap++;
			num_map_op_class++;
	}
#else
		for (i = 0; i < op_class->num_of_op_class; i++) {
#ifdef MAP_6E_SUPPORT
			if (OP_CLASS_MATCH_RADIO_CONF(radio_band, op_class->opClassInfoExt[i].op_class))
#else
			if (OP_CLASS_MATCH_RADIO_CONF(radio_band, op_class->opClassInfo[i].op_class))
#endif
			{
#ifdef MAP_6E_SUPPORT
			opcap->op_class = op_class->opClassInfoExt[i].op_class;
#else
			opcap->op_class = op_class->opClassInfo[i].op_class;
#endif
			opcap->max_tx_pwr = get_max_power_for_op_class(ap, opcap->op_class);
			if (radio_band == RADIO_5GL && opcap->op_class == 128) {
				opcap->non_operch_num = ARRAY_SIZE(non_op_5GL_128);
				if (opcap->non_operch_num <= MAX_CH_NUM) {
					for (j = 0; j < opcap->non_operch_num; j++)
						opcap->non_operch_list[j] = non_op_5GL_128[j];
				} else
					opcap->non_operch_num = 0;
			} else if (radio_band == RADIO_5GH && opcap->op_class == 128) {
				opcap->non_operch_num = ARRAY_SIZE(non_op_5GH_128);
				if (opcap->non_operch_num <= MAX_CH_NUM) {
					for (j = 0; j < opcap->non_operch_num; j++)
						opcap->non_operch_list[j] = non_op_5GH_128[j];
				} else
					 opcap->non_operch_num = 0;
			} else if (radio_band == RADIO_5GL && opcap->op_class == 129) {
				opcap->non_operch_num = ARRAY_SIZE(non_op_5GL_129);
				if (opcap->non_operch_num <= MAX_CH_NUM) {
					for (j = 0; j < opcap->non_operch_num; j++)
						opcap->non_operch_list[j] = non_op_5GL_129[j];
				} else
					opcap->non_operch_num = 0;
			} else if (radio_band == RADIO_5GH && opcap->op_class == 129) {
				opcap->non_operch_num = ARRAY_SIZE(non_op_5GH_129);
				if (opcap->non_operch_num <= MAX_CH_NUM) {
					for (j = 0; j < opcap->non_operch_num; j++)
						opcap->non_operch_list[j] = non_op_5GH_129[j];
				} else
					 opcap->non_operch_num = 0;
			} else
				opcap->non_operch_num = 0;
			opcap++;
				num_map_op_class++;
			}
		}
#endif
		map_event->length = sizeof(struct ap_radio_basic_cap)
					+ (num_map_op_class* sizeof(struct radio_basic_cap));
		apRaCap->op_class_num = num_map_op_class;
		send_pkt_len = sizeof(*map_event) + map_event->length;
	}

	return send_pkt_len;
}

int map_build_ap_cap(
	struct wifi_app *wapp, unsigned char *addr, char *evt_buf)
{
	struct evt *map_event = NULL;
	struct ap_capability *ap_cap = NULL;
	int send_pkt_len = 0;
#ifdef MAP_R6
#if 1
	struct wapp_dev *wdev = NULL;
	struct wapp_dev *sta_wdev = NULL;
	int i = 0;
	unsigned char wdev_identifier[ETH_ALEN] = {0};
	u8 ZERO_MAC_ADDR[MAC_ADDR_LEN] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
#endif
#endif

	map_event = (struct evt *)evt_buf;
	map_event->type = WAPP_AP_CAPABILITY;
	map_event->length = sizeof(struct ap_capability);
	ap_cap = (struct ap_capability *)map_event->buffer;

	if (wapp->map->sta_report_on_cop)
		ap_cap->sta_report_on_cop = 1;
	if (wapp->map->sta_report_not_cop)
		ap_cap->sta_report_not_cop = 1;
	if (wapp->map->rssi_steer)
		ap_cap->rssi_steer = 1;

#ifdef MAP_R6
#if 1
	ap_cap->bsta_reconfig = 0;
	wdev = wapp_dev_list_lookup_by_radio(wapp, (char *)addr);
	if (!wdev) {
		err(DEBUG_CAT_MLO, "%s null wdev\n", __func__);
		return 0;
	}

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		struct ap_dev *ap = (struct ap_dev *)wdev->p_dev;
		struct wdev_mlo_caps *mlo_cap;

		mlo_cap = &ap->mlo_cap;
		for (i = 0; i < mlo_cap->RoleNum && i < MAX_ROLE_NUM; i++) {
			/* Implementation for BSTA MLD TLV */
			if (mlo_cap->MloCapPerRole[i].DeviceRole == 1 && (mlo_cap->MloCapPerRole[i].MloEnable == 1)) {
				if (wdev->radio) {
					MAP_GET_RADIO_IDNFER(wdev->radio, wdev_identifier);
					if (os_memcmp(wdev_identifier, ZERO_MAC_ADDR, ETH_ALEN) != 0) {
					sta_wdev = wapp_dev_list_lookup_by_radio_for_sta(wapp, (char *)wdev_identifier);
					if (!sta_wdev) {
						err(DEBUG_CAT_MLO, "%s null wdev\n", __func__);
						continue;
					}

					if (sta_wdev->counter == 0) {
						sta_wdev->counter = 1;
						sta_wdev->apcli_mlo_enable = 1;
						ap_cap->bsta_reconfig = 1;
					}
					}
				}
			}
		}
	}
#endif
#endif

	send_pkt_len = sizeof(*map_event) + map_event->length;
	return send_pkt_len;
}

int map_build_ap_ht_cap(
	struct wifi_app *wapp, unsigned char *addr, char *evt_buf)
{
	struct wapp_dev *wdev = NULL;
	struct evt *map_event = NULL;
	struct ap_dev *ap = NULL;
	wdev_ht_cap *ht_cap = NULL;
	int send_pkt_len = 0;
	struct ap_ht_capability *map_ht_cap = NULL;

	wdev = wapp_dev_list_lookup_by_radio(wapp, (char *)addr);
	if (!wdev) {
		err(DEBUG_CAT_CAP, "%s null wdev\n", __func__);
		return 0;
	}

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		ap = (struct ap_dev *)wdev->p_dev;
		ht_cap = &ap->ht_cap;

		map_event = (struct evt *)evt_buf;
		if (!map_event) {
			err(DEBUG_CAT_CAP, "%s null map_event\n", __func__);
			return 0;
		}
		map_event->type = WAPP_AP_HT_CAPABILITY;
		map_event->length = sizeof(struct ap_ht_capability);
		map_ht_cap = (struct ap_ht_capability *)map_event->buffer;
		if (wdev->radio) {
			MAP_GET_RADIO_IDNFER(wdev->radio, map_ht_cap->identifier);
		}

		switch (ht_cap->tx_stream) {
			case 1:
				map_ht_cap->tx_stream = 0;
				break;
			case 2:
				map_ht_cap->tx_stream = 1;
				break;
			case 3:
				map_ht_cap->tx_stream = 2;
				break;
			case 4:
				map_ht_cap->tx_stream = 3;
				break;
			default:
				notice(DEBUG_CAT_CAP, "%s: - Unknown HT Tx Spatial Stream %d!!\n", __func__, ht_cap->rx_stream);
				map_ht_cap->tx_stream = 0;  //TODO, check why
				break;
		}

		switch (ht_cap->rx_stream) {
			case 1:
				map_ht_cap->rx_stream = 0;
				break;
			case 2:
				map_ht_cap->rx_stream = 1;
				break;
			case 3:
				map_ht_cap->rx_stream = 2;
				break;
			case 4:
				map_ht_cap->rx_stream = 3;
				break;
			default:
				notice(DEBUG_CAT_CAP, "%s: - Unknown HT Rx Spatial Stream!! %d\n", __func__, ht_cap->rx_stream);
				map_ht_cap->rx_stream = 0;  //TODO, check why
				break;
		}

		map_ht_cap->sgi_20 = (ht_cap->sgi_20) ? 1 : 0;
		map_ht_cap->sgi_40 = (ht_cap->sgi_40) ? 1 : 0;
		map_ht_cap->ht_40 = (ht_cap->ht_40) ? 1 : 0;
	}
	if (map_event)
		send_pkt_len = sizeof(*map_event) + map_event->length;

	return send_pkt_len;
}


int map_build_ap_vht_cap(
	struct wifi_app *wapp, unsigned char *addr, char *evt_buf)
{
	struct wapp_dev *wdev = NULL;
	struct evt *map_event = NULL;
	struct ap_dev *ap = NULL;
	wdev_vht_cap *vht_cap = NULL;
	int send_pkt_len = 0;
	struct ap_vht_capability *map_vht_cap;

	wdev = wapp_dev_list_lookup_by_radio(wapp, (char *)addr);
	if (!wdev) {
		err(DEBUG_CAT_CAP, "%s null wdev\n", __func__);
		return 0;
	}

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		ap = (struct ap_dev *)wdev->p_dev;
		vht_cap = &ap->vht_cap;

		map_event = (struct evt *)evt_buf;
		map_event->type = WAPP_AP_VHT_CAPABILITY;
		map_event->length = sizeof(struct ap_vht_capability);
		map_vht_cap = (struct ap_vht_capability *)map_event->buffer;

		if (wdev->radio) {
			MAP_GET_RADIO_IDNFER(wdev->radio, map_vht_cap->identifier);
		}
		os_memcpy(&map_vht_cap->vht_tx_mcs, vht_cap->sup_tx_mcs, sizeof(unsigned short));
		os_memcpy(&map_vht_cap->vht_rx_mcs, vht_cap->sup_rx_mcs, sizeof(unsigned short));

		switch (vht_cap->tx_stream) {
			case 1:
				map_vht_cap->tx_stream = 0;
				break;
			case 2:
				map_vht_cap->tx_stream = 1;
				break;
			case 3:
				map_vht_cap->tx_stream = 2;
				break;
			case 4:
				map_vht_cap->tx_stream = 3;
				break;
			case 5:
				map_vht_cap->tx_stream = 4;
				break;
			case 6:
				map_vht_cap->tx_stream = 5;
				break;
			case 7:
				map_vht_cap->tx_stream = 6;
				break;
			case 8:
				map_vht_cap->tx_stream = 7;
				break;
			default:
				notice(DEBUG_CAT_CAP, "%s: - Unknown VHT Tx Spatial Stream!!\n", __func__);

				break;
		}

		switch (vht_cap->rx_stream) {
			case 1:
				map_vht_cap->rx_stream = 0;
				break;
			case 2:
				map_vht_cap->rx_stream = 1;
				break;
			case 3:
				map_vht_cap->rx_stream = 2;
				break;
			case 4:
				map_vht_cap->rx_stream = 3;
				break;
			case 5:
				map_vht_cap->rx_stream = 4;
				break;
			case 6:
				map_vht_cap->rx_stream = 5;
				break;
			case 7:
				map_vht_cap->rx_stream = 6;
				break;
			case 8:
				map_vht_cap->rx_stream = 7;
				break;
			default:
				notice(DEBUG_CAT_CAP, "%s: - Unknown VHT Rx Spatial Stream!!\n", __func__);

				break;
		}

		map_vht_cap->sgi_80 = (vht_cap->sgi_80) ? 1 : 0;
		map_vht_cap->sgi_160 = (vht_cap->sgi_160) ? 1 : 0;
		map_vht_cap->vht_8080 = (vht_cap->vht_8080) ? 1 : 0;
		map_vht_cap->vht_160 = (vht_cap->vht_160) ? 1 : 0;
		map_vht_cap->su_beamformer = (vht_cap->su_bf) ? 1 : 0;
		map_vht_cap->mu_beamformer = (vht_cap->su_bf) ? 1 : 0;

		send_pkt_len = sizeof(*map_event) + map_event->length;
	}

	return send_pkt_len;
}


int map_build_assoc_cli(
	struct wifi_app *wapp,
	unsigned char *bss_addr,
	unsigned char *sta_addr,
	unsigned char stat,
	char *evt_buf,
	u16 disassoc_reason
#ifdef MAP_R6
	, unsigned char *sta_mld_addr, unsigned char *ap_mld_addr,
	u8 num_affiliated_ap, struct mlo_non_setup_info *non_setup_info,
	u8 is_setup_link_entry
#endif
	)
{
	struct wapp_dev *wdev = NULL;
	struct ap_dev *ap = NULL;
	struct wapp_sta *sta = NULL;
	struct evt *map_event = NULL;
#ifdef MAP_R6
	u8 ZERO_MLO_MAC[MAC_ADDR_LEN] = {0, 0, 0, 0, 0, 0};
#endif
	struct client_association_event *assoc_evt;
	int send_pkt_len = 0;
	u8 FF_MAC[MAC_ADDR_LEN] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};

	wdev = wapp_dev_list_lookup_by_mac_and_type(wapp, bss_addr, WAPP_DEV_TYPE_AP);
	if (!wdev) {
		notice_np(DEBUG_CAT_MISC, "%s null wdev\n", __func__);
		return 0;
	}

	ap = (struct ap_dev *)wdev->p_dev;

	sta = wdev_ap_client_list_lookup(wapp, ap, sta_addr);
	if (sta) {
		map_event = (struct evt *)evt_buf;
		map_event->type = WAPP_CLIENT_NOTIFICATION;
		assoc_evt = (struct client_association_event *)map_event->buffer;
		assoc_evt->map_assoc_evt.assoc_evt = stat;
		os_memcpy(assoc_evt->map_assoc_evt.sta_mac, sta->mac_addr, MAC_ADDR_LEN);
		os_memcpy(assoc_evt->map_assoc_evt.bssid, sta->bssid, MAC_ADDR_LEN);
		assoc_evt->map_assoc_evt.assoc_time = sta->assoc_time;
		assoc_evt->map_assoc_evt.is_APCLI = sta->is_APCLI;
		os_memcpy(&assoc_evt->cli_caps, &sta->cli_caps, sizeof(struct map_priv_cli_cap));
#ifdef MAP_R6
		if (sta_mld_addr != NULL)
			os_memcpy(assoc_evt->map_assoc_evt.sta_mld_addr, sta_mld_addr, MAC_ADDR_LEN);
		else
			os_memcpy(assoc_evt->map_assoc_evt.sta_mld_addr, ZERO_MLO_MAC, MAC_ADDR_LEN);
		if (ap_mld_addr != NULL)
			os_memcpy(assoc_evt->map_assoc_evt.ap_mld_addr, ap_mld_addr, MAC_ADDR_LEN);
		else
			os_memcpy(assoc_evt->map_assoc_evt.ap_mld_addr, ZERO_MLO_MAC, MAC_ADDR_LEN);

		if (ap_mld_addr != NULL || sta_mld_addr != NULL)
			assoc_evt->map_assoc_evt.is_setup_link_entry = is_setup_link_entry;
		else
			assoc_evt->map_assoc_evt.is_setup_link_entry = 0;

		for (int k = 0; k < 3; k++)
			os_memset(assoc_evt->map_assoc_evt.mld_non_setup_info[k].affiliated_bssid, 0, MAC_ADDR_LEN);
		assoc_evt->map_assoc_evt.num_affiliated = num_affiliated_ap;
		notice_np(DEBUG_CAT_MISC, "num affiliated is %d\n", assoc_evt->map_assoc_evt.num_affiliated);
		if (assoc_evt->map_assoc_evt.num_affiliated) {
			for (int i = 0; i < num_affiliated_ap; i++) {
				if (os_memcmp(non_setup_info[i].affiliated_ap_bssid, ZERO_MLO_MAC, MAC_ADDR_LEN) != 0)
					os_memcpy(assoc_evt->map_assoc_evt.mld_non_setup_info[i].affiliated_bssid,
						non_setup_info[i].affiliated_ap_bssid, MAC_ADDR_LEN);
			}
		}
#endif
		notice(DEBUG_CAT_MISC, "for map sta->mac_addr "MACSTR"\n", MAC2STR(sta->mac_addr));
		if (stat == STA_LEAVE) {
			map_event->length = sizeof(struct client_association_event);
			assoc_evt->map_assoc_evt.assoc_req_len = 0;
			assoc_evt->map_assoc_evt.reason = disassoc_reason;
		} else {
			map_event->length = sizeof(struct client_association_event) +  sta->assoc_req_len;
			assoc_evt->map_assoc_evt.assoc_req_len =  sta->assoc_req_len;
			os_memcpy(assoc_evt->map_assoc_evt.assoc_req, sta->assoc_req, sta->assoc_req_len);
		}
		send_pkt_len = sizeof(*map_event) + map_event->length;
	}

	if (!sta && (os_memcmp(sta_addr, FF_MAC, MAC_ADDR_LEN) == 0) && (stat == STA_LEAVE)) {
		notice_np(DEBUG_CAT_MISC, "%s NOT found sta sta_addr "MACSTR"\n", __func__, MAC2STR(sta_addr));
		map_event = (struct evt *)evt_buf;
		map_event->type = WAPP_CLIENT_NOTIFICATION;
		assoc_evt = (struct client_association_event *)map_event->buffer;
		assoc_evt->map_assoc_evt.assoc_evt = stat;
		map_event->length = sizeof(struct client_association_event);
		assoc_evt->map_assoc_evt.assoc_req_len = 0;
		assoc_evt->map_assoc_evt.reason = disassoc_reason;
		os_memcpy(assoc_evt->map_assoc_evt.sta_mac, FF_MAC, MAC_ADDR_LEN);
		os_memcpy(assoc_evt->map_assoc_evt.bssid, bss_addr, MAC_ADDR_LEN);
		assoc_evt->map_assoc_evt.is_APCLI = 0;
		send_pkt_len = sizeof(*map_event) + map_event->length;
	}
	return send_pkt_len;
}

#ifdef MAP_R2
int map_build_disassoc_stats(
	struct wifi_app *wapp,
	unsigned char *bss_addr,
	wapp_client_info *cli_info,
	char *evt_buf)
{
	struct wapp_dev *wdev = NULL;
	struct ap_dev *ap = NULL;
	struct wapp_sta *sta = NULL;
	struct evt *map_event = NULL;
	struct client_disassociation_stats_event *disassoc_stats_evt;

	int send_pkt_len = 0;

	wdev = wapp_dev_list_lookup_by_mac_and_type(wapp, bss_addr, WAPP_DEV_TYPE_AP);
	if (!wdev) {
		notice(DEBUG_CAT_STATS, "%s null wdev\n", __func__);
		return 0;
	}

	ap = (struct ap_dev *)wdev->p_dev;

	sta = wdev_ap_client_list_lookup(wapp, ap, cli_info->mac_addr);
	if (sta) {
		map_event = (struct evt *)evt_buf;
		map_event->type = WAPP_DISASSOC_STATS_EVT;
		disassoc_stats_evt = (struct client_disassociation_stats_event *)map_event->buffer;
		os_memcpy(disassoc_stats_evt->mac_addr, sta->mac_addr, ETH_ALEN);
		disassoc_stats_evt->reason_code = cli_info->disassoc_reason;
		map_event->length = sizeof(struct client_disassociation_stats_event);
		notice(DEBUG_CAT_STATS, "disassoc_stats_evt->reason_code: %d\n", disassoc_stats_evt->reason_code);
		send_pkt_len = sizeof(*map_event) + map_event->length;
	}

	return send_pkt_len;
}

#endif

int map_get_config(
	struct wifi_app *wapp,
	struct wapp_radio *ra)
{
	struct wps_get_config *conf = NULL;
	u8 num_of_dev = 0, i;
	u16 data_len = 0;
	char *data = NULL;
	struct wapp_dev *wdev, *wdev_temp = NULL;
	struct dl_list *dev_list;

	/* alid ra_id mac bss info rf band */
	data_len = sizeof(struct wps_get_config);

	dev_list = &wapp->dev_list;
	if (!dl_list_empty(dev_list)){
		dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
			if (wdev->radio == ra && wdev->dev_type == WAPP_DEV_TYPE_AP) {
				num_of_dev++;
			}
		}
	}

	data_len += (num_of_dev * sizeof(inf_info));

	data = os_zalloc(data_len);
	if (data == NULL) {
		notice(DEBUG_CAT_MISC, "%s: buf alloc failed", __func__);
		return WAPP_RESOURCE_ALLOC_FAIL;
	}

	conf = (struct wps_get_config *) data;
	conf->band = (ra->op_ch > 14) ? BAND_5G : BAND_24G;
	notice(DEBUG_CAT_MISC, BLUE("%s, for band %d.\n"), __func__, conf->band);

	conf->dev_type = WAPP_DEV_TYPE_AP;
	conf->num_of_inf = num_of_dev;
	MAP_GET_RADIO_IDNFER(ra, conf->identifier);

	i = 0;
	wdev_temp = NULL;
	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
		if (i > num_of_dev) {
			notice(DEBUG_CAT_MISC, "%s: unexpected error!", __func__);
			os_free(data);
			return WAPP_UNEXP;
		}

		if (wdev->radio == ra && wdev->dev_type == WAPP_DEV_TYPE_AP) {
			os_memcpy(conf->inf_data[i].ifname, wdev->ifname, IFNAMSIZ);
			os_memcpy(conf->inf_data[i].mac_addr, wdev->mac_addr, MAC_ADDR_LEN);
			i++;
		}
	}

	wapp_send_1905_msg(
		wapp,
		WAPP_GET_WSC_CONF,
		data_len,
		data);

	os_free(data);
	return WAPP_SUCCESS;
}
int is_wdev_radio_primary(struct wifi_app *wapp,
	struct wapp_dev *wdev_check, struct wapp_radio *ra);

int map_radio_tear_down(
	struct wifi_app *wapp,
	char *idtfer)
{
	struct wapp_dev *wdev = NULL, *wdev_temp = NULL;
	struct map_conf_state *conf_stat = NULL;
	struct dl_list *dev_list;
	struct wapp_radio *ra;
	u8 idfr[MAC_ADDR_LEN];
	int i;
	struct ap_dev * ap = NULL;
#if defined(HOSTAPD_MAP_SUPPORT) || defined(MTK_HOSTAPD_SUPPORT)
	struct wireless_setting unConf_wifi_profile = {0};
#endif
#ifdef HOSTAPD_MAP_SUPPORT
	char cmd[MAX_CMD_MSG_LEN] = {0};
#endif
#ifdef MTK_HOSTAPD_SUPPORT
	int ret = 0;
	char file_name[64] = {0};
	char value[128] = {0};
	char param[32] = {0};
#endif /* MTK_HOSTAPD_SUPPORT */
	struct wireless_setting config;
#ifdef MTK_HOSTAPD_SUPPORT
#ifdef MAP_R6
	int total_bss_num = 0;
#endif
#endif


	if (!wapp || !idtfer || !wapp->map) {
		err(DEBUG_CAT_WIFI_CONFIG, RED("%s, %u\n"), __func__, __LINE__);
		return WAPP_INVALID_ARG;
	}

	for (i = 0; i < MAX_NUM_OF_RADIO; i++) {
		ra = &wapp->radio[i];
		if (ra->adpt_id) {
			MAP_GET_RADIO_IDNFER(ra, idfr);
			if(!os_memcmp(idfr, idtfer, ETH_ALEN))
				break;
		}
	}

	if (i == MAX_NUM_OF_RADIO) {
		err(DEBUG_CAT_WIFI_CONFIG, RED("%s, %u\n"), __func__, __LINE__);
		return WAPP_INVALID_ARG;
	}

	/*update wps bh info*/
	err(DEBUG_CAT_WIFI_CONFIG, "%s disable current radio("MACSTR") in wps bh info\n",
		__func__, MAC2STR(idtfer));
	memset(&config, 0, sizeof(config));
	dev_list = &wapp->dev_list;
	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
		/*check wdev with ap cap in the same radio of wireless setting*/
		if (wdev->radio == ra && wdev->dev_type == WAPP_DEV_TYPE_AP) {
			ap = (struct ap_dev *)wdev->p_dev;
			if (ap->bss_info.map_role & BIT_BH_BSS) {
				os_memcpy(config.mac_addr, ap->bss_info.if_addr, MAC_ADDR_LEN);
				os_memcpy(config.Ssid, ap->bss_info.ssid, ap->bss_info.SsidLen);
				if (ap->bss_info.SsidLen <= 32)
					config.Ssid[ap->bss_info.SsidLen] = '\0';
				else
					config.Ssid[32] = '\0';
				config.AuthMode = ap->bss_info.auth_mode;
				config.EncrypType = ap->bss_info.enc_type;
				os_memcpy(config.WPAKey, ap->bss_info.key, ap->bss_info.key_len);
				if (ap->bss_info.key_len <= 64)
					config.WPAKey[ap->bss_info.key_len] = '\0';
				else
					config.WPAKey[64] = '\0';
				config.map_vendor_extension = BIT_TEAR_DOWN;
				config.hidden_ssid = ap->bss_info.hidden_ssid;
				err(DEBUG_CAT_WIFI_CONFIG, "%s ssid(%s) key(%s)\n",
					__func__, config.Ssid, config.WPAKey);
#ifndef MTK_HOSTAPD_SUPPORT
				set_bh_wsc_profile(wapp, &config);
#endif
				break;
			}
		}
	}

	dev_list = &wapp->dev_list;
	wdev_temp = NULL;
	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
		if (wdev->radio == ra && wdev->dev_type == WAPP_DEV_TYPE_AP) {
			ap = (struct ap_dev *)wdev->p_dev;
#ifdef MTK_HOSTAPD_SUPPORT
			if (ap->isActive == WAPP_BSS_STOP) {
				err(DEBUG_CAT_WIFI_CONFIG, "%s BSS is already stopped no need update\n", __func__);
				continue;
			}
#endif /* MTK_HOSTAPD_SUPPORT */
			ap->isActive = WAPP_BSS_STOP;
			wdev_set_ssid(wapp, wdev, "MAP-UNCONF");
#ifndef MTK_HOSTAPD_SUPPORT
			wapp_set_bss_stop(wapp, wdev->ifname);
#endif /* MTK_HOSTAPD_SUPPORT */
#if defined(HOSTAPD_MAP_SUPPORT) || defined(MTK_HOSTAPD_SUPPORT)
			os_strlcpy((char *)unConf_wifi_profile.Ssid, "MAP-UNCONF", sizeof("MAP-UNCONF"));
#ifdef MTK_HOSTAPD_SUPPORT
			/*
			 * Write the BSS configuration to hostapd.conf map file
			 * setting dev role as per ap capability
			 */
			unConf_wifi_profile.map_vendor_extension = ap->bss_info.map_role;
			os_memcpy(unConf_wifi_profile.WPAKey, "12345678", os_strlen("12345678"));
			unConf_wifi_profile.AuthMode = WPS_AUTH_WPA2PSK;

			ret = wdev_set_hapd_wifi_profile(wapp, wdev, &unConf_wifi_profile);
			if (ret != 0) {
				err(DEBUG_CAT_WIFI_CONFIG, "%s wdev_set_hapd_wifi_profile failure\n", __func__);
				continue;
			}

#else
			wapp_set_hapd_wifi_profile(wapp, wdev, &unConf_wifi_profile, 0, FALSE);
#endif /* MTK_HOSTAPD_SUPPORT */
#ifndef MTK_HOSTAPD_SUPPORT
			/*Bringdown hostapd for this interface*/
			memset(cmd, 0, sizeof(cmd));
			os_snprintf(cmd, sizeof(cmd), "hostapd_cli -i%s disable", wdev->ifname);
	if (system(cmd) == -1)
		err(DEBUG_CAT_WIFI_CONFIG, "[%s] (%d): system() call return value is -1\n", __func__, __LINE__);
#endif /* MTK_HOSTAPD_SUPPORT */
#endif /* HOSTAPD_MAP_SUPPORT || MTK_HOSTAPD_SUPPORT */
			debug(DEBUG_CAT_WIFI_CONFIG, "%s bss stop %s\n", __func__, wdev->ifname);
		}
	}

#ifdef MTK_HOSTAPD_SUPPORT
#ifdef MAP_R6
	dl_list_for_each(wdev, dev_list, struct wapp_dev, list) {
		if (wdev->radio == ra && wdev->dev_type == WAPP_DEV_TYPE_AP) {
			total_bss_num++;
		}
	}
#endif
#endif
#ifdef MTK_HOSTAPD_SUPPORT
	dl_list_for_each(wdev, dev_list, struct wapp_dev, list) {
		if (wdev->radio == ra && wdev->dev_type == WAPP_DEV_TYPE_AP) {
			/*Bringdown hostapd for this interface after all interface update*/
#ifdef MAP_R6
			total_bss_num--;
			/*if 0 means it is the last bss on this radio*/
			if (total_bss_num == 0) {
				wapp_set_no_bcn(wapp, wdev, 1);
				notice(DEBUG_CAT_CAP, "Sending no beacon to itf: %s\n", wdev->ifname);
			}
#endif
			if (wapp->drv_ops->drv_send_ap_intf_stop)
				wapp->drv_ops->drv_send_ap_intf_stop(wapp->drv_data,  wdev->ifname);

			/* Reading the 1905 cfg file for updating the cont alid */
			ret = os_snprintf(file_name, sizeof(file_name), MAP_1905_CFG_FILE);
			if (os_snprintf_error(sizeof(file_name), ret))
				err(DEBUG_CAT_WIFI_CONFIG, "[%s] os_snprintf fail\n", __func__);

			ret = os_snprintf(param, sizeof(param), "map_controller_alid");
			if (os_snprintf_error(sizeof(param), ret))
				err(DEBUG_CAT_WIFI_CONFIG, "[%s] os_snprintf fail\n", __func__);

			get_parameters(file_name, param, value, NON_DRIVER_PARAM, sizeof(value));
			ret = hwaddr_aton(value, wapp->map->ctrl_alid);
			if (ret != 0)
				err(DEBUG_CAT_WIFI_CONFIG, "[%s] hwaddr_aton fail\n", __func__);

			os_memset(value, 0, sizeof(value));
			os_memset(param, 0, sizeof(param));
			ret = os_snprintf(param, sizeof(param), "map_agent_alid");
			if (os_snprintf_error(sizeof(param), ret))
				err(DEBUG_CAT_WIFI_CONFIG, "[%s] os_snprintf fail\n", __func__);

			get_parameters(file_name, param, value, NON_DRIVER_PARAM, sizeof(value));
			ret = hwaddr_aton(value, wapp->map->agnt_alid);
			if (ret != 0)
				err(DEBUG_CAT_WIFI_CONFIG, "[%s] hwaddr_aton fail\n", __func__);

			if ((os_memcmp(wdev->mac_addr, wapp->map->ctrl_alid, ETH_ALEN) == 0
				|| os_memcmp(wdev->mac_addr, wapp->map->agnt_alid, ETH_ALEN) == 0))
				wapp_add_intf_interface_bridge(wapp, wdev->ifname, wapp->map->br_iface);
		}
	}
#endif /* MTK_HOSTAPD_SUPPORT */

	conf_stat = &ra->conf_state;
	MAP_CONF_STATE_SET(conf_stat, MAP_CONF_STOP);

	return WAPP_SUCCESS;
}

int map_bh_ready(
	struct wifi_app *wapp,
	u8 bh_type,
	u8 *ifname,
	u8 *mac_addr,
	u8 *bssid
#ifdef MTK_MLO_MAP_SUPPORT
	,
	u8 setup_link_num,
	struct mlo_non_setup_linkinfo *linkinfo
#ifdef MAP_R6
	,
	struct mlo_bh_sta_info *mlo_sta
#endif
#endif
)
{
	struct bh_link_info bh;
	wapp_device_status *device_status = &wapp->map->device_status;
	int i = 0, len = 0;
	int if_len;
#ifdef MAP_R6
	int ifindex = 0;
	unsigned char radio_id[ETH_ALEN];
	struct wapp_dev *wdev = NULL;
#endif
	char *map_evt_buf = NULL;

#ifdef MAP_R3
	struct dpp_authentication *auth = NULL;
#endif /* MAP_R3 */
	map_evt_buf = (char *)os_malloc(MAX_EVT_BUF_LEN * sizeof(char));
	if (!map_evt_buf) {
		err(DEBUG_CAT_AUTOCONFIG, "Alloc map_evt_buf failed !!!\n");
		return WAPP_RESOURCE_ALLOC_FAIL;
	}
	for (i = 0; i < MAX_NUM_OF_RADIO; i++)
	{
		struct wapp_radio *ra = &wapp->radio[i];
		u8 id[MAC_ADDR_LEN];

		if (!ra->adpt_id)
			continue;

		MAP_GET_RADIO_IDNFER(ra, id);
		map_send_ap_ht_capability_msg(wapp, id, map_evt_buf, &len);
		if (0 > map_1905_send(wapp, map_evt_buf, len)) {
			err(DEBUG_CAT_AUTOCONFIG, "send ap ht capability msg fail\n");
			os_free(map_evt_buf);
			return MAP_ERROR;
		}
		memset(map_evt_buf,0, MAX_EVT_BUF_LEN * sizeof(char));
		map_send_ap_vht_capability_msg(wapp, id, map_evt_buf, &len);
		if (0 > map_1905_send(wapp, map_evt_buf, len)) {
			err(DEBUG_CAT_AUTOCONFIG, "send ap vht capability msg fail\n");
			os_free(map_evt_buf);
			return MAP_ERROR;
		}
	}
	os_free(map_evt_buf);
	wapp->map->bh_link_ready = 1;

	os_memset(&bh, 0, sizeof(bh));
	bh.type = bh_type;
	if (bh.type == MAP_BH_ETH) {
		int i;
		struct map_conf_state *conf_stat = NULL;

		map_update_bh_link_info(wapp, MAP_BH_ETH, 1, 0);
		for (i = 0; i < MAX_NUM_OF_RADIO; i++) {
			conf_stat = &wapp->radio[i].conf_state;
			MAP_CONF_STATE_SET(conf_stat, MAP_CONF_UNCONF);
		}
		wapp->map->ongoing_conf_retry_times = 0;
		map_reset_conf_sm(wapp->map);
		wapp_soft_reset_scan_states(wapp);
#ifdef MAP_R3
		if ((wapp->map->map_version == DEV_TYPE_R3) && wapp->dpp) {
			wapp->dpp->dpp_eth_conn_ind = TRUE;
			if (wapp->dpp->dpp_allowed_roles == DPP_CAPAB_ENROLLEE) {
				if(wapp->dpp->chirp_ongoing) {
					/* Stop chirping if the chirp is ongoing */
					notice(DEBUG_CAT_AUTOCONFIG, "stop chirping in DPP enrollee mode\n");
					wapp_dpp_presence_announce_stop(wapp);
				}

				if (wapp->dpp->dpp_onboard_ongoing) {
					/* If dpp onboard ongoing and ETH link connected
					 * clear the existing wifi state and continue with ETH */
					notice(DEBUG_CAT_AUTOCONFIG, " clear auth state in DPP enrollee mode\n");
					wapp->dpp->dpp_onboard_ongoing = 0;
					wapp->dpp->dpp_wifi_onboard_ongoing = FALSE;
					auth = wapp_dpp_get_first_auth(wapp);
					if(!auth) {
						err(DEBUG_CAT_AUTOCONFIG, "%s auth instance not found\n", __func__);
					}
					else {
						wapp_dpp_cancel_timeouts(wapp,auth);
						eloop_cancel_timeout(wapp_dpp_conn_result_timeout, wapp,auth);
						dpp_auth_deinit(auth);
					}
				}
			}
#ifndef EM_PLUS_SUPPORT
			if (wapp->dpp->dpp_allowed_roles == DPP_CAPAB_PROXYAGENT) {
				/* if device was onboarded previsouly and eth triggered
				 * first convert to Enrollee mode */
				err(DEBUG_CAT_AUTOCONFIG, "Device is proxy agnt, convert to enrollee\n");
#ifndef EM_PLUS_SUPPORT
				wapp->dpp->dpp_allowed_roles = DPP_CAPAB_ENROLLEE;
#endif
				/* Disabling 1905 security on ETH detection */
				wapp->dpp->map_sec_done = FALSE;
				wapp_dpp_set_1905_sec(wapp, wapp->dpp->map_sec_done);
			}
#endif
		}
#endif /* MAP_R3 */
		err(DEBUG_CAT_AUTOCONFIG, "[eth case]eth link up\n");
	} else {
		err(DEBUG_CAT_AUTOCONFIG, "[wifi case]%s linked to "MACSTR"\n", ifname, MAC2STR(bssid));
	}
	if_len = os_strlen((char *)ifname);
	if (if_len > IFNAMSIZ) {
		err(DEBUG_CAT_AUTOCONFIG, "invalid len of  ifname = %d\n", if_len);
		return WAPP_UNEXP;
	}

	os_memcpy(bh.ifname, ifname, if_len);
	os_memcpy(bh.mac_addr, mac_addr, MAC_ADDR_LEN);
	os_memcpy(bh.bssid, bssid, MAC_ADDR_LEN);
#ifdef MTK_MLO_MAP_SUPPORT
	if (linkinfo != NULL && bh.type != MAP_BH_ETH) {
		if (setup_link_num < MAX_MLO_NON_SETUP_LINK)
			bh.setup_link_num = setup_link_num;
		else
			bh.setup_link_num = MAX_MLO_NON_SETUP_LINK;
#ifdef MAP_R6
		if (bh.setup_link_num > 0) {
			if (mlo_sta->mld_mac_valid == 1)
				bh.mldinfo.mld_mac_bitmap |= BIT(7);
			if (mlo_sta->bss_mld_mac_valid == 1)
				bh.mldinfo.mld_mac_bitmap |= BIT(6);

			os_memcpy(bh.mldinfo.mld_mac, mlo_sta->mld_mac, MAC_ADDR_LEN);
			os_memcpy(bh.mldinfo.bss_mld_mac, mlo_sta->bss_mld_mac, MAC_ADDR_LEN);
			if (mlo_sta->str_en_dis == 1)
				bh.mldinfo.switch_bitmap |= BIT(7);
			if (mlo_sta->nstr_en_dis == 1)
				bh.mldinfo.switch_bitmap |= BIT(6);
			if (mlo_sta->emlsr_en_dis == 1)
				bh.mldinfo.switch_bitmap |= BIT(5);
			if (mlo_sta->emlmr_en_dis == 1)
				bh.mldinfo.switch_bitmap |= BIT(4);

			bh.mldinfo.num_affiliated_sta = bh.setup_link_num;
		}
#endif
		for (i = 0; i < bh.setup_link_num; i++) {
			os_memcpy(&bh.linkinfo[i], &linkinfo[i],
					sizeof(struct mlo_non_setup_linkinfo));
#ifdef MAP_R6
			bh.mldinfo.sta[i].bitmap |= BIT(7);
			os_memcpy(bh.mldinfo.sta[i].affiliated_sta_bssid, bh.linkinfo[i].mac_addr, ETH_ALEN);
			ifindex = bh.linkinfo[i].ifindex;
			wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
			if (!wdev) {
				err(DEBUG_CAT_AUTOCONFIG, " wdev null, skip\n");
				continue;
			}

			if (wdev->radio) {
				MAP_GET_RADIO_IDNFER(wdev->radio, radio_id);
				os_memcpy(bh.mldinfo.sta[i].ruid, radio_id, ETH_ALEN);
			}

			if (wdev->dev_type == WAPP_DEV_TYPE_STA) {
				os_memcpy(wapp->bsta_affltd_bssid[i], bh.mldinfo.sta[i].affiliated_sta_bssid, ETH_ALEN);
				os_memcpy(wapp->bsta_ruid[i], bh.mldinfo.sta[i].ruid, ETH_ALEN);
			}
			/* Save in apcli wdev info */
			os_memcpy(wdev->bh_apcli_mld_mac, bh.mldinfo.mld_mac, ETH_ALEN);
			os_memcpy(wdev->bh_apcli_bss_mld_mac, bh.mldinfo.bss_mld_mac, ETH_ALEN);
			wdev->str_en_dis = mlo_sta->str_en_dis;
			wdev->nstr_en_dis = mlo_sta->nstr_en_dis;
			wdev->emlsr_en_dis = mlo_sta->emlsr_en_dis;
			wdev->emlmr_en_dis = mlo_sta->emlmr_en_dis;

			err(DEBUG_CAT_AUTOCONFIG, "[NAKUL DEBUG]%d linked to "MACSTR"\n",
					bh.mldinfo.num_affiliated_sta, MAC2STR(bh.mldinfo.sta[i].affiliated_sta_bssid));
			err(DEBUG_CAT_AUTOCONFIG, "mld mac "MACSTR"\n",
					MAC2STR(bh.mldinfo.mld_mac));
#endif
		}
	}
#endif
	if (device_status->status_bhsta != STATUS_BHSTA_CONFIGURED) {
		if(bh.type != MAP_BH_ETH)
			device_status->status_bhsta = STATUS_BHSTA_BH_READY;
		else
			device_status->status_bhsta = STATUS_BHSTA_UNCONFIGURED;
		device_status->status_fhbss = STATUS_FHBSS_UNCONFIGURED;
		wapp_send_1905_msg(
			wapp,
			WAPP_DEVICE_STATUS,
			sizeof(wapp_device_status),
			(char *)device_status);
	}
	return wapp_send_1905_msg(
		wapp,
		WAPP_MAP_BH_READY,
		sizeof (struct bh_link_info),
		(char *) &bh);
}

void map_conf_state_check(
	struct wifi_app *wapp)
{
	int ret;
	struct map_info *map = wapp->map;
	struct wapp_radio *ra = NULL;
	struct map_conf_state *conf_stat = NULL;
	unsigned char identifier[6] = {0};
	int conf_flag = 0;
	int i = 0;


	/* if backhaul link is ready and controller is found,
	   check for any unconfig radio and try to get config */

	if (map->bh_link_ready && map->ctrler_found)
	{
		if (map->conf_ongoing_radio_idx >= MAX_NUM_OF_RADIO) {
			map->conf_ongoing_radio_idx = 0;
		}

		map->conf_ongoing_radio = &wapp->radio[map->conf_ongoing_radio_idx];
		ra = map->conf_ongoing_radio;

		/* non active radio , try next radio */
		if (!ra->adpt_id) {
			struct map_conf_state *conf_state = NULL;
			conf_flag = 0;
			map->conf_ongoing_radio_idx++;
			if (wapp->map->conf == MAP_CONN_STATUS_CONF)
				return;
			for (i = 0; i < MAX_NUM_OF_RADIO; i++) {
				conf_state = &wapp->radio[i].conf_state;
				if ((wapp->radio[i].adpt_id) && (IS_CONF_STATE(conf_state, MAP_CONF_UNCONF)
					|| IS_CONF_STATE(conf_state, MAP_CONF_WAIT_RSP)))
					conf_flag = 1;
			}
			if(conf_flag != 1) {
				wapp_device_status *device_status = &map->device_status;
				eloop_cancel_timeout(map_wps_timeout, wapp, device_status);
				wapp->map->conf = MAP_CONN_STATUS_CONF;
				device_status->status_fhbss = STATUS_FHBSS_CONFIGURED;
				device_status->status_bhsta = STATUS_BHSTA_CONFIGURED;
				wapp_send_1905_msg(
					wapp,
					WAPP_DEVICE_STATUS,
					sizeof(wapp_device_status),
					(char *)device_status);
			}
			return;
		}

		MAP_GET_RADIO_IDNFER(ra, identifier);
		conf_stat = &ra->conf_state;

		debug(DEBUG_CAT_WIFI_CONFIG, "identifier("MACSTR")\n", MAC2STR(identifier));
		debug(DEBUG_CAT_WIFI_CONFIG, "state(%d)\n", conf_stat->state);
		debug(DEBUG_CAT_WIFI_CONFIG, "conf_ongoing_radio_idx(%d)\n", map->conf_ongoing_radio_idx);
		debug(DEBUG_CAT_WIFI_CONFIG, "ongoing_conf_retry_times(%d)\n", map->ongoing_conf_retry_times);
		debug(DEBUG_CAT_WIFI_CONFIG, "elapsed_time(%d)\n", conf_stat->elapsed_time);

		if (IS_CONF_STATE(conf_stat, MAP_CONF_UNCONF)) {
			ret = map_get_config(wapp, ra);
			if (ret == WAPP_SUCCESS) {
				/* retry 4 times, then give up , try next radio */
				if(map->ongoing_conf_retry_times > 3) {
					wapp_device_status *device_status = &map->device_status;
					MAP_CONF_STATE_SET(conf_stat, MAP_CONF_STOP);
					err(DEBUG_CAT_WIFI_CONFIG, "\033[1;32m %s, %u give up radio %d.\033[0m\n", __func__,
						__LINE__, map->conf_ongoing_radio_idx);
					map->conf_ongoing_radio_idx++;
					map->ongoing_conf_retry_times = 0;
					device_status->status_bhsta = STATUS_BHSTA_CONFIG_PENDING;
					device_status->status_fhbss = STATUS_FHBSS_UNCONFIGURED;
					wapp_send_1905_msg(
						wapp,
						WAPP_DEVICE_STATUS,
						sizeof(wapp_device_status),
						(char *)device_status);
					for (i = 0; i < MAX_NUM_OF_RADIO; i++) {
						ra = &wapp->radio[i];
						MAP_CONF_STATE_SET((&ra->conf_state), MAP_CONF_UNCONF);
					}
					if(wapp->map->TurnKeyEnable) {
						map_reset_conf_sm(wapp->map);
					}
					wapp->map->bh_link_ready = 0;
					if(wapp->map->is_agnt)
						wapp->map->ctrler_found = 0;
					device_status->status_fhbss = STATUS_FHBSS_UNCONFIGURED;
					device_status->status_bhsta = STATUS_BHSTA_UNCONFIGURED;
					wapp_send_1905_msg(
					wapp,
					WAPP_DEVICE_STATUS,
					sizeof(wapp_device_status),
					(char *)device_status);
					wapp_soft_reset_scan_states(wapp);
				} else {
					MAP_CONF_STATE_SET(conf_stat, MAP_CONF_WAIT_RSP);
				}
			} else {
			}
		} else if (IS_CONF_STATE(conf_stat, MAP_CONF_WAIT_RSP)) {
			if (conf_stat->elapsed_time > MAP_CONF_TIMEOUT) {
				/* retry */
				MAP_CONF_STATE_SET(conf_stat, MAP_CONF_UNCONF);
				map->ongoing_conf_retry_times++;
			} else {
				conf_stat->elapsed_time++;
			}
		} else if (IS_CONF_STATE(conf_stat, MAP_CONF_STOP)) {
			/* 1905 will auto retry m1 if it got renew, will be confed in map_config_wireless_setting_msg */
			notice(DEBUG_CAT_WIFI_CONFIG, "\033[1;32m %s, %u this radio %d was gave up, do nothing.\033[0m\n",
								__func__, __LINE__, map->conf_ongoing_radio_idx);
			map->conf_ongoing_radio_idx++;
			map->ongoing_conf_retry_times = 0;
		} else if (IS_CONF_STATE(conf_stat, MAP_CONF_CONFED)){
			map->conf_ongoing_radio_idx++;
			map->ongoing_conf_retry_times = 0;
		}

	}
}

void map_block_list_state_check(
	struct wifi_app *wapp)
{
	struct wapp_dev *wdev = NULL, *wdev_temp = NULL;
	struct dl_list *dev_list;
	struct ap_dev *ap = NULL;
	int i = 0;

	dev_list = &wapp->dev_list;
	if (dl_list_empty(dev_list))
		return;
	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
		if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
			ap = (struct ap_dev *)wdev->p_dev;
#ifdef EM_PLUS_SUPPORT
			if (ap == NULL)
				continue;
#endif
			for (i = 0; i < ap->max_num_of_block_cli; i++) {
				if (ap->block_table[i].valid_period > 0) {
					ap->block_table[i].valid_period--;
					if (!ap->block_table[i].valid_period) {
						info(DEBUG_CAT_MISC, "[ACL]valid period expire; free assoc ctrl sta("MACSTR")\n",
							MAC2STR(ap->block_table[i].mac_addr));
						acl_cmd_data(wapp, wdev->ifname, ACL_DEL,
							ap->block_table[i].mac_addr, MAC_ADDR_LEN);
						os_memset(ap->block_table[i].mac_addr, 0, MAC_ADDR_LEN);
						ap->num_of_block_cli--;
					}
				}
			}
		}
	}
}

void map_link_metric_check(
	struct wifi_app *wapp)
{
	int i = 0;
	struct wapp_radio *ra = NULL;
	char idfr[MAC_ADDR_LEN];
	struct wapp_dev *wdev = NULL;
	static int cnt = 0, tot_cnt = 0;
	static int send_above_threshold = 0;

	for (i = 0; i < MAX_NUM_OF_RADIO; i++)
	{
		ra = &wapp->radio[i];
		if (ra->adpt_id) {
			MAP_GET_RADIO_IDNFER(ra, idfr);
			if (ra->metric_policy.ch_util_thres > 0) {
				/*
				 * work around 4.7.6: do not check real channel utilization,
				 * just send link metric report for every 5 sec
				 */
				if (tot_cnt == 10) {
					if (cnt >= 7 && send_above_threshold == 0) {
						wapp_send_1905_msg(
								wapp,
								WAPP_AP_LINK_METRIC_REQ,
								ETH_ALEN,
								idfr);
						send_above_threshold = 1;
					} else if (cnt <= 5 && send_above_threshold == 1) {
						wapp_send_1905_msg(
								wapp,
								WAPP_AP_LINK_METRIC_REQ,
								ETH_ALEN,
								idfr);
						send_above_threshold = 0;
					}
					cnt = 0;
					tot_cnt = 0;
				}

				/*query channel utilization again*/
				wdev = wapp_dev_list_lookup_by_radio(wapp, idfr);
				if (wdev)
					wapp_query_wdev_by_req_id(wapp, wdev->ifname, WAPP_CH_UTIL_QUERY_REQ);
				if (ra->metric_policy.ch_util_current > ra->metric_policy.ch_util_thres)
					cnt++;
				tot_cnt++;
			}
		}
	}
}

void map_periodic_exec(
	struct wifi_app *wapp)
{
	map_block_list_state_check(wapp);
	map_link_metric_check(wapp);
}

int map_reset_default(
		struct wifi_app *wapp)
{
	int i, ret = 0;
	struct wapp_dev *wdev = NULL, *main_dev = NULL, *wdev_temp = NULL;
	struct wapp_radio *ra = NULL;
	struct dl_list *dev_list;
#ifndef MTK_HOSTAPD_SUPPORT
	struct sec_info sec;
#endif /* MTK_HOSTAPD_SUPPORT */
	wapp_device_status *device_status = NULL;

	if (!wapp) {
		err(DEBUG_CAT_MISC, "%s null wapp\n", __func__);
		return WAPP_INVALID_ARG;
	}

	device_status = &wapp->map->device_status;
	dev_list = &wapp->dev_list;
#ifndef MTK_HOSTAPD_SUPPORT
	os_memset(&sec, 0, sizeof(sec));
#if 1
	int res;
	res = snprintf(sec.auth, sizeof(sec.auth), "OPEN");
	if (os_snprintf_error(sizeof(sec.auth), res))
		err(DEBUG_CAT_MISC, "%s-%d error in snprintf\n", __func__, __LINE__);
	res = snprintf(sec.encryp, sizeof(sec.encryp), "NONE");
	if (os_snprintf_error(sizeof(sec.encryp), res))
		err(DEBUG_CAT_MISC, "%s-%d error in snprintf\n", __func__, __LINE__);
	res = snprintf(sec.psphr, sizeof(sec.psphr), "12345678");
	if (os_snprintf_error(sizeof(sec.psphr), res))
		err(DEBUG_CAT_MISC, "%s-%d error in snprintf\n", __func__, __LINE__);
#endif
#endif /* MTK_HOSTAPD_SUPPORT */
	save_map_parameters(wapp,"BhProfile0Valid", "0", NON_DRIVER_PARAM);
	if (!dl_list_empty(dev_list)){
		dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
#ifdef MAP_R3
			dpp_save_config(wapp, "_valid", "0", NULL);
#endif
			if ((wdev->dev_type == WAPP_DEV_TYPE_APCLI || wdev->dev_type == WAPP_DEV_TYPE_STA)) {
				wdev_bh_sta_reset_default(wapp, wdev);
				continue;
			}
		}
	}
	for (i = 0; i < MAX_NUM_OF_RADIO; i++) {
//#ifdef MAP_R2
		struct wapp_dev *ap_wdev = NULL;
//#endif
		ra = &wapp->radio[i];

		if (ra->adpt_id == 0)
			continue;
		wdev_temp = NULL;
		dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
			eloop_cancel_timeout(bh_steering_ready_timeout, wapp, wdev);
#if 1 /* now, only for ap_dev */
#ifdef MAP_R2
			ts_bh_set_default_8021q(wapp, wdev, VLAN_N_VID, 0);
			ts_bh_set_all_vid(wapp, wdev, 0, NULL);
			ts_fh_set_vid(wapp, wdev, VLAN_N_VID);
#endif
#endif

			if (wdev->radio == ra) {
				struct ap_dev *ap = (struct ap_dev *)wdev->p_dev;
				ap_wdev = wdev;
				if ((ap_wdev->dev_type == WAPP_DEV_TYPE_APCLI || ap_wdev->dev_type == WAPP_DEV_TYPE_STA))
					continue;
				ap->isActive = WAPP_BSS_START;
				wapp_set_dev_status(wapp, wdev, 0);
#ifndef MTK_HOSTAPD_SUPPORT
				wapp_set_bss_start(wapp, wdev->ifname);
#else

				if (wapp->drv_ops->drv_send_ap_intf_enable)
					wapp->drv_ops->drv_send_ap_intf_enable(wapp->drv_data, wdev->ifname);
#endif /* MTK_HOSTAPD_SUPPORT */

				if (!main_dev)
					main_dev = wdev;
#ifdef MTK_HOSTAPD_SUPPORT
				struct wireless_setting unConf_wifi_profile = {0};

				os_strlcpy((char *)unConf_wifi_profile.Ssid, MAP_DEFAULT_SSID, sizeof(MAP_DEFAULT_SSID));
				/*
				 * Write the BSS configuration to hostapd.conf map file
				 * setting FH BSS bit as the FH BSS profile is to be updated here
				 */
				unConf_wifi_profile.map_vendor_extension = ap->bss_info.map_role;
				/*unConf_wifi_profile.EncrypType = WSC_ENCRTYPE_NONE;
				*unConf_wifi_profile.AuthMode = WPS_AUTH_OPEN;
				*/

				os_memcpy(unConf_wifi_profile.WPAKey, "12345678", os_strlen("12345678"));
				unConf_wifi_profile.AuthMode = WPS_AUTH_WPA2PSK;

				ret = wdev_set_hapd_wifi_profile(wapp, wdev, &unConf_wifi_profile);
				if (ret != 0) {
					err(DEBUG_CAT_MISC, "%s wdev_set_hapd_wifi_profile failure\n", __func__);
					continue;
				}
				/* Call hapd update for this interface */
				wdev_send_config_update(wapp, wdev);
				wdev_set_ssid(wapp, wdev, MAP_DEFAULT_SSID);
#else
				ret += wdev_set_sec_and_ssid(wapp, wdev, &sec, MAP_DEFAULT_SSID);
#endif /* MTK_HOSTAPD_SUPPORT */
				//sleep(3);
			}

		}

		if (ap_wdev)
			wapp_reset_map_params(wapp, ap_wdev);

#ifdef MAP_R5
		qos_cmd_reset_default(wapp, NULL, 0, NULL);
#endif

		MAP_CONF_STATE_SET((&ra->conf_state), MAP_CONF_UNCONF);
	}
	if(wapp->map->TurnKeyEnable) {
		map_reset_conf_sm(wapp->map);
		eloop_cancel_timeout(map_config_state_check,wapp,NULL);
	}
	wapp_reset_scan_states(wapp);
	wapp->map->bh_link_ready = 0;
	if(wapp->map->is_agnt)
		wapp->map->ctrler_found = 0;
#ifdef MAP_R3
	//Disabling 1905 security on map reset default
	if (wapp->dpp->dpp_allowed_roles == DPP_CAPAB_PROXYAGENT)
		wapp->dpp->dpp_allowed_roles = DPP_CAPAB_ENROLLEE;

	wapp->dpp->map_sec_done = FALSE;
	wapp_dpp_set_1905_sec(wapp, 0);
#endif /* MAP_R3 */

	device_status->status_fhbss = STATUS_FHBSS_UNCONFIGURED;
	device_status->status_bhsta = STATUS_BHSTA_UNCONFIGURED;
	wapp_send_1905_msg(
		wapp,
		WAPP_DEVICE_STATUS,
		sizeof(wapp_device_status),
		(char *)device_status);
	map_send_reset_msg(wapp);

	return ret;
}

void map_show_param(
	struct wifi_app *wapp)
{
	struct map_info *map = NULL;
	FILE *file;

	if (!wapp) {
		err(DEBUG_CAT_MISC, "%s null wapp\n", __func__);
		return;
	}

	map = wapp->map;

	file = fopen(MAP_TMP_FILE, "w");

	if (!file) {
		err(DEBUG_CAT_MISC, "open MAP tmp file (%s) fail\n", MAP_TMP_FILE);
		return;
	}

	if (fprintf(file,
		"map param:\n"
		"\t is_ctrler             %u\n"
		"\t is_agnt               %u\n"
		"\t is_root 		      %u\n"
		"\t ctrl_alid             %02x:%02x:%02x:%02x:%02x:%02x\n"
		"\t agnt_alid             %02x:%02x:%02x:%02x:%02x:%02x\n"
		"\t fh_24g_bssid 	      %02x:%02x:%02x:%02x:%02x:%02x\n"
		"\t fh_5g1_bssid 	      %02x:%02x:%02x:%02x:%02x:%02x\n"
		"\t fh_5g2_bssid 	      %02x:%02x:%02x:%02x:%02x:%02x\n"
		"\t fh_radio_supt 	      %u\n"
		"\t bh_wifi_dev 	      %s\n"
		"\t bh_type(%u)           %s\n"
		"\t radio_band_options    %u-%u-%u\n",
		map->is_ctrler,
		map->is_agnt,
		map->is_root,
		PRINT_MAC(map->ctrl_alid),
		PRINT_MAC(map->agnt_alid),
		PRINT_MAC(map->fh_24g_bssid),
		PRINT_MAC(map->fh_5g1_bssid),
		PRINT_MAC(map->fh_5g2_bssid),
		map->fh_radio_supt,
		map->bh_wifi_dev == NULL? "NONE":map->bh_wifi_dev->ifname,
		map->bh_type, map->bh_type == MAP_BH_ETH ? "eth" : "wifi",
		map->radio_band_options[0],
		map->radio_band_options[1],
		map->radio_band_options[2]) < 0)
			err(DEBUG_CAT_MISC, "[%s] fprintf fail\n", __func__);

	if (fclose(file) != 0)
		err(DEBUG_CAT_MISC, "[%s] fclose fail\n", __func__);

	map_send_wireless_inf_info(wapp, TRUE, 0);
}

int map_btm_rsp_action(
	struct wifi_app *wapp,
	struct wapp_dev *wdev,
	const u8 *peer_mac_addr,
	struct btm_payload *btm_resp)
{
	char buf[128] = {0};
	struct cli_steer_btm_event btm_evt;

	os_memset(&btm_evt,0,sizeof(btm_evt));
	/*send client steering BTM report*/
	COPY_MAC_ADDR(&btm_evt.bssid, wdev->mac_addr);
	COPY_MAC_ADDR(&btm_evt.sta_mac, peer_mac_addr);
	btm_evt.status = btm_resp->u.btm_rsp.status_code;
	if (btm_resp->u.btm_rsp.status_code == 0) /* target bssid is present only if status code is 0 */
		COPY_MAC_ADDR(&btm_evt.tbssid, btm_resp->u.btm_rsp.variable);
	wapp_send_cli_steer_btm_report_msg(wapp, buf, 128, &btm_evt);

	return WAPP_SUCCESS;
}

int map_update_radio_band(
	struct wifi_app *wapp,
	struct wapp_radio *ra,
	u8 ch)
{
	int i, j;
	u8 used = FALSE;
	struct map_info *map = wapp->map;

	if (!ra)
		return WAPP_INVALID_ARG;

	/* release the ocuppied entry */
	ra->radio_band = NULL;

	/* Check single band first */
	for ( i = 0; i < MAP_MAX_RADIO; i++)
	{
#ifndef MAP_6E_SUPPORT
		if ((map->radio_band_options[i] == RADIO_24G && IS_MAP_CH_24G(ra->op_ch)) ||
			(map->radio_band_options[i] == RADIO_5GL && IS_MAP_CH_5GL(ra->op_ch)) ||
			(map->radio_band_options[i] == RADIO_5GH && IS_MAP_CH_5GH(ra->op_ch)))
#else
		if ((map->radio_band_options[i] == RADIO_24G && IS_OP_CLASS_24G(ra->opclass)) ||
			(map->radio_band_options[i] == RADIO_5GL && IS_OP_CLASS_5GL(ra->opclass) && IS_MAP_CH_5GL(ra->op_ch)) ||
			(map->radio_band_options[i] == RADIO_5GH && IS_OP_CLASS_5GH(ra->opclass) && IS_MAP_CH_5GH(ra->op_ch)) ||
			(map->radio_band_options[i] == RADIO_6G && IS_OP_CLASS_6G(ra->opclass)))
#endif
		{
			used = FALSE;
			/* found one option match the radio channel,
			   check if other radio is using this one */
			for (j = 0; j < MAP_MAX_RADIO; j++)
			{
				if (wapp->radio[j].radio_band == &map->radio_band_options[i])
				{
					used = TRUE;
					break;
				}
			}

			if (used == FALSE)
			{
				ra->radio_band = &map->radio_band_options[i];
				break;
			}
		}
	}

	/* If not found, check again for 5G full band options */
	if (ra->radio_band == NULL) {
		for ( i = 0; i < MAP_MAX_RADIO; i++)
		{
			if ( map->radio_band_options[i] == RADIO_5G && IS_MAP_CH_5G(ra->op_ch))
			{
				used = FALSE;
				/* found one option match the radio channel,
			   	check if other radio is using this one */
				for (j = 0; j < MAP_MAX_RADIO; j++)
				{
					if (wapp->radio[j].radio_band == &map->radio_band_options[i])
					{
						used = TRUE;
						break;
					}
				}

				if (used == FALSE)
				{
					ra->radio_band = &map->radio_band_options[i];
					break;
				}
			}
		}
	}
	if (ra->radio_band == NULL)
		err(DEBUG_CAT_NL80211, "no valid band options!\n");

	return WAPP_SUCCESS;
}

struct wapp_ctrl_cmd map_cmd[] = {
	{"show_param",        map_cmd_show_param,                      "show param for wts DEV_GET_PARAMETER"},
	{"get_macaddr",       map_cmd_get_macaddr_by_ssid_ruid,        "get macaddr by matching ssid and radioID"},
	{"set_bh_type",       map_cmd_set_bh_type,                     "set backhaul type: [arg1]:eth or wifi"},
	{"set_alid",          map_cmd_set_alid,                        "[arg1]:ALid. set local ALid"},
	{"dev_send_1905",     map_cmd_send_1905,                       "dev data to 1905"},
	{"reset_default",     map_cmd_reset_default,                   "reset default (unconf)"},
	{"dev_set_config",    map_cmd_set_dev_config,                  "notify dev setting config to 1905"},
	{"trigger_wps",		  map_cmd_trigger_wps,                     "trigger ap or apcli do wps (currently from UCC)"},
#if 0 /* TODO */
	{"set_devrole",       wapp_cmd_wdev_ht_cap_query,			   "[arg1]:interface. query ht_cap of the interface"},
	{"set_bh_type",       wapp_cmd_wdev_ht_cap_query,			   "[arg1]:interface. query ht_cap of the interface"},
	{"set_bh_if",         wapp_cmd_wdev_ht_cap_query,			   "[arg1]:interface. query ht_cap of the interface"},
#endif /* TODO*/
	{"help",              map_cmd_show_help,                    "show this help"},
	{"wps_connect",       wps_connect,                      	"wps_connect"},
	{"0x0001",				toponotify,                  		"topology notification"},
	{"0x8018",				high_layer_data,                    "send high layer data"},
	{"operbss",				operbss,                      		"operational bss info"},
	{"0x8006",				ch_select_req,                      "channel selection request message"},
	{"0x8014",				cli_steer_req,                      "client steering request message"},
	{"0x8004",				ch_prefer_query,                    "channel preference query message"},
	{"0x8003",				map_policy_config_req,              "multi-ap policy config request message"},
	{"0x8016",				cli_assoc_cntrl_req,                "client association control request message"},
/*commen*/
	{"discovery",			discovery,                      	"topology discovery"},
	{"query",				topoquery,                      	"topology query"},
	{"notification",		toponotify,                  		"topology notification"},
/*steering*/
	{"steer_complete",		steering_completed,                 "steering completed message"},
	{"btm_report",			btm_report,                 		"client steering btm report message"},
	{"steer_mand",			steer_mand,                 		"Steering Request message in 4.8.1"},
	{"steer_oppo",			steer_oppo,                 		"Steering Request message in 4.8.3"},
	{"steer_policy",		steer_policy,                 		"Steering Policy message in 4.8.1"},
	{"steer_policy_rssi",	steer_policy_rssi,                 	"Steering Policy message in 4.8.4"},
	{"assoc_cntrl",			assoc_cntrl,                 		"Client Association Control Request message in 4.8.5"},
	{"backhaul_steer",		backhaul_steer,                 	"Backhaul Steering Request message in 4.9.1"},
/*metrics*/
	{"metrics_all_neighbor",		metrics_all_neighbor,       "link metrics query message in 4.7.1"},
	{"metrics_specific_neighbor",	metrics_specific_neighbor,  "link metrics query message in 4.7.2"},
	{"metrics_query",				metrics_query,  			"ap metrics query message in 4.7.4"},
	{"metric_report_policy",		metric_report_policy,  		"metrics report policy message in 4.7.5"},
	{"sta_link_metric_query",		sta_link_metric_query,  	"associated sta link metrics query message in 4.7.7"},
	{"sta_unlink_metric_query",		sta_unlink_metric_query,  	"unassociated sta link metrics query message in 4.7.8"},
	{"1905_req",            map_cmd_1905_req,                   "[arg1] req_id [arg2] req_value - send req to 1905 "},
#ifdef MAP_R2
	{"ch_scan",            map_cmd_ch_scan_req,                   "[arg1] req_id [arg2] req_value - send req to 1905 "},
#endif
#ifdef DFS_CAC_R2
	{"cac_status",            map_cmd_cac_status,                   "[arg1] req_id [arg2] req_value - send cac status to 1905 "},
#endif
	{"set_beacon_state",       map_cmd_set_beacon_state,                     "set beacon state: [arg1]:en or dis"},
#ifdef MAP_R3
	{"dev_set_trigger",            map_cmd_dev_set_trigger,                   "[arg1] sta MAC address "},
#endif /* MAP_R3 */
#ifdef MAP_6E_SUPPORT
	{"set_channel",            map_cmd_ch_set_req,                   "Req arg: arg [1], [2], [3], [4]"},
	{"off_ch_scan",            map_cmd_off_ch_req,                   "Req arg: arg [1]"},
	{"set_wireless_setting",   map_cmd_set_wireless_setting,         "No arguments"},
	{"set_tx_power",           map_cmd_set_tx_prcntg,                "Req arg: arg [1], [2]"},
	{"bh_connect_req",         map_cmd_bh_connect_req,               "Req arg: arg [1], [2], [3]"},
#endif
#ifdef DFS_SLAVE_SUPPORT
	{"slave_bcn_en",			map_cmd_slave_bcn_en,			"set slave_bcn_en: [arg1]:en or dis"},
#endif /* DFS_SLAVE_SUPPORT */
#ifdef MAP_R6
	{"get_mldaddr",       map_cmd_get_mld_addr_by_ssid,        "get mld addr by matching ssid and radioID"},
	{"get_bsta_affiliated_mac_addr",  map_cmd_get_bsta_affiliated_mac_by_ssid_ruid,   "get bsta affilaited macaddr"},
#endif
	{NULL,                map_cmd_show_help,	NULL}
};


int map_ctrl_interface_cmd_handle(
	struct wifi_app *wapp,
	const char *iface,
	u8 argc,
	char **argv)
{
	int i, ret;

	if (!argv[0]) {
		err(DEBUG_CAT_EVENT, "Invalid argument\n");
		return WAPP_INVALID_ARG;
	}

	for (i = 0; i < ARRAY_SIZE(map_cmd) && map_cmd[i].cmd != NULL; i++) {
		if (os_strncmp(map_cmd[i].cmd, argv[0], os_strlen(argv[0])) == 0) {
			ret = map_cmd[i].cmd_proc(wapp, iface, argc, argv);
			if (ret != WAPP_SUCCESS)
				err(DEBUG_CAT_EVENT, "cmd [%s] failed. ret = %d\n",	map_cmd[i].cmd, ret);
			break;
		}
	}

	return WAPP_SUCCESS;
}

int map_cmd_show_help( struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	u8 i = 0;

	printf("\033[1;36m available cmds: \033[0m\n");
	for(i=0;(map_cmd[i].cmd != NULL);i++){
		printf("\033[1;36m %20s  \t -  %s\033[0m\n",map_cmd[i].cmd,map_cmd[i].help);
	}

	return WAPP_SUCCESS;
}


int map_cmd_show_param( struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	map_show_param(wapp);

	return WAPP_SUCCESS;
}

int map_cmd_get_macaddr_by_ssid_ruid( struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	u8 idnfer[MAC_ADDR_LEN];
	u8 id[MAC_ADDR_LEN];
	u8 ssid[MAX_LEN_OF_SSID];
	struct dl_list *dev_list;
	struct wapp_dev *wdev = NULL, *wdev_temp = NULL;
	FILE *file=NULL;
	int ret;
	BOOLEAN found = FALSE;

	if (argc != 3) {
		notice(DEBUG_CAT_WIFI_CONFIG, "%s: cmd parameter error! need 3 but %d\n", __func__, argc);
		return WAPP_INVALID_ARG;
	}
	notice(DEBUG_CAT_WIFI_CONFIG, "\033[1;36m %s SSID [%s] RUID:%s\033[0m\n", __func__, argv[1], argv[2]);
	ret = snprintf((char *)ssid, sizeof(ssid), "%s", argv[1]);
	if (os_snprintf_error(sizeof(ssid), ret))
		err(DEBUG_CAT_WIFI_CONFIG, "%s-%d error in snprintf\n", __func__, __LINE__);
	AtoH(argv[2], (char *) idnfer, MAC_ADDR_LEN);

	notice(DEBUG_CAT_WIFI_CONFIG, "\033[1;36m %s SSID [%s] RUID: "MACSTR"\033[0m\n", __func__, ssid, MAC2STR(idnfer));

	file = fopen(MAC_ADDR_TMP_FILE, "w");

	if (!file) {
		notice(DEBUG_CAT_WIFI_CONFIG, "\033[1;32m %s, %u \033[0m\n", __func__, __LINE__);

		notice(DEBUG_CAT_WIFI_CONFIG, "open MAP tmp file (%s) fail\n", MAC_ADDR_TMP_FILE);
		return WAPP_RESOURCE_ALLOC_FAIL;
	}

	if (os_strcmp(argv[1], "BHSTA") == 0) {
		dev_list = &wapp->dev_list;
		if (!dl_list_empty(dev_list)){
			dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
				if (wdev->radio) {
					MAP_GET_RADIO_IDNFER(wdev->radio, id);
					if ((wdev->dev_type == WAPP_DEV_TYPE_STA) &&
						(os_memcmp(id, idnfer, MAC_ADDR_LEN) == 0)) {
							notice(DEBUG_CAT_WIFI_CONFIG, "[%s] HWAddr "MACSTR"\n",
							wdev->ifname, MAC2STR(wdev->mac_addr));
							found = TRUE;
							break;
					}
				}
			}
		}
	} else {
		dev_list = &wapp->dev_list;
		wdev_temp = NULL;
		if (!dl_list_empty(dev_list)){
			dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
				if (wdev->radio) {
					MAP_GET_RADIO_IDNFER(wdev->radio, id);
					if ((wdev->dev_type == WAPP_DEV_TYPE_AP) &&
						(os_memcmp(id, idnfer, MAC_ADDR_LEN) == 0)) {
							struct ap_dev *ap = (struct ap_dev *)wdev->p_dev;
							if (os_memcmp(ssid, ap->bss_info.ssid, os_strlen((char *)ssid)) == 0) {
								notice(DEBUG_CAT_WIFI_CONFIG, "[%s] len %zu [%s] HWAddr "MACSTR"\n",
								ap->bss_info.ssid, os_strlen((char *)ssid), wdev->ifname,
								MAC2STR(wdev->mac_addr));
								found = TRUE;
								break;
							}
					}
				}
			}
		}
	}
	if(found) {
		if (fprintf(file, "\t HWAddr              %02x:%02x:%02x:%02x:%02x:%02x\n", PRINT_MAC(wdev->mac_addr)) < 0)
			err(DEBUG_CAT_WIFI_CONFIG, "HWAddr fprintf erro\n");
	} else {
		printf("HWAddr N/A\n");
		if (fprintf(file, "HWAddr N/A\n") < 0)
			err(DEBUG_CAT_WIFI_CONFIG, "HWAddr fprintf error\n");
	}

	if (fclose(file) != 0)
		err(DEBUG_CAT_WIFI_CONFIG, "[%s] fclose fail\n", __func__);
	return WAPP_SUCCESS;
}

#ifdef MAP_R6
int map_cmd_get_bsta_affiliated_mac_by_ssid_ruid(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	u8 idnfer[MAC_ADDR_LEN];
	u8 ssid[MAX_LEN_OF_SSID];
	struct dl_list *dev_list;
	struct wapp_dev *wdev = NULL, *wdev_temp = NULL;
	struct wapp_sta *wdev_sta = NULL;
	FILE *file = NULL;
	int ret;
	BOOLEAN found = FALSE;
	u8 m = 0;

	if (argc != 3) {
		notice(DEBUG_CAT_MLO, "%s: cmd parameter error! need 3 but %d\n", __func__, argc);
		return WAPP_INVALID_ARG;
	}
	if (!argv[1] || !argv[2])
		return WAPP_INVALID_ARG;
	notice(DEBUG_CAT_MLO, "\033[1;36m %s SSID [%s] RUID:%s\033[0m\n", __func__, argv[1], argv[2]);
	ret = snprintf((char *)ssid, sizeof(ssid), "%s", argv[1]);
	if (os_snprintf_error(sizeof(ssid), ret))
		err(DEBUG_CAT_MLO, "%s-%d error in snprintf\n", __func__, __LINE__);
	AtoH(argv[2], (char *) idnfer, MAC_ADDR_LEN);

	notice(DEBUG_CAT_MLO, "\033[1;36m %s SSID [%s] RUID: "MACSTR"\033[0m\n", __func__, ssid, MAC2STR(idnfer));

	file = fopen(BSTA_AFF_MAC_ADDR_TMP_FILE, "w");

	if (!file) {
		err(DEBUG_CAT_MLO, "open MAP tmp file (%s) fail\n", BSTA_AFF_MAC_ADDR_TMP_FILE);
		return WAPP_RESOURCE_ALLOC_FAIL;
	}
	dev_list = &wapp->dev_list;
	if (!dl_list_empty(dev_list)) {
		dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
			if (!wdev)
				continue;
			wdev_sta = (struct wapp_sta *)wdev->p_dev;
			if (wdev->radio && wdev->dev_type == WAPP_DEV_TYPE_STA &&
				os_memcmp(ssid, wdev_sta->ssid, os_strlen((char *)ssid)) == 0) {
				for (m = 0; m < MAX_MLO_NON_SETUP_LINK; m++) {
					if (os_memcmp(wapp->bsta_ruid[m], idnfer, ETH_ALEN) == 0) {
						notice(DEBUG_CAT_MLO, "[%s] len %zu [%s] BSTA affilaited mac "MACSTR"\n",
						wdev_sta->ssid, os_strlen((char *)ssid),
						wdev->ifname, MAC2STR(wapp->bsta_affltd_bssid[m]));
						found = TRUE;
						break;
					}
				}
			}
		}
	}

	if (found) {
		if (fprintf(file, "\t BSTA_AFFILIATED_MAC_ADDR %02x:%02x:%02x:%02x:%02x:%02x\n", PRINT_MAC(wapp->bsta_affltd_bssid[m])) < 0)
			err(DEBUG_CAT_MLO, "BSTA_Affiliated_Mac fprintf error\n");
	} else {
		if (fprintf(file, "BSTA_AFFILIATED_MAC_ADDR N/A\n") < 0)
			err(DEBUG_CAT_MLO, "BSTA_Affiliated_Mac fprintf error\n");
	}

	if (fclose(file) != 0)
		err(DEBUG_CAT_MLO, "[%s] fclose fail\n", __func__);
	return WAPP_SUCCESS;
}

int map_cmd_get_mld_addr_by_ssid(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	u8 ssid[MAX_LEN_OF_SSID];
	struct dl_list *dev_list;
	struct wapp_dev *wdev = NULL, *wdev_temp = NULL;
	struct wapp_sta *wdev_sta = NULL;
	struct ap_dev *ap = NULL;
	FILE *file = NULL;
	int ret;
	BOOLEAN found = FALSE, found_ap_mld = FALSE;

	if (argc != 2) {
		notice(DEBUG_CAT_MLO, "%s: cmd parameter error! need 2 but %d\n", __func__, argc);
		return WAPP_INVALID_ARG;
	}
	ret = snprintf((char *)ssid, sizeof(ssid), "%s", argv[1]);
	if (os_snprintf_error(sizeof(ssid), ret))
		err(DEBUG_CAT_MLO, "%s-%d error in snprintf\n", __func__, __LINE__);

	file = fopen(MLD_ADDR_TMP_FILE, "w");

	if (!file) {
		notice(DEBUG_CAT_MLO, "open MAP tmp file (%s) fail\n", MLD_ADDR_TMP_FILE);
		return WAPP_RESOURCE_ALLOC_FAIL;
	}
	dev_list = &wapp->dev_list;
	wdev_temp = NULL;
	if (!dl_list_empty(dev_list)) {
		dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
			if (wdev->radio) {
				if (wdev->dev_type == WAPP_DEV_TYPE_STA) {
					wdev_sta = (struct wapp_sta *)wdev->p_dev;
					if (os_memcmp(ssid, wdev_sta->ssid, os_strlen((char *)ssid)) == 0) {
						debug(DEBUG_CAT_MLO, "[%s] len %zu [%s] BSTA MLD_Addr "MACSTR"\n",
							wdev_sta->ssid, os_strlen((char *)ssid),
							wdev->ifname, MAC2STR(wdev_sta->sta_mld_addr));
						found = TRUE;
						break;
					}
				} else if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
					ap = (struct ap_dev *)wdev->p_dev;
					if (os_memcmp(ssid, ap->bss_info.ssid, os_strlen((char *)ssid)) == 0) {
						debug(DEBUG_CAT_MLO, "[%s] len %zu [%s] AP_MLD_Addr "MACSTR"\n",
							ap->bss_info.ssid, os_strlen((char *)ssid),
							wdev->ifname, MAC2STR(ap->mlo_info.mld_addr));
						found_ap_mld = TRUE;
						break;
					}
				}
			}
		}
	}

	if (found) {
		if (fprintf(file, "\t MLD_Addr          %02x:%02x:%02x:%02x:%02x:%02x\n", PRINT_MAC(wdev_sta->sta_mld_addr)) < 0)
			err(DEBUG_CAT_MLO, "MLD_Addr fprintf erro\n");
	} else if (found_ap_mld) {
		if (fprintf(file, "\t MLD_Addr          %02x:%02x:%02x:%02x:%02x:%02x\n", PRINT_MAC(ap->mlo_info.mld_addr)) < 0)
			err(DEBUG_CAT_MLO, " MLD_Addr fprintf error\n");
	} else {
		if (fprintf(file, "MLD_Addr N/A\n") < 0)
			err(DEBUG_CAT_MLO, "MLD_Addr fprintf error\n");
	}

	if (fclose(file) != 0)
		err(DEBUG_CAT_MLO, "[%s] fclose fail\n", __func__);
	return WAPP_SUCCESS;
}
#endif

int map_cmd_set_bh_type( struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	struct map_info *map = wapp->map;
	struct wapp_dev *wdev = NULL, *wdev_temp = NULL;
	struct dl_list *dev_list;
	u8 mac_addr[MAC_ADDR_LEN] = {0};
	u8 idnfer[MAC_ADDR_LEN];
	u8 id[MAC_ADDR_LEN];
	u8 dev_found = 0;

	if (!argv[1]) {
		err(DEBUG_CAT_AUTOCONFIG, "Invalid argument\n");
		return WAPP_INVALID_ARG;
	}

	notice(DEBUG_CAT_AUTOCONFIG, "\033[1;36m %s = type = %s\033[0m\n", __func__, argv[1]);

	if (os_strcmp(argv[1], "eth") == 0) {
		map->bh_type = MAP_BH_ETH;
		wapp_get_mac_addr_by_ifname(MAP_DEFAULT_ETH_BH, mac_addr);
		if (wapp->map->TurnKeyEnable) {
			struct bh_type_info bh;

			bh.type = MAP_BH_ETH;
			wapp_send_1905_msg(
				wapp,
				WAPP_SET_BH_TYPE,
				sizeof (struct bh_type_info),
				(char *) &bh);
		}
		map_bh_ready(wapp, MAP_BH_ETH, (u8 *) MAP_DEFAULT_ETH_BH, mac_addr, mac_addr
#ifdef MTK_MLO_MAP_SUPPORT
		,
		0,
		NULL
#ifdef MAP_R6
,		NULL
#endif
#endif
);
	} else if (os_strcmp(argv[1], "wifi") == 0){
		if (!wapp->map->TurnKeyEnable) {
			if (argv[2] == NULL) {
				err(DEBUG_CAT_AUTOCONFIG, "Invalid argument\n");
				return WAPP_INVALID_ARG;
			}
			AtoH(argv[2], (char *) idnfer, MAC_ADDR_LEN);

			notice(DEBUG_CAT_AUTOCONFIG, "\033[1;36m %s idnfer = "MACSTR"\033[0m\n", __func__, MAC2STR(idnfer));
			dev_list = &wapp->dev_list;
			dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
				if (wdev->radio) {
					MAP_GET_RADIO_IDNFER(wdev->radio, id);
					if ((wdev->dev_type == WAPP_DEV_TYPE_STA) &&
						(os_memcmp(id, idnfer, MAC_ADDR_LEN) == 0)) {
							dev_found = 1;
							break;
					}
				}
			}

			map->bh_type = MAP_BH_WIFI;
			if (dev_found == 1) {
				map->bh_wifi_dev = wdev;
				notice(DEBUG_CAT_AUTOCONFIG, "bh_wifi_dev  %s\n", map->bh_wifi_dev->ifname);
			} else {
				notice(DEBUG_CAT_AUTOCONFIG, RED("%s: dev not found use default %s\n"),
						__func__, map->bh_wifi_dev->ifname);
			}

		} else {
			struct bh_type_info bh;

			bh.type = MAP_BH_WIFI;
			wapp_send_1905_msg(
				wapp,
				WAPP_SET_BH_TYPE,
				sizeof (struct bh_type_info),
				(char *) &bh);
		}
	} else {
		notice(DEBUG_CAT_AUTOCONFIG, "\033[1;36m %s: unknown bh type %s\033[0m\n", __func__, argv[1]);
	}

	return WAPP_SUCCESS;
}


int map_cmd_set_alid( struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	struct map_info *map = wapp->map;
	u8 alid[MAC_ADDR_LEN];
	char *token;
	int i;

	if (!argv[1] || !argv[2]) {
		err(DEBUG_CAT_MISC, "Invalid argument\n");
		return WAPP_INVALID_ARG;
	}

	notice(DEBUG_CAT_MISC, "\033[1;36m %s ALid = %s\033[0m\n", __func__, argv[1]);

	i = 0;
	token = strtok(argv[1], ":");

	while (token != NULL) {
		AtoH(token, (char *) &alid[i], 1);
		i++;
		if (i >= MAC_ADDR_LEN)
			break;
		token = strtok(NULL, ":");
	}

	if (os_strcmp(argv[2], "c") == 0)
		COPY_MAC_ADDR(map->ctrl_alid, alid);
	else
		COPY_MAC_ADDR(map->agnt_alid, alid);

	notice(DEBUG_CAT_MISC, "\033[1;36m %s alid = "MACSTR"\033[0m\n", __func__, MAC2STR(alid));

	return WAPP_SUCCESS;
}

int map_cmd_reset_default( struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	return map_reset_default(wapp);
}

int map_cmd_send_1905( struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	struct evt *wapp_event;
	u8 buffer[256];
	int send_pkt_len = 0;
	int role;

	if (!argv[1] || !argv[2]) {
		err(DEBUG_CAT_MISC, "Invalid argument\n");
		return WAPP_INVALID_ARG;
	}

	wapp_event = (struct evt *)buffer;
	wapp_event->type = WAPP_1905_READ_1905_TLV_REQUEST;
	wapp_event->length = strlen(argv[1]);
	/* Buffer Size = 256 - sizeof(type)-sizeof(mid)-sizeof(length)*/
	os_strlcpy((char *)wapp_event->buffer, argv[1], min(wapp_event->length+1, 253));

	send_pkt_len = sizeof(struct evt) + wapp_event->length;

	role = hex2num(*argv[2]);

	if (role == 0) { /*send to controller*/
		if (0 > map_1905_send_controller(wapp, (char *)buffer, send_pkt_len)) {
			err(DEBUG_CAT_MISC, "%s map_1905_send fail\n", __func__);
			return MAP_ERROR;
		}
	} else { /*send to agent*/
		if (0 > map_1905_send(wapp, (char *)buffer, send_pkt_len)) {
			err(DEBUG_CAT_MISC, "%s map_1905_send fail\n", __func__);
			return MAP_ERROR;
		}
	}
	notice(DEBUG_CAT_MISC,
				"%s\t argv[1] = %s	len=%zu	event->buffer=%s argv[2] = %d\n",
				 __FUNCTION__,argv[1],strlen(argv[1]), wapp_event->buffer, role);

	memset(buffer, 0, send_pkt_len);
	return WAPP_SUCCESS;
}

int map_cmd_set_dev_config( struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	struct evt *wapp_event;
	u8 buffer[256];
	int send_pkt_len = 0;
#ifdef MAP_R5
	int value, ret = 0;
	struct wapp_dev *wdev = NULL;
	struct dl_list *dev_list = NULL;
#endif


	if (!argv[1]) {
		err(DEBUG_CAT_WIFI_CONFIG, "Invalid argument\n");
		return WAPP_INVALID_ARG;
	}

#ifdef MAP_R5
	if (os_strcmp(argv[1], "dscppolicy_capa") == 0) {
		err(DEBUG_CAT_WIFI_CONFIG, "set %s = %s\n", argv[1], argv[2]);
		if (!argv[2])
			return WAPP_INVALID_ARG;

		value = strtol(argv[2], 0, 10);
		if (errno == ERANGE) {
			err(DEBUG_CAT_WIFI_CONFIG, "Input argument is outside of the range.\n");
			return WAPP_INVALID_ARG;
		}
		dev_list = &wapp->dev_list;
		dl_list_for_each(wdev, dev_list, struct wapp_dev, list) {
			if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
				ret = wapp->drv_ops->drv_set_DSCPPolicyEnable(wapp->drv_data, wdev->ifname, value);
				if (ret < 0)
					err(DEBUG_CAT_WIFI_CONFIG, "set DSCPPolicyEnable, command failed.\n");
				debug(DEBUG_CAT_WIFI_CONFIG, "set DSCPPolicyEnable = %d\n", value);
			}
		}
		return WAPP_SUCCESS;
	} else if (os_strcmp(argv[1], "qosmap_capa") == 0) {
		err(DEBUG_CAT_QOS, "set %s = %s\n", argv[1], argv[2]);
		if (!argv[2])
			return WAPP_INVALID_ARG;

		value = strtol(argv[2], 0, 10);
		if (errno == ERANGE) {
			err(DEBUG_CAT_QOS, "Input argument is outside of the range.\n");
			return WAPP_INVALID_ARG;
		}
		dev_list = &wapp->dev_list;
		dl_list_for_each(wdev, dev_list, struct wapp_dev, list) {
			if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
				ret = wapp->drv_ops->drv_set_QosMapCapa(wapp->drv_data, wdev->ifname, value);
				if (ret < 0)
					err(DEBUG_CAT_QOS, "set QosMapCapa, command failed.\n");
				debug(DEBUG_CAT_QOS, "set QosMapCapa = %d\n", value);
			}
		}
		return WAPP_SUCCESS;
	}

#endif

	wapp_event = (struct evt *)buffer;
	wapp_event->type = WAPP_1905_READ_BSS_CONF_REQUEST;
	wapp_event->length = strlen(argv[1]);
	/* Buffer Size = 256 - sizeof(type)-sizeof(mid)-sizeof(length)*/
	os_strlcpy((char *)wapp_event->buffer, argv[1], min(wapp_event->length+1, 253));
	send_pkt_len = sizeof(struct evt) + wapp_event->length;

	if (0 > map_1905_send_controller(wapp, (char *)buffer, send_pkt_len)) {
		err(DEBUG_CAT_MISC, "%s map_1905_send fail\n", __func__);
		return MAP_ERROR;
	}
	notice(DEBUG_CAT_MISC,
				"%s\t argv[1] = %s	len=%zu  event->buffer=%s\n",
				 __FUNCTION__,argv[1],strlen(argv[1]), wapp_event->buffer);

	memset(buffer, 0, send_pkt_len);
	return WAPP_SUCCESS;
}

struct wapp_dev* wapp_dev_list_lookup_by_band_and_type_for_cert(struct wifi_app *wapp, int band, int target_dev_type)
{
	struct wapp_dev *wdev = NULL, *target_wdev = NULL, *wdev_temp = NULL;
	struct dl_list *dev_list;
#ifdef MAP_6E_SUPPORT
	u8 is6G = 0;
#endif

	dev_list = &wapp->dev_list;
#ifdef MAP_6E_SUPPORT
	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
		if (wdev->radio == NULL)
			continue;
		if (IS_MAP_CH_6G(wdev->radio->op_ch)
			&& IS_OP_CLASS_6G(wdev->radio->opclass)) {
			is6G = 1;
			break;
		}
	}
#endif
	wdev_temp = NULL;
	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
#ifdef MAP_6E_SUPPORT
		if (is6G == 1) {
			if (wdev->radio &&
				((IS_MAP_CH_5G(wdev->radio->op_ch) && IS_OP_CLASS_5G(wdev->radio->opclass)
				&& ((band == WPS_BAND_5GL) || (band == WPS_BAND_5GH) || (band == WPS_BAND_5G)))
				|| (IS_MAP_CH_24G(wdev->radio->op_ch) && IS_OP_CLASS_24G(wdev->radio->opclass)
				&& band == WPS_BAND_24G) ||
				(IS_MAP_CH_6G(wdev->radio->op_ch) && IS_OP_CLASS_6G(wdev->radio->opclass)
				&& band == WPS_BAND_6G))
				&& wdev->dev_type == target_dev_type) {
				target_wdev = wdev;
				break;
			}
		} else {
			if (wdev->radio &&
				((IS_MAP_CH_5GL(wdev->radio->op_ch) && band == WPS_BAND_5GL)
				|| (IS_MAP_CH_5GH(wdev->radio->op_ch) && band == WPS_BAND_5GH)
				|| (IS_MAP_CH_24G(wdev->radio->op_ch) && band == WPS_BAND_24G))
				&& wdev->dev_type == target_dev_type) {
				target_wdev = wdev;
				break;
			}
		}
#else
		if (wdev->radio &&
			((IS_MAP_CH_5GL(wdev->radio->op_ch) && band == WPS_BAND_5GL)
			|| (IS_MAP_CH_5GH(wdev->radio->op_ch) && band == WPS_BAND_5GH)
			|| (IS_MAP_CH_24G(wdev->radio->op_ch) && band == WPS_BAND_24G))
			&& wdev->dev_type == target_dev_type) {
			target_wdev = wdev;
			break;
		}
#endif
	}

	if (target_wdev)
		err(DEBUG_CAT_MISC, "\033[1;36m %s, got target_wdev [%s], ifidx %d \033[0m\n",
			__func__, target_wdev->ifname, target_wdev->ifindex);
	return target_wdev;
}

struct wapp_dev* wapp_dev_list_lookup_by_band_and_type(struct wifi_app *wapp, int band, int target_dev_type)
{
	struct wapp_dev *wdev = NULL, *target_wdev = NULL, *wdev_temp = NULL;
	struct dl_list *dev_list = NULL;
	int radio_count = 0;
#ifdef MAP_6E_SUPPORT
	u8 is6G = 0;
#endif

	dev_list = &wapp->dev_list;
	radio_count = get_valid_radio_count(wapp);

#ifdef MAP_6E_SUPPORT
	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
		if (wdev->radio == NULL)
			continue;

		if (IS_MAP_CH_6G(wdev->radio->op_ch)
			&& IS_OP_CLASS_6G(wdev->radio->opclass)) {
			is6G = 1;
			break;
		}
	}
#endif
	wdev_temp = NULL;
	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
#ifdef MAP_6E_SUPPORT
		if (radio_count && is6G == 1) {
			if (wdev->radio &&
				((IS_MAP_CH_5G(wdev->radio->op_ch) && IS_OP_CLASS_5G(wdev->radio->opclass)
				&& ((band == WPS_BAND_5GL) || (band == WPS_BAND_5GH) || (band == WPS_BAND_5G))) ||
				(IS_MAP_CH_24G(wdev->radio->op_ch) && IS_OP_CLASS_24G(wdev->radio->opclass)
				&& band == WPS_BAND_24G) ||
				(IS_MAP_CH_6G(wdev->radio->op_ch) && IS_OP_CLASS_6G(wdev->radio->opclass)
				&& band == WPS_BAND_6G))
				&& wdev->dev_type == target_dev_type) {
				target_wdev = wdev;
				break;
			}
		} else if (radio_count == 3) {
			if (wdev->radio &&
				((IS_MAP_CH_5GL(wdev->radio->op_ch) && band == WPS_BAND_5GL)
				|| (IS_MAP_CH_5GH(wdev->radio->op_ch) && band == WPS_BAND_5GH)
				|| (IS_MAP_CH_24G(wdev->radio->op_ch) && band == WPS_BAND_24G))
				&& wdev->dev_type == target_dev_type) {
				target_wdev = wdev;
				break;
			}
		} else if (radio_count == 1 || radio_count == 2) {
			if (wdev->radio &&
				((IS_MAP_CH_5G(wdev->radio->op_ch) && band == WPS_BAND_5G)
				|| (IS_MAP_CH_24G(wdev->radio->op_ch) && band == WPS_BAND_24G))
				&& wdev->dev_type == target_dev_type) {
				target_wdev = wdev;
				break;
			}
		}
#else

		if (radio_count == 3) {
			if (wdev->radio &&
				((IS_MAP_CH_5GL(wdev->radio->op_ch) && band == WPS_BAND_5GL)
				|| (IS_MAP_CH_5GH(wdev->radio->op_ch) && band == WPS_BAND_5GH)
				|| (IS_MAP_CH_24G(wdev->radio->op_ch) && band == WPS_BAND_24G))
				&& wdev->dev_type == target_dev_type) {
				target_wdev = wdev;
				break;
			}
		} else if (radio_count == 2 || radio_count == 1) {
			if (wdev->radio &&
				((IS_MAP_CH_5G(wdev->radio->op_ch) && band == WPS_BAND_5G)
				|| (IS_MAP_CH_24G(wdev->radio->op_ch) && band == WPS_BAND_24G))
				&& wdev->dev_type == target_dev_type) {
				target_wdev = wdev;
				break;
			}
		}
#endif
	}

	if (target_wdev)
		err(DEBUG_CAT_MISC, "\033[1;36m %s, got target_wdev [%s], ifidx %d \033[0m\n",
				__func__, target_wdev->ifname, target_wdev->ifindex);
	return target_wdev;
}


struct wapp_dev* wapp_dev_list_lookup_fhbss_by_band_and_type(struct wifi_app *wapp, int band, int target_dev_type)
{
	struct wapp_dev *wdev, *target_wdev = NULL, *wdev_temp = NULL;
	struct dl_list *dev_list;
	int radio_count = 0;
	struct ap_dev *ap;
#ifdef MAP_6E_SUPPORT
	u8 is6G = 0;
#endif

	dev_list = &wapp->dev_list;
	radio_count = get_valid_radio_count(wapp);
#ifdef MAP_6E_SUPPORT
	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
		if (wdev->radio == NULL)
			continue;
		if (IS_MAP_CH_6G(wdev->radio->op_ch) && IS_OP_CLASS_6G(wdev->radio->opclass)) {
			is6G = 1;
			break;
		}
	}
#endif
	wdev_temp = NULL;
	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
		ap = (struct ap_dev *)wdev->p_dev;

		if (ap && (ap->isActive != WAPP_BSS_START))
			continue;
#ifdef MAP_6E_SUPPORT
		if (radio_count && is6G == 1) {
			if (wdev->radio &&
				((IS_MAP_CH_5G(wdev->radio->op_ch) && IS_OP_CLASS_5G(wdev->radio->opclass)
				&& ((band == WPS_BAND_5GL) || (band == WPS_BAND_5GH) || (band == WPS_BAND_5G))) ||
				(IS_MAP_CH_24G(wdev->radio->op_ch) && IS_OP_CLASS_24G(wdev->radio->opclass)
				&& band == WPS_BAND_24G) ||
				(IS_MAP_CH_6G(wdev->radio->op_ch) && IS_OP_CLASS_6G(wdev->radio->opclass)
				&& band == WPS_BAND_6G))
				&&(wdev->dev_type == target_dev_type) && wdev->i_am_fh_bss) {
				target_wdev = wdev;
				break;
			}
		} else if (radio_count == 3) {
			if (wdev->radio &&
				((IS_MAP_CH_5GL(wdev->radio->op_ch) && band == WPS_BAND_5GL)
				|| (IS_MAP_CH_5GH(wdev->radio->op_ch) && band == WPS_BAND_5GH)
				|| (IS_MAP_CH_24G(wdev->radio->op_ch) && band == WPS_BAND_24G))
				&& (wdev->dev_type == target_dev_type) && wdev->i_am_fh_bss) {
				target_wdev = wdev;
				break;
			}
		} else if (radio_count == 1 || radio_count == 2) {
			if (wdev->radio &&
				((IS_MAP_CH_5G(wdev->radio->op_ch) && band == WPS_BAND_5G)
				|| (IS_MAP_CH_24G(wdev->radio->op_ch) && band == WPS_BAND_24G))
				&& (wdev->dev_type == target_dev_type) && wdev->i_am_fh_bss) {
				target_wdev = wdev;
				break;
			}
		}
#else
		if (radio_count == 2) {
			if (wdev && wdev->radio &&
				((IS_MAP_CH_5G(wdev->radio->op_ch) && band == WPS_BAND_5G)
				|| (IS_MAP_CH_24G(wdev->radio->op_ch) && band == WPS_BAND_24G))
				&& wdev->dev_type == target_dev_type && wdev->i_am_fh_bss) {
				target_wdev = wdev;
				break;
			}
		} else {
			if (wdev && wdev->radio &&
				((IS_MAP_CH_5GL(wdev->radio->op_ch) && band == WPS_BAND_5GL)
				|| (IS_MAP_CH_5GH(wdev->radio->op_ch) && band == WPS_BAND_5GH)
				|| (IS_MAP_CH_24G(wdev->radio->op_ch) && band == WPS_BAND_24G))
				&& wdev->dev_type == target_dev_type && wdev->i_am_fh_bss) {
				target_wdev = wdev;
				break;
			}
		}
#endif
	}

	if (target_wdev)
		printf("\033[1;36m %s, got target_wdev [%s], ifidx %d \033[0m\n", __FUNCTION__, target_wdev->ifname, target_wdev->ifindex);
	return target_wdev;
}
int map_cmd_trigger_wps( struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	struct map_info *map = NULL;
	int wps_mode;
	int target_band = 0;
	struct wapp_dev *target_wdev = NULL;
	int radio_count = 0;

	if (!wapp) {
		err(DEBUG_CAT_EVENT, DPP_MAP_PREX"wapp instance not found..\n");
		return WAPP_INVALID_ARG;
	}
	map = wapp->map;
#ifdef MTK_HOSTAPD_SUPPORT
	int map_enable = 0;
#endif /* MTK_HOSTAPD_SUPPORT */
#ifndef MTK_HOSTAPD_SUPPORT
	char cmd[1024];
	char cmd_bk[1024];
	int ret = 0;

	memset(cmd,0,sizeof(cmd));
#endif /* MTK_HOSTAPD_SUPPORT */

	if (!argv[1] || !argv[2]) {
		err(DEBUG_CAT_EVENT, "Invalid argument\n");
		return WAPP_INVALID_ARG;
	}
	radio_count = get_valid_radio_count(wapp);

#ifdef MTK_HOSTAPD_SUPPORT
	if (wapp->map && wapp->map->MapMode) {
		if (wapp->map->MapMode != 0)
			map_enable = 1;
	}
#endif /* MTK_HOSTAPD_SUPPORT */

	/*
	  * argv[1] : mode
	  * argv[2] : band
	  * argv[3] : trigger_role bh/fh (enrollee/registrar)
	  */


	//printf("\033[1;36m %s, argv[1] [%s], argv[2] [%s] argv[3] [%s]\033[0m\n", __FUNCTION__,argv[1],argv[2],argv[3]);

	if (os_strcmp(argv[1], "PBC") == 0) {
		wps_mode = 2;
	} else {
		err(DEBUG_CAT_EVENT, "%s UNKNOWN WPS MODE [%s]\n", __func__, argv[1]);
		return WAPP_INVALID_ARG;
	}

	if (os_strcmp(argv[2], "24G") == 0) {
		target_band = WPS_BAND_24G;
	} else if (os_strcmp(argv[2], "5GL") == 0){
		if (radio_count == 2)
			target_band = WPS_BAND_5G;
		else
			target_band = WPS_BAND_5GL;
	} else if (os_strcmp(argv[2], "5GH") == 0){
		if (radio_count == 2)
			target_band = WPS_BAND_5G;
		else
			target_band = WPS_BAND_5GH;
#ifdef MAP_6E_SUPPORT
	} else if (os_strcmp(argv[2], "6G") == 0) {
		target_band = WPS_BAND_6G;
		return WAPP_INVALID_ARG;
#endif
	} else
		err(DEBUG_CAT_EVENT, "%s UNKNOWN WPS BAND [%s]\n", __func__, argv[2]);

#if 1 /* ucc don't have argv[3], judge role by bh_link_ready */
#if WEXT_SUPPORT
	if(map->bh_link_ready || map->ctrler_found) { /* bh ready won't come in case of device operating as controller */
		/*I got bh link, trigger first fh bss as wps registrar*/
		target_wdev = wapp_dev_list_lookup_fhbss_by_band_and_type(wapp, target_band, WAPP_DEV_TYPE_AP);

		if(target_wdev == NULL) {
			notice(DEBUG_CAT_EVENT, "%s not find wdev for [%s] type WAPP_DEV_TYPE_AP\n",
					__func__, target_band?"5G":"2G");
			return WAPP_INVALID_ARG;
		} else {
			u8 WscConfMode = 4;
			u8 WscConfStatus = 2;
			u8 WscGetConf = 1;

			wapp_set_wsc_conf_mode(wapp, (const char *)target_wdev->ifname,
							(char *)&WscConfMode,1);
			wapp_set_wsc_mode(wapp, (const char *)target_wdev->ifname,
							(char *)&wps_mode,
							(size_t)sizeof(wps_mode));
			wapp_set_wsc_conf_status(wapp, (const char *)target_wdev->ifname,
							(char *)&WscConfStatus,1);
			wapp_set_wsc_get_conf(wapp, (const char *)target_wdev->ifname,
							(char *)&WscGetConf,1);
		}
	} else {
		/*I don't have bh link, trigger wps as enrollee*/
#ifdef MAP_R2
		target_wdev = wapp_dev_list_lookup_by_band_and_type(wapp, target_band, WAPP_DEV_TYPE_STA);
#else
		target_wdev = map->bh_wifi_dev;
#endif
		if(target_wdev == NULL) {
			notice(DEBUG_CAT_EVENT, "%s not find wdev for [%s] type WAPP_DEV_TYPE_APCLI\n",
					__func__, target_band?"5G":"2G");
		} else {
			u8 set = 1;
			/* Add function call for OID call og ApCliEnable = 1 */
			wapp_set_apcli_mode(wapp, (const char *)target_wdev->ifname,
							(char *)&set,1);
			wapp_set_wsc_conf_mode(wapp, (const char *)target_wdev->ifname,
							(char *)&set,1);
			wapp_set_wsc_mode(wapp, (const char *)target_wdev->ifname,
							(char *)&wps_mode,
							(size_t)sizeof(wps_mode));
			wapp_set_wsc_get_conf(wapp, (const char *)target_wdev->ifname,
							(char *)&set,1);
		}
	}
#else
	if(map->bh_link_ready || map->ctrler_found) { /* bh ready won't come in case of device operating as controller */
		/*I got bh link, trigger first fh bss as wps registrar*/
		target_wdev = wapp_dev_list_lookup_fhbss_by_band_and_type(wapp, target_band, WAPP_DEV_TYPE_AP);

		if(target_wdev == NULL) {
			notice(DEBUG_CAT_EVENT, "%s not find wdev for [%s] type WAPP_DEV_TYPE_AP\n",
					 __func__, target_band?"5G":"2G");
			return WAPP_INVALID_ARG;
		} else {
#ifdef MTK_HOSTAPD_SUPPORT
			if (wapp->drv_ops->drv_send_wps_pbc)
				wapp->drv_ops->drv_send_wps_pbc(wapp->drv_data, target_wdev->ifname, 0);

#else
			ret = os_snprintf(cmd, sizeof(cmd),
				"mwctl %s set WscConfMode=4;mwctl %s set WscMode=%d;mwctl %s set WscConfStatus=2;mwctl %s set WscGetConf=1",
				target_wdev->ifname,target_wdev->ifname,wps_mode,target_wdev->ifname,target_wdev->ifname);
			if (os_snprintf_error(sizeof(cmd), ret))
				return WAPP_INVALID_ARG;
#endif
		}
	} else {
		/*I don't have bh link, trigger wps as enrollee*/
#ifdef MAP_R2
		target_wdev = wapp_dev_list_lookup_by_band_and_type(wapp, target_band, WAPP_DEV_TYPE_STA);
#else
		target_wdev = map->bh_wifi_dev;
#endif
		if(target_wdev == NULL) {
			notice(DEBUG_CAT_EVENT, "%s not find wdev for [%s] type WAPP_DEV_TYPE_APCLI\n",
					 __func__, target_band?"5G":"2G");
		} else {
#ifdef MTK_HOSTAPD_SUPPORT
			wapp->wsc_bh_wait = TRUE;
			if (wapp->drv_ops->drv_send_wps_pbc)
				wapp->drv_ops->drv_send_wps_pbc(wapp->drv_data, target_wdev->ifname, map_enable);

#else
			ret = os_snprintf(cmd, sizeof(cmd),
				"mwctl %s set ApCliEnable=1;mwctl %s set WscConfMode=1;mwctl %s set WscMode=%d;mwctl %s set WscGetConf=1",
				target_wdev->ifname,target_wdev->ifname,target_wdev->ifname,wps_mode,target_wdev->ifname);
			if (os_snprintf_error(sizeof(cmd), ret))
				return WAPP_INVALID_ARG;
#endif /* MTK_HOSTAPD_SUPPORT */
		}
	}


#ifndef MTK_HOSTAPD_SUPPORT
	notice(DEBUG_CAT_EVENT, "\033[1;36m cmd [%s] \033[0m\n", cmd);
	if (system(cmd) == -1)
		err(DEBUG_CAT_EVENT, "[%s] (%d): system() call return value is -1\n", __func__, __LINE__);
#endif /* MTK_HOSTAPD_SUPPORT */
#endif /* WEXT_SUPPORT */

#ifndef MTK_HOSTAPD_SUPPORT
	memset(cmd_bk,0,sizeof(cmd_bk));
	ret = os_snprintf(cmd_bk, sizeof(cmd_bk), "echo \"%s\" > /tmp/wps_dbg", cmd);
	if (os_snprintf_error(sizeof(cmd), ret))
		return WAPP_INVALID_ARG;
	if (system(cmd_bk) == -1)
		err(DEBUG_CAT_EVENT, "[%s] (%d): system() call return value is -1\n", __func__, __LINE__);
#endif /* MTK_HOSTAPD_SUPPORT */
#else /* normal usage, judge by argv[3] : TODO */

	if (os_strcmp(argv[3], "bh") == 0) {
		//trigger wps as enrollee
	} else if (os_strcmp(argv[3], "fh") == 0) {
		//trigger wps as registrar
	} else {
		err(DEBUG_CAT_EVENT,
				"%s UNKNOWN WPS ROLE [%s]\n", __FUNCTION__,argv[3]);
		return WAPP_INVALID_ARG;
	}
#endif
	debug(DEBUG_CAT_EVENT, "[%s] (%d): wps_mode : %d\n", __func__, __LINE__, wps_mode);
	return WAPP_SUCCESS;
}
#ifdef MAP_6E_SUPPORT
int map_cmd_ch_set_req(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	unsigned char almac[6] = {0};
	unsigned char wdev_identifier[ETH_ALEN] = {0};
	u8 opclass = 0, channel = 0;
	struct channel_setting *setting = NULL;
	struct wapp_dev *wdev = NULL;
	u8 j = 0, count = 1;
	char *buf = NULL;
	int ret = 0, value = 0;

	if (argc != 5) {
		printf("Error! Correct Format: wappctrl ra0 map set_channel <ALID> <ifname> <channel> <opclass>\n");
		return WAPP_INVALID_ARG;
	}

	ret = hwaddr_aton(argv[1], almac);
	if (ret) {
		printf("%s: incorrect almac address %s\n", __func__, argv[1]);
		return WAPP_INVALID_ARG;
	}
	value = strtol(argv[3], NULL, 10);
	if (value < 0 || value > 255)
		printf("invalid channel (%d).\n",  value);
	else
		channel = value;

	value = strtol(argv[4], NULL, 10);
	if (value < 0 || value > 255)
		printf("invalid opclass (%d).\n",  value);
	else
		opclass = value;

	printf("almac address "MACSTR" ch(%u) op(%u)\n", MAC2STR(almac), channel, opclass);

	wdev = wapp_dev_list_lookup_by_band_and_type(wapp, WPS_BAND_6G, WAPP_DEV_TYPE_AP);
	if (wdev == NULL)
		return 0;
	if (wdev->radio == NULL)
		return 0;

	setting = os_zalloc(512);
	if (setting == NULL) {
		printf("Memory Alloc failed\n");
		return 0;
	}

	buf = (char *)setting;
	os_memcpy(setting->almac, almac, ETH_ALEN);
	setting->ch_set_num++;

	while (j < count) {
		MAP_GET_RADIO_IDNFER(wdev->radio, wdev_identifier);
		os_memcpy(setting->chinfo[j].identifier, wdev_identifier, ETH_ALEN);
		os_memcpy(setting->chinfo[j].ifname, wdev->ifname, ETH_ALEN);
#ifdef MAP_EHT_SUPPORT
		setting->chinfo[j].channel = get_centre_freq_ch(wapp, wdev, channel, opclass, wdev->HE_EXTCHA);
#else
		setting->chinfo[j].channel = get_centre_freq_ch(wapp, wdev, channel, opclass, 0);
#endif
		setting->chinfo[j].op_class = opclass;
		if (opclass == 132 || opclass == 133 || opclass == 134) {
			setting->chinfo[j+1].channel = channel;
			setting->chinfo[j+1].op_class = 131;
			os_memcpy(setting->chinfo[j+1].identifier, wdev_identifier, ETH_ALEN);
			os_memcpy(setting->chinfo[j+1].ifname, wdev->ifname, ETH_ALEN);
		}
		setting->ch_set_num++;
		j++;
	}
	map_config_channel_setting_msg(wapp, buf, NULL, NULL);
	os_free(setting);

	return 0;
}

int map_cmd_off_ch_req(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	struct off_ch_scan_req_ext_msg_s *scan_msg = NULL;
	u8 buf[4000] = {0};
	unsigned char ch_list_24g[3] = {2, 7, 11};
	unsigned char ch_list_5g[3] = {48, 149, 165};
	unsigned char ch_list_6g[3] = {37, 77, 133};
	int value = 0;

	if (argc != 2) {
		printf("Correct Format: wappctrl ra0 map off_ch_scan <mode:0/1>\n");
		printf("mode:0(SCAN_MODE_CH)/1(SCAN_MODE_BAND)\n");
		return WAPP_INVALID_ARG;
	}

	scan_msg = (struct off_ch_scan_req_ext_msg_s *)buf;

	value = strtol(argv[1], NULL, 10);
	if (value < 0 || value > 255)
		printf("invalid mode (%d).\n",  value);
	else
		scan_msg->mode = value;

	scan_msg->bw = 0;
	scan_msg->total_band = 3;

	if (scan_msg->mode == SCAN_MODE_CH) {
		scan_msg->chbody[0].band = WPS_BAND_24G;
		scan_msg->chbody[1].band = WPS_BAND_5G;
		scan_msg->chbody[2].band = WPS_BAND_6G;

		os_memcpy(scan_msg->chbody[0].ch_list, ch_list_24g, 3);
		os_memcpy(scan_msg->chbody[1].ch_list, ch_list_5g, 3);
		os_memcpy(scan_msg->chbody[2].ch_list, ch_list_6g, 3);
	} else if (scan_msg->mode == SCAN_MODE_BAND) {
		scan_msg->chbody[0].band = WPS_BAND_24G;
		scan_msg->chbody[1].band = WPS_BAND_5G;
		scan_msg->chbody[2].band = WPS_BAND_6G;
	}

	map_prepare_off_channel_scan_req(wapp, (char *)buf, WAPP_USER_SET_NET_OPT_SCAN_REQ);

	return 0;
}

#ifdef MAP_R6
/*Need to store the data in mapd_cfg once diff is found in new bsta credentials and old from mapd_cfg*/
int save_map_parameters_R6(struct wifi_app *wapp, char *param, char *value, param_type type)
{
#ifdef OPENWRT_SUPPORT
	struct kvc_context *dat_ctx = NULL;
	int ret = 0;
	const char *file = NULL;

	debug(DEBUG_CAT_MLO, "%s param(%s) value(%s)\n", __func__, param, value);

	if (type == NON_DRIVER_PARAM && wapp && wapp->map) {
		dat_ctx = kvc_load((const char *)wapp->map->map_cfg, LF_FLOCK|LF_KEY_CASE_SENSITIVE);
		if (!dat_ctx) {
			err(DEBUG_CAT_MLO, "load file(%s) fail\n", wapp->map->map_user_cfg);
			ret = -1;
			goto out;
		}
		ret = kvc_set(dat_ctx, (const char *)param, (const char *)value);
		if (ret) {
			err(DEBUG_CAT_MLO, "set param(%s) fail\n", param);
			goto out;
		}
		ret = kvc_commit(dat_ctx);
		if (ret) {
			err(DEBUG_CAT_MLO, "write param(%s) fail\n", param);
			goto out;
		}
	} else {
		file = get_dat_path_by_ord(0);
		if (!file) {
			err(DEBUG_CAT_MLO, "invalid file!!! type(%d)\n", type);
			return -1;
		}
		dat_ctx = kvc_load((const char *)file, LF_FLOCK|LF_KEY_CASE_SENSITIVE);
		if (!dat_ctx) {
			err(DEBUG_CAT_MLO, "load file(%s) fail\n", file);
			ret = -1;
			goto out;
		}

		ret = kvc_set(dat_ctx, (const char *)param, (const char *)value);
		if (ret) {
			err(DEBUG_CAT_MLO, "set param(%s) fail\n", param);
			goto out;
		}
		ret = kvc_commit(dat_ctx);
		if (ret) {
			err(DEBUG_CAT_MLO, "write param(%s) fail\n", param);
			goto out;
		}
	}
out:
	if (file)
		free_dat_path(file);
	if (dat_ctx)
		kvc_unload(dat_ctx);
	if (ret)
		return -1;
	else
		return 0;
#else
	char cmd_buffer[256] = {0};

	os_snprintf(cmd_buffer, sizeof(cmd_buffer), "nvram_set 2860 %s %s &", param, value);
	if (system(cmd_buffer) == -1)
		err(DEBUG_CAT_MLO, "[%s] (%d): system() call return value is -1\n", __func__, __LINE__);
	debug(DEBUG_CAT_MLO, "get_map_parameter %s = %s\n", param, value);

	return 0;
#endif
}

unsigned char WscGetEncrypType_R6(char *EncrypTypeString)
{
	if (os_strlen(EncrypTypeString) == 0)
		return 0;
	if (!os_strcmp(EncrypTypeString, "NONE"))
		return WSC_ENCRTYPE_NONE;
	else if (!os_strcmp(EncrypTypeString, "WEP"))
		return WSC_ENCRTYPE_WEP;
	else if (!os_strcmp(EncrypTypeString, "TKIP"))
		return WSC_ENCRTYPE_TKIP;
	else if (!os_strcmp(EncrypTypeString, "AES"))
		return WSC_ENCRTYPE_AES;
	else if (!os_strcmp(EncrypTypeString, "TKIPAES"))
		return (WSC_ENCRTYPE_AES | WSC_ENCRTYPE_TKIP);
	return 0;
}

void read_backhaul_configs_R6(struct wifi_app *wapp)
{
	int i = 0;
	char value[200] = {0};
	char ssid[33] = {0};
	char key[65] = {0};
	char param[65];
	char role[5] = {0};
	char ret = 0;

	ret = os_snprintf(param, sizeof(param), "DeviceRole");

	if (os_snprintf_error(sizeof(param), ret))
		err(DEBUG_CAT_MLO, "%s %d snprintf error\n", __func__, __LINE__);

	get_map_parameters(wapp->map, param, role, NON_DRIVER_PARAM, sizeof(role));

	err(DEBUG_CAT_MLO, "DeviceRole %s\n", role);
	/*If device is agent*/
	if (os_strncmp(role, "2", 1) == 0) {
		for (i = 0; i < MAX_MLO_NON_SETUP_LINK; i++) {
			ret = os_snprintf(param, sizeof(param), "BhProfile%dValid", i);
			if (os_snprintf_error(sizeof(param), ret))
				err(DEBUG_CAT_MLO, "%s %d snprintf error\n", __func__, __LINE__);

			get_map_parameters_user_cfg(wapp->map, param, value, NON_DRIVER_PARAM, sizeof(value));

			err(DEBUG_CAT_MLO, "BhProfile%dValid : %s\n", i, value);
			if (strncmp(value, "0", 1) == 0)
				break;
			ret = os_snprintf(param, sizeof(param), "BhProfile%dSsid", i);

			if (os_snprintf_error(sizeof(param), ret))
				err(DEBUG_CAT_MLO, "%s %d snprintf error\n", __func__, __LINE__);

			get_map_parameters_user_cfg(wapp->map, param, ssid, NON_DRIVER_PARAM, sizeof(ssid));

			os_memcpy(wapp->wps_reconf_db.data[i].ssid, ssid, strlen(ssid)); /*SSID*/
			wapp->wps_reconf_db.data[i].ssid_len = strlen(ssid);

			ret = os_snprintf(param, sizeof(param), "BhProfile%dWpaPsk", i);

			if (os_snprintf_error(sizeof(param), ret))
				err(DEBUG_CAT_MLO, "%s %d snprintf error\n", __func__, __LINE__);

			get_map_parameters_user_cfg(wapp->map, param, key, NON_DRIVER_PARAM, MAX_PROFILE_KEYLEN); /* read max Key length */

			os_memcpy(wapp->wps_reconf_db.data[i].key, key, strlen(key)); /*key*/
			wapp->wps_reconf_db.data[i].key_len = strlen(key);

			ret = os_snprintf(param, sizeof(param), "BhProfile%dAuthMode", i);
			if (os_snprintf_error(sizeof(param), ret))
				err(DEBUG_CAT_MLO, "%s %d snprintf error\n", __func__, __LINE__);
			get_map_parameters_user_cfg(wapp->map, param, value, NON_DRIVER_PARAM, sizeof(value));

			wapp->wps_reconf_db.data[i].auth_type = WscGetAuthType(value);  /*auth type*/

			ret = os_snprintf(param, sizeof(param), "BhProfile%dEncrypType", i);
			if (os_snprintf_error(sizeof(param), ret))
				err(DEBUG_CAT_MLO, "%s %d snprintf error\n", __func__, __LINE__);
			get_map_parameters_user_cfg(wapp->map, param, value, NON_DRIVER_PARAM, sizeof(value));

			wapp->wps_reconf_db.data[i].encr_type = WscGetEncrypType_R6(value); /*encrypt type*/
		}
		wapp->wps_reconf_db.wps_cred_reconfig_num = i;
	}
}

void update_backhaul_cfgs_R6(struct wifi_app *wapp, struct wps_cred_reconf *wps_data)
{
	int i = 0, ret = 0;
	char value[200] = {0};
	char param[65];
	char role[5] = {0};
	struct map_info *map;

	map = wapp->map;
	debug(DEBUG_CAT_CAP, "Entered  set_backhaul_configs_R6 in mapd related conf files\n");
	get_map_parameters(wapp->map, "DeviceRole", role, NON_DRIVER_PARAM, sizeof(role));

	err(DEBUG_CAT_MLO, DPP_MAP_PREX"DeviceRole %s\n", role);
	/*If device is agent*/
	if (os_strncmp(role, "2", 1) == 0) {
		for (i = 0; i < MAX_NUM_OF_RADIO; i++) {
			ret = os_snprintf(param, sizeof(param), "BhProfile%dValid", i);
			if (os_snprintf_error(sizeof(param), ret))
				err(DEBUG_CAT_MLO, "[%s] os_snprintf fail\n", __func__);
			if (map->MapMode == MAP_CERT_MODE)
				get_map_parameters(wapp->map, param, value, NON_DRIVER_PARAM, sizeof(value));
			else
				get_parameters((char *)wapp->map->map_user_cfg, param, value, NON_DRIVER_PARAM, sizeof(value));
			if (strncmp(value, "0", 1) == 0)
				continue;
			/*update ssid*/
			ret = os_snprintf(param, sizeof(param), "BhProfile%dSsid", i);
			if (os_snprintf_error(sizeof(param), ret))
				err(DEBUG_CAT_MLO, "[%s] os_snprintf fail\n", __func__);
			/*1.based on CERT or Turnkey mode, mapd_cfg and mapd_user_cfg would be updated inside this function
			 *2. using 0th idx values for wps_data->data[] array because same data is stored at first and second idx.
			 */
			save_map_parameters(wapp, param, (char *)wps_data->data[0].ssid, NON_DRIVER_PARAM);
			/*to store the data in mapd_cfg */
			save_map_parameters_R6(wapp, param, (char *)wps_data->data[0].ssid, NON_DRIVER_PARAM);

			/*update key*/
			ret = os_snprintf(param, sizeof(param), "BhProfile%dWpaPsk", i);
			if (os_snprintf_error(sizeof(param), ret))
				err(DEBUG_CAT_MLO, "[%s] os_snprintf fail\n", __func__);
			save_map_parameters(wapp, param, (char *)wps_data->data[0].key, NON_DRIVER_PARAM);
			save_map_parameters_R6(wapp, param, (char *)wps_data->data[0].key, NON_DRIVER_PARAM);

			/*auth type*/
			ret = os_snprintf(param, sizeof(param), "BhProfile%dAuthMode", i);
			if (os_snprintf_error(sizeof(param), ret))
				err(DEBUG_CAT_MLO, "%s %d snprintf error\n", __func__, __LINE__);
			ret = os_snprintf(value, sizeof(value), "%s", WscGetAuthTypeStr(wps_data->data[0].auth_type));
			if (os_snprintf_error(sizeof(value), ret))
				err(DEBUG_CAT_MLO, "%s %d snprintf error\n", __func__, __LINE__);

			save_map_parameters(wapp, param, value, NON_DRIVER_PARAM);
			save_map_parameters_R6(wapp, param, value, NON_DRIVER_PARAM);

			/*encrypt type*/
			ret = os_snprintf(param, sizeof(param), "BhProfile%dEncrypType", i);
			if (os_snprintf_error(sizeof(param), ret))
				err(DEBUG_CAT_MLO, "%s %d snprintf error\n", __func__, __LINE__);

			ret = os_snprintf(value, sizeof(value), "%s", WscGetEncryTypeStr(wps_data->data[0].encr_type));
			if (os_snprintf_error(sizeof(value), ret))
				err(DEBUG_CAT_MLO, "%s %d snprintf error\n", __func__, __LINE__);
			save_map_parameters(wapp, param, value, NON_DRIVER_PARAM);
			save_map_parameters_R6(wapp, param, value, NON_DRIVER_PARAM);
		}
	}
}

/*remove network for every apcli interface b4 sending connect request
 */

void remove_network_all(struct wifi_app *wapp)
{
	struct wapp_dev *wdev = NULL, *wdev_tmp = NULL;

	dl_list_for_each_safe(wdev, wdev_tmp, &wapp->dev_list, struct wapp_dev, list) {
		if (wdev->radio && wdev->dev_type == WAPP_DEV_TYPE_STA) {
#ifdef MTK_HOSTAPD_SUPPORT
			if (wapp->drv_ops->drv_send_remove_network)
				wapp->drv_ops->drv_send_remove_network(wapp->drv_data, wdev->ifname);
#endif
		}
	}
}


/*
 * find highest band and send connect req
 */

void get_band_send_connect_req(struct wifi_app *wapp, struct backhaul_connect_request *bh, char *lbuf)
{
	struct wapp_dev *wdev = NULL, *wdev_tmp = NULL;
	/*
	 * To store what radio band is being supported by device
	 * 0 --> 2G
	 * 1 --> 5GL
	 * 2 --> 5GH
	 * 3 --> 6G , 4 & 5 --> future use
	 */
	u8 highest_band[MAX_NUM_OF_RADIO] = {0};

	dl_list_for_each_safe(wdev, wdev_tmp, &wapp->dev_list, struct wapp_dev, list) {
		if (wdev->radio) {
			/*Consider the wdev which are STA and part of the BH STA MLD Group*/
			if (IS_MAP_CH_24G(wdev->radio->op_ch) && IS_OP_CLASS_24G(wdev->radio->opclass)
			&& wdev->dev_type == WAPP_DEV_TYPE_STA && wdev->apcli_mlo_enable == 1)
				highest_band[0] = 1;
			else if (IS_MAP_CH_5GL(wdev->radio->op_ch) && IS_OP_CLASS_5GL(wdev->radio->opclass)
			&& wdev->dev_type == WAPP_DEV_TYPE_STA && wdev->apcli_mlo_enable == 1)
				highest_band[1] = 1;
			else if (IS_MAP_CH_5GH(wdev->radio->op_ch) && IS_OP_CLASS_5GH(wdev->radio->opclass)
			&& wdev->dev_type == WAPP_DEV_TYPE_STA && wdev->apcli_mlo_enable == 1)
				highest_band[2] = 1;
#ifdef MAP_6E_SUPPORT
			else if (IS_MAP_CH_6G(wdev->radio->op_ch) && IS_OP_CLASS_6G(wdev->radio->opclass)
			&& wdev->dev_type == WAPP_DEV_TYPE_STA && wdev->apcli_mlo_enable == 1)
				highest_band[3] = 1;
#endif
			}
	}
	/*
	 * Pick the highest band supported and send the backhaul connect msg
	 */
	if (highest_band[3]) {
		dl_list_for_each_safe(wdev, wdev_tmp, &wapp->dev_list, struct wapp_dev, list) {
			if (wdev->radio) {
#ifdef MAP_6E_SUPPORT
				if (IS_MAP_CH_6G(wdev->radio->op_ch) && IS_OP_CLASS_6G(wdev->radio->opclass)
				&& wdev->dev_type == WAPP_DEV_TYPE_STA) {
					os_memcpy(bh->backhaul_mac, wdev->mac_addr, ETH_ALEN);
					DBGPRINT(RT_DEBUG_OFF, DPP_MAP_PREX "6G wdev Found : MAC addrs "MACSTR"\n",
					MAC2STR(bh->backhaul_mac));
					bh->channel = wdev->radio->op_ch;
					bh->bw =  chan_mon_get_bw_from_op_class(wdev->radio->opclass);
					bh->oper_class = wdev->radio->opclass;
					/*remove network for every apcli interface b4 sending connect request*/
					remove_network_all(wapp);
					map_config_backhaul_connect_msg(wapp, lbuf, NULL, NULL);
					break;
			}
#endif
			}
		}
	} else if (highest_band[2]) {
		dl_list_for_each_safe(wdev, wdev_tmp, &wapp->dev_list, struct wapp_dev, list) {
			if (wdev->radio && IS_MAP_CH_5GH(wdev->radio->op_ch) && IS_OP_CLASS_5GH(wdev->radio->opclass)
			&& wdev->dev_type == WAPP_DEV_TYPE_STA){
				os_memcpy(bh->backhaul_mac, wdev->mac_addr, ETH_ALEN);
				DBGPRINT(RT_DEBUG_OFF, DPP_MAP_PREX "5GH wdev Found : MAC addr "MACSTR"\n",
				MAC2STR(bh->backhaul_mac));
				bh->channel = wdev->radio->op_ch;
				bh->bw =  chan_mon_get_bw_from_op_class(wdev->radio->opclass);
				bh->oper_class = wdev->radio->opclass;
				/*remove network for every apcli interface b4 sending connect request*/
				remove_network_all(wapp);
				map_config_backhaul_connect_msg(wapp, lbuf, NULL, NULL);
				break;
			}
		}
	} else if (highest_band[1]) {
		dl_list_for_each_safe(wdev, wdev_tmp, &wapp->dev_list, struct wapp_dev, list) {
			if (wdev->radio && IS_MAP_CH_5GL(wdev->radio->op_ch) && IS_OP_CLASS_5GL(wdev->radio->opclass)
			&& wdev->dev_type == WAPP_DEV_TYPE_STA){
				os_memcpy(bh->backhaul_mac, wdev->mac_addr, ETH_ALEN);
				DBGPRINT(RT_DEBUG_OFF, DPP_MAP_PREX "5GL wdev Found : MAC addr "MACSTR"\n",
				MAC2STR(bh->backhaul_mac));
				bh->channel = wdev->radio->op_ch;
				bh->bw =  chan_mon_get_bw_from_op_class(wdev->radio->opclass);
				bh->oper_class = wdev->radio->opclass;
				/*remove network for every apcli interface b4 sending connect request*/
				remove_network_all(wapp);
				map_config_backhaul_connect_msg(wapp, lbuf, NULL, NULL);
				break;
			}
		}
	} else if (highest_band[0]) {
		dl_list_for_each_safe(wdev, wdev_tmp, &wapp->dev_list, struct wapp_dev, list) {
			if (wdev->radio && IS_MAP_CH_24G(wdev->radio->op_ch) && IS_OP_CLASS_24G(wdev->radio->opclass)
			&& wdev->dev_type == WAPP_DEV_TYPE_STA){
				os_memcpy(bh->backhaul_mac, wdev->mac_addr, ETH_ALEN);
				DBGPRINT(RT_DEBUG_OFF, DPP_MAP_PREX "24G wdev Found : MAC addr "MACSTR"\n",
				MAC2STR(bh->backhaul_mac));
				bh->channel = wdev->radio->op_ch;
				bh->bw =  chan_mon_get_bw_from_op_class(wdev->radio->opclass);
				bh->oper_class = wdev->radio->opclass;
				/*remove network for every apcli interface b4 sending connect request*/
				remove_network_all(wapp);
				map_config_backhaul_connect_msg(wapp, lbuf, NULL, NULL);
				break;
			}
		}
	}
}

int map_config_set_bh_reconfig(struct wifi_app *wapp,  char *msg_buf, unsigned char *sta_addr, unsigned short buf_len)
{
	struct wps_cred_reconf *wps_data = NULL;
	struct wps_cred_reconf_info *wsc_data = NULL;
	struct backhaul_connect_request *bh = NULL;
	struct wapp_dev *apcli_wdev = NULL;
	unsigned char i = 0;
	u8 ZERO_MAC_ADDR[MAC_ADDR_LEN] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
	struct map_info *map;
	unsigned int len = sizeof(struct backhaul_connect_request);
	char *lbuf = os_zalloc(len);

	if (lbuf == NULL) {
		err(DEBUG_CAT_BH_RECONF, "Malloc failed");
		return -1;
	}
	unsigned int len2 =  sizeof(struct wps_cred_reconf);
	BOOLEAN diff_found_turnkey = FALSE;
	BOOLEAN diff_found_api = FALSE;
	wsc_apcli_config_msg *apcli_config_msg;
	struct wps_credential_reconfig_info *pdata;
	unsigned int send_pkt_len = 0;
	char lbuf1[512] = {0};
	struct apcli_association_info *apcli_stat_info;
	struct wsc_m8_conf_cert_db *cert_db = NULL;
	struct wsc_m8_conf_cert_db *tmp_cert_db = NULL;
	int diff_in_cred = 1;

	memset(lbuf, 0, sizeof(struct backhaul_connect_request));

	if (!msg_buf || buf_len == 0 || buf_len > len2) {
		err(DEBUG_CAT_BH_RECONF,
				"len invalid buf_len:%d, len:%d\n", buf_len, (int)sizeof(struct backhaul_connect_request));
		os_free(lbuf);
		lbuf = NULL;
		return -1;
	}

	map = wapp->map;
	wps_data = os_zalloc(sizeof(struct wps_cred_reconf));
	if (!wps_data) {
		err(DEBUG_CAT_BH_RECONF, "fail to malloc wps_cred_reconf\n");
		if (lbuf) {
			os_free(lbuf);
			lbuf = NULL;
		}
		return -1;
	}
	wsc_data = (struct wps_cred_reconf_info *)msg_buf;

	wpa_hexdump(MSG_ERROR, DPP_MAP_PREX "MSG Buff is", msg_buf, buf_len);

	/*Only one bsta wsc reconfig */
	if (wps_data) {
		/*Fill wsc data*/
		wps_data->wps_cred_reconfig_num = MAX_MLO_NON_SETUP_LINK;
		wps_data->bsta_mld_present = wsc_data->bsta_mld_present;

		/*fill for 0,1,2th idx the same values as only one bsta wsc would come*/
		for (i = 0; i < MAX_MLO_NON_SETUP_LINK; i++) {
			wps_data->data[i].ssid_len = wsc_data->ssid_len;
			if (wsc_data->ssid_len <= MAX_LEN_OF_SSID) {
				os_memcpy(wps_data->data[i].ssid, wsc_data->ssid, wsc_data->ssid_len);
				wps_data->data[i].ssid[wsc_data->ssid_len] = '\0';
			} else {
				os_memcpy(wps_data->data[i].ssid, wsc_data->ssid, MAX_LEN_OF_SSID);
				wps_data->data[i].ssid[MAX_LEN_OF_SSID] = '\0';
			}
			wps_data->data[i].auth_type = wsc_data->auth_mode;
			wps_data->data[i].encr_type = wsc_data->encr_type;
			wps_data->data[i].key_len = wsc_data->key_len;
			os_memcpy(wps_data->data[i].key, wsc_data->key, 64 + 1);
		}
	}

	/* update wapp->wps_reconf_db with the data received from mapd_ */
	read_backhaul_configs_R6(wapp);

	if (map->MapMode != TURNKEY_MODE) {
		/*If cert local db is empty, initialse it with the credentials from mapd_user_cfg*/
		cert_db = &wapp->wsc_m8_cert_db;
		tmp_cert_db = (struct wsc_m8_conf_cert_db *)os_zalloc(sizeof(struct wsc_m8_conf_cert_db));
		if (tmp_cert_db == NULL) {
			debug(DEBUG_CAT_WSC_M8, DPP_MAP_PREX "os_zalloc failed.\n");
			if (wps_data) {
				os_free(wps_data);
				wps_data = NULL;
			}
			if (lbuf) {
				os_free(lbuf);
				lbuf = NULL;
			}
			return 0;
		}
		if (os_memcmp(cert_db, tmp_cert_db, sizeof(struct wsc_m8_conf_cert_db)) == 0) {
			debug(DEBUG_CAT_WSC_M8, DPP_MAP_PREX "CERT M8 Case local db is empty update from mapd files.\n");
			cert_db->ssid_len = wapp->wps_reconf_db.data[0].ssid_len;
			os_memcpy(cert_db->ssid, wapp->wps_reconf_db.data[0].ssid, cert_db->ssid_len);
			cert_db->auth_type = wapp->wps_reconf_db.data[0].auth_type;
			cert_db->encr_type = wapp->wps_reconf_db.data[0].encr_type;
			cert_db->key_len = wapp->wps_reconf_db.data[0].key_len;
			os_memcpy(cert_db->key, wapp->wps_reconf_db.data[0].key, cert_db->key_len);
		}
		if (tmp_cert_db) {
			os_free(tmp_cert_db);
			tmp_cert_db = NULL;
		}
	}
	/*compare with the mapd_cfg profiles and find out if there is
	 *any change in any profile with the wsc_credentials we
	 *received from 1905 through mapd
	 */
	for (i = 0; i < wapp->wps_reconf_db.wps_cred_reconfig_num; i++) {
		apcli_stat_info = &wapp->cli_assoc_info;
		if (!(apcli_stat_info->apcli_assoc_state == WAPP_APCLI_DISASSOCIATED)) {
			apcli_wdev = wapp_dev_list_lookup_by_ifindex(wapp, apcli_stat_info->interface_index);
			if (!apcli_wdev) {
				err(DEBUG_CAT_BH_RECONF, "apcli for wdev NULL\n");
				continue;
			}
		}

		/*This comparison would have taken O(N^2) time bt it would take O(N)
		 *only as inside wps_data, for diff idx, same profiles are stored
		 */
		if (((wapp->wps_reconf_db.data[i].ssid_len == wps_data->data[i].ssid_len) &&
			!os_memcmp(wapp->wps_reconf_db.data[i].ssid, wps_data->data[i].ssid, wapp->wps_reconf_db.data[i].ssid_len)) &&
				(wapp->wps_reconf_db.data[i].auth_type == wps_data->data[i].auth_type) &&
				(wapp->wps_reconf_db.data[i].encr_type == wps_data->data[i].encr_type) &&
				(wapp->wps_reconf_db.data[i].key_len == wps_data->data[i].key_len &&
				!os_memcmp(wapp->wps_reconf_db.data[i].key, wps_data->data[i].key, wapp->wps_reconf_db.data[i].key_len))
		) {
			continue;
		} else {
			diff_found_turnkey = TRUE;
			break;
		}
	}

	debug(DEBUG_CAT_WSC_M8, DPP_MAP_PREX "wsc_m8_diff : %d\n", diff_found_turnkey);
	/*update mapd_cfg and mapd_user_cfg if diff is found*/
	if (diff_found_turnkey)
		update_backhaul_cfgs_R6(wapp, wps_data);

	wapp->wsc_m8_diff = diff_found_turnkey;

	if (map->MapMode != TURNKEY_MODE) {
		diff_found_api = FALSE;
		i = 0;
		bh = (struct backhaul_connect_request *)lbuf;

		debug(DEBUG_CAT_WSC_M8, DPP_MAP_PREX "bsta mld not present conn will be made using wsc_m8 change.\n");
		debug(DEBUG_CAT_WSC_M8, DPP_MAP_PREX "wps wps_data->bsta_mld_present : %d\n", wps_data->bsta_mld_present);
		debug(DEBUG_CAT_WSC_M8, DPP_MAP_PREX "wps ssid : %s\n", wps_data->data[i].ssid);
		debug(DEBUG_CAT_WSC_M8, DPP_MAP_PREX "wps bssid : "MACSTR"\n", MAC2STR(wps_data->data[i].mac_addr));
		debug(DEBUG_CAT_WSC_M8, DPP_MAP_PREX "wps ssid : %s\n", wps_data->data[i].ssid);
		debug(DEBUG_CAT_WSC_M8, DPP_MAP_PREX "wps auth mode : %d\n", wps_data->data[i].auth_type);
		debug(DEBUG_CAT_WSC_M8, DPP_MAP_PREX "wps encryption : %d\n", wps_data->data[i].encr_type);
		debug(DEBUG_CAT_WSC_M8, DPP_MAP_PREX "wps key : %s\n", wps_data->data[i].key);
		debug(DEBUG_CAT_WSC_M8, DPP_MAP_PREX "wps key_len: %zd\n", wps_data->data[i].key_len);


		debug(DEBUG_CAT_WSC_M8, DPP_MAP_PREX "stored wsc m8 cert cred.\n");
		debug(DEBUG_CAT_WSC_M8, DPP_MAP_PREX "cert_db ssid_len: %zd\n", cert_db->ssid_len);
		debug(DEBUG_CAT_WSC_M8, DPP_MAP_PREX "cert_db ssid : %s\n", cert_db->ssid);
		debug(DEBUG_CAT_WSC_M8, DPP_MAP_PREX "cert_db auth mode : %d\n", cert_db->auth_type);
		debug(DEBUG_CAT_WSC_M8, DPP_MAP_PREX "cert_db encryption : %d\n", cert_db->encr_type);
		debug(DEBUG_CAT_WSC_M8, DPP_MAP_PREX "cert_db key_len: %zd\n", cert_db->key_len);
		debug(DEBUG_CAT_WSC_M8, DPP_MAP_PREX "cert_db key : %s\n", cert_db->key);

		/*Compare this wsc_m8 msg's credentials with the old one.
		 * if there is some diff then store in local db and establish
		 * the connection with the new credentials.
		 */
		if (((cert_db->ssid_len == wps_data->data[i].ssid_len) &&
			!os_memcmp(cert_db->ssid, wps_data->data[i].ssid, wapp->wps_reconf_db.data[i].ssid_len)) &&
				(cert_db->auth_type == wps_data->data[i].auth_type) &&
				(cert_db->encr_type == wps_data->data[i].encr_type) &&
				(cert_db->key_len == wps_data->data[i].key_len &&
				!os_memcmp(cert_db->key, wps_data->data[i].key, wapp->wps_reconf_db.data[i].key_len))
		) {
			debug(DEBUG_CAT_WSC_M8, DPP_MAP_PREX "No WSC-M8 Diff found, No need to disconnect or store creds.\n");
			wapp->wsc_m8_diff = 0;
			diff_in_cred = 0;
			if (wps_data->bsta_mld_present == 1)
				debug(DEBUG_CAT_WSC_M8, DPP_MAP_PREX "bsta mld present, skip, conn will be made using bsta_mld tlv.");
			if (wps_data) {
				os_free(wps_data);
				wps_data = NULL;
			}
			if (tmp_cert_db) {
				os_free(tmp_cert_db);
				tmp_cert_db = NULL;
			}
			if (lbuf) {
				os_free(lbuf);
				lbuf = NULL;
			}
			return  0;
		}
		/* just to avoid checkPatch used diff_in_cred var
		 * since not allow to use else with return 0.
		 * if diff_in_cred is not 0 means we have diff in cred
		 * and need to execute the below code block
		 */
		if (diff_in_cred == 1) {
			diff_found_api = TRUE;
			wapp->wsc_m8_diff = diff_found_api;
			debug(DEBUG_CAT_WSC_M8, DPP_MAP_PREX "CERT WSC M8 Diff Found.\n");

			/* Copy the new diff found wsc-m8 cred into wapp->wsc_m8_cert_db db*/
			cert_db->ssid_len = wps_data->data[i].ssid_len;
			os_memcpy(cert_db->ssid, wps_data->data[i].ssid, cert_db->ssid_len);
			cert_db->auth_type = wps_data->data[i].auth_type;
			cert_db->encr_type = wps_data->data[i].encr_type;
			cert_db->key_len = wps_data->data[i].key_len;
			os_memcpy(cert_db->key, wps_data->data[i].key, cert_db->key_len);
		}

		debug(DEBUG_CAT_WSC_M8, DPP_MAP_PREX "wsc_m8_diff api : %d\n", diff_found_api);

		if (wps_data->bsta_mld_present == 1) {
			debug(DEBUG_CAT_WSC_M8, DPP_MAP_PREX "bsta mld present, skip, conn will be made using bsta_mld tlv.\n");
			if (wps_data) {
				os_free(wps_data);
				wps_data = NULL;
			}
			if (tmp_cert_db) {
				os_free(tmp_cert_db);
				tmp_cert_db = NULL;
			}
			if (lbuf) {
				os_free(lbuf);
				lbuf = NULL;
			}
			return  0;
		}

		if (diff_found_api && wps_data->bsta_mld_present == 0) {

			/* Get APCLI MAC from wdev */
			if (os_memcmp(sta_addr, ZERO_MAC_ADDR, ETH_ALEN) != 0)
				os_memcpy(bh->backhaul_mac, sta_addr, ETH_ALEN);
			if (os_memcmp(wps_data->data[i].mac_addr, ZERO_MAC_ADDR, ETH_ALEN) != 0)
				os_memcpy(bh->target_bssid, wps_data->data[i].mac_addr, ETH_ALEN);

			if (os_strlen((char *)(wps_data->data[i].ssid)) < sizeof(bh->target_ssid))
				os_memcpy(bh->target_ssid, wps_data->data[i].ssid, strlen((char *)(wps_data->data[i].ssid)));
			else
				os_memcpy(bh->target_ssid, wps_data->data[i].ssid, MAX_LEN_OF_SSID);

			debug(DEBUG_CAT_WSC_M8, DPP_MAP_PREX "BH->Key len using sizeof : %zd\n", sizeof(bh->Key));
			debug(DEBUG_CAT_WSC_M8, DPP_MAP_PREX "WPS->key len using sizeof : %zd\n", sizeof(wps_data->data[i].key));
			debug(DEBUG_CAT_WSC_M8, DPP_MAP_PREX "WPS->key len : %zd\n", wps_data->data[i].key_len);

			if (wps_data->data[i].key_len < MAX_PROFILE_KEYLEN)
				os_memcpy(bh->Key, wps_data->data[i].key, wps_data->data[i].key_len);

			/*Handling for DPP and AKM24 Mapping*/
			bh->AuthType = check_dpp_akm24_mapping(wps_data->data[i].auth_type);
			bh->EncrType = wps_data->data[i].encr_type;
			debug(DEBUG_CAT_WSC_M8, DPP_MAP_PREX "WSC-M8 ssid len : %zd\n", wsc_data->ssid_len);
			debug(DEBUG_CAT_WSC_M8, DPP_MAP_PREX "WSC-M8 ssid : %s\n", wsc_data->ssid);
			debug(DEBUG_CAT_WSC_M8, DPP_MAP_PREX "WSC-M8 auth mode : %d\n", wsc_data->auth_mode);
			debug(DEBUG_CAT_WSC_M8, DPP_MAP_PREX "WSC-M8 encryption : %d\n", wsc_data->encr_type);
			debug(DEBUG_CAT_WSC_M8, DPP_MAP_PREX "WSC-M8 key len : %zd\n", wsc_data->key_len);
			debug(DEBUG_CAT_WSC_M8, DPP_MAP_PREX "WSC-M8 key : %s\n", wsc_data->key);

			get_band_send_connect_req(wapp, bh, lbuf);
		}
	} else if (diff_found_turnkey == TRUE) {
		/* copy all configuration to pass best ap */
		os_memset(lbuf1, 0, sizeof(wsc_apcli_config_msg));
		apcli_config_msg = (wsc_apcli_config_msg *)lbuf1;

		apcli_config_msg->profile_count = wps_data->wps_cred_reconfig_num;
		for (i = 0; i < wps_data->wps_cred_reconfig_num; i++) {
			pdata = &wps_data->data[i];
			os_memcpy(apcli_config_msg->apcli_config[i].ssid, pdata->ssid, pdata->ssid_len);
			os_memcpy(apcli_config_msg->apcli_config[i].Key, pdata->key, pdata->key_len);
			os_memcpy(apcli_config_msg->apcli_config[i].bssid, pdata->mac_addr, MAC_ADDR_LEN);

			apcli_config_msg->apcli_config[i].SsidLen = pdata->ssid_len;
			apcli_config_msg->apcli_config[i].AuthType = pdata->auth_type;
			apcli_config_msg->apcli_config[i].EncrType = pdata->encr_type;
			apcli_config_msg->apcli_config[i].KeyLength = pdata->key_len;
			apcli_config_msg->apcli_config[i].KeyIndex = pdata->key_idx;
			/*update wapp->map->apcli_configs so that operating bss report
			 *could not overwrite bh configurations inside
			 *wlanif_handle_bh_config_event in mapd when operating bss report
			 *comes
			 */
			if (wapp->map->apcli_configs[i].config_valid) {
				os_memcpy(&wapp->map->apcli_configs[i].apcli_config,
				&apcli_config_msg->apcli_config[i], sizeof(wsc_apcli_config));
				notice(DEBUG_CAT_BH_RECONF, "BH Config SSID : %s\n",
				apcli_config_msg->apcli_config[i].ssid);
			}
		}
		/* send event to MAPD */
		send_pkt_len = sizeof(wsc_apcli_config_msg) + sizeof(wsc_apcli_config) * apcli_config_msg->profile_count;
		wapp_send_1905_msg(wapp, WAPP_MAP_BH_CONFIG, send_pkt_len, (char *)apcli_config_msg);

		/* now find out on which wdev BH sta connection need to send disable network*/
		apcli_stat_info = &wapp->cli_assoc_info;
		if (!(apcli_stat_info->apcli_assoc_state == WAPP_APCLI_DISASSOCIATED)) {
			apcli_wdev = wapp_dev_list_lookup_by_ifindex(wapp, apcli_stat_info->interface_index);
			if (!apcli_wdev) {
				err(DEBUG_CAT_BH_RECONF, "apcli wdev is null\n");
				if (wps_data) {
					os_free(wps_data);
					wps_data = NULL;
				}
				if (lbuf) {
					os_free(lbuf);
					lbuf = NULL;
				}
				return -1;
			}
		}
		if (wapp->drv_ops->drv_send_disable_network && wps_data->bsta_mld_present == 0)
			wapp->drv_ops->drv_send_disable_network(wapp->drv_data, apcli_wdev->ifname, apcli_wdev->network_id);
	}
	if (wps_data) {
		os_free(wps_data);
		wps_data = NULL;
	}
	if (lbuf) {
		os_free(lbuf);
		lbuf = NULL;
	}
	return 0;
}
#endif

extern int map_config_wireless_setting_msg(struct wifi_app *wapp,
	char *msg_buf, struct map_radio_identifier *ra_identifier, unsigned char Role);

int map_cmd_set_wireless_setting(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	char buf[4000] = {0};
	struct wsc_config *conf = NULL;
	struct wapp_dev *wdev = NULL, *wdev_temp = NULL;
	struct dl_list *dev_list = NULL;
	u8 count = 0, i = 0, target_band = 0;
	struct map_radio_identifier ra_identifier;

	if (argc != 3) {
		printf("Correct Format: wappctrl ra0 map set_wireless_setting <mode:0/1/2> <SSID>\n");
		printf("mode:0(24G)/1(5G)/2(6G)\n");
		return WAPP_INVALID_ARG;
	}

	conf = (struct wsc_config *)buf;
	dev_list = &wapp->dev_list;

	if (strtol(argv[1], NULL, 10) == 0)
		target_band = WPS_BAND_24G;
	else if (strtol(argv[1], NULL, 10) == 1)
		target_band = WPS_BAND_5G;
	else if (strtol(argv[1], NULL, 10) == 2)
		target_band = WPS_BAND_6G;

	dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
		if (wdev->dev_type != WAPP_DEV_TYPE_AP)
			continue;
		if (wdev->radio == NULL)
			continue;
		if (wdev->radio->radio_band) {
			if (*wdev->radio->radio_band != target_band)
				continue;
		} else
			continue;

		os_memcpy(conf->setting[count].mac_addr, wdev->mac_addr, ETH_ALEN);

		if (IS_OP_CLASS_24G(wdev->radio->opclass)) {
			if (os_strlen(argv[2]) < sizeof(conf->setting[count].Ssid)) {
				os_memcpy(conf->setting[count].Ssid, argv[2], os_strlen(argv[2]));
				conf->setting[count].Ssid[os_strlen(argv[2])] = '\0';
			} else {
				os_memcpy(conf->setting[count].Ssid, argv[2], MAX_LEN_OF_SSID);
				conf->setting[count].Ssid[MAX_LEN_OF_SSID] = '\0';
			}
			conf->setting[count].AuthMode = WPS_AUTH_WPA2PSK;
		} else if (IS_OP_CLASS_5G(wdev->radio->opclass)) {
			if (os_strlen(argv[2]) < sizeof(conf->setting[count].Ssid)) {
				os_memcpy(conf->setting[count].Ssid, argv[2], os_strlen(argv[2]));
				conf->setting[count].Ssid[os_strlen(argv[2])] = '\0';
			} else {
				os_memcpy(conf->setting[count].Ssid, argv[2], MAX_LEN_OF_SSID);
				conf->setting[count].Ssid[MAX_LEN_OF_SSID] = '\0';
			}
			conf->setting[count].AuthMode = WPS_AUTH_WPA2PSK;
		} else if (IS_OP_CLASS_6G(wdev->radio->opclass)) {
			if (os_strlen(argv[2]) < sizeof(conf->setting[count].Ssid)) {
				os_memcpy(conf->setting[count].Ssid, argv[2], os_strlen(argv[2]));
				conf->setting[count].Ssid[os_strlen(argv[2])] = '\0';
			} else {
				os_memcpy(conf->setting[count].Ssid, argv[2], MAX_LEN_OF_SSID);
				conf->setting[count].Ssid[MAX_LEN_OF_SSID] = '\0';
			}
			conf->setting[count].AuthMode = WPS_AUTH_SAE;
		}
		if (os_strlen(argv[2]) < sizeof(conf->setting[count].Ssid)) {
			os_memcpy(conf->setting[count].Ssid, argv[2], os_strlen(argv[2]));
			conf->setting[count].Ssid[os_strlen(argv[2])] = '\0';
		} else {
			os_memcpy(conf->setting[count].Ssid, argv[2], MAX_LEN_OF_SSID);
			conf->setting[count].Ssid[MAX_LEN_OF_SSID] = '\0';
		}
		count++;
	}

	conf->num = count;
	for (i = 0; i < count; i++) {
		conf->setting[i].EncrypType = WPS_ENCR_AES;
		os_memcpy(conf->setting[i].WPAKey, "maprocks1", 9);
		conf->setting[i].map_vendor_extension = (BIT_FH_BSS | BIT_BH_BSS);
		conf->setting[i].hidden_ssid = 0;
	}

	os_memset(&ra_identifier, 0, sizeof(ra_identifier));
	map_config_wireless_setting_msg(wapp, buf, &ra_identifier, 1);

	return 0;
}

int map_cmd_set_tx_prcntg(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	struct tx_power_percentage_setting *tx_power_setting = NULL;
	char buf[4000] = {0};
	int value = 0;

	if (argc != 3) {
		printf("Format: wappctrl ra0 map set_tx_power <band> <power>\n");
		printf("band 0:24G, 1:5G, 2:6G\n");
		return WAPP_INVALID_ARG;
	}

	tx_power_setting = (struct tx_power_percentage_setting *)buf;

	value = strtol(argv[1], NULL, 10);
	if (value < 0 || value > 255) {
		printf("invalid bandIdx (%d).\n",  value);
		value = 0;
	}
	tx_power_setting->bandIdx = value;

	value = strtol(argv[2], NULL, 10);
	if (value < 0 || value > 255) {
		printf("invalid tx_power_percentage (%d).\n",  value);
		value = 0;
	}
	tx_power_setting->tx_power_percentage = value;

	printf("bandidx(%u) power(%u)\n", tx_power_setting->bandIdx, tx_power_setting->tx_power_percentage);

	map_config_tx_power_percentage_msg(wapp, (char *)buf, NULL, NULL);

	return 0;
}

int map_cmd_bh_connect_req(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	struct backhaul_connect_request *bh = NULL;
	char buf[4000] = {0};
	unsigned char apcli_mac[6] = {0};
	unsigned char bssid[6] = {0};
	int ret;

	if (argc != 4) {
		printf("Format: wappctrl ra0 map bh_connect_req <APCLI_MAC> <BSSID> <SSID>\n");
		return WAPP_INVALID_ARG;
	}

	bh = (struct backhaul_connect_request *)buf;
	ret = hwaddr_aton(argv[1], apcli_mac);
	if (ret) {
		printf("%s: incorrect almac address %s\n", __func__, argv[1]);
		return WAPP_INVALID_ARG;
	}
	ret = hwaddr_aton(argv[2], bssid);
	if (ret) {
		printf("%s: incorrect almac address %s\n", __func__, argv[2]);
		return WAPP_INVALID_ARG;
	}

	os_memcpy(bh->backhaul_mac, apcli_mac, 6);
	os_memcpy(bh->target_bssid, bssid, 6);
	if (os_strlen(argv[3]) < sizeof(bh->target_ssid)) {
		os_memcpy(bh->target_ssid, argv[3], strlen(argv[3]));
		bh->target_ssid[strlen(argv[3])] = '\0';
	} else {
		os_memcpy(bh->target_ssid, argv[3], MAX_LEN_OF_SSID);
	}
	bh->AuthType = WSC_AUTHTYPE_SAE;
	bh->EncrType = WSC_ENCRTYPE_AES;
	os_memcpy(bh->Key, "12345678", 8);
	bh->channel = 37;
	bh->bw = BW_160;
	bh->oper_class = 134;

	map_config_backhaul_connect_msg(wapp, buf, NULL, NULL);

	return 0;
}
#endif
#ifdef MAP_R2
u8 mapd_get_channel_scan_capab_from_driver(struct wifi_app *wapp);

#if 1
int map_cmd_ch_scan_req( struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{

#if 0
#if 1

	struct off_ch_scan_req_s*scan_req = NULL;
	u8 buf[8000] = {0};
	u32 len;
	u8 radio_id_5GH[6] = {0,0,0,0,1,0};
	u8 radio_id_5GL[6] = {0,0,0,0,3,0};
	u8 radio_id_2G[6] = {0,0,0,0,2,0};
#endif
#if 1
	scan_req = (struct channel_scan_req *)buf;
	printf("%s %d\n", __func__, __LINE__);
	mapd_get_channel_scan_capab_from_driver(wapp);

	scan_req->fresh_scan= 0x80;
	scan_req->radio_num = 3;
	os_memcpy(scan_req->body[0].radio_id, radio_id_2G, 6);
	scan_req->body[0].oper_class_num = 1;
	scan_req->body[0].ch_body[0].oper_class = 81;
	scan_req->body[0].ch_body[0].ch_list_num = 0;
#if 1
	os_memcpy(scan_req->body[1].radio_id, radio_id_5GL, 6);
	scan_req->body[1].oper_class_num = 2;
	scan_req->body[1].ch_body[0].oper_class = 115;
	scan_req->body[1].ch_body[0].ch_list_num = 0;

	scan_req->body[1].ch_body[1].oper_class = 118;
	scan_req->body[1].ch_body[1].ch_list_num = 0;

	os_memcpy(scan_req->body[2].radio_id, radio_id_5GH, 6);
	scan_req->body[2].oper_class_num = 2;
	scan_req->body[2].ch_body[0].oper_class = 121;
	scan_req->body[2].ch_body[0].ch_list_num = 0;

	scan_req->body[2].ch_body[1].oper_class = 125;
	scan_req->body[2].ch_body[1].ch_list_num = 0;

#endif
	len = sizeof(struct channel_scan_req) + 3*sizeof(struct scan_body);
	printf("%s: scanReqLen = %d\n",__func__,len);
	map_receive_channel_scan_req(wapp, (char *)buf,(u16)len);
#endif
	// fill send channel scan req
#endif
return WAPP_SUCCESS;
}
#endif

#ifdef DFS_CAC_R2
int map_send_cac_status_msg(
	struct wifi_app *wapp, char *addr, char *evt_buf, int* len_buf);
int map_cmd_cac_status( struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	char buf[8000] = {0};
	int len;
	map_send_cac_status_msg(wapp, NULL, buf, &len);
	// fill send channel scan req
	return WAPP_SUCCESS;
}


#endif
#endif
#ifdef MAP_R3
int map_cmd_dev_set_trigger( struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	struct wapp_dev *wdev = NULL;
	u8 sta_mac[MAC_ADDR_LEN];
	char *token;
	int i;

	if (argc != 3) {
		err(DEBUG_CAT_EVENT, "%s: cmd parameter error! need 3 but %d\n", __func__, argc);
		return WAPP_INVALID_ARG;
	}
	notice(DEBUG_CAT_EVENT, "[%s] Trigger type %s second param frm cmd %s\n", __func__, argv[1], argv[2]);

	if (os_strcmp(argv[1], "deauthentication") == 0) {
		i = 0;
		token = strtok(argv[2], ":");

		while (token != NULL) {
			AtoH(token, (char *) &sta_mac[i], 1);
			i++;
			if (i >= MAC_ADDR_LEN)
				break;
			token = strtok(NULL, ":");
		}
		notice(DEBUG_CAT_EVENT, "\n STA MAC = %02x:%02x:%02x:%02x:%02x:%02x\n", PRINT_MAC(sta_mac));
		wdev = wdev_sta_lookup_for_all_bss(wapp, sta_mac);
		if(!wdev)
			return WAPP_INVALID_ARG;
	}
	else if (os_strcmp(argv[1], "dpppresenceannouncementblock") == 0) {
		if (os_strcmp(argv[2], "enable") == 0) {
			//Set global variable to disable presence announcement handling here
			notice(DEBUG_CAT_EVENT, "chirp handing disabled..\n");
			wapp->dpp->dpp_chirp_handling = 0;
		}
		else if (os_strcmp(argv[2], "disable") == 0) {
			//Set global variable to enable presence announcement handling here
			notice(DEBUG_CAT_EVENT, "chirp handing enabled..\n");
			wapp->dpp->dpp_chirp_handling = 1;
		}
		else {

			err(DEBUG_CAT_EVENT, "\n Invalid argument\n");
			return WAPP_INVALID_ARG;
		}
	}
	else {
		err(DEBUG_CAT_EVENT, "\n Invalid argument\n");
		return WAPP_INVALID_ARG;
	}

	return WAPP_SUCCESS;
}
#endif /* MAP_R3 */

int map_cmd_1905_req( struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	struct wapp_1905_req req;
	int value = 0;

	if (!argv[1] || !argv[2]) {
		err(DEBUG_CAT_EVENT, "Invalid argument\n");
		return WAPP_INVALID_ARG;
	}

	value = strtol(argv[1], NULL, 10);
	if (value < 0 || value > 255) {
		notice(DEBUG_CAT_EVENT, "invalid req.id (%d).\n",  value);
		value = 0;
	}
	req.id = value;

	value = strtol(argv[2], NULL, 10);
	if (value < 0 || value > 255) {
		notice(DEBUG_CAT_EVENT, "invalid req.value (%d).\n",  value);
		value = 0;
	}
	req.value = value;

	notice(DEBUG_CAT_EVENT, BLUE("%s: id = %u, value = %u\n"), __func__, req.id, req.value);

	map_1905_req(wapp, &req);
	return WAPP_SUCCESS;

}

void map_event_bh_sta_wap_done(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL;
	struct map_info *map = NULL;
	wapp_device_status *device_status = NULL;
#ifdef MAP_R6
	struct wapp_sta *cli = NULL;
#endif

	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);

	if (!wdev)
		return;

#ifdef MAP_R6
	if (wdev->dev_type == WAPP_DEV_TYPE_STA) {
		cli = (struct wapp_sta *)wdev->p_dev;
		cli->ssid_len = event_data->bhsta_info.ssid_len;
		os_memset(cli->ssid, 0, MAX_LEN_OF_SSID);
		os_memcpy(cli->ssid, event_data->bhsta_info.ssid, cli->ssid_len);
		os_memset(cli->sta_mld_addr, 0, ETH_ALEN);
		os_memcpy(cli->sta_mld_addr, event_data->bhsta_info.sta_mld_addr, ETH_ALEN);
		err(DEBUG_CAT_MLO, "sta mld mac in wapp is "MACSTR"\n", MAC2STR(cli->sta_mld_addr));
	}
#endif
	map = wapp->map;
	device_status = &wapp->map->device_status;

	notice(DEBUG_CAT_MLO, BLUE("%s\n"), __func__);

#ifdef MAP_R6
	if (wapp->bsta_link_deleted == 1) {
		debug(DEBUG_CAT_MLO, "bh type updated as wifi since bsta lin deleted set");
		map->bh_type = MAP_BH_WIFI;
	}
#endif

	if(event_data->bhsta_info.peer_map_enable)
	{
		if ((map->bh_type == MAP_BH_WIFI) &&
			(wdev == map->bh_wifi_dev)
#ifdef MTK_HOSTAPD_SUPPORT
			&& (wapp->wsc_bh_wait == FALSE)
#endif
) {
			map_bh_ready(wapp, MAP_BH_WIFI, (u8 *)wdev->ifname, wdev->mac_addr, event_data->bhsta_info.connected_bssid
#ifdef MTK_MLO_MAP_SUPPORT
,
			event_data->bhsta_info.setup_link_num, event_data->bhsta_info.linkinfo
#ifdef MAP_R6
,			&event_data->bhsta_info.sta
#endif
#endif
);
		}	else if (map->bh_wifi_dev == NULL)
		{
#ifdef MAP_R3
			if(map->TurnKeyEnable && (map->map_version == DEV_TYPE_R3)) {
				/* Setting BH type to wifi to use later */
				map->bh_type = MAP_BH_WIFI;
			}
#endif /* MAP_R3 */
#ifdef MTK_TK_HOSTAPD_SUPPORT
			if (wapp->wsc_bh_wait == FALSE)
#endif

				map_bh_ready(wapp, MAP_BH_WIFI, (u8 *)wdev->ifname, wdev->mac_addr, event_data->bhsta_info.connected_bssid
#ifdef MTK_MLO_MAP_SUPPORT
	,
				event_data->bhsta_info.setup_link_num, event_data->bhsta_info.linkinfo
#ifdef MAP_R6
,			&event_data->bhsta_info.sta
#endif
#endif
);
		}
#ifdef MAP_R6
/* No need (wdev == map->bh_wifi_dev) check in CERT MODE
 * as map bh_wifi_dev may be different which is being passed in WPS.
 */
		else if (wapp->map->MapMode == MAP_CERT_MODE) {
			if ((map->bh_type == MAP_BH_WIFI)
#ifdef MTK_HOSTAPD_SUPPORT
			&& (wapp->wsc_bh_wait == FALSE)
#endif
) {
				DBGPRINT(RT_DEBUG_TRACE, "CERT Case check\n");
				map_bh_ready(wapp, MAP_BH_WIFI, (u8 *)wdev->ifname, wdev->mac_addr, event_data->bhsta_info.connected_bssid
#ifdef MTK_MLO_MAP_SUPPORT
,
				event_data->bhsta_info.setup_link_num, event_data->bhsta_info.linkinfo
#ifdef MAP_R6
,				&event_data->bhsta_info.sta
#endif
#endif
); }
	}
#endif
	}else {
			/* Connection to Non-MAP AP*/
			device_status->status_bhsta = STATUS_BHSTA_WPS_NORMAL_CONFIGURED;
			device_status->status_fhbss = STATUS_FHBSS_UNCONFIGURED;
			wapp_send_1905_msg(
			wapp,
			WAPP_DEVICE_STATUS,
			sizeof(wapp_device_status),
			(char *)device_status);
	}
}

#ifdef MAP_R6
int find_wdev_from_mld_mac(struct wifi_app *wapp, u8 *mld_mac, struct wapp_dev *wdev_list[])
{
	struct dl_list *dev_list;
	struct wapp_dev *wdev;
	int count = 0;

	dev_list = &wapp->dev_list;
	dl_list_for_each(wdev, dev_list, struct wapp_dev, list) {
		if (!os_memcmp(wdev->mld_addr_renew, mld_mac, MAC_ADDR_LEN)) {
			if (count < MAX_AFFILIATED_AP) {
				wdev_list[count] = wdev;
				count++;
			}
		}
	}
	return(count);
}

int find_wdev_from_ssid(struct wifi_app *wapp, u8 *ssid, u8 ssid_len, struct wapp_dev *wdev_list[])
{
	struct wapp_dev *wdev = NULL;
	struct dl_list *dev_list;
	int count = 0;
	struct ap_dev *ap;

	dev_list = &wapp->dev_list;
	dl_list_for_each(wdev, dev_list, struct wapp_dev, list) {
		ap = (struct ap_dev *)wdev->p_dev;
#if DUMP_LOG
		if (ap && wdev->dev_type == WAPP_DEV_TYPE_AP) {
			notice(DEBUG_CAT_WIFI_CONFIG, "ssid = %s\n", os_ssid_txt(ssid, ssid_len));
			notice(DEBUG_CAT_WIFI_CONFIG, "ap->bss_info.ssid = %s\n",
				os_ssid_txt((u8 *)ap->bss_info.ssid, ap->bss_info.SsidLen));
			notice(DEBUG_CAT_WIFI_CONFIG, "ifname = %s\n", wdev->ifname);
			notice(DEBUG_CAT_WIFI_CONFIG, "wdev->mld_addr_renew = " MACSTR "\n", MAC2STR(wdev->mld_addr_renew));
		}
#endif /*if 0 */
		if (ap && wdev->dev_type == WAPP_DEV_TYPE_AP &&
			ap->bss_info.SsidLen == ssid_len &&
			!os_memcmp(ap->bss_info.ssid, ssid, ssid_len)) {
			if (count < MAX_AFFILIATED_AP) {
				notice(DEBUG_CAT_WIFI_CONFIG, "wdev mld_addr_renew = " MACSTR "\n", MAC2STR(wdev->mld_addr_renew));
				if (is_all_zero_mac(wdev->mld_addr_renew) == FALSE) {
					wdev_list[count] = wdev;
					count++;
				}
			}
		}
	}
	return count;
}

void mark_all_wdev_del_link_invalid(struct wifi_app *wapp)
{
	struct wapp_dev *wdev = NULL;
	struct dl_list *dev_list;

	dev_list = &wapp->dev_list;
	dl_list_for_each(wdev, dev_list, struct wapp_dev, list) {
		if (wdev->dev_type == WAPP_DEV_TYPE_AP)
			wdev->mld_del_link_state = DEL_LINK_INVALID;
	}
}

int process_mld_del_link_setting(struct wifi_app *wapp,
	u8 num_af_ap, struct affiliated_ap_db *ap,
	struct wapp_dev *wdev_list[], int wdev_list_len)
{
	int i, j;
	int flag;
	int found;

	struct wapp_dev *t_wdev[MAX_AFFILIATED_AP] = {NULL,};
	struct wapp_dev *twdev;
	struct ap_dev *apdev;

	twdev = wdev_list[0];
	for (i = 0; i < num_af_ap; i++) {
		if (ap[i].mlo_valid_bitmap & BIT(7)) {
			t_wdev[i] = wapp_dev_list_lookup_by_mac_and_type(wapp, ap[i].affiliated_ap_bssid, WAPP_DEV_TYPE_AP);
			notice(DEBUG_CAT_MLO, "wdev interface after look up %s\n", t_wdev[i]->ifname);
		} else if (ap[i].mlo_valid_bitmap & BIT(6)) {
			t_wdev[i] = wapp_dev_list_lookup_by_mld_link_id(wapp, ap[i].link_id);
		} else {
			apdev = (struct ap_dev *)twdev->p_dev;
			t_wdev[i] = wapp_dev_list_lookup_by_ruid(wapp, ap[i].ruid, (u8 *)apdev->bss_info.ssid, apdev->bss_info.SsidLen);
		}
	}

	for (i = 0; i < num_af_ap; i++) {
		if (t_wdev[i]) {
			notice(DEBUG_CAT_MLO, "affilated wdev from msg config %s\n", t_wdev[i]->ifname);
			notice(DEBUG_CAT_MLO, "\n");
		} else {
			notice(DEBUG_CAT_MLO, "t_wdev[%d] is null from affilated msg\n", i);
		}
	}
	flag = 0;
	for (i = 0; i < wdev_list_len; i++) {
		found = 0;
		for (j = 0; j < num_af_ap; j++) {
			if (wdev_list[i] == t_wdev[j] && wdev_list[i]->mld_del_link_state == DEL_LINK_INVALID) {
				found = 1;
				break;
			}
		}
		if (!found) {
			err(DEBUG_CAT_MLO, "mismatch wdev found need to call reconfig link %s\n", wdev_list[i]->ifname);
			flag = 1;
			twdev = wdev_list[i];
			break;
		}
	}
	if (flag) {
		twdev->mld_del_link_state = DEL_LINK_ONGOING;
		notice(DEBUG_CAT_MLO, "going to call reconfig\n");
		if (wapp->map->TurnKeyEnable == 1)
			wapp->drv_ops->drv_set_mld_link_reconfig(wapp->drv_data, twdev->ifname, twdev->mld_id, RECONF_SECONDS);
		else
			wapp->drv_ops->drv_set_mld_link_reconfig(wapp->drv_data, twdev->ifname, twdev->mld_id, RECONF_SECONDS_CERT);
		return 1;
	}

	if (num_af_ap == 0) {
		notice(DEBUG_CAT_MLO, "del all link case, need to call del link\n");
		for (j = 0; j < MAX_AFFILIATED_AP && wdev_list[j]; j++) {
			if (wdev_list[j]->mld_del_link_state == DEL_LINK_INVALID) {
				twdev = wdev_list[j];
				twdev->mld_del_link_state = DEL_LINK_ONGOING;
				err(DEBUG_CAT_MLO, "wdev about to del ifname = %s\n", twdev->ifname);
				wapp->drv_ops->drv_set_mld_link_del(wapp->drv_data, twdev->ifname, twdev->mld_id);
				break;
			}
		}
	}
	return(0);
}

void process_mld_add_link_setting(struct wifi_app *wapp,
	u8 num_af_ap, struct affiliated_ap_db *ap,
	struct wapp_dev *wdev_list[], u8 *ssid, u8 ssidlen, int wdev_list_len)
{
	int i, j;
	struct wapp_dev *t_wdev[MAX_AFFILIATED_AP] = {NULL,};
	struct wapp_dev *twdev;
	struct wapp_dev *wdevlist;
	struct ap_dev *apdev;


	//wdevlist = wdev_list[0];
	for (i = 0; i < num_af_ap; i++) {
		if (ap[i].mlo_valid_bitmap & BIT(7)) {
			t_wdev[i] = wapp_dev_list_lookup_by_mac_and_type(wapp, ap[i].affiliated_ap_bssid, WAPP_DEV_TYPE_AP);
			notice(DEBUG_CAT_MLO, "wdev interface after look up %s\n", t_wdev[i]->ifname);
		} else if (ap[i].mlo_valid_bitmap & BIT(6)) {
			t_wdev[i] = wapp_dev_list_lookup_by_mld_link_id(wapp, ap[i].link_id);
		} else {
			//apdev = (struct ap_dev *)wdevlist->p_dev;
			t_wdev[i] = wapp_dev_list_lookup_by_ruid(wapp, ap[i].ruid, ssid, ssidlen);
			if (t_wdev[i])
				err(DEBUG_CAT_MLO, "wdev interface after look up i = %d %s\n", i, t_wdev[i]->ifname);
		}
	}

	for (i = 0; i < num_af_ap; i++) {
		if (t_wdev[i])
			notice(DEBUG_CAT_MLO, " affilated wdev from msg config %s\n", t_wdev[i]->ifname);
	}

	if (!wdev_list_len) {
		for (i = 0; i < num_af_ap && t_wdev[i]; i++) {
			notice(DEBUG_CAT_MLO, "going to call add link %s\n", t_wdev[i]->ifname);
			wapp->drv_ops->drv_set_mld_link_add(wapp->drv_data, t_wdev[i]->ifname, t_wdev[i]->mld_id_before_del, 1);
			os_memcpy(t_wdev[i]->mld_addr_renew, t_wdev[i]->mld_addr_before_del, ETH_ALEN);
			t_wdev[i]->mld_id = t_wdev[i]->mld_id_before_del;
			apdev = (struct ap_dev *)(t_wdev[i]->p_dev);
			apdev->isActive = WAPP_BSS_START;
		}
	} else {
		wdevlist = wdev_list[0];
		for (i = 0; i < num_af_ap; i++) {
			for (j = 0; j < wdev_list_len; j++) {
				if (t_wdev[i] == wdev_list[j])
					break;
			}
			if (j == wdev_list_len) {
				if (t_wdev[i] == NULL) {
					err(DEBUG_CAT_MLO, "t_wdev i = %d is null\n", i);
					break;
				}
				err(DEBUG_CAT_MLO, "mismatch wdev found need to call add link %s\n", t_wdev[i]->ifname);
				twdev = t_wdev[i];
				wapp->drv_ops->drv_set_mld_link_add(wapp->drv_data, twdev->ifname, wdevlist->mld_id, 1);
				os_memcpy(twdev->mld_addr_renew, wdevlist->mld_addr_renew, ETH_ALEN);
				twdev->mld_id = wdevlist->mld_id;
				apdev = (struct ap_dev *)twdev->p_dev;
				apdev->isActive = WAPP_BSS_START;
			}
		}
	}
}

enum renew_buffer_state process_mld_renew_wireless_setting(struct wifi_app *wapp)
{
	struct mld_config_db *config_db = NULL;
	struct mlo_config_db *mlo_config = NULL;
	int i, j;
	int ret;
	struct wapp_dev *wdev[MAX_AFFILIATED_AP] = {NULL};
	int l_affilated_ap_count = 0;

	/* first need to check dellink case */
	config_db = wapp->renew_config_db;
	if (!config_db) {
		err(DEBUG_CAT_WIFI_CONFIG, "wapp renew config db is null now\n");
		return RENEW_BUFFER_DONE;
	}
	for (i = 0; i < config_db->num_ap_mld; i++) {
		mlo_config = &config_db->config[i];
		if (mlo_config->valid_bitmap & BIT(7)) {
			/* need to search from mld address */
			l_affilated_ap_count = find_wdev_from_mld_mac(wapp, mlo_config->mld_mac, wdev);
			notice(DEBUG_CAT_MLD_CONFIG, "mld mac from db "MACSTR
				" l_affilated_ap_count = %d\n", MAC2STR(mlo_config->mld_mac), l_affilated_ap_count);
			for (j = 0; j < l_affilated_ap_count; j++)
				notice(DEBUG_CAT_MLD_CONFIG, "currently mld mac for interfaces are %s\n", wdev[j]->ifname);

			notice(DEBUG_CAT_WIFI_CONFIG, "this is indication to del link by mld id\n");
			/* Need to use link reconfig instead of del llink */
			ret = process_mld_del_link_setting(wapp, mlo_config->num_affiliated_ap,
				mlo_config->ap, wdev, l_affilated_ap_count);
			if (ret)
				return RENEW_BUFFER_START;
		} else {
			/* need to search from ssid */
			l_affilated_ap_count = find_wdev_from_ssid(wapp, mlo_config->ssid, mlo_config->ssid_len, wdev);
			for (j = 0; j < l_affilated_ap_count; j++)
				notice(DEBUG_CAT_MLD_CONFIG, "currently ssid for interfaces are %s\n", wdev[j]->ifname);

			if (l_affilated_ap_count) {
				notice(DEBUG_CAT_MLD_CONFIG, "this is indication to del link by ssid\n");
				/* Need to use link reconfig instead of del llink */
				ret = process_mld_del_link_setting(wapp, mlo_config->num_affiliated_ap,
					mlo_config->ap, wdev, l_affilated_ap_count);
				if (ret)
					return RENEW_BUFFER_START;
			} else
				notice(DEBUG_CAT_MLD_CONFIG, "No wdev found for this ssid\n");
		}
	}
	/* Add link case handling */
	for (i = 0; i < config_db->num_ap_mld; i++) {
		mlo_config = &config_db->config[i];
		if (mlo_config->valid_bitmap & BIT(7)) {
			/* need to search from mld address */
			l_affilated_ap_count = find_wdev_from_mld_mac(wapp, mlo_config->mld_mac, wdev);
			notice(DEBUG_CAT_MLD_CONFIG, "mld mac from db "MACSTR
				"l_affilated_ap_count = %d\n", MAC2STR(mlo_config->mld_mac), l_affilated_ap_count);
			for (j = 0; j < l_affilated_ap_count; j++)
				notice(DEBUG_CAT_MLD_CONFIG, "currently mld mac for interfaces are %s\n", wdev[j]->ifname);

			if (l_affilated_ap_count) {
				notice(DEBUG_CAT_MLD_CONFIG, "this is indication to add link\n");
				process_mld_add_link_setting(wapp, mlo_config->num_affiliated_ap,
					mlo_config->ap, wdev, mlo_config->ssid, mlo_config->ssid_len, l_affilated_ap_count);
			} else
				notice(DEBUG_CAT_MLD_CONFIG, "this is indication to group add case\n");
		} else {
			/* need to search from ssid */
			l_affilated_ap_count = find_wdev_from_ssid(wapp, mlo_config->ssid, mlo_config->ssid_len, wdev);
			for (j = 0; j < l_affilated_ap_count; j++)
				notice(DEBUG_CAT_MLD_CONFIG, "currently ssid for interfaces are %s\n", wdev[j]->ifname);

			notice(DEBUG_CAT_MLD_CONFIG, "this is indication to add link\n");
			if (!l_affilated_ap_count)
				wdev[0] = NULL;
			process_mld_add_link_setting(wapp, mlo_config->num_affiliated_ap,
				mlo_config->ap, wdev, mlo_config->ssid, mlo_config->ssid_len, l_affilated_ap_count);
		}
	}
	return RENEW_BUFFER_DONE;
}

void wapp_mlo_reconfig_status_event(struct wifi_app *wapp, char *data)
{
	char state = *data;
	struct wapp_dev *wdev;
	struct wapp_dev *twdev;
	struct dl_list *dev_list;
	struct ap_dev *ap;
	u8 zeromac[MAC_ADDR_LEN] = {0};
	int flag;

	notice(DEBUG_CAT_MLD_CONFIG, "driver reconfig event state = %d\n", state);
	dev_list = &wapp->dev_list;

	if (state == BSS_RECONFIG_IDLE_STAGE) {
		flag = 0;
		/* need to handle only this event indicate dellink complete */
		if (wapp->set_wireless_setting == TRUE) {
			err(DEBUG_CAT_MLD_CONFIG, "new wireless setting message no need to handle previous mld setting\n");
			return;
		}

		dl_list_for_each(wdev, dev_list, struct wapp_dev, list) {
			if (wdev->dev_type == WAPP_DEV_TYPE_AP &&
				wdev->mld_del_link_state == DEL_LINK_ONGOING) {
				twdev = wdev;
				flag = 1;
				break;
			}
		}
		if (flag) {
			notice(DEBUG_CAT_MLD_CONFIG, "ongoing wdev is %s\n", twdev->ifname);
			// wapp->drv_ops->drv_set_no_bcn(wapp->drv_data, twdev->ifname, BEACON_STOP);
			//     no need to call no bcn now driver will handle this.

			ap = (struct ap_dev *)twdev->p_dev;
			ap->isActive = WAPP_BSS_STOP;
			ap->is_ap_mld_reconf = 1;
			twdev->mld_del_link_state = DEL_LINK_DONE;
			os_memcpy(twdev->mld_addr_before_del, twdev->mld_addr_renew, MAC_ADDR_LEN);
			twdev->mld_id_before_del = twdev->mld_id;
			os_memcpy(twdev->mld_addr_renew, zeromac, MAC_ADDR_LEN);
			twdev->mld_id = 0;
			if (wapp->renew_buf_state != RENEW_BUFFER_DONE) {
				wapp->renew_buf_state = process_mld_renew_wireless_setting(wapp);
				if (wapp->renew_buf_state == RENEW_BUFFER_DONE)
					free_renew_config_db(wapp);
			}
		} else {
			notice(DEBUG_CAT_MLD_CONFIG, "it could be a indication for new renew message or driver executing command\n");
		}
	}
}
#endif /* MAP_R6 */

void map_event_str_sta_rsp_handle(struct wifi_app *wapp, u32 ifindex, wapp_event_data *event_data)
{
	struct wapp_dev *wdev = NULL;
	wdev_steer_sta *str_sta = NULL;
	struct wapp_sta *sta = NULL;
	char cand_list[128] = {0};
	char buf[128] = {0};
	u8 btm_neighbor_report_header[2] = {0};
	size_t btm_req_len = 0, cand_list_len = 0;
	u8 frame_pos = 0, req_mode = 0;

	if (!wapp)
		return;

	wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);

	if (!wdev)
		return;

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		str_sta = &event_data->str_sta;
		struct ap_dev *ap = (struct ap_dev *)wdev->p_dev;

		sta = wdev_ap_client_list_lookup(wapp, ap, str_sta->mac_addr);
		if (!sta) {
			err(DEBUG_CAT_EVENT, "null sta\n");
			return;
		}

		if (sta->bLocalSteerDisallow == FALSE) {
			if ((sta->bBSSMantSupport == TRUE)
				&& (sta->bBTMSteerDisallow == FALSE)) {
				req_mode = (1 << ABIDGED_BIT_MAP) | (1 << DISASSOC_IMNT_BIT_MAP);
				u16 append_entry_len = NEIGHBOR_REPORT_IE_SIZE; /* append Bssid ~ CandidatePref */
				/* element ID: 52, len: 16 */
				btm_neighbor_report_header[0] = IE_RRM_NEIGHBOR_REP;
				btm_neighbor_report_header[1] = append_entry_len;

				os_memcpy(&cand_list[frame_pos], &btm_neighbor_report_header, sizeof(btm_neighbor_report_header));
				frame_pos += sizeof(btm_neighbor_report_header);
				cand_list_len += sizeof(btm_neighbor_report_header);

				// fill neighbor report info
				os_memcpy(&cand_list[frame_pos], &wapp->daemon_nr_list.NRInfo[0], append_entry_len);
				cand_list_len += append_entry_len;
				//hex_dump_dbg("entry", (u8 *)frame_pos, append_entry_len);

				btm_req_len = wapp_build_btm_req(req_mode, 10 * 10, 200, //Validate interval
												NULL, NULL, 0, cand_list, cand_list_len, buf);

#ifndef KV_API_SUPPORT
				wapp_send_btm_req(wapp, (char*)wdev->ifname, str_sta->mac_addr, buf, btm_req_len);
#else
#ifdef MTK_HOSTAPD_SUPPORT
				wapp_send_btm_req(wapp, (char *)wdev->ifname, str_sta->mac_addr, buf, btm_req_len);
#else
				wapp_send_btm_req_11kv_api(wapp, wdev->ifname, sta->mac_addr, buf, btm_req_len);
#endif /* MTK_HOSTAPD_SUPPORT */
#endif /* KV_API_SUPPORT */
			} else {
				map_trigger_deauth(wapp, wdev->ifname, str_sta->mac_addr);
			}

			if (++sta->steered_count > MAP_MAX_STEER_COUNT)
				sta->bLocalSteerDisallow = TRUE;
		}
	}

}

int save_map_parameters(struct wifi_app *wapp,char *param, char *value, param_type type)
{
#ifdef OPENWRT_SUPPORT
	struct kvc_context *dat_ctx = NULL;
	int ret = 0;
	const char *file = NULL;

	debug(DEBUG_CAT_MISC, "param(%s) value(%s)\n", param, value);

	if (type == NON_DRIVER_PARAM && wapp->map) {
		dat_ctx = kvc_load((const char *)wapp->map->map_user_cfg, LF_FLOCK|LF_KEY_CASE_SENSITIVE);
		if (!dat_ctx) {
			err(DEBUG_CAT_MISC, "load file(%s) fail\n", wapp->map->map_user_cfg);
			ret = -1;
			goto out;
		}
		ret = kvc_set(dat_ctx, (const char *)param, (const char *)value);
		if (ret) {
			err(DEBUG_CAT_MISC, "set param(%s) fail\n", param);
			goto out;
		}
		ret = kvc_commit(dat_ctx);
		if (ret) {
			err(DEBUG_CAT_MISC, "write param(%s) fail\n", param);
			goto out;
		}
		/*IN Map Certification Easymesh will not be triggered so we need to reset the params in mapd_cfg*/
		if(!wapp->map->TurnKeyEnable) {
			kvc_unload(dat_ctx);
			dat_ctx = kvc_load((const char *)wapp->map->map_cfg, LF_FLOCK|LF_KEY_CASE_SENSITIVE);
			if (!dat_ctx) {
				err(DEBUG_CAT_MISC, "load file(%s) fail\n", wapp->map->map_cfg);
				ret = -1;
				goto out;
			}
			ret = kvc_set(dat_ctx, (const char *)param, (const char *)value);
			if (ret) {
				err(DEBUG_CAT_MISC, "set param(%s) fail\n", param);
				goto out;
			}
			ret = kvc_commit(dat_ctx);
			if (ret) {
				err(DEBUG_CAT_MISC, "write param(%s) fail\n", param);
				goto out;
			}
		}
	} else {
		file = get_dat_path_by_ord(0);
		if (!file) {
			err(DEBUG_CAT_MISC, "invalid file!!! type(%d)\n", type);
			return -1;
		}
		dat_ctx = kvc_load((const char *)file, LF_FLOCK|LF_KEY_CASE_SENSITIVE);
		if (!dat_ctx) {
			err(DEBUG_CAT_MISC, "load file(%s) fail\n", file);
			ret = -1;
			goto out;
		}

		ret = kvc_set(dat_ctx, (const char *)param, (const char *)value);
		if (ret) {
			err(DEBUG_CAT_MISC, "set param(%s) fail\n", param);
			goto out;
		}
		ret = kvc_commit(dat_ctx);
		if (ret) {
			err(DEBUG_CAT_MISC, "write param(%s) fail\n", param);
			goto out;
		}
	}
out:
	if (file)
		free_dat_path(file);
	if (dat_ctx)
		kvc_unload(dat_ctx);
	if (ret)
		return -1;
	else
		return 0;
#else
	char cmd_buffer[256] = {0};

	os_snprintf(cmd_buffer, sizeof(cmd_buffer),"nvram_set 2860 %s %s &", param, value);
	if (system(cmd_buffer) == -1)
		err(DEBUG_CAT_MISC, "[%s] (%d): system() call return value is -1\n", __func__, __LINE__);
	debug(DEBUG_CAT_MISC, "get_map_parameter %s = %s\n", param, value);

	return 0;
#endif
}

char *get_map_param_type_str(int type)
{
	switch (type) {
	case NON_DRIVER_PARAM:
		return "NON_DRIVER_PARAM";
	case DRIVER_PARAM:
		return "DRIVER_PARAM";
#ifdef MAP_R6
	case DRIVER_6G_PARAM:
		return "DRIVER_6G_PARAM";
#endif
	default:
		return "UNKNOWN TYPE";
	}
}

int get_map_parameters(struct map_info *map, char* param, char* value, param_type type, size_t val_len)
{
#ifdef OPENWRT_SUPPORT
	const char *tmp_value = NULL;
	unsigned int len = 0;
	struct kvc_context *dat_ctx = NULL;
#ifdef MTK_HOSTAPD_SUPPORT
	struct kvc_context *dat_ctx2 = NULL;
#endif /* MTK_HOSTAPD_SUPPORT */
	const char *file = NULL;
	int ret = 0;

	os_memset(value, 0, val_len);

	if (type == NON_DRIVER_PARAM)
		file = map->map_cfg;
	else {
#ifndef MTK_HOSTAPD_SUPPORT
		file = get_dat_path_by_ord(0);
#else
		dat_ctx2 = dat_load_by_index(0);
		if (!dat_ctx2) {
			err(DEBUG_CAT_MISC, "load file fail\n");
			ret = -1;
			goto out;
		}
		if (type == DRIVER_5G_PARAM)
			file = kvc_get(dat_ctx2, "BN1_profile_path");
#ifdef MAP_6E_SUPPORT
		else if (type == DRIVER_6G_PARAM)
			file = kvc_get(dat_ctx2, "BN2_profile_path");
#endif /* MAP_6E_SUPPORT */
		else
			file = kvc_get(dat_ctx2, "BN0_profile_path");
#endif /* MTK_HOSTAPD_SUPPORT */
	}

	if (!file) {
		err(DEBUG_CAT_MISC, "invalid file; type=%d(%s)\n", type,
			get_map_param_type_str(type));
		ret = -1;
		goto out;
	}

	dat_ctx = kvc_load(file, LF_FLOCK|LF_KEY_CASE_SENSITIVE);
	if (!dat_ctx) {
		err(DEBUG_CAT_MISC, "load file(%s) fail\n", file);
		ret = -1;
		goto out;
	}

	tmp_value = kvc_get(dat_ctx, (const char *)param);
	if (!tmp_value) {
		err(DEBUG_CAT_MISC, "get param(%s) fail\n", param);
		ret = -1;
		goto out;
	}
	len = os_min(os_strlen(tmp_value), val_len - 1);
	os_memcpy(value, tmp_value, len);

	info(DEBUG_CAT_MISC, "param=%s; type=%d(%s); value=%s\n", param, type,
		get_map_param_type_str(type), value);
out:
#ifndef MTK_HOSTAPD_SUPPORT
	if (file && (type == DRIVER_PARAM))
		free_dat_path(file);
#ifdef MAP_R6
	if (file && (type == DRIVER_6G_PARAM))
		free_dat_path(file);
#endif
#else
	if (dat_ctx2)
		kvc_unload(dat_ctx2);
#endif /* MTK_HOSTAPD_SUPPORT */
	if (dat_ctx)
		kvc_unload(dat_ctx);

	return ret;
#else
	char cmd_buffer[256] = {0};
	char tmp_buffer[350] = {0};
	char temp_file[] = "/tmp/system_command_output";
	FILE *fp;

	os_memset(value, 0, val_len);
	os_snprintf(cmd_buffer, sizeof(cmd_buffer),"nvram_get 2860 %s > %s &", param, temp_file);
	if ((fp = popen(temp_file, "r")) == NULL) {
		err(DEBUG_CAT_MISC, "Error opening pipe!\n");
		return -1;
	}
	fscanf(fp, "%349s", tmp_buffer);

	os_memcpy(value, tmp_buffer, val_len);
	info(DEBUG_CAT_MISC, "get_map_parameter %s = %s\n", param, value);

	if(pclose(fp)) {
		err(DEBUG_CAT_MISC, "Command not found or exited with error status\n");
		return -1;
	}

	return 0;
#endif
}

#ifdef MAP_R6
int get_map_parameters_user_cfg(struct map_info *map, char *param, char *value, param_type type, size_t val_len)
{
#ifdef OPENWRT_SUPPORT
	const char *tmp_value = NULL;
	unsigned int len = 0;
	struct kvc_context *dat_ctx = NULL;
#ifdef MTK_HOSTAPD_SUPPORT
	struct kvc_context *dat_ctx2 = NULL;
#endif /* MTK_HOSTAPD_SUPPORT */
	const char *file = NULL;
	int ret = 0;

	debug(DEBUG_CAT_MLO, "param(%s)\n", param);

	os_memset(value, 0, val_len);

	if (type == NON_DRIVER_PARAM)
		file = map->map_user_cfg;
#ifdef MAP_R6
	else if (type == DRIVER_6G_PARAM) {
#ifndef MTK_HOSTAPD_SUPPORT
		file = get_dat_path_by_ord(0);
#else
		dat_ctx2 = dat_load_by_index(0);
		if (!dat_ctx2) {
			err(DEBUG_CAT_MLO, "load file fail\n");
			ret = -1;
			goto out;
		}
		file = kvc_get(dat_ctx2, "BN2_profile_path");
#endif /* MTK_HOSTAPD_SUPPORT */
	}
#endif
	else {
#ifndef MTK_HOSTAPD_SUPPORT
		file = get_dat_path_by_ord(0);
#else
		dat_ctx2 = dat_load_by_index(0);
		if (!dat_ctx2) {
			err(DEBUG_CAT_MLO, "load file fail\n");
			ret = -1;
			goto out;
		}
		file = kvc_get(dat_ctx2, "BN0_profile_path");
#endif /* MTK_HOSTAPD_SUPPORT */
	}

	if (!file) {
		err(DEBUG_CAT_MLO, "invalid file!!! type(%d)\n", type);
		ret = -1;
		goto out;
	}

	dat_ctx = kvc_load(file, LF_FLOCK|LF_KEY_CASE_SENSITIVE);
	if (!dat_ctx) {
		err(DEBUG_CAT_MLO, "load file(%s) fail\n", file);
		ret = -1;
		goto out;
	}

	tmp_value = kvc_get(dat_ctx, (const char *)param);
	if (!tmp_value) {
		err(DEBUG_CAT_MLO, "get param(%s) fail\n", param);
		ret = -1;
		goto out;
	}
	len = os_min(os_strlen(tmp_value), val_len - 1);
	os_memcpy(value, tmp_value, len);

	debug(DEBUG_CAT_MLO, "value(%s)\n", value);
out:
#ifndef MTK_HOSTAPD_SUPPORT
	if (file && (type == DRIVER_PARAM))
		free_dat_path(file);
#ifdef MAP_R6
	if (file && (type == DRIVER_6G_PARAM))
		free_dat_path(file);
#endif
#else
	if (dat_ctx2)
		kvc_unload(dat_ctx2);
#endif /* MTK_HOSTAPD_SUPPORT */
	if (dat_ctx)
		kvc_unload(dat_ctx);

	return ret;
#else
	char cmd_buffer[256] = {0};
	char tmp_buffer[350] = {0};
	char temp_file[] = "/tmp/system_command_output";
	FILE *fp;

	os_memset(value, 0, val_len);
	os_snprintf(cmd_buffer, sizeof(cmd_buffer), "nvram_get 2860 %s > %s &", param, temp_file);
	fp = popen(temp_file, "r");
	if (fp == NULL) {
		err(DEBUG_CAT_MLO, "Error opening pipe!\n");
		return -1;
	}
	fscanf(fp, "%349s", tmp_buffer);

	os_memcpy(value, tmp_buffer, val_len);
	debug(DEBUG_CAT_MLO, "get_map_parameter %s = %s\n", param, value);

	if (pclose(fp)) {
		err(DEBUG_CAT_MLO, "Command not found or exited with error status\n");
		return -1;
	}

	return 0;
#endif
}
#endif /* MAP_R6 */


#ifdef EM_PLUS_SUPPORT
void hapd_extract_conf_file(struct wifi_app *wapp, struct wapp_dev *wdev, char *file_name)
{
	char result[MAX_HAPD_CNF_FILE_SIZE] = {0};
	int ret = 0, value = 0;
	u8 bss_idx = 0, radio_idx = 0, hapd_cnf_idx = 0;

	os_memset(result, '\0', MAX_HAPD_CNF_FILE_SIZE);

	if (IS_OP_CLASS_24G(wdev->radio->opclass)) {
		radio_idx = 0;
		value = strtol(wdev->ifname + strlen(PREFIX_WIFI2G), NULL, 10);
		if (value < 0) {
			err(DEBUG_CAT_MISC, DPP_MAP_PREX"Invalid 2G band index:%d\n", value);
			value = 0;
		}
		bss_idx = value;
		hapd_cnf_idx = (bss_idx * 2) + radio_idx;
	} else if (IS_OP_CLASS_5G(wdev->radio->opclass)) {
		radio_idx = 1;
		value = strtol(wdev->ifname + strlen(PREFIX_WIFI5G), NULL, 10);
		if (value < 0) {
			err(DEBUG_CAT_MISC, DPP_MAP_PREX"Invalid 5G band index:%d\n", value);
			value = 0;
		}
		bss_idx = value;
		hapd_cnf_idx = (bss_idx * 2) + radio_idx;
	} else if (IS_OP_CLASS_6G(wdev->radio->opclass)) {
		radio_idx = 2;
		value = strtol(wdev->ifname + strlen(PREFIX_WIFI6G), NULL, 10);
		if (value < 0) {
			err(DEBUG_CAT_MISC, DPP_MAP_PREX"Invalid 6G band index:%d\n", value);
			value = 0;
		}
		bss_idx = value;
		hapd_cnf_idx = 16 + bss_idx;
	} else {
		err(DEBUG_CAT_MISC, DPP_MAP_PREX"Invalid band fail\n");
		return;
	}

	ret = os_snprintf(result, sizeof(result), "%s%d.conf", HAPD_CONFIG_PREFIX, hapd_cnf_idx);
	if (os_snprintf_error(sizeof(result), ret)) {
		err(DEBUG_CAT_MISC, "snprintf error in result copy!\n");
		return;
	}

	debug(DEBUG_CAT_MISC, "output result = %s\n", result);
	os_memcpy(file_name, result, sizeof(result));
}
#endif /* EM_PLUS_SUPPORT */

#ifdef MAP_R3_DE
void get_linux_ver(char *res)
{
	char result[DE_MAX_LEN];
	struct utsname buf;
	int ret;

	os_memset(result, '\0', DE_MAX_LEN);

	if (uname(&buf) < 0) {
		err(DEBUG_CAT_MISC, "Error uname call!\n");
		return;
	} else {
		ret = os_snprintf(result, sizeof(result), "%s %s", buf.sysname, buf.release);
		if (os_snprintf_error(sizeof(result), ret)) {
			err(DEBUG_CAT_MISC, "snprintf error in result copy!\n");
			return;
		}
		err(DEBUG_CAT_MISC, "uname output result = %s\n", result);
	}

	os_memcpy(res, result, sizeof(result));
	return;
}

int map_send_dev_inven(
	struct wifi_app *wapp, unsigned char *addr, char *evt_buf)
{
	int i = 0;
	struct wapp_dev *wdev = NULL, *wdev_temp = NULL;
	struct evt *map_event = NULL;
	int send_pkt_len = 0;
	struct dev_inven_ruid *de_ruid;
	struct dev_inven *de;

#ifdef EM_PLUS_SUPPORT
	int ret = 0;
#endif /* EM_PLUS_SUPPORT */

	unsigned char wdev_identifier[ETH_ALEN] = {0};
	struct dl_list *dev_list;
	dev_list = &wapp->dev_list;

	map_event = (struct evt *)evt_buf;
	map_event->type = WAPP_DEV_INVEN_TLV;
	map_event->length = sizeof(struct dev_inven);
	de = (struct dev_inven *) map_event->buffer;

	os_memset(de, '\0', sizeof(struct dev_inven));

	os_memcpy(de->sw_ver, "MAP_R3_v0.0.3", strlen("MAP_R3_v0.0.3"));
	de->sw_ver[strlen("MAP_R3_v0.0.3")] = '\0';
	de->sw_ver_len = strlen(de->sw_ver);

#ifdef EM_PLUS_SUPPORT
	os_memset(de->exec_env, 0, DE_MAX_LEN);
#endif /* EM_PLUS_SUPPORT */

	get_linux_ver(de->exec_env);
	de->exec_env_len = strlen(de->exec_env);
	if (!dl_list_empty(dev_list)) {
		dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
			if (wdev->radio) {
				struct map_conf_state *conf_state = &wdev->radio->conf_state;

				if (IS_CONF_STATE(conf_state, MAP_CONF_STOP))
					continue;

				MAP_GET_RADIO_IDNFER(wdev->radio, wdev_identifier);
				if (!os_memcmp(wdev_identifier, (char *)addr, ETH_ALEN) &&
						(wdev->dev_type == WAPP_DEV_TYPE_AP)) {
#ifdef EM_PLUS_SUPPORT
					ret = os_snprintf(de->ser_num, DE_MAX_LEN, ""MACSTR"", MAC2STR(wdev->mac_addr));
					if (os_snprintf_error(DE_MAX_LEN, ret)) {
						err(DEBUG_CAT_EVENT, "%d Unexpected snprintf fail\n", __LINE__);
						continue;
					}
					de->ser_num_len = os_strlen(de->ser_num);
#else
					os_memcpy(de->ser_num, wdev->mac_addr, ETH_ALEN);
					de->ser_num_len = ETH_ALEN;
#endif /* EM_PLUS_SUPPORT */
				}
			}
			de_ruid = &de->ruid[i];

			os_memcpy(de_ruid->identifier, wdev_identifier, ETH_ALEN);
#ifdef EM_PLUS_SUPPORT
			os_memset(de_ruid->chip_ven, 0, DE_MAX_LEN);
#endif /* EM_PLUS_SUPPORT */
			os_memcpy(de_ruid->chip_ven, "Mediatek", strlen("Mediatek"));
			de_ruid->chip_ven[strlen("Mediatek")] = '\0';
			de_ruid->chip_ven_len = strlen(de_ruid->chip_ven);
			i++;
		}
	}
	de->num_radio = MAX_RUID;
	send_pkt_len = sizeof(struct evt) + map_event->length;
	return send_pkt_len;
}
#endif /*MAP_R3_DE*/

#ifdef MAP_R3_WF6
int map_build_ap_wf6_cap(
	struct wifi_app *wapp, unsigned char *addr, char *evt_buf)
{
	struct wapp_dev *wdev = NULL;
	struct evt *map_event = NULL;
	struct ap_dev *ap = NULL;
	wdev_wf6_cap_roles *wf6_cap = NULL;
	int send_pkt_len = 0;
	int i = 0;
	struct ap_wf6_cap_roles *map_wf6_cap;

	wdev = wapp_dev_list_lookup_by_radio(wapp, (char *)addr);
	if (!wdev) {
		err(DEBUG_CAT_CAP, "%s null wdev\n", __func__);
		return 0;
	}

	debug(DEBUG_CAT_CAP, "WF6:WAPPD:%s Preparing the AP capa data in wapp to send to MAPD\n", __func__);

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		ap = (struct ap_dev *)wdev->p_dev;
		wf6_cap = &ap->wf6_cap;

		map_event = (struct evt *)evt_buf;
		map_event->type = WAPP_AP_WF6_CAPABILITY;
		map_event->length = sizeof(struct ap_wf6_cap_roles);
		map_wf6_cap = (struct ap_wf6_cap_roles *)map_event->buffer;

		if (wdev->radio) {
			MAP_GET_RADIO_IDNFER(wdev->radio, map_wf6_cap->identifier);
		}
		map_wf6_cap->role_supp = wf6_cap->role_supp;
#ifdef MAP_R4_SPT
		map_wf6_cap->sr_mode = ap->sr_info.sr_mode;
#endif
		for(i = 0; i < map_wf6_cap->role_supp; i++) {
			switch (wf6_cap->wf6_role[i].tx_stream) {
				case 1:
					map_wf6_cap->wf6_role[i].tx_stream = 0;
					break;
				case 2:
					map_wf6_cap->wf6_role[i].tx_stream = 1;
					break;
				case 3:
					map_wf6_cap->wf6_role[i].tx_stream = 2;
					break;
				case 4:
					map_wf6_cap->wf6_role[i].tx_stream = 3;
					break;
				case 5:
					map_wf6_cap->wf6_role[i].tx_stream = 4;
					break;
				case 6:
					map_wf6_cap->wf6_role[i].tx_stream = 5;
					break;
				case 7:
					map_wf6_cap->wf6_role[i].tx_stream = 6;
					break;
				case 8:
					map_wf6_cap->wf6_role[i].tx_stream = 7;
					break;
				default:
					notice(DEBUG_CAT_CAP, "%s: - Unknown HE Tx Spatial Stream!!\n", __func__);
					break;
			}

			switch (wf6_cap->wf6_role[i].rx_stream) {
				case 1:
					map_wf6_cap->wf6_role[i].rx_stream = 0;
					break;
				case 2:
					map_wf6_cap->wf6_role[i].rx_stream = 1;
					break;
				case 3:
					map_wf6_cap->wf6_role[i].rx_stream = 2;
					break;
				case 4:
					map_wf6_cap->wf6_role[i].rx_stream = 3;
					break;
				case 5:
					map_wf6_cap->wf6_role[i].rx_stream = 4;
					break;
				case 6:
					map_wf6_cap->wf6_role[i].rx_stream = 5;
					break;
				case 7:
					map_wf6_cap->wf6_role[i].rx_stream = 6;
					break;
				case 8:
					map_wf6_cap->wf6_role[i].rx_stream = 7;
					break;
				default:
					notice(DEBUG_CAT_CAP, "%s: - Unknown HE Rx Spatial Stream!!\n", __func__);
					break;
			}
			map_wf6_cap->wf6_role[i].he_160 = wf6_cap->wf6_role[i].he_160;
			map_wf6_cap->wf6_role[i].he_8080 = wf6_cap->wf6_role[i].he_8080;
			map_wf6_cap->wf6_role[i].he_mcs_len = wf6_cap->wf6_role[i].he_mcs_len;
			os_memcpy(map_wf6_cap->wf6_role[i].he_mcs, wf6_cap->wf6_role[i].he_mcs, wf6_cap->wf6_role[i].he_mcs_len);
			map_wf6_cap->wf6_role[i].su_bf_cap = wf6_cap->wf6_role[i].su_bf_cap;
			map_wf6_cap->wf6_role[i].mu_bf_cap = wf6_cap->wf6_role[i].mu_bf_cap;
			map_wf6_cap->wf6_role[i].dl_mu_mimo_ofdma_cap = wf6_cap->wf6_role[i].dl_mu_mimo_ofdma_cap;
			map_wf6_cap->wf6_role[i].dl_ofdma_cap = wf6_cap->wf6_role[i].dl_ofdma_cap;
			map_wf6_cap->wf6_role[i].ul_mu_mimo_ofdma_cap = wf6_cap->wf6_role[i].ul_mu_mimo_ofdma_cap;
			map_wf6_cap->wf6_role[i].ul_mu_mimo_cap = wf6_cap->wf6_role[i].ul_mu_mimo_cap;
			map_wf6_cap->wf6_role[i].ul_ofdma_cap = wf6_cap->wf6_role[i].ul_ofdma_cap;
			map_wf6_cap->wf6_role[i].agent_role = wf6_cap->wf6_role[i].agent_role;
			map_wf6_cap->wf6_role[i].su_beamformee_status = wf6_cap->wf6_role[i].su_beamformee_status;
			map_wf6_cap->wf6_role[i].beamformee_sts_less80 = wf6_cap->wf6_role[i].beamformee_sts_less80;
			map_wf6_cap->wf6_role[i].beamformee_sts_more80 = wf6_cap->wf6_role[i].beamformee_sts_more80;
			map_wf6_cap->wf6_role[i].max_user_dl_tx_mu_mimo = wf6_cap->wf6_role[i].max_user_dl_tx_mu_mimo;
			map_wf6_cap->wf6_role[i].max_user_ul_rx_mu_mimo = wf6_cap->wf6_role[i].max_user_ul_rx_mu_mimo;
			map_wf6_cap->wf6_role[i].max_user_dl_tx_ofdma = wf6_cap->wf6_role[i].max_user_dl_tx_ofdma;
			map_wf6_cap->wf6_role[i].max_user_ul_rx_ofdma = wf6_cap->wf6_role[i].max_user_ul_rx_ofdma;
			map_wf6_cap->wf6_role[i].rts_status = wf6_cap->wf6_role[i].rts_status;
			map_wf6_cap->wf6_role[i].mu_rts_status = wf6_cap->wf6_role[i].mu_rts_status;
			map_wf6_cap->wf6_role[i].m_bssid_status = wf6_cap->wf6_role[i].m_bssid_status;
			map_wf6_cap->wf6_role[i].mu_edca_status = wf6_cap->wf6_role[i].mu_edca_status;
			map_wf6_cap->wf6_role[i].twt_requester_status = wf6_cap->wf6_role[i].twt_requester_status;
			map_wf6_cap->wf6_role[i].twt_responder_status = wf6_cap->wf6_role[i].twt_responder_status;
		}
	}

	if (!map_event) {
		err(DEBUG_CAT_CAP, "%s null map_event\n", __func__);
		return 0;
	}
	send_pkt_len = sizeof(*map_event) + map_event->length;
	return send_pkt_len;
}

#endif /*MAP_R3_WF6*/

#ifdef MAP_R4_SPT
int map_build_spt_reuse_query(
	struct wifi_app *wapp, unsigned char *addr, char *evt_buf)
{
	struct wapp_dev *wdev = NULL;
	struct evt *map_event = NULL;
	struct ap_dev *ap = NULL;
	struct wapp_mesh_sr_info *spt_reuse = NULL;
	int send_pkt_len = 0;

	struct ap_spt_reuse_req *map_spt_reuse;

	wdev = wapp_dev_list_lookup_by_radio(wapp, (char *)addr);
	if (!wdev) {
		err(DEBUG_CAT_SR, "%s null wdev\n", __func__);
		return 0;
	}

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		ap = (struct ap_dev *)wdev->p_dev;
		if(!ap)
			return 0;
		spt_reuse = &ap->sr_info;

		map_event = (struct evt *)evt_buf;
		map_event->type = WAPP_AP_SPT_REUSE_REQ;
		map_event->length = sizeof(struct ap_spt_reuse_req);
		map_spt_reuse = (struct ap_spt_reuse_req *)map_event->buffer;

		if (wdev->radio) {
			MAP_GET_RADIO_IDNFER(wdev->radio, map_spt_reuse->identifier);
		}

		debug(DEBUG_CAT_SR, "DM: identifer"MACSTR"\n", MAC2STR(map_spt_reuse->identifier));
		map_spt_reuse->bss_color = 8;
		map_spt_reuse->hesiga_spa_reuse_val_allowed = 1;
		map_spt_reuse->srg_info_valid = 1;
		map_spt_reuse->nonsrg_offset_valid = 0;
		map_spt_reuse->psr_disallowed = 0;
		map_spt_reuse->nonsrg_obsspd_max_offset = 75;
		map_spt_reuse->srg_obsspd_min_offset = 0;
		map_spt_reuse->srg_obsspd_max_offset = 110;
		os_memcpy(map_spt_reuse->srg_bss_color_bitmap, (unsigned
		char*)&spt_reuse->bm_info.color_31_0, 8);
		os_memcpy(map_spt_reuse->srg_partial_bssid_bitmap, (unsigned
		char*)&spt_reuse->bm_info.bssid_31_0, 8);
	}

	if (!map_event) {
		err(DEBUG_CAT_SR, "%s null map_event\n", __func__);
		return 0;
	}
	send_pkt_len = sizeof(*map_event) + map_event->length;
	return send_pkt_len;
}
#endif


int map_build_ap_he_cap(
	struct wifi_app *wapp, unsigned char *addr, char *evt_buf)
{
	struct wapp_dev *wdev = NULL;
	struct evt *map_event = NULL;
	struct ap_dev *ap = NULL;
	wdev_he_cap *he_cap = NULL;
	int send_pkt_len = 0;
	struct ap_he_capability *map_he_cap;

	wdev = wapp_dev_list_lookup_by_radio(wapp, (char *)addr);
	if (!wdev) {
		err(DEBUG_CAT_CAP, "%s null wdev\n", __func__);
		return 0;
	}

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		ap = (struct ap_dev *)wdev->p_dev;
		he_cap = &ap->he_cap;

		map_event = (struct evt *)evt_buf;
		if (!map_event) {
			err(DEBUG_CAT_CAP, "%s null map_event\n", __func__);
			return 0;
		}
		map_event->type = WAPP_AP_HE_CAPABILITY;
		map_event->length = sizeof(struct ap_he_capability);
		map_he_cap = (struct ap_he_capability *)map_event->buffer;

		if (wdev->radio) {
			MAP_GET_RADIO_IDNFER(wdev->radio, map_he_cap->identifier);
		}

		switch (he_cap->tx_stream) {
			case 1:
				map_he_cap->tx_stream = 0;
				break;
			case 2:
				map_he_cap->tx_stream = 1;
				break;
			case 3:
				map_he_cap->tx_stream = 2;
				break;
			case 4:
				map_he_cap->tx_stream = 3;
				break;
			case 5:
				map_he_cap->tx_stream = 4;
				break;
			case 6:
				map_he_cap->tx_stream = 5;
				break;
			case 7:
				map_he_cap->tx_stream = 6;
				break;
			case 8:
				map_he_cap->tx_stream = 7;
				break;
			default:
				notice(DEBUG_CAT_CAP,  "%s: - Unknown HE Tx Spatial Stream!!\n", __func__);
				break;
		}

		switch (he_cap->rx_stream) {
			case 1:
				map_he_cap->rx_stream = 0;
				break;
			case 2:
				map_he_cap->rx_stream = 1;
				break;
			case 3:
				map_he_cap->rx_stream = 2;
				break;
			case 4:
				map_he_cap->rx_stream = 3;
				break;
			case 5:
				map_he_cap->rx_stream = 4;
				break;
			case 6:
				map_he_cap->rx_stream = 5;
				break;
			case 7:
				map_he_cap->rx_stream = 6;
				break;
			case 8:
				map_he_cap->rx_stream = 7;
				break;
			default:
			 notice(DEBUG_CAT_CAP, "%s: - Unknown HE Rx Spatial Stream!!\n", __func__);
				break;
		}
		map_he_cap->he_160 = he_cap->he_160;
		map_he_cap->he_8080 = he_cap->he_8080;
		map_he_cap->he_mcs_len = he_cap->he_mcs_len;
		os_memcpy(map_he_cap->he_mcs, he_cap->he_mcs, he_cap->he_mcs_len);
		map_he_cap->su_bf_cap = he_cap->su_bf_cap;
		map_he_cap->mu_bf_cap = he_cap->mu_bf_cap;
		map_he_cap->dl_mu_mimo_ofdma_cap = he_cap->dl_mu_mimo_ofdma_cap;
		map_he_cap->dl_ofdma_cap = he_cap->dl_ofdma_cap;
		map_he_cap->ul_mu_mimo_ofdma_cap = he_cap->ul_mu_mimo_ofdma_cap;
		map_he_cap->ul_mu_mimo_cap = he_cap->ul_mu_mimo_cap;
		map_he_cap->ul_ofdma_cap = he_cap->ul_ofdma_cap;
	}

	if (!map_event) {
		err(DEBUG_CAT_CAP, "%s null map_event\n", __func__);
		return 0;
	}
	send_pkt_len = sizeof(*map_event) + map_event->length;
	return send_pkt_len;
}

#ifdef MAP_EHT_SUPPORT
int map_build_ap_eht_cap(
	struct wifi_app *wapp, unsigned char *addr, char *evt_buf)
{
	struct wapp_dev *wdev = NULL;
	struct evt *map_event = NULL;
	struct ap_dev *ap = NULL;
	struct wdev_eht_cap *eht_cap = NULL;
	int send_pkt_len = 0;
	struct ap_eht_capability *map_eht_cap;

	wdev = wapp_dev_list_lookup_by_radio(wapp, (char *)addr);

	if (!wdev) {
		err(DEBUG_CAT_EHT_CAP, "%s null wdev\n", __func__);
		return 0;
	}

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		ap = (struct ap_dev *)wdev->p_dev;
		eht_cap = &ap->eht_cap;

		map_event = (struct evt *)evt_buf;
		if (!map_event) {
			err(DEBUG_CAT_EHT_CAP, "%s null map_event\n", __func__);
			return 0;
		}
		map_event->type = WAPP_AP_EHT_CAPABILITY;
		map_event->length = sizeof(struct ap_eht_capability);
		map_eht_cap = (struct ap_eht_capability *)map_event->buffer;

		if (wdev->radio)
			MAP_GET_RADIO_IDNFER(wdev->radio, map_eht_cap->identifier);
		switch (eht_cap->tx_stream) {
		case 1:
			map_eht_cap->tx_stream = 0;
			break;
		case 2:
			map_eht_cap->tx_stream = 1;
			break;
		case 3:
			map_eht_cap->tx_stream = 2;
			break;
		case 4:
			map_eht_cap->tx_stream = 3;
			break;
		case 5:
			map_eht_cap->tx_stream = 4;
			break;
		case 6:
			map_eht_cap->tx_stream = 5;
			break;
		case 7:
			map_eht_cap->tx_stream = 6;
			break;
		case 8:
			map_eht_cap->tx_stream = 7;
			break;
		default:
			notice(DEBUG_CAT_EHT_CAP, "%s:Unknown EHT Tx Spatial Stream!!\n", __func__);
			break;
		}
		switch (eht_cap->rx_stream) {
		case 1:
			map_eht_cap->rx_stream = 0;
			break;
		case 2:
			map_eht_cap->rx_stream = 1;
			break;
		case 3:
			map_eht_cap->rx_stream = 2;
			break;
		case 4:
			map_eht_cap->rx_stream = 3;
			break;
		case 5:
			map_eht_cap->rx_stream = 4;
			break;
		case 6:
			map_eht_cap->rx_stream = 5;
			break;
		case 7:
			map_eht_cap->rx_stream = 6;
			break;
		case 8:
			map_eht_cap->rx_stream = 7;
			break;
		default:
			notice(DEBUG_CAT_EHT_CAP, "%s:Unknown EHT Rx Spatial Stream!!\n", __func__);
			break;
		}
		map_eht_cap->eht_ch_width = eht_cap->eht_ch_width;
		map_eht_cap->ccfs0 = eht_cap->ccfs0;
		map_eht_cap->ccfs1 = eht_cap->ccfs1;
	}

	if (!map_event) {
		err(DEBUG_CAT_EHT_CAP, "%s null map_event\n", __func__);
		return 0;
	}
	send_pkt_len = sizeof(*map_event) + map_event->length;
	return send_pkt_len;
}
#endif
#if defined(MAP_R6) || defined(EM_PLUS_SUPPORT)
void find_ruid(
	struct wapp_dev *wdev, struct wifi7_ap_mlo_capability *map_mlo_cap, int index)
{
	MAP_GET_RADIO_IDNFER(wdev->radio, map_mlo_cap->mlo_cap.record[index].identifier);
}

int wapp_get_max_num_aff_ap(struct wifi_app *wapp)
{
	struct wapp_dev *wdev;
	int count = 0;
	struct dl_list *dev_list;

	dev_list = &wapp->dev_list;
	dl_list_for_each(wdev, dev_list, struct wapp_dev, list) {
		if (wdev->dev_type == WAPP_DEV_TYPE_AP && wdev->radio) {
			struct ap_dev *ap = (struct ap_dev *)wdev->p_dev;

			if (ap->isActive == WAPP_BSS_START)
				count++;
		}
	}
	err(DEBUG_CAT_EHT_CAP, "count = %d\n", count);
	return count;
}

int wapp_get_max_num_mld(struct wifi_app *wapp)
{
	struct wapp_dev *wdev;
	int count = 0;
	struct dl_list *dev_list;
	int radio_count = get_valid_radio_count(wapp);

	dev_list = &wapp->dev_list;
	dl_list_for_each(wdev, dev_list, struct wapp_dev, list) {
		if (wdev->dev_type == WAPP_DEV_TYPE_AP && wdev->radio)
			count++;
	}
	err(DEBUG_CAT_EHT_CAP, "radio_count = %d count = %d\n", radio_count, count);
	count = count/radio_count;
	return count;
}


int wapp_get_sta_radio_num(struct wifi_app *wapp)
{
	struct wapp_dev *wdev;
	int count = 0;
	struct dl_list *dev_list;

	dev_list = &wapp->dev_list;
	dl_list_for_each(wdev, dev_list, struct wapp_dev, list) {
		if (wdev->dev_type == WAPP_DEV_TYPE_STA && wdev->radio)
			count++;
	}
	err(DEBUG_CAT_EHT_CAP, "count = %d\n", count);
	return count;
}


int map_build_wifi7_ap_mlo_cap(
	struct wifi_app *wapp, unsigned char *addr, char *evt_buf)
{
	struct wapp_dev *wdev = NULL;
	struct evt *map_event = NULL;
	struct ap_dev *ap = NULL;
	int send_pkt_len = 0;
	int i;
	//struct wdev_wifi7_mlo_caps *wifi7_mlo_cap = NULL;
	struct wifi7_ap_mlo_capability *map_mlo_cap;
	struct wapp_dev *wdev_2g = NULL;
	struct wapp_dev *wdev_5g = NULL;
	struct wapp_dev *wdev_6g = NULL;
	struct wapp_dev *wdev_tmp = NULL;
	struct dl_list *dev_list;
	struct wdev_mlo_caps *mlo_cap = NULL;
	int count = 0;
	dev_list = &wapp->dev_list;

	wdev = wapp_dev_list_lookup_by_radio(wapp, (char *)addr);
	if (!wdev) {
		err(DEBUG_CAT_WIFI7_CAP, "%s null wdev\n", __func__);
		return 0;
	}
	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		ap = (struct ap_dev *)wdev->p_dev;
		//wifi7_mlo_cap = &ap->wifi7_mlo_cap;
		mlo_cap = &ap->mlo_cap;

		map_event = (struct evt *)evt_buf;
		if (!map_event) {
			err(DEBUG_CAT_WIFI7_CAP, "%s null map_event\n", __func__);
			return 0;
		}
		map_event->type = WAPP_MLO_CAPABILITY;
		map_mlo_cap = (struct wifi7_ap_mlo_capability *)map_event->buffer;
		if (wdev->radio)
			MAP_GET_RADIO_IDNFER(wdev->radio, map_mlo_cap->identifier);
		count = wapp_get_max_num_mld(wapp);
		if (count)
			map_mlo_cap->mlo_cap.max_num_mld = count;

		count = wapp_get_max_num_aff_ap(wapp);
		if (count && (count - 1) >= 0 && (count - 1) <= 14)
			map_mlo_cap->mlo_cap.ap_max_link = count - 1;
		else
			map_mlo_cap->mlo_cap.ap_max_link = 0;

		count = wapp_get_sta_radio_num(wapp);
		if (count && (count - 1) >= 0 && (count - 1) <= 14)
			map_mlo_cap->mlo_cap.bsta_max_link = count - 1;
		else
			map_mlo_cap->mlo_cap.bsta_max_link = 0;

		map_mlo_cap->mlo_cap.tid_to_link_map = 0;
		map_mlo_cap->mlo_cap.legacy = 1;

		if (mlo_cap != NULL) {
			for (i = 0; i < mlo_cap->RoleNum && i < MAX_ROLE_NUM; i++) {
				if (mlo_cap->MloCapPerRole[i].DeviceRole == 0) {
					map_mlo_cap->mlo_cap.ap_str_support = 1;
					map_mlo_cap->mlo_cap.ap_nstr_support = 0;
					map_mlo_cap->mlo_cap.ap_emlsr_support = mlo_cap->MloCapPerRole[i].EmlCap.emlsr_supp;
					map_mlo_cap->mlo_cap.ap_emlmr_support = mlo_cap->MloCapPerRole[i].EmlCap.emlmr_supp;
				} else if (mlo_cap->MloCapPerRole[i].DeviceRole == 1) {
					map_mlo_cap->mlo_cap.sta_str_support = 1;
					map_mlo_cap->mlo_cap.sta_nstr_support = 0;
					map_mlo_cap->mlo_cap.sta_emlsr_support =  mlo_cap->MloCapPerRole[i].EmlCap.emlsr_supp;
					map_mlo_cap->mlo_cap.sta_emlmr_support = mlo_cap->MloCapPerRole[i].EmlCap.emlmr_supp;
				}
			}

		} else {
			map_mlo_cap->mlo_cap.ap_str_support = 1;
			map_mlo_cap->mlo_cap.ap_nstr_support = 0;
			map_mlo_cap->mlo_cap.ap_emlsr_support = 1;
			map_mlo_cap->mlo_cap.ap_emlmr_support = 0;
			map_mlo_cap->mlo_cap.sta_str_support = 1;
			map_mlo_cap->mlo_cap.sta_nstr_support = 0;
			map_mlo_cap->mlo_cap.sta_emlsr_support = 1;
			map_mlo_cap->mlo_cap.sta_emlmr_support = 0;
		}

		map_mlo_cap->mlo_cap.num_ap_str_records = 3;
		map_mlo_cap->mlo_cap.num_ap_nstr_records = 0;
		map_mlo_cap->mlo_cap.num_ap_emlsr_records = 3;
		map_mlo_cap->mlo_cap.num_ap_emlmr_records = 0;
		map_mlo_cap->mlo_cap.num_sta_str_records = 3;
		map_mlo_cap->mlo_cap.num_sta_nstr_records = 0;
		map_mlo_cap->mlo_cap.num_sta_emlsr_records = 3;
		map_mlo_cap->mlo_cap.num_sta_emlmr_records = 0;

		map_mlo_cap->mlo_cap.total_ap_sta_records = ((map_mlo_cap->mlo_cap.num_ap_str_records) +
		(map_mlo_cap->mlo_cap.num_ap_nstr_records) + (map_mlo_cap->mlo_cap.num_ap_emlsr_records)
		+ (map_mlo_cap->mlo_cap.num_ap_emlmr_records) + (map_mlo_cap->mlo_cap.num_sta_str_records)
		+ (map_mlo_cap->mlo_cap.num_sta_nstr_records) + (map_mlo_cap->mlo_cap.num_sta_emlsr_records)
		+ (map_mlo_cap->mlo_cap.num_sta_emlmr_records));

		debug(DEBUG_CAT_WIFI7_CAP, "find wdev corresponding to all radios\n");
		dl_list_for_each_safe(wdev, wdev_tmp, dev_list, struct wapp_dev, list) {
			if ((wdev->radio) && (wdev->radio->opclass) && (wdev->radio->op_ch)) {
				if (IS_OP_CLASS_6G(wdev->radio->opclass) && IS_MAP_CH_6G(wdev->radio->op_ch)) {
					if (!wdev_6g)
						wdev_6g = wdev;
					continue;
				} else if (IS_OP_CLASS_5G(wdev->radio->opclass) && IS_MAP_CH_5G(wdev->radio->op_ch)) {
					if (!wdev_5g)
						wdev_5g = wdev;
					continue;
				} else if (IS_OP_CLASS_24G(wdev->radio->opclass) && IS_MAP_CH_24G(wdev->radio->op_ch)) {
					if (!wdev_2g)
						wdev_2g = wdev;
					continue;
				}
			}
		}

		for (i = 0; i < map_mlo_cap->mlo_cap.total_ap_sta_records; i = i+3) {
			if (wdev_2g)
				find_ruid(wdev_2g, map_mlo_cap, i);
			else
				os_memset(map_mlo_cap->mlo_cap.record[i].identifier, 0, ETH_ALEN);
			if (wdev_5g)
				find_ruid(wdev_5g, map_mlo_cap, (i+1));
			else
				os_memset(map_mlo_cap->mlo_cap.record[i+1].identifier, 0, ETH_ALEN);
			if (wdev_6g)
				find_ruid(wdev_6g, map_mlo_cap, (i+2));
			else
				os_memset(map_mlo_cap->mlo_cap.record[i+2].identifier, 0, ETH_ALEN);
			map_mlo_cap->mlo_cap.record[i].freq_separation = 0;
			map_mlo_cap->mlo_cap.record[i+1].freq_separation = 0;
			map_mlo_cap->mlo_cap.record[i+2].freq_separation = 0;
		}
		map_event->length = (sizeof(struct wifi7_ap_mlo_capability) +
				((map_mlo_cap->mlo_cap.total_ap_sta_records) * sizeof(struct mlo_record)));
	}
	if (!map_event) {
		err(DEBUG_CAT_WIFI7_CAP, "%s null map_event\n", __func__);
		return 0;
	}
	send_pkt_len = (sizeof(*map_event) + map_event->length);
	return send_pkt_len;
}
#endif
#ifdef MTK_MLO_MAP_SUPPORT
int map_build_ap_mlo_cap(
	struct wifi_app *wapp, unsigned char *addr, char *evt_buf)
{
	struct wapp_dev *wdev = NULL;
	struct evt *map_event = NULL;
	struct ap_dev *ap = NULL;
	struct wdev_mlo_caps *mlo_cap = NULL;
	int send_pkt_len = 0;
	int i = 0;
	struct ap_mlo_capability *map_mlo_cap;

	wdev = wapp_dev_list_lookup_by_radio(wapp, (char *)addr);

	if (!wdev) {
		err(DEBUG_CAT_WIFI7_CAP, "%s null wdev\n", __func__);
		return 0;
	}

	if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
		ap = (struct ap_dev *)wdev->p_dev;
		mlo_cap = &ap->mlo_cap;

		map_event = (struct evt *)evt_buf;
		if (!map_event) {
			err(DEBUG_CAT_WIFI7_CAP, "%s null map_event\n", __func__);
			return 0;
		}
		map_event->type = WAPP_MLO_CAPABILITY;
		map_event->length = sizeof(struct ap_mlo_capability);
		map_mlo_cap = (struct ap_mlo_capability *)map_event->buffer;

		if (wdev->radio)
			MAP_GET_RADIO_IDNFER(wdev->radio, map_mlo_cap->identifier);
		map_mlo_cap->RoleNum = mlo_cap->RoleNum;
		for (i = 0; i < mlo_cap->RoleNum && i < MAX_ROLE_NUM; i++) {
			map_mlo_cap->MloCapPerRole[i].DeviceRole = mlo_cap->MloCapPerRole[i].DeviceRole;
			map_mlo_cap->MloCapPerRole[i].StatPunctureSupport = mlo_cap->MloCapPerRole[i].StatPunctureSupport;
			map_mlo_cap->MloCapPerRole[i].MloEnable = mlo_cap->MloCapPerRole[i].MloEnable;
			os_memcpy(&map_mlo_cap->MloCapPerRole[i].EmlCap, &mlo_cap->MloCapPerRole[i].EmlCap, sizeof(struct eml_caps_info));
			os_memcpy(&map_mlo_cap->MloCapPerRole[i].MldCap, &mlo_cap->MloCapPerRole[i].MldCap, sizeof(struct mld_caps_info));
		}
	}

	if (!map_event) {
		err(DEBUG_CAT_WIFI7_CAP, "%s null map_event\n", __func__);
		return 0;
	}
	send_pkt_len = sizeof(*map_event) + map_event->length;
	return send_pkt_len;
}
#endif

void wapp_reset_backhaul_config(struct wifi_app *wapp, struct wapp_dev *wappdev)
{
	struct wapp_dev *wdev, *wdev_temp = NULL;
	struct dl_list *dev_list;
	int ret;
#if WEXT_SUPPORT
	u8 Enable = 0;
#endif

	 /* This if condition should only be called during wapp init*/
	if (wappdev && wappdev->dev_type == WAPP_DEV_TYPE_AP) {
#if WEXT_SUPPORT
		wapp_set_fhbss(wapp, (const char *)wappdev->ifname,
				(char *)&Enable, 1);
		Enable = 1;
		wapp_set_fhbss(wapp, (const char *)wappdev->ifname,
				(char *)&Enable, 1);
#else
		ret = wdev_set_ap_fhbss(wapp, wappdev, 0);
		if (ret != WAPP_SUCCESS)
			err(DEBUG_CAT_MISC, "disable fhbss fail for %s\n", wappdev->ifname);

		ret = wdev_set_ap_fhbss(wapp, wappdev, 1);
		if (ret != WAPP_SUCCESS)
			err(DEBUG_CAT_MISC, "enable fhbss fail for %s\n", wappdev->ifname);
#endif
	} else {
		dev_list = &wapp->dev_list;
		if (!dl_list_empty(dev_list)) {
			dl_list_for_each_safe(wdev, wdev_temp, dev_list, struct wapp_dev, list) {
				if (wdev->dev_type == WAPP_DEV_TYPE_AP) {
#if WEXT_SUPPORT
					Enable = 0;
					wapp_set_fhbss(wapp, (const char *)wdev->ifname,
							(char *)&Enable, 1);
					Enable = 1;
					if (wdev->i_am_fh_bss) {
						wapp_set_fhbss(wapp, (const char *)wdev->ifname,
								(char *)&Enable, 1);
					}
#else
					ret = wdev_set_ap_fhbss(wapp, wdev, 0);
					if (ret != WAPP_SUCCESS)
						err(DEBUG_CAT_MISC, "disable fhbss fail for %s\n", wdev->ifname);
					if (wdev->i_am_fh_bss) {
						ret = wdev_set_ap_fhbss(wapp, wdev, 1);
						if (ret != WAPP_SUCCESS)
							err(DEBUG_CAT_MISC, "enable fhbss fail for %s\n", wdev->ifname);
					}
#endif
				}
			}
		}
	}
}

#ifdef MAP_R2
int map_build_metric_reporting_info(
	struct wifi_app *wapp, unsigned char *addr, char *evt_buf)
{
	struct evt *map_event = NULL;
	u32 *metric_rep_interval = 0;
	int send_pkt_len = 0;

	map_event = (struct evt *)evt_buf;
	map_event->type = WAPP_METRIC_REP_INTERVAL_CAP;
	map_event->length = sizeof(u32);
	metric_rep_interval = (u32 *)map_event->buffer;

	*metric_rep_interval = wapp->map->metric_rep_intv;

	notice(DEBUG_CAT_STATS, "%s metric_rep_interval= %d\n", __func__, *metric_rep_interval);

	send_pkt_len = sizeof(*map_event) + map_event->length;
	return send_pkt_len;
}

#endif
int map_cmd_set_beacon_state( struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	struct wapp_dev *ap_wdev = NULL;
	char idfr[MAC_ADDR_LEN];
	u8 i;
	int ret;


	if (!argv[1]) {
		err(DEBUG_CAT_MISC, "Invalid argument\n");
		return WAPP_INVALID_ARG;
	}

	for (i = 0; i < MAX_NUM_OF_RADIO; i++) {
		if (wapp->radio[i].adpt_id) {
			struct wapp_radio *ra = &wapp->radio[i];
			MAP_GET_RADIO_IDNFER(ra, idfr);
			ap_wdev = wapp_dev_list_lookup_by_radio(wapp, idfr);
			if (!ap_wdev) {
				err(DEBUG_CAT_MISC, "null wdev\n");
				continue;
			}
#if WEXT_SUPPORT
			u8 diable = 0;
			u8 enable = 1;

			if (os_strcmp(argv[1], "en") == 0) {
				wapp_set_v10converter(wapp, (const char *)ap_wdev->ifname,
								(char *)&enable,1);
			} else {
				wapp_set_v10converter(wapp, (const char *)ap_wdev->ifname,
								(char *)&disable,1);
			}
#else
			if (os_strcmp(argv[1], "en") == 0) {
				ret = wdev_set_v10converter(wapp, ap_wdev, 1);
				if (ret != 0) {
					err(DEBUG_CAT_MISC, "wdev_set_v10converter fail\n");
					continue;
				}
			} else {
				ret = wdev_set_v10converter(wapp, ap_wdev, 0);
				if (ret != 0) {
					err(DEBUG_CAT_MISC, "wdev_set_v10converter fail\n");
					continue;
				}
			}
#endif /* WEXT_SUPPORT */
		}
	}
	return WAPP_SUCCESS;
}

void map_update_bh_link_info(struct wifi_app *wapp, unsigned char type, u8 action, u32 ifindex)
{
	struct wapp_dev *wdev = NULL;
	struct bh_link *link = NULL, *tmp = NULL;
	u8 is_exist = 0;
#ifdef MAP_R3
	struct dpp_authentication *auth = NULL;
#endif
	if (type == MAP_BH_ETH) {
		dl_list_for_each_safe(link, tmp, &wapp->map->bh_link_list, struct bh_link, list) {
			if (type == MAP_BH_ETH && link->type == type) {
				is_exist = 1;
				break;
			}
		}
		if (!action && is_exist){
#ifdef MAP_R3
		if ((wapp->map->map_version == DEV_TYPE_R3) && wapp->dpp) {
			wapp->dpp->dpp_eth_conn_ind = FALSE;
			auth = wapp_dpp_get_first_auth(wapp);
			if (auth && wapp->dpp->dpp_allowed_roles == DPP_CAPAB_ENROLLEE) {
				err(DEBUG_CAT_WIFI_CONFIG, "Auth deinit\n");
				wapp_dpp_cancel_timeouts(wapp, auth);
				dpp_auth_deinit(auth);
			} else {
				err(DEBUG_CAT_WIFI_CONFIG, "Auth not found, not deinit\n");
			}
		}
#endif
			dl_list_del(&link->list);
			os_free(link);
			wapp->map->bh_link_num--;
			err(DEBUG_CAT_WIFI_CONFIG, "remove eth bh link; bh_link_num(%d)\n", wapp->map->bh_link_num);
		} else if (action && !is_exist) {
			link = (struct bh_link *)os_zalloc(sizeof(struct bh_link));
			if (link == NULL) {
				err(DEBUG_CAT_WIFI_CONFIG, "alloc bh_links fail for eth\n");
				return;
			}
			link->type = type;
			dl_list_add_tail(&wapp->map->bh_link_list, &link->list);
			wapp->map->bh_link_num++;
			notice(DEBUG_CAT_WIFI_CONFIG, "add eth bh link; bh_link_num(%d)\n", wapp->map->bh_link_num);
		}
	} else {
		wdev = wapp_dev_list_lookup_by_ifindex(wapp, ifindex);
		if (!wdev) {
			err(DEBUG_CAT_WIFI_CONFIG, "find wdev fail based on ifindex(%d)\n", ifindex);
			return;
		}
		dl_list_for_each_safe(link, tmp, &wapp->map->bh_link_list, struct bh_link, list) {
			if (type == MAP_BH_WIFI && !os_memcmp(link->bssid, wdev->mac_addr, MAC_ADDR_LEN)) {
				is_exist = 1;
				break;
			}
		}
		if (action == 0 && is_exist == 1) { // disassoc case
			dl_list_del(&link->list);
			os_free(link);
			wapp->map->bh_link_num--;
			notice(DEBUG_CAT_WIFI_CONFIG, "remove wifi link mac: "MACSTR" bh_link_num(%d)\n",
				MAC2STR(wdev->mac_addr), wapp->map->bh_link_num);
		} else if (action == 1 && !is_exist) { // assoc case
			/*create New link*/
			link = (struct bh_link *)os_zalloc(sizeof(struct bh_link));
			if(link == NULL) {
				err(DEBUG_CAT_WIFI_CONFIG, "alloc bh_links fail for wifi\n");
				return;
			}
			os_memcpy(link->bssid, wdev->mac_addr, MAC_ADDR_LEN);
			link->type = type;
			dl_list_add_tail(&wapp->map->bh_link_list, &link->list);
			wapp->map->bh_link_num++;
			notice(DEBUG_CAT_WIFI_CONFIG, "add wifi link mac: "MACSTR" bh_link_num(%d)\n",
				MAC2STR(wdev->mac_addr), wapp->map->bh_link_num);
		}
	}
}

#ifdef DFS_SLAVE_SUPPORT
int map_cmd_slave_bcn_en(struct wifi_app *wapp, const char *iface, u8 argc, char **argv)
{
	unsigned char i = 0, conf_done = 0;

	if (!argv[1]) {
		err(DEBUG_CAT_MISC, "Invalid argument\n");
		return WAPP_INVALID_ARG;
	}

	notice(DEBUG_CAT_MISC, "[DFS-SLAVE]argv[%s]\n", argv[1]);

	if (os_strcmp(argv[1], "en") == 0) {
		conf_done = 1;
		for (i = 0; i < MAX_NUM_OF_RADIO; i++) {
			if (wapp->radio[i].adpt_id &&
				wapp->radio[i].op_ch &&
				!(wapp->radio[i].conf_state.state == MAP_CONF_CONFED)) {
				conf_done = 0;
				break;
			}
		}
		notice(DEBUG_CAT_MISC, "[DFS-SLAVE]conf_done:%d\n", conf_done);
		if (conf_done)
			wapp_update_beacon(wapp, TRUE);
	} else
		wapp_update_beacon(wapp, FALSE);

	return WAPP_SUCCESS;
}
#endif /* DFS_SLAVE_SUPPORT */

#ifdef STANDARD_NL_CMD
int wapp_get_country(struct wifi_app *wapp, char *country_code)
{
	if (!wapp->drv_ops ||
		!wapp->drv_ops->drv_get_country)
		return -1;

	return wapp->drv_ops->drv_get_country(wapp->drv_data, country_code);
}

int wapp_get_feature(struct wifi_app *wapp, struct phy_info *phy)
{
	if (!wapp->drv_ops ||
		!wapp->drv_ops->drv_get_feature)
		return -1;

	return wapp->drv_ops->drv_get_feature(wapp->drv_data, phy);
}

struct wapp_radio *get_radio_by_phy_id(struct wifi_app *wapp, u8 phy_id)
{
	int i = 0;

	for (i = 0; i < MAX_NUM_OF_RADIO; i++) {
		if ((wapp->radio[i].radio_id == phy_id) &&
			(wapp->radio[i].onoff == RADIO_ON))
			return &wapp->radio[i];
	}

	return NULL;
}

int assign_nop_channels(struct wifi_app *wapp)
{
	struct phy_info *phy = NULL;
	struct channel_data *channel = NULL;
	u8 i = 0;

	dl_list_for_each(phy, &wapp->phy_head, struct phy_info, list) {
		if (!check_5G_by_freq((unsigned int)phy->channels[0].freq)) {
			debug(DEBUG_CAT_CHANNEL, "not 5G; no cac\n");
			continue;
		}
		for (i = 0; i < phy->num_channels; i++) {
			channel = &phy->channels[i];
			if (is_bit_set(channel->flag, CHAN_DISABLED)) {
				update_primary_ch_status(channel->chan, FALSE);
				continue;
			}
			if ((channel->flag & CHAN_DFS_AVAILABLE) == CHAN_DFS_AVAILABLE)
				continue;
			else if ((channel->flag & CHAN_DFS_UNAVAILABLE) == CHAN_DFS_UNAVAILABLE)
				update_primary_ch_status(channel->chan, FALSE);
		}
	}
	dump_primary_ch_status();

	return 0;
}

void dump_cac_status(struct cac_status_report_lib *status)
{
	u8 i = 0;

	if (!status) {
		err(DEBUG_CAT_DFS, "invalid cac cap\n");
		return;
	}

	notice(DEBUG_CAT_DFS, "allowed_channel=%d\n",
		status->allowed_channel_num);
	for (i = 0; i < status->allowed_channel_num; i++) {
		notice(DEBUG_CAT_DFS, "opclass=%d ch=%d time=%d\n",
			status->allowed_channel[i].op_class,
			status->allowed_channel[i].ch_num,
			status->allowed_channel[i].cac_interval);
	}
	notice(DEBUG_CAT_DFS, "non_allowed_channel_num=%d\n",
		status->non_allowed_channel_num);
	for (i = 0; i < status->non_allowed_channel_num; i++) {
		notice(DEBUG_CAT_DFS, "opclass=%d ch=%d time=%d\n",
			status->non_allowed_channel[i].op_class,
			status->non_allowed_channel[i].ch_num,
			status->non_allowed_channel[i].remain_interval);
	}
	notice(DEBUG_CAT_DFS, "ongoing_cac_channel_num=%d\n",
		status->ongoing_cac_channel_num);
	for (i = 0; i < status->ongoing_cac_channel_num; i++) {
		notice(DEBUG_CAT_DFS, "opclass=%d ch=%d time=%d\n",
			status->cac_ongoing_channel[i].op_class,
			status->cac_ongoing_channel[i].ch_num,
			status->cac_ongoing_channel[i].remain_interval);
	}
}

int dump_cac_caps(struct cac_capability_lib *cac, char *buf, size_t max_len)
{
	struct cac_cap *cap = NULL;
	struct cac_type *type = NULL;
	struct cac_opcap *op = NULL;
	unsigned char i = 0, j = 0, k = 0, m = 0;
	int ret = 0, len = 0;

	ret = snprintf(buf + len, max_len - len, "\ncac info:\n");
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	ret = snprintf(buf + len, max_len - len, "\tcountry_code=%s, radio_num=%d",
		cac->country_code, cac->radio_num);
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	for (i = 0; i < cac->radio_num; i++) {
		cap = &cac->cap[i];
		ret = snprintf(buf + len, max_len - len,
			"\n\t raid="MACSTR"; type_num=%d\n",
			MAC2STR(cap->identifier), cap->cac_type_num);
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;

		for (j = 0; j < cap->cac_type_num; j++) {
			type = &cap->type[j];
			ret = snprintf(buf + len, max_len - len,
				"\t  cac_mode=%d(0:CONTINUOUS; 1:ZERO_WAIT); interval=%02x %02x %02x; op_class_num=%d\n",
				type->cac_mode, type->cac_interval[0],
				type->cac_interval[1], type->cac_interval[2], type->op_class_num);
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf fail\n");
				return -1;
			}
			len += ret;

			for (k = 0; k < type->op_class_num; k++) {
				op = &type->opcap[k];
				ret = snprintf(buf + len, max_len - len,
					"\t   opclass=%d; ch_num==%d; ch_list=",
					op->op_class, op->ch_num);
				if (os_snprintf_error(max_len - len, ret)) {
					err(DEBUG_CAT_MISC, "snprintf fail\n");
					return -1;
				}
				len += ret;

				for (m = 0; m < op->ch_num; m++) {
					ret = snprintf(buf + len, max_len - len,
						"%d ", op->ch_list[m]);
				if (os_snprintf_error(max_len - len, ret)) {
						err(DEBUG_CAT_MISC, "snprintf fail\n");
						return -1;
					}
					len += ret;
				}
				ret = snprintf(buf + len, max_len - len, "\n");
				if (os_snprintf_error(max_len - len, ret)) {
					err(DEBUG_CAT_MISC, "snprintf fail\n");
					return -1;
				}
				len += ret;
			}
		}
	}

	return len;
}

void free_cac_opclass(struct dl_list *cac_list)
{
	struct cac_opcap_new *cac = NULL, *cac_tmp = NULL;

	if (!cac_list)
		return;

	dl_list_for_each_safe(cac, cac_tmp, cac_list, struct cac_opcap_new, list) {
		dl_list_del(&cac->list);
		os_free(cac);
	}
}

int insert_op_ch_in_cac_list(struct dl_list *cac_list, unsigned char op,
	unsigned short chan)
{
	struct cac_opcap_new *cac = NULL;
	unsigned char i = 0;

	if (!cac_list) {
		err(DEBUG_CAT_MISC, "invalid input parameter\n");
		return -1;
	}

	dl_list_for_each(cac, cac_list, struct cac_opcap_new, list)
	{
		if (cac->op_class != op)
			continue;
		for (i = 0; i < cac->ch_num; i++) {
			if (cac->ch_list[i] && cac->ch_list[i] == chan)
				return 1;
		}
		cac->ch_list[cac->ch_num++] = chan;
		return 0;
	}
	cac = os_zalloc(sizeof(*cac));
	if (!cac) {
		err(DEBUG_CAT_MISC, "alloac struct cac_opcap_new fail\n");
		return -1;
	}
	cac->op_class = op;
	cac->ch_list[cac->ch_num++] = chan;
	dl_list_add_tail(cac_list, &cac->list);

	return 0;
}

int insert_ch_in_cac_list(struct dl_list *cac_list, unsigned short chan,
	unsigned char bw)
{
	u8 op = 0;
	u16 new_chan = 0;
	int ret = 0;

	if (!cac_list) {
		err(DEBUG_CAT_CHANNEL, "invalid input parameter\n");
		return -1;
	}

	op = find_opclass_by_ch_bw(chan, bw, &new_chan);
	if (!op)
		return 0;
	if (new_chan)
		chan = new_chan;
	ret = insert_op_ch_in_cac_list(cac_list, op, chan);
	if (ret < 0)
		return -1;

	return 0;
}

int prepare_cac_opclass(struct wifi_app *wapp, struct phy_info *phy, struct dl_list *cac_list)
{
	struct _wdev_op_class_info_ext *op_class = NULL;
	struct opClassInfoExt *op_info = NULL;

	struct cac_opcap_new *cac = NULL;
	int ret = 0;
	unsigned char i = 0, j = 0;

	if (!phy || !cac_list) {
		err(DEBUG_CAT_MISC, "invalid input parameter\n");
		return -1;
	}

	op_class = get_opclass_by_phy(wapp, phy->phy_id);
	if (op_class == NULL) {
		err(DEBUG_CAT_MISC, "get opclass by phy-%d fail\n", phy->phy_id);
		return -1;
	}
	for (i = 0; i < op_class->num_of_op_class; i++) {
#ifndef MAP_6E_SUPPORT
		op_info = &op_class->opClassInfo[i];
#else
		op_info = &op_class->opClassInfoExt[i];
#endif
		if (op_info->op_class >= 118 &&
			op_info->op_class <= 123 &&
			op_info->num_of_ch > 0) {
			cac = os_zalloc(sizeof(*cac));
			if (!cac) {
				err(DEBUG_CAT_MISC, "alloac struct cac_opcap_new fail\n");
				return -1;
			}
			cac->op_class = op_info->op_class;
			cac->ch_num =  op_info->num_of_ch;
			os_memcpy(cac->ch_list, op_info->ch_list, cac->ch_num);
			dl_list_add_tail(cac_list, &cac->list);
		} else if (op_info->op_class == 128) {
			for (j = 0; j < op_info->num_of_ch; j++) {
				if (op_info->ch_list[j] >= 58 &&
					op_info->ch_list[j] <= 138) {
					ret = insert_op_ch_in_cac_list(cac_list, op_info->op_class, op_info->ch_list[j]);
					if (ret < 0)
						return -1;
				}
			}
		}  else if (op_info->op_class == 129) {
			for (j = 0; j < op_info->num_of_ch; j++) {
				if (op_info->ch_list[j] == 50 ||
					op_info->ch_list[j] == 114) {
					ret = insert_op_ch_in_cac_list(cac_list, op_info->op_class, op_info->ch_list[j]);
					if (ret < 0)
						return -1;
				}
			}
		}
	}

	return 0;
}

int assign_cac_caps(struct wifi_app *wapp)
{
	struct phy_info *phy = NULL;
	struct cac_capability_lib *cac_capab = NULL;
	struct cac_cap *cap = NULL;
	struct cac_type *type = NULL;
	struct cac_opcap *op = NULL;
	struct cac_opcap_new *cac_new = NULL;
	struct wapp_radio *ra = NULL;
	struct dl_list cac_op_list;
	size_t capab_len;
	unsigned int cac_time = 0;

	if (wapp->map->cac_capab) {
		os_free(wapp->map->cac_capab);
		wapp->map->cac_capab = NULL;
		wapp->map->cac_capab_len = 0;
		wapp->map->cac_capab_final_len = 0;
	}

	capab_len = sizeof(struct cac_capability_lib);
	cac_capab = os_zalloc(capab_len);
	if (!cac_capab) {
		err(DEBUG_CAT_MISC, "alloac cac_capab fail; size=%zu\n", capab_len);
		return -1;
	}

	/*assign country code from hostapd*/
	os_memcpy(cac_capab->country_code, wapp->country_code, 2);
	dl_list_for_each(phy, &wapp->phy_head, struct phy_info, list) {
		if (!check_5G_by_freq((unsigned int)phy->channels[0].freq))
			continue;
		wapp_get_feature(wapp, phy);
		dl_list_init(&cac_op_list);
		if (prepare_cac_opclass(wapp, phy, &cac_op_list)) {
			err(DEBUG_CAT_MISC, "prepare_cac_opclass fail for 5G\n");
			free_cac_opclass(&cac_op_list);
			os_free(cac_capab);
			return -1;
		}
		cap = &cac_capab->cap[cac_capab->radio_num];
		ra = get_radio_by_phy_id(wapp, phy->phy_id);
		if (ra != NULL) {
			MAP_GET_RADIO_IDNFER(ra, cap->identifier);
			cap->cac_type_num = 1;
			type = &cap->type[0];
			if (phy->zero_wait_dfs)
				type->cac_mode = CAC_ZERO_WAIT;
			else
				type->cac_mode = CAC_CONTINUOUS;
			cac_time = 65;
			type->cac_interval[0] = cac_time & 0xff0000;
			type->cac_interval[1] = cac_time & 0x00ff00;
			type->cac_interval[2] = cac_time & 0x0000ff;

			op = type->opcap;
			dl_list_for_each(cac_new, &cac_op_list, struct cac_opcap_new, list)
			{
				op->op_class = cac_new->op_class;
				op->ch_num = cac_new->ch_num;
				os_memcpy(op->ch_list, cac_new->ch_list, op->ch_num);
				type->op_class_num++;
				op++;
			}
			cac_capab->radio_num++;
			free_cac_opclass(&cac_op_list);
		}
	}

	wapp->map->cac_capab = cac_capab;
	wapp->map->cac_capab_len = capab_len;

	return 0;
}

int wapp_init_cac_caps(struct wifi_app *wapp)
{
	if (assign_cac_caps(wapp))
		return -1;

	return 0;
}

int dump_scan_cap(struct off_ch_scan_capab *cap, char *buf, size_t max_len)
{
	unsigned char i = 0, j = 0, k = 0;
	struct radio_scan_capab *rcap = NULL;
	struct channel_body *ch_body = NULL;
	int ret = 0, len = 0;

	ret = snprintf(buf + len, max_len - len, "\nscan info:");
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	for (i = 0; i < cap->radio_num; i++) {
		rcap = &cap->radio_scan_params[i];
		ret = snprintf(buf + len, max_len - len,
			"\n\traid="MACSTR"; boot_scan_only=%d; scan_impact=%d;"
			" min_scan_interval=%d; oper_class_num=%d\n",
			MAC2STR(rcap->radio_id), rcap->boot_scan_only, rcap->scan_impact,
			rcap->min_scan_interval, rcap->oper_class_num);
		if (os_snprintf_error(max_len - len, ret)) {
			err(DEBUG_CAT_MISC, "snprintf fail\n");
			return -1;
		}
		len += ret;

		for (j = 0; j < rcap->oper_class_num; j++) {
			ch_body = &rcap->ch_body[j];
			ret = snprintf(buf + len, max_len - len,
				"\t opclass=%d; ch_list_num=%d\n\t ch_list=",
				ch_body->oper_class, ch_body->ch_list_num);
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf fail\n");
				return -1;
			}
			len += ret;

			for (k = 0; k < ch_body->ch_list_num; k++) {
				ret = snprintf(buf + len, max_len - len,
					"%d ", ch_body->ch_list[k]);
			if (os_snprintf_error(max_len - len, ret)) {
					err(DEBUG_CAT_MISC, "snprintf fail\n");
					return -1;
				}
				len += ret;
			}
			ret = snprintf(buf + len, max_len - len, "\n");
			if (os_snprintf_error(max_len - len, ret)) {
				err(DEBUG_CAT_MISC, "snprintf fail\n");
				return -1;
			}
			len += ret;
		}
	}

	return len;
}

int wapp_init_scan_cap(struct wifi_app *wapp)
{
	struct phy_info *phy = NULL;
	struct off_ch_scan_capab *scan_capab = NULL;
	struct radio_scan_capab *cap = NULL;
	struct channel_body *ch_body = NULL;
#ifndef MAP_6E_SUPPORT
	wdev_op_class_info	*op_class = NULL;
	struct opClassInfo *op_info = NULL;
#else
	struct _wdev_op_class_info_ext *op_class = NULL;
	struct opClassInfoExt *op_info = NULL;
#endif
	struct wapp_radio *ra = NULL;
	size_t scan_capab_len;
	unsigned char i = 0;

	if (wapp->map->off_ch_scan_capab) {
		os_free(wapp->map->off_ch_scan_capab);
		wapp->map->off_ch_scan_capab = NULL;
		wapp->map->off_ch_scan_capab_len = 0;
	}

	scan_capab_len = sizeof(struct off_ch_scan_capab);
	scan_capab = os_zalloc(scan_capab_len);
	if (!scan_capab) {
		err(DEBUG_CAT_MISC, "alloac scan_capab fail\n");
		return -1;
	}

	dl_list_for_each(phy, &wapp->phy_head, struct phy_info, list) {
		op_class = get_opclass_by_phy(wapp, phy->phy_id);
		if (op_class == NULL) {
			err(DEBUG_CAT_MISC, "get opclass by phy-%d fail\n", phy->phy_id);
			continue;
		}
		cap = &scan_capab->radio_scan_params[scan_capab->radio_num];
		ra = get_radio_by_phy_id(wapp, phy->phy_id);
		if (ra == NULL) {
			err(DEBUG_CAT_MISC, "get radio by phy-%d fail\n", phy->phy_id);
			continue;
		}
		MAP_GET_RADIO_IDNFER(ra, cap->radio_id);
		cap->boot_scan_only = 0;
		cap->scan_impact = 0x3;
		cap->min_scan_interval = 60;
		ra->min_scan_interval = 2;
		for (i = 0; i < op_class->num_of_op_class; i++) {
#ifndef MAP_6E_SUPPORT
			op_info = &op_class->opClassInfo[i];
#else
			op_info = &op_class->opClassInfoExt[i];
#endif
			if (check_2G_by_freq((unsigned int)phy->channels[0].freq) &&
				(op_info->op_class == 81 || op_info->op_class == 82)) {
				ch_body = &cap->ch_body[cap->oper_class_num++];
				ch_body->oper_class = op_info->op_class;
				ch_body->ch_list_num = op_info->num_of_ch;
				os_memcpy(ch_body->ch_list, op_info->ch_list, ch_body->ch_list_num);
			} else if (check_5G_by_freq((unsigned int)phy->channels[0].freq) &&
				(op_info->op_class == 115 || op_info->op_class == 118 ||
				op_info->op_class == 121 || op_info->op_class == 125)) {
				ch_body = &cap->ch_body[cap->oper_class_num++];
				ch_body->oper_class = op_info->op_class;
				ch_body->ch_list_num = op_info->num_of_ch;
				os_memcpy(ch_body->ch_list, op_info->ch_list, ch_body->ch_list_num);
			} else if (check_6G_by_freq((unsigned int)phy->channels[0].freq) &&
				op_info->op_class == 131) {
				ch_body = &cap->ch_body[cap->oper_class_num++];
				ch_body->oper_class = op_info->op_class;
				ch_body->ch_list_num = op_info->num_of_ch;
				os_memcpy(ch_body->ch_list, op_info->ch_list, ch_body->ch_list_num);
			}
		}
		scan_capab->radio_num++;
	}

	if (!scan_capab->radio_num) {
		err(DEBUG_CAT_MISC, "get valid radio scan_capab->radio_num fail\n");
		os_free(scan_capab);
		return -1;
	}

	wapp->map->off_ch_scan_capab = scan_capab;
	wapp->map->off_ch_scan_capab_len = scan_capab_len;

	return 0;
}
#endif

int dump_map_info(struct wifi_app *wapp, char *buf, size_t max_len)
{
	int ret = 0, len = 0;

	ret = snprintf(buf + len, max_len - len, "\nmap info:\n");
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;

	ret = snprintf(buf + len, max_len - len,
		"\tver=%d; map_cfg_file=%s; map_user_cfg_file=%s;"
		" MapMode=%d(0:disable; 1:turkey; 4:cert); TurnKeyEnable=%d\n"
		"\t enable_wps_toggle_5GL_5GH=%d; quick_ch_change=%d; "
		"max_client_cnt=%d; send_buffer=%d\n",
		wapp->map->map_version, wapp->map->map_cfg, wapp->map->map_user_cfg,
		wapp->map->MapMode, wapp->map->TurnKeyEnable,
		wapp->map->enable_wps_toggle_5GL_5GH, wapp->map->quick_ch_change,
		wapp->map->max_client_cnt, wapp->map->send_buffer);
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;
#ifdef MAP_R2
	ret = snprintf(buf + len, max_len - len,
		"\t metric_rep_intv=%d\n", wapp->map->metric_rep_intv);
	if (os_snprintf_error(max_len - len, ret)) {
		err(DEBUG_CAT_MISC, "snprintf fail\n");
		return -1;
	}
	len += ret;
#endif

	return len;
}

