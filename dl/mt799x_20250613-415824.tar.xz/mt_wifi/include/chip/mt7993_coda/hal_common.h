

#ifndef __HAL_COMMON_H__
#define __HAL_COMMON_H__

#define CONN_INFRA_ON_REMAPPING_OFFSET 0x64000000

#endif //__HAL_COMMON_H__
