/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2022  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */
#ifndef __LIBWPACTRL_H_
#define __LIBWPACTRL_H_

#define PRINT_MAC(addr)	\
	addr[0], addr[1], addr[2], addr[3], addr[4], addr[5]

typedef enum {
	WPACTRL_TYPE_NONE = 0,
	WPACTRL_TYPE_HOSTAPD,
	WPACTRL_TYPE_SUPPLICANT,
	WPACTRL_TYPE_MAX,
} wpactrl_type_t;

typedef enum {
	WPS_CONFIG_AUTH_OPEN = 0,
	WPS_CONFIG_AUTH_WPAPSK,
	WPS_CONFIG_AUTH_WPA2PSK,
	WPS_CONFIG_AUTH_MAX
} wps_config_auth_t;

typedef enum {
	WPS_CONFIG_ENCR_NONE = 0,
	WPS_CONFIG_ENCR_TKIP,
	WPS_CONFIG_ENCR_CCMP,
	WPS_CONFIG_ENCR_MAX
} wps_config_encr_t;

#define WPS_EVENT_DPP_URI_RECEIVED "WPS-DPP-URI-RECEIVED "
#define WPA_EVENT_RECONF_FAIL "WPA-RECONF-FAIL "

enum {
	WPACTRL_NONE_LIB = 0,
	WPACTRL_TYPE_AP_LIB,
	WPACTRL_TYPE_STA_LIB,
};

#define MAC_ADDR_LEN 6

typedef int (*wpactrl_event_btm_query_cb_t)(void *ctx, const char *iface,
	uint8_t *mac, uint8_t *payload, size_t payload_len);
typedef int (*wpactrl_event_btm_resp_cb_t)(void *ctx, const char *iface,
	uint8_t *mac, uint8_t *payload, size_t payload_len);
typedef int (*wpactrl_event_wnm_notify_req_cb_t)(void *ctx, const char *iface,
	uint8_t *mac, uint8_t *payload, size_t payload_len);
typedef int (*wpactrl_event_anqp_init_req_cb_t)(void *ctx, const char *iface,
	uint8_t *mac, uint8_t *payload, size_t payload_len);
typedef int (*wpactrl_event_anqp_resp_cb_t)(void *ctx, const char *iface,
	uint8_t *mac, uint8_t *payload, size_t payload_len);
typedef int (*wpactrl_event_sta_connected_cb_t)(void *ctx, const char *iface,
						const uint8_t *addr);
typedef int (*wpactrl_event_sta_disconnected_cb_t)(void *ctx, const char *iface,
						const uint8_t *addr);
typedef int (*wpactrl_event_connected_cb_t)(void *ctx, const char *iface);
typedef int (*wpactrl_event_disconnected_cb_t)(void *ctx, const char *iface);
typedef int (*wpactrl_event_wps_overlap_cb_t)(void *ctx, const char *iface);
typedef int (*wpactrl_event_wps_new_ap_setting_cb_t)(void *ctx, const char *iface,
	const uint8_t *cred_attr, size_t cred_attr_len);
typedef int (*wpactrl_event_wps_enrollee_seen_cb_t)(void *ctx, const char *iface,
					const uint8_t *addr, const uint8_t *uuid,
					const uint8_t *dev_type, uint32_t config_methods,
					uint32_t dev_password_id, uint32_t request_type,
					const char *dev_name);
typedef int (*wpactrl_event_wps_timeout_cb_t)(void *ctx, const char *iface);
typedef int (*wpactrl_event_wps_success_cb_t)(void *ctx, const char *iface);
typedef int (*wpactrl_event_wps_fail_cb_t)(void *ctx, const char *iface,
					int msg, int config_error, int reason);
typedef int (*wpactrl_event_wps_active_cb_t)(void *ctx, const char *iface);
typedef int (*wpactrl_event_wps_disable_cb_t)(void *ctx, const char *iface);
typedef int (*wpactrl_event_dfs_radar_detected_cb_t)(void *ctx, const char *iface,
	int freq, int ht_enabled, int chan_offset, int chan_width, int cf1, int cf2);
typedef int (*wpactrl_event_dfs_new_channel_cb_t)(void *ctx, const char *iface,
	int freq, int chan, int sec_chan);
typedef int (*wpactrl_event_dfs_cac_start_cb_t)(void *ctx, const char *iface,
	int freq, int chan, int sec_chan, int width, int seq0, int seq1, int cac_time);
typedef int (*wpactrl_event_dfs_cac_complete_cb_t)(void *ctx, const char *iface,
	int success, int freq, int ht_enabled, int chan_offset,
	int chan_width, int cf1, int cf2);
typedef int (*wpactrl_event_dfs_nop_finished_cb_t)(void *ctx, const char *iface,
	int freq, int ht_enabled, int chan_offset, int chan_width, int cf1, int cf2);
typedef int (*wpactrl_event_dfs_pre_cac_expired_cb_t)(void *ctx, const char *iface,
	int freq, int ht_enabled, int chan_offset, int chan_width, int cf1, int cf2);
typedef int (*wpactrl_event_beacon_report_cb_t)(void *ctx, const char *iface,
	uint8_t *mac, uint8_t token, uint8_t report_mode, uint8_t *payload, size_t payload_len);
typedef int (*wpactrl_event_beacon_report_done_cb_t)(void *ctx, const char *iface,
	uint8_t *mac, uint8_t token, uint8_t report_mode);
typedef int (*wpactrl_event_eap_failure_cb_t)(void *ctx, const char *iface, uint8_t *mac);
typedef int (*wpactrl_event_eap_timeout_cb_t)(void *ctx, const char *iface);
typedef int (*wpactrl_event_wnm_notify_network_added_cb_t)(void *ctx, const char *iface, int network_added);
typedef int (*wpactrl_event_wps_scan_fail_cb_t)(void *ctx, const char *iface);
typedef int (*wpactrl_event_wps_dpp_uri_cb_t)(void *ctx, const char *iface,
	uint8_t *mac, uint8_t *payload, size_t payload_len);
typedef int (*wpactrl_event_wps_cred_cb_t)(void *ctx, const char *iface,
	uint8_t *payload, size_t payload_len);
typedef int (*wpactrl_event_reconfig_fail_cb_t)(void *ctx, const char *iface);
typedef int (*wpactrl_event_eapol_complete_cb_t)(void *ctx, const char *iface,
	const uint8_t *addr, uint8_t multi_ap);
typedef int (*wpactrl_event_assoc_cb_t)(void *ctx, const char *iface,
	uint8_t *mac, int reassoc, const char *payload, size_t payload_len);
typedef int (*wpactrl_event_disassoc_cb_t)(void *ctx, const char *iface);
typedef int (*wpactrl_deal_event_ap_rx_probe_req_cb_t)(void *ctx, const char *iface,
	uint8_t *mac, int freq, int rssi, const char *payload, size_t payload_len);
typedef int (*wpactrl_deal_event_ap_ch_survey_cb_t)(void *ctx, const char *iface,
	uint8_t *mac, int freq, int cu);
typedef int (*wpactrl_event_action_rx_cb_t)(void *ctx, const char *iface, const uint8_t *src, int freq, int is_gas,
	const char *buf, size_t buf_len);
typedef int (*wpactrl_event_sta_connected_info_cb_t)(void *ctx, const char *iface,
	const uint8_t *addr, uint8_t *bssid, uint8_t connect_stage,
	uint16_t reason_code, uint16_t assoc_status_code, uint16_t assoc_reason_code);
typedef struct {
	wpactrl_event_connected_cb_t		event_connected_cb;
	wpactrl_event_disconnected_cb_t		event_disconnected_cb;
	wpactrl_event_sta_connected_cb_t	event_sta_connected_cb;
	wpactrl_event_sta_disconnected_cb_t	event_sta_disconnected_cb;
	wpactrl_event_wps_overlap_cb_t 		event_wps_overlap_cb;
	wpactrl_event_wps_new_ap_setting_cb_t	event_wps_new_ap_setting_cb;
	wpactrl_event_wps_timeout_cb_t		event_wps_timeout_cb;
	wpactrl_event_wps_success_cb_t		event_wps_success_cb;
	wpactrl_event_wps_fail_cb_t		event_wps_fail_cb;
	wpactrl_event_wps_active_cb_t		event_wps_active_cb;
	wpactrl_event_wps_disable_cb_t		event_wps_disable_cb;
	wpactrl_event_wps_enrollee_seen_cb_t	event_wps_enrollee_seen_cb;
	wpactrl_event_btm_query_cb_t		event_btm_query_cb;
	wpactrl_event_btm_resp_cb_t		event_btm_resp_cb;
	wpactrl_event_beacon_report_cb_t	event_beacon_report_cb;
	wpactrl_event_beacon_report_done_cb_t	event_beacon_report_done_cb;
	wpactrl_event_wnm_notify_req_cb_t	event_wnm_notify_req_cb;
	wpactrl_event_anqp_init_req_cb_t	event_anqp_init_req_cb;
	wpactrl_event_anqp_resp_cb_t		event_anqp_resp_cb;
	wpactrl_event_dfs_radar_detected_cb_t	event_dfs_radar_detected_cb;
	wpactrl_event_dfs_new_channel_cb_t	event_dfs_new_channel_cb;
	wpactrl_event_dfs_cac_start_cb_t	event_dfs_cac_start_cb;
	wpactrl_event_dfs_cac_complete_cb_t	event_dfs_cac_complete_cb;
	wpactrl_event_dfs_nop_finished_cb_t	event_dfs_nop_finished_cb;
	wpactrl_event_dfs_pre_cac_expired_cb_t	event_dfs_pre_cac_expired_cb;
	wpactrl_event_wps_dpp_uri_cb_t		event_wps_dpp_uri_cb;
	wpactrl_event_wps_cred_cb_t		event_wps_cred_cb;
	wpactrl_event_reconfig_fail_cb_t		event_reconfig_fail_cb;
	wpactrl_event_eap_failure_cb_t          event_eap_failure_cb;
	wpactrl_event_wnm_notify_network_added_cb_t  event_wnm_notify_network_added_cb;
	wpactrl_event_wps_scan_fail_cb_t  	event_wps_scan_fail_cb;
	wpactrl_event_eap_timeout_cb_t          event_eap_timeout_cb;
	wpactrl_event_eapol_complete_cb_t			event_eapol_complete_cb;
	wpactrl_event_assoc_cb_t			event_assoc_cb;
	wpactrl_event_disassoc_cb_t			event_disassoc_cb;
	wpactrl_deal_event_ap_rx_probe_req_cb_t	event_probe_req_cb;
	wpactrl_deal_event_ap_ch_survey_cb_t	event_ap_ch_survey_cb;
	wpactrl_event_action_rx_cb_t		event_action_rx_cb;
	wpactrl_event_sta_connected_info_cb_t	event_sta_connected_info_cb;
} wpactrl_cbs_t;

/**
 * wpactrl_event_get - Get event from control interface, parsing,
 *                     and call event callback function
 * @context: control interface context
 * Returns: 0 on success, < 0 on error
 */
int wpactrl_event_get(void *context);

/**
 * wpactrl_cmd_enable - Send Enable command to control interface
 * @context: control interface context
 * @ifname: interface name
 * Returns: 0 on success, < 0 on error
 */
int wpactrl_cmd_enable(void* context, const char *ifname);

/**
 * wpactrl_cmd_disable - Send Disable command to control interface
 * @context: control interface context
 * @ifname: interface name
 * Returns: 0 on success, < 0 on error
 */
int wpactrl_cmd_disable(void* context, const char *ifname);

/**
 * wpactrl_cmd_intf_disable - Send Disable command to pericular AP interface
 * @context: global interface context
 * @ifname: interface name
 * Returns: 0 on success, < 0 on error
 */
int wpactrl_cmd_intf_disable(void* context, const char *ifname);

/**
 * wpactrl_cmd_intf_add - Send add command to pericular AP interface
 * @context: global interface context
 * @phy_iface: phy interface name
 * @bss_config_path: the string of bss_config_path
 * @config_path:the string of hostapd config path
 * Returns: 0 on success, < 0 on error
 */
int wpactrl_cmd_intf_add(void* context,const char *phy_iface, const char *bss_config_path, const char *config_path);

/**
 * wpactrl_cmd_set - Send SET command to control interface
 * @context: control interface context
 * @ifname: interface name
 * @name: variable name to be set
 * @value: variable value
 * Returns: 0 on success, < 0 on error
 */
int wpactrl_cmd_set(void* context, const char *ifname, const char* name, const char* value);

/**
 * wpactrl_cmd_set_network - Send SET_NETWORK command to control interface
 * @context: control interface context
 * @ifname: interface name
 * @network_id: network id for which network has to be enabled
 * @name: variable name to be set
 * @value: variable value
 * Returns: 0 on success, < 0 on error
 */
int wpactrl_cmd_set_network(void* context, const char *ifname, int network_id, const char* name, const char* value);

/**
 * wpactrl_cmd_set_network_dpp_pfs - Send set dpp pfs command to control interface
 * @context: control interface context
 * @ifname: interface name
 * @network_id: integer value for network id
 * @name: string name for dpp pfs to be set
 * @value: dpp pfs security value
 * Returns: 0 on success, < 0 on error
 */
int wpactrl_cmd_set_network_dpp_pfs(void* context, const char *ifname, int network_id, const char* name, int value);

/**
 * wpactrl_cmd_bss_tm_req - Send BSS Transition Management command to control interface
 * @context: control interface context
 * @ifname: interface name
 * @sta_mac: Hex value for mac address
 * @disassoc_timer: the number of TBTT util AP send disassociation
 *	frame to sta. 0 means ignore of this timer.
 * @valid_int: validity interval, number of TBTT util BSS transition candidate list is
 *	no longer valid. 0 means ignore of this timer.
 * @dialog_token: The Dialog Token field is the nonzero value of the corresponding Event
 *	Request frame. If the Event Report frame is being transmitted other than in
 *	response to an Event Request frame, then the Dialog token is zero.
 * @bss_term: BSS Termination Duration. Number of minutes that the responding STA
 *	requests the BSS to delay termination.
 * @cand_list: BSS Transition Candidate List Entries field contains zero or more Neighbor
 *	Report elements.
 * @cand_list_len: The number of BSS Transition Candidate List Entries.
 * @url: Optional Session Information URL field
 * @url_len: The length of URL
 * @pref: Indicate The Preferred Candidate List Included
 * @abridged: Indicate the Abridged bit
 * @disassoc_imminent: Indicate the Disassociation Imminent bit
 * Returns: 0 on success, < 0 on error
 */
typedef struct {
	uint8_t		bssid[6];
	uint32_t	bssid_info;
	int		operating_class;
	int		channel;
	int		phy_type;
	uint8_t		subelement[64];
	int		subelement_len;
} bss_tm_req_candidate_t;

int wpactrl_cmd_bss_tm_req(void* context, const char *ifname, const uint8_t* sta_mac,
			int disassoc_timer, int valid_int,
			int dialog_token, int bss_term,
			bss_tm_req_candidate_t *cand_list, int cand_list_len,
			const char *url, int url_len,
			int pref, int abridged, int disassoc_imminent,
			int mbo_reason, int reassoc_delay, int cell_pref);

/**
 * wpactrl_cmd_sta_deauth - Send Sta Deauthentication command to control interface
 * @context: control interface context
 * @ifname: interface name
 * @sta_mac: Hex value for STA mac address.
 * Returns: 0 on success, < 0 on error
 */
int wpactrl_cmd_sta_deauth(void* context, const char *ifname, const uint8_t* sta_mac);

/**
 * wpactrl_cmd_get_pmk - to get PMK of AP and write in dpp_cfg_test file
 * @context: control interface context
 * @ifname: interface name
 * @sta_mac: Hex value for STA mac address.
 * @reply_buf : to store pmk value and retrive in wapp
 * Returns: 0 on success, < 0 on error
 */
int wpactrl_cmd_get_pmk(void* context, const char *ifname, const uint8_t* sta_mac, uint8_t* reply_buf);


/**
 * wpactrl_cmd_set_autoscan_module - Send set autoscan module
 * @context: control interface context
 * @ifname: interface name
 * @module: autoscan module name
 *          WPACTRL_AUTOSCAN_NULL - default setting
 *          WPACTRL_AUTOSCAN_EXPONENTIAL - exponential module
 *          WPACTRL_AUTOSCAN_PERIODIC - periodic module
 * @param1: module parameters
            for exponential module, param1 is base exponential
            for periodic module, param1 is fixed interval delay.
 * @param2: module parameters
            for exponential module, param2 is up limit
 * Returns: 0 on success, < 0 on error
 */
typedef enum {
	WPACTRL_AUTOSCAN_NULL = 0,
	WPACTRL_AUTOSCAN_EXPONENTIAL = 1,
	WPACTRL_AUTOSCAN_PERIODIC = 2,
} wpactrl_autoscan_module_t;

int wpactrl_cmd_set_autoscan_module(void* context,
	const char *ifname,
	wpactrl_autoscan_module_t module,
	const uint16_t param1,
	const uint16_t param2);

/**
 * wpactrl_cmd_disconnect - Send disconnect cmd to supplicant
 * @context: control interface context
 * @ifname: interface name
 * Returns: 0 on success, < 0 on error
 */
int wpactrl_cmd_disconnect(void* context, const char *ifname);

/**
 * wpactrl_cmd_remove_network - Send remove all network command to control interface
 * @context: control interface context
 * @ifname: interface name
 * Returns: 0 on success, < 0 on error
 */
int wpactrl_cmd_remove_network(void* context, const char *ifname);

/**
 * wpactrl_cmd_disable_network - Send  disable network command corresponding to network ID to control interface
 * @context: control interface context
 * @ifname: interface name
 * @network_id: network id for which network has to be disabled
 * Returns: 0 on success, < 0 on error
 */
int wpactrl_cmd_disable_network(void* context, const char *ifname, int network_id);


/**
 * wpactrl_cmd_select_network - Send  select network command corresponding to network ID to control interface
 * @context: control interface context
 * @ifname: interface name
 * @network_id: network id for which network has to be disabled
 * @frequency: 
 * Returns: 0 on success, < 0 on error
 */
int wpactrl_cmd_select_network(void* context, const char *ifname, int network_id, int frequency);

/**
 * wpactrl_cmd_enable_network - Send enable network command  corresponding to network ID to control interface
 * @context: control interface context
 * @ifname: interface name
 * @network_id: network id for which network has to be enabled
 * Returns: 0 on success, < 0 on error
 */
int wpactrl_cmd_enable_network(void* context, const char *ifname, int network_id);

/**
 * wpactrl_cmd_bss_flush - Send BSS flush command to control interface
 * @context: control interface context
 * @ifname: interface name
 * Returns: 0 on success, < 0 on error
 */
int wpactrl_cmd_bss_flush(void* context, const char *ifname);

/**
 * wpactrl_cmd_set_network_bssid - Send  set bssid command corresponding to network ID to control interface
 * @context: control interface context
 * @ifname: interface name
 * @network_id: integer value for network id
 * @bssid : target bssid
 * Returns: 0 on success, < 0 on error
 */
int wpactrl_cmd_set_network_bssid(void* context, const char *ifname, int network_id, const char *bssid);

/**
 * wpactrl_cmd_add_network_key - Send  add network  command to control interface
 * @context: control interface context
 * @ifname: ifname
 * Returns: 0 on success, < 0 on error
 */
int wpactrl_cmd_add_network(void* context, const char *ifname);

/**
  * wpactrl_cmd_add_network_key - Send add network key  command to  control interface
 * @context: control interface context
 * @ifname: interface name
 * @network_id: integer value for network id
 * @key : network key to be added
 * Returns: network ID from supplicant on success, < 0 on error
 */
int wpactrl_cmd_add_network_key(void* context, const char *ifname, int network_id, const char *key);

/**
 * wpactrl_cmd_set_keymgmt - Send set key management command to  control interface
 * @context: control interface context
 * @ifname: interface name
 * @network_id: integer value for network id
 * @keymgmt : key management to be set
 * Returns: 0 on success, < 0 on error
 *
*/
int wpactrl_cmd_set_keymgmt(void* context, const char *ifname, int network_id, const char *keymgmt);

/**
 * wpactrl_cmd_set_sae_pwd- Send set sae password command to  control interface
 * @context: control interface context
 * @ifname: interface name
 * @network_id: integer value for network id
 * @pwd : password to be set
 * Returns: 0 on success, < 0 on error
 *
*/
int wpactrl_cmd_set_sae_pwd(void* context, const char *ifname, int network_id, const char *pwd);

/**
 * wpactrl_cmd_set_wep_key- Send set wep key command to  control interface
 * @context: control interface context
 * @ifname: interface name
 * @network_id: integer value for network id
 * @key_idx: key_idx to be set
 * @key : wep key to be set
 * Returns: 0 on success, < 0 on error
 *
*/
int wpactrl_cmd_set_wep_key(void* context, const char *ifname, int network_id, int key_idx, const char *key);

/**
 * wpactrl_cmd_save_config- Send save config command to  control interface
 * @context: control interface context
 * @ifname: interface name
 * Returns: 0 on success, < 0 on error
 *
*/
int wpactrl_cmd_save_config(void* context, const char *ifname);

/**
 * wpactrl_cmd_scan_ssid- Send ssid scan command to  control interface
 * @context: control interface context
 * @ifname: interface name
 * @network_id: integer value for network id
 * @enable: to enable scan for hidden ssid
 * Returns: 0 on success, < 0 on error
 *
*/
int wpactrl_cmd_scan_ssid(void* context, const char *ifname, int network_id, int enable);

/**
 * wpactrl_cmd_set_wps_pbc - Send wps pbc trigger command to  control interface
 * @context: control interface context
 * @ifname: interface name
 * @map_enable: set 1 if map enable for STA
 * @dev_type: dev_type( STA/AP) coming from wapp
 * Returns: 0 on success, < 0 on error
 *
*/
int wpactrl_cmd_set_wps_pbc(void* context, const char *ifname, int dev_type, int map_enable);


/**
 * wpactrl_cmd_set_ssid- Send set ssid  command to  control interface
 * @context: control interface context
 * @ifname: interface name
 * @network_id: integer value for network id
 * @ssid: ssid to be set
 * @dev_type: dev_type ( either AP/STA)  to be set
 * Returns: 0 on success, < 0 on error
 *
*/
int wpactrl_cmd_set_ssid(void* context, const char *ifname, const char *ssid, int network_id, int dev_type);

/**
 * wpactrl_cmd_config_update- Send config update command to  control interface
 * @context: control interface context
 * @ifname: interface name
 * Returns: 0 on success, < 0 on error
 *
*/
int wpactrl_cmd_config_update(void* context, const char *ifname);

/**
 * wpactrl_cmd_reload- Send reload command to  control interface
 * @context: control interface context
 * @ifname: interface name
 * Returns: 0 on success, < 0 on error
 *
*/
int wpactrl_cmd_reload(void* context, const char *ifname);

/**
 * wpactrl_cmd_disassoc_imminent - send Disassociation Imminent notification
 * @context: control interface context
 * @ifname: interface name
 * @sta_mac: Hex value for STA mac address.
 * @disassoc_timer: the number of TBTT util AP send disassociation
 *	frame to sta. 0 means ignore of this timer.
 * Returns: 0 on success, < 0 on error
 */

int wpactrl_cmd_disassoc_imminent(void* context,
				const char *ifname,
				const uint8_t* sta_mac,
				int disassoc_timer);

/**
 * wpactrl_cmd_ess_disassoc - send ESS Dissassociation Imminent notification
 * @context: control interface context
 * @ifname: interface name
 * @sta_mac: Hex value for STA mac address.
 * @disassoc_timer: the number of TBTT util AP send disassociation
 *	frame to sta. 0 means ignore of this timer.
 * @url: Optional Session Information URL field
 * @url_len: The length of URL
 * Returns: 0 on success, < 0 on error
 */
int wpactrl_cmd_ess_disassoc(void* context,
				const char *ifname,
				const uint8_t* sta_mac,
				int disassoc_timer,
				const char *url,
				int url_len);

/**
 * wpactrl_cmd_coloc_intf_req - send ESS Dissassociation Imminent notification
 * @context: control interface context
 * @ifname: interface name
 * @sta_mac: Hex value for STA mac address.
 * @auto_report: Automatic Report Enabled subfield in Collocated
	Interference Request frame
 * @timeout: Report Timeout field in Collocated Interference Request frame
 * Returns: 0 on success, < 0 on error
 */
int wpactrl_cmd_coloc_intf_req(void* context,
				const char *ifname,
				const uint8_t* sta_mac,
				unsigned int auto_report,
				unsigned int timeout);
/**
 * wpactrl_cmd_req_beacon - send a Beacon report request to a station
 * @context: control interface context
 * @ifname: interface name
 * @sta_mac: Hex value for STA mac address.
 * @req_mode: Measurement Request mode
 * @req: Measurement Request feild
 * @req_len: The length of Measurement Request feild
 * Returns: 0 on success, < 0 on error
 */
int wpactrl_cmd_req_beacon(void* context,
			const char *ifname,
			uint8_t* sta_mac,
			uint8_t req_mode,
			uint8_t* req,
			int req_len);


/**
 * wpactrl_cmd_hs20_wnm_notif - send WNM-Notification Subscription Remediation Request.
 * @context: control interface context.
 * @ifname: interface name
 * @sta_mac: Hex value for STA mac address.
 * @url: Optional Session Information URL field
 * @url_len: The length of URL
 * Returns: 0 on success, < 0 on error
 */
int wpactrl_cmd_hs20_wnm_notif(void* context,
			const char *ifname,
			uint8_t* sta_mac,
			const char *url,
			int url_len);


/**
 * wpactrl_cmd_hs20_deauth_req - send WNM-Notification imminent deauthentication indication
 * @context: control interface context.
 * @ifname: interface name
 * @sta_mac: Hex value for STA mac address.
 * @code: Deauth reason code
 * @dely: Reauth delay
 * @url: URL
 * @url_len: The length of URL
 * Returns: 0 on success, < 0 on error
 */
int wpactrl_cmd_hs20_deauth_req(void* context,
			const char *ifname,
			uint8_t* sta_mac,
			int code,
			int delay,
			const char *url,
			int url_len);

/**
 * wpactrl_cmd_wps_pbc - Send WPS Push Button command to control interface
 * @context: control interface context
 * @ifname: interface name
 * Returns: 0 on success, < 0 on error
 */
int wpactrl_cmd_wps_pbc(void* context, const char *ifname);


/**
 * wpactrl_cmd_wps_cancel - Send WPS Cancel command to control interface
 * @context: control interface context
 * @ifname: interface name
 * Returns: 0 on success, < 0 on error
 */
int wlpactrl_cmd_wps_cancel(void* context, const char *ifname);


/**
 * wpactrl_cmd_wps_pin - Send WPS PIN command to control interface
 * @context: control interface context
 * @ifname: interface name
 * @uuid: Enrollee UUID, string format
 * @pin: PIN string format
 * @timeout: Expire  time in seconds
 * @addr: Hex value for mac address
 * Returns: 0 on success, < 0 on error
 */
int wpactrl_cmd_wps_pin(void* context,
			const char *ifname,
			const char* uuid,
			const char *pin,
			int timeout,
			uint8_t *addr);

/**
 * wpactrl_cmd_wps_config - Send WPS Config command to control interface
 * @context: control interface context
 * @ifname: interface name
 * @ssid: ssid string format
 * @auth: refer to wps_config_auth_t
 * @encr: refer to wps_config_encr_t
 * @key: Hex format
 * @key_len: key length
 * Returns: 0 on success, < 0 on error
 */
int wpactrl_cmd_wps_config(void* context,
			const char *ifname,
			const char* ssid,
			wps_config_auth_t auth,
			wps_config_encr_t encr,
			const uint8_t* key,
			size_t key_len);


/**
 * wpactrl_cmd_set_ap_pmk - Send PMK set command to control interface
 * @context: control interface context
 * @ifname: interface name
 * @sta_mac: sta mac address
 * @pmk_id: PMKID derived during DPP handshakes
 * @pmk: PMK established during DPP handshakes
 * @pmk_len: PMK length
 * @expiry: expiration in seconds
 * @akmp: akm of wireless security
 * Returns: 0 on success, < 0 on error
 */
int wpactrl_cmd_set_ap_pmk(void* context,
			const char *ifname,
			const uint8_t* sta_mac,
			const uint8_t* pmk_id,
			const uint8_t* pmk,
			size_t pmk_len,
			int expiry,
			int akmp);

/**
 * wpactrl_cmd_set_sta_pmk - Send PMK set command to control interface
 * @context: control interface context
 * @ifname: interface name
 * @nw_id: supplicant network id
 * @bssid: MAC address of an AP
 * @pmk_id: PMKID derived during DPP handshakes
 * @pmk: PMK established during DPP handshakes
 * @pmk_len: PMK length
 * @reauth: reauth_time in seconds
 * @expiry: expiration in seconds
 * @akmp: akm of wireless security
 * @opportunistic: opportunistic
 * Returns: 0 on success, < 0 on error
 */
int wpactrl_cmd_set_sta_pmk(void* context,
			const char *ifname,
			uint8_t nw_id,
			const uint8_t* bssid,
			const uint8_t* pmk_id,
			const uint8_t* pmk,
			size_t pmk_len,
			int reauth,
			int expiry,
			int akmp,
			int opportunistic);

int wpactrl_cmd_set_network_pairwise(void* context,
			const char *ifname,
			int network_id,
			const char *pairwise);


int wpactrl_cmd_set_network_group(void* context,
			const char *ifname,
			int network_id,
			const char *group);


int wpactrl_cmd_set_network_grpmgmt(void* context,
			const char *ifname,
			int network_id,
			const char *grpmgmt);

int wpactrl_cmd_set_bcn_prot(void* context,
			const char *ifname,
			int network_id,
			uint8_t beacon_prot);

/**
 * wpactrl_cmd_set_dpp_uri - Send DPP URI to supplicant
 * @context: control interface context
 * @ifname: interface name
 * @dpp_uri: DPP URI
 * @dpp_uri_len: DPP URI len
 * Returns: 0 on success, < 0 on error
 */
int wpactrl_cmd_set_dpp_uri(void* context,
			const char *ifname,
			const uint8_t* dpp_uri,
			size_t dpp_uri_len);

/**
 * wpactrl_cmd_set_map_sec - Set map security flag to control interface
 * @context: control interface context
 * @ifname: interface name
 * @map_sec_enable: map security flag enabe/disable
 * Returns: 0 on success, < 0 on error
 */
int wpactrl_cmd_set_map_sec(void* context,
			const char *ifname,
			uint8_t map_sec_enable);

/**
 * wpactrl_cmd_update_bridge_supplicant - Update bridge to control interface
 * @context: control interface context
 * @ifname: interface name
 * @bridge_enable: bridge flag add/remove
 * @br_name: bridge name in case of adding
 * Returns: 0 on success, < 0 on error
 */
int wpactrl_cmd_update_bridge_supplicant(void* context,
			const char *ifname,
			uint8_t bridge_flag,
			const char *br_name);

/**
 * wpactrl_iface_fd_get - Get file descriptor from control interface context
 * @context: control interface context
 * Returns: file descriptor
 */
int wpactrl_iface_fd_get(void* context);



/**
 * wpactrl_iface_open - Register control interface
 * @context: Save pointer for control interface context
 * @type: Type for control interface (hostapd/supplicant).
 * @iface: Interface name for control interface.
 * @ctrl_path: Path for UNIX domain sockets; default path used if ignored.
 * @cb_ctx: Callback context used by event callback function.
 * @cbs: Event callback functions.
 * @flag: Bit0 0:Don`t attach; 1: attch, other bits: reserved
 * Returns: 0 on success, < 0 on error
 */
int wpactrl_iface_open(void** context,
			wpactrl_type_t type,
			const char *iface,
			const char *ctrl_path,
			void *cb_ctx,
			wpactrl_cbs_t *cbs,
			int flag);

/**
 * wpactrl_iface_close - Unregister control interface
 * @context: Pointer for control interface context pointer,
 *           used for saving created context.
 * Returns: 0 on success, < 0 on error
 */
void wpactrl_iface_close(void* context);


/**
 * wpactrl_debug_level_set: set debug level
 * @level: integer debug level
 */
typedef enum {
	WPACTRL_DBGLVL_DEBUG = 0,
	WPACTRL_DBGLVL_INFO,
	WPACTRL_DBGLVL_WARN,
	WPACTRL_DBGLVL_ERROR,
} wpctrl_dbglvl_t;

void wpactrl_debug_level_set(int level);

/**
 * wpactrl_debug_prefix_set: set log prefix
 * prefix: prefix string for every log
 */
void wpactrl_debug_prefix_set(const char *prefix);

/**
 * wpactrl_debug_print_func_set - replace default debug print fucntion
 * @func: pointer to printf function
 */
void wpactrl_debug_print_func_set(int (*func)(const char *format, ...));

/**
 * wpactrl_cmd_set_psk- Send set wpa_passphrase command to  control interface
 * @context: control interface context
 * @ifname: interface name
 * @psk: pass phrase to be set
 * @dev_type: dev_type ( either AP/STA)  to be set
 * Returns: 0 on success, < 0 on error
 *
*/
int wpactrl_cmd_set_psk(void* context, const char *ifname, const char *psk, int dev_type);

/**
 * wpactrl_cmd_acl_set_policy- Send acl policy to  control interface
 * @context: control interface context
 * @ifname: interface name
 * @policy: acl policy
 * Returns: 0 on success, < 0 on error
 *
*/
int wpactrl_cmd_acl_set_policy(void *context, const char *ifname, int policy);

/**
 * wpactrl_cmd_acl_accept_add_mac- add mac to acl accept mac list
 * @context: control interface context
 * @ifname: interface name
 * @mac: interface mac
 * Returns: 0 on success, < 0 on error
 *
*/
int wpactrl_cmd_acl_accept_add_mac(void *context, const char *ifname, unsigned char *mac);

/**
 * wpactrl_cmd_acl_accept_del_mac- del mac from acl accept mac list
 * @context: control interface context
 * @ifname: interface name
 * @mac: interface mac
 * Returns: 0 on success, < 0 on error
 *
*/
int wpactrl_cmd_acl_accept_del_mac(void *context, const char *ifname, unsigned char *mac);

/**
 * wpactrl_cmd_acl_accept_clear_mac- clear accept mac list
 * @context: control interface context
 * @ifname: interface name
 * Returns: 0 on success, < 0 on error
 *
*/
int wpactrl_cmd_acl_accept_clear_mac(void *context, const char *ifname);

/**
 * wpactrl_cmd_acl_accept_show_mac- show accept mac list
 * @context: control interface context
 * @ifname: interface name
 * Returns: 0 on success, < 0 on error
 *
*/
int wpactrl_cmd_acl_accept_show_mac(void *context, const char *ifname);

/**
 * wpactrl_cmd_acl_deny_add_mac- add mac to acl deny mac list
 * @context: control interface context
 * @ifname: interface name
 * @mac: interface mac
 * Returns: 0 on success, < 0 on error
 *
*/
int wpactrl_cmd_acl_deny_add_mac(void *context, const char *ifname, unsigned char *mac);

/**
 * wpactrl_cmd_acl_deny_del_mac- del mac from acl deny mac list
 * @context: control interface context
 * @ifname: interface name
 * @mac: interface mac
 * Returns: 0 on success, < 0 on error
 *
*/
int wpactrl_cmd_acl_deny_del_mac(void *context, const char *ifname, unsigned char *mac);

/**
 * wpactrl_cmd_acl_deny_clear_mac- clear acl deny mac list
 * @context: control interface context
 * @ifname: interface name
 * Returns: 0 on success, < 0 on error
 *
*/
int wpactrl_cmd_acl_deny_clear_mac(void *context, const char *ifname);

/**
 * wpactrl_cmd_acl_deny_show_mac- show acl deny mac list
 * @context: control interface context
 * @ifname: interface name
 * Returns: 0 on success, < 0 on error
 *
*/
int wpactrl_cmd_acl_deny_show_mac(void *context, const char *ifname);

/**
 * wpactrl_cmd_set_channel_switch - Send Channel Switch command to control interface
 * @context: control interface context
 * @ifname: interface name
 * @channel: channel switch to
 * @freq: freq switch to
 * Returns: 0 on success, < 0 on error
 */
int wpactrl_cmd_set_channel_switch(void *context,
	char *ifname,
	unsigned char cs_count, unsigned int freq,
	unsigned int bw, unsigned int center_freq1,
	int sec_channel_offset, unsigned int skip_cac);

int wpactrl_cmd_zero_wait_cac(void *context,
	char *ifname,
	unsigned char ch, unsigned char bw);


/**
 * wpactrl_cmd_set_dfs_detect_mode - Send dfs_detect_mode to control interface
 * @context: control interface context
 * @ifname: interface name
 * @mode: dfs detect mode
 * Returns: 0 on success, < 0 on error
 */
int wpactrl_cmd_set_dfs_detect_mode(void *context, const char *ifname, int mode);

/**
 * wpactrl_cmd_send_action - send action frame to control interface
 * @context: control interface context
 * @ifname: interface name
 * @buf: action frame
 * @len: length of buffer
 * Returns: 0 on success, < 0 on error
 */
int wpactrl_cmd_send_action(void *context, const char *ifname, char *buf, unsigned short len);

/**
 * wpactrl_cmd_set_cce_ie - set dpp cce flag to control interface
 * @context: control interface context
 * @ifname: interface name
 * @enable: dpp cce flag enable/disable
 * Returns: 0 on success, < 0 on error
 */
int wpactrl_cmd_set_cce_ie(void *context, const char *ifname, unsigned char enable);

/**
 * wpactrl_cmd_get_probe_info - to get probe request of unassociated sta and transfer to mapd
 * @context: control interface context
 * @ifname: interface name
 * @reply_buf : to store unassociated sta info, which include(mac time_delta rssi)and retrive in wapp
 * Returns: 0 on success, < 0 on error
 */
int wpactrl_cmd_get_probe_info(void* context, const char *ifname, uint8_t* reply_buf);

/**
 * wpactrl_cmd_set_mesh_profile - set map version to hostapd
 * @context: control interface context
 * @ifname: interface name
 * @map_profile: map version, such as MAP_R1, MAP_R2
 * Returns: 0 on success, < 0 on error
 */
int wpactrl_cmd_set_mesh_profile(void *context, const char *ifname, unsigned char map_profile);

/**
 * wpactrl_cmd_set_mesh_primary_vid - set map primary vid to hostapd
 * @context: control interface context
 * @ifname: interface name
 * @map_pvid: map primary vid for traffic seperation, valid range:1-4094, invalid:4095
 * Returns: 0 on success, < 0 on error
 */
int wpactrl_cmd_set_mesh_primary_vid(void *context, const char *ifname, unsigned short map_pvid);

/**
 * wpactrl_cmd_get_usr_preffer_ch - get usr defined channel list from hostapd
 * @context: control interface context
 * @ifname: interface name
 * @freq_list_str: freq list;
 * @freq_list_len: freq list str len;
 * Returns: 0 on success, < 0 on error
 * Comma separated list of frequency ranges.
 * Freqency list per band; For example: 2412-2432,2462
 */
int wpactrl_cmd_get_usr_prefer_freqlist(void *context, const char *ifname, char *freq_list_str,
	size_t freq_list_len);

#endif
