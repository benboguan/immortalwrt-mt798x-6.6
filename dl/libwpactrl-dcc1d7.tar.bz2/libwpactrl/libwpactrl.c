/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2022  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdarg.h>
#include <errno.h>
#include <limits.h>
#include <unistd.h>
#include <pthread.h>
#include <net/if.h>
#include <string.h>
#include <wpa_ctrl.h>
#include <libwpactrl.h>

typedef struct {
	char iface[IFNAMSIZ];
	char full_ctrl_path[64 + IFNAMSIZ];
	wpactrl_type_t type;
	struct wpa_ctrl *wpa_ptr;
	int fd;
	void *cb_ctx;
	wpactrl_cbs_t *cbs;
} wpactrl_context_t;

const char *default_hostap_ctrl_path = "/var/run/hostapd/";

#ifndef MAC2STR
#define MAC2STR(a) (a)[0], (a)[1], (a)[2], (a)[3], (a)[4], (a)[5]
#define MAC2STRP(a) &(a)[0], &(a)[1], &(a)[2], &(a)[3], &(a)[4], &(a)[5]
#define MACSTR "%02hhx:%02hhx:%02hhx:%02hhx:%02hhx:%02hhx"
#endif

#ifndef ETH_ALEN
#define ETH_ALEN 6
#endif

#ifndef UUID_LEN
#define UUID_LEN 16
#endif

#ifndef PMKID_LEN
#define PMKID_LEN 16
#endif

typedef struct {
	char *op;
	size_t len;
	int (*func)(wpactrl_context_t *ctx, const char *ifname, const char *buf, size_t buf_len);
} event_handler_t;

#define EVENT_HANDLER_ENTRY(a, b) {a, (sizeof(a) - 1), b}

static inline int os_snprintf_error(size_t size, int res)
{
	return res < 0 || (unsigned int) res >= size;
}

static int snprintf_hex_sep(char *buf, size_t buf_size,
				const uint8_t *data, size_t len, char sep)
{
	size_t i;
	char *pos = buf, *end = buf + buf_size;
	int ret;

	if (buf_size == 0)
		return 0;

	for (i = 0; i < len; i++) {
		ret = snprintf(pos, end - pos, "%02x%c",
				  data[i], sep);
		if (os_snprintf_error(end - pos, ret)) {
			end[-1] = '\0';
			return pos - buf;
		}
		pos += ret;
	}
	pos[-1] = '\0';
	return pos - buf;
}


static inline int snprintf_hex(char *buf, size_t buf_size,
				const uint8_t *data, size_t len)
{
	size_t i;
	char *pos = buf, *end = buf + buf_size;
	int ret;
	if (buf_size == 0)
		return 0;
	for (i = 0; i < len; i++) {
		ret = snprintf(pos, end - pos, "%02x",
				  data[i]);
		if (os_snprintf_error(end - pos, ret)) {
			end[-1] = '\0';
			return pos - buf;
		}
		pos += ret;
	}
	end[-1] = '\0';
	return pos - buf;
}


static int hex2num(char c)
{
	if (c >= '0' && c <= '9')
		return c - '0';
	if (c >= 'a' && c <= 'f')
		return c - 'a' + 10;
	if (c >= 'A' && c <= 'F')
		return c - 'A' + 10;
	return -1;
}


static int hex2byte(const char *hex)
{
	int a, b;
	a = hex2num(*hex++);
	if (a < 0)
		return -1;
	b = hex2num(*hex++);
	if (b < 0)
		return -1;
	return (a << 4) | b;
}


static int hexstr2bin(const char *hex, uint8_t *buf, size_t len)
{
	size_t i;
	int a;
	const char *ipos = hex;
	uint8_t *opos = buf;

	for (i = 0; i < len; i++) {
		a = hex2byte(ipos);
		if (a < 0)
			return -1;
		*opos++ = a;
		ipos += 2;
	}
	return 0;
}

static const char * hwaddr_parse(const char *txt, uint8_t *addr)
{
	size_t i;

	for (i = 0; i < ETH_ALEN; i++) {
		int a;

		a = hex2byte(txt);
		if (a < 0)
			return NULL;
		txt += 2;
		addr[i] = a;
		if (i < ETH_ALEN - 1 && *txt++ != ':')
			return NULL;
	}
	return txt;
}


static int hwaddr_aton(const char *txt, uint8_t *addr)
{
	return hwaddr_parse(txt, addr) ? 0 : -1;
}

int uuid_str2bin(const char *str, uint8_t *bin)
{
	const char *pos;
	uint8_t *opos;

	pos = str;
	opos = bin;

	if (hexstr2bin(pos, opos, 4))
		return -1;
	pos += 8;
	opos += 4;

	if (*pos++ != '-' || hexstr2bin(pos, opos, 2))
		return -1;
	pos += 4;
	opos += 2;

	if (*pos++ != '-' || hexstr2bin(pos, opos, 2))
		return -1;
	pos += 4;
	opos += 2;

	if (*pos++ != '-' || hexstr2bin(pos, opos, 2))
		return -1;
	pos += 4;
	opos += 2;

	if (*pos++ != '-' || hexstr2bin(pos, opos, 6))
		return -1;

	return 0;
}

static inline void WPA_PUT_BE16(uint8_t *a, uint16_t val)
{
	a[0] = val >> 8;
	a[1] = val & 0xff;
}

int wps_dev_type_str2bin(const char *str, uint8_t* dev_type)
{
	const char *pos;

	/* <categ>-<OUI>-<subcateg> */
	WPA_PUT_BE16(dev_type, atoi(str));
	pos = strchr(str, '-');
	if (pos == NULL)
		return -1;
	pos++;
	if (hexstr2bin(pos, &dev_type[2], 4))
		return -1;
	pos = strchr(pos, '-');
	if (pos == NULL)
		return -1;
	pos++;
	WPA_PUT_BE16(&dev_type[6], atoi(pos));


	return 0;
}


static int debug_level = WPACTRL_DBGLVL_INFO;
static char *debug_prefix = NULL;

void wpactrl_debug_level_set(int level)
{
	debug_level = level;
}

void wpactrl_debug_prefix_set(const char *prefix)
{
	if (debug_prefix)
		free(debug_prefix);

	if (prefix) {
		debug_prefix = strdup(prefix);
	} else {
		debug_prefix = NULL;
	}
}

static int wpactrl_debug_default_printf(const char *fmt, ...)
{
	int ret;
	va_list ap;

	if (debug_prefix)
		ret = printf("%s", debug_prefix);
	va_start(ap, fmt);
	ret = vprintf(fmt, ap);
	va_end(ap);
	printf("\n");

	return ret;
}

static int (*wpactrl_debug_printf)(const char *format, ...) = \
					wpactrl_debug_default_printf;


void wpactrl_debug_print_func_set(int (*func)(const char *format, ...))
{
	wpactrl_debug_printf = func;
}

#define WPACTRL_DBGPRINTF(level, fmt, args...)					\
{										\
	if ((wpactrl_debug_printf) && (level >= debug_level)) {			\
		wpactrl_debug_printf("%s:%d: " fmt,				\
				__func__, __LINE__, ## args);			\
	}									\
}

static int wpactrl_deal_event_sta_connected(wpactrl_context_t *ctx,
					const char *ifname,
					const char *buf, size_t buf_len)
{
	uint8_t addr[ETH_ALEN];

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");
	if (ctx->cbs->event_sta_connected_cb== NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "no callback handler");
		return 0;
	}

	if (hwaddr_aton(buf, addr)) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", buf);
		return -EINVAL;
	}

	ctx->cbs->event_sta_connected_cb(ctx->cb_ctx, ifname, addr);

	return 0;
}

static int wpactrl_deal_event_sta_disconnected(wpactrl_context_t *ctx,
					const char *ifname,
					const char *buf, size_t buf_len)
{
	uint8_t addr[ETH_ALEN];

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (ctx->cbs->event_sta_disconnected_cb == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "no callback handler");
		return 0;
	}

	if (hwaddr_aton(buf, addr)) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", buf);
		return -EINVAL;
	}

	ctx->cbs->event_sta_disconnected_cb(ctx->cb_ctx, ifname, addr);

	return 0;
}

static int wpactrl_deal_event_connected(wpactrl_context_t *ctx,
					const char *ifname,
					const char *buf, size_t buf_len)
{
	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (ctx->cbs->event_connected_cb == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "no callback handler");
		return 0;
	}

	ctx->cbs->event_connected_cb(ctx->cb_ctx, ifname);

	return 0;
}

static int wpactrl_deal_event_disconnected(wpactrl_context_t *ctx,
					const char *ifname,
					const char *buf, size_t buf_len)
{
	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (ctx->cbs->event_disconnected_cb == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "no callback handler");
		return 0;
	}

	ctx->cbs->event_disconnected_cb(ctx->cb_ctx, ifname);

	return 0;
}


static int wpactrl_deal_event_wps_overlap(wpactrl_context_t *ctx,
					const char *ifname,
					const char *buf, size_t buf_len)
{
	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (ctx->cbs->event_wps_overlap_cb == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "no callback handler");
		return 0;
	}

	ctx->cbs->event_wps_overlap_cb(ctx->cb_ctx, ifname);

	return 0;
}

static int wpactrl_deal_event_wps_success(wpactrl_context_t *ctx,
					const char *ifname,
					const char *buf, size_t buf_len)
{
	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (ctx->cbs->event_wps_success_cb == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "no callback handler");
		return 0;
	}

	ctx->cbs->event_wps_success_cb(ctx->cb_ctx, ifname);

	return 0;
}

static int wpactrl_deal_event_wps_scan_fail(wpactrl_context_t *ctx,
					const char *ifname,
					const char *buf, size_t buf_len)
{
	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (ctx->cbs->event_wps_scan_fail_cb == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "no callback handler");
		return 0;
	}

	ctx->cbs->event_wps_scan_fail_cb(ctx->cb_ctx, ifname);

	return 0;
}

static int wpactrl_deal_event_wps_timeout(wpactrl_context_t *ctx,
					const char *ifname,
					const char *buf, size_t buf_len)
{
	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (ctx->cbs->event_wps_timeout_cb == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "no callback handler");
		return 0;
	}

	ctx->cbs->event_wps_timeout_cb(ctx->cb_ctx, ifname);

	return 0;
}

static int wpactrl_deal_event_wps_fail(wpactrl_context_t *ctx,
					const char *ifname,
					const char *buf, size_t buf_len)
{
	const char *msg_str = NULL;
	const char *config_error_str = NULL;
	const char *reason_str = NULL;
	int msg = 0;
	int config_error = 0;
	int reason = 0;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (ctx->cbs->event_wps_fail_cb == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "no callback handler");
		return 0;
	}

	msg_str = strstr(buf, " msg=");
	if (msg_str) {
		msg_str += 5;
		msg = atoi(msg_str);
	}

	config_error_str = strstr(buf, " config_error=");
	if (config_error_str) {
		config_error_str += 14;
		config_error = atoi(config_error_str);
	}

	reason_str = strstr(buf, " reason=");
	if (reason_str) {
		reason_str += 8;
		reason = atoi(reason_str);
	}

	ctx->cbs->event_wps_fail_cb(ctx->cb_ctx, ifname, msg, config_error, reason);

	return 0;
}

#ifdef WPACTRL_SUPPORT_MTK_EXTENSION
#ifdef WPS_EVENT_EAPOL_COMPLETE
static int wpactrl_deal_event_eapol_complete(wpactrl_context_t *ctx,
					const char *ifname,
					const char *buf, size_t buf_len)
{
	uint8_t addr[ETH_ALEN];

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (ctx->cbs->event_eapol_complete_cb == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "no callback handler");
		return 0;
	}

	if (hwaddr_aton(buf, addr)) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", buf);
		return -EINVAL;
	}

	buf = strchr(buf, '=') + 1;

	ctx->cbs->event_eapol_complete_cb(ctx->cb_ctx, ifname, addr, atoi(buf));

	return 0;
}
#endif /* WPS_EVENT_EAPOL_COMPLETE */
#endif /* WPACTRL_SUPPORT_MTK_EXTENSION */

static int wpactrl_deal_event_wps_active(wpactrl_context_t *ctx,
					const char *ifname,
					const char *buf, size_t buf_len)
{
	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (ctx->cbs->event_wps_active_cb == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "no callback handler");
		return 0;
	}

	ctx->cbs->event_wps_active_cb(ctx->cb_ctx, ifname);

	return 0;
}

static int wpactrl_deal_event_wps_disable(wpactrl_context_t *ctx,
					const char *ifname,
					const char *buf, size_t buf_len)
{
	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (ctx->cbs->event_wps_disable_cb == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "no callback handler");
		return 0;
	}

	ctx->cbs->event_wps_disable_cb(ctx->cb_ctx, ifname);

	return 0;
}

static int wpactrl_deal_event_wps_enrollee_seen(wpactrl_context_t *ctx,
					const char *ifname,
					const char *buf, size_t buf_len)
{
	uint8_t addr[ETH_ALEN];
	uint8_t uuid[UUID_LEN];
	uint8_t dev_type[8];
	uint32_t config_methods;
	uint32_t dev_password_id = 0;
	uint32_t request_type;
	char *dev_name = NULL;
	const char *uuid_str;
	const char *config_methods_str;
	const char *dev_type_str;
	const char *dev_password_id_str;
	const char *request_type_str;
	const char *dev_name_str;
	const char *end;
	int len;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (ctx->cbs->event_wps_enrollee_seen_cb == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "no callback handler");
		return 0;
	}

	if (hwaddr_aton(buf, addr)) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", buf);
		return -EINVAL;
	}

	uuid_str = strchr(buf, ' ');
	if (!uuid_str) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", buf);
		return -EINVAL;
	}
	uuid_str += 1;
	if (uuid_str2bin(uuid_str, uuid) < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", uuid_str);
		return -EINVAL;
	}

	dev_type_str = strchr(uuid_str, ' ');
	if (!dev_type_str) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", uuid_str);
		return -EINVAL;
	}
	dev_type_str += 1;
	if (wps_dev_type_str2bin(dev_type_str, dev_type) < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", dev_type_str);
		return -EINVAL;
	}

	config_methods_str = strchr(dev_type_str, ' ');
	if (!config_methods_str) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", dev_type_str);
		return -EINVAL;
	}
	config_methods_str += 1;
	config_methods = strtoul(config_methods_str, NULL, 16);
	if (config_methods == ULONG_MAX) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", config_methods_str);
		return -EINVAL;
	}

	request_type_str = strchr(config_methods_str, ' ');
	if (!request_type_str) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", config_methods_str);
		return -EINVAL;
	}
	request_type_str += 1;
	request_type = strtoul(request_type_str, NULL, 10);
	if (request_type == ULONG_MAX) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", request_type_str);
		return -EINVAL;
	}

	dev_name_str = strchr(request_type_str, ' ');
	if (!dev_name_str) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", request_type_str);
		return -EINVAL;
	}
	dev_name_str +=2;
	end = buf + buf_len - 1;
	len = end - dev_name_str;
	if (len) {
		dev_name = malloc(len + 1);
		if (!dev_name) {
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "malloc failed");
			return -ENOMEM;
		}
		memcpy(dev_name, dev_name_str, len);
		dev_name[len] = '\0';
	}


	ctx->cbs->event_wps_enrollee_seen_cb(ctx->cb_ctx, ifname,
					addr, uuid, dev_type, config_methods,
					dev_password_id, request_type, dev_name);
	if (dev_name)
		free(dev_name);

	return 0;
}

static int wpactrl_deal_event_wps_new_ap_setting(wpactrl_context_t *ctx,
						const char *ifname,
						const char *buf, size_t buf_len)
{
	size_t cred_attr_len;
	uint8_t cred_attr[256];

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (ctx->cbs->event_wps_new_ap_setting_cb == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "no callback handler");
		return 0;
	}

	cred_attr_len = strlen(buf);
	cred_attr_len /= 2;

	if (hexstr2bin(buf, cred_attr, cred_attr_len) < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", buf);
		return -EINVAL;
	}

	ctx->cbs->event_wps_new_ap_setting_cb(ctx->cb_ctx, ifname, cred_attr, cred_attr_len);

	return 0;
}

static int wpactrl_deal_event_btm_query(wpactrl_context_t *ctx,
					const char *ifname,
					const char *buf, size_t buf_len)
{
	const char *pos = NULL;
	const char *end = buf + buf_len;
	const char *neighbor_list = NULL;
	uint8_t mac[ETH_ALEN] = {0, 0, 0, 0, 0, 0};
	uint8_t *payload = NULL;
	size_t payload_len = 2;
	size_t neighbor_list_len = 0;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (ctx->cbs->event_btm_query_cb == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "no callback handler");
		return 0;
	}

	if (hwaddr_aton(buf, mac)) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", buf);
		return -EINVAL;
	}

	neighbor_list = strstr(buf, " neighbor=");
	if (neighbor_list) {
		neighbor_list += 10;
		neighbor_list_len = (end - neighbor_list) / 2;
		payload_len += neighbor_list_len;
	}

	payload = malloc(payload_len);
	if (!payload) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "malloc failed");
		return -ENOMEM;
	}

	pos = strstr(buf, " dialog_token=");
	if (!pos) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", buf);
		free(payload);
		return -EINVAL;
	}
	pos += 14;
	payload[0] = atoi(pos);

	pos = strstr(pos, " reason=");
	if (!pos) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", buf);
		free(payload);
		return -EINVAL;
	}
	pos += 8;
	payload[1] = atoi(pos);

	if (neighbor_list) {
		if (hexstr2bin(neighbor_list,
				payload + 2,
				neighbor_list_len) != 0) {
			free(payload);
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", neighbor_list);
			return -EINVAL;
		}
	}

	ctx->cbs->event_btm_query_cb(ctx->cb_ctx, ifname, mac,
				payload, payload_len);

	free(payload);

	return 0;
}

static int wpactrl_deal_event_btm_resp(wpactrl_context_t *ctx,
					const char *ifname,
					const char *buf, size_t buf_len)
{
	const char *pos = NULL;
	const char *end = buf + buf_len;
	const char *target_bssid = NULL;
	const char *neighbor_list = NULL;
	uint8_t mac[ETH_ALEN] = {0, 0, 0, 0, 0, 0};
	uint8_t *payload = NULL;
	size_t payload_len = 3;
	size_t neighbor_list_len = 0;
	size_t target_bssid_len = 0;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (ctx->cbs->event_btm_resp_cb == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "no callback handler");
		return 0;
	}

	if (hwaddr_aton(buf, mac)) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", buf);
		return -EINVAL;
	}

	target_bssid = strstr(buf, " target_bssid=");
	if (target_bssid) {
		target_bssid += 14;
		target_bssid_len = 6;
		payload_len += target_bssid_len;
	}

	neighbor_list = strstr(buf, " neighbor=");
	if (neighbor_list) {
		neighbor_list += 10;
		neighbor_list_len = (end - neighbor_list) / 2;
		payload_len += neighbor_list_len;
	}

	payload = malloc(payload_len);
	if (!payload) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "malloc failed");
		return -ENOMEM;
	}

	pos = strstr(buf, " dialog_token=");
	if (!pos) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", buf);
		free(payload);
		return -EINVAL;
	}
	pos += 14;
	payload[0] = atoi(pos);

	pos = strstr(pos, " status_code=");
	if (!pos) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", buf);
		free(payload);
		return -EINVAL;
	}
	pos += 13;
	payload[1] = atoi(pos);

	pos = strstr(pos, " bss_termination_delay=");
	if (!pos) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", buf);
		free(payload);
		return -EINVAL;
	}
	pos += 23;
	payload[2] = atoi(pos);

	if (target_bssid) {
		if (hwaddr_aton(target_bssid, payload + 3)) {
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", target_bssid);
			free(payload);
			return -EINVAL;
		}
	}

	if (neighbor_list) {
		if (hexstr2bin(neighbor_list,
				payload + 3 + target_bssid_len,
				neighbor_list_len) != 0) {
			free(payload);
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", neighbor_list);
			return -EINVAL;
		}
	}

	ctx->cbs->event_btm_resp_cb(ctx->cb_ctx, ifname, mac,
				payload, payload_len);

	free(payload);

	return 0;
}


#ifdef WPACTRL_SUPPORT_MTK_EXTENSION
#ifdef WNM_NOTIFY_REQ
static int wpactrl_deal_event_wnm_notify_req(wpactrl_context_t *ctx,
					const char *ifname,
					const char *buf, size_t buf_len)
{
	const char *payload_str = NULL;
	uint8_t mac[ETH_ALEN] = {0, 0, 0, 0, 0, 0};
	uint8_t *payload = NULL;
	size_t payload_len = 0;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (ctx->cbs->event_wnm_notify_req_cb == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "no callback handler");
		return 0;
	}

	if (hwaddr_aton(buf, mac)) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", buf);
		return -EINVAL;
	}

	payload_str = strstr(buf, " payload=");
	if (payload_str) {
		const char *end;

		payload_str += 9;
		end = strchr(payload_str, ' ');
		if (!end) {
			end = strchr(payload_str, '\0');
			if (!end) {
				WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", payload_str);
				return -EINVAL;
			}
		}
		if (end > payload_str) {
			payload_len = (end - payload_str) / 2;
			payload = malloc(payload_len);
			if (!payload) {
				WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "malloc failed");
				return -ENOMEM;
			}

			if (hexstr2bin(payload_str,
					payload,
					payload_len) != 0) {
				free(payload);
				WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", payload_str);
				return -EINVAL;
			}
		}

	}

	ctx->cbs->event_wnm_notify_req_cb(ctx->cb_ctx, ifname, mac,
				payload, payload_len);

	if (payload)
		free(payload);

	return 0;
}
#endif /* WNM_NOTIFY_REQ */

#ifdef ANQP_INITIAL_REQ
static int wpactrl_deal_event_anqp_init_req(wpactrl_context_t *ctx,
					const char *ifname,
					const char *buf, size_t buf_len)
{
	const char *payload_str = NULL;
	uint8_t mac[ETH_ALEN] = {0, 0, 0, 0, 0, 0};
	uint8_t *payload = NULL;
	size_t payload_len = 0;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (ctx->cbs->event_anqp_init_req_cb == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "no callback handler");
		return 0;
	}

	if (hwaddr_aton(buf, mac)) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", buf);
		return -EINVAL;
	}

	payload_str = strstr(buf, " payload=");
	if (payload_str) {
		const char *end;

		payload_str += 9;
		end = strchr(payload_str, ' ');
		if (!end) {
			end = strchr(payload_str, '\0');
			if (!end) {
				WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", payload_str);
				return -EINVAL;
			}
		}
		if (end > payload_str) {
			payload_len = (end - payload_str) / 2;
			payload = malloc(payload_len);
			if (!payload) {
				WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "malloc failed");
				return -ENOMEM;
			}

			if (hexstr2bin(payload_str,
					payload,
					payload_len) != 0) {
				free(payload);
				WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", payload_str);
				return -EINVAL;
			}
		}

	}

	ctx->cbs->event_anqp_init_req_cb(ctx->cb_ctx, ifname, mac,
				payload, payload_len);

	if (payload)
		free(payload);

	return 0;
}
#endif /* ANQP_INITIAL_REQ */
#endif /* WPACTRL_SUPPORT_MTK_EXTENSION */

static int wpactrl_deal_event_dfs_radar_detected(wpactrl_context_t *ctx,
					const char *ifname,
					const char *buf, size_t buf_len)
{
	int freq;
	int ht_enabled;
	int chan_offset;
	int chan_width;
	int cf1;
	int cf2;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (ctx->cbs->event_dfs_radar_detected_cb == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "no callback handler");
		return 0;
	}

	if (sscanf(buf, "freq=%d ht_enabled=%d chan_offset=%d chan_width=%d cf1=%d cf2=%d",
		&freq, &ht_enabled, &chan_offset, &chan_width, &cf1, &cf2) != 6) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", buf);
		return -EINVAL;
	}

	ctx->cbs->event_dfs_radar_detected_cb(ctx->cb_ctx, ifname, freq,
						ht_enabled, chan_offset,
						chan_width, cf1, cf2);

	return 0;
}

static int wpactrl_deal_event_dfs_new_channel(wpactrl_context_t *ctx,
					const char *ifname,
					const char *buf, size_t buf_len)
{
	int freq;
	int chan;
	int sec_chan;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (ctx->cbs->event_dfs_new_channel_cb == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "no callback handler");
		return 0;
	}

	if (sscanf(buf, "freq=%d chan=%d sec_chan=%d", &freq, &chan, &sec_chan) != 3) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", buf);
		return -EINVAL;
	}

	ctx->cbs->event_dfs_new_channel_cb(ctx->cb_ctx, ifname,
						freq, chan, sec_chan);

	return 0;
}

static int wpactrl_deal_event_eap_failure(wpactrl_context_t *ctx,
					const char *ifname,
					const char *buf, size_t buf_len)
{
	uint8_t mac[ETH_ALEN] = {0, 0, 0, 0, 0, 0};

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	/*
	 * TODO: Add proper handling for EAP failure
	 * with current setting wapp crash was observed
	 */
	if (ctx->cbs->event_eap_failure_cb == NULL)
		return 0;

	if (hwaddr_aton(buf, mac)) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", buf);
		return -EINVAL;
	}

	ctx->cbs->event_eap_failure_cb(ctx->cb_ctx, ifname, mac);

	return 0;
}

#ifdef WPACTRL_SUPPORT_MTK_EXTENSION
#ifdef WPA_EVENT_EAPOL_TIMEOUT
static int wpactrl_deal_event_eapol_timeout(wpactrl_context_t *ctx,
					const char *ifname,
					const char *buf, size_t buf_len)
{
	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (ctx->cbs->event_eap_timeout_cb == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "no callback handler");
		return 0;
	}

	ctx->cbs->event_eap_timeout_cb(ctx->cb_ctx, ifname);

	return 0;
}
#endif /* WPA_EVENT_EAPOL_TIMEOUT */
#endif /* WPACTRL_SUPPORT_MTK_EXTENSION */

static int wpactrl_deal_event_network_added(wpactrl_context_t *ctx,
					const char *ifname,
					const char *buf, size_t buf_len)
{
	int network_id = 0;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "trace");

	if (ctx->cbs->event_wnm_notify_network_added_cb == NULL)
		return 0;

	if (!buf)
		return -EINVAL;

	network_id = atoi(buf);

	ctx->cbs->event_wnm_notify_network_added_cb(ctx->cb_ctx, ifname, network_id);

	return 0;
}

static int wpactrl_deal_event_dfs_cac_start(wpactrl_context_t *ctx,
					const char *ifname,
					const char *buf, size_t buf_len)
{
	int freq;
	int chan;
	int sec_chan;
	int width;
	int seg0;
	int seg1;
	int cac_time;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (ctx->cbs->event_dfs_cac_start_cb == NULL)
		return 0;

	if (sscanf(buf, "freq=%d chan=%d sec_chan=%d, width=%d, seg0=%d, seg1=%d, cac_time=%ds",
		&freq, &chan, &sec_chan, &width, &seg0, &seg1, &cac_time) != 7) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", buf);
		return 0;
	}

	ctx->cbs->event_dfs_cac_start_cb(ctx->cb_ctx, ifname, freq,
						chan, sec_chan, width,
						seg0, seg1, cac_time);

	return 0;
}

static int wpactrl_deal_event_dfs_cac_completed(wpactrl_context_t *ctx,
					const char *ifname,
					const char *buf, size_t buf_len)
{
	int success;
	int freq;
	int ht_enabled;
	int chan_offset;
	int chan_width;
	int cf1;
	int cf2;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (ctx->cbs->event_dfs_cac_complete_cb == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "no callback handler");
		return 0;
	}

	if (sscanf(buf, "success=%d freq=%d ht_enabled=%d chan_offset=%d chan_width=%d cf1=%d cf2=%d",
		&success, &freq, &ht_enabled, &chan_offset, &chan_width, &cf1, &cf2) != 7) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", buf);
		return -EINVAL;
	}

	ctx->cbs->event_dfs_cac_complete_cb(ctx->cb_ctx, ifname, success,
						freq, ht_enabled, chan_offset,
						chan_width, cf1, cf2);

	return 0;
}

static int wpactrl_deal_event_dfs_nop_finished(wpactrl_context_t *ctx,
					const char *ifname,
					const char *buf, size_t buf_len)
{
	int freq;
	int ht_enabled;
	int chan_offset;
	int chan_width;
	int cf1;
	int cf2;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (ctx->cbs->event_dfs_nop_finished_cb == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "no callback handler");
		return 0;
	}

	if (sscanf(buf, "freq=%d ht_enabled=%d chan_offset=%d chan_width=%d cf1=%d cf2=%d",
		&freq, &ht_enabled, &chan_offset, &chan_width, &cf1, &cf2) != 6) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", buf);
		return -EINVAL;
	}

	ctx->cbs->event_dfs_nop_finished_cb(ctx->cb_ctx, ifname, freq,
						ht_enabled, chan_offset,
						chan_width, cf1, cf2);
	return 0;
}

static int wpactrl_deal_event_dfs_pre_cac_expired(wpactrl_context_t *ctx,
					const char *ifname,
					const char *buf, size_t buf_len)
{
	int freq;
	int ht_enabled;
	int chan_offset;
	int chan_width;
	int cf1;
	int cf2;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (ctx->cbs->event_dfs_pre_cac_expired_cb == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "no callback handler");
		return 0;
	}

	if (sscanf(buf, "freq=%d ht_enabled=%d chan_offset=%d chan_width=%d cf1=%d cf2=%d",
		&freq, &ht_enabled, &chan_offset, &chan_width, &cf1, &cf2) != 6) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", buf);
		return -EINVAL;
	}

	ctx->cbs->event_dfs_pre_cac_expired_cb(ctx->cb_ctx, ifname, freq,
						ht_enabled, chan_offset,
						chan_width, cf1, cf2);

	return 0;
}

static int wpactrl_deal_event_beacon_report(wpactrl_context_t *ctx,
					const char *ifname,
					const char *buf, size_t buf_len)
{
	const char *pos = NULL;
	uint8_t mac[ETH_ALEN] = {0, 0, 0, 0, 0, 0};
	uint8_t token;
	uint8_t report_mode;
	uint8_t *payload = NULL;
	size_t payload_len = 0;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (ctx->cbs->event_beacon_report_cb == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "no callback handler");
		return 0;
	}

	if (hwaddr_aton(buf, mac)) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", buf);
		return -EINVAL;
	}

	pos = strchr(buf + 17, ' ');
	if (!pos) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", buf);
		return -EINVAL;
	}

	pos += 1;
	token = atoi(pos);

	pos = strchr(pos, ' ');
	pos += 1;
	report_mode = strtoul(pos, NULL, 16);

	pos = strchr(pos, ' ');
	pos += 1;

	payload_len = ((buf + buf_len) - pos) / 2;
	if (payload_len > 0) {
		payload = malloc(payload_len);
		if (!payload) {
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "malloc failed");
			return -ENOMEM;
		}

		if (hexstr2bin(pos, payload, payload_len) != 0) {
			free(payload);
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", pos);
			return -EINVAL;
		}
	}

	ctx->cbs->event_beacon_report_cb(ctx->cb_ctx, ifname, mac, token,
		report_mode, payload, payload_len);

	if (payload)
		free(payload);

	return 0;
}

#ifdef WPACTRL_SUPPORT_MTK_EXTENSION
#ifdef BEACON_RESP_RX_DONE
static int wpactrl_deal_event_beacon_report_done(wpactrl_context_t *ctx,
					const char *ifname,
					const char *buf, size_t buf_len)
{
	const char *pos = NULL;
	uint8_t mac[ETH_ALEN] = {0, 0, 0, 0, 0, 0};
	uint8_t token;
	uint8_t report_mode;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (ctx->cbs->event_beacon_report_done_cb == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "no callback handler");
		return 0;
	}

	if (hwaddr_aton(buf, mac)) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", buf);
		return -EINVAL;
	}

	pos = strchr(buf + 17, ' ');
	if (!pos) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", buf);
		return -EINVAL;
	}

	pos += 1;
	token = atoi(pos);

	pos = strchr(pos, ' ');
	pos += 1;
	report_mode = strtoul(pos, NULL, 16);

	ctx->cbs->event_beacon_report_done_cb(ctx->cb_ctx, ifname,
		mac, token, report_mode);

	return 0;
}
#endif /* BEACON_RESP_RX_DONE */

#ifdef WPS_EVENT_DPP_URI_RECEIVED
static int wpactrl_deal_event_dpp_uri(wpactrl_context_t *ctx,
					const char *ifname,
					const char *buf, size_t buf_len)
{
	const char *pos = NULL;
	uint8_t *payload = NULL;
	uint8_t mac[ETH_ALEN] = {0, 0, 0, 0, 0, 0};
	size_t payload_len = 0;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (ctx->cbs->event_wps_dpp_uri_cb == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "no callback handler");
		return 0;
	}

	if (hwaddr_aton(buf, mac)) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", buf);
		return -EINVAL;
	}

	pos = strchr(buf + 17, ' ');
	if (!pos) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", buf);
		return -EINVAL;
	}
	pos += 1;

	payload_len = ((buf + buf_len) - pos) / 2;
	if (payload_len > 0) {
		payload = malloc(payload_len);
		if (!payload) {
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "malloc failed");
			return -ENOMEM;
		}

		if (hexstr2bin(pos, payload, payload_len) != 0) {
			free(payload);
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", pos);
			return -EINVAL;
		}
	}

	ctx->cbs->event_wps_dpp_uri_cb(ctx->cb_ctx, ifname,
		mac, payload, payload_len);

	if (payload)
		free(payload);

	return 0;
}
#endif /* WPS_EVENT_DPP_URI_RECEIVED */
#endif /* WPACTRL_SUPPORT_MTK_EXTENSION */

static int wpactrl_deal_event_wps_cred(wpactrl_context_t *ctx,
					const char *ifname,
					const char *buf, size_t buf_len)
{
	const char *pos = NULL;
	uint8_t *payload = NULL;
	size_t payload_len = 0;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (ctx->cbs->event_wps_cred_cb == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "no callback handler");
		return 0;
	}

	/*
	 * if buffer is NULL or buf len is zero then
	 * send event with payload len zero
	 */
	if(buf == NULL || (buf_len == 0)) {
		payload_len = 0;
		goto send_wapp;
	}

	pos = buf;
	payload_len = buf_len / 2;
	if (payload_len > 0) {
		payload = malloc(payload_len+2);
		if (!payload) {
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "malloc failed");
			return -ENOMEM;
		}
		memset(payload, 0, payload_len + 2);

		if (hexstr2bin(pos, payload, payload_len) != 0) {
			free(payload);
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", pos);
			return -EINVAL;
		}
	}

send_wapp:
	ctx->cbs->event_wps_cred_cb(ctx->cb_ctx, ifname, payload, payload_len);

	if (payload)
		free(payload);

	return 0;
}

#ifdef WPACTRL_SUPPORT_MTK_EXTENSION
#ifdef WPA_EVENT_RECONF_FAIL
static int wpactrl_deal_event_reconfig_fail(wpactrl_context_t *ctx,
					const char *ifname,
					const char *buf, size_t buf_len)
{

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (ctx->cbs->event_reconfig_fail_cb == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "no callback handler");
		return 0;
	}

	ctx->cbs->event_reconfig_fail_cb(ctx->cb_ctx, ifname);

	return 0;
}
#endif /* WPA_EVENT_RECONF_FAIL */

#ifdef WPA_EVENT_AP_STA_ASSOCED
static int wpactrl_deal_event_sta_assoc(wpactrl_context_t *ctx,
					const char *ifname,
					const char *buf, size_t buf_len)
{

	const char *pos = NULL;
	uint8_t mac[ETH_ALEN] = {0, 0, 0, 0, 0, 0};
	uint8_t assoc_ie_len;
	int reassoc;
	uint8_t *payload = NULL;
	size_t payload_len = 0;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (ctx->cbs->event_assoc_cb == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "no callback handler");
		return 0;
	}

	if (hwaddr_aton(buf, mac)) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", buf);
		return -EINVAL;
	}

	pos = strchr(buf + 17, ' ');
	if (!pos) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", buf);
		return -EINVAL;
	}

	pos += 1;
	reassoc = atoi(pos);
	pos = strchr(pos, ' ');

	pos += 1;
	assoc_ie_len = atoi(pos);
	pos = strchr(pos, ' ');

	pos += 1;
	payload_len = ((buf + buf_len) - pos) / 2;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_INFO, "Check Assoc_ie_len %d and payload_len %d\n",
		assoc_ie_len, payload_len);

	if (payload_len > 0) {
		payload = malloc(payload_len);
		if (!payload) {
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "malloc failed.\n");
			return -ENOMEM;
		}

		if (hexstr2bin(pos, payload, payload_len) != 0) {
			free(payload);
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s\n", pos);
			return -EINVAL;
		}

		ctx->cbs->event_assoc_cb(ctx->cb_ctx, ifname, mac, reassoc,
				(const char *)payload, payload_len);
		free(payload);
	} else {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "payload len error!\n");
		return -EINVAL;
	}


	return 0;

}
#endif /*WPA_EVENT_AP_STA_ASSOCED*/

#ifdef WPA_EVENT_AP_STA_DISASSOCED
static int wpactrl_deal_event_sta_disassoc(wpactrl_context_t *ctx,
						const char *ifname,
					const char *buf, size_t buf_len)
{
	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (ctx->cbs->event_disassoc_cb == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "no callback handler");
		return 0;

	}
	ctx->cbs->event_disassoc_cb(ctx->cb_ctx, ifname);

	return 0;

}
#endif /*WPA_EVENT_AP_STA_DISASSOCED*/

#ifdef WPA_EVENT_AP_RX_PROBE_REQ
static int wpactrl_deal_event_ap_rx_probe_req(wpactrl_context_t *ctx,
						const char *ifname,
					const char *buf, size_t buf_len)
{
	const char *pos = NULL;
	uint8_t mac[ETH_ALEN] = {0, 0, 0, 0, 0, 0};
	uint8_t probe_req_len;
	uint8_t *payload = NULL;
	size_t payload_len = 0;
	int freq = 0;
	int ssi_signal = 0;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (ctx->cbs->event_probe_req_cb == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "no callback handler");
		return 0;
	}

	if (hwaddr_aton(buf, mac)) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", buf);
		return -EINVAL;
	}

	pos = strchr(buf + 17, ' ');
	if (!pos) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", buf);
		return -EINVAL;
	}

	pos += 1;
	freq = atoi(pos);

	pos = strchr(pos, ' ');
	pos += 1;

	ssi_signal = atoi(pos);

	pos = strchr(pos, ' ');
	pos += 1;

	probe_req_len = atoi(pos);

	pos = strchr(pos, ' ');
	pos += 1;

	payload_len = ((buf + buf_len) - pos) / 2;

	if (payload_len > 0) {
		payload = malloc(payload_len);
		if (!payload) {
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "malloc failed.\n");
			return -ENOMEM;
		}

		if (hexstr2bin(pos, payload, payload_len) != 0) {
			free(payload);
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s\n", pos);
			return -EINVAL;
		}
		ctx->cbs->event_probe_req_cb(ctx->cb_ctx, ifname, mac,
			freq, ssi_signal, (const char *)payload, probe_req_len);
		free(payload);
	} else {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "payload len error!\n");
		return -EINVAL;
	}

	return 0;

}
#endif /*WPA_EVENT_AP_RX_PROBE_REQ*/

#ifdef WPA_EVENT_AP_CH_SURVEY
static int wpactrl_deal_event_ap_ch_survey(wpactrl_context_t *ctx,
						const char *ifname,
					const char *buf, size_t buf_len)
{

	const char *pos = NULL;
	uint8_t mac[ETH_ALEN] = {0, 0, 0, 0, 0, 0};
	int freq, cu;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (ctx->cbs->event_ap_ch_survey_cb == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "no callback handler");
		return 0;
	}

	if (hwaddr_aton(buf, mac)) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", buf);
		return -EINVAL;
	}

	pos = strchr(buf + 17, ' ');
	if (!pos) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", buf);
		return -EINVAL;
	}

	pos += 1;
	freq = atoi(pos);

	pos = strchr(pos, ' ');
	pos += 1;

	cu = atoi(pos);
	pos = strchr(pos, ' ');
	pos += 1;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "Single Channel Survey: Channel Utilization %d\n", cu);
	ctx->cbs->event_ap_ch_survey_cb(ctx->cb_ctx, ifname, mac, freq, cu);

	return 0;

}
#endif /*WPA_EVENT_AP_CH_SURVEY*/

#ifdef WPA_EVENT_ACTION_RX
static int wpactrl_deal_event_action_rx(wpactrl_context_t *ctx, const char *ifname, const char *buf, size_t buf_len)
{
	char mac_buf[18] = {0};
	char *frame_buf = NULL;
	uint8_t *frame = NULL;
	uint8_t mac[ETH_ALEN] = {0, 0, 0, 0, 0, 0};
	size_t frame_len = 0;
	int freq = 0;
	int is_gas = 0;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (ctx->cbs->event_action_rx_cb == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "no callback handler");
		return 0;
	}

	frame_buf = malloc(buf_len);
	if (!frame_buf)
		return -1;
	memset(frame_buf, 0, buf_len);

	if (sscanf(buf, "%s %d %d %s", mac_buf, &freq, &is_gas, frame_buf) != 4) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", buf);
		free(frame_buf);
		return -EINVAL;
	}

	if (hwaddr_aton(mac_buf, mac)) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", mac_buf);
		free(frame_buf);
		return -EINVAL;
	}

	frame_len = strlen((const char *)frame_buf) / 2;/*hex str length / 2*/
	if (frame_len < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", frame_buf);
		free(frame_buf);
		return -EINVAL;
	}

	frame = malloc(frame_len);
	if (!frame) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "frame malloc fail");
		free(frame_buf);
		return -ENOMEM;
	}

	if (hexstr2bin(frame_buf, frame, frame_len) < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", frame_buf);
		free(frame);
		free(frame_buf);
		return -EINVAL;
	}

	ctx->cbs->event_action_rx_cb(ctx->cb_ctx, ifname, (const uint8_t *)mac, freq, is_gas,
								(const char *)frame, frame_len);

	free(frame);
	free(frame_buf);

	return 0;
}
#endif /*WPA_EVENT_ACTION RX*/

#ifdef WPA_EVENT_AP_STA_CONNECTED_INFO
static int wpactrl_deal_event_sta_connected_info(wpactrl_context_t *ctx, const char *ifname,
						const char *buf, size_t buf_len)
{

	const char *pos = NULL;
	const char *dev_bssid = NULL;
	uint8_t addr[ETH_ALEN] = {0, 0, 0, 0, 0, 0};
	uint8_t bssid[ETH_ALEN] = {0, 0, 0, 0, 0, 0};
	uint8_t connect_stage;
	uint16_t reason_code;
	uint16_t assoc_status_code;
	uint16_t assoc_reason_code;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (ctx->cbs->event_sta_connected_info_cb == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "no callback handler");
		return 0;
	}

	if (hwaddr_aton(buf, addr)) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", buf);
		return -EINVAL;
	}
	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "sta mac "MACSTR "\n", MAC2STR(addr));

	dev_bssid = strstr(buf, " dev_bssid=");
	if (dev_bssid) {
		dev_bssid += 11;
	}

	if (hwaddr_aton(dev_bssid, bssid)) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", buf);
		return -EINVAL;
	}
	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "sta bssid "MACSTR "\n", MAC2STR(bssid));

	pos = strstr(buf, " connect_stage=");
	if (!pos) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", buf);
		return -EINVAL;
	}
	pos += 15;
	connect_stage = atoi(pos);

	pos = strstr(pos, " reason_code=");
	if (!pos) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", buf);
		return -EINVAL;
	}
	pos += 13;
	reason_code = atoi(pos);

	pos = strstr(pos, " assoc_status_code=");
	if (!pos) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", buf);
		return -EINVAL;
	}
	pos += 19;
	assoc_status_code = atoi(pos);

	pos = strstr(pos, " assoc_reason_code=");
	if (!pos) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format:%s", buf);
		return -EINVAL;
	}
	pos += 19;
	assoc_reason_code = atoi(pos);

	ctx->cbs->event_sta_connected_info_cb(ctx->cb_ctx, ifname, addr, bssid,
		   connect_stage, reason_code, assoc_status_code, assoc_reason_code);

	return 0;
}
#endif /*WPA_EVENT_AP_STA_CONNECTED_FAIL*/

int wpactrl_cmd_send_action(void *context, const char *ifname, char *buf, unsigned short len)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char *cmd = NULL;
	char reply[16];
	size_t reply_len = sizeof(reply);
	int prefix_len = 60; /*the prefix_len of cmd: infacename + action_tx*/
	int malloc_len = (len * 2) + 1 + prefix_len;/*(len*2)+1 = length of hex cmd*/
	int cmd_len = 0;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	cmd = malloc(malloc_len);
	if (!cmd) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "malloc fail");
		return -ENOMEM;
	}

	memset(cmd, 0, malloc_len);
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, malloc_len, "IFNAME=%s ACTION_TX ", ifname);
	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		free(cmd);
		return -EFAULT;
	}

	cmd_len += ret;
	ret = snprintf_hex(cmd + cmd_len, malloc_len - cmd_len, (const uint8_t *)buf, len);
	cmd_len += ret;
	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s\n", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr, cmd, cmd_len, reply, &reply_len, NULL);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed\n");
		free(cmd);
		return -EFAULT;
	}

	if ((reply_len == 3) &&
		(reply[0] == 'O') &&
		(reply[1] == 'K')) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "send dpp action frame ok\n");
		free(cmd);
		return 0;
	}
	free(cmd);
	return -EFAULT;
}

int wpactrl_cmd_set_cce_ie(void *context, const char *ifname, unsigned char enable)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[2048];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s SET cce %d", ifname, enable);
	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len += ret;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr, cmd, cmd_len, reply, &reply_len, NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
		(reply[0] == 'O') &&
		(reply[1] == 'K')) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "add/delete cce ie ok");
		return 0;
	} else {
		return -EFAULT;
	}
}

int wpactrl_cmd_set_mesh_profile(void *context, const char *ifname, unsigned char map_profile)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[2048];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace ifname:%s map_profile %d", ifname, map_profile);

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s SET map_profile %d", ifname, map_profile);
	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len += ret;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr, cmd, cmd_len, reply, &reply_len, NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
		(reply[0] == 'O') &&
		(reply[1] == 'K')) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "add map_profile ok");
		return 0;
	} else {
		return -EFAULT;
	}
}

int wpactrl_cmd_set_mesh_primary_vid(void *context, const char *ifname, unsigned short map_pvid)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[2048];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace ifname:%s map_pvid %d", ifname, map_pvid);

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s SET map_pvid %d", ifname, map_pvid);
	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len += ret;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr, cmd, cmd_len, reply, &reply_len, NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
		(reply[0] == 'O') &&
		(reply[1] == 'K')) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "add map_pvid ok");
		return 0;
	} else {
		return -EFAULT;
	}
}

#endif /*WPACTRL_SUPPORT_MTK_EXTENSION*/

static event_handler_t hostapd_event_handler_table[] =
{
	EVENT_HANDLER_ENTRY(AP_STA_CONNECTED, wpactrl_deal_event_sta_connected),
	EVENT_HANDLER_ENTRY(AP_STA_DISCONNECTED, wpactrl_deal_event_sta_disconnected),
	EVENT_HANDLER_ENTRY(WPS_EVENT_OVERLAP, wpactrl_deal_event_wps_overlap),
	EVENT_HANDLER_ENTRY(WPS_EVENT_NEW_AP_SETTINGS, wpactrl_deal_event_wps_new_ap_setting),
	EVENT_HANDLER_ENTRY(WPS_EVENT_SUCCESS,wpactrl_deal_event_wps_success),
	EVENT_HANDLER_ENTRY(WPS_EVENT_TIMEOUT, wpactrl_deal_event_wps_timeout),
	EVENT_HANDLER_ENTRY(WPS_EVENT_FAIL, wpactrl_deal_event_wps_fail),
	EVENT_HANDLER_ENTRY(WPS_EVENT_ACTIVE, wpactrl_deal_event_wps_active),
	EVENT_HANDLER_ENTRY(WPS_EVENT_DISABLE, wpactrl_deal_event_wps_disable),
	/* Event handler for WPS credentials received from hostapd */
	EVENT_HANDLER_ENTRY(WPS_EVENT_CRED_RECEIVED, wpactrl_deal_event_wps_cred),
	EVENT_HANDLER_ENTRY(WPS_EVENT_ENROLLEE_SEEN, wpactrl_deal_event_wps_enrollee_seen),
	EVENT_HANDLER_ENTRY(BSS_TM_QUERY, wpactrl_deal_event_btm_query),
	EVENT_HANDLER_ENTRY(BSS_TM_RESP, wpactrl_deal_event_btm_resp),
	EVENT_HANDLER_ENTRY(BEACON_RESP_RX, wpactrl_deal_event_beacon_report),
	EVENT_HANDLER_ENTRY(DFS_EVENT_RADAR_DETECTED, wpactrl_deal_event_dfs_radar_detected),
	EVENT_HANDLER_ENTRY(DFS_EVENT_NEW_CHANNEL, wpactrl_deal_event_dfs_new_channel),
	EVENT_HANDLER_ENTRY(DFS_EVENT_CAC_START, wpactrl_deal_event_dfs_cac_start),
	EVENT_HANDLER_ENTRY(DFS_EVENT_CAC_COMPLETED, wpactrl_deal_event_dfs_cac_completed),
	EVENT_HANDLER_ENTRY(DFS_EVENT_NOP_FINISHED, wpactrl_deal_event_dfs_nop_finished),
	EVENT_HANDLER_ENTRY(DFS_EVENT_PRE_CAC_EXPIRED, wpactrl_deal_event_dfs_pre_cac_expired),
	EVENT_HANDLER_ENTRY(WPA_EVENT_EAP_TIMEOUT_FAILURE , wpactrl_deal_event_eap_failure),
	EVENT_HANDLER_ENTRY(WPA_EVENT_EAP_TIMEOUT_FAILURE2 , wpactrl_deal_event_eap_failure),
#ifdef WPACTRL_SUPPORT_MTK_EXTENSION
#ifdef WPS_EVENT_DPP_URI_RECEIVED
	EVENT_HANDLER_ENTRY(WPS_EVENT_DPP_URI_RECEIVED, wpactrl_deal_event_dpp_uri),
#endif /* WPS_EVENT_DPP_URI_RECEIVED */
#ifdef BEACON_RESP_RX_DONE
	EVENT_HANDLER_ENTRY(BEACON_RESP_RX_DONE, wpactrl_deal_event_beacon_report_done),
#endif /* BEACON_RESP_RX_DONE */
#ifdef ANQP_INITIAL_REQ
	EVENT_HANDLER_ENTRY(ANQP_INITIAL_REQ, wpactrl_deal_event_anqp_init_req),
#endif /* ANQP_INITIAL_REQ */
#ifdef WNM_NOTIFY_REQ
	EVENT_HANDLER_ENTRY(WNM_NOTIFY_REQ, wpactrl_deal_event_wnm_notify_req),
#endif /* WNM_NOTIFY_REQ */
#ifdef WPS_EVENT_EAPOL_COMPLETE
	EVENT_HANDLER_ENTRY(WPS_EVENT_EAPOL_COMPLETE, wpactrl_deal_event_eapol_complete),
#endif /* WPS_EVENT_EAPOL_COMPLETE */
#ifdef WPA_EVENT_AP_STA_ASSOCED
	EVENT_HANDLER_ENTRY(WPA_EVENT_AP_STA_ASSOCED, wpactrl_deal_event_sta_assoc),
#endif /*WPA_EVENT_AP_STA_ASSOCED*/
#ifdef WPA_EVENT_AP_STA_DISASSOCED
	EVENT_HANDLER_ENTRY(WPA_EVENT_AP_STA_DISASSOCED, wpactrl_deal_event_sta_disassoc),
#endif /*WPA_EVENT_AP_STA_DISASSOCED*/
#ifdef WPA_EVENT_AP_RX_PROBE_REQ
	EVENT_HANDLER_ENTRY(WPA_EVENT_AP_RX_PROBE_REQ, wpactrl_deal_event_ap_rx_probe_req),
#endif /*WPA_EVENT_AP_RX_PROBE_REQ*/
#ifdef WPA_EVENT_AP_CH_SURVEY
	EVENT_HANDLER_ENTRY(WPA_EVENT_AP_CH_SURVEY, wpactrl_deal_event_ap_ch_survey),
#endif /*WPA_EVENT_AP_CH_SURVEY*/
#ifdef WPA_EVENT_ACTION_RX
	EVENT_HANDLER_ENTRY(WPA_EVENT_ACTION_RX, wpactrl_deal_event_action_rx),
#endif /*WPA_EVENT_ACTION_RX*/
#ifdef WPA_EVENT_AP_STA_CONNECTED_INFO
	EVENT_HANDLER_ENTRY(WPA_EVENT_AP_STA_CONNECTED_INFO, wpactrl_deal_event_sta_connected_info),
#endif /*WPA_EVENT_AP_STA_CONNECTED_FAIL*/
#endif /* WPACTRL_SUPPORT_MTK_EXTENSION */
	{NULL, 0, NULL},
};

static event_handler_t supplicant_event_handler_table[] =
{
	EVENT_HANDLER_ENTRY(WPA_EVENT_CONNECTED, wpactrl_deal_event_connected),
	EVENT_HANDLER_ENTRY(WPA_EVENT_DISCONNECTED, wpactrl_deal_event_disconnected),
	EVENT_HANDLER_ENTRY(WPS_EVENT_OVERLAP, wpactrl_deal_event_wps_overlap),
	EVENT_HANDLER_ENTRY(WPS_EVENT_SUCCESS,wpactrl_deal_event_wps_success),
	EVENT_HANDLER_ENTRY(WPS_EVENT_TIMEOUT, wpactrl_deal_event_wps_timeout),
	EVENT_HANDLER_ENTRY(WPS_EVENT_FAIL, wpactrl_deal_event_wps_fail),
	EVENT_HANDLER_ENTRY(WPS_EVENT_ACTIVE, wpactrl_deal_event_wps_active),
	EVENT_HANDLER_ENTRY(WPS_EVENT_DISABLE, wpactrl_deal_event_wps_disable),
	EVENT_HANDLER_ENTRY(WPS_EVENT_CRED_RECEIVED, wpactrl_deal_event_wps_cred),
	EVENT_HANDLER_ENTRY(WPA_EVENT_NETWORK_ADDED, wpactrl_deal_event_network_added),
	EVENT_HANDLER_ENTRY(WPA_EVENT_SCAN_FAILED, wpactrl_deal_event_wps_scan_fail),
#ifdef WPACTRL_SUPPORT_MTK_EXTENSION
#ifdef WPA_EVENT_EAPOL_TIMEOUT
	EVENT_HANDLER_ENTRY(WPA_EVENT_EAPOL_TIMEOUT, wpactrl_deal_event_eapol_timeout),
#endif /* WPA_EVENT_EAPOL_TIMEOUT */
#ifdef WPA_EVENT_RECONF_FAIL
	EVENT_HANDLER_ENTRY(WPA_EVENT_RECONF_FAIL, wpactrl_deal_event_reconfig_fail),
#endif /* WPA_EVENT_RECONF_FAIL */
#ifdef WNM_NOTIFY_REQ
	EVENT_HANDLER_ENTRY(WNM_NOTIFY_REQ, wpactrl_deal_event_wnm_notify_req),
#endif /* WNM_NOTIFY_REQ */
#endif /* WPACTRL_SUPPORT_MTK_EXTENSION */
	//EVENT_HANDLER_ENTRY(ANQP_RESP, wpactrl_deal_event_anqp_resp),
	{NULL, 0, NULL},
};

static event_handler_t none_event_handler_table[] =
{
	{NULL, 0, NULL},
};

static event_handler_t* event_handler_table[WPACTRL_TYPE_MAX] = {
	[WPACTRL_TYPE_NONE] = none_event_handler_table,
	[WPACTRL_TYPE_HOSTAPD] = hostapd_event_handler_table,
	[WPACTRL_TYPE_SUPPLICANT] = supplicant_event_handler_table,
};

int wpactrl_event_get(void *context)
{
	int ret;
	char buf[2048];
	char *msg = NULL;
	size_t buf_len = sizeof(buf);
	size_t msg_len;
	wpactrl_context_t *ctx = NULL;
	char *opcode;
	char *saveptr = NULL;
	event_handler_t *handler;
	char ifname[33] = "\0";

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_INFO, "trace");

	if (!context) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	ret = wpa_ctrl_pending(ctx->wpa_ptr);
	switch (ret) {
	case -1:
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_pending:%d", ret);
		return -EFAULT;
	case 0:
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_INFO, "wpa_ctrl_pending done");
		return 0;
	case 1:
		break;
	default:
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_pending:%d", ret);
		return -EFAULT;
	}

	if (wpa_ctrl_recv(ctx->wpa_ptr, buf, &buf_len) != 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_recv failed");
		return -EFAULT;
	}

	buf[buf_len] = '\0';

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "buf:%s", buf);

	if (buf_len <= 5) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format");
		return -EINVAL;
	}

	if (sscanf(buf, "IFNAME=%s ", ifname) == EOF) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "get ifname fail");
		return -EFAULT;
	}

	msg = strchr(buf, '>');
	if (!msg) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid format");
		return 0;
	}
	msg += 1;
	msg_len = buf_len - (msg - buf);

	for (handler = event_handler_table[ctx->type];
	     ((handler->len != 0) && (handler->op != NULL)); handler++) {
		if (strncasecmp(handler->op, msg, handler->len) == 0) {
			if (!handler->func) {
				WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "shouldn't reach here");
				return 0;
			}
			return handler->func(ctx, ifname, msg + handler->len, msg_len - handler->len);
		}
	}

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_INFO, "skip event:%s", buf);

	return 0;
}


int wpactrl_cmd_enable(void* context, const char *ifname)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[64];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s ENABLE", ifname);
	if (ret <= 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len = ret;

	memset(reply, 0, sizeof(reply));

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);
	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR,
				"wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
	    (reply[0] == 'O') &&
	    (reply[1] == 'K')) {
		return 0;
	} else {
		return -EINVAL;
	}

	return 0;
}

int wpactrl_cmd_disable(void* context, const char *ifname)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[64];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s DISABLE", ifname);
	if (ret <= 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len = ret;

	memset(reply, 0, sizeof(reply));

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
	    (reply[0] == 'O') &&
	    (reply[1] == 'K')) {
		return 0;
	} else {
		return -EFAULT;
	}
}
int wpactrl_cmd_intf_add(void* context,const char *phy_iface, const char *bss_config_path, const char *config_path)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[256] = {0};
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl_cmd_intf_add trace");

	if ((context == NULL) ||
		((phy_iface == NULL || bss_config_path == NULL) && (config_path == NULL))) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "ADD ");
	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len = ret;

	if (phy_iface != NULL && bss_config_path != NULL) {
		ret = snprintf(cmd + cmd_len, sizeof(cmd) - cmd_len, "bss_config=%s:%s", phy_iface, bss_config_path);
		if (ret < 0) {
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
			return -EFAULT;
		}
		cmd_len += ret;
	}

	if (config_path != NULL) {
		ret = snprintf(cmd + cmd_len, sizeof(cmd) - cmd_len, " config=%s", config_path);
		if (ret < 0) {
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
			return -EFAULT;
		}
		cmd_len += ret;
	}

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "ADD BSS cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
	    (reply[0] == 'O') &&
	    (reply[1] == 'K')) {
		return 0;
	} else {
		return -EFAULT;
	}
}

int wpactrl_cmd_intf_disable(void* context, const char *iface)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[256] = {0};
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !iface || *iface == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "REMOVE %s", iface);
	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len += ret;
	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
	    (reply[0] == 'O') &&
	    (reply[1] == 'K')) {
		return 0;
	} else {
		return -EFAULT;
	}
}

int wpactrl_cmd_set(void* context, const char *ifname, const char* name, const char* value)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[2048];
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0' || name == NULL || value == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s SET %s %s", ifname, name, value);
	if (ret <= 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	} else if (ret > sizeof(cmd)) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf incomplete (%d)", ret);
	}

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", strlen(cmd), cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				strlen(cmd),
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
	    (reply[0] == 'O') &&
	    (reply[1] == 'K')) {
		return 0;
	} else {
		return -EFAULT;
	}
}

int wpactrl_cmd_set_network(void* context, const char *ifname, int network_id, const char* name, const char* value)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[128];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0' || name == NULL || value == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s SET_NETWORK %d %s %s", ifname, network_id, name, value);
	if (ret <= 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len = ret;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
	    (reply[0] == 'O') &&
	    (reply[1] == 'K')) {
		return 0;
	} else {
		return -EFAULT;
	}
}

int wpactrl_cmd_set_network_dpp_pfs(void* context, const char *ifname, int network_id, const char* name, int value)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[128];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0' || name == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s SET_NETWORK %d %s %d", ifname, network_id, name, value);
	if (ret <= 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len = ret;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
	    (reply[0] == 'O') &&
	    (reply[1] == 'K')) {
		return 0;
	} else {
		return -EFAULT;
	}
}

int wpactrl_cmd_bss_tm_req(void* context, const char *ifname, const uint8_t* sta_mac,
			int disassoc_timer, int valid_int,
			int dialog_token, int bss_term,
			bss_tm_req_candidate_t *cand_list, int cand_list_len,
			const char *url, int url_len,
			int pref, int abridged, int disassoc_imminent,
			int mbo_reason, int reassoc_delay, int cell_pref)
{
	int ret;
	int i;
	wpactrl_context_t *ctx = NULL;
	char cmd[2048];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s BSS_TM_REQ " MACSTR,
			ifname, MAC2STR(sta_mac));
	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len += ret;

	if (disassoc_timer > 0) {
		ret = snprintf(cmd + cmd_len,
				sizeof(cmd) - cmd_len,
				" disassoc_timer=%d",
				disassoc_timer);
		if (ret < 0) {
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
			return -EFAULT;
		}
		cmd_len += ret;
	}

	if (valid_int > 0) {
		ret = snprintf(cmd + cmd_len,
				sizeof(cmd) - cmd_len,
				" valid_int=%d",
				valid_int);
		if (ret < 0) {
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
			return -EFAULT;
		}
		cmd_len += ret;
	}

	if (dialog_token > 0) {
		ret = snprintf(cmd + cmd_len,
				sizeof(cmd) - cmd_len,
				" dialog_token=%d",
				dialog_token);
		if (ret < 0) {
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
			return -EFAULT;
		}
		cmd_len += ret;
	}

	if (bss_term > 0) {
		ret = snprintf(cmd + cmd_len,
				sizeof(cmd) - cmd_len,
				" bss_term=%d",
				bss_term);
		if (ret < 0) {
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
			return -EFAULT;
		}
		cmd_len += ret;
	}

	for (i = 0; i < cand_list_len; i++) {
		bss_tm_req_candidate_t *cand = &cand_list[i];
		ret = snprintf(cmd + cmd_len,
				sizeof(cmd) - cmd_len,
				" neighbor=" MACSTR ",0x%04x,%d,%d,%d%s",
				MAC2STR(cand->bssid),
				cand->bssid_info,
				cand->operating_class,
				cand->channel,
				cand->phy_type,
				(cand->subelement_len > 0)? ",": "");
		if (ret < 0) {
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
			return -EFAULT;
		}
		cmd_len += ret;

		ret = snprintf_hex(cmd + cmd_len,
				sizeof(cmd) - cmd_len,
				cand->subelement,
				cand->subelement_len);
		if (ret <= 0) {
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf_hex failed");
			return -EFAULT;
		}
		cmd_len += ret;
	}

	if (url && (url_len > 0)) {
		ret = snprintf(cmd + cmd_len,
				sizeof(cmd) - cmd_len,
				" url=%s",
				url);
		if (ret < 0) {
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
			return -EFAULT;
		}
		cmd_len += ret;
	}

	if (pref != 0) {
		ret = snprintf(cmd + cmd_len,
				sizeof(cmd) - cmd_len,
				" pref=1");
		if (ret < 0) {
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
			return -EFAULT;
		}
		cmd_len += ret;
	}

	if (abridged != 0) {
		ret = snprintf(cmd + cmd_len,
				sizeof(cmd) - cmd_len,
				" abridged=1");
		if (ret < 0) {
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
			return -EFAULT;
		}
		cmd_len += ret;
	}

	if (disassoc_imminent != 0) {
		ret = snprintf(cmd + cmd_len,
				sizeof(cmd) - cmd_len,
				" disassoc_imminent=1");
		if (ret < 0) {
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
			return -EFAULT;
		}
		cmd_len += ret;
	}

	if ( mbo_reason != 255 ) {
		ret = snprintf(cmd + cmd_len,
				sizeof(cmd) - cmd_len,
				" mbo=%u:%u:%u",
				mbo_reason,
				reassoc_delay,
				cell_pref);
		if (ret < 0) {
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
			return -EFAULT;
		}
		cmd_len += ret;
	}

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
	    (reply[0] == 'O') &&
	    (reply[1] == 'K')) {
		return 0;
	} else {
		return -EFAULT;
	}
}


int wpactrl_cmd_sta_deauth(void *context, const char *ifname, const uint8_t* sta_mac)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[2048];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s DEAUTHENTICATE " MACSTR " ",
			ifname, MAC2STR(sta_mac));

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}

	cmd_len += ret;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);
	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR,
				"wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
	    (reply[0] == 'O') &&
	    (reply[1] == 'K')) {
		return 0;
	} else {
		return -EINVAL;
	}

	return 0;
}

int wpactrl_cmd_get_pmk(void* context, const char *ifname, const uint8_t* sta_mac, uint8_t* reply_buf)
{
        int ret;
        wpactrl_context_t *ctx = NULL;
        char cmd[2048];
        int cmd_len = 0;
        char reply[66];
        size_t reply_len = sizeof(reply);

        WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

        if (!context || !ifname || *ifname == '\0') {
                WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
                return -EINVAL;
        }

        ctx = context;
        if (ctx->wpa_ptr == NULL) {
                WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
                return -EFAULT;
        }

        memset(cmd, 0, sizeof(cmd));
        memset(reply, 0, sizeof(reply));

        ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s GET_PMK " MACSTR " ",
                        ifname, MAC2STR(sta_mac));

        if (ret < 0) {
                WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
				return -EFAULT;
        }

        cmd_len += ret;

        WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

        ret = wpa_ctrl_request(ctx->wpa_ptr,
                                cmd,
                                cmd_len,
                                reply,
                                &reply_len,
                                NULL);

        WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

        if (ret < 0) {
                WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR,
                                "wpa_ctrl_request failed");
                return -EFAULT;
        }

        if (reply_len <= 0 || reply_len > 66) {
                WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "reply len failed");
                return -EFAULT;
        }

	if ((reply_len == 5) &&
		(reply[0] == 'F') &&
		(reply[1] == 'A') &&
		(reply[2] == 'I') &&
		(reply[3] == 'L')) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "reply len failed");
                return -EFAULT;
	}
	if (reply_len > 0) {
		/* reply buf will be used in wapp to write pmk in dpp cfg test file*/
		memset(reply_buf, 0, reply_len);
		memcpy(reply_buf, reply, reply_len);
	}

        return ret;
}

int wpactrl_cmd_remove_network(void* context, const char *ifname)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[128];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}


	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s REMOVE_NETWORK all", ifname);
	if (ret <= 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len = ret;

	memset(reply, 0, sizeof(reply));

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
	    (reply[0] == 'O') &&
	    (reply[1] == 'K')) {
		return 0;
	} else {
		return -EFAULT;
	}
}

int wpactrl_cmd_disable_network(void* context, const char *ifname, int network_id)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[2048];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s DISABLE_NETWORK %d", ifname, network_id);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}

	cmd_len += ret;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
	    (reply[0] == 'O') &&
	    (reply[1] == 'K')) {
		return 0;
	} else {
		return -EFAULT;
	}
}

int wpactrl_cmd_bss_flush(void* context, const char *ifname)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[2048];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s BSS_FLUSH 0", ifname);
	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len += ret;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
			cmd,
			cmd_len,
			reply,
			&reply_len,
			NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
			(reply[0] == 'O') &&
			(reply[1] == 'K')) {
		return 0;
	} else {
		return -EFAULT;
	}
}

int wpactrl_cmd_select_network(void* context, const char *ifname, int network_id, int frequency)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[2048];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	if (frequency)
		ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s SELECT_NETWORK %d freq=%d", ifname, network_id, frequency);
	else
		ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s SELECT_NETWOTK %d", ifname, network_id);
	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}

	cmd_len += ret;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
	    (reply[0] == 'O') &&
	    (reply[1] == 'K')) {
		return 0;
	} else {
		return -EFAULT;
	}
}

int wpactrl_cmd_enable_network(void* context, const char *ifname, int network_id)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[2048];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s ENABLE_NETWORK %d", ifname, network_id);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}

	cmd_len += ret;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
	    (reply[0] == 'O') &&
	    (reply[1] == 'K')) {
		return 0;
	} else {
		return -EFAULT;
	}
}

int wpactrl_cmd_set_network_bssid(void* context, const char *ifname, int network_id, const char *bssid)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[2048];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s SET_NETWORK %d bssid ", ifname, network_id);
	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}

	cmd_len += ret;

	ret = snprintf (cmd + cmd_len, sizeof(cmd) - cmd_len, "%02x:%02x:%02x:%02x:%02x:%02x", PRINT_MAC(bssid));
	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}

	cmd_len += ret;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
	    (reply[0] == 'O') &&
	    (reply[1] == 'K')) {
		return 0;
	} else {
		return -EFAULT;
	}
}

int wpactrl_cmd_add_network(void* context, const char *ifname)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[128];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s ADD_NETWORK", ifname);
	if (ret <= 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len = ret;

	memset(reply, 0, sizeof(reply));

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if (reply_len < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "reply len failed");
		return -EFAULT;
	}

	if (reply_len > 0)
		return atoi(reply) ;
	else
		return -EFAULT;
}

int wpactrl_cmd_add_network_key(void* context, const char *ifname, int network_id, const char *key)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[2048];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);
	size_t key_len = strlen(key);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s SET_NETWORK %d psk ", ifname, network_id);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}

	cmd_len += ret;

	/* Double Quotes before key */
	ret = snprintf(cmd + cmd_len, sizeof(cmd) - cmd_len, "\"");
	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len += ret;

	if (key) {
		ret = snprintf(cmd + cmd_len, sizeof(cmd) - cmd_len, key, key_len);
		if (ret < 0) {
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
			return -EINVAL;
		}
		cmd_len += ret;
	}

	/* Double Quotes after key */
	ret = snprintf(cmd + cmd_len, sizeof(cmd) - cmd_len, "\"");
	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len += ret;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
	    (reply[0] == 'O') &&
	    (reply[1] == 'K')) {
		return 0;
	} else {
		return -EFAULT;
	}
}

int wpactrl_cmd_set_keymgmt(void* context, const char *ifname, int network_id, const char *keymgmt)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[2048];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0' || !keymgmt) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s SET_NETWORK %d key_mgmt %s", ifname, network_id, keymgmt);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}

	cmd_len += ret;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
		(reply[0] == 'O') &&
		(reply[1] == 'K')) {
		return 0;
	} else {
		return -EFAULT;
	}
}

int wpactrl_cmd_set_sae_pwd(void* context, const char *ifname, int network_id, const char *pwd)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[2048];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);
	size_t pwd_len = strlen(pwd);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s SET_NETWORK %d sae_password ", ifname, network_id);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len += ret;

	/* Double Quotes before pwd*/
	ret = snprintf(cmd + cmd_len, sizeof(cmd) - cmd_len, "\"");
	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len += ret;

	if (pwd) {
		ret = snprintf(cmd + cmd_len, sizeof(cmd) - cmd_len, pwd, pwd_len);
		if (ret < 0) {
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf_hex failed");
			return -EINVAL;
		}
		cmd_len += ret;
	}

	/* Double Quotes after pwd*/
	ret = snprintf(cmd + cmd_len, sizeof(cmd) - cmd_len, "\"");
	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len += ret;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
		(reply[0] == 'O') &&
		(reply[1] == 'K')) {
		return 0;
	} else {
		return -EFAULT;
	}
}

int wpactrl_cmd_set_wep_key(void* context, const char *ifname, int network_id, int key_idx, const char *key)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[2048];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);
	size_t key_len = strlen(key);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));


	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s SET_NETWORK %d wep_key%d  ", ifname, network_id, key_idx);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len += ret;

	/* Double Quotes before wep key*/
	ret = snprintf(cmd + cmd_len, sizeof(cmd) - cmd_len, "\"");
	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len += ret;

	if (key) {
		ret = snprintf_hex(cmd + cmd_len, sizeof(cmd) - cmd_len, key, key_len);
		if (ret < 0) {
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf_hex failed");
			return -EINVAL;
		}
		cmd_len += ret;
	}

	/* Double Quotes after wep key*/
	ret = snprintf(cmd + cmd_len, sizeof(cmd) - cmd_len, "\"");
	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len += ret;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
		(reply[0] == 'O') &&
		(reply[1] == 'K')) {
		return 0;
	} else {
		return -EFAULT;
	}
}

int wpactrl_cmd_save_config(void* context, const char *ifname)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[128];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}


	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s SAVE_CONFIG", ifname);
	if (ret <= 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len = ret;

	memset(reply, 0, sizeof(reply));

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
	    (reply[0] == 'O') &&
	    (reply[1] == 'K')) {
		return 0;
	} else {
		return -EFAULT;
	}
}

int wpactrl_cmd_scan_ssid(void* context, const char *ifname, int network_id, int enable)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[128];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s SET_NETWORK %d scan_ssid %d", ifname, network_id, enable);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}

	cmd_len += ret;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
		(reply[0] == 'O') &&
		(reply[1] == 'K')) {
		return 0;
	} else {
		return -EFAULT;
	}
}

int wpactrl_cmd_set_ssid(void* context, const char *ifname, const char *ssid, int network_id, int dev_type)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[128];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	if (dev_type == WPACTRL_TYPE_AP_LIB) {
		ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s SET ssid ", ifname);

		if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
		}

		cmd_len += ret;

		ret = snprintf (cmd + cmd_len, sizeof(cmd) - cmd_len, "%s", ssid);
		if (ret < 0) {
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
			return -EFAULT;
		}

		cmd_len += ret;
	}
	else if (dev_type == WPACTRL_TYPE_STA_LIB) {

		ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s SET_NETWORK %d ssid ", ifname, network_id);

		if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
		}

		cmd_len += ret;

		ret = snprintf (cmd + cmd_len, sizeof (cmd) - cmd_len, "\"");

		if (ret < 0) {
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
			return -EFAULT;
		}

		cmd_len += ret;

		ret = snprintf (cmd + cmd_len, sizeof(cmd) - cmd_len, "%s", ssid);
		if (ret < 0) {
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
			return -EFAULT;
		}

		cmd_len += ret;

		ret = snprintf (cmd + cmd_len, sizeof (cmd) - cmd_len, "\"");
		if (ret < 0) {
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
			return -EFAULT;
		}
		cmd_len += ret;
	}
/*	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}

	cmd_len += ret;*/

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
		(reply[0] == 'O') &&
		(reply[1] == 'K')) {
		return 0;
	} else {
		return -EFAULT;
	}
}

int wpactrl_cmd_set_wps_pbc(void* context, const char *ifname, int dev_type, int map_enable)
{
	int ret = 0;
	wpactrl_context_t *ctx = NULL;
	char cmd[128];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	if (dev_type == WPACTRL_TYPE_AP_LIB)
		ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s WPS_PBC", ifname);
	else if (dev_type == WPACTRL_TYPE_STA_LIB) {
		if (map_enable == 1)
			ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s WPS_PBC multi_ap=%d", ifname, map_enable);
		else
			ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s WPS_PBC", ifname);
		}

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}

	cmd_len += ret;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
		(reply[0] == 'O') &&
		(reply[1] == 'K')) {
		return 0;
	} else {
		return -EFAULT;
	}
}

int wpactrl_cmd_config_update(void* context, const char *ifname)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[128];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s UPDATE", ifname);
	if (ret <= 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len = ret;

	memset(reply, 0, sizeof(reply));

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
	    (reply[0] == 'O') &&
	    (reply[1] == 'K')) {
		return 0;
	} else {
		return -EFAULT;
	}
}

int wpactrl_cmd_reload(void* context, const char *ifname)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[128];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s RELOAD", ifname);
	if (ret <= 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len = ret;

	memset(reply, 0, sizeof(reply));

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
	    (reply[0] == 'O') &&
	    (reply[1] == 'K')) {
		return 0;
	} else {
		return -EFAULT;
	}
}


int wpactrl_cmd_disassoc_imminent(void* context,
				const char *ifname,
				const uint8_t* sta_mac,
				int disassoc_timer)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[128];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s DISASSOC_IMMINENT " MACSTR " %d",
			ifname, MAC2STR(sta_mac), disassoc_timer);
	if (ret <= 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len = ret;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if (reply_len <= 0)
		return -EFAULT;

	if (sscanf(reply, "%d", &ret) != 1) {
		return -EFAULT;
	}

	return ret;

}

int wpactrl_cmd_ess_disassoc(void* context,
				const char *ifname,
				const uint8_t* sta_mac,
				int disassoc_timer,
				const char *url,
				int url_len)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[512];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s ESS_DISASSOC " MACSTR " %d%s%s",
			ifname, MAC2STR(sta_mac), disassoc_timer, url? " ": "", url? url: "");
	if (ret <= 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len = ret;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if (reply_len <= 0)
		return -EFAULT;

	if (sscanf(reply, "%d", &ret) != 1) {
		return -EFAULT;
	}

	return ret;

}

int wpactrl_cmd_coloc_intf_req(void* context,
				const char *ifname,
				const uint8_t* sta_mac,
				unsigned int auto_report,
				unsigned int timeout)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[128];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s COLOC_INTF_REQ " MACSTR " %u %u",
			ifname, MAC2STR(sta_mac), auto_report, timeout);
	if (ret <= 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len = ret;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG,
			"cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG,
			"ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR,
				"wpa_ctrl_request failed");
		return -EFAULT;
	}

	if (reply_len <= 0)
		return -EFAULT;

	if (sscanf(reply, "%d", &ret) != 1) {
		return -EFAULT;
	}

	return ret;
}

int wpactrl_cmd_hs20_wnm_notif(void* context,
			const char *ifname,
			uint8_t* sta_mac,
			const char *url,
			int url_len)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[512];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s HS20_WNM_NOTIF " MACSTR " %s",
			ifname, MAC2STR(sta_mac), url);
	if (ret <= 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len = ret;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if (reply_len <= 0)
		return -EFAULT;

	if (sscanf(reply, "%d", &ret) != 1) {
		return -EFAULT;
	}

	return ret;
}


int wpactrl_cmd_hs20_deauth_req(void* context,
			const char *ifname,
			uint8_t* sta_mac,
			int code,
			int delay,
			const char *url,
			int url_len)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[512];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s HS20_DEAUTH_REQ " MACSTR " %d %d%s%s",
			ifname, MAC2STR(sta_mac), code, delay, url? " ": "", url? url: "");
	if (ret <= 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len = ret;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG,
			"cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if (reply_len <= 0)
		return -EFAULT;

	if (sscanf(reply, "%d", &ret) != 1) {
		return -EFAULT;
	}

	return ret;
}

int wpactrl_cmd_req_beacon(void* context, const char *ifname, uint8_t* sta_mac, uint8_t req_mode, uint8_t* req, int req_len)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[512];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0' || !req || (req_len <= 0)) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s REQ_BEACON " MACSTR " req_mode=%02x ",
			ifname, MAC2STR(sta_mac), req_mode);
	if (ret <= 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len = ret;

	ret = snprintf_hex(cmd + cmd_len, sizeof(cmd) - cmd_len,
				req, req_len);
	if (ret <= 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf_hex failed");
		return -EFAULT;
	}
	cmd_len += ret;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR,
				"wpa_ctrl_request failed");
		return -EFAULT;
	}

	if (reply_len <= 0)
		return -EFAULT;

	if (sscanf(reply, "%d", &ret) != 1) {
		return -EFAULT;
	}

	return ret;
}

int wpactrl_cmd_wps_pbc(void* context, const char *ifname)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[64];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "context is NULL");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s WPS_PBC", ifname);
	if (ret <= 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len = ret;

	memset(reply, 0, sizeof(reply));

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG,
			"cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG,
			"ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR,
				"wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
	    (reply[0] == 'O') &&
	    (reply[1] == 'K')) {
		return 0;
	} else {
		return -EFAULT;
	}
}

int wpactrl_cmd_wps_cancel(void* context, const char *ifname)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[64];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s WPS_CANCEL", ifname);
	if (ret <= 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len = ret;

	memset(reply, 0, sizeof(reply));

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG,
			"cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
	    (reply[0] == 'O') &&
	    (reply[1] == 'K')) {
		return 0;
	} else {
		return -EFAULT;
	}
}

int wpactrl_cmd_wps_pin(void* context, const char *ifname, const char* uuid,
			const char *pin, int timeout,
			uint8_t *addr)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[256];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s WPS_PIN %s %s",
			ifname, uuid? uuid: "any", pin);
	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR,
				"snprintf failed");
		return -EFAULT;
	}
	cmd_len = ret;

	if (timeout > 0) {
		ret = snprintf(cmd + cmd_len, sizeof(cmd) - cmd_len,
			" %d", timeout);
		if (ret < 0) {
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
			return -EFAULT;
		}
		cmd_len += ret;
	}

	if (addr) {
		ret = snprintf(cmd + cmd_len, sizeof(cmd) - cmd_len,
 			" " MACSTR, MAC2STR(addr));
		if (ret < 0) {
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
			return -EFAULT;
		}
		cmd_len += ret;
	}

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
	    (reply[0] == 'O') &&
	    (reply[1] == 'K')) {
		return 0;
	} else {
		return -EFAULT;
	}
}



const char *wps_config_auth_str[] = {
	"OPEN",
	"WPAPSK",
	"WPA2PSK",
};

const char *wps_config_encr_str[] = {
	"NONE",
	"TKIP",
	"CCMP",
};

int wpactrl_cmd_wps_config(void* context, const char *ifname, const char* ssid,
			wps_config_auth_t auth,
			wps_config_encr_t encr,
			const uint8_t* key,
			size_t key_len)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[256];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0' ||
	    !ssid ||
	    (auth < 0) ||
	    (encr < 0) ||
	    (auth >= WPS_CONFIG_AUTH_MAX) ||
	    (encr >= WPS_CONFIG_ENCR_MAX) ||
	    (key == NULL && (key_len > 0))) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s WPS_CONFIG %s %s %s",
			ifname, ssid, wps_config_auth_str[auth],
			wps_config_encr_str[encr]);
	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}

	cmd_len = ret;

	if (key) {
		ret = snprintf_hex(cmd + cmd_len, sizeof(cmd) - cmd_len, key, key_len);
		if (ret < 0) {
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf_hex failed");
			return -EINVAL;
		}
		cmd_len += ret;
	}

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG,
			"cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG,
			"ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
	    (reply[0] == 'O') &&
	    (reply[1] == 'K'))
		return 0;
	else
		return -EFAULT;
}

int wpactrl_cmd_set_ap_pmk(void* context,
			const char *ifname,
			const uint8_t* sta_mac, const uint8_t* pmk_id,
			const uint8_t* pmk, size_t pmk_len, int expiry,
			int akmp)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[256];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s PMKSA_ADD " MACSTR " ",
			ifname, MAC2STR(sta_mac));
	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len += ret;

	if (pmk_id) {
		ret = snprintf_hex(cmd + cmd_len, sizeof(cmd) - cmd_len, pmk_id, PMKID_LEN);
		if (ret < 0) {
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf_hex failed");
			return -EINVAL;
		}
		cmd_len += ret;
	}

	/* Space between pmkid and pmk */
	ret = snprintf(cmd + cmd_len, sizeof(cmd) - cmd_len, " ");
	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len += ret;

	if (pmk) {
		ret = snprintf_hex(cmd + cmd_len, sizeof(cmd) - cmd_len, pmk, pmk_len);
		if (ret < 0) {
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf_hex failed");
			return -EINVAL;
		}
		cmd_len += ret;
	}

	ret = snprintf(cmd + cmd_len, sizeof(cmd) - cmd_len,
			" %d %d", expiry, akmp);
	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len += ret;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
	    (reply[0] == 'O') &&
	    (reply[1] == 'K')) {
		return 0;
	} else {
		return -EFAULT;
	}
}

int wpactrl_cmd_set_sta_pmk(void* context,
			const char *ifname,
			uint8_t nw_id, const uint8_t* bssid,
			const uint8_t* pmk_id, const uint8_t* pmk,
			size_t pmk_len, int reauth,
			int expiry, int akmp,
			int opportunistic)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[256];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s PMKSA_ADD %d " MACSTR " ",
			ifname, (int) nw_id, MAC2STR(bssid));
	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len += ret;

	if (pmk_id) {
		ret = snprintf_hex(cmd + cmd_len, sizeof(cmd) - cmd_len, pmk_id, PMKID_LEN);
		if (ret < 0) {
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf_hex failed");
			return -EINVAL;
		}
		cmd_len += ret;
	}

	/* Space between pmkid and pmk */
	ret = snprintf(cmd + cmd_len, sizeof(cmd) - cmd_len, " ");
	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len += ret;

	if (pmk) {
		ret = snprintf_hex(cmd + cmd_len, sizeof(cmd) - cmd_len, pmk, pmk_len);
		if (ret < 0) {
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf_hex failed");
			return -EINVAL;
		}
		cmd_len += ret;
	}

	ret = snprintf(cmd + cmd_len, sizeof(cmd) - cmd_len,
			" %d %d %d %d", reauth, expiry, akmp, opportunistic);
	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len += ret;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
	    (reply[0] == 'O') &&
	    (reply[1] == 'K')) {
		return 0;
	} else {
		return -EFAULT;
	}
}

int wpactrl_cmd_set_network_pairwise(void* context, const char *ifname, int network_id, const char *pairwise)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[2048];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0' || !pairwise) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s SET_NETWORK %d pairwise %s", ifname, network_id, pairwise);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}

	cmd_len += ret;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
		(reply[0] == 'O') &&
		(reply[1] == 'K')) {
		return 0;
	} else {
		return -EFAULT;
	}
}


int wpactrl_cmd_set_network_group(void* context, const char *ifname, int network_id, const char *group)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[2048];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0' || !group) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s SET_NETWORK %d group %s", ifname, network_id, group);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}

	cmd_len += ret;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
		(reply[0] == 'O') &&
		(reply[1] == 'K')) {
		return 0;
	} else {
		return -EFAULT;
	}
}

int wpactrl_cmd_set_network_grpmgmt(void* context, const char *ifname, int network_id, const char *grpmgmt)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[2048];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0' || !grpmgmt) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s SET_NETWORK %d group_mgmt %s", ifname, network_id, grpmgmt);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}

	cmd_len += ret;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
		(reply[0] == 'O') &&
		(reply[1] == 'K')) {
		return 0;
	} else {
		return -EFAULT;
	}
}

int wpactrl_cmd_set_bcn_prot(void* context, const char *ifname, int network_id, uint8_t beacon_prot)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[2048];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s SET_NETWORK %d beacon_prot %d", ifname, network_id, beacon_prot);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}

	cmd_len += ret;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
		(reply[0] == 'O') &&
		(reply[1] == 'K')) {
		return 0;
	} else {
		return -EFAULT;
	}
}

int wpactrl_cmd_set_dpp_uri(void* context,
			const char *ifname,
			const uint8_t* dpp_uri,
			size_t dpp_uri_len)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[256];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s WPS_DPP_URI uri_len=%ld ", ifname, dpp_uri_len);
	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len += ret;

	if (dpp_uri && (dpp_uri_len != 0)) {
		ret = snprintf_hex(cmd + cmd_len, sizeof(cmd) - cmd_len, dpp_uri, dpp_uri_len);
		if (ret < 0) {
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
			return -EINVAL;
		}
		cmd_len += ret;
	}

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
	    (reply[0] == 'O') &&
	    (reply[1] == 'K')) {
		return 0;
	} else {
		return -EFAULT;
	}
}

int wpactrl_cmd_set_map_sec(void* context,
			const char *ifname,
			uint8_t map_sec_enable)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[256];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s WPS_MAP_SEC %d", ifname, map_sec_enable);
	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len += ret;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
	    (reply[0] == 'O') &&
	    (reply[1] == 'K')) {
		return 0;
	} else {
		return -EFAULT;
	}
}

int wpactrl_cmd_update_bridge_supplicant(void* context,
			const char *ifname,
			uint8_t bridge_flag,
			const char *br_name)
{
#ifdef WPACTRL_SUPPORT_MTK_EXTENSION
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[256];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);
	char bridge_name[16] = "";

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	if (bridge_flag == 1) {
		memset(bridge_name, 0, sizeof(bridge_name));
		memcpy(bridge_name, br_name, strlen(br_name));
	}
	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s UPDATE_BRIDGE %s", ifname, bridge_name);
	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len += ret;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
	    (reply[0] == 'O') &&
	    (reply[1] == 'K')) {
		return 0;
	} else {
		return -EFAULT;
	}
#else
	return 0;
#endif /* WPACTRL_SUPPORT_MTK_EXTENSION */
}

int wpactrl_iface_fd_get(void* context)
{
	int ret;
	wpactrl_context_t *ctx = NULL;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	return wpa_ctrl_get_fd(ctx->wpa_ptr);
}


int
wpactrl_iface_open(void** context,
		wpactrl_type_t type,
		const char *iface,
		const char *ctrl_path,
		void *cb_ctx,
		wpactrl_cbs_t *cbs,
		int flag)
{
	int ret;
	wpactrl_context_t *ctx = NULL;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context ||
		!iface ||
		!cbs ||
		(type < 0) || (type >= WPACTRL_TYPE_MAX)) { /* invalid input parameters */
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		ret = -EINVAL;
		goto error;
	}

	if (strlen(iface) <= 0) { /* invalid interface name */
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		ret = -EINVAL;
		goto error;
	}

	ctx = malloc(sizeof(*ctx));
	if (!ctx) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "malloc failed");
		ret = -ENOMEM;
		goto error;
	}

	ret = snprintf(ctx->iface, sizeof(ctx->iface), "%s", iface);
	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		ret = -EFAULT;
		goto error;
	}

	if (ctrl_path && (ctrl_path[0] != '\0')) {
		int ctrl_path_len = strlen(ctrl_path);

		if (ctrl_path[ctrl_path_len - 1] != '/') {
			ret = snprintf(ctx->full_ctrl_path,
					sizeof(ctx->full_ctrl_path),
					"%s/%s", ctrl_path, iface);
		} else {
			ret = snprintf(ctx->full_ctrl_path,
					sizeof(ctx->full_ctrl_path),
					"%s%s", ctrl_path, iface);
		}
	} else {
		ret = snprintf(ctx->full_ctrl_path,
				sizeof(ctx->full_ctrl_path),
				"%s%s", default_hostap_ctrl_path, iface);
	}
	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		ret = -EFAULT;
		goto error;
	}

	if (access(ctx->full_ctrl_path, F_OK) != 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "access failed");
		ret = -ENOENT;
		goto error;
	}

	ctx->wpa_ptr = wpa_ctrl_open(ctx->full_ctrl_path);
	if (!ctx->wpa_ptr) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_open failed");
		ret = -EFAULT;
		goto error;
	}

	if (flag & 0x01) {
		if (wpa_ctrl_attach(ctx->wpa_ptr) != 0) {
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_attach failed");
			ret = -EFAULT;
			goto error2;
		}
	}

	ctx->fd = wpa_ctrl_get_fd(ctx->wpa_ptr);
	if (ctx->fd < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_get_fd failed");
		ret = -EFAULT;
		goto error3;
	}

	ctx->type = type;
	ctx->cb_ctx = cb_ctx;
	if (cbs)
		ctx->cbs = cbs;

	(*context) = ctx;

	return 0;
error3:
	wpa_ctrl_detach(ctx->wpa_ptr);
error2:
	wpa_ctrl_close(ctx->wpa_ptr);
error:
	if (ctx) {
		free(ctx);
	}

	return ret;
}

void wpactrl_iface_close(void* context)
{
	int ret = 0;
	wpactrl_context_t *ctx = NULL;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return;
	}

	ctx = context;

	if (!ctx->wpa_ptr) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		goto error;
	}

	if (wpa_ctrl_detach(ctx->wpa_ptr) != 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_detach failed");
		goto error;
	}

error:
	if (ctx) {
		if (ctx->wpa_ptr)
			wpa_ctrl_close(ctx->wpa_ptr);
		free(ctx);
	}
}
int wpactrl_cmd_hide_ssid(void* context, const char *ifname, int enable)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[2048];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s ignore_broadcast_ssid %d", ifname, enable);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}

	cmd_len += ret;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
	    (reply[0] == 'O') &&
	    (reply[1] == 'K')) {
		return 0;
	} else {
		return -EFAULT;
	}
}

int wpactrl_cmd_set_psk(void* context, const char *ifname, const char *psk, int dev_type)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[2048];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	if (dev_type == WPACTRL_TYPE_AP_LIB) {
		ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s SET wpa_passphrase ", ifname);

		if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
		}

		cmd_len += ret;

		ret = snprintf (cmd + cmd_len, sizeof(cmd) - cmd_len, "%s", psk);
		if (ret < 0) {
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
			return -EFAULT;
		}

		cmd_len += ret;
	}

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
		(reply[0] == 'O') &&
		(reply[1] == 'K')) {
		return 0;
	} else {
		return -EFAULT;
	}
}

int wpactrl_cmd_acl_set_policy(void *context, const char *ifname, int policy)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[2048];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}
	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s SET macaddr_acl %d", ifname, policy);
	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len += ret;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);
	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}
	if ((reply_len == 3) &&
		(reply[0] == 'O') &&
		(reply[1] == 'K')) {
		return 0;
	} else {
		return -EFAULT;
	}
}


int wpactrl_cmd_acl_accept_add_mac(void *context, const char *ifname, unsigned char *mac)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[2048];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}
	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s ACCEPT_ACL ADD_MAC %02x:%02x:%02x:%02x:%02x:%02x",
		ifname, PRINT_MAC(mac));
	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len += ret;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "cmd:(%d)%s", cmd_len, cmd);
	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);
	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "ret:%d reply:(%d)%s", ret, reply_len, reply);
	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}
	if ((reply_len == 3) &&
		(reply[0] == 'O') &&
		(reply[1] == 'K')) {
		return 0;
	} else {
		return -EFAULT;
	}
}

int wpactrl_cmd_acl_accept_del_mac(void *context, const char *ifname, unsigned char *mac)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[2048];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}
	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));


	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s ACCEPT_ACL DEL_MAC %02x:%02x:%02x:%02x:%02x:%02x",
		ifname, PRINT_MAC(mac));
	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len += ret;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
		(reply[0] == 'O') &&
		(reply[1] == 'K')) {
		return 0;
	} else {
		return -EFAULT;
	}
}

int wpactrl_cmd_acl_accept_clear_mac(void *context, const char *ifname)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[2048];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}
	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s ACCEPT_ACL CLEAR", ifname);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}

	cmd_len += ret;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
		(reply[0] == 'O') &&
		(reply[1] == 'K')) {
		return 0;
	} else {
		return -EFAULT;
	}
}

int wpactrl_cmd_acl_accept_show_mac(void *context, const char *ifname)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[2048] = { 0 };
	int cmd_len = 0;
	char reply[512];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}
	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s ACCEPT_ACL SHOW", ifname);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}

	cmd_len += ret;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "ret:%d reply_len(%d),accept mac list:\n%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	return 0;
}


int wpactrl_cmd_acl_deny_add_mac(void *context, const char *ifname, unsigned char *mac)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[2048];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}
	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s DENY_ACL ADD_MAC %02x:%02x:%02x:%02x:%02x:%02x",
		ifname, PRINT_MAC(mac));

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len += ret;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
		(reply[0] == 'O') &&
		(reply[1] == 'K')) {
		return 0;
	} else {
		return -EFAULT;
	}
}

int wpactrl_cmd_acl_deny_del_mac(void *context, const char *ifname, unsigned char *mac)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[2048];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}
	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s DENY_ACL DEL_MAC %02x:%02x:%02x:%02x:%02x:%02x",
		ifname, PRINT_MAC(mac));

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}

	cmd_len += ret;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
		(reply[0] == 'O') &&
		(reply[1] == 'K')) {
		return 0;
	} else {
		return -EFAULT;
	}
}

int wpactrl_cmd_acl_deny_clear_mac(void *context, const char *ifname)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[2048];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}
	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s DENY_ACL CLEAR", ifname);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}

	cmd_len += ret;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
		(reply[0] == 'O') &&
		(reply[1] == 'K')) {
		return 0;
	} else {
		return -EFAULT;
	}
}
int wpactrl_cmd_acl_deny_show_mac(void *context, const char *ifname)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[2048] = { 0 };
	int cmd_len = 0;
	char reply[512];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}
	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s DENY_ACL SHOW", ifname);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}

	cmd_len += ret;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "ret:%d reply_len(%d), deny mac list:\n%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	return 0;
}

int wpactrl_cmd_set_channel_switch(void *context,
	char *ifname,
	unsigned char cs_count, unsigned int freq,
	unsigned int bw, unsigned int center_freq1,
	int sec_channel_offset, unsigned int skip_cac)
{
	int ret = 0;
	wpactrl_context_t *ctx = NULL;
	char cmd[512] = {0};
	int cmd_len = 0;
	char reply[16] ={0};
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}
	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s CHAN_SWITCH %d %d sec_channel_offset=%d center_freq1=%d bandwidth=%d auto-ht",
			ifname, cs_count, freq, sec_channel_offset, center_freq1, bw);
	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len += ret;
	if (skip_cac) {
		ret = snprintf(cmd + cmd_len, sizeof(cmd) - cmd_len, " skip_cac");
		if (ret < 0) {
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
			return -EFAULT;
		}
		cmd_len += ret;
	}
	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);
	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
	    (reply[0] == 'O') &&
	    (reply[1] == 'K'))
		return 0;
	else
		return -EFAULT;
}

int wpactrl_cmd_zero_wait_cac(void *context,
	char *ifname,
	unsigned char ch, unsigned char bw)
{
	int ret = 0;
	wpactrl_context_t *ctx = NULL;
	char cmd[256] = {0};
	int cmd_len = 0;
	char reply[16] = {0};
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}
	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s SET_OFFCHAN_CTRL chan=%d",ifname, ch);
	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len += ret;
	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);
	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);
	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
	    (reply[0] == 'O') &&
	    (reply[1] == 'K'))
		return 0;
	else
		return -EFAULT;
}

int wpactrl_cmd_set_dfs_detect_mode(void *context, const char *ifname, int mode)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[2048];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}
	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s SET dfs_detect_mode %d", ifname, mode);
	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len += ret;
	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);
	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
	    (reply[0] == 'O') &&
	    (reply[1] == 'K'))
		return 0;
	else
		return -EFAULT;
}

int wpactrl_cmd_get_probe_info(void* context, const char *ifname, uint8_t *reply_buf)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[2048];
	int cmd_len = 0;
	char reply[2048];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s TRACK_STA_LIST", ifname);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}

	cmd_len += ret;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if (reply_len <= 0 || reply_len > 2048) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "reply len failed");
		return -EFAULT;
	}

	if ((reply_len == 5) &&
		(reply[0] == 'F') &&
		(reply[1] == 'A') &&
		(reply[2] == 'I') &&
		(reply[3] == 'L')) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "reply len failed");
		return -EFAULT;
	}
	if (reply_len > 0) {
		/* reply buf will be used in wapp to fill unassociated sta info */
		memset(reply_buf, 0, reply_len);
		memcpy(reply_buf, reply, reply_len);
	}

	return ret;
}

int wpactrl_cmd_set_autoscan_module(void* context,
		const char *ifname,
		wpactrl_autoscan_module_t module,
		const uint16_t param1,
		const uint16_t param2)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[2048];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}
	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	switch (module) {
	case WPACTRL_AUTOSCAN_NULL:
		ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s AUTOSCAN ", ifname);
		if (ret < 0) {
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
			return -EFAULT;
		}
		cmd_len = ret;
		break;
	case WPACTRL_AUTOSCAN_EXPONENTIAL:
		ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s AUTOSCAN exponential:%u:%u", ifname, param1, param2);
		if (ret < 0) {
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
			return -EFAULT;
		}
		cmd_len = ret;
		break;
	case WPACTRL_AUTOSCAN_PERIODIC:
		ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s AUTOSCAN periodic:%u", ifname, param1);
		if (ret < 0) {
			WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
			return -EFAULT;
		}
		cmd_len = ret;
		break;
	default:
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid module");
		return -EFAULT;
	}

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);
	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
	    (reply[0] == 'O') &&
	    (reply[1] == 'K'))
		return 0;
	else
		return -EFAULT;
}

int wpactrl_cmd_disconnect(void* context, const char *ifname)
{
	int ret;
	wpactrl_context_t *ctx = NULL;
	char cmd[2048];
	int cmd_len = 0;
	char reply[16];
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || *ifname == '\0') {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}
	memset(cmd, 0, sizeof(cmd));
	memset(reply, 0, sizeof(reply));

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s DISCONNECT", ifname);
	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len = ret;

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
				cmd,
				cmd_len,
				reply,
				&reply_len,
				NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "ret:%d reply:(%d)%s", ret, reply_len, reply);
	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}

	if ((reply_len == 3) &&
	    (reply[0] == 'O') &&
	    (reply[1] == 'K'))
		return 0;
	else
		return -EFAULT;
}

int wpactrl_cmd_get_usr_prefer_freqlist(void *context, const char *ifname, char *freq_list_str,
	size_t freq_list_len)
{
	wpactrl_context_t *ctx = NULL;
	int ret = 0, cmd_len = 0;
	char cmd[128] = {0};
	char reply[512] = {0};
	size_t reply_len = sizeof(reply);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_DEBUG, "trace");

	if (!context || !ifname || !freq_list_str) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "invalid args");
		return -EINVAL;
	}

	ctx = context;
	if (ctx->wpa_ptr == NULL) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpactrl is not attached");
		return -EFAULT;
	}

	ret = snprintf(cmd, sizeof(cmd), "IFNAME=%s GET_USR_PREFER_FREQLIST", ifname);
	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "snprintf failed");
		return -EFAULT;
	}
	cmd_len += ret;
	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "cmd:(%d)%s", cmd_len, cmd);

	ret = wpa_ctrl_request(ctx->wpa_ptr,
	                        cmd,
	                        cmd_len,
	                        reply,
	                        &reply_len,
	                        NULL);

	WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "ret:%d reply:(%d)%s", ret, reply_len, reply);

	if (ret < 0) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "wpa_ctrl_request failed");
		return -EFAULT;
	}
	if ((reply_len == 5) &&
		(memcmp(reply, "FAIL", 4) == 0)) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "reply len failed");
		return -EFAULT;
	}
	if ((reply_len == 16) &&
		(memcmp(reply, "UNKNOWN COMMAND", 15) == 0)) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "UNKNOWN COMMAND");
		return -EFAULT;
	}

	if (reply_len > freq_list_len) {
		WPACTRL_DBGPRINTF(WPACTRL_DBGLVL_ERROR, "reply_len(%u) > freq_list_len(%u)", reply_len, freq_list_len);
		return -EFAULT;
	}

	memcpy(freq_list_str, reply, reply_len);

	return 0;
}

