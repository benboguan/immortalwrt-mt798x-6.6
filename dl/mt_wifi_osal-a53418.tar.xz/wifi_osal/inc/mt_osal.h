/* SPDX-License-Identifier: GPL-2.0 OR BSD-3-Clause */
/* Copyright (C) 2024 MediaTek Inc. */


#ifndef __MT_WIFI_OSAL_H_
#define __MT_WIFI_OSAL_H_

#include <linux/scatterlist.h>
#include <linux/ieee80211.h>
#include <crypto/aead.h>

#include <linux/version.h>
#include <linux/rcupdate.h>
#include <linux/timekeeping.h>
#include <net/cfg80211.h>
#include <linux/debugfs.h>
#include <linux/idr.h>
#include <linux/device.h>
#include <linux/firmware.h>
#include <linux/cpu.h>
#include <linux/cpumask.h>
#include <linux/kallsyms.h>
#include <linux/pci.h>

#include "mt_osal_type.h"
#include "mt_osal_debug.h"
#include "mt_osal_mem.h"
#include "mt_osal_dts_emi.h"
#include "mt_osal_util.h"
#include "mt_osal_ipc.h"
#include "mt_osal_lock.h"
#include "mt_osal_timer.h"
#include "mt_osal_task.h"
#include "mt_osal_net.h"
#include "mt_osal_crypto.h"
#include "mt_osal_fs.h"
#include "mt_osal_wifi.h"
#include "mt_osal_bus.h"
#include "mt_osal_system.h"
#include "mt_osal_packet.h"
#include "mt_osal_iw_ext.h"
#include "mt_osal_cfg80211.h"
#include "mt_osal_cfg80211_vndr.h"
#include "mt_osal_cfg80211_event.h"
#include "mt_osal_csi.h"
#include "mt_osal_proc.h"
#include "mt_osal_genl.h"

#endif /* __MT_WIFI_OSAL_H_ */
