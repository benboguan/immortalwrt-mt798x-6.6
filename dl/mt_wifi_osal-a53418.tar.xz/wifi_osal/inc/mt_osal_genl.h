/* SPDX-License-Identifier: GPL-2.0 OR BSD-3-Clause */
/* Copyright (C) 2024 MediaTek Inc. */


#ifndef __MT_OSAL_GENL_H_
#define __MT_OSAL_GENL_H_

#include <linux/netlink.h>
#include <net/genetlink.h>

enum mt_cmm_genl_attr {
	MT_CMM_GENL_ATTR_UNSPEC = 0,
	MT_CMM_GENL_ATTR_FIPS_140_3_TC,
	MT_CMM_GENL_ATTR_FIPS_140_3_TR,
	MT_CMM_GENL_ATTR_FIPS_140_3_COMM_MSG,
	__MT_CMM_GENL_ATTR_MAX,
};

enum mt_cmm_genl_ops {
	MT_CMM_GENL_OPS_UNSPEC = 0,
	MT_CMM_GENL_OPS_FIPS_140_3_DAEMON_TO_DRV,
	MT_CMM_GENL_OPS_FIPS_140_3_DRV_TO_DAEMON,
	__MT_CMM_GENL_OPS_MAX,
};


#define MT_CMM_GENL_ATTR_MAX (__MT_CMM_GENL_ATTR_MAX - 1)

#define MT_CMM_GENL_NAME "mt_cmm_genl"

/* ================= FIPS 140-3 Begin ================= */
#define MT_MAX_FIPS_140_3_PKT_LEN 1500

struct mt_cmm_genl_ctrl {
	unsigned char *data;
	unsigned int data_len;
	void *info;
	unsigned int attr;
};

int mt_cmm_genl_recv_doit(struct sk_buff *skb_temp, struct genl_info *info);
int mt_fips_140_3_send_reply(int attrtype, struct mt_cmm_genl_ctrl *ctrl_data_rsp);
/* ====================== FIPS 140-3 END ======================*/

int mtk_cmm_genl_register(void);
int mtk_cmm_genl_unregister(void);

#endif /* __MT_OSAL_GENL_H_ */
