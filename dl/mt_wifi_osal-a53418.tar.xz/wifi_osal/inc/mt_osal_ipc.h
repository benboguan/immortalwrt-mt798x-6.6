/* SPDX-License-Identifier: GPL-2.0 OR BSD-3-Clause */
/* Copyright (C) 2024 MediaTek Inc. */

#ifndef __MT_OSAL_IPC_H_
#define __MT_OSAL_IPC_H_

#endif /* __MT_OSAL_IPC_H_ */
