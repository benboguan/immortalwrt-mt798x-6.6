/* SPDX-License-Identifier: GPL-2.0 OR BSD-3-Clause */
/* Copyright (C) 2024 MediaTek Inc. */


#ifndef __MT_LINUX_H_
#define __MT_LINUX_H_

#include "mt_osal.h"

#endif /* __MT_LINUX_H_ */
