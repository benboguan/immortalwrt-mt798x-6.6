/* SPDX-License-Identifier: GPL-2.0 OR BSD-3-Clause */
/* Copyright (C) 2024 MediaTek Inc. */
#include <linux/version.h>
#include <linux/netdevice.h>
#include <linux/types.h>
#include <linux/proc_fs.h>
#include <asm/unaligned.h>

#define SUBMODULE "mt_osal_genl"
#include <mt_osal_debug.h>
#include <mt_osal_net.h>
#include <mt_osal_wifi.h>
#include <mt_osal_proc.h>
#include <mt_osal_module.h>
#include <mt_osal_genl.h>

/* fips 140_3 policy */
static struct nla_policy mt_cmm_genl_policy[MT_CMM_GENL_ATTR_MAX + 1] = {
	[MT_CMM_GENL_ATTR_FIPS_140_3_TC] = { .type = NLA_BINARY,
		.len = MT_MAX_FIPS_140_3_PKT_LEN },
	[MT_CMM_GENL_ATTR_FIPS_140_3_TR] = { .type = NLA_BINARY,
		.len = MT_MAX_FIPS_140_3_PKT_LEN },
	[MT_CMM_GENL_ATTR_FIPS_140_3_COMM_MSG] = { .type = NLA_BINARY,
		.len = MT_MAX_FIPS_140_3_PKT_LEN },
};

/* fips 140_3 ops init */
static struct genl_ops mt_cmm_genl_ops[] = {
	{
		.cmd = MT_CMM_GENL_OPS_FIPS_140_3_DAEMON_TO_DRV,
		.flags = GENL_ADMIN_PERM,
#if KERNEL_VERSION(5, 2, 0) > LINUX_VERSION_CODE
		.policy = mt_cmm_genl_policy,
#endif
		.doit = mt_cmm_genl_recv_doit,
		.dumpit = NULL,
	}
};

/* fips 140_3 family */
static struct genl_family fips_140_3_genl_family = {
#if KERNEL_VERSION(4, 9, 300) >= LINUX_VERSION_CODE
	.id = GENL_ID_GENERATE,
#endif
#if KERNEL_VERSION(5, 2, 0) <= LINUX_VERSION_CODE
	.policy = mt_cmm_genl_policy,
#endif
	.hdrsize = 0,
	.name = MT_CMM_GENL_NAME,
	.version = 1,
	.netnsok = true,
	.maxattr = MT_CMM_GENL_ATTR_MAX,
#if KERNEL_VERSION(4, 10, 0) <= LINUX_VERSION_CODE
	.ops = mt_cmm_genl_ops,
	.n_ops = ARRAY_SIZE(mt_cmm_genl_ops),
	.module = THIS_MODULE,
#endif
};


int mt_cmm_genl_recv_doit(struct sk_buff *skb_temp, struct genl_info *info)
{
	struct nlattr *na = NULL;
	struct net_device *dev = NULL;
	struct mt_net_dev_priv *net_priv_info = NULL;
	struct mt_cmm_genl_ctrl ctrl_data, *ctrl_data_ptr = &ctrl_data;
	struct mt_os_wifi_ioctl_cmd_cfg IoctlConfig, *pIoctlConfig = &IoctlConfig;
	unsigned int attr_tmp;
	int ret;

	if (!info || !skb_temp) {
		MT_DEBUG_ERROR("genl_info or skb null!\n");
		return -EINVAL;
	}

	if (info->attrs[MT_CMM_GENL_ATTR_FIPS_140_3_TC]) {
		na = info->attrs[MT_CMM_GENL_ATTR_FIPS_140_3_TC];
		attr_tmp = MT_CMM_GENL_ATTR_FIPS_140_3_TC;
	} else if (info->attrs[MT_CMM_GENL_ATTR_FIPS_140_3_TR]) {
		na = info->attrs[MT_CMM_GENL_ATTR_FIPS_140_3_TR];
		attr_tmp = MT_CMM_GENL_ATTR_FIPS_140_3_TR;
	} else if (info->attrs[MT_CMM_GENL_ATTR_FIPS_140_3_COMM_MSG]) {
		na = info->attrs[MT_CMM_GENL_ATTR_FIPS_140_3_COMM_MSG];
		attr_tmp = MT_CMM_GENL_ATTR_FIPS_140_3_COMM_MSG;
	} else {
		MT_DEBUG_ERROR("invalid attribute\n");
		return -EINVAL;
	}

#if KERNEL_VERSION(4, 12, 0) <= LINUX_VERSION_CODE
	if (nla_validate(na, na->nla_len, MT_CMM_GENL_ATTR_MAX, mt_cmm_genl_policy, NULL))
#else
	if (nla_validate(na, na->nla_len, MT_CMM_GENL_ATTR_MAX, mt_cmm_genl_policy))
#endif
	{
		MT_DEBUG_ERROR("nla_validate fail!!!\n");
		return -EINVAL;
	}

	ctrl_data_ptr->data = (unsigned char *) nla_data(na);
	ctrl_data_ptr->data_len = (unsigned short) nla_len(na);
	ctrl_data_ptr->info = (void *) info;
	ctrl_data_ptr->attr = attr_tmp;

	dev = dev_get_by_name(genl_info_net(info), "ra0");

	if (!dev) {
		MT_DEBUG_ERROR("genl_rev not find net_dev ra0\n");
		return -EFAULT;
	}

	net_priv_info = (struct mt_net_dev_priv *)netdev_priv((struct net_device *)dev);
	if (!net_priv_info) {
		MT_DEBUG_ERROR("!net_priv_info\n");
		return -ENETDOWN;
	}
	if (!net_priv_info->ioctl) {
		MT_DEBUG_ERROR("!net_priv_info->ioctl\n");
		return -ENETDOWN;
	}

	pIoctlConfig->net_dev = dev;
	pIoctlConfig->priv_flags = mt_os_net_dev_get_priv_flags(dev);
	pIoctlConfig->cmd = MT_IO_CMM_GENL;
	pIoctlConfig->data = ctrl_data_ptr;
	ret = net_priv_info->ioctl(dev, pIoctlConfig);

	return 0;
}

int mt_fips_140_3_send_reply(int attr_type, struct mt_cmm_genl_ctrl *ctrl_data_rsp)
{
	struct sk_buff *skb = NULL;
	void *msg_rsp = NULL;
	struct genl_info *info = (struct genl_info *) ctrl_data_rsp->info;

	skb = genlmsg_new(nla_total_size(ctrl_data_rsp->data_len), GFP_KERNEL);

	if (!skb) {
		MT_DEBUG_ERROR("csi skb alloc fail!!!\n");
		return -ENOMEM;
	}

	msg_rsp = genlmsg_put(skb, info->snd_portid, info->snd_seq,
			&fips_140_3_genl_family, 0, MT_CMM_GENL_OPS_FIPS_140_3_DRV_TO_DAEMON);

	if (!msg_rsp) {
		MT_DEBUG_ERROR("FIPS 140-3 genl header alloc fail!!!\n");
		nlmsg_free(skb);
		return -1;
	}

	if (nla_put(skb, attr_type, ctrl_data_rsp->data_len, ctrl_data_rsp->data)) {
		MT_DEBUG_ERROR("nla_put_attr fail!!!\n");
		nlmsg_free(skb);
		return -1;
	}

	genlmsg_end(skb, msg_rsp);

	if (genlmsg_reply(skb, info)) {
		MT_DEBUG_ERROR("genl reply status fail!!!\n");
		return -1;
	}

	return 0;
}
EXPORT_SYMBOL(mt_fips_140_3_send_reply);

int mtk_cmm_genl_register(void)
{
	int ret;
#if KERNEL_VERSION(4, 10, 0) <= LINUX_VERSION_CODE
	ret = genl_register_family(&fips_140_3_genl_family);
#else
	ret = genl_register_family_with_ops(&fips_140_3_genl_family, mt_cmm_genl_ops);
#endif
	if (ret < 0) {
		MT_DEBUG_ERROR("failed to register FIPS 140-3 genl family (ret=%d)!!!\n", ret);
		return ret;
	}

	MT_DEBUG_ERROR("register FIPS 140-3 genl family (ret=%d, family_id=%d)!!!\n",
		ret, fips_140_3_genl_family.id);

	return ret;
}

int mtk_cmm_genl_unregister(void)
{
	int ret;

	ret = genl_unregister_family(&fips_140_3_genl_family);

	if (ret < 0) {
		MT_DEBUG_ERROR("failed to unregister FIPS 140-3 genl family(ret=%d)!!!\n", ret);
		return ret;
	}

	MT_DEBUG_ERROR("unregister FIPS 140-3 genl family(ret=%d)!!!\n", ret);

	return ret;
}

DECLARE_SUB_MODULE_INIT(mt_osal_genl_init)
{
	MT_DEBUG_TRACE("loaded");
	mtk_cmm_genl_register();

	return 0;
}
sub_module_init(mt_osal_genl_init);

DECLARE_SUB_MODULE_EXIT(mt_osal_genl_exit)
{
	MT_DEBUG_TRACE("unloaded");
	mtk_cmm_genl_unregister();
}
sub_module_exit(mt_osal_genl_exit);
