#ifndef _PKT_QUEUE_H_
#define _PKT_QUEUE_H_

#define DOWNTREAM 0x1
#define UPTREAM 0x2
#define QUEUE 0x1
#define DEQUEUE 0x0
#define PRE_ROUNTING 0x1
#define LOCAL_OUT 0x2


struct queue_info {
	unsigned char mac[ETH_ALEN];
	unsigned char action;
	unsigned char direction;
};

struct skb_db {
	struct hlist_node hlist;
	struct sk_buff *skb;
	struct net_device *indev;
	unsigned char state;
};


struct pkt_queue_db {
	struct hlist_node hlist;
	struct rcu_head rcu;
	struct queue_info info;
	spinlock_t skb_lock;
	struct hlist_head skb_list;
	unsigned int skb_cnt;
};

struct cli_context {
	struct hlist_head client_head;
	spinlock_t hash_lock;
};

struct pkt_queue {
	unsigned char enable;
	struct kobject *obj;
	struct cli_context clients[HASH_TABLE_SIZE];
};

void pkt_queue_init(struct kobject *parent_obj);
void pkt_queue_deinit(void);
int handle_client_pkt_queue(struct queue_info *info);

#endif
