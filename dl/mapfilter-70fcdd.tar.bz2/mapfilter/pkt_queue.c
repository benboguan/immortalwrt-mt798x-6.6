#include <linux/skbuff.h>
#include <linux/netdevice.h>
#include <linux/if_bridge.h>
#include <linux/etherdevice.h>
#include <net/route.h>
#include <net/ip.h>
#include <../net/bridge/br_private.h>
#include "mtkmapfilter.h"
#include "debug.h"
#include "pkt_queue.h"

struct pkt_queue pkt_q;

struct pkt_queue_db *get_pkt_queue_db(unsigned char mac[])
{
	struct pkt_queue_db *client = NULL;
	unsigned char hash_idx = MAC_ADDR_HASH_INDEX(mac);
	struct hlist_head *head = &pkt_q.clients[hash_idx].client_head;

	hlist_for_each_entry_rcu(client, head, hlist) {
		if (!memcmp(client->info.mac, mac, ETH_ALEN))
			break;
	}

	return client;
}

struct pkt_queue_db *create_pkt_queue_db(struct queue_info *info)
{
	struct pkt_queue_db *client = NULL;

	client = kmalloc(sizeof(struct pkt_queue_db), GFP_ATOMIC);
	if (client) {
		memset(client, 0, sizeof(struct pkt_queue_db));
		INIT_HLIST_NODE(&client->hlist);
		memcpy(&client->info, info, sizeof(*info));
		spin_lock_init(&client->skb_lock);
		INIT_HLIST_HEAD(&client->skb_list);
		client->skb_cnt = 0;
	}

	return client;
}

static void free_pkt_queue_db(struct rcu_head *head)
{
	struct pkt_queue_db *client = container_of(head, struct pkt_queue_db, rcu);

	pr_info("%s rcu %p,%p\n", __func__, head, client);
	kfree(client);
}


int update_pkt_queue_db(struct queue_info *info)
{
	struct pkt_queue_db *client = NULL, *client_new = NULL;
	int ret = 0;
	unsigned char free = 1;
	unsigned char hash_idx = MAC_ADDR_HASH_INDEX(info->mac);
	struct hlist_head *head = &pkt_q.clients[hash_idx].client_head;

	rcu_read_lock();
	client = get_pkt_queue_db(info->mac);
	if (!client)
		goto end;

	if (client->info.action == info->action)
		goto end;
	rcu_read_unlock();

	if (info->action == QUEUE) {
		client_new = create_pkt_queue_db(info);
		if (!client_new)
			goto end1;
		spin_lock_bh(&pkt_q.clients[hash_idx].hash_lock);
		hlist_for_each_entry_rcu(client, head, hlist) {
			if (!memcmp(client->info.mac, info->mac, ETH_ALEN)) {
				hlist_replace_rcu(&client->hlist, &client_new->hlist);
				free = 0;
				call_rcu(&client->rcu, free_pkt_queue_db);
			}
		}
		spin_unlock_bh(&pkt_q.clients[hash_idx].hash_lock);
		if (free)
			kfree(client_new);
	}

end:
	rcu_read_unlock();
end1:
	return ret;
}


int handle_client_pkt_queue(struct queue_info *info)
{
#if (KERNEL_VERSION(5, 0, 0) < LINUX_VERSION_CODE)
	struct pkt_queue_db *client = NULL;
	unsigned char hash_idx = MAC_ADDR_HASH_INDEX(info->mac);
	struct cli_context *client_head = NULL;
	struct hlist_node *n = NULL;
	struct skb_db *db = NULL;
	struct net_device *dev = NULL;
	struct net_bridge_port *p = NULL;
	unsigned char found = 0;
	unsigned char seq1 = 0, seq2 = 0;

	if (info->direction != DOWNTREAM) {
		pr_err("%s-%d not downstream; do not handle", __func__, __LINE__);
		return -1;
	}

	client_head = &pkt_q.clients[hash_idx];
	if (info->action == QUEUE) {
		pr_err("%s need queue pkt for "MAC2STR"\n",
			__func__, PRINT_MAC(info->mac));
		rcu_read_lock();
		client = get_pkt_queue_db(info->mac);
		if (!client) {
			rcu_read_unlock();
			client = create_pkt_queue_db(info);
			if (!client) {
				pr_err("%s create_pkt_queue_db fail for "MAC2STR"\n",
					__func__, PRINT_MAC(info->mac));
				return -1;
			}
			spin_lock_bh(&client_head->hash_lock);
			hlist_add_head_rcu(&client->hlist, &client_head->client_head);
			spin_unlock_bh(&client_head->hash_lock);
		} else {
			rcu_read_unlock();
			update_pkt_queue_db(info);
		}
	} else {
		spin_lock_bh(&client_head->hash_lock);
		hlist_for_each_entry_safe(client, n, &client_head->client_head, hlist) {
			if (!memcmp(client->info.mac, info->mac, ETH_ALEN)) {
				found = 1;
				break;
			}
		}
		if (found == 0) {
			pr_err("%s no pkt queue for "MAC2STR"\n", __func__, PRINT_MAC(info->mac));
			spin_unlock_bh(&client_head->hash_lock);
			return -1;
		}
		spin_lock_bh(&client->skb_lock);
		hlist_for_each_entry_safe(db, n, &client->skb_list, hlist) {
			hlist_del(&db->hlist);
			seq1 = *(db->skb->data + 4);
			seq2 = *(db->skb->data + 5);
			pr_err("%s dequeue for "MAC2STR" seq=0x%02x%02x skb_cnt-%d for %d state\n",
				__func__, PRINT_MAC(info->mac), seq1, seq2, client->skb_cnt, db->state);
			dev = db->skb->dev;
			p = br_port_get_rcu(dev);
			pr_err("indev=%s", dev->name);
			dev = br_fdb_find_port(p->br->dev, client->info.mac, db->skb->vlan_tci);
			pr_err("outdev=%s", dev->name);
			skb_push(db->skb, ETH_HLEN);
			db->skb->dev = dev;
			dev_queue_xmit(db->skb);
			kfree(db);
			client->skb_cnt--;
		}
		spin_unlock_bh(&client->skb_lock);
		hlist_del_rcu(&client->hlist);
		spin_unlock_bh(&client_head->hash_lock);
		call_rcu(&client->rcu, free_pkt_queue_db);
	}
#endif
	return 0;
}

struct skb_db *create_skb_db(struct sk_buff *skb, struct net_device *indev,
	unsigned char state)
{
	struct skb_db *pkt = NULL;

	pkt = kmalloc(sizeof(struct skb_db), GFP_ATOMIC);
	if (pkt) {
		memset(pkt, 0, sizeof(struct skb_db));
		INIT_HLIST_NODE(&pkt->hlist);
		pkt->skb = skb;
		pkt->indev = indev;
		pkt->state = state;
	}

	return pkt;
}

unsigned int pkt_q_hook_fn_local_out(void *priv, struct sk_buff *skb,
	const struct nf_hook_state *state)
{
	struct ethhdr *hdr = NULL;
	const struct net_device *indev = NULL;
	struct hlist_head *head = NULL;
	struct skb_db *pkt = NULL;
	struct pkt_queue_db *client = NULL;
	unsigned int ret = NF_ACCEPT;
	unsigned char hash_idx = 0;
	unsigned char seq1 = 0, seq2 = 0;

	indev = state->in;

	if (!pkt_q.enable)
		goto end;

	hdr = eth_hdr(skb);
	if (hdr->h_proto != 0x0008 &&
		hdr->h_proto != 0x0800)
		goto end;

	hash_idx = MAC_ADDR_HASH_INDEX(hdr->h_dest);
	head = &pkt_q.clients[hash_idx].client_head;
	rcu_read_lock();
	hlist_for_each_entry(client, head, hlist) {
		if (!memcmp(client->info.mac, hdr->h_dest, ETH_ALEN))
			break;
	}
	if (!client) {
		rcu_read_unlock();
		goto end;
	}
	if (client->info.action == QUEUE) {
		pkt = create_skb_db(skb, (struct net_device *)indev, LOCAL_OUT);
		if (pkt) {
			seq1 = *(skb->data + 4);
			seq2 = *(skb->data + 5);
			spin_lock_bh(&client->skb_lock);
			pr_err("%s queue for "MAC2STR" seq=0x%02x%02x skb_cnt-%d\n",
				__func__, PRINT_MAC(hdr->h_dest), seq1, seq2, client->skb_cnt);
			hlist_add_tail_rcu(&pkt->hlist, &client->skb_list);
			client->skb_cnt++;
			spin_unlock_bh(&client->skb_lock);
		}
		rcu_read_unlock();
		return NF_STOLEN;
	}
	spin_lock_bh(&client->skb_lock);
	pr_err("%s dequeue not finished; skb_cnt-%d for "MAC2STR"\n",
		__func__, client->skb_cnt, PRINT_MAC(hdr->h_dest));
	spin_unlock_bh(&client->skb_lock);
	rcu_read_unlock();

end:
	return ret;
}

unsigned int pkt_q_hook_fn_pre_rout(void *priv, struct sk_buff *skb,
	const struct nf_hook_state *state)
{
	struct ethhdr *hdr = NULL;
	const struct net_device *indev = NULL;
	struct hlist_head *head = NULL;
	struct skb_db *pkt = NULL;
	struct pkt_queue_db *client = NULL;
	unsigned int ret = NF_ACCEPT;
	unsigned char hash_idx = 0;
	unsigned char seq1 = 0, seq2 = 0;

	indev = state->in;

	if (!pkt_q.enable)
		goto end;

	hdr = eth_hdr(skb);
	if (hdr->h_proto != 0x0008 &&
		hdr->h_proto != 0x0800)
		goto end;

	hash_idx = MAC_ADDR_HASH_INDEX(hdr->h_dest);
	head = &pkt_q.clients[hash_idx].client_head;
	rcu_read_lock();
	hlist_for_each_entry(client, head, hlist) {
		if (!memcmp(client->info.mac, hdr->h_dest, ETH_ALEN))
			break;
	}
	if (!client) {
		rcu_read_unlock();
		goto end;
	}
	if (client->info.action == QUEUE) {
		pkt = create_skb_db(skb, (struct net_device *)indev, PRE_ROUNTING);
		if (pkt) {
			seq1 = *(skb->data + 4);
			seq2 = *(skb->data + 5);
			spin_lock_bh(&client->skb_lock);
			pr_err("%s queue for "MAC2STR" seq=0x%02x%02x skb_cnt-%d\n",
				__func__, PRINT_MAC(hdr->h_dest), seq1, seq2, client->skb_cnt);
			hlist_add_tail_rcu(&pkt->hlist, &client->skb_list);
			client->skb_cnt++;
			spin_unlock_bh(&client->skb_lock);
		}
		rcu_read_unlock();
		return NF_STOLEN;
	}
	spin_lock_bh(&client->skb_lock);
	pr_err("%s dequeue not finished; skb_cnt-%d for "MAC2STR"\n",
		__func__, client->skb_cnt, PRINT_MAC(hdr->h_dest));
	spin_unlock_bh(&client->skb_lock);
	rcu_read_unlock();

end:
	return ret;
}




static struct nf_hook_ops pkt_q_ops[] = {
	{
		.hook		= pkt_q_hook_fn_local_out,
		.pf			= NFPROTO_BRIDGE,
		.hooknum	= NF_BR_LOCAL_OUT,
		.priority	= NF_BR_PRI_FIRST,
	},
	{
		.hook		= pkt_q_hook_fn_pre_rout,
		.pf			= NFPROTO_BRIDGE,
		.hooknum	= NF_BR_PRE_ROUTING,
		.priority	= NF_BR_PRI_FIRST,
	},
};

static ssize_t map_pkt_q_show(struct kobject *kobj,
		struct kobj_attribute *attr, char *buf)
{
	int len = 0, total_len = 0;
	unsigned short i = 0;
	struct cli_context *head = NULL;
	struct pkt_queue_db *client = NULL;

	len = snprintf(buf, PAGE_SIZE, "pkt queue information\n");
	if (snprintf_error(PAGE_SIZE - total_len, len))
		goto end;

	total_len += len;

	len = snprintf(buf + total_len, PAGE_SIZE, "status %s\n", pkt_q.enable ? "on" : "off");
	if (snprintf_error(PAGE_SIZE - total_len, len))
		goto end;

	total_len += len;

	rcu_read_lock();
	for (i = 0; i < HASH_TABLE_SIZE; i++) {
		head = &pkt_q.clients[i];
		hlist_for_each_entry_rcu(client, &head->client_head, hlist) {
			len = snprintf(buf + total_len, PAGE_SIZE,
				"mac(" MAC2STR ") action=%d direction=%02x skb_cnt=%d\n", PRINT_MAC(client->info.mac),
				client->info.action, client->info.direction, client->skb_cnt);
			if (snprintf_error(PAGE_SIZE - total_len, len)) {
				rcu_read_unlock();
				goto end;
			}
			total_len += len;
		}
	}
	rcu_read_unlock();
end:
	len = total_len;

	return len;
}

ssize_t map_pkt_q_config_set(struct kobject *kobj, struct kobj_attribute *attr,
	const char *buf, size_t count)
{
	if (sscanf(buf, "%hhu\n", &pkt_q.enable) < 0)
		pr_err("%s sscanf fail\n", __func__);

	pr_err("%s pkt_q %s\n", __func__, pkt_q.enable ? "on" : "off");

	return count;
}

ssize_t map_pkt_q_cli_config_set(struct kobject *kobj, struct kobj_attribute *attr,
	const char *buf, size_t count)
{
	struct queue_info info = {0};

	if (sscanf(buf, "%02x:%02x:%02x:%02x:%02x:%02x %hhu %hhu\n",
		(unsigned int *)&info.mac[0], (unsigned int *)&info.mac[1],
		(unsigned int *)&info.mac[2], (unsigned int *)&info.mac[3],
		(unsigned int *)&info.mac[4], (unsigned int *)&info.mac[5],
		&info.action, &info.direction) < 0)
		pr_err("[map_sysfs_pkt_q_cli_config] sscanf fail\n");

	pr_err("[map_sysfs_pkt_q_cli_config] cli=%pM action=%d direction=%d\n",
		info.mac, info.action, info.direction);

	handle_client_pkt_queue(&info);

	return count;
}


static struct kobj_attribute map_sysfs_pkt_q_show =
		__ATTR(show, S_IRUGO, map_pkt_q_show, NULL);
static struct kobj_attribute map_sysfs_pkt_q_config =
		__ATTR(config, S_IWUSR, NULL, map_pkt_q_config_set);
static struct kobj_attribute map_sysfs_pkt_q_cli_config =
		__ATTR(cli_config, S_IWUSR, NULL, map_pkt_q_cli_config_set);


static struct attribute *pkt_q_sysfs[] = {
	&map_sysfs_pkt_q_show.attr,
	&map_sysfs_pkt_q_config.attr,
	&map_sysfs_pkt_q_cli_config.attr,
	NULL,
};
static struct attribute_group pkt_q_attr_group = {
	.attrs = pkt_q_sysfs,
};


void pkt_queue_init(struct kobject *parent_obj)
{
	int i = 0, ret = 0;

	memset(&pkt_q, 0, sizeof(struct pkt_queue));
	pkt_q.enable = 0;

	pkt_q.obj = kobject_create_and_add("pkt_queue", parent_obj);
	if (!pkt_q.obj) {
		pr_info("kobject for pkt_queue create failure\n");
		return;
	}

	ret = sysfs_create_group(pkt_q.obj, &pkt_q_attr_group);
	if (ret) {
		pr_info("sysfs for ts create failure\n");
		return;
	}

	for (i = 0; i < HASH_TABLE_SIZE; i++) {
		INIT_HLIST_HEAD(&pkt_q.clients[i].client_head);
		spin_lock_init(&pkt_q.clients[i].hash_lock);
	}

	ret = nf_register_net_hooks(&init_net, &pkt_q_ops[0], ARRAY_SIZE(pkt_q_ops));
	if (ret < 0)
		pr_err("register nf hook for pkt_queue fail, ret = %d\n", ret);
}

void clear_pkt_queue(void)
{
	struct pkt_queue_db *client = NULL;
	struct hlist_node *n = NULL;
	struct cli_context *head = NULL;
	struct skb_db *db = NULL;
	struct hlist_head clear_list;
	int i = 0;

	INIT_HLIST_HEAD(&clear_list);

	for (i = 0; i < HASH_TABLE_SIZE; i++) {
		head = &pkt_q.clients[i];
		spin_lock_bh(&head->hash_lock);
		hlist_for_each_entry_safe(client, n, &head->client_head, hlist) {
			hlist_del_rcu(&client->hlist);
			hlist_add_head_rcu(&client->hlist, &clear_list);
		}
		spin_unlock_bh(&head->hash_lock);
	}

	hlist_for_each_entry_safe(client, n, &clear_list, hlist) {
		hlist_del_rcu(&client->hlist);
		synchronize_rcu();
		hlist_for_each_entry_safe(db, n, &client->skb_list, hlist) {
			hlist_del_rcu(&db->hlist);
			synchronize_rcu();
			kfree(db);
		}
		kfree(client);
	}
}


void pkt_queue_deinit(void)
{
	sysfs_remove_group(pkt_q.obj, &pkt_q_attr_group);
	kobject_put(pkt_q.obj);

	nf_unregister_net_hooks(&init_net, &pkt_q_ops[0], ARRAY_SIZE(pkt_q_ops));

	clear_pkt_queue();
}
